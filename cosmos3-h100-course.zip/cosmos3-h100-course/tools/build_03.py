"""Build 03_reasoning_captioning.ipynb.

Derived from the source DLI course `S-OV-57-V1`, notebook 02, section 1
("Video captioning", cells 12-14). The source spends three cells on it. This
lesson keeps its prompt and its fps=4 default, and expands the section into the
thing the rest of the course actually needs: structured scene records, produced
reproducibly, at a measured cost.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 03 — Captioning and structured scene records")

# ---------------------------------------------------------------- title
nb.md("""
# Lesson 03 — Captioning and structured scene records

**What you will build.** `outputs/03/scene_records.jsonl` — one structured,
schema-validated record per clip, produced reproducibly and at a cost you have
measured. Lesson 07 turns those records into generation prompts, and the
capstone runs the whole loop.

| | |
|---|---|
| **Time** | ~75 minutes |
| **GPU** | 1 × H100, with the Reasoner NIM from Lesson 02 already running |
| **Downloads** | None. Cookbook clips only. |
| **Prerequisites** | Lesson 02. The NIM must be up before you start. |

Captioning is the cheapest thing you can ask a reasoner to do and the one whose
output feeds everything downstream. That combination makes it the right place to
establish prompt discipline, because a sloppy caption format costs you nothing
today and costs you the whole pipeline in Module 6.
""")

nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Explain** what the model actually receives when you hand it a video, and
   compute the frame count from clip length and `fps`.
2. **Measure** how `fps` changes both the caption's content and its token cost,
   and choose a value for a stated purpose rather than accepting the default.
3. **Convert** a free-text caption prompt into a schema-constrained one, and
   parse the result reliably with `Reasoner.parse_json()`.
4. **Control** run-to-run variation with `seed`, `temperature` and `top_p`, and
   demonstrate the difference between a controlled and an uncontrolled prompt.
5. **Diagnose** an HTTP 422 caused by an undecodable video, from symptom to
   verified repair.
6. **Build** a batch captioner that writes one validated JSONL record per clip
   and reports its own throughput.
""")

# -------------------------------------------- Module 1 opener
nb.md("""
## Environment, and confirming the NIM is up

Before any of the theory, get the machine talking. The setup cell is the same in
every lesson, and the cell after it fails immediately — with instructions —
if the reasoner from Lesson 02 is not serving. Failing here costs five seconds.
Failing after twenty minutes of reading costs the reading.
""")

nb.code('__lesson__ = "03"   # OUTPUT_DIR resolves to outputs/03\n\n' + SETUP_CELL)

nb.code('''
from cosmos_course.nim import NimConfig, nim_status, print_status
from cosmos_course.models import Reasoner

NIM = NimConfig()
status = nim_status(NIM)

cc.require(
    status["ready"],
    f"The Cosmos 3 Reasoner NIM is not answering at {NIM.base_url}.\\n"
    f"  Every cell in this lesson needs it.",
    fix=(
        "Go back to Lesson 02 (02_serving_the_reasoner.ipynb) and run the "
        "start section, or from here:\\n"
        "        from cosmos_course.nim import start_nim\\n"
        "        start_nim(NimConfig())\\n"
        "      First start downloads ~20 GB and takes 10-30 minutes. If it was "
        "running earlier and is not now, read the logs:\\n"
        "        from cosmos_course.nim import nim_logs; print(nim_logs())"
    ),
)

print_status(NIM)
reasoner = Reasoner(base_url=NIM.base_url)
print()
print(f"model: {reasoner.model}")
''')

nb.md("""
## Module 1 in one table: the six things you can ask a reasoner

Lesson 02 got a server running. From here to the end of Lesson 05 you are asking
it questions, and there are six distinct kinds of question worth asking. This
table is the map of the module — it is carried from the source DLI course
(`S-OV-57-V1`, notebook 02) because it is the clearest single statement of what
a physical-world reasoner is *for*, with one column added: where each capability
is actually taught here.

| Capability | What it answers | Why it matters for Physical AI | Covered in |
| --- | --- | --- | --- |
| **Video captioning** | *What is happening in this clip?* | Turns raw video into structured scene descriptions | **Lesson 03 — this one** |
| **Embodied reasoning** | *What should the agent do next? What is the plan?* | Bridges perception to action | Lesson 04 |
| **Common-sense reasoning** | *Is this physically sensible?* | Grounds decisions in real-world physics | Lesson 04 |
| **2D grounding** | *Where exactly is object X?* | Localizes objects to interact with | Lesson 05 |
| **Describe anything** | *Describe each marked region.* | Fine-grained, region-level understanding | Lesson 05 |
| **Action chain-of-thought** | *What path should the gripper follow?* | Produces spatial plans for manipulation | Lesson 05 |

Read down the second column and notice that the six questions get progressively
harder to check. "What is happening?" has many acceptable answers and no wrong
one you can detect automatically. "Where exactly is object X?" has a right answer
with coordinates. **How hard a capability is to verify is not the same as how
hard it is to elicit**, and the two run in opposite directions here: captioning
is the easiest to get and the hardest to grade, trajectories the reverse. Each
lesson in this module is shaped by which end of that trade its capability sits at.

One structural point before you start. All six are the *same model*, the same
weights and the same endpoint. Nothing switches. The only thing that changes
between a caption and a gripper trajectory is the words in the prompt and what
you do with the reply — which is why prompt discipline, established below, is
worth more here than it looks.

That last claim is checkable against the server you just connected to.
""")

nb.code('''
# The six capabilities as data, plus the claim that they are all one model.
CAPABILITIES = {
    "video captioning":       ("what is happening in this clip",       "03"),
    "embodied reasoning":     ("what should the agent do next",        "04"),
    "common-sense reasoning": ("is this physically sensible",          "04"),
    "2D grounding":           ("where exactly is object X",            "05"),
    "describe anything":      ("describe each marked region",          "05"),
    "action chain-of-thought": ("what path should the gripper follow", "05"),
}

print(f"{'capability':<24}{'taught in':>10}   asks")
for name, (question, lesson) in CAPABILITIES.items():
    print(f"{name:<24}{'Lesson ' + lesson:>10}   {question}?")
print()
print(f"capabilities: {len(CAPABILITIES)}")
print(f"endpoints   : 1  ({NIM.base_url})")
print(f"models      : 1  ({reasoner.model})")
print()
print("There is no capability selector, no mode argument and no second endpoint.")
print("Every one of the six is this model answering a differently worded prompt,")
print("which is why the prompt is the entire interface.")
''')

# -------------------------------------------- conceptual foundation
nb.md("""
## The model never sees a video

This is the single most important idea in the lesson, and it is easy to miss
because the API takes a `.mp4` and gives you a paragraph about it.

What actually happens: the server **decodes the video and samples still frames
from it at a rate you choose**, then feeds those frames to a vision-language
model as a sequence of images. There is no temporal convolution, no optical
flow, no video encoder. There is a list of pictures and a language model.

```
  clip.mp4          decode          sample at fps        vision encoder
  8.0 s  ──────▶  240 frames  ──────▶   N frames   ──────▶  N x ~256 image tokens
  30 fps           (native)          N = 8.0 x fps           ───────────────▶ LLM
```

Two consequences follow, and both are practical.

**Cost.** Every sampled frame becomes a few hundred tokens in the context
window. Frame count is therefore the dominant cost lever in video reasoning —
larger than prompt length, larger than the answer length, usually by an order of
magnitude. You will measure this.

**What the model can notice.** An event shorter than the gap between samples is
invisible. At `fps=1` you see one frame per second; a gripper that closes over
300 ms either lands on a sampled frame or it does not exist. At `fps=8` you
almost certainly catch it — and you pay eight times the frame budget for the
whole clip to do so.

So `fps` is not a quality knob you turn up. It is a **statement about the
timescale of the thing you are asking about.**

> **`fps` here means the sampling rate for the model, not the clip's own frame
> rate.** They are unrelated numbers. A 30 fps clip sampled at `fps=4` gives the
> model 4 frames per second of footage, discarding 26. A 10 fps clip sampled at
> `fps=4` gives 4 per second too. And asking for `fps=60` on a 30 fps clip does
> not conjure frames that were never recorded — you get at most the native rate.

Both consequences are arithmetic, so do the arithmetic.
""")

nb.code('''
# What sampling rate costs, and what it can see. Two multiplications and a
# comparison; no model involved.
CLIP_SECONDS = 8.0
NATIVE_FPS = 30
TOKENS_PER_FRAME = 256      # order of magnitude for a vision encoder tile

print(f"a {CLIP_SECONDS:.0f} s clip recorded at {NATIVE_FPS} fps "
      f"= {CLIP_SECONDS * NATIVE_FPS:.0f} frames on disk")
print()
print(f"{'fps':>5}{'frames':>9}{'image tokens':>15}{'gap between':>14}"
      f"{'catches a 300 ms':>19}")
print(f"{'':>5}{'sampled':>9}{'':>15}{'samples':>14}{'gripper close?':>19}")
for fps in (1, 2, 4, 8, 16):
    frames = min(fps, NATIVE_FPS) * CLIP_SECONDS
    gap_ms = 1000.0 / min(fps, NATIVE_FPS)
    print(f"{fps:>5}{frames:>9.0f}{frames * TOKENS_PER_FRAME:>15,.0f}"
          f"{gap_ms:>12.0f} ms{'likely' if gap_ms <= 300 else 'no':>19}")
print()
print("The token column is the cost lever. The gap column is the limit on what")
print("the model can notice: an event shorter than the gap can fall between two")
print("samples and leave no trace. Choosing fps means choosing a timescale, and")
print("paying for it linearly.")
print()
print(f"asking for fps=60 on this clip still gives you at most "
      f"{min(60, NATIVE_FPS) * CLIP_SECONDS:.0f} frames — "
      f"sampling cannot invent footage that was never recorded.")
''')

nb.code('''
# Assets by name, never by path.
def need_asset(name):
    try:
        return cc.asset(name)
    except FileNotFoundError as exc:
        raise RuntimeError(
            f"{exc}\\n"
            f"  Fetch the cookbook:  python3 scripts/fetch_assets.py"
        ) from None

CLIP = need_asset("video_caption")

print(f"clip: {CLIP}")
print(f"size: {CLIP.stat().st_size / 1e6:.1f} MB")
cc.show_video(CLIP, caption="video_caption.mp4 — the source course's captioning clip")
''')

nb.md("""
### How long is it, and how many frames will the model see?

Ask `ffprobe`, do not guess. The frame count the model receives is what every
cost number in this lesson is a function of, so it deserves to be a measurement
rather than an assumption.
""")

nb.code('''
import json
import shutil
import subprocess

def probe(path):
    """Duration, native fps, codec and resolution, via ffprobe."""
    if shutil.which("ffprobe") is None:
        print("ffprobe not installed — `apt install ffmpeg`. Returning empty.")
        return {}
    out = subprocess.run(
        # One -show_entries with both sections. Passing the flag twice makes the
        # second call replace the first, which silently loses the duration.
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries",
         "stream=codec_name,width,height,avg_frame_rate,nb_frames:format=duration",
         "-of", "json", str(path)],
        capture_output=True, text=True, check=True,
    )
    data = json.loads(out.stdout)
    stream = (data.get("streams") or [{}])[0]
    num, _, den = (stream.get("avg_frame_rate") or "0/1").partition("/")
    native_fps = float(num) / float(den) if float(den or 0) else 0.0
    return {
        "codec": stream.get("codec_name"),
        "width": stream.get("width"),
        "height": stream.get("height"),
        "native_fps": round(native_fps, 2),
        "duration_s": round(float(data.get("format", {}).get("duration", 0.0)), 2),
    }

meta = probe(CLIP)
print(json.dumps(meta, indent=2))
print()
for rate in (1, 2, 4, 8):
    n = max(1, round(meta.get("duration_s", 0) * rate))
    print(f"  fps={rate}: the model would see about {n:4d} frames")
''')

# ------------------------------------------------- guided lab
nb.md("""
## The baseline caption

This is the source course's prompt and its `fps=4` default, unchanged, so you
have something to compare everything else against.
""")

nb.code('''
baseline_caption = reasoner.ask(
    "Describe the video in detail.",
    videos=CLIP,
    fps=4,
    max_tokens=4096,
)
print(baseline_caption)
print()
print(f"latency : {reasoner.last_latency_s} s")
print(f"usage   : {reasoner.last_usage}")
print()

# Verify it is language, not degenerate repetition or an empty 200.
print(cc.check_text(baseline_caption))
''')

nb.md("""
### About that `fps` argument

Here is a thing this course will not paper over. **The wire format for the
sampling rate is not verified against a live NIM 1.7 container.**

Every serving stack spells it differently. `cosmos_course.models` implements
three shapes and lets you switch between them:

| `fps_mode` | What goes on the wire |
|---|---|
| `"video_url"` (default) | `{"type": "video_url", "video_url": {"url": ..., "fps": 4.0}}` |
| `"extra_body"` | `fps` as a top-level key in `extra_body` |
| `"off"` | not sent at all; you get the server's default |

The source DLI course used a fourth shape —
`extra_body={"media_io_kwargs": {"video": {"fps": 4.0}}}` — which is the vLLM
convention and may well be what this NIM wants.

You do not have to take anyone's word for it, because **there is a measurement
that settles it**: send the same clip at two different `fps` values and compare
`prompt_tokens`. If the token count moves, the server honoured the field. If it
does not move, the field is being ignored and every "fps" result in this lesson
is measuring nothing.

Run that check now. It takes two requests.
""")

nb.code('''
def fps_is_honoured(clip, low=1, high=8, mode=None):
    """Does changing fps change prompt_tokens? The only test that matters."""
    probe_client = Reasoner(base_url=NIM.base_url, fps_mode=mode) if mode else reasoner
    counts = {}
    for rate in (low, high):
        probe_client.ask("Reply with the single word: ok.",
                         videos=clip, fps=rate, max_tokens=16)
        counts[rate] = probe_client.last_usage.get("prompt_tokens")
    print(f"  fps={low:<2} -> prompt_tokens={counts[low]}")
    print(f"  fps={high:<2} -> prompt_tokens={counts[high]}")
    changed = (
        counts[low] is not None and counts[high] is not None
        and counts[low] != counts[high]
    )
    print(f"  server honours fps: {changed}")
    return changed, counts

print(f"fps_mode in use: {reasoner.fps_mode!r}\\n")
FPS_HONOURED, fps_token_counts = fps_is_honoured(CLIP)
''')

nb.md("""
If that printed `False`, do not just carry on. Try the other modes before you
conclude anything:

```python
for mode in ("video_url", "extra_body", "off"):
    print(mode)
    fps_is_honoured(CLIP, mode=mode)
```

The mode whose token count *moves* is the one your server understands. Set it
for good with `export COSMOS_COURSE_VIDEO_FPS_MODE=<mode>` and restart the
kernel, or pass `Reasoner(fps_mode=...)` per instance.

If none of them move the count, the server is sampling at a fixed rate you
cannot control from the client. That is a real and reportable finding — write it
in your notes, and read the rest of this lesson as being about *frame count* in
general rather than about this particular knob.
""")

nb.predict_run_explain(
    predict=(
        "Pick a clip with a fast action in it — `robotics_next_action` is a "
        "robot mid-manipulation, which is a good one. Before running anything, "
        "write down: (a) one specific detail you expect the caption at `fps=8` "
        "to mention that the caption at `fps=1` will miss; (b) whether the "
        "`fps=1` caption will be shorter, longer, or about the same length."
    ),
    change=(
        "Run the sweep below. It captions the same clip at 1, 2, 4 and 8 frames "
        "per second with everything else — prompt, seed, temperature — held "
        "fixed, and records tokens and latency for each."
    ),
    explain=(
        "Was your specific detail present at 8 and absent at 1? If it was "
        "present at both, your prediction was about the wrong timescale — find "
        "an event that is genuinely brief. If it was absent at both, the model "
        "may simply not consider it notable, which is a prompt problem, not an "
        "fps problem. Say which of those two your result was."
    ),
    hint=(
        "Length is the trap here. People predict that fewer frames means a "
        "shorter caption. Output length is governed by the prompt and by "
        "`max_tokens`, not by how much the model saw — a model with less "
        "evidence often writes just as much, with more of it invented."
    ),
)

nb.code('''
import time

ACTION_CLIP = need_asset("robotics_next_action")
action_meta = probe(ACTION_CLIP)
print(f"clip     : {ACTION_CLIP.name}")
print(f"duration : {action_meta.get('duration_s')} s at {action_meta.get('native_fps')} native fps")
cc.show_video(ACTION_CLIP, caption="robotics_next_action.mp4")
''')

nb.code('''
FPS_SWEEP = (1, 2, 4, 8)
sweep = {}

for rate in FPS_SWEEP:
    started = time.perf_counter()
    text = reasoner.ask(
        "Describe the video in detail.",
        videos=ACTION_CLIP,
        fps=rate,
        max_tokens=1024,
        seed=0,
        temperature=0.0,
    )
    sweep[rate] = {
        "caption": text,
        "latency_s": round(time.perf_counter() - started, 2),
        "prompt_tokens": reasoner.last_usage.get("prompt_tokens"),
        "completion_tokens": reasoner.last_usage.get("completion_tokens"),
        "expected_frames": max(1, round(action_meta.get("duration_s", 0) * rate)),
    }
    print(f"fps={rate} done")

print()
header = f"{'fps':>4} {'frames~':>8} {'prompt_tok':>11} {'out_tok':>8} {'latency_s':>10}"
print(header)
print("-" * len(header))
for rate, row in sweep.items():
    print(f"{rate:>4} {row['expected_frames']:>8} {str(row['prompt_tokens']):>11} "
          f"{str(row['completion_tokens']):>8} {row['latency_s']:>10.2f}")

# Now read the captions themselves, not just the numbers. Diff them by eye:
# what appears at fps=8 that is missing at fps=1?
print()
for rate in FPS_SWEEP:
    print("=" * 72)
    print(f"fps = {rate}   ({sweep[rate]['expected_frames']} frames)")
    print("=" * 72)
    print(sweep[rate]["caption"][:1200])
    print()
''')

nb.md("""
### What the token numbers tell you

Look at `prompt_tokens` across the sweep and work out the relationship yourself
rather than being told one. Two questions:

1. Going from `fps=1` to `fps=8` multiplies the frame count by 8. By what factor
   did `prompt_tokens` multiply? If it is close to 8, the per-frame token cost is
   constant and the text part of your prompt is negligible.
2. Did latency scale the same way as tokens? If not, why not — what part of the
   request is *not* proportional to the number of frames?

Write both answers down before you continue. If the numbers do not scale at all,
go back to the `fps_is_honoured` check; you may be measuring a server that
ignores the field.
""")

nb.predict_run_explain(
    predict=(
        "Predict the prompt-token count for the *same clip* at `fps=16`, using "
        "only the four measurements you already have. Write the number down, "
        "and write down the rule you used to get it."
    ),
    change=(
        "Run the cell below, which measures `fps=16` and compares it with your "
        "extrapolation."
    ),
    explain=(
        "If your prediction was high, one likely reason is that the clip's "
        "native frame rate put a ceiling on how many frames could be sampled — "
        "you cannot sample 16 fps out of footage recorded at 10. Check the "
        "native rate you measured earlier. If it was low, look for a fixed "
        "overhead in the prompt that you divided out too early."
    ),
)

nb.code('''
predicted = None
if sweep[8]["prompt_tokens"] and sweep[4]["prompt_tokens"]:
    per_doubling = sweep[8]["prompt_tokens"] - sweep[4]["prompt_tokens"]
    predicted = sweep[8]["prompt_tokens"] + per_doubling * 2
    print(f"linear-in-frames extrapolation to fps=16: {predicted}")

reasoner.ask("Describe the video in detail.", videos=ACTION_CLIP,
             fps=16, max_tokens=256, seed=0, temperature=0.0)
measured = reasoner.last_usage.get("prompt_tokens")

print(f"measured at fps=16                       : {measured}")
if predicted and measured:
    print(f"ratio measured/predicted                 : {measured / predicted:.2f}")
print(f"clip native frame rate                   : {action_meta.get('native_fps')} fps")
print()
print("A ratio well below 1.0 means the clip ran out of frames to give you.")
''')

# ------------------------------------------ structured captions
nb.md("""
## From prose to a record

A paragraph is a fine thing for a human to read and a poor thing for a pipeline
to consume. Lesson 07 needs to take a caption and vary *one attribute of it* —
change the lighting, keep the subject — and you cannot vary an attribute of a
paragraph.

So: ask for a **structured** caption. Name the exact keys you want, give the
model an example of the shape, and tell it to reply with JSON and nothing else.

The schema below is the through-line of this whole course. `subjects`,
`setting`, `actions`, `lighting` and `camera` are the five axes Module 2 knows
how to condition on, which is why they are the five fields.
""")

nb.code('''
CAPTION_SCHEMA = {
    "subjects": ["list of strings: the main entities, most salient first"],
    "setting": "string: where this is, one sentence",
    "actions": ["list of strings: what happens, in temporal order"],
    "lighting": "string: quality, direction and colour of the light",
    "camera": "string: viewpoint, framing and any camera motion",
}

STRUCTURED_PROMPT = (
    "Describe this video as a structured scene record.\\n"
    "Reply with JSON only — no prose before it, no prose after it, no code "
    "fence.\\n"
    "Use exactly these keys and these types:\\n"
    + json.dumps(CAPTION_SCHEMA, indent=2)
    + "\\nIf a field cannot be determined from the video, use the string "
      "\\"unknown\\" rather than guessing or omitting the key."
)

print(STRUCTURED_PROMPT)
''')

nb.md("""
Three things in that prompt are doing real work, and it is worth knowing which:

- **"Reply with JSON only"** suppresses the model's strong habit of writing
  "Here is the JSON you asked for:" first. That preamble is the most common
  reason a naive `json.loads` fails.
- **The example object** pins key names *and* types. Without it you get
  `"subject"` sometimes and `"subjects"` others, and a string where you wanted a
  list.
- **The `"unknown"` instruction** stops the model from silently dropping a key
  it cannot fill. A missing key breaks a downstream `record["lighting"]`; the
  string `"unknown"` does not.
""")

nb.code('''
raw = reasoner.ask(STRUCTURED_PROMPT, videos=CLIP, fps=4,
                   max_tokens=1024, seed=0, temperature=0.0)
print(raw)
''')

nb.md("""
Now parse it. `Reasoner.parse_json` handles the four ways a model wraps JSON in
practice: markdown fences, prose before, prose after, and a preceding
`<think>` block. It scans for the first *balanced* brace pair rather than using
a greedy regex — given `[1,2] and then [3,4]`, a greedy `\\[.*\\]` returns the
whole span including the prose between them, which parses to nothing useful.

It raises `ValueError` rather than returning `None`, because a silent empty
result hides a prompt problem until it is much harder to attribute.
""")

nb.code('''
record = reasoner.parse_json(raw)
print(json.dumps(record, indent=2))
print()


def validate_record(rec):
    """Check one scene record against CAPTION_SCHEMA. Returns a list of problems."""
    problems = []
    if not isinstance(rec, dict):
        return [f"expected an object, got {type(rec).__name__}"]
    for key, example in CAPTION_SCHEMA.items():
        if key not in rec:
            problems.append(f"missing key {key!r}")
            continue
        want_list = isinstance(example, list)
        got_list = isinstance(rec[key], list)
        if want_list and not got_list:
            problems.append(f"{key!r} should be a list, got {type(rec[key]).__name__}")
        elif not want_list and not isinstance(rec[key], str):
            problems.append(f"{key!r} should be a string, got {type(rec[key]).__name__}")
    extra = set(rec) - set(CAPTION_SCHEMA)
    if extra:
        problems.append(f"unexpected keys: {sorted(extra)}")
    return problems

issues = validate_record(record)
print("valid" if not issues else "PROBLEMS:")
for item in issues:
    print(f"  - {item}")
''')

nb.callout("note", """
This is a *validator*, not a *constraint*. The server generated free text and
you checked it afterwards. Some serving stacks support genuine constrained
decoding — a grammar the sampler cannot leave — which makes malformed output
impossible rather than merely detectable. Whether NIM 1.7 exposes that is not
verified here. Until you have checked, assume the model can produce anything and
validate every record. A pipeline that trusts unvalidated model JSON fails at
3 a.m. on record 4,000.
""")

# --------------------------------------------- determinism
nb.md("""
## Determinism: why the same request gives different answers

Language models sample. At each step the model produces a probability
distribution over the next token — a score for every word in its vocabulary,
saying how likely each is to come next — and the sampler draws one token from
that distribution. Six parameters govern that draw. This is the course's
reference table for all six; later lessons pass them without re-explaining them.

The first three decide **which tokens are eligible**, and the last one of those
decides **which of the eligible ones you get**:

| Parameter | What it does | Effect on captioning |
|---|---|---|
| `temperature` | Scales the logits (the raw pre-probability scores) before the softmax that turns them into probabilities. Above 1 flattens the distribution and makes unlikely tokens more likely; below 1 sharpens it; `0` stops sampling altogether and always takes the single most likely token | `0` gives you repeatable captions |
| `top_p` | Nucleus sampling: sort tokens by probability, keep adding them until their probabilities sum to `p`, and sample only from that set. `top_p=0.95` throws away the least likely 5% of the probability mass | Trims the long tail of unlikely words |
| `top_k` | The blunter cousin of `top_p`: keep only the `k` most likely tokens and sample from those, whatever their probabilities add up to. `top_k=20` means the model may never pick its 21st choice, even where that choice was nearly as good as its 20th | Caps how strange a word can be, regardless of how flat the distribution is |
| `seed` | Initialises the random number generator the sampler draws from | Same seed plus same everything else gives the same output |

Those four are easier to believe once you have watched them operate on a
distribution you can see all of at once.
""")

nb.code('''
# A toy next-token distribution over seven words, so the three eligibility
# parameters are visible rather than abstract. Plain Python; this is arithmetic,
# not a model.
import math

VOCAB = ["kitchen", "room", "counter", "space", "workshop", "galley", "scullery"]
LOGITS = [4.0, 3.2, 2.6, 1.9, 1.0, 0.2, -0.6]


def softmax(logits, temperature):
    if temperature == 0:                      # greedy: all mass on the argmax
        best = max(range(len(logits)), key=lambda i: logits[i])
        return [1.0 if i == best else 0.0 for i in range(len(logits))]
    scaled = [x / temperature for x in logits]
    m = max(scaled)
    exps = [math.exp(x - m) for x in scaled]
    total = sum(exps)
    return [e / total for e in exps]


print("effect of temperature on the probabilities (same logits every time)")
print(f"{'temp':>6}  " + "".join(f"{w[:9]:>10}" for w in VOCAB))
for t in (0.0, 0.3, 0.7, 1.0, 2.0):
    probs = softmax(LOGITS, t)
    print(f"{t:>6}  " + "".join(f"{p:>10.3f}" for p in probs))
print("  temperature 0 puts everything on one word. Raising it flattens the row,")
print("  which is the same thing as making an unlikely word more reachable.")
print()

def nucleus(probs, p_cut):
    """The tokens top_p would keep: most likely first, until the mass reaches p."""
    order = sorted(range(len(probs)), key=lambda i: -probs[i])
    kept, mass = [], 0.0
    for i in order:
        kept.append(i)
        mass += probs[i]
        if mass >= p_cut:
            break
    return kept


print("how many of the 7 words survive each rule")
print(f"{'temp':>6}{'top_p=0.75':>12}{'top_p=0.90':>12}{'top_p=0.99':>12}{'top_k=4':>10}")
for t in (0.3, 1.0, 2.0):
    probs = softmax(LOGITS, t)
    counts = [len(nucleus(probs, p)) for p in (0.75, 0.90, 0.99)]
    print(f"{t:>6}" + "".join(f"{c:>12}" for c in counts) + f"{4:>10}")
print()
print("Read the top_p columns against the top_k column. As temperature flattens")
print("the row, top_p keeps MORE words, because it takes as many as it needs to")
print("reach the mass you asked for. top_k keeps 4 whatever happens, because it")
print("counts words and never looks at their probabilities. That is the whole")
print("difference: top_p adapts to the shape of the distribution, top_k does not.")
print()
print("At temperature 1.0, top_p=0.90 keeps:",
      [VOCAB[i] for i in nucleus(softmax(LOGITS, 1.0), 0.90)])
''')

nb.md("""
The remaining two parameters do something different. They do not restrict the
candidate set; they **rewrite the scores of tokens based on what has already been
generated**, to stop the model repeating itself:

| Parameter | What it does | Effect on captioning |
|---|---|---|
| `repetition_penalty` | Divides the score of any token that has already appeared, so repeats become less likely. `1.0` is off — no penalty. Above about `1.2` the model starts avoiding words it legitimately needs again, such as the name of the object it is describing | `1.0` leaves the model free to repeat a noun as often as the scene requires |
| `presence_penalty` | Subtracts a flat amount from the score of every token that has appeared at least once, however many times it appeared. `0.0` is off. It differs from `repetition_penalty` in being additive rather than multiplicative, and in not caring about the count | `0.0` is the neutral setting, which is what this course uses |

Two things worth holding onto. `top_p`, `top_k` and `temperature` interact:
setting `temperature=0` makes the other two irrelevant, because there is no
longer a draw to restrict. And the two penalties are the only parameters here
whose effect depends on what the model has already said — everything else
treats each step independently.

`Reasoner.ask` sends **none** of these unless you pass them. That is deliberate:
quietly substituting a default makes results irreproducible against the server's
own documented behaviour, and hides which knob is responsible when output
changes.

Watch what happens without them.
""")

nb.code('''
uncontrolled = [
    reasoner.ask("Describe the video in one sentence.", videos=CLIP, fps=2, max_tokens=120)
    for _ in range(3)
]
for i, text in enumerate(uncontrolled):
    print(f"[{i}] {text.strip()}")
print()
print(f"all three identical: {len(set(uncontrolled)) == 1}")
''')

nb.code('''
controlled = [
    reasoner.ask("Describe the video in one sentence.", videos=CLIP, fps=2,
                 max_tokens=120, temperature=0.0, top_p=1.0, seed=7)
    for _ in range(3)
]
for i, text in enumerate(controlled):
    print(f"[{i}] {text.strip()}")
print()
print(f"all three identical: {len(set(controlled)) == 1}")
''')

nb.callout("warning", """
If the controlled runs still differ, you have learned something real about your
server rather than hit a bug in the notebook. Batched inference on a GPU is not
bitwise deterministic: which other requests happen to be in the same batch
changes the reduction order in the matrix multiplies, which changes the last
bits of the logits, which occasionally flips an argmax. `temperature=0` removes
the *sampling* randomness and does not remove that. Report what you saw. For a
pipeline, the defensive answer is to store the caption you actually used
alongside the record, rather than assuming you can regenerate it.
""")

nb.md("""
### Which setting do you want?

Not `temperature=0` by default, and this surprises people.

- For a **scene record that feeds generation**, yes: you want it reproducible, so
  a downstream difference is attributable to the thing you changed.
- For **exploring what a model can see**, no: three samples at `temperature=0.7`
  tell you about the model's uncertainty, and a single greedy sample tells you
  nothing about it. Lesson 04's self-consistency exercise leans on exactly this.

The rule: fix the sampling when you are measuring something else, vary it when
the variation *is* the measurement.
""")

# --------------------------------------------- cost
nb.md("""
## What it costs

`Reasoner` records latency and token counts for every call it makes, on the
instance, in `history`. `stats()` aggregates. Nothing has to be wrapped or
instrumented — the numbers below are from the calls you already ran.

Note that the latency here is **end-to-end HTTP**: base64 encoding on this side,
transfer, decode, sampling, prefill, decode, transfer back. It is not GPU time,
and Lesson 14 will show you why conflating the two produces fictional numbers.
""")

nb.code('''
stats = reasoner.stats()
print(json.dumps(stats, indent=2))
print()
print(f"calls recorded: {len(reasoner.history)}")
print()

# Latency against frame count, from the sweep you already ran.
print(f"{'fps':>4} {'frames~':>8} {'prompt_tok':>11} {'latency_s':>10} {'s/frame':>9}")
print("-" * 46)
for rate, row in sweep.items():
    frames = row["expected_frames"]
    per_frame = row["latency_s"] / frames if frames else float("nan")
    print(f"{rate:>4} {frames:>8} {str(row['prompt_tokens']):>11} "
          f"{row['latency_s']:>10.2f} {per_frame:>9.3f}")
print()
print("If seconds-per-frame falls as fps rises, there is a fixed overhead being")
print("amortised over more frames. Name it: what in the request does not depend")
print("on how many frames there are?")
''')

nb.md("""
### Clip length is the other axis

Frame count is `duration × fps`, so a 30-second clip at `fps=2` costs the same as
a 15-second clip at `fps=4`. That equivalence is worth checking, because it
means you have two independent ways to buy the same budget — and they are not
equally good. Sampling densely over a short window and sparsely over a long one
answer different questions.

Trim before you send, not after. A base64-inlined 300 MB video becomes a ~400 MB
request body, and no amount of server-side sampling makes that transfer cheaper.
""")

nb.code('''
def trim(src, seconds, dst):
    """Cut the first `seconds` of a clip, re-encoded to H.264 so the NIM can read it."""
    if shutil.which("ffmpeg") is None:
        print("ffmpeg not installed; skipping trim.")
        return src
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-t", str(seconds),
         "-c:v", "libx264", "-crf", "20", "-preset", "veryfast",
         "-pix_fmt", "yuv420p", "-an", str(dst)],
        check=True, timeout=900,
    )
    return dst

half = trim(CLIP, max(1.0, meta.get("duration_s", 4.0) / 2), OUTPUT_DIR / "clip_half.mp4")

reasoner.ask("Describe the video in detail.", videos=CLIP, fps=2,
             max_tokens=256, seed=0, temperature=0.0)
full_tokens = reasoner.last_usage.get("prompt_tokens")

reasoner.ask("Describe the video in detail.", videos=half, fps=4,
             max_tokens=256, seed=0, temperature=0.0)
half_tokens = reasoner.last_usage.get("prompt_tokens")

print(f"full clip at fps=2 : {full_tokens} prompt tokens")
print(f"half clip at fps=4 : {half_tokens} prompt tokens")
print()
print("Same frame budget, different questions answered. Are the token counts close?")
''')

# ------------------------------------------ debugging lab
nb.md("""
## Debugging lab: HTTP 422 and zero decoded frames

**Symptom.** A video request that has worked all afternoon suddenly returns:

```
openai.UnprocessableEntityError: Error code: 422
```

The message says nothing about video. Nothing about codecs. The same clip plays
fine in your browser and in VLC. Images still work. Short videos still work.
This one does not.

**Hypothesis.** The NIM decodes video with **OpenCV**, whose bundled FFmpeg build
has no AV1 decoder. Handed an AV1 file, OpenCV does not raise — it opens the
container, reads the metadata, and returns **zero frames**. The server then has
a request with a video part containing no frames, and rejects it as
unprocessable.

This is not an edge case. LeRobot v3 datasets — the format all the Cosmos 3
action data ships in — store their video shards as AV1. So does a lot of what a
modern phone, screen recorder or YouTube download produces.

**Diagnostic.** `ffprobe`. One command, and it is the difference between a
five-minute fix and an afternoon.
""")

nb.code('''
def make_av1(src, dst):
    """Re-encode to AV1 so the failure is real rather than described.

    Returns None if no AV1 encoder is available in this ffmpeg build, which is
    common. In that case read the walkthrough below and run the ensure_h264
    verification on the clips you do have.
    """
    if shutil.which("ffmpeg") is None:
        return None
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    for encoder in ("libsvtav1", "libaom-av1"):
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-t", "3",
                 "-c:v", encoder, "-crf", "40", "-pix_fmt", "yuv420p", "-an", str(dst)],
                check=True, capture_output=True, timeout=900,
            )
            print(f"encoded a 3-second AV1 clip with {encoder}")
            return dst
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            continue
    print("no AV1 encoder in this ffmpeg build (libsvtav1 / libaom-av1 both absent).")
    print("The walkthrough below still applies; you just cannot reproduce it locally.")
    return None

av1_clip = make_av1(CLIP, OUTPUT_DIR / "broken_av1.mp4")
if av1_clip:
    print(json.dumps(probe(av1_clip), indent=2))
''')

nb.code('''
# Deliberately wrong: send the AV1 file with transcoding bypassed, so the 422
# arrives for real. Reasoner normally calls ensure_h264 for you, which is why
# this has to reach past the public method to reproduce the failure.
if av1_clip:
    import openai

    broken = Reasoner(base_url=NIM.base_url, max_retries=1)
    try:
        payload = broken._data_url(av1_clip)     # skips the ensure_h264 step
        client = broken._openai()
        client.chat.completions.create(
            model=broken.model,
            messages=[{"role": "user", "content": [
                {"type": "video_url", "video_url": {"url": payload}},
                {"type": "text", "text": "Describe the video."},
            ]}],
            max_tokens=64,
        )
        print("No error. Your NIM build can decode AV1 — note that, it is useful.")
    except openai.UnprocessableEntityError as exc:
        print("Reproduced: HTTP 422")
        print(str(exc)[:400])
    except Exception as exc:
        print(f"{type(exc).__name__}: {str(exc)[:400]}")
else:
    print("skipped — no AV1 clip was produced on this machine")
''', tags=["teaching-antipattern"])

nb.md("""
**Repair.** `Reasoner.ensure_h264()` transcodes to H.264 with `yuv420p`, caches
the result keyed on the source's path, mtime and size, and returns the original
untouched if it is already H.264. `Reasoner.ask` calls it automatically for every
local video — the cell above had to reach past that to reproduce the failure.

Note that it forces **`yuv420p`**, not just H.264. A 10-bit or 4:2:2 H.264
stream is perfectly valid and this decoder still cannot open it, producing the
identical symptom for a file whose codec name looks correct.

**Verification.** Two steps, both necessary. Confirm the codec changed, then
confirm the model actually saw frames — a request that returns 200 having seen
one frame is not a fix.
""")

nb.code('''
if av1_clip:
    fixed = reasoner.ensure_h264(av1_clip)
    print(f"source : {probe(av1_clip).get('codec')}   {av1_clip.name}")
    print(f"fixed  : {probe(fixed).get('codec')}   {fixed.name}")
    print()

    answer = reasoner.ask("Describe the video in one sentence.", videos=fixed,
                          fps=4, max_tokens=120)
    print(answer)
    print()
    print(cc.check_text(answer))
    print(f"prompt_tokens: {reasoner.last_usage.get('prompt_tokens')}  "
          f"(compare against a single image; many more means many frames arrived)")
else:
    print("skipped — no AV1 clip on this machine.")
    print("Run the verification on a clip you do have:")
    print(f"  reasoner.ensure_h264({CLIP.name!r})  ->  returns it unchanged, already h264")
''')

nb.callout("gotcha", """
`ensure_h264` needs `ffprobe` to know what the codec is. If `ffprobe` is
missing, it prints a warning and passes the file through **unchanged** — which
is the right call, because a needless transcode of an already-fine H.264 file
costs minutes and loses quality, and most video already is H.264. But it means
that on a machine without ffmpeg installed, this whole protection is silently
inactive and the 422 comes back. `apt install ffmpeg`.
""")

# ------------------------------------------- the artefact
nb.md("""
## Build the scene records

The artefact. One JSONL line per clip, each holding the validated record plus
enough provenance to reproduce it: the prompt, the sampling settings, the model
id, and the measured cost.

Provenance is not bureaucracy. In Lesson 07 you will look at a generated video
and want to know exactly which caption produced it and at what `fps`. A record
without that is an anecdote.
""")

nb.code('''
CLIP_NAMES = [
    "video_caption",
    "robotics_next_action",
    "situation_understanding",
    "common_sense",
    "temporal_localization",
    "physical_plausibility",
]

def caption_one(name, *, fps=4, seed=0):
    """Caption one named cookbook clip into a validated scene record."""
    path = need_asset(name)
    started = time.perf_counter()
    text = reasoner.ask(STRUCTURED_PROMPT, videos=path, fps=fps,
                        max_tokens=1024, seed=seed, temperature=0.0)
    elapsed = time.perf_counter() - started
    rec = reasoner.parse_json(text)
    return {
        "clip": name,
        "source_file": path.name,
        "record": rec,
        "problems": validate_record(rec),
        "provenance": {
            "model": reasoner.model,
            "fps": fps,
            "seed": seed,
            "temperature": 0.0,
            "fps_honoured_by_server": bool(FPS_HONOURED),
            "prompt_tokens": reasoner.last_usage.get("prompt_tokens"),
            "completion_tokens": reasoner.last_usage.get("completion_tokens"),
            "latency_s": round(elapsed, 2),
        },
    }

print(f"{len(CLIP_NAMES)} clips to caption.")
''')

nb.code('''
records = []
for name in CLIP_NAMES:
    try:
        row = caption_one(name)
    except Exception as exc:
        print(f"  {name:<26} FAILED  {type(exc).__name__}: {str(exc)[:120]}")
        continue
    records.append(row)
    flag = "ok" if not row["problems"] else f"{len(row['problems'])} problem(s)"
    print(f"  {name:<26} {flag:<16} {row['provenance']['latency_s']:>6.1f} s")

jsonl = OUTPUT_DIR / "scene_records.jsonl"
with jsonl.open("w", encoding="utf-8") as fh:
    for row in records:
        fh.write(json.dumps(row, ensure_ascii=False) + "\\n")

print()
print(f"wrote {len(records)} records to {jsonl}")
''')

nb.checkpoint(
    "Every record parses, has all five schema fields with the right types, and "
    "its caption text passes `check_text`. Do not go on to Lesson 04 until this "
    "passes — Lesson 07 reads this file.",
    '''
loaded = [json.loads(line) for line in jsonl.read_text(encoding="utf-8").splitlines() if line]
assert loaded, "scene_records.jsonl is empty"

bad = [row for row in loaded if row["problems"]]
for row in bad:
    print(f"  {row['clip']}: {row['problems']}")
assert not bad, f"{len(bad)} record(s) failed schema validation"

for row in loaded:
    blob = " ".join(str(v) for v in row["record"].values())
    result = cc.check_text(blob)
    assert result.passed, f"{row['clip']}: {result.reason}"

total_s = sum(row["provenance"]["latency_s"] for row in loaded)
print(f"checkpoint passed: {len(loaded)} valid records")
print(f"total captioning wall clock: {total_s:.1f} s "
      f"({total_s / len(loaded):.1f} s per clip on this machine)")
''',
)

# --------------------------------------------- exercises
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "Three clips, one schema, and what does not fit",
    goal=(
        "Find out where a fixed schema stops describing the world, by applying "
        "it to clips it was not designed around."
    ),
    instructions=(
        "1. Caption three clips of clearly different kinds — a robot "
        "manipulation clip, a driving clip (`drive_scene_next_action`), and "
        "`temporal_localization` — with the same `STRUCTURED_PROMPT`.\n"
        "2. Build a small table: for each clip and each of the five fields, is "
        "the value specific, generic, or `\"unknown\"`?\n"
        "3. Name one field that carries almost no information for one of the "
        "clips, and say why.\n"
        "4. Propose one additional field that would earn its place, and say "
        "which downstream lesson would use it."
    ),
    success=(
        "You have a filled table, one field identified as low-value with a "
        "reason, and one proposed field with a named consumer. A proposed field "
        "nobody downstream would read does not count."
    ),
    starter='''
COMPARE = ["robotics_next_action", "drive_scene_next_action", "temporal_localization"]

# YOUR CODE: caption each, then build the specific/generic/unknown table.
''',
    hints=[
        "`camera` is the field to look at hardest. On a fixed tripod shot it "
        "says the same thing every time, and a field with no variance carries "
        "no information — but it is exactly the field Lesson 07 conditions on, "
        "so 'useless here' and 'useless' are not the same claim.",
        "For the proposed field, think about what Module 2 can actually vary. "
        "A field describing something the generator cannot control is a field "
        "you will never use.",
    ],
    solution_ref="solutions/03_solutions.ipynb",
)

nb.exercise(
    "applied",
    "Caption to generation prompt",
    goal=(
        "Write `record_to_prompt(record)` that converts a scene record into a "
        "structured Cosmos 3 generation prompt, plus a validator that catches a "
        "bad conversion before it costs you a generation run."
    ),
    instructions=(
        "1. Read a real cookbook prompt to see the target shape: "
        "`cc.asset('prompt_robot_kitchen')` is a structured `text2video` prompt. "
        "Open it and note its fields.\n"
        "2. Write `record_to_prompt(record, *, style=None)` mapping your five "
        "schema fields onto that shape. Decide — and justify in a comment — what "
        "to do with `\"unknown\"` values: drop the field, or pass the word "
        "through?\n"
        "3. Write `validate_prompt(prompt)` that checks the result is complete, "
        "has no empty strings, and contains no leftover schema placeholder text "
        "like the word 'list of strings'.\n"
        "4. Run both over every record in your JSONL and report how many "
        "convert cleanly.\n"
        "5. Save the converted prompts to `outputs/03/generation_prompts.json`."
    ),
    success=(
        "Every record either converts to a prompt that passes "
        "`validate_prompt`, or is rejected with a stated reason. Nothing "
        "converts silently into a prompt containing the word 'unknown'."
    ),
    starter='''
kitchen = cc.asset_or_none("prompt_robot_kitchen")
if kitchen:
    print(json.dumps(json.loads(kitchen.read_text()), indent=2)[:1200])
else:
    print("cookbook prompt not fetched; run scripts/fetch_assets.py")

def record_to_prompt(record, *, style=None):
    """Convert one scene record into a structured generation prompt."""
    raise NotImplementedError

def validate_prompt(prompt):
    """Return a list of problems; empty means the prompt is usable."""
    raise NotImplementedError
''',
    hints=[
        "The `\"unknown\"` decision is the real content of this exercise. "
        "Passing it through puts the literal word into a generation prompt, and "
        "the model will try to render it. Dropping the field lets the generator "
        "choose freely. Neither is universally right — pick one and write down "
        "when you would pick the other.",
        "`actions` is a temporal list and most generation prompts want a single "
        "coherent description. Joining with commas produces something the "
        "generator reads as simultaneous. Think about what you actually want a "
        "5-second clip to contain.",
    ],
    solution_ref="solutions/03_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "A batch captioner with caching, retry and a manifest",
    goal=(
        "Turn the loop above into something you would leave running unattended "
        "over a directory of clips, and report its measured throughput."
    ),
    instructions=(
        "1. Write `caption_directory(src_dir, out_dir, *, fps=4, workers=1)` "
        "that finds every video under `src_dir` and produces one JSONL record "
        "each.\n"
        "2. **Cache** on a content key — the file's size and mtime, or a hash — "
        "so a re-run skips work already done. Prove it by running twice and "
        "showing the second run is dominated by skips.\n"
        "3. **Retry** transient failures with backoff, and do not retry "
        "permanent ones. A 422 retried four times is four times the wait for "
        "the same error; a connection reset is worth retrying.\n"
        "4. **Manifest**: write `manifest.json` with one entry per clip — "
        "status, cache hit or miss, retries used, latency, token counts — plus a "
        "summary block with totals, throughput in clips per minute, and the "
        "failure breakdown by cause.\n"
        "5. Measure throughput at `workers=1` and at `workers=4`. The NIM "
        "batches internally, so concurrency on the client side may help more "
        "than you expect, or not at all. Report which, with numbers.\n"
        "6. Handle the case where the NIM goes down mid-run: detect it, stop "
        "cleanly, and leave the manifest consistent so a re-run resumes."
    ),
    success=(
        "A second run over the same directory does almost no model work. The "
        "manifest accounts for every input file. You can state your measured "
        "throughput at both worker counts and say which is faster on your "
        "machine, with the numbers to back it."
    ),
    starter='''
# Build a small corpus to run against: the cookbook clips, symlinked or copied.
CORPUS = OUTPUT_DIR / "corpus"
CORPUS.mkdir(parents=True, exist_ok=True)
for name in CLIP_NAMES:
    src = cc.asset_or_none(name)
    if src and src.is_file():
        target = CORPUS / src.name
        if not target.exists():
            shutil.copy2(src, target)
print(f"corpus: {len(list(CORPUS.glob('*.mp4')))} clips in {CORPUS}")

def caption_directory(src_dir, out_dir, *, fps=4, workers=1):
    raise NotImplementedError
''',
    hints=[
        "Cache key: `f\"{path.name}:{stat.st_size}:{stat.st_mtime_ns}:{fps}:{seed}\"`. "
        "Include the settings, not just the file — a re-run at a different fps "
        "is different work and must not hit the cache.",
        "Retry policy: `openai.APIConnectionError`, `APITimeoutError`, "
        "`RateLimitError` and `InternalServerError` are worth retrying. "
        "`UnprocessableEntityError` (422) and `BadRequestError` (400) are not — "
        "the request is wrong and will stay wrong.",
        "For `workers>1`, `ThreadPoolExecutor` is right: these tasks are "
        "network-bound, and the GIL is released during the HTTP wait. Watch out "
        "for the shared `Reasoner` instance — its `history` list is appended "
        "from several threads at once, so either give each worker its own "
        "instance or accept that `stats()` is approximate.",
    ],
    solution_ref="solutions/03_solutions.ipynb",
)

# ------------------------------------- assessment
nb.md("""
## Assessment and reflection

### Knowledge check

1. A 12-second clip recorded at 30 fps is sent with `fps=3`. How many frames
   does the model see, and how many were discarded?
2. You want to know whether a gripper closed during a clip. The closing motion
   takes about 200 ms. What is the lowest `fps` that reliably catches it, and
   what assumption are you making?
3. Name the three things in `STRUCTURED_PROMPT` that make the output parseable,
   and say what breaks if you remove each one.
4. Why does `Reasoner.ask` send no `temperature` by default?
5. `temperature=0` and a fixed `seed` still gave you two different captions.
   Give a mechanism that explains it without either parameter being ignored.
6. An HTTP 422 on a video request: what is the first thing you check, and what
   command do you run?
7. Why does `ensure_h264` force `yuv420p` rather than only checking the codec
   name?
8. Two ways to halve the token cost of captioning a 20-second clip. Which would
   you choose for "did the robot drop the object?" and which for "what kind of
   room is this?"

### Practical completion test

Without looking back at the cells:

1. Caption any cookbook clip at two different `fps` values and state the token
   ratio you measured.
2. Produce one structured record that passes `validate_record` first try.
3. Produce two identical captions of the same clip in two separate calls.
4. Given a clip your NIM cannot decode, name the diagnostic command and the fix.
5. Read one line out of your `scene_records.jsonl` and state which `fps` and
   `seed` produced it, from the record alone.
""")

nb.code('''
def self_test():
    passed = []

    assert jsonl.exists(), "scene_records.jsonl was not written"
    rows = [json.loads(line) for line in jsonl.read_text().splitlines() if line]
    assert len(rows) >= 3, f"only {len(rows)} records; expected at least 3"
    passed.append(f"{len(rows)} scene records on disk")

    assert all(not row["problems"] for row in rows), "some records failed validation"
    passed.append("every record matches the schema")

    assert all(row["provenance"].get("fps") for row in rows), "provenance missing fps"
    assert all(row["provenance"].get("model") for row in rows), "provenance missing model"
    passed.append("every record carries reproducible provenance")

    a = reasoner.ask("Describe the video in one sentence.", videos=CLIP, fps=2,
                     max_tokens=80, temperature=0.0, top_p=1.0, seed=99)
    b = reasoner.ask("Describe the video in one sentence.", videos=CLIP, fps=2,
                     max_tokens=80, temperature=0.0, top_p=1.0, seed=99)
    if a == b:
        passed.append("fixed seed and temperature reproduced the caption exactly")
    else:
        passed.append("NOTE: greedy decoding was not bitwise reproducible here — "
                      "expected on a batching server; record it")

    for item in passed:
        print(f"  PASS  {item}")
    return passed

_ = self_test()
''')

nb.md("""
### Summary

- The model sees **sampled frames**, not video. `frames ≈ duration × fps`, and
  frame count dominates cost.
- `fps` states the timescale of your question. Raise it to catch brief events;
  lower it to caption a long clip affordably.
- Verify that your server honours `fps` at all — compare `prompt_tokens` at two
  rates — before drawing any conclusion from an fps experiment.
- Free text is for humans; **structured records are for pipelines**. Name the
  keys, give an example, forbid prose, and forbid omission.
- Validate every record. Generation is not constrained decoding unless you have
  confirmed it is.
- Fix sampling when you are measuring something else; vary it when the variation
  is the measurement.
- HTTP 422 on video means zero decoded frames until proven otherwise. `ffprobe`
  first, `ensure_h264` second, verify the token count third.

### Common misconceptions

| Belief | Correction |
|---|---|
| "Higher fps gives a better caption" | It gives a caption over more frames. If nothing brief happens, you paid for nothing. |
| "The model watches the video" | It reads N stills. Anything between samples did not happen as far as it is concerned. |
| "`temperature=0` guarantees identical output" | It removes sampling randomness. Batch-dependent floating-point reductions on a GPU can still flip an argmax. |
| "The JSON parsed, so the record is fine" | Parsing checks syntax. `validate_record` checks that the keys and types you need are there. |
| "The clip plays in VLC so the NIM can read it" | VLC has an AV1 decoder. The NIM's OpenCV build does not, and returns zero frames rather than an error. |
| "A short caption means the model saw less" | Output length is set by the prompt and `max_tokens`. A model with less evidence often writes just as much, with more invented. |

### Suggested extensions

- Caption the same clip at `fps=4` five times at `temperature=0.7`, and count how
  many distinct objects appear in at least four of the five. That intersection is
  a cheap confidence signal, and Lesson 04 builds it into a harness.
- Add a `duration_s` and `native_fps` field to the provenance block and check
  whether captions of clips longer than some threshold degrade.
- Feed one of your records into `cc.check_text` field by field rather than as one
  blob, and see which field is most often degenerate.

### Mastery checklist

- [ ] I can compute the frame count from a clip's duration and an `fps` value.
- [ ] I have verified whether my server honours `fps`, by token count.
- [ ] I measured the token and latency cost across an fps sweep.
- [ ] I can write a schema prompt that parses first time.
- [ ] I validate every record rather than trusting the parse.
- [ ] I know what `seed`, `temperature` and `top_p` each do.
- [ ] I can diagnose a 422 in under a minute.
- [ ] `outputs/03/scene_records.jsonl` exists and every line validates.

**Leave the NIM running.** Lesson 04 needs it.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "03_reasoning_captioning.ipynb")
