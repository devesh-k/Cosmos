"""Build solutions/18_solutions.ipynb — reference answers for Lesson 18."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("18", "Evaluation", lesson_file="18_evaluation.ipynb")

nb.header(
    "Lesson 18 builds an evaluation harness against a **fixture whose true effect is "
    "known**, which is the only situation in which you can find out whether an evaluator "
    "works. The foundation exercise tabulates per-prompt results with intervals and "
    "discovers how little a per-prompt interval can say. The applied one fixes a decision "
    "rule in advance, sweeps the seed count, and — the part that matters — measures the "
    "**false-positive rate on a null model pair**. The challenge one produces the report "
    "you would put your name on, with a recommendation."
)

nb.callout(
    "note",
    "**Everything in this notebook runs with no GPU.** The two \"models\" are synthetic "
    "fixtures differing in one number, so the harness, the statistics, the leakage gate "
    "and the false-positive measurement are all real and all executed here. What they are "
    "not is measurements of Cosmos 3 — and that is the point of a fixture: you cannot "
    "calibrate an evaluator against a model whose true effect you do not know.",
)

nb.prelude("The lesson's fixtures, harness, metrics and statistics, unchanged.")
nb.code(setup_cell("18"))

nb.code('''
import hashlib
import json
import math
import shutil
import statistics
from dataclasses import asdict, dataclass, field

import numpy as np
from PIL import Image

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

RUN_REAL_GENERATION = os.environ.get("COSMOS_COURSE_RUN_EVAL_GEN", "0") == "1"
FINETUNED_MODEL = (cc.OUTPUT_ROOT / "17" / "train" / "cosmos3" / "sft"
                   / "vision_sft_edge" / "model")
N_FRAMES, FRAME_SIZE = 8, 64


def _rng(*parts):
    """Deterministic RNG from arbitrary keys. NOT Python's salted hash()."""
    key = "|".join(str(p) for p in parts).encode()
    return np.random.default_rng(
        int.from_bytes(hashlib.sha1(key).digest()[:8], "big"))


MODELS = {
    "base": {"base_smoothness": 0.45, "effect": 0.00, "seed_noise": 0.03,
             "memorised": ()},
    "finetuned": {"base_smoothness": 0.45, "effect": 0.05, "seed_noise": 0.03,
                  "memorised": ()},
}
CATEGORY_GAIN = {"in-domain": 1.0, "near-domain": 0.5, "out-of-domain": -0.4}


def prompt_difficulty(prompt_id):
    return float(_rng(prompt_id, "difficulty").normal(0, 0.07))


def effective_smoothness(model, case, seed, *, noise=True, difficulty=True):
    cfg = MODELS[model]
    s = cfg["base_smoothness"] + cfg["effect"] * CATEGORY_GAIN[case.category]
    if difficulty:
        s += prompt_difficulty(case.prompt_id)
    if case.prompt_id in cfg["memorised"]:
        s += 0.15
    if noise:
        s += _rng(model, case.prompt_id, seed, "noise").normal(0, cfg["seed_noise"])
    return float(np.clip(s, 0.05, 0.95))


@dataclass
class EvalCase:
    prompt_id: str
    prompt: str
    category: str
    note: str = ""


@dataclass
class EvalRecord:
    model: str
    prompt_id: str
    seed: int
    ok: bool
    path: str | None = None
    metrics: dict = field(default_factory=dict)
    checks: dict = field(default_factory=dict)
    error: str = ""


def write_records(records, path):
    with Path(path).open("w") as fh:
        for r in records:
            fh.write(json.dumps(asdict(r)) + "\\n")
    return path


print(f"RUN_REAL_GENERATION : {RUN_REAL_GENERATION}")
print(f"fine-tuned export   : present={FINETUNED_MODEL.exists()}")
''')

nb.code('''
def _spatial_smooth(a, strength, passes=6):
    out = a.copy()
    for _ in range(passes):
        blur = (out + np.roll(out, 1, 0) + np.roll(out, -1, 0)
                + np.roll(out, 1, 1) + np.roll(out, -1, 1)) / 5.0
        out = (1.0 - strength) * out + strength * blur
    return out


def render(smoothness, content_key, out_dir):
    """Write a frame stack. `content_key` excludes the model on purpose."""
    rng = _rng(*content_key)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    frames, prev = [], rng.normal(0, 1, (FRAME_SIZE, FRAME_SIZE))
    for i in range(N_FRAMES):
        prev = 0.8 * prev + 0.2 * rng.normal(0, 1, (FRAME_SIZE, FRAME_SIZE))
        img = _spatial_smooth(prev, smoothness)
        arr = ((img - img.min()) / (np.ptp(img) + 1e-9) * 255).astype(np.uint8)
        path = out_dir / f"frame_{i:03d}.png"
        Image.fromarray(arr).save(path)
        frames.append(path)
    return frames


def synthesise(model, case, seed, out_dir):
    return render(effective_smoothness(model, case, seed),
                  (case.prompt_id, seed), out_dir)


def load_stack(paths):
    return np.stack([np.asarray(Image.open(p), dtype=np.float64) for p in paths])


def structure(stack):
    """Spatial autocorrelation at lag 1, averaged over frames and both axes."""
    vals = []
    for f in stack:
        for shifted in (np.roll(f, 1, 0), np.roll(f, 1, 1)):
            a, b = f.ravel(), shifted.ravel()
            a = a - a.mean()
            b = b - b.mean()
            denom = math.sqrt((a * a).sum() * (b * b).sum()) + 1e-9
            vals.append(float((a * b).sum() / denom))
    return sum(vals) / len(vals)


def aliveness(stack):
    if len(stack) < 2:
        return 0.0
    return float(np.abs(np.diff(stack, axis=0)).mean() / 255.0)


def stability(stack):
    if len(stack) < 3:
        return 0.0
    per_frame = np.abs(np.diff(stack, axis=0)).mean(axis=(1, 2))
    return float(np.std(per_frame) / 255.0)


def measure(paths):
    stack = load_stack(paths)
    return {"structure": round(structure(stack), 4),
            "aliveness": round(aliveness(stack), 4),
            "stability": round(stability(stack), 4)}


def run_suite(models, cases, seeds, root, *, generate=synthesise):
    """Every (model, case, seed). Verified, measured, recorded — failures too."""
    records = []
    for model in models:
        for case in cases:
            for seed in seeds:
                out = Path(root) / model / case.prompt_id / f"seed{seed}"
                try:
                    paths = generate(model, case, seed, out)
                except Exception as exc:                      # noqa: BLE001
                    records.append(EvalRecord(model, case.prompt_id, seed,
                                              ok=False, error=repr(exc)))
                    continue
                check = cc.check_image(paths[0])
                records.append(EvalRecord(
                    model=model, prompt_id=case.prompt_id, seed=seed,
                    ok=bool(check.passed), path=str(out), metrics=measure(paths),
                    checks={"first_frame": check.passed,
                            "reason": check.reason[:120]}))
    return records


def paired_differences(records, metric="structure", model_a="base",
                       model_b="finetuned", cases=None):
    index = {(r.model, r.prompt_id, r.seed): r for r in records}
    keys = sorted({(r.prompt_id, r.seed) for r in records
                   if cases is None or r.prompt_id in cases})
    diffs, used = [], []
    for prompt_id, seed in keys:
        ra, rb = index.get((model_a, prompt_id, seed)), index.get((model_b, prompt_id, seed))
        if not (ra and rb and ra.ok and rb.ok):
            continue
        diffs.append(rb.metrics[metric] - ra.metrics[metric])
        used.append((prompt_id, seed))
    return diffs, used


def stats_of(diffs):
    n = len(diffs)
    mean = statistics.mean(diffs) if n else float("nan")
    sd = statistics.stdev(diffs) if n > 1 else float("nan")
    se = sd / math.sqrt(n) if n > 1 else float("nan")
    return {"n": n, "mean": mean, "sd": sd, "se": se,
            "lo": mean - 1.96 * se, "hi": mean + 1.96 * se}


# ---- the in-memory fast path -------------------------------------------
# Hint 1 of Exercise 2: the sweeps are a few thousand samples, and writing each
# as eight PNGs makes them IO-bound on a workload that is arithmetic. The
# harness does not care where load_stack reads from, so the sweeps use arrays
# and the REPORTED evaluations use files.
#
# What the fast path gives up: cc.check_image, which needs a file. That is
# acceptable for a SWEEP over a fixture that cannot produce a blank frame, and
# it is not acceptable for anything reported — so the foundation exercise and
# the final evaluation below both use the file-based run_suite.
def render_array(smoothness, content_key):
    rng = _rng(*content_key)
    frames, prev = [], rng.normal(0, 1, (FRAME_SIZE, FRAME_SIZE))
    for _ in range(N_FRAMES):
        prev = 0.8 * prev + 0.2 * rng.normal(0, 1, (FRAME_SIZE, FRAME_SIZE))
        img = _spatial_smooth(prev, smoothness)
        frames.append((img - img.min()) / (np.ptp(img) + 1e-9) * 255)
    return np.stack(frames)


def measure_stack(stack):
    return {"structure": round(structure(stack), 4),
            "aliveness": round(aliveness(stack), 4),
            "stability": round(stability(stack), 4)}


def run_suite_fast(models, cases, seeds):
    """run_suite without the filesystem. Same records, no check_image."""
    records = []
    for model in models:
        for case in cases:
            for seed in seeds:
                stack = render_array(effective_smoothness(model, case, seed),
                                     (case.prompt_id, seed))
                records.append(EvalRecord(
                    model=model, prompt_id=case.prompt_id, seed=seed, ok=True,
                    path=None, metrics=measure_stack(stack),
                    checks={"first_frame": None,
                            "reason": "in-memory sweep: check_image skipped"}))
    return records


print("harness ready (file-based run_suite and in-memory run_suite_fast)")
''')

nb.code('''
CLEAN_SUITE = [
    EvalCase("clean_a", "A mechanical claw transfers a cylinder between two "
             "shelves.", "in-domain", note="written independently"),
    EvalCase("clean_b", "An articulated manipulator opens a drawer and reaches "
             "inside.", "in-domain"),
    EvalCase("clean_c", "A gantry robot lowers a component onto a conveyor.",
             "in-domain"),
    EvalCase("clean_d", "A human hand stacks three wooden rings onto a peg.",
             "near-domain"),
    EvalCase("clean_e", "Waves break against rocks beneath a lighthouse.",
             "out-of-domain", note="regression check: must NOT improve"),
    EvalCase("clean_f", "Traffic moves through a city intersection at dusk.",
             "out-of-domain", note="regression check: must NOT improve"),
]
CAL_DIR = OUTPUT_DIR / "calibration"


def metric_at(smoothness, tag="cal"):
    return measure(render(smoothness, ("calibration",), CAL_DIR / tag))["structure"]


cal_case = EvalCase("calibration", "calibration probe", "in-domain")
s_base = effective_smoothness("base", cal_case, 0, noise=False, difficulty=False)
s_tuned = effective_smoothness("finetuned", cal_case, 0, noise=False, difficulty=False)
TRUE_EFFECT = metric_at(s_tuned, "tuned") - metric_at(s_base, "base")


def expected_pooled_effect(cases):
    gains = [CATEGORY_GAIN[c.category] for c in cases]
    return TRUE_EFFECT * (sum(gains) / len(gains))


print(f"TRUE_EFFECT (in-domain, metric units) : {TRUE_EFFECT:+.4f}")
print(f"expected pooled over CLEAN_SUITE      : "
      f"{expected_pooled_effect(CLEAN_SUITE):+.4f}")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Run the evaluator and tabulate the result",
    goal="Produce a per-prompt table of base against fine-tuned with intervals, and say "
         "for each prompt whether the difference survives seed variance.",
    success="One row per prompt, intervals on every difference, a written answer to step "
            "4 referring to the measured seed variance, and a stated choice of metric.",
    approach="Compute the per-prompt intervals honestly, compare the count of "
             "interval-excludes-zero prompts against what the measured noise **predicts**, "
             "and repeat with `aliveness` to show a metric behaving correctly by "
             "detecting nothing.",
)

nb.code('''
SEEDS = list(range(8))          # step 1: at least six
records = run_suite(["base", "finetuned"], CLEAN_SUITE, SEEDS,
                    OUTPUT_DIR / "runs")
write_records(records, OUTPUT_DIR / "records.jsonl")
n_ok = sum(r.ok for r in records)
print(f"{len(records)} samples, {n_ok} passed verification, "
      f"{len(records) - n_ok} failed")


def per_prompt_table(records, metric="structure",
                     model_a="base", model_b="finetuned", cases=CLEAN_SUITE):
    """One row per prompt: means, paired difference, interval, verdict."""
    index = {(r.model, r.prompt_id, r.seed): r for r in records}
    rows = []
    for case in cases:
        d, used = paired_differences(records, metric=metric, model_a=model_a,
                                     model_b=model_b, cases={case.prompt_id})
        s = stats_of(d)
        a_vals = [index[(model_a, pid, sd)].metrics[metric] for pid, sd in used]
        b_vals = [index[(model_b, pid, sd)].metrics[metric] for pid, sd in used]
        rows.append({"prompt_id": case.prompt_id, "category": case.category,
                     "base_mean": statistics.mean(a_vals) if a_vals else float("nan"),
                     "tuned_mean": statistics.mean(b_vals) if b_vals else float("nan"),
                     "diff": s["mean"], "sd": s["sd"], "se": s["se"],
                     "lo": s["lo"], "hi": s["hi"], "n": s["n"],
                     "excludes_zero": bool(s["lo"] > 0 or s["hi"] < 0),
                     "expected": TRUE_EFFECT * CATEGORY_GAIN[case.category]})
    return rows


def print_table(rows, metric):
    print(f"metric = {metric}")
    print(f"{'prompt':<10}{'category':<15}{'base':>8}{'tuned':>8}{'diff':>9}"
          f"{'95% interval':>22}{'excl 0':>8}{'expected':>10}")
    print("-" * 92)
    for r in rows:
        print(f"{r['prompt_id']:<10}{r['category']:<15}{r['base_mean']:>8.4f}"
              f"{r['tuned_mean']:>8.4f}{r['diff']:>+9.4f}"
              f"   [{r['lo']:+.4f}, {r['hi']:+.4f}]{'YES' if r['excludes_zero'] else 'no':>8}"
              f"{r['expected']:>+10.4f}")
    fired = sum(r["excludes_zero"] for r in rows)
    print(f"\\n{fired} of {len(rows)} prompts have an interval excluding zero")
    return fired


rows_structure = per_prompt_table(records, metric="structure")
fired_structure = print_table(rows_structure, "structure")
''')

nb.code('''
# Step 4 needs the MEASURED seed variance, not intuition. Measure it directly:
# the same model, the same prompt, varying only the seed.
def seed_variance(records, model="base", metric="structure"):
    by_prompt = {}
    for r in records:
        if r.model == model and r.ok:
            by_prompt.setdefault(r.prompt_id, []).append(r.metrics[metric])
    sds = [statistics.stdev(v) for v in by_prompt.values() if len(v) > 1]
    return statistics.mean(sds) if sds else float("nan")


sigma = seed_variance(records)
n_seeds = len(SEEDS)
# A paired difference is the difference of two independent noisy measurements,
# so its sd is sqrt(2) * sigma, and its standard error is that over sqrt(n).
predicted_se = math.sqrt(2) * sigma / math.sqrt(n_seeds)
observed_se = statistics.mean([r["se"] for r in rows_structure])
print(f"measured per-sample seed sd (base model) : {sigma:.4f}")
print(f"predicted per-prompt SE at n={n_seeds}         : {predicted_se:.4f}")
print(f"observed  per-prompt SE (mean over prompts): {observed_se:.4f}")
print()
print("These agree, which is the check that the intervals are the right SIZE. "
      "A large disagreement would mean the interval is computed wrongly and "
      "every verdict above is unreliable.")

# What SHOULD fire, given the true effects and this SE? A per-prompt interval
# excludes zero when |effect| > 1.96 * SE.
threshold = 1.96 * observed_se
print(f"\\ndetection threshold at this n: |effect| > {threshold:.4f}")
print(f"{'prompt':<10}{'expected effect':>17}{'detectable?':>14}{'fired?':>9}")
for r in rows_structure:
    should = abs(r["expected"]) > threshold
    print(f"{r['prompt_id']:<10}{r['expected']:>+17.4f}"
          f"{'yes' if should else 'no':>14}{'yes' if r['excludes_zero'] else 'no':>9}")
predicted_fires = sum(abs(r["expected"]) > threshold for r in rows_structure)
print(f"\\npredicted to fire: {predicted_fires}   actually fired: {fired_structure}")
''')

nb.code('''
# Step 5: the same table with `aliveness`. The planted effect is SPATIAL
# smoothing; aliveness measures TEMPORAL change. Expect nothing.
rows_alive = per_prompt_table(records, metric="aliveness")
fired_alive = print_table(rows_alive, "aliveness")
print()
print(f"structure: {fired_structure}/{len(rows_structure)} fired   "
      f"aliveness: {fired_alive}/{len(rows_alive)} fired")
print()
print("A metric that detects nothing here is not a broken metric. `aliveness` "
      "is doing exactly what it is for — measuring whether the clip moves — and "
      "the planted effect does not change whether the clip moves. Reporting "
      "'aliveness shows no difference' as a NEGATIVE RESULT about the model "
      "would be the error, and it is a common one: a metric insensitive to the "
      "change you made will always report no difference, whatever the model does.")
''')

nb.model_answer(
    "**How many prompts survive seed variance, is that the expected number, and which "
    "metric would I report?**\n\n"
    "**How many, and why so few.** With eight seeds, each per-prompt interval rests on "
    "eight paired differences. The standard error is `sqrt(2) x sigma / sqrt(n)` — "
    "`sqrt(2)` because a paired difference is the difference of two noisy measurements — "
    "and at this noise level that lands close to the size of the in-domain effect itself. "
    "So only the prompts whose true effect is *largest* clear `1.96 x SE`, and the "
    "near-domain prompt (half the gain) and the out-of-domain ones (a smaller negative "
    "gain) generally do not.\n\n"
    "**Is that what I would expect?** Yes, and the cell above checks it rather than "
    "asserting it: it computes the detection threshold from the *measured* seed variance "
    "and predicts, per prompt, whether that prompt's true effect should clear it. The "
    "predicted count and the actual count agree. That agreement is worth more than "
    "either number, because it means the intervals are the right size — if the observed "
    "SE had come out at half the predicted one, every verdict in the table would be "
    "wrong in the direction of over-confidence, and nothing else in the analysis would "
    "have shown it.\n\n"
    "**Why per-prompt intervals are the wrong thing to want.** Hint 1 states it and the "
    "arithmetic is unforgiving: going from four seeds to eight divides the SE by "
    "`sqrt(2)`, and getting to sixteen divides it by two. Halving a per-prompt interval "
    "costs four times the compute, every time. **Pooling across prompts is what buys "
    "precision**, because six prompts at eight seeds is 48 paired differences rather "
    "than eight — the same generations, a `sqrt(6)` narrower interval. The reason to "
    "compute per-prompt rows at all is not to test each prompt; it is to see whether the "
    "effect is *consistent in sign* across prompts, which pooling hides.\n\n"
    "**Which metric I would report: `structure`, pooled, split by category.** Three "
    "reasons.\n\n"
    "First, it is the only one of the three sensitive to the change that was made — "
    "which I know here because the fixture told me, and which in a real evaluation I "
    "would have to establish by planting a known change and checking the metric moves. "
    "That step is not optional and it is the one everybody skips.\n\n"
    "Second, `aliveness` detecting nothing is *correct behaviour*, not a failure, and "
    "the distinction matters enormously in practice. A metric that cannot see your effect "
    "will report \"no difference\" for a model that improved a great deal, and the "
    "report will look rigorous. The defence is to know, in advance, what each metric can "
    "see — which is why all three are computed and only one is reported.\n\n"
    "Third, split by category, because a pooled mean over a suite containing "
    "out-of-domain regression prompts is a *composition-weighted* average of an "
    "improvement and a regression. Change the suite's composition and the headline "
    "number changes with the model unchanged. `expected_pooled_effect` exists to make "
    "that visible, and reporting the categories separately is what stops the headline "
    "being a property of the prompt list.\n\n"
    "**One thing I would add to the table.** The `stability` column. The planted effect "
    "is spatial, so `stability` should show nothing — and a third metric that correctly "
    "shows nothing is a free specificity check on the one that shows something. If "
    "`structure` and `stability` both moved, the fixture would be doing something "
    "broader than advertised and the calibration would be suspect."
)

nb.extend(
    "The intervals here are normal-approximation intervals on a mean of eight "
    "differences, which is thin. A **paired bootstrap** — resample the (prompt, seed) "
    "pairs with replacement a few thousand times and take percentiles of the resampled "
    "means — makes no distributional assumption and costs milliseconds, since the "
    "generations are already done. It matters most where it is easiest to be wrong: "
    "small n, and a difference distribution that may be skewed because the metric is "
    "concave in the underlying parameter. It also generalises to statistics with no "
    "closed-form interval, such as the median difference or the fraction of pairs that "
    "improved — and that last one is often the number a reader actually wants."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "Does the difference survive a variance estimate?",
    goal="Add a proper variance estimate over N seeds and decide, with a rule fixed in "
         "advance, whether the difference is real.",
    success="A decision rule written before the analysis, a plot of half-width against N, "
            "a measured false-positive rate on a null model pair, and a chosen N with a "
            "justification.",
    approach="Write the rule down first including its regression clause, sweep N on both "
             "the real pair and a null pair, and measure the false-positive rate over "
             "repeated **experiments** rather than repeated samples.",
)

nb.md(
    "### The decision rule, fixed before any of the analysis below\n\n"
    "> **I will claim an improvement if, on the `structure` metric, the 95% paired "
    "confidence interval over the in-domain and near-domain prompts excludes zero **and** "
    "is positive, **and** the out-of-domain prompts' paired mean is not more negative "
    "than −2 × TRUE\\_EFFECT.**\n\n"
    "Three parts, each doing a job:\n\n"
    "- **The metric is named.** Otherwise the rule is satisfiable by trying all three and "
    "reporting whichever fires — which is three chances at a 5% test.\n"
    "- **The interval must exclude zero *and* be positive.** An interval excluding zero "
    "on the negative side is a regression, and a rule that fires on it would report a "
    "harm as an improvement.\n"
    "- **The regression clause.** A fine-tune that improves in-domain content and "
    "destroys everything else is a trade, not an improvement. The threshold is expressed "
    "as a multiple of the known effect so it scales with the experiment rather than "
    "being an absolute number pulled from nowhere.\n\n"
    "Fixed here, before the sweep runs. Everything after this point is measurement."
)

nb.code('''
MODELS["null_model"] = dict(MODELS["base"])     # identical to base: zero effect

IN_NEAR = {c.prompt_id for c in CLEAN_SUITE if c.category != "out-of-domain"}
OOD = {c.prompt_id for c in CLEAN_SUITE if c.category == "out-of-domain"}


def rule_fires(records, model_b, metric="structure"):
    """The decision rule, as code. Returns (fires, detail)."""
    d_main, _ = paired_differences(records, metric=metric, model_b=model_b,
                                   cases=IN_NEAR)
    if len(d_main) < 2:
        return False, {"reason": "not enough pairs"}
    s = stats_of(d_main)
    d_ood, _ = paired_differences(records, metric=metric, model_b=model_b,
                                  cases=OOD)
    ood_mean = statistics.mean(d_ood) if d_ood else 0.0
    excludes_zero_positive = s["lo"] > 0
    regression_ok = ood_mean >= -2 * TRUE_EFFECT
    return (excludes_zero_positive and regression_ok,
            {"mean": s["mean"], "lo": s["lo"], "hi": s["hi"], "n": s["n"],
             "half_width": (s["hi"] - s["lo"]) / 2, "ood_mean": ood_mean,
             "excludes_zero_positive": excludes_zero_positive,
             "regression_ok": regression_ok})


def sweep_seeds(model_b, cases, max_seeds=32, metric="structure", offset=0):
    """For N = 2..max_seeds, return (n, mean, half_width, rule_fires)."""
    out = []
    for n in range(2, max_seeds + 1, 2):
        seeds = list(range(offset, offset + n))
        recs = run_suite_fast(["base", model_b], cases, seeds)
        fires, detail = rule_fires(recs, model_b, metric=metric)
        out.append({"n": n, "fires": fires, **detail})
    return out


real_sweep = sweep_seeds("finetuned", CLEAN_SUITE, max_seeds=32)
print(f"{'N':>4}{'mean':>10}{'half width':>13}{'ood':>10}{'fires':>8}")
print("-" * 47)
for row in real_sweep:
    print(f"{row['n']:>4}{row['mean']:>+10.4f}{row['half_width']:>13.4f}"
          f"{row['ood_mean']:>+10.4f}{'YES' if row['fires'] else 'no':>8}")

firing = [r["n"] for r in real_sweep if r["fires"]]
first_reliable = None
for row in real_sweep:
    later = [r for r in real_sweep if r["n"] >= row["n"]]
    if later and all(r["fires"] for r in later):
        first_reliable = row["n"]
        break
print(f"\\nrule first fires at N={min(firing) if firing else None}; "
      f"fires for every N from {first_reliable} upwards")
''')

nb.code('''
# Step 4: the null pair. Same harness, a model with ZERO true effect. Hint 1 is
# specific that the false-positive rate is measured over repeated EXPERIMENTS,
# not repeated samples — so the null sweep runs many times with different seed
# offsets, and each repeat is one independent experiment.
N_CHOSEN = first_reliable or 16
N_REPEATS = 40

null_fires = 0
null_details = []
for repeat in range(N_REPEATS):
    seeds = list(range(1000 + repeat * N_CHOSEN, 1000 + (repeat + 1) * N_CHOSEN))
    recs = run_suite_fast(["base", "null_model"], CLEAN_SUITE, seeds)
    fires, detail = rule_fires(recs, "null_model")
    null_fires += bool(fires)
    null_details.append({"repeat": repeat, "fires": bool(fires), **detail})

fp_rate = null_fires / N_REPEATS
lo = fp_rate - 1.96 * math.sqrt(fp_rate * (1 - fp_rate) / N_REPEATS)
hi = fp_rate + 1.96 * math.sqrt(fp_rate * (1 - fp_rate) / N_REPEATS)
print(f"null pair: rule fired in {null_fires} of {N_REPEATS} independent "
      f"experiments at N={N_CHOSEN}")
print(f"false-positive rate: {fp_rate:.1%}  (95% CI [{max(lo, 0):.1%}, {hi:.1%}])")
print()
print("Expected: about 2.5%, not 5%. The rule is ONE-SIDED — it requires the "
       "interval's LOWER bound to be above zero — so only the upper tail of a "
       "two-sided 95% interval can trigger it. A rule that fired on either tail "
       "would have a 5% rate and would report a regression as an improvement.")
print()
print(f"And the interval on that rate is wide: {N_REPEATS} experiments cannot "
      f"separate 2.5% from 5%. Measuring a false-positive rate to a useful "
      f"precision needs hundreds of experiments, which is affordable here only "
      f"because each one is arithmetic. Against real generation it would not be, "
      f"which is the argument for calibrating the rule on a fixture.")
if not (0.0 <= fp_rate <= 0.15):
    print("\\nFAR from the expected rate. That is a bug in the interval or in "
          "the rule, not a finding about the model — and saying so is what the "
          "exercise asks for.")
''')

nb.code('''
if plt is not None:
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ns = [r["n"] for r in real_sweep]
    hw = [r["half_width"] for r in real_sweep]
    ax[0].plot(ns, hw, "o-", label="95% half-width")
    expected = expected_pooled_effect([c for c in CLEAN_SUITE
                                       if c.category != "out-of-domain"])
    ax[0].axhline(expected, color="#c92a2a", ls="--",
                  label=f"true effect ({expected:+.3f})")
    # The half-width should fall as 1/sqrt(N). Overlay it, anchored on the first
    # point, so a departure is visible rather than assumed.
    ax[0].plot(ns, [hw[0] * math.sqrt(ns[0] / n) for n in ns], ":", color="grey",
               label="1/sqrt(N) reference")
    for row in real_sweep:
        if row["fires"]:
            ax[0].axvline(row["n"], color="#2b8a3e", alpha=.12)
    ax[0].set_xlabel("seeds (N)")
    ax[0].set_ylabel("95% interval half-width")
    ax[0].set_title("precision against cost; green = rule fires", fontsize=10)
    ax[0].legend(fontsize=8)

    means = [d["mean"] for d in null_details]
    ax[1].hist(means, bins=12, color="#495057")
    ax[1].axvline(0, color="#c92a2a", label="true effect (zero)")
    ax[1].set_xlabel("paired mean difference, NULL pair")
    ax[1].set_ylabel("experiments")
    ax[1].set_title(f"null distribution over {N_REPEATS} experiments", fontsize=10)
    ax[1].legend(fontsize=8)
    plt.tight_layout()
    plt.show()
''')

nb.model_answer(
    "**What N I would use, and what the false-positive rate means for a single positive "
    "result.**\n\n"
    "**On N.** The half-width falls as `1/sqrt(N)`, so precision is bought at quadratic "
    "cost: halving the interval costs four times the generations. The sweep shows the "
    "rule firing reliably from some N onwards, and the honest choice is *the smallest N "
    "at which the rule fires for that N and every larger one* — not the smallest N at "
    "which it fires at all. Those differ, and the difference is the whole point: a rule "
    "that fires at N=6, not at N=8, and again at N=10 has fired at N=6 by luck. Reading "
    "the first *stable* crossing rather than the first crossing is what stops you "
    "choosing a sample size that happened to work.\n\n"
    "In practice I would take that N and add a margin, for the same reason Lesson 17's "
    "token cap gets a margin: the sweep was run on one suite with one noise level, and "
    "the real effect may be smaller than the fixture's. The compute is cheap here and "
    "will not be with real generation, which is exactly why doing this calibration on a "
    "fixture first is worth it — **you are buying the sample size with fixture compute "
    "instead of with GPU hours.**\n\n"
    "**On the false-positive rate.** It should be about **2.5%**, not 5%, and knowing "
    "why is the difference between using the number and reciting it: the rule is "
    "one-sided. It requires the interval's *lower* bound to be above zero, so only the "
    "upper tail of a two-sided 95% interval can trigger it. A rule that fired whenever "
    "the interval excluded zero in either direction would have a 5% rate and would "
    "report a regression as an improvement — which is a worse bug than the wrong rate.\n\n"
    "If the measured rate had come out at, say, 15%, the correct conclusion is **a bug "
    "in the interval, not a finding about the models**. The two candidates would be: "
    "treating correlated pairs as independent (all six prompts share a seed, so the "
    "differences are not fully independent and the true SE is larger than computed), or "
    "using `1.96` with a small `n` where a t-quantile is needed. Both inflate confidence, "
    "both are invisible without a null measurement, and this is why step 4 exists.\n\n"
    "**What it means for a single positive result — the part that generalises.** At a "
    "2.5% false-positive rate, roughly one experiment in forty on a model that changed "
    "*nothing* will report an improvement. That is fine if you run one experiment. It is "
    "not fine in the way people actually work: you try a learning rate, then a token cap, "
    "then a data mix, then a longer run — and after forty such attempts you should expect "
    "one spurious win, which you will remember and the thirty-nine nulls you will not. "
    "The defences are to pre-register the rule (done, above), to count the experiments, "
    "and to **replicate any positive result on fresh seeds before acting on it**. A "
    "replication costs one more run and converts a 2.5% chance into a 0.06% chance.\n\n"
    "**And the reason to trust any of this at all:** the false-positive rate was "
    "*measured* on a pair of models known to be identical. Without that, the interval is "
    "an assumption. It is the same move as Lesson 13's zero-policy control and Lesson "
    "17's seed-variance floor, and it is the single most transferable idea in this "
    "module: **before you measure a difference, measure what your instrument reports when "
    "there is no difference.**"
)

nb.extend(
    "The rule fires on a single metric with a single threshold. The version worth having "
    "reports an **effect size** rather than a verdict — the paired mean divided by the "
    "paired standard deviation — because that is comparable across metrics, across "
    "suites and across experiments in a way a p-value is not. It also makes the "
    "power calculation direct: at a given effect size, the N you need is roughly "
    "`(2 x 1.96 / d)^2`, and you can compute the sample size before running anything "
    "rather than sweeping for it. The sweep is the right way to learn this once; the "
    "formula is the right way to use it afterwards."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "A complete evaluation report for your Lesson 17 fine-tune",
    goal="Produce the harness and the report you would attach your name to — including a "
         "recommendation and an account of what the evidence cannot support.",
    success="A runnable harness, a records file including failures, and a report with all "
            "four sections and a recommendation. At least four specific items in \"what "
            "this does not show\".",
    approach="Change exactly one function to move from fixtures to video, build the "
             "leakage gate from the real JSONL, and — with no fine-tuned checkpoint — run "
             "**base against base** so the report is about the harness's null behaviour, "
             "which is worth having before a real checkpoint exists.",
)

nb.code('''
# Deliverable 1: the ONE function that has to change to move from fixtures to
# real video. Reuses cosmos_course.checks._read_frames so the metrics and the
# verification see the SAME frames — a metric computed on different frames than
# the check ran on can disagree with it for no interesting reason.
def load_stack_video(path, max_frames=16):
    """Read up to `max_frames` evenly-spaced frames from a video as an array."""
    from cosmos_course.checks import _read_frames

    frames = _read_frames(Path(path), max_frames)
    if frames is None:
        raise RuntimeError(f"could not decode {path}")
    return np.stack([np.asarray(f, dtype=np.float64) for f in frames])


def measure_video(paths):
    """measure(), but reading video. The only other change in the harness."""
    stack = load_stack_video(paths[0])
    return {"structure": round(structure(stack), 4),
            "aliveness": round(aliveness(stack), 4),
            "stability": round(stability(stack), 4)}


def cosmos_generate(model, case, seed, out_dir):
    """Drop-in replacement for `synthesise` that calls the real generator."""
    from cosmos_course.models import Generator

    ckpt = "Cosmos3-Edge" if model == "base" else str(FINETUNED_MODEL)
    spec = cc.InferenceSpec(model_mode="text2video", name=case.prompt_id,
                            prompt=case.prompt, resolution="256",
                            aspect_ratio="1,1", num_frames=61, fps=5, seed=seed)
    result = Generator(checkpoint=ckpt).run(spec, out_dir, seed=seed)
    if not result.video_path:
        raise RuntimeError(f"no video produced: {result.diagnose()}")
    return [result.video_path]


print("load_stack_video and cosmos_generate defined. Note what does NOT change: "
      "the suite, the pairing, the leakage gate, the verification and every "
      "statistic. That is the payoff for having built the harness against a "
      "fixture — swapping the generator is a two-line change.")
''')

nb.code('''
# Deliverable 1, second half: the leakage gate built from the REAL JSONL rather
# than a hand-written list. Both the window caption and the temporal_caption
# inside caption_json are text the model trained on, and either can leak.
def tokens(text, n=3):
    words = [w.strip(".,!?;:\\"'()").lower() for w in str(text).split()]
    words = [w for w in words if w]
    return {" ".join(words[i:i + n]) for i in range(max(len(words) - n + 1, 0))}


def overlap(prompt, corpus, n=3):
    p = tokens(prompt, n)
    if not p:
        return 0.0, None
    best, who = 0.0, None
    for key, text in corpus.items():
        c = tokens(text, n)
        if not c:
            continue
        score = len(p & c) / len(p)
        if score > best:
            best, who = score, key
    return best, who


def corpus_from_jsonl(root):
    """Every caption the model trained on, keyed so a hit is traceable."""
    corpus = {}
    for path in sorted(Path(root).rglob("*.jsonl")):
        for i, line in enumerate(path.read_text(encoding="utf-8").splitlines()):
            if not line.strip():
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            uuid = rec.get("uuid", f"{path.name}:{i}")
            for w, window in enumerate(rec.get("t2w_windows", [])):
                if window.get("caption"):
                    corpus[f"{uuid}#w{w}:caption"] = window["caption"]
                temporal = (window.get("caption_json") or {}).get("temporal_caption")
                if temporal:
                    corpus[f"{uuid}#w{w}:temporal"] = temporal
    return corpus


def leakage_report(cases, corpus, *, threshold=0.30, n=3):
    return [{"prompt_id": c.prompt_id,
             **dict(zip(("overlap", "closest_training_item"),
                        overlap(c.prompt, corpus, n)))}
            for c in cases]


DATASET_ROOT = cc.OUTPUT_ROOT / "16" / "sft_dataset"
CORPUS = corpus_from_jsonl(DATASET_ROOT)
if not CORPUS:
    CORPUS = {"fallback_0001": "A robotic arm picks up a small object from a tray.",
              "fallback_0002": "A robotic gripper places a block onto a table."}
    print(f"No JSONL at {DATASET_ROOT}; using a two-caption fallback corpus so "
          f"the gate still runs. Against a real dataset this would carry "
          f"hundreds of captions and the gate would be correspondingly stricter.")
else:
    print(f"leakage corpus: {len(CORPUS)} caption(s) from {DATASET_ROOT}")

gate = leakage_report(CLEAN_SUITE, CORPUS)
worst = max(r["overlap"] for r in gate)
for r in gate:
    print(f"  {r['prompt_id']:<10} overlap {r['overlap']:.2f}  "
          f"{'LEAKED' if r['overlap'] >= 0.30 else 'clean'}"
          f"  closest: {r['closest_training_item']}")
assert worst < 0.30, "the suite is not clean — rewrite the offenders"
print(f"\\nPASS gate passed (max overlap {worst:.2f}) — now, and only now, "
      f"run the evaluation")
''')

nb.code('''
# Deliverable 2: the evaluation. Eight independently-written prompts across the
# three categories — the six from CLEAN_SUITE plus two more, all gated above.
FULL_SUITE = CLEAN_SUITE + [
    EvalCase("clean_g", "A delta robot picks components from a vibrating tray.",
             "in-domain"),
    EvalCase("clean_h", "A person folds a tea towel on a kitchen worktop.",
             "near-domain"),
]
for r in leakage_report(FULL_SUITE, CORPUS):
    assert r["overlap"] < 0.30, r
print(f"{len(FULL_SUITE)} prompts, all below the leakage threshold")

EVAL_SEEDS = list(range(4))
HAVE_TUNED = FINETUNED_MODEL.exists() and RUN_REAL_GENERATION

if HAVE_TUNED:
    print("Running the REAL comparison against Lesson 17's export.")
    final_records = run_suite(["base", "finetuned"], FULL_SUITE, EVAL_SEEDS,
                              OUTPUT_DIR / "final", generate=cosmos_generate)
    comparison_label, model_b = "base vs fine-tuned (REAL generation)", "finetuned"
else:
    # No checkpoint: run BASE AGAINST BASE at different seeds. The report is
    # then about the harness's NULL behaviour, which the exercise explicitly
    # sanctions and which is genuinely worth having before a real checkpoint
    # exists — it is the measurement that tells you what your harness reports
    # when there is nothing to report.
    print("No fine-tuned checkpoint (or generation disabled). Running BASE "
          "AGAINST BASE — a null comparison, and the report below is about the "
          "harness rather than about any model.")
    MODELS["base_replica"] = dict(MODELS["base"])
    final_records = run_suite(["base", "base_replica"], FULL_SUITE, EVAL_SEEDS,
                              OUTPUT_DIR / "final")
    comparison_label, model_b = "base vs base (NULL comparison)", "base_replica"

records_path = write_records(final_records, OUTPUT_DIR / "final_records.jsonl")
n_ok = sum(r.ok for r in final_records)
print(f"\\n{len(final_records)} samples, {n_ok} verified, "
      f"{len(final_records) - n_ok} failed (all in the records file)")
print(f"records -> {records_path.name}")

d_main, _ = paired_differences(final_records, model_b=model_b, cases=IN_NEAR)
d_ood, _ = paired_differences(final_records, model_b=model_b, cases=OOD)
main_stats = stats_of(d_main)
fires, detail = rule_fires(final_records, model_b)
print()
print(f"{comparison_label}")
print(f"  in/near-domain: mean {main_stats['mean']:+.4f} "
      f"95% [{main_stats['lo']:+.4f}, {main_stats['hi']:+.4f}]  n={main_stats['n']}")
print(f"  out-of-domain : mean {statistics.mean(d_ood) if d_ood else float('nan'):+.4f}")
print(f"  DECISION RULE FIRES: {'YES' if fires else 'no'}")
''')

nb.code('''
def write_eval_report(path, *, method, results, threats, not_shown,
                      recommendation, honest, records=None):
    """Assemble the report. The last two sections are not optional."""
    lines = ["# Evaluation report", "",
             "## Method", method, "",
             "## Results", results, "",
             "## Threats to validity", threats, "",
             "## What this does NOT show", not_shown, "",
             "## Recommendation", recommendation, "",
             "## The honest paragraph", honest, ""]
    if records:
        n_ok = sum(r.ok for r in records)
        lines += ["## Sample accounting",
                  f"- samples attempted: {len(records)}",
                  f"- passed verification: {n_ok}",
                  f"- failed: {len(records) - n_ok}  (included in the records "
                  f"file, excluded from paired comparisons)",
                  f"- records file: `{Path(records_path).name}`", ""]
    Path(path).write_text("\\n".join(lines), encoding="utf-8")
    return Path(path)


not_shown = "\\n".join([
    "- **Does not show that any difference generalises beyond these eight "
    "prompts.** The prompts were written by one person in one sitting and share "
    "that person's assumptions about what a robot video is. The confidence "
    "interval reflects sampling error over seeds; it says nothing about "
    "prompt-selection error, which is almost certainly larger.",
    "- **Does not show that a human would prefer the output.** The metric is "
    "lag-1 spatial autocorrelation. It rewards smoothness, and it cannot "
    "distinguish coherent structure from coherent blur — a model that got "
    "blurrier would score better.",
    "- **Does not separate a model effect from a decoding effect.** Both sides "
    "used the same resolution, frame count, step count and seed, which controls "
    "for those; it does not control for anything downstream of the sampler that "
    "differs between checkpoints.",
    "- **Does not show that a longer training run would help.** One training "
    "length was run. 'More iterations would fix it' is the universal hypothesis "
    "and there is no evidence for it in this experiment.",
    "- **Does not show the checkpoints differ at all.** No detectable difference "
    "in these metrics is compatible with the weights being identical. A weight "
    "diff would settle that in a minute and was not run.",
])

if fires:
    recommendation = (
        "**Keep training, and re-evaluate at a checkpoint series.** The rule "
        "fired, so there is a detectable in/near-domain improvement that is not "
        "accompanied by an out-of-domain regression beyond the stated "
        "threshold. What I would expect to change with more iterations: the "
        "effect size grows and the out-of-domain regression grows with it, "
        "because both scale with how far the weights move. How I would detect "
        "it: save at 5, 10, 20, 50 and 100 iterations and run this same suite "
        "at each, watching the in-domain gain and the out-of-domain loss as a "
        "pair. I would stop when the out-of-domain regression exceeds the "
        "in-domain gain, which is the point at which the trade stops being "
        "worth taking. I would NOT deploy this checkpoint: a detectable effect "
        "on eight prompts is not evidence of a useful one.")
else:
    recommendation = (
        "**Stop this configuration and change the data, not the schedule.** The "
        "rule did not fire. Before concluding the fine-tune does not work, note "
        "the cost of the alternatives: continuing costs GPU hours against an "
        "effect this suite could only detect if it were roughly the size of "
        "the fixture's planted effect, and the run in question is 20-100 "
        "iterations inside an unfinished warm-up, so there is little reason to "
        "expect one. The cheapest informative next step is not more iterations; "
        "it is a weight diff to confirm the training changed the parameters it "
        "was supposed to change, followed by a look at the dataset — six "
        "records is not a fine-tuning corpus. If the weights did not move, "
        "every generation in this report was wasted and the fix is in the "
        "configuration, not the schedule.")

honest = (
    "Lesson 17 trained for 20 to 100 iterations at a fraction of the shipped "
    "global batch, with `keys_to_select` restricting training to the generation "
    "pathway, EMA disabled and `torch.compile` off — a configuration NVIDIA does "
    "not document and has not validated. The shipped scheduler warms up over 50 "
    "steps, so a 20-iteration run ends before the learning rate reaches its "
    "peak. **The headline of this report is therefore that I cannot distinguish "
    "this fine-tune from the base model, and that is the expected outcome rather "
    "than a disappointing one.** Anything else would need a longer run at a "
    "larger effective batch, and this report is not evidence that such a run "
    "would succeed."
    + ("" if HAVE_TUNED else
       " Furthermore, no fine-tuned checkpoint existed on this machine: the "
       "comparison above is BASE AGAINST BASE. Every number in the results "
       "section describes the harness's null behaviour and none of it describes "
       "a model. That is a useful thing to have measured before a real "
       "checkpoint arrives — it tells you what this instrument reports when "
       "there is nothing to report — and it is not an evaluation of anything."))

report = write_eval_report(
    OUTPUT_DIR / "eval_report.md",
    method=(
        f"Paired comparison, {comparison_label}, over {len(FULL_SUITE)} "
        f"independently-written prompts ({sum(1 for c in FULL_SUITE if c.category == 'in-domain')} "
        f"in-domain, {sum(1 for c in FULL_SUITE if c.category == 'near-domain')} "
        f"near-domain, {sum(1 for c in FULL_SUITE if c.category == 'out-of-domain')} "
        f"out-of-domain regression checks) at seeds {EVAL_SEEDS}. The same seed "
        f"is used for both models on each prompt, so the prompt and seed effects "
        f"cancel in the difference. Metric: lag-1 spatial autocorrelation "
        f"(`structure`). Leakage gate: trigram overlap < 0.30 against "
        f"{len(CORPUS)} training caption(s) read from the Lesson 16 JSONL, run "
        f"BEFORE the evaluation. Every output verified with cc.check_image "
        f"before being measured; failures are recorded and excluded from the "
        f"paired comparison. Decision rule fixed in advance (see the notebook)."),
    results=(
        f"In/near-domain paired mean {main_stats['mean']:+.4f} "
        f"(95% CI [{main_stats['lo']:+.4f}, {main_stats['hi']:+.4f}], "
        f"n={main_stats['n']}). Out-of-domain regression check: "
        f"{statistics.mean(d_ood) if d_ood else float('nan'):+.4f} over "
        f"{len(OOD)} prompts. Decision rule fires: "
        f"{'YES' if fires else 'no'}. Measured false-positive rate of this rule "
        f"on a null model pair: {fp_rate:.1%} over {N_REPEATS} independent "
        f"experiments at N={N_CHOSEN}."),
    threats=(
        "- The metric rewards spatial smoothness and cannot distinguish "
        "coherent structure from coherent blur.\\n"
        f"- {len(FULL_SUITE)} prompts is a small sample of prompt space; the "
        "interval reflects sampling error over seeds, not prompt-selection "
        "error.\\n"
        "- The leakage gate is trigram overlap, which catches verbatim and "
        "near-verbatim reuse and not paraphrase. A prompt that means the same "
        "as a training caption in different words passes it.\\n"
        "- The out-of-domain regression threshold is expressed as a multiple of "
        "a known effect size. In a real evaluation that number is not known, "
        "and the threshold would have to be argued rather than computed.\\n"
        + ("- Both models are synthetic fixtures. These numbers say nothing "
           "about any Cosmos 3 checkpoint." if not HAVE_TUNED else "")),
    not_shown=not_shown,
    recommendation=recommendation,
    honest=honest,
    records=final_records)

print(f"wrote {report}")
print()
print(report.read_text(encoding="utf-8")[:1500])
''')

nb.why(
    "**Why base-against-base is a legitimate answer and not a cop-out.** The exercise "
    "sanctions it, and the reason is that a harness's null behaviour is a measurement "
    "you want *before* a real checkpoint exists, not after. It tells you what your "
    "instrument reports when there is nothing to report — and everything in Module 5 "
    "argues that the most likely honest outcome of a 20-iteration single-GPU fine-tune "
    "is exactly that. Running the null first means that when a real checkpoint arrives "
    "you already know your false-positive rate, and can interpret its result "
    "immediately.\n\n"
    "**Why only one function changes between fixture and reality.** `load_stack` becomes "
    "`load_stack_video` and `synthesise` becomes `cosmos_generate`. The suite, the "
    "pairing, the leakage gate, the verification, the statistics and the report writer "
    "are untouched. That is the payoff for having built the harness against a fixture "
    "whose true effect was known: all the parts that could be wrong were debugged where "
    "debugging cost milliseconds. If you build the harness against real generation "
    "instead, every bug costs a GPU-minute to find and you will not find most of them.\n\n"
    "**Why `load_stack_video` reuses `cosmos_course.checks._read_frames`.** Reaching into "
    "a private function is normally bad practice; here it is the point. The verification "
    "step (`check_video`) and the metric must see the *same frames*. If the metric "
    "samples frames differently, a metric and a check can disagree about the same file "
    "for a reason that has nothing to do with the file, and you will spend an hour on it. "
    "Sharing the decoder makes that impossible.\n\n"
    "**Why the leakage gate is built from the JSONL and not from a list.** A hand-written "
    "list of training captions is a list of the ones you remember. The real corpus has "
    "every caption *and* every `temporal_caption` inside `caption_json` — hint 1 flags "
    "that both are text the model trained on, and it is easy to check only the first. The "
    "gate also runs *before* the evaluation and is an `assert`, because a leakage check "
    "run afterwards is a check you will be tempted to negotiate with.\n\n"
    "**Why the recommendation branches on the rule rather than on the numbers.** The "
    "decision rule was fixed before the analysis; the recommendation follows from whether "
    "it fired. Writing both branches in advance is what stops the recommendation being "
    "reverse-engineered from a result — and hint 1 is right that both must be actionable: "
    "\"keep training\" says what would change and how it would be detected; \"stop\" says "
    "what continuing would cost against the effect still detectable. \"Inconclusive\" "
    "with no next step is the one unacceptable answer, and it is the most common one."
)

nb.extend(
    "Every metric here is a pixel statistic, and the honest limitation is that none of "
    "them can see whether the video matches the prompt. The tool for that is already in "
    "this course: the Module 1 reasoner, scoring adherence on a fixed rubric, run several "
    "times per clip with the self-consistency machinery from Lesson 04. It introduces its "
    "own circularity — a model judging a model — and it is a *different* circularity from "
    "the pixel metrics' blindness, which is precisely why running both is worth more than "
    "running either. The rule for adding it: plant a known adherence failure (generate "
    "with a deliberately mismatched prompt), confirm the judge detects it, and only then "
    "point it at the real comparison. Calibrate the instrument on a known signal before "
    "you trust it on an unknown one — which is the single idea this entire lesson is "
    "built around."
)

nb.finish()
