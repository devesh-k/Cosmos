"""Build solutions/14_solutions.ipynb — reference answers for Lesson 14."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("14", "Performance and memory",
                      lesson_file="14_performance_and_memory.ipynb")

nb.header(
    "Lesson 14 is about not fooling yourself with a number. The foundation exercise "
    "repairs a timing harness that looks fine and measures the wrong thing — CUDA is "
    "asynchronous, so a naive `perf_counter` around a kernel launch times the launch. "
    "The applied one profiles memory in a process you are not inside, which is the only "
    "situation that matters here because the generator is a subprocess. The challenge "
    "one publishes a benchmark with the two sections everyone skips: a machine-readable "
    "methodology, and limitations specific enough to act on."
)

nb.callout(
    "note",
    "Lesson 14 refuses to start without CUDA, and it is right to — on CPU it has no "
    "content. This notebook softens that to a flag, because the *harness* logic is what "
    "is being taught and it is checkable anywhere. Where CUDA is present, the lesson's "
    "own automated checks run unchanged. Where it is not, each check runs a CPU analogue "
    "that tests the same properties against a workload of known duration, and says so.",
)

nb.prelude("The lesson's imports, workloads and samplers.")
nb.code(setup_cell("14"))

nb.code('''
import gc
import json
import math
import statistics
import subprocess
import threading
import time
from datetime import datetime, timezone

import numpy as np

try:
    import torch
except ImportError:
    torch = None
try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

from cosmos_course.measure import MeasurementLog

HAVE_TORCH = torch is not None
HAVE_CUDA = bool(HAVE_TORCH and torch.cuda.is_available())
OOM_ERROR = (getattr(torch, "OutOfMemoryError", None) or torch.cuda.OutOfMemoryError) \\
    if HAVE_TORCH else RuntimeError

if HAVE_CUDA:
    props = torch.cuda.get_device_properties(0)
    TOTAL_VRAM_GB = props.total_memory / 1e9
else:
    props, TOTAL_VRAM_GB = None, None

if MODE == "full":
    MATMUL_N, WARM_ITERS, TIMED_ITERS, N_SAMPLES = 8192, 10, 30, 15
else:
    MATMUL_N, WARM_ITERS, TIMED_ITERS, N_SAMPLES = 4096, 5, 15, 9

RESULTS = {}
log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")

print(f"torch : {getattr(torch, '__version__', 'not installed')}")
print(f"cuda  : {HAVE_CUDA}"
      + (f"  ({props.name}, {TOTAL_VRAM_GB:.1f} GB)" if HAVE_CUDA else ""))
if not HAVE_CUDA:
    print("\\nNo CUDA. Every check below runs its CPU analogue, and every reported "
          "figure is a property of this machine's CPU, not of an H100.")
''')

nb.code('''
def _sync():
    """Block until queued GPU work is done. A no-op without CUDA."""
    if HAVE_CUDA:
        torch.cuda.synchronize()


if HAVE_CUDA:
    A = torch.randn(MATMUL_N, MATMUL_N, device="cuda", dtype=torch.bfloat16)
    B = torch.randn(MATMUL_N, MATMUL_N, device="cuda", dtype=torch.bfloat16)

    def matmul_workload(iters=1):
        out = None
        for _ in range(iters):
            out = A @ B
        return out
else:
    _An = np.random.default_rng(0).standard_normal((512, 512), dtype=np.float32)

    def matmul_workload(iters=1):
        out = None
        for _ in range(iters):
            out = _An @ _An
        return out


def time_with_events(fn, iters):
    """Per-iteration DEVICE time, one host sync for the whole batch.

    Without CUDA this falls back to a per-iteration wall clock, which is the
    right analogue: on CPU there is no asynchrony to hide from, so the host
    clock IS the device clock.
    """
    if not HAVE_CUDA:
        out = []
        for _ in range(iters):
            t0 = time.perf_counter()
            fn()
            out.append(time.perf_counter() - t0)
        return out
    starts = [torch.cuda.Event(enable_timing=True) for _ in range(iters)]
    ends = [torch.cuda.Event(enable_timing=True) for _ in range(iters)]
    torch.cuda.synchronize()
    for i in range(iters):
        starts[i].record()
        fn()
        ends[i].record()
    torch.cuda.synchronize()
    return [starts[i].elapsed_time(ends[i]) / 1e3 for i in range(iters)]


matmul_workload(WARM_ITERS)
_sync()
print("workload warm")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Repair a broken timing harness",
    goal="Take a plausible-looking `time_op()` and make it produce a figure you would be "
         "willing to defend, then prove it with the supplied automated check.",
    success="`check_timing_harness()` prints all-pass, and one corrected figure is "
            "written down with its spread and its warm-up count.",
    approach="Fix all four bugs — sync inside the loop, sync *before* the clock starts, "
             "warm up outside the timed region, and report a median with quartiles — and "
             "have the harness report its own methodology so a caller can check it.",
)

nb.code('''
def time_op_broken(fn, repeats=5):
    """Plausible. Wrong in at least three ways. Find them before you rewrite it."""
    total = 0.0
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn()
        total += time.perf_counter() - t0
    if HAVE_CUDA:
        torch.cuda.synchronize()
    return total / repeats


# The bugs, in the order they bite. Each is a comment on the line it applies to
# in the function above; collecting them here makes the diff against the fixed
# version readable.
BUGS = [
    ("synchronise is OUTSIDE the loop",
     "CUDA is asynchronous: `fn()` returns as soon as the work is QUEUED. With "
     "one sync after the loop, iterations 1..n-1 time the launch — microseconds "
     "— and iteration n absorbs all the accumulated device work. The mean is "
     "then (total device time) / n, which is right by accident for a uniform "
     "workload and wrong for anything else, and every individual sample is "
     "meaningless."),
    ("no synchronise BEFORE the clock starts",
     "Work queued by a previous cell is still in flight. The first `t0` is "
     "taken while the device is busy, so the first sample is charged for "
     "somebody else's kernels. This is the subtle one and it survives fixing "
     "the first bug."),
    ("no warm-up",
     "The first call pays cuBLAS algorithm selection for this shape and dtype, "
     "allocator pool growth, and possibly a JIT compile. With repeats=5 that "
     "first sample is 20% of the mean."),
    ("returns a MEAN",
     "One slow run — a clock excursion, a background process, a page-cache "
     "miss — moves a 5-sample mean substantially and moves a median not at "
     "all. Latency distributions have a long right tail; the mean sits in the "
     "tail and describes nothing."),
]
for name, why in BUGS:
    print(f"- {name}\\n    {why}\\n")
print(f"{len(BUGS)} bugs (the exercise says at least three)")
''')

nb.code('''
def time_op_fixed(fn, warmup=3, repeats=11):
    """Median and IQR, warm-up outside the timed region, synchronised properly."""
    # Bug 3: warm up BEFORE anything is timed, and do not count these samples.
    for _ in range(max(0, warmup)):
        fn()
    _sync()

    samples = []
    for _ in range(max(1, repeats)):
        _sync()                      # bug 2: start from a quiet device
        t0 = time.perf_counter()
        fn()
        _sync()                      # bug 1: inside the loop, per iteration
        samples.append(time.perf_counter() - t0)

    samples_sorted = sorted(samples)
    n = len(samples_sorted)
    # Bug 4: a median, with quartiles so the spread is visible. quantiles()
    # needs n >= 2; at n == 1 the quartiles collapse onto the median, which is
    # honest — a single sample has no spread.
    if n >= 2:
        q1, _med, q3 = statistics.quantiles(samples_sorted, n=4)
    else:
        q1 = q3 = samples_sorted[0]
    return {"median_s": statistics.median(samples_sorted),
            "q1_s": q1, "q3_s": q3,
            "min_s": min(samples_sorted), "max_s": max(samples_sorted),
            "n": n, "warmup": warmup, "samples_s": samples_sorted}
''')

nb.code('''
def check_timing_harness(harness):
    """Automated check. A harness that does not synchronise cannot pass this.

    The ground truth is torch.cuda._sleep, which busy-waits on the DEVICE for a
    fixed number of cycles and costs the host almost nothing. Any harness that
    times the launch instead of the work reports near zero for it.
    """
    passed = []

    if HAVE_CUDA and hasattr(torch.cuda, "_sleep"):
        cycles = 400_000_000
        device_only = lambda: torch.cuda._sleep(cycles)
    elif HAVE_CUDA:
        print("  ----  torch.cuda._sleep unavailable; using a matmul instead")
        device_only = lambda: matmul_workload(4)
    else:
        # CPU ANALOGUE. There is no launch/execute split to catch, so this
        # cannot test the synchronisation. It tests everything else: the
        # returned shape, the honesty of n and warmup, quartile ordering, and
        # agreement with an independently known duration.
        print("  ----  no CUDA: using a sleep of known duration. This cannot "
              "detect a missing synchronise — nothing on CPU can.")
        device_only = lambda: time.sleep(0.02)

    reference = statistics.median(time_with_events(device_only, 7))
    got = harness(device_only, warmup=2, repeats=9)

    for key in ("median_s", "q1_s", "q3_s", "min_s", "n", "warmup"):
        assert key in got, f"the returned dict is missing {key!r}"
    passed.append("returns median, quartiles, min, n and warmup")

    assert got["median_s"] > 0.5 * reference, (
        f"reported {got['median_s'] * 1e3:.3f} ms against a reference "
        f"{reference * 1e3:.3f} ms — this harness is timing the launch, "
        f"not the work")
    passed.append(f"agrees with the reference to within 2x "
                  f"({got['median_s'] * 1e3:.3f} vs {reference * 1e3:.3f} ms)")

    assert got["n"] == 9 and got["warmup"] == 2, \\
        "n and warmup must report what was actually done"
    passed.append("reports its own methodology honestly")

    assert got["q1_s"] <= got["median_s"] <= got["q3_s"], "quartiles are out of order"
    passed.append("quartiles bracket the median")

    for item in passed:
        print(f"  PASS  {item}")
    return passed


check_timing_harness(time_op_fixed)
''')

nb.code('''
# Step 4: the corrected figure for the workload, and the size of the correction.
fixed = time_op_fixed(lambda: matmul_workload(1), warmup=WARM_ITERS, repeats=N_SAMPLES)
broken = time_op_broken(lambda: matmul_workload(1), repeats=5)

print(f"time_op_fixed  : median {fixed['median_s'] * 1e3:8.3f} ms   "
      f"IQR [{fixed['q1_s'] * 1e3:.3f}, {fixed['q3_s'] * 1e3:.3f}] ms   "
      f"n={fixed['n']}  warmup={fixed['warmup']}")
print(f"time_op_broken : mean   {broken * 1e3:8.3f} ms   (no spread reported)")
ratio = broken / fixed["median_s"] if fixed["median_s"] else float("nan")
print(f"ratio          : {ratio:.3f}x")
print()
if HAVE_CUDA:
    print("On a GPU the broken harness typically reports a SMALLER number, because "
          "most of its samples time a launch rather than the work. How much smaller "
          "depends on how much of the queue the final synchronise absorbs, which is "
          "why the ratio is not a constant and why quoting one would be wrong.")
else:
    print("On CPU the two agree closely, because there is no launch/execute split "
          "to get wrong. That agreement is NOT evidence that the fixed harness is "
          "correct on a GPU — it is evidence that this machine cannot test the bug.")
RESULTS["timing"] = {"fixed": {k: v for k, v in fixed.items() if k != "samples_s"},
                     "broken_mean_s": broken}
''')

nb.why(
    "**Why the synchronise has to be in two places, not one.** Moving it inside the loop "
    "fixes the obvious bug and leaves a second one: the very first `perf_counter()` is "
    "taken while the device may still be executing work queued by an earlier cell. That "
    "work is then charged to your first sample. A median over eleven samples survives one "
    "contaminated sample, which is exactly why the median matters — but the fix is one "
    "line and there is no reason to rely on the statistics for something a `_sync()` "
    "removes.\n\n"
    "**Why `torch.cuda._sleep` is the right ground truth**, and why the check is built "
    "around it. It busy-waits *on the device* for a fixed number of cycles and costs the "
    "host almost nothing. A harness that times the launch reports microseconds for it; a "
    "harness that times the work reports the real duration. The two answers differ by "
    "orders of magnitude, so the assertion does not need a tight tolerance to be "
    "decisive. Choosing a probe whose correct and incorrect answers are far apart is what "
    "makes a check robust — a probe where the two answers differ by 5% needs careful "
    "thresholds and will produce flaky failures.\n\n"
    "**Why the harness reports `n` and `warmup` back to the caller.** It looks like "
    "bookkeeping and the check asserts on it, which is the tell: a figure without its "
    "sample count and warm-up count is not reproducible, and the commonest way for a "
    "benchmark to drift is for someone to change `repeats` and not update the caption. "
    "Returning the methodology with the number makes them impossible to separate.\n\n"
    "**Why the ratio between broken and fixed is not quoted as a constant.** It depends "
    "on how much queued work the trailing synchronise absorbs, which depends on the "
    "workload, the queue depth and the driver. The cell prints the ratio it measured and "
    "explicitly declines to generalise it — which is the same discipline this course "
    "applies to every performance figure, applied to a figure about measurement itself."
)

nb.extend(
    "The harness reports a median and an IQR from a handful of samples. What it does not "
    "report is a *confidence interval on the median*, and with n = 9 that interval is "
    "wide — the order statistics give roughly the 2nd to the 8th sample as a 95% "
    "interval, which is nearly the whole range. Adding a bootstrap CI (resample the nine "
    "samples with replacement a thousand times, take the 2.5th and 97.5th percentiles of "
    "the resampled medians) costs a few lines and turns \"12.3 ms\" into \"12.3 ms, "
    "95% CI [11.8, 13.9]\" — which is what you need before claiming one configuration is "
    "faster than another."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "A memory profiler for an out-of-process run",
    goal="Write `profile_run(command)` reporting peak allocated, peak reserved, "
         "device-wide peak and a fragmentation figure for work in a process you are not "
         "inside.",
    success="`check_profiler()` passes, and you can state the difference between the "
            "child's reported peak and the device-wide peak in gigabytes, with a correct "
            "explanation of where those gigabytes went.",
    approach="Sample the device on a thread while the child runs, parse the child's own "
             "figures from its **last stdout line**, and subtract the pre-launch baseline "
             "so the answer is attributable rather than merely device-wide.",
)

nb.code('''
class GpuSampler:
    """Poll device-wide VRAM on a background thread. Peak and baseline, in GB."""

    def __init__(self, interval=0.25, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self.timestamps = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_gb()
            if value is not None:
                self.samples.append(value)
                self.timestamps.append(time.perf_counter())

    def __enter__(self):
        first = self._read_gb()
        self.samples = [first] if first is not None else []
        self.timestamps = [time.perf_counter()]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None

    @property
    def baseline_gb(self):
        return self.samples[0] if self.samples else None


def compute_apps_gb():
    """host PID -> VRAM GB, for every process with a CUDA context. {} if unreadable."""
    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-compute-apps=pid,used_memory",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=10, check=True).stdout
    except Exception:
        return {}
    result = {}
    for line in out.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) == 2 and parts[0].isdigit():
            try:
                result[int(parts[0])] = float(parts[1]) * (1024 ** 2) / 1e9
            except ValueError:
                continue
    return result
''')

nb.code('''
def profile_run(command, interval=0.25):
    """Profile a child process's GPU memory from outside it."""
    started = time.perf_counter()
    per_pid_peak = {}
    with GpuSampler(interval=interval) as sampler:
        proc = subprocess.Popen(command, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True)
        # Poll per-process attribution WHILE the child is alive; once it exits,
        # nvidia-smi has nothing to attribute and the information is gone.
        while proc.poll() is None:
            for pid, gb in compute_apps_gb().items():
                per_pid_peak[pid] = max(per_pid_peak.get(pid, 0.0), gb)
            time.sleep(interval / 2)
        stdout, stderr = proc.communicate()
    wall = time.perf_counter() - started

    # Hint 1: the child prints ONE JSON object as its last line. Everything the
    # framework logged before it is noise to skip, not noise to suppress —
    # suppressing it would also hide the traceback when the child fails.
    child_reported = {}
    for line in reversed((stdout or "").strip().splitlines()):
        try:
            candidate = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(candidate, dict):
            child_reported = candidate
            break

    baseline = sampler.baseline_gb
    peak = sampler.peak_gb
    attributable = None
    if peak is not None and baseline is not None:
        attributable = max(0.0, peak - baseline)
    # Prefer per-process attribution when the driver gave it to us: it excludes
    # anything else that happened to grow on the card during the run.
    child_pid_peak = per_pid_peak.get(proc.pid)
    if child_pid_peak:
        attributable = child_pid_peak

    alloc = child_reported.get("max_alloc_gb")
    reserved = child_reported.get("max_reserved_gb")
    # Reserved minus allocated is a PROXY for fragmentation, not a measurement:
    # it is the pool the caching allocator holds and is not currently handing
    # out. Some of that is genuine fragmentation (free blocks too small or badly
    # placed to satisfy the next request) and some is simply headroom the
    # allocator grabbed and has not needed to reuse yet. The two are
    # indistinguishable from outside; torch.cuda.memory_snapshot() inside the
    # child is what would separate them.
    fragmentation = (reserved - alloc) if (alloc is not None and reserved is not None) \\
        else None

    return {"command": list(command), "returncode": proc.returncode,
            "wall_s": wall,
            "device_baseline_gb": baseline, "device_peak_gb": peak,
            "attributable_gb": attributable,
            "per_pid_peak_gb": per_pid_peak,
            "samples": len(sampler.samples),
            "child_reported": child_reported,
            "fragmentation_gb": fragmentation,
            "stderr_tail": (stderr or "").strip()[-400:]}
''')

nb.code('''
def check_profiler():
    """Launch a child of known size and check the profiler agrees."""
    passed = []
    target_gb = 4.0
    child = (
        "import json, time, torch\\n"
        f"x = torch.empty(int({target_gb} * 1e9), dtype=torch.uint8, device='cuda')\\n"
        "torch.cuda.synchronize(); time.sleep(3.0)\\n"
        "print(json.dumps({'max_alloc_gb': torch.cuda.max_memory_allocated() / 1e9,\\n"
        "                  'max_reserved_gb': torch.cuda.max_memory_reserved() / 1e9}))\\n"
    )
    out = profile_run([sys.executable, "-c", child])

    for key in ("wall_s", "device_baseline_gb", "device_peak_gb",
                "attributable_gb", "samples", "child_reported"):
        assert key in out, f"missing key {key!r}"
    passed.append("returns every required field")

    assert out["samples"] >= 5, \\
        f"only {out['samples']} samples over {out['wall_s']:.1f}s — poll faster"
    passed.append(f"{out['samples']} samples in {out['wall_s']:.1f} s")

    assert out["attributable_gb"] >= 0.8 * target_gb, (
        f"attributed {out['attributable_gb']:.2f} GB to a child that allocated "
        f"{target_gb} GB — the sampler is missing the peak")
    passed.append(f"attributed {out['attributable_gb']:.2f} GB of {target_gb} GB")

    reported = out["child_reported"].get("max_alloc_gb")
    assert reported and out["attributable_gb"] > reported, (
        "the device-wide figure must EXCEED the child's own allocated peak — "
        "if it does not, you are not seeing the CUDA context")
    passed.append(f"device-wide {out['attributable_gb']:.2f} GB exceeds the "
                  f"child's {reported:.2f} GB, as it must")

    for item in passed:
        print(f"  PASS  {item}")
    return out


def check_profiler_cpu_analogue():
    """No CUDA: check everything about the profiler that is not a GPU number.

    What this CAN test: that the child is launched, that its wall time is
    measured, that the sampler produces samples at the requested rate, and — the
    part most likely to be wrong — that the child's LAST JSON line is parsed out
    of a stdout stream that also contains noise. What it CANNOT test is any
    memory figure, and it says so rather than passing vacuously.
    """
    passed = []
    child = (
        "import json, sys, time\\n"
        "print('framework: loading checkpoint shard 1/4')\\n"
        "print('framework: {this line is not valid json')\\n"
        "time.sleep(1.5)\\n"
        "print(json.dumps({'max_alloc_gb': 4.0, 'max_reserved_gb': 4.6}))\\n"
    )
    out = profile_run([sys.executable, "-c", child], interval=0.1)

    assert out["returncode"] == 0, out["stderr_tail"]
    passed.append("child ran to completion")
    assert out["wall_s"] >= 1.4, out["wall_s"]
    passed.append(f"wall time measured ({out['wall_s']:.2f} s)")
    assert out["child_reported"].get("max_alloc_gb") == 4.0, out["child_reported"]
    passed.append("parsed the child's LAST json line, skipping the log noise "
                  "and the line that is not valid JSON")
    assert abs(out["fragmentation_gb"] - 0.6) < 1e-9, out["fragmentation_gb"]
    passed.append(f"fragmentation proxy computed ({out['fragmentation_gb']:.2f} GB)")
    for item in passed:
        print(f"  PASS  {item}")
    print("  ----  memory figures NOT tested: this machine has no CUDA device, so "
          "device_peak_gb and attributable_gb are None and the assertions that "
          "matter most cannot run.")
    return out


profile_result = check_profiler() if HAVE_CUDA else check_profiler_cpu_analogue()
''')

nb.model_answer(
    "**Why the device-wide peak exceeds the child's own `max_memory_allocated()`, in "
    "gigabytes.**\n\n"
    "Four contributions, and only the first three belong to the child:\n\n"
    "**1. The CUDA context — typically 300–600 MB.** Every process that touches CUDA "
    "creates a context: the driver's per-process state, the loaded module images for "
    "every kernel the binary might call, and the primary stream. `nvidia-smi` sees it. "
    "`torch.cuda.max_memory_allocated()` does not, because PyTorch's allocator never "
    "touched it. This alone guarantees the device figure exceeds the child figure, which "
    "is why `check_profiler` asserts the inequality — an equality would mean you are not "
    "seeing the context and are therefore not measuring what you think.\n\n"
    "**2. Reserved-but-unallocated pool.** PyTorch's caching allocator requests memory "
    "from the driver in large blocks and hands out slices. `max_memory_reserved()` minus "
    "`max_memory_allocated()` is that gap, and the driver counts the reserved figure. On "
    "a generation run this is often several GB.\n\n"
    "**3. Library workspaces.** cuBLAS, cuDNN and flash-attention allocate their own "
    "scratch outside PyTorch's allocator. Invisible to `max_memory_allocated`, visible to "
    "`nvidia-smi`.\n\n"
    "**4. Everything else on the card**, which is *not* the child's. Another process, a "
    "Reasoner NIM left running from Module 1, a Jupyter kernel holding tensors. This is "
    "why `profile_run` subtracts the pre-launch baseline, and why it prefers "
    "`--query-compute-apps` per-PID attribution when the driver provides it: the "
    "baseline subtraction is fooled by anything that grows *during* the run, and per-PID "
    "attribution is not.\n\n"
    "**Which number to use for what.** For \"will this fit\", the device-wide figure, "
    "because that is what the driver enforces. For \"is my model too big\", the child's "
    "allocated peak, because that is the part you can change by changing the model. For "
    "\"am I fragmenting\", the reserved-minus-allocated gap — and treat it as a proxy: it "
    "conflates genuine fragmentation with headroom the allocator grabbed and has not "
    "needed to reuse. `PYTORCH_ALLOC_CONF=expandable_segments:True` (rung 1 of "
    "`COSMOS3_FACTS.md` §5's OOM ladder) attacks exactly this gap, and the way to find "
    "out whether it helped is to measure this proxy with and without it.\n\n"
    "**The practical consequence for this course.** The generator runs as a subprocess "
    "(`cosmos_course.models.Generator`), so *every* memory number in Module 2 has to come "
    "from outside the process. That is not an inconvenience — it is why "
    "`torch.cuda.memory_allocated()` in your notebook reports approximately zero while "
    "the card is full, which is a genuinely confusing observation the first time you meet "
    "it."
)

nb.extend(
    "The profiler reports a peak. What it cannot show is *when* the peak occurred, and "
    "that is usually the actionable part: a peak during weight loading is fixed "
    "differently from a peak during denoising, and a peak at the very end is a VAE decode. "
    "`GpuSampler` already records timestamps, so plotting the series against wall time and "
    "annotating it with the child's stdout markers turns one number into a profile you "
    "can point at. On a run that OOMs, the shape of the curve just before the failure is "
    "the whole diagnosis."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "Publish a defensible benchmark of your own H100",
    goal="Produce `outputs/14/benchmark_report.json` and a README a sceptical reader "
         "could use to reproduce the numbers and decide how much to trust them.",
    success="`check_report()` passes, the JSON has at least six swept points each with "
            "n >= 5, and the limitations section names at least four specific things.",
    approach="Sweep a synthetic attention-shaped workload over sequence length — cheap "
             "enough to run **forwards and then backwards**, which is what lets thermal "
             "drift be measured rather than speculated about.",
)

nb.code('''
REPORT_PATH = OUTPUT_DIR / "benchmark_report.json"
README_PATH = OUTPUT_DIR / "README.md"

# STEP 1: the sweep, and why.
#
# An attention-shaped workload swept over sequence length, not a resolution x
# steps sweep of real generation. Three reasons, and the third is the one that
# matters:
#   * it costs seconds per point instead of minutes, so n >= 5 per point is
#     affordable and so is a repeat of the whole sweep;
#   * it isolates the quadratic term that actually dominates video generation
#     cost, which the linear cost model in cosmos_course.config cannot see;
#   * it can be run FORWARDS AND THEN BACKWARDS in a few minutes, which is the
#     only way to find out whether thermal drift contaminated the ordering
#     (hint 1). A generation sweep is too slow to repeat, so its drift is
#     unmeasurable and has to be speculated about instead.
SEQ_LENS = [512, 1024, 2048, 4096, 6144, 8192] if HAVE_CUDA else \\
           [64, 96, 128, 192, 256, 320]
HEAD_DIM = 64
N_HEADS = 8 if HAVE_CUDA else 2
REPEATS = 7
WARMUP = 3


def attention_workload(seq_len):
    """One scaled-dot-product attention pass. Cost is O(seq_len^2)."""
    if HAVE_CUDA:
        q = torch.randn(1, N_HEADS, seq_len, HEAD_DIM, device="cuda",
                        dtype=torch.bfloat16)
        k = torch.randn_like(q)
        v = torch.randn_like(q)

        def run():
            return torch.nn.functional.scaled_dot_product_attention(q, k, v)
        return run
    rng = np.random.default_rng(0)
    q = rng.standard_normal((N_HEADS, seq_len, HEAD_DIM), dtype=np.float32)
    k = rng.standard_normal((N_HEADS, seq_len, HEAD_DIM), dtype=np.float32)
    v = rng.standard_normal((N_HEADS, seq_len, HEAD_DIM), dtype=np.float32)

    def run():
        scores = q @ k.transpose(0, 2, 1) / math.sqrt(HEAD_DIM)
        scores -= scores.max(axis=-1, keepdims=True)
        w = np.exp(scores)
        w /= w.sum(axis=-1, keepdims=True)
        return w @ v
    return run


print(f"sweep: seq_len in {SEQ_LENS}, {N_HEADS} heads, head_dim {HEAD_DIM}")
print(f"per point: {WARMUP} warm-up + {REPEATS} timed")
print(f"backend: {'CUDA (SDPA, bf16)' if HAVE_CUDA else 'NumPy on CPU (fp32)'}")
''')

nb.code('''
def sweep(seq_lens):
    """One pass over the sweep. Returns a list of points."""
    points = []
    for seq_len in seq_lens:
        run = attention_workload(seq_len)
        timing = time_op_fixed(run, warmup=WARMUP, repeats=REPEATS)
        points.append({"config": {"seq_len": seq_len, "n_heads": N_HEADS,
                                  "head_dim": HEAD_DIM},
                       "median_s": timing["median_s"], "q1_s": timing["q1_s"],
                       "q3_s": timing["q3_s"], "min_s": timing["min_s"],
                       "max_s": timing["max_s"], "n": timing["n"],
                       "warmup": timing["warmup"]})
        if HAVE_CUDA:
            del run
            gc.collect()
            torch.cuda.empty_cache()
    return points


started = time.time()
forward_points = sweep(SEQ_LENS)
backward_points = sweep(list(reversed(SEQ_LENS)))
elapsed = time.time() - started

# Hint 1's drift check, MEASURED. Same points, opposite order. A systematic
# difference is thermal (or clock) drift; agreement is evidence worth quoting.
backward_by_len = {p["config"]["seq_len"]: p for p in backward_points}
print(f"{'seq_len':>8}{'forward ms':>13}{'backward ms':>14}{'diff':>10}")
print("-" * 46)
drifts = []
for p in forward_points:
    n = p["config"]["seq_len"]
    b = backward_by_len[n]
    rel = (b["median_s"] - p["median_s"]) / p["median_s"]
    drifts.append(rel)
    print(f"{n:>8}{p['median_s'] * 1e3:>13.3f}{b['median_s'] * 1e3:>14.3f}"
          f"{rel:>+9.1%}")
mean_drift = float(np.mean(drifts))
print(f"\\nmean signed difference, backward vs forward: {mean_drift:+.1%}")
print("A consistent sign across every point is drift. Scatter around zero is "
      "run-to-run noise, and is evidence the ordering did NOT matter.")
print(f"whole sweep took {elapsed:.1f} s")
''')

nb.code('''
env = cc.probe_environment(check_docker=False)


def build_report():
    """Run the sweep and return the report dict. Save nothing here."""
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "machine": {
            "gpu_names": env.gpu_names,
            "gpu_vram_total_gb": env.gpu_vram_total_gb,
            "compute_capability": env.compute_capability,
            "driver_version": env.driver_version,
            "torch_version": env.torch_version,
            "torch_cuda_version": env.torch_cuda_version,
            "cuda_available": env.torch_cuda_available,
            "python_version": env.python_version,
            "os": f"{env.os_name} {env.os_release}",
            "other_processes_on_card": sorted(compute_apps_gb().items()),
            "backend_used": "CUDA SDPA bfloat16" if HAVE_CUDA
                            else "NumPy float32 on CPU",
        },
        "methodology": {
            "warmup": WARMUP,
            "repeats": REPEATS,
            "synchronisation": ("torch.cuda.synchronize() before starting the clock "
                                "AND after the work, once per timed iteration"
                                if HAVE_CUDA else
                                "none required: CPU execution is synchronous"),
            "clock": "time.perf_counter (host), monotonic",
            "statistic": "median, with q1/q3 from statistics.quantiles(n=4)",
            "held_fixed": {"n_heads": N_HEADS, "head_dim": HEAD_DIM,
                           "dtype": "bfloat16" if HAVE_CUDA else "float32",
                           "batch": 1, "process": "one, no other GPU work started "
                                                  "by this notebook"},
            "varied": "seq_len",
            "sweep_order": "forwards, then backwards over the same points, to "
                           "detect drift",
            "sweep_wall_seconds": round(elapsed, 1),
            "drift_check_mean_signed_difference": round(mean_drift, 4),
        },
        "points": forward_points,
        "points_reverse_order": backward_points,
        "limitations": [
            ("The sweep is a synthetic attention workload, not Cosmos 3 generation. "
             "It isolates the quadratic sequence-length term and says nothing about "
             "VAE decode, guardrail passes, weight loading or file writing, which "
             "together are a large fraction of a real run's wall clock."),
            (f"Each point is {REPEATS} samples, so the median carries no useful "
             f"confidence interval: the order statistics give roughly the 2nd to "
             f"the 6th sample as a 95% interval, which is most of the observed "
             f"range. Differences between adjacent points smaller than the IQR "
             f"should not be interpreted."),
            (f"The whole sweep took {elapsed:.0f} s and was run forwards and then "
             f"backwards; the mean signed difference between the two orderings was "
             f"{mean_drift:+.1%}. That is the size of any thermal or clock drift "
             f"present, and it is NOT controlled for within a single ordering."),
            ("One shape family, one dtype, one batch size, one head count. Nothing "
             "here supports extrapolation to a different attention backend "
             "(flash-attn-3 on Hopper vs natten on Blackwell, per COSMOS3_FACTS.md "
             "section 3), which is chosen per architecture and has different "
             "scaling."),
            ("Memory was not measured at all in this sweep, only time. A "
             "configuration that is fast and does not fit is not usable, and this "
             "report cannot tell you which those are."),
            ("The first point of each ordering pays a cold page cache and possibly "
             "a JIT compile despite the warm-up, because warm-up is per point and "
             "not per process. This is visible as an asymmetry between the first "
             "forward point and the last backward point, which are the same "
             "config."),
        ],
    }


report = build_report()
REPORT_PATH.write_text(json.dumps(report, indent=2, default=str) + "\\n",
                       encoding="utf-8")
print(f"wrote {REPORT_PATH} ({REPORT_PATH.stat().st_size / 1024:.1f} KB)")
print(f"{len(report['points'])} points, {len(report['limitations'])} limitations")
''')

nb.code('''
quotable = (
    f"On {env.gpu_names[0] if env.gpu_names else 'this machine'}, scaled "
    f"dot-product attention at {N_HEADS} heads and head_dim {HEAD_DIM} took a "
    f"median {forward_points[-1]['median_s'] * 1e3:.2f} ms at seq_len "
    f"{forward_points[-1]['config']['seq_len']}, over {REPEATS} samples after "
    f"{WARMUP} warm-up iterations."
)
would_change = (
    "A different attention backend would change these numbers by more than "
    "anything measured here: COSMOS3_FACTS.md section 3 records that the backend "
    "is selected per architecture (flash-attn-3-nv on Hopper, natten on "
    "Blackwell), and this sweep used whatever "
    + ("torch.nn.functional.scaled_dot_product_attention chose"
       if HAVE_CUDA else "NumPy does") + ", which is not necessarily what the "
    "framework uses."
)

readme = f"""# Attention sweep — benchmark report

Generated {report['generated_at']}.
Data: `benchmark_report.json` next to this file.

## What was measured

Scaled dot-product attention, {N_HEADS} heads, head_dim {HEAD_DIM}, batch 1,
swept over sequence length {SEQ_LENS[0]}..{SEQ_LENS[-1]}. Backend:
**{report['machine']['backend_used']}**.

Each point: {WARMUP} warm-up iterations (discarded), then {REPEATS} timed
iterations. Median reported with quartiles.
{"Synchronised before the clock starts and after the work, once per iteration."
 if HAVE_CUDA else "No synchronisation needed: CPU execution is synchronous."}

## One sentence you could quote

> {quotable}

## One sentence about what would change it

> {would_change}

## Results

| seq_len | median (ms) | IQR (ms) | min (ms) | n |
|---:|---:|---|---:|---:|
"""
for p in forward_points:
    readme += (f"| {p['config']['seq_len']} | {p['median_s'] * 1e3:.3f} | "
               f"[{p['q1_s'] * 1e3:.3f}, {p['q3_s'] * 1e3:.3f}] | "
               f"{p['min_s'] * 1e3:.3f} | {p['n']} |\\n")

readme += f"""
## Drift check

The sweep was run forwards and then backwards over the same points. Mean signed
difference (backward minus forward): **{mean_drift:+.1%}**. A consistent sign
across all points would indicate thermal or clock drift; scatter around zero is
run-to-run noise.

## How to reproduce

Run `solutions/14_solutions.ipynb` on the machine described in
`benchmark_report.json` under `machine`. The methodology block in the JSON is
machine-readable on purpose: warm-up count, repeat count, synchronisation
strategy, clock, what was held fixed and what varied.

## Limitations

"""
for item in report["limitations"]:
    readme += f"- {item}\\n"

README_PATH.write_text(readme, encoding="utf-8")
print(f"wrote {README_PATH} ({README_PATH.stat().st_size} bytes)")
''')

nb.code('''
def check_report(path=REPORT_PATH):
    """Refuse to accept a report that a reader could not evaluate."""
    passed = []
    report = json.loads(Path(path).read_text())

    for key in ("machine", "methodology", "points", "limitations", "generated_at"):
        assert key in report, f"missing top-level key {key!r}"
    passed.append("has machine, methodology, points, limitations, generated_at")

    for key in ("warmup", "repeats", "synchronisation", "clock", "held_fixed", "varied"):
        assert key in report["methodology"], f"methodology is missing {key!r}"
    passed.append("methodology is complete enough to reproduce")

    points = report["points"]
    assert len(points) >= 6, f"only {len(points)} points; sweep something wider"
    for point in points:
        for key in ("median_s", "q1_s", "q3_s", "min_s", "max_s", "n", "config"):
            assert key in point, f"a point is missing {key!r}"
        assert point["n"] >= 5, f"a point has n={point['n']}; five is the floor"
        assert point["q1_s"] <= point["median_s"] <= point["q3_s"], \\
            "quartiles out of order"
    passed.append(f"{len(points)} points, all with n >= 5 and ordered quartiles")

    limits = report["limitations"]
    assert len(limits) >= 4, f"only {len(limits)} limitations; look harder"
    assert all(len(str(item)) > 40 for item in limits), \\
        "a one-line limitation is a placeholder, not a limitation"
    passed.append(f"{len(limits)} specific limitations")

    assert README_PATH.exists(), "no README next to the JSON"
    passed.append(f"README present ({README_PATH.stat().st_size} bytes)")

    for item in passed:
        print(f"  PASS  {item}")
    return passed


check_report()

if plt is not None:
    fig, ax = plt.subplots(figsize=(7, 4))
    xs = [p["config"]["seq_len"] for p in forward_points]
    ys = [p["median_s"] * 1e3 for p in forward_points]
    lo = [p["q1_s"] * 1e3 for p in forward_points]
    hi = [p["q3_s"] * 1e3 for p in forward_points]
    ax.errorbar(xs, ys, yerr=[np.array(ys) - lo, np.array(hi) - ys], fmt="o-",
                capsize=3, label="forward")
    ax.plot([p["config"]["seq_len"] for p in backward_points],
            [p["median_s"] * 1e3 for p in backward_points], "s--", alpha=.6,
            label="backward")
    # A quadratic through the first point, for reference. Attention is O(n^2).
    ref = [ys[0] * (x / xs[0]) ** 2 for x in xs]
    ax.plot(xs, ref, ":", color="grey", label="quadratic reference")
    ax.set_xlabel("sequence length")
    ax.set_ylabel("median ms (IQR bars)")
    ax.set_yscale("log")
    ax.set_xscale("log")
    ax.legend(fontsize=8)
    ax.set_title(report["machine"]["backend_used"], fontsize=10)
    plt.tight_layout()
    plt.show()
''')

nb.why(
    "**Why an attention sweep rather than a generation sweep.** Step 1 asks for the "
    "choice and its justification. The decisive reason is not cost, it is that a cheap "
    "sweep can be run **twice, in opposite orders**, and that is the only way to turn "
    "\"thermal drift might have affected this\" into a measured number. Hint 1 suggests "
    "exactly this and it is the single most valuable thing in the report: a limitations "
    "section that says \"the mean signed difference between orderings was +0.8%\" is "
    "worth more than a paragraph about generalisability, because a reader can act on it.\n\n"
    "The secondary reason is that attention is where the quadratic term lives. "
    "`cosmos_course.config.estimate_generation_cost` is linear in tokens times steps, and "
    "Lesson 01's exercise identified that linearity as the dominant source of prediction "
    "error. Measuring the quadratic directly is the experiment that error implies.\n\n"
    "**Why the methodology is structured data.** Step 4 insists on it and the reason is "
    "that prose methodology is not checkable. `check_report` asserts on six specific "
    "keys, so a report that has drifted away from its own description fails a test rather "
    "than merely misleading a reader. It also makes the report diffable: two reports from "
    "different machines can be compared field by field, and the fields that differ are "
    "exactly the confounds.\n\n"
    "**Why the limitations are specific and slightly uncomfortable.** \"More testing is "
    "needed\" is a sentence that costs nothing and says nothing. Each limitation above "
    "names something a reader could check, and two of them undermine the report's own "
    "headline — the sample size does not support a confidence interval, and memory was "
    "not measured at all, so a fast configuration that OOMs would look good here. "
    "`check_report`'s 40-character minimum is a crude proxy for specificity, and it is "
    "there because the temptation to write four short ones is real.\n\n"
    "**Why the quadratic reference line is on the plot.** A log-log plot of attention "
    "time against sequence length should have slope 2. Drawing the reference makes the "
    "deviation visible, and the deviation is informative: at short sequences the curve "
    "is flatter than quadratic because launch overhead dominates, and the length at "
    "which it straightens out is the point below which your measurements are about the "
    "framework rather than about attention."
)

nb.extend(
    "The report describes one machine at one moment. The version worth keeping is one "
    "*committed to the repository and regenerated on every environment change*, with a "
    "small script that diffs the new points against the last committed ones and fails if "
    "any point moved by more than its IQR. That turns the benchmark from a document into "
    "a regression test, and it catches the class of problem that is otherwise found "
    "months later: a driver update, a torch upgrade, or a different attention backend "
    "silently changing performance. The machinery is already here — the JSON is "
    "structured, the methodology is machine-readable, and `check_report` is most of the "
    "comparison logic."
)

nb.finish()
