"""Build solutions/04_solutions.ipynb — reference answers for Lesson 04."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("04", "Reasoning: embodied",
                      lesson_file="04_reasoning_embodied.ipynb")

nb.header(
    "Lesson 04 asks a vision-language model to plan, and finds that it will confidently "
    "plan around an object that is not there. The three exercises attack that from three "
    "sides: make the output **strictly parseable** so the failure cannot hide behind a "
    "parse error; **check groundability** so a plan referencing a ghost is rejected "
    "before it reaches a robot; and build a **self-consistency harness**, then ask the "
    "question that decides whether it is worth its cost — does agreement actually "
    "predict correctness?"
)

nb.prelude(
    "The lesson's setup and assets, with the NIM gate softened to a flag. When no "
    "reasoner is reachable, every probe falls back to a **stub** whose failure modes are "
    "the ones this lesson is about. The stub is not a model and its answers are not "
    "findings — it exists so the harness logic around the model can be proven correct."
)
nb.code(setup_cell("04"))

nb.code('''
import json
import random
import re
import shutil
import time
from collections import Counter

from cosmos_course.models import Reasoner, split_think
from cosmos_course.nim import NimConfig, nim_status

NIM = NimConfig()
NIM_READY = bool(nim_status(NIM).get("ready")) if shutil.which("docker") else False
reasoner = Reasoner(base_url=NIM.base_url) if NIM_READY else None

PLANNING_IMAGE = cc.asset_or_none("robot_planning")
NEXT_ACTION_CLIP = cc.asset_or_none("robotics_next_action")
ASSISTED_CLIP = cc.asset_or_none("assisted_task")
COMMON_SENSE_CLIP = cc.asset_or_none("common_sense")
ASSETS_PRESENT = all(p is not None for p in
                     (PLANNING_IMAGE, NEXT_ACTION_CLIP, ASSISTED_CLIP, COMMON_SENSE_CLIP))

print(f"NIM ready      : {NIM_READY}")
print(f"cookbook assets: {'present' if ASSETS_PRESENT else 'missing — scripts/fetch_assets.py'}")
LIVE = NIM_READY and ASSETS_PRESENT
if not LIVE:
    print("\\nRunning against the stub. Everything below still executes; nothing "
          "below is a measurement of Cosmos 3.")
''')

nb.code('''
class StubReasoner:
    """A deliberately badly-behaved model, for exercising the harness offline.

    It reproduces exactly the three wrapping failures hint 1 lists, and it
    reproduces them CONDITIONALLY on the prompt: it adds a code fence unless the
    prompt forbids fences, a preamble unless the prompt forbids prose before,
    and a trailing explanation unless the prompt forbids prose after. That is
    what makes the ablation in step 4 of Exercise 1 demonstrable without a GPU.

    It is a caricature, not a model. A real reasoner's behaviour is
    probabilistic and its response to an instruction is not a switch. Every
    number produced against this stub is a property of the stub.
    """

    # What the stubbed scene contains. Used by the grounder in Exercise 2.
    SCENE = {"flower": [120, 300, 260, 640], "red bottle": [400, 280, 520, 660],
             "table": [0, 600, 1000, 1000], "person": [700, 100, 950, 900],
             "green cup": [560, 420, 650, 640]}
    SYNONYMS = {"plant": "flower", "flowers": "flower", "bottle": "red bottle",
                "red container": "red bottle", "cup": "green cup",
                "human": "person", "worktop": "table", "desk": "table"}

    def __init__(self, seed=0):
        self.rng = random.Random(seed)
        self.calls = 0

    def ask(self, prompt, *, images=None, videos=None, temperature=None, **kwargs):
        self.calls += 1
        if '"present"' in prompt or "present" in prompt and "bbox_2d" in prompt:
            return self._ground(prompt)
        if "Reply with JSON only" in prompt or '"step": 1' in prompt:
            return self._plan(prompt)
        return self._short_answer(prompt, temperature)

    # -- planning ---------------------------------------------------------
    def _plan(self, prompt):
        goal = prompt.splitlines()[0]
        body = json.dumps([
            {"step": 1, "action": "move above the flower", "object": "flower",
             "gripper_state": "open"},
            {"step": 2, "action": "close the gripper on the stem", "object": "flower",
             "gripper_state": "closed"},
            {"step": 3, "action": "lower the flower into the opening",
             "object": "red bottle", "gripper_state": "closed"},
        ], indent=2)
        # Any goal that is not the shipped one makes the stub reach for an
        # object that is not in the scene — the ghost-mug failure, on purpose.
        if "clear the table" in goal:
            body = json.dumps([
                {"step": 1, "action": "pick up the blue ceramic mug",
                 "object": "blue ceramic mug", "gripper_state": "closed"},
                {"step": 2, "action": "place it in the bin", "object": "bin",
                 "gripper_state": "open"},
            ], indent=2)
        out = body
        if "no code fence" not in prompt.lower():
            out = "```json\\n" + out + "\\n```"
        if "no prose before" not in prompt.lower():
            out = "Here is a plan for the task:\\n\\n" + out
        if "no prose after" not in prompt.lower():
            out = out + "\\n\\nLet me know if you would like me to expand any step."
        return out

    # -- grounding --------------------------------------------------------
    def _ground(self, prompt):
        match = re.search(r'object:\\s*"([^"]+)"', prompt.lower())
        name = (match.group(1).strip() if match else "").strip()
        canonical = self.SYNONYMS.get(name, name)
        if canonical in self.SCENE:
            # A false rejection, on purpose: the stub refuses to recognise
            # "flower" about 25% of the time, standing in for a real grounder
            # that misses a real object.
            if canonical == "flower" and self.rng.random() < 0.25:
                return json.dumps({"present": False, "name": None, "bbox_2d": None,
                                   "confidence": 0.2})
            return json.dumps({"present": True, "name": canonical,
                               "bbox_2d": self.SCENE[canonical], "confidence": 0.9})
        return json.dumps({"present": False, "name": None, "bbox_2d": None,
                           "confidence": 0.05})

    # -- short free-text answers, with tunable spread ---------------------
    _POOLS = {
        "left": ["to the left of the bottle", "left of the red bottle",
                 "on the left side, beside the bottle"],
        "hard": ["three", "four", "two", "five"],
        "easy": ["yes", "yes", "yes", "yes", "yes", "yes", "no"],
    }

    def _short_answer(self, prompt, temperature):
        pool = self._POOLS["left"]
        if "how many" in prompt.lower():
            pool = self._POOLS["hard"]
        elif prompt.lower().startswith(("is ", "does ", "can ")):
            pool = self._POOLS["easy"]
        if not temperature:
            return pool[0]
        return self.rng.choice(pool)


STUB = StubReasoner()
print("stub ready — its scene contains:", sorted(StubReasoner.SCENE))
''')

nb.code('''
# The lesson's schema-constrained planning prompt, unchanged, as the baseline.
PLAN_SCHEMA_PROMPT = """The task is to put flower into the red bottle.
Generate a plan consisting of subtasks for accomplishing the task.

Reply with JSON only. No prose, no code fence. Use exactly this shape:
[
  {"step": 1,
   "action": "short imperative verb phrase",
   "object": "the single object this step acts on, as it appears in the image",
   "gripper_state": "open" or "closed"}
]
Order the steps so that each one is physically executable given the state left
by the step before it."""

GOAL_SENTINEL = "put flower into the red bottle"


def ask(prompt, *, images=None, videos=None, **kwargs):
    """One entry point for every model call, so the stub can stand in for it."""
    if LIVE:
        return reasoner.ask(prompt, images=images, videos=videos, **kwargs)
    return STUB.ask(prompt, images=images, videos=videos, **kwargs)
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Make the plan strictly parseable",
    goal="Rewrite a planning prompt so its output parses first time, every time, across "
         "five different goals — without post-processing.",
    success="Five out of five parse with no post-processing, and you can name the one "
            "instruction doing most of the work.",
    approach="Measure with `json.loads`, not with `reasoner.parse_json` — because "
             "`parse_json` *is* the post-processing the exercise forbids, and measuring "
             "with it lets a sloppy prompt score 5/5.",
)

nb.code('''
MY_GOALS = [
    "put flower into the red bottle",
    "move the red bottle to the left edge of the table",
    "hand the red bottle to the person",
    "tidy the table without moving the flower",
    "pour the contents of the red bottle into the green cup",
]


def strict_parse(text):
    """Parse with NO tolerance. Returns (ok, value_or_reason).

    This is `json.loads`, not `reasoner.parse_json`. Read parse_json's
    docstring: it strips markdown fences, skips prose before, ignores prose
    after, and can look past a <think> block. Those are the four failures this
    exercise is asking you to eliminate FROM THE PROMPT. Scoring with it would
    mean a prompt that produces a fenced, prefaced, footnoted blob scores 5/5 —
    a measurement that cannot see the thing being measured.
    """
    try:
        return True, json.loads(text)
    except json.JSONDecodeError as exc:
        return False, f"{exc.msg} at line {exc.lineno} col {exc.colno}"


def diagnose_wrapper(text):
    """Which of the known wrapping failures is present?"""
    found = []
    if "```" in text:
        found.append("markdown fence")
    stripped = text.strip()
    if stripped and stripped[0] not in "[{":
        found.append("prose before the JSON")
    if stripped.endswith((".", "!", "?")) and stripped[-1] not in "]}":
        found.append("prose after the JSON")
    if "<think>" in text:
        found.append("reasoning block")
    if re.search(r",\\s*[}\\]]", text):
        found.append("trailing comma")
    if "//" in text or "/*" in text:
        found.append("comment")
    return found


def parse_rate(prompt_template, goals, image, *, sentinel=GOAL_SENTINEL):
    """Fraction of goals whose plan parses on the first attempt, strictly."""
    results = []
    for goal in goals:
        prompt = prompt_template.replace(sentinel, goal)
        text = ask(prompt, images=image, max_tokens=2048, seed=0, temperature=0.0)
        ok, detail = strict_parse(text)
        results.append({"goal": goal, "ok": ok,
                        "reason": None if ok else detail,
                        "wrappers": diagnose_wrapper(text),
                        "raw_head": text[:70].replace("\\n", "\\\\n")})
    rate = sum(r["ok"] for r in results) / len(results)
    return rate, results


def report(label, rate, results):
    print(f"{label}: {rate:.0%} strict-parse ({sum(r['ok'] for r in results)}"
          f"/{len(results)})")
    for r in results:
        if not r["ok"]:
            print(f"  FAIL {r['goal'][:44]:<46} {', '.join(r['wrappers']) or r['reason']}")
            print(f"       starts: {r['raw_head']}")
''')

nb.code('''
baseline_rate, baseline_results = parse_rate(PLAN_SCHEMA_PROMPT, MY_GOALS, PLANNING_IMAGE)
report("baseline PLAN_SCHEMA_PROMPT", baseline_rate, baseline_results)
print()
print("Step 2 — what the model did wrong, per failure:")
tally = Counter(w for r in baseline_results for w in r["wrappers"])
for wrapper, n in tally.most_common():
    print(f"  {wrapper:<24} {n} of {len(MY_GOALS)} goals")
if not tally:
    print("  (nothing — the baseline already parses strictly on this backend)")
''')

nb.code('''
# Step 3: change THE PROMPT until all five parse. Four additions, each aimed at
# one observed failure, and each phrased as a negative constraint plus a
# positive restatement of what to emit instead.
HARDENED_PLAN_PROMPT = """The task is to put flower into the red bottle.
Generate a plan consisting of subtasks for accomplishing the task.

Output format — follow every line exactly:
- Output raw JSON and nothing else.
- No prose before the JSON.
- No prose after the JSON.
- No code fence, no backtick characters, no explanation, no apology.
- The first character of your reply must be [ and the last must be ].
- Do not emit comments and do not emit trailing commas.

Shape:
[
  {"step": 1,
   "action": "short imperative verb phrase",
   "object": "the single object this step acts on, as it appears in the image",
   "gripper_state": "open"},
  {"step": 2,
   "action": "short imperative verb phrase",
   "object": "the single object this step acts on, as it appears in the image",
   "gripper_state": "closed"}
]

Order the steps so that each one is physically executable given the state left
by the step before it."""

hardened_rate, hardened_results = parse_rate(HARDENED_PLAN_PROMPT, MY_GOALS,
                                             PLANNING_IMAGE)
report("hardened prompt", hardened_rate, hardened_results)
assert hardened_rate == 1.0, hardened_results
print()
print("PASS 5/5 parse strictly, with no post-processing applied to the output")
''')

nb.code('''
# Step 4: break it on purpose. Remove one instruction at a time and see which
# removal costs the most. This is an ablation, and it is the only way to tell
# which instruction is load-bearing from which is superstition.
ABLATIONS = {
    "no fence rule":
        "- No code fence, no backtick characters, no explanation, no apology.\\n",
    "no prose-before rule": "- No prose before the JSON.\\n",
    "no prose-after rule": "- No prose after the JSON.\\n",
    "no first/last-character rule":
        "- The first character of your reply must be [ and the last must be ].\\n",
    "no worked two-step example": None,   # handled specially below
}

print(f"{'ablation':<32}{'parse rate':>12}   what broke")
print("-" * 78)
print(f"{'(none — hardened prompt)':<32}{hardened_rate:>11.0%}")
for label, fragment in ABLATIONS.items():
    if fragment is None:
        # Drop the second element of the shape example, leaving a one-item list.
        variant = re.sub(r",\\n  \\{\\"step\\": 2,.*?\\}\\n\\]", "\\n]",
                         HARDENED_PLAN_PROMPT, flags=re.S)
    else:
        variant = HARDENED_PLAN_PROMPT.replace(fragment, "")
    assert variant != HARDENED_PLAN_PROMPT, f"{label}: the ablation removed nothing"
    rate, results = parse_rate(variant, MY_GOALS, PLANNING_IMAGE)
    broke = sorted({w for r in results for w in r["wrappers"]})
    print(f"{label:<32}{rate:>11.0%}   {', '.join(broke) or '-'}")

if not LIVE:
    print()
    print("READ THE ZEROES, NOT THE HUNDREDS. The stub only models three wrapping")
    print("behaviours, so any row still at 100% is a row the stub is BLIND to, not")
    print("a rule that is free. The first/last-character rule and the worked example")
    print("cannot show an effect here by construction; against a real model they can,")
    print("and the model answer below argues that the example is the strongest of them.")
''')

nb.model_answer(
    "**Which instruction carries the load, and why.**\n\n"
    "On this backend the ablation table names the fence rule, and that ordering is worth "
    "explaining rather than just reporting. The three wrapping failures are not equally "
    "likely, because they come from different parts of the model's training. A markdown "
    "fence around JSON is the single most reinforced pattern in any chat-tuned model's "
    "instruction data — it is what \"show me some JSON\" looks like in nearly every "
    "example it ever saw. Preambles and trailing offers of help are assistant-persona "
    "behaviour, strong but weaker. So the instruction that suppresses the strongest prior "
    "is the one whose removal costs the most.\n\n"
    "**But the more interesting answer is that no single instruction is doing the work — "
    "the *worked example* is.** Hint 2 says it directly: putting the literal shape in the "
    "prompt beats describing it, because the model is completing a pattern rather than "
    "following a description. The ablation above includes a row for removing the second "
    "element of the shape example, and that row is there because a one-element example is "
    "ambiguous about whether a list is even wanted. Two elements settles it. If your "
    "ablation found the example mattered more than any prohibition, that is the better "
    "finding and it generalises further: **constraints tell a model what not to do; "
    "examples tell it what to do, and the second is more reliable.**\n\n"
    "**The instruction I would keep even if the ablation said it was free:** \"the first "
    "character of your reply must be `[` and the last must be `]`\". It is the only one "
    "phrased as a *checkable property of the output* rather than as a prohibition on a "
    "behaviour. That makes it robust to failures nobody enumerated — a language "
    "disclaimer, a leading newline with a BOM, an unexpected XML tag — because it "
    "constrains the string rather than the intent. Prohibitions cover the failures you "
    "have already seen. Output-shape assertions cover the ones you have not.\n\n"
    "**Caveat that must not be skipped.** With no NIM, the table above was produced "
    "against `StubReasoner`, which switches three wrapping behaviours on the literal "
    "presence of phrases in the prompt and models nothing else. Two consequences. "
    "First, the ablation is *perfectly* clean, which a real model never is. Second — and "
    "this is the one that would mislead you — **the stub cannot exhibit an effect from "
    "the worked example or from the first/last-character rule at all**, so those rows "
    "read 100% because the instrument is blind, not because the instructions are free. "
    "Rows that drop to 0% are informative; rows that stay at 100% are not. Re-run "
    "against the NIM before believing any ordering: the real result is probabilistic, "
    "five goals is a small sample, and an instruction that looks free at n=5 may be "
    "carrying a 10% failure rate you cannot see."
)

nb.extend(
    "Five goals is not enough to distinguish a 100% prompt from a 90% one. The cheap "
    "extension is to run each goal `k` times at `temperature=0.7` rather than once at 0, "
    "and report the parse rate as a proportion with a binomial interval. Instructions "
    "look load-bearing or free depending on where the failures fall, and at n=5 you "
    "cannot tell a real effect from a coin. The expensive-but-correct version is to keep "
    "the failures: log every non-parsing response to a file, and grow a regression set "
    "of prompts-that-broke. That file is worth more than the prompt, because the next "
    "model version will break differently and you will want yesterday's failures to test "
    "against."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "A plan validator that checks groundability",
    goal="Reject plans that reference objects the model cannot actually find in the "
         "image — the check that would have caught the ghost mug.",
    success="Every plan gets a groundability verdict per step, the injected fake object "
            "is caught, and the report contains at least one honest false rejection — a "
            "real object the grounder missed.",
    approach="Give the model an explicit way to say \"absent\", and have it return the "
             "name it *would* use, so a mismatch of vocabulary can be told apart from a "
             "mismatch of reality.",
)

nb.code('''
GROUND_PROMPT = """Look at the image and answer about one object.

OBJECT: "{name}"

Reply with raw JSON only, no fence, no prose. The first character must be {{ and
the last must be }}.

{{"present": true or false,
 "name": "the word YOU would use for this object, or null if it is not there",
 "bbox_2d": [x1, y1, x2, y2] in 0-1000 normalised coordinates, or null,
 "confidence": a number between 0 and 1}}

If the object is not in the image, say so: set "present" to false. Saying an
object is absent is a correct answer, not a failure to answer."""


def _normalise_name(text):
    """Loose comparison, so 'the red bottle' and 'red bottle ' are one thing."""
    text = re.sub(r"[^a-z0-9 ]+", " ", str(text or "").lower())
    words = [w for w in text.split() if w not in {"a", "an", "the", "of"}]
    return " ".join(sorted(words))


def _names_agree(asked, returned):
    """Do these two names plausibly denote the same object?

    Hint 2's trap: if you reject 'flower' because the grounder called it
    'plant', you have built a vocabulary matcher. Overlap on any content word is
    a deliberately loose test — it accepts 'red bottle' vs 'bottle' and 'flower'
    vs 'flower in a vase', and it will also accept some genuine mismatches. That
    asymmetry is chosen: a false ACCEPT here costs you one bad plan step that
    later checks may catch; a false REJECT throws away a correct plan.
    """
    if not returned:
        return False
    a, b = set(_normalise_name(asked).split()), set(_normalise_name(returned).split())
    return bool(a & b)


def can_ground(object_name, image, *, threshold=0.5):
    """Ask for a box for one object; allow 'not present' as an answer.

    Returns (found, confidence, box). `found` requires three things together:
    the model said present, its confidence cleared the threshold, and the name
    it returned is compatible with the one asked about.
    """
    text = ask(GROUND_PROMPT.format(name=object_name), images=image,
               max_tokens=256, seed=0, temperature=0.0)
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        try:
            data = Reasoner.parse_json(text)     # tolerant fallback, logged below
        except ValueError:
            return False, 0.0, None
    present = bool(data.get("present"))
    confidence = float(data.get("confidence") or 0.0)
    box = data.get("bbox_2d")
    if present and confidence >= threshold and not _names_agree(object_name,
                                                                data.get("name")):
        # Present, confident, but calling it something unrelated. Report it as
        # ungroundable rather than silently accepting a different object.
        return False, confidence, box
    return (present and confidence >= threshold), confidence, box


def validate_plan_grounding(plan, image, *, threshold=0.5):
    """Return {'ok': [...], 'ungroundable': [...]} over the plan's objects."""
    objects = []
    for step in plan or []:
        if isinstance(step, dict) and step.get("object"):
            name = str(step["object"]).strip()
            if name and name not in objects:
                objects.append(name)
    ok, bad = [], []
    for name in objects:
        found, confidence, box = can_ground(name, image, threshold=threshold)
        entry = {"object": name, "confidence": round(confidence, 3), "bbox_2d": box}
        (ok if found else bad).append(entry)
    surviving = [s for s in (plan or [])
                 if isinstance(s, dict)
                 and str(s.get("object", "")).strip() not in {b["object"] for b in bad}]
    return {"ok": ok, "ungroundable": bad, "steps_total": len(plan or []),
            "steps_surviving": len(surviving)}
''')

nb.code('''
# The three goals from the lesson's ablation, planned then grounded.
GOALS = ["put flower into the red bottle", "clear the table",
         "hand the red bottle to the person"]

plans, verdicts = {}, {}
for goal in GOALS:
    prompt = HARDENED_PLAN_PROMPT.replace(GOAL_SENTINEL, goal)
    text = ask(prompt, images=PLANNING_IMAGE, max_tokens=2048, seed=0, temperature=0.0)
    ok, value = strict_parse(text)
    plans[goal] = value if ok else []
    verdicts[goal] = validate_plan_grounding(plans[goal], PLANNING_IMAGE)

print(f"{'goal':<44}{'steps':>7}{'survive':>9}  ungroundable")
print("-" * 92)
for goal in GOALS:
    v = verdicts[goal]
    bad = ", ".join(b["object"] for b in v["ungroundable"]) or "-"
    print(f"{goal:<44}{v['steps_total']:>7}{v['steps_surviving']:>9}  {bad}")
''')

nb.code('''
# Step 4 — verify the validator by trying to fool it. A validator you have not
# attacked is a validator you do not know works.
INJECTED = "blue ceramic mug"
poisoned = list(plans[GOALS[0]]) + [
    {"step": 99, "action": "pick up the blue ceramic mug", "object": INJECTED,
     "gripper_state": "closed"}]

v = validate_plan_grounding(poisoned, PLANNING_IMAGE)
caught = [b["object"] for b in v["ungroundable"]]
print(f"injected object   : {INJECTED!r}")
print(f"ungroundable      : {caught}")
assert INJECTED in caught, "the injected ghost object was NOT caught"
print("PASS the injected object was rejected")

# The other half of the check, and the one people forget: the validator must
# not reject everything. A function that returns "ungroundable" for all input
# also catches the ghost.
real_found, real_conf, real_box = can_ground("red bottle", PLANNING_IMAGE)
print(f"\\ncontrol: can_ground('red bottle') -> found={real_found} "
      f"confidence={real_conf}")
assert real_found, ("the validator rejects a real object as well, so catching the "
                    "ghost proves nothing")
print("PASS a real object is still accepted, so the rejection above was selective")
''')

nb.code('''
# Step 5 — the report, including an HONEST false rejection. The stub misses
# "flower" about a quarter of the time on purpose; against a real model you
# will find your own, and you should look for it rather than hope it is absent.
trials, misses = 12, []
for i in range(trials):
    found, conf, _ = can_ground("flower", PLANNING_IMAGE)
    if not found:
        misses.append(conf)

total_objects = sum(len(v["ok"]) + len(v["ungroundable"]) for v in verdicts.values())
total_rejected = sum(len(v["ungroundable"]) for v in verdicts.values())

lines = [
    "# Groundability report — Lesson 04, Exercise 2",
    "",
    ("**Produced against the offline stub, not against Cosmos 3.** Re-run with a "
     "NIM to replace every number here." if not LIVE else
     "Measured against the Reasoner NIM on this machine."),
    "",
    "## Rejection rate",
    "",
    f"- distinct objects checked across {len(GOALS)} plans: {total_objects}",
    f"- rejected as ungroundable: {total_rejected}"
    + (f" ({total_rejected / total_objects:.0%})" if total_objects else ""),
    "",
    "## A correct rejection",
    "",
    f"`{INJECTED}` was injected into a plan deliberately. It is not in the image, the "
    "grounder said `present: false`, and the step was removed. This is the ghost-mug "
    "failure from the lesson, caught before it reached anything that could act on it.",
    "",
    "## An honest false rejection",
    "",
    (f"`flower` IS in the image, and the grounder returned `present: false` on "
     f"{len(misses)} of {trials} repeated asks (confidences: "
     f"{[round(c, 2) for c in misses]}). A real object that the grounder misses is a "
     f"false rejection, and it costs a correct plan step."
     if misses else
     f"No false rejection was observed in {trials} repeated asks about `flower`. "
     f"That is not evidence there are none — it is evidence that this object, at "
     f"this threshold, is easy. Lower the threshold until you find one, or try an "
     f"object that is small, occluded, or partly out of frame."),
    "",
    "## What the threshold is really trading",
    "",
    "Raising `threshold` catches more ghosts and rejects more real objects. The two "
    "errors are not symmetric: a false accept puts a nonexistent object into a plan a "
    "robot may execute; a false reject discards a step a human can restore. For "
    "anything with an actuator on the end of it, prefer the false reject — and log "
    "both, because a rejection rate that climbs over time is how you notice the "
    "grounder degrading before it starts hallucinating.",
]
report_path = OUTPUT_DIR / "grounding_report.md"
report_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {report_path}\\n")
print("\\n".join(lines[:22]))
''')

nb.why(
    "**Why the grounder is asked for a name as well as a box.** Hint 2 names the failure: "
    "reject \"flower\" because the model called it \"plant\" and you have built a "
    "vocabulary matcher, not a grounder. The fix is to ask the model what *it* would call "
    "the object and compare loosely — content-word overlap, stopwords removed. That "
    "accepts \"red bottle\" against \"bottle\" and \"flower\" against \"flower in a "
    "vase\".\n\n"
    "It also accepts some genuine mismatches, and that asymmetry is deliberate. A false "
    "accept here costs one bad plan step, which later checks and a human may catch. A "
    "false reject silently deletes a correct step from a plan. When the two errors have "
    "different costs, the threshold should not sit where accuracy is maximised.\n\n"
    "**Why `present: false` has to be offered explicitly.** This is the load-bearing "
    "sentence in `GROUND_PROMPT`: *\"Saying an object is absent is a correct answer, not "
    "a failure to answer.\"* Asked \"where is the blue ceramic mug\", an instruction-tuned "
    "model treats not-answering as failing the user, and produces a plausible location. "
    "That is the entire ghost-mug mechanism from the lesson. Restructuring the question "
    "so that \"it is not there\" is a *value of a field* rather than a refusal to comply "
    "changes what the model is being rewarded for.\n\n"
    "**Why the control check exists.** The injected-ghost assertion is necessary and not "
    "sufficient: `def can_ground(*a, **k): return False, 0.0, None` passes it. So the "
    "cell asserts both directions — the ghost is rejected *and* a real object is "
    "accepted. Any test that only checks the failing case is passed by a function that "
    "always fails, and this is a mistake worth being paranoid about, because a validator "
    "that rejects everything looks extremely safe right up until someone notices nothing "
    "gets through.\n\n"
    "**Why the false rejection is hunted rather than hoped for.** Step 5 asks for one, "
    "and the temptation is to run the grounder once, see it succeed, and write \"none "
    "observed\". A single ask at temperature 0 is one sample; repeating it twelve times "
    "is the minimum that can distinguish \"reliable\" from \"usually works\". If none turns "
    "up, the report says explicitly that this is evidence about *this object at this "
    "threshold*, not evidence about the grounder — and tells you where to look next "
    "(small, occluded, partly out of frame). A report that cannot find its own failure "
    "mode has usually not looked."
)

nb.extend(
    "Groundability is a per-object check; the failure it cannot see is a **relational** "
    "one. Every object in \"place the flower to the left of the bottle\" grounds "
    "perfectly, and the plan is still wrong if the flower is already there or if the "
    "bottle is out of reach. The extension is to ground the *relation*: having boxes for "
    "both objects, check that the spatial claim in the action is consistent with them "
    "before executing. Lesson 05 gives you the coordinates to do it with, and it converts "
    "this validator from \"do these words refer to anything\" into \"is this step "
    "physically sensible\" — a substantially stronger claim, and one that costs no extra "
    "model calls because the boxes are already in hand."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "A self-consistency harness, and does agreement predict correctness?",
    goal="Build the harness, then answer whether higher agreement actually means a "
         "higher chance of being right on a small hand-labelled set.",
    success="`outputs/04/consistency_report.md` contains the accuracy-by-agreement "
            "table, the labelled set is saved so someone else could re-run it, and the "
            "conclusion is stated with its uncertainty rather than as a finding.",
    approach="Cluster by normalised token overlap rather than exact string match, keep "
             "the labelled set deliberately mixed in difficulty, and report the "
             "agreement/accuracy relationship with an interval wide enough to be honest "
             "about n=12.",
)

nb.code('''
_FILLER = {"the", "a", "an", "is", "it", "of", "to", "in", "on", "at", "and",
           "that", "this", "there", "are", "be", "as", "its", "with"}


def _canonical(answer):
    """Normalise an answer for clustering: lowercase, strip filler, sort tokens."""
    text = re.sub(r"[^a-z0-9 ]+", " ", str(answer).lower())
    return frozenset(w for w in text.split() if w and w not in _FILLER)


def _similar(a, b, *, threshold=0.5):
    """Jaccard overlap on content words."""
    if not a or not b:
        return a == b
    return len(a & b) / len(a | b) >= threshold


def cluster_answers(answers, *, threshold=0.5):
    """Group semantically-equivalent answers. Returns [(representative, [answers])].

    Exact string match is not good enough — the exercise says so, and the
    canonical example is "to the left of the bottle" versus "left of the red
    bottle". Token-overlap clustering handles that class without a second model
    call. It does NOT handle paraphrase without shared vocabulary ("beside it,
    on the near side") or negation ("not on the right"), and the commentary
    below says what to do about that.
    """
    clusters = []
    for answer in answers:
        key = _canonical(answer)
        for cluster in clusters:
            if _similar(key, cluster["key"], threshold=threshold):
                cluster["members"].append(answer)
                break
        else:
            clusters.append({"key": key, "members": [answer]})
    clusters.sort(key=lambda c: -len(c["members"]))
    return [(c["members"][0], c["members"]) for c in clusters]


def self_consistency(question, media, *, n=8, temperature=0.8, images=None,
                     videos=None, max_tokens=96, threshold=0.5):
    """Sample n answers, cluster them, return (majority, agreement, clusters)."""
    images = images if images is not None else (media if media and
                                                str(media).endswith((".png", ".jpg",
                                                                     ".jpeg")) else None)
    videos = videos if videos is not None else (media if media and
                                                str(media).endswith(".mp4") else None)
    answers = []
    for i in range(n):
        text = ask(question, images=images, videos=videos, max_tokens=max_tokens,
                   temperature=temperature, seed=i)
        answers.append(split_think(text)[1].strip() or text.strip())
    clusters = cluster_answers(answers, threshold=threshold)
    majority, members = clusters[0]
    return majority, len(members) / len(answers), clusters
''')

nb.code('''
# The clustering is the part that has to be right, and it can be checked on
# hand-made strings — including the exact pair the exercise names.
pairs_same = [
    ("to the left of the bottle", "left of the red bottle"),
    ("three", "three."),
    ("yes, it is stable", "yes it is stable"),
]
pairs_different = [
    ("to the left of the bottle", "to the right of the bottle"),
    ("three", "four"),
]
for a, b in pairs_same:
    clusters = cluster_answers([a, b])
    assert len(clusters) == 1, (a, b, clusters)
for a, b in pairs_different:
    clusters = cluster_answers([a, b])
    assert len(clusters) == 2, (a, b, clusters)
print("PASS 'to the left of the bottle' and 'left of the red bottle' cluster together")
print("PASS 'left of' and 'right of' do NOT cluster together")

# And the known limitation, demonstrated rather than merely admitted:
hard = cluster_answers(["to the left of the bottle", "on the near side, beside it"])
print(f"\\nKNOWN MISS: {len(hard)} clusters for two answers a human would call the "
      f"same. Token overlap cannot see paraphrase without shared vocabulary.")
''')

nb.code('''
# Step 3 — the hand-labelled set. Twelve items across the four clips, mixed in
# difficulty on purpose (hint 2): four expected-hard, the rest expected-easy.
# `truth` is what a human determined by LOOKING; where no assets are present,
# the truths are placeholders and are marked as such.
def _m(path):
    return str(path) if path is not None else None


LABELLED = [
    {"id": "p1", "question": "Is there a red bottle in this image? Answer yes or no.",
     "media": _m(PLANNING_IMAGE), "kind": "image", "truth": "yes", "expect": "easy"},
    {"id": "p2", "question": "Where is the flower relative to the red bottle? "
                             "Answer in under ten words.",
     "media": _m(PLANNING_IMAGE), "kind": "image", "truth": "to the left of the bottle",
     "expect": "easy"},
    {"id": "p3", "question": "Is there a blue ceramic mug in this image? yes or no.",
     "media": _m(PLANNING_IMAGE), "kind": "image", "truth": "no", "expect": "hard"},
    {"id": "p4", "question": "How many distinct objects are on the table? "
                             "Answer with a number only.",
     "media": _m(PLANNING_IMAGE), "kind": "image", "truth": "three", "expect": "hard"},
    {"id": "n1", "question": "Is a robot arm visible? yes or no.",
     "media": _m(NEXT_ACTION_CLIP), "kind": "video", "truth": "yes", "expect": "easy"},
    {"id": "n2", "question": "Does the gripper close during the clip? yes or no.",
     "media": _m(NEXT_ACTION_CLIP), "kind": "video", "truth": "yes", "expect": "easy"},
    {"id": "n3", "question": "How many times does the gripper open? number only.",
     "media": _m(NEXT_ACTION_CLIP), "kind": "video", "truth": "two", "expect": "hard"},
    {"id": "a1", "question": "Is a person present in this clip? yes or no.",
     "media": _m(ASSISTED_CLIP), "kind": "video", "truth": "yes", "expect": "easy"},
    {"id": "a2", "question": "Does the person hand something over? yes or no.",
     "media": _m(ASSISTED_CLIP), "kind": "video", "truth": "yes", "expect": "easy"},
    {"id": "c1", "question": "Does anything fall in this clip? yes or no.",
     "media": _m(COMMON_SENSE_CLIP), "kind": "video", "truth": "no", "expect": "hard"},
    {"id": "c2", "question": "Is the scene indoors? yes or no.",
     "media": _m(COMMON_SENSE_CLIP), "kind": "video", "truth": "yes", "expect": "easy"},
    {"id": "c3", "question": "Is anything in the clip physically impossible? yes or no.",
     "media": _m(COMMON_SENSE_CLIP), "kind": "video", "truth": "no", "expect": "easy"},
]

labelled_path = OUTPUT_DIR / "labelled_probes.json"
labelled_path.write_text(json.dumps(
    {"note": ("Hand-labelled by looking at the media. If the cookbook assets are not "
              "on this machine the `truth` values are PLACEHOLDERS — open each clip "
              "and correct them before drawing any conclusion."),
     "assets_present": ASSETS_PRESENT, "items": LABELLED}, indent=2) + "\\n",
    encoding="utf-8")
print(f"wrote {len(LABELLED)} labelled probes to {labelled_path}")
print(f"  {sum(1 for i in LABELLED if i['expect'] == 'hard')} expected-hard, "
      f"{sum(1 for i in LABELLED if i['expect'] == 'easy')} expected-easy")
''')

nb.code('''
# Hint 3: estimate the cost BEFORE the loop. 12 items x N samples is the whole
# budget, and finding out afterwards is the expensive way to learn it.
N_SAMPLES = 8 if LIVE else 8
TEMPERATURE = 0.8
requests = len(LABELLED) * N_SAMPLES
stats = reasoner.stats() if (LIVE and reasoner is not None) else {}
per_call = stats.get("mean_seconds")
print(f"planned: {len(LABELLED)} items x {N_SAMPLES} samples = {requests} requests")
if per_call:
    print(f"measured mean latency so far: {per_call:.1f} s "
          f"-> about {requests * per_call / 60:.0f} minutes")
else:
    print("No latency measured yet on this machine, so no time estimate is offered. "
          "Run one item first and multiply — do not take a number from anywhere else.")
''')

nb.code('''
def is_correct(answer, truth):
    """Loose match against the hand label. Same clustering rule as the harness."""
    return _similar(_canonical(answer), _canonical(truth), threshold=0.5)


results = []
for item in LABELLED:
    majority, agreement, clusters = self_consistency(
        item["question"], item["media"], n=N_SAMPLES, temperature=TEMPERATURE,
        images=item["media"] if item["kind"] == "image" else None,
        videos=item["media"] if item["kind"] == "video" else None)
    results.append({"id": item["id"], "expect": item["expect"],
                    "agreement": round(agreement, 3), "majority": majority,
                    "truth": item["truth"],
                    "correct": bool(is_correct(majority, item["truth"])),
                    "n_clusters": len(clusters)})

print(f"{'id':<5}{'exp':<6}{'agree':>7}{'ok':>5}  majority")
for r in results:
    print(f"{r['id']:<5}{r['expect']:<6}{r['agreement']:>7.2f}"
          f"{'  Y' if r['correct'] else '  N':>5}  {str(r['majority'])[:44]}")
''')

nb.code('''
# Step 5 — bucket by agreement and report accuracy per bucket.
BUCKETS = [(0.0, 0.5, "low  <0.5"), (0.5, 0.875, "mid  0.5-0.87"),
           (0.875, 1.01, "high >=0.87")]


def wilson(successes, total, z=1.96):
    """A 95% interval that does not go negative or exceed 1 at tiny n.

    The normal approximation gives nonsense at n=4 (intervals below zero, or
    zero width at 0/4 and 4/4). Wilson is two extra lines and does not embarrass
    itself, which matters here precisely because the samples ARE tiny.
    """
    if total == 0:
        return 0.0, 1.0
    p = successes / total
    d = 1 + z ** 2 / total
    centre = (p + z ** 2 / (2 * total)) / d
    half = z * ((p * (1 - p) / total + z ** 2 / (4 * total ** 2)) ** 0.5) / d
    return max(0.0, centre - half), min(1.0, centre + half)


table = []
for low, high, label in BUCKETS:
    rows = [r for r in results if low <= r["agreement"] < high]
    if not rows:
        table.append((label, 0, 0, None, (0.0, 1.0)))
        continue
    ok = sum(r["correct"] for r in rows)
    table.append((label, len(rows), ok, ok / len(rows), wilson(ok, len(rows))))

print(f"{'agreement bucket':<18}{'n':>4}{'correct':>9}{'accuracy':>10}   95% interval")
print("-" * 66)
for label, n, ok, acc, (lo, hi) in table:
    acc_s = f"{acc:.0%}" if acc is not None else "   -"
    print(f"{label:<18}{n:>4}{ok:>9}{acc_s:>10}   [{lo:.0%}, {hi:.0%}]")

overall = sum(r["correct"] for r in results) / len(results)
print(f"\\noverall accuracy: {overall:.0%} over {len(results)} items")
''')

nb.code('''
lines = [
    "# Self-consistency report — Lesson 04, Exercise 3",
    "",
    ("**Produced against the offline stub, not Cosmos 3.** Every number below is a "
     "property of `StubReasoner`. The harness, the clustering and the analysis are "
     "real; the model is not." if not LIVE else
     "Measured against the Reasoner NIM on this machine."),
    "",
    f"- items: {len(LABELLED)} (hand-labelled, saved at `outputs/04/labelled_probes.json`)",
    f"- samples per item: {N_SAMPLES} at temperature {TEMPERATURE}",
    f"- total requests: {len(LABELLED) * N_SAMPLES}",
    f"- overall accuracy of the majority answer: {overall:.0%}",
    "",
    "## Accuracy by agreement",
    "",
    "| agreement bucket | n | correct | accuracy | 95% interval (Wilson) |",
    "|---|---:|---:|---:|---|",
]
for label, n, ok, acc, (lo, hi) in table:
    acc_s = f"{acc:.0%}" if acc is not None else "-"
    lines.append(f"| {label} | {n} | {ok} | {acc_s} | [{lo:.0%}, {hi:.0%}] |")

lines += [
    "",
    "## What twelve items can and cannot support",
    "",
    "Twelve items split three ways leaves about four per bucket. A four-item bucket "
    "at 75% accuracy has a 95% Wilson interval of roughly [30%, 95%] — wide enough to "
    "contain both 'agreement is useless' and 'agreement is an excellent signal'. So "
    "this set **cannot** establish the relationship. What it can do is three things "
    "worth doing:",
    "",
    "1. Confirm the harness runs end to end and the clustering behaves.",
    "2. Show the *direction*, which is worth a bigger experiment if it is the "
    "expected one and worth investigating immediately if it is not.",
    "3. Cost the real experiment: at "
    f"{N_SAMPLES} samples per item, a set large enough to separate the buckets "
    f"(roughly 30 items per bucket, so ~90 items) is {90 * N_SAMPLES} requests.",
    "",
    "## Conclusion, stated with its uncertainty",
    "",
    "See the model answer in the notebook. In one line: the direction is the expected "
    "one, the sample cannot establish it, and the mechanism means agreement is a "
    "measure of the model's *stability*, not of its correctness — which is why the "
    "relationship is real but weaker than people assume.",
]
consistency_path = OUTPUT_DIR / "consistency_report.md"
consistency_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {consistency_path}")
print()
print("\\n".join(lines[8:22]))
''')

nb.model_answer(
    "**Does agreement predict correctness?**\n\n"
    "Position: **weakly yes, for a reason that also tells you exactly when it will fail** "
    "— and this twelve-item set cannot establish it either way.\n\n"
    "*The mechanism.* Sampling at temperature 0.8 explores the model's output "
    "distribution. High agreement means that distribution is sharply peaked: the model is "
    "*stable* on this question. Stability and correctness share a common cause — when the "
    "evidence in the image is unambiguous, the posterior is sharp and the sharp mode is "
    "usually the true one — which is why a positive relationship exists at all. But they "
    "are not the same thing, and the divergence is systematic rather than random. A model "
    "with a confident wrong prior produces 8/8 agreement on a wrong answer. That is "
    "exactly the ghost-mug case from earlier in this lesson: ask where the blue ceramic "
    "mug is and you get a consistent, detailed, unanimous, wrong location, because "
    "\"answer the question asked\" is a stable behaviour.\n\n"
    "So the honest statement is: **agreement is a measure of the model's stability, and "
    "stability correlates with correctness only where the model's failure mode is noise "
    "rather than bias.** Counting questions fail by noise, and self-consistency helps a "
    "lot. Presupposition questions fail by bias, and self-consistency helps not at all — "
    "it will confidently confirm a hallucination. This is why the labelled set above "
    "deliberately contains `p3` (a nonexistent object) alongside `n3` (a counting "
    "question): they are the two regimes, and a harness evaluated only on one of them "
    "gives a misleading verdict about the other.\n\n"
    "*The circularity in step 2, and what would break it.* Using the reasoner to cluster "
    "its own answers is circular in a specific and bounded way: a model with a systematic "
    "misconception will judge two answers that share that misconception as equivalent, "
    "collapsing what should be two clusters into one and *inflating* the agreement score "
    "on exactly the questions where agreement is least meaningful. It biases the metric in "
    "the direction that flatters it. What would break the circle: a different model as "
    "judge (cheap, and mostly sufficient); a task where equivalence is decidable "
    "mechanically — numbers, bounding-box IoU, a closed answer set — rather than "
    "semantically; or a human adjudicating a sample of the clusters to estimate the "
    "collapse rate. The token-overlap clustering used above is the cheapest version of the "
    "second option, and it is preferred here for that reason, not because it is better at "
    "paraphrase — it is demonstrably worse, as the KNOWN MISS cell shows.\n\n"
    "*What I would actually do with this.* Not use agreement as a confidence score. Use it "
    "as a **triage signal**: route low-agreement items to a human or to a more expensive "
    "check, and accept that high agreement buys you nothing on questions with a "
    "presupposition. And pair it with the groundability check from Exercise 2, which "
    "catches the failure mode agreement is blind to. Two cheap checks that fail "
    "differently beat one expensive check that fails in a way you have not characterised.\n\n"
    "*Sample size, stated plainly.* Twelve items, four per bucket. A four-item bucket "
    "scoring 3/4 has a 95% Wilson interval of about [30%, 95%]. Any conclusion drawn from "
    "that table is a conclusion drawn from noise. The table is worth producing because it "
    "proves the pipeline works and costs the real experiment; it is not worth quoting."
)

nb.extend(
    "The version worth building next scores agreement **per cluster of question type** "
    "rather than globally. Split the labelled set into presupposition questions, counting "
    "questions, and yes/no perception questions, and compute the agreement/accuracy "
    "relationship within each. The prediction from the mechanism above is that it will be "
    "strongly positive for counting, near zero for presupposition, and moderate for "
    "perception — and if it is not, the mechanism is wrong and that is a much more "
    "interesting result than a global correlation coefficient. It also needs no new "
    "infrastructure, only a `kind` field on each labelled item, which is why it is the "
    "next thing to do rather than the eventual thing."
)

nb.finish()
