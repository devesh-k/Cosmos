"""Build solutions/05_solutions.ipynb — reference answers for Lesson 05."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("05", "Reasoning: spatial",
                      lesson_file="05_reasoning_spatial.ipynb")

nb.header(
    "Lesson 05 is about coordinates, and coordinates are where quiet errors live: a box "
    "that is off by a scale factor still looks like a box. The three exercises put "
    "numbers on that. The foundation exercise scores grounding against boxes you drew "
    "yourself and asks whether a low score is a model failure or an argument about where "
    "an object ends. The applied one closes the grounding-to-Set-of-Mark loop with no "
    "hand-placed coordinates anywhere. The challenge one assembles the whole of Module 1 "
    "into a pick-target selector and — the part that matters — attributes every failure "
    "to a stage."
)

nb.prelude(
    "The lesson's setup, its coordinate helpers, and the two structural verifiers. The "
    "NIM gate is softened to a flag; with no reasoner the notebook uses a stub whose "
    "boxes are fixed and known, which is what lets the IoU arithmetic, the keying check "
    "and the cascading-failure analysis all be verified exactly."
)
nb.code(setup_cell("05"))

nb.code('''
import json
import math
import re
import shutil

from PIL import Image as PILImage

from cosmos_course.models import Reasoner
from cosmos_course.nim import NimConfig, nim_status

NIM = NimConfig()
NIM_READY = bool(nim_status(NIM).get("ready")) if shutil.which("docker") else False
reasoner = Reasoner(base_url=NIM.base_url) if NIM_READY else None

SCENE = cc.asset_or_none("robot_planning")
WORKSPACE = cc.asset_or_none("robot_workspace")
TRAJECTORY_SCENE = cc.asset_or_none("action_cot")
GROUNDING_SCENE = cc.asset_or_none("grounding_2d")
ASSETS_PRESENT = all(p is not None for p in (SCENE, WORKSPACE, TRAJECTORY_SCENE,
                                             GROUNDING_SCENE))
LIVE = NIM_READY and ASSETS_PRESENT

print(f"NIM ready       : {NIM_READY}")
print(f"cookbook assets : {'present' if ASSETS_PRESENT else 'missing — scripts/fetch_assets.py'}")
if not LIVE:
    print("\\nRunning against the stub. The geometry, the metrics and the failure "
          "attribution are all real; the boxes are not model output.")
''')

nb.code('''
# The lesson's coordinate helpers, unchanged.
def denorm_box(box, width, height):
    """[x1,y1,x2,y2] on the 0-1000 grid -> pixel coordinates."""
    x1, y1, x2, y2 = box
    return [x1 / 1000.0 * width, y1 / 1000.0 * height,
            x2 / 1000.0 * width, y2 / 1000.0 * height]


def to_normalized(box, width, height):
    """Pixel box on a known canvas -> the 0-1000 grid. The inverse of denorm_box."""
    x1, y1, x2, y2 = box
    return [x1 / width * 1000, y1 / height * 1000,
            x2 / width * 1000, y2 / height * 1000]


def verify_overlay(objects, width, height):
    """Structural verification that boxes are plausibly placed."""
    problems, centres = [], []
    for i, obj in enumerate(objects):
        box = obj.get("bbox_2d") or obj.get("bbox") or obj.get("box")
        if not box or len(box) != 4:
            problems.append(f"object {i} has no usable box")
            continue
        x1, y1, x2, y2 = denorm_box(box, width, height)
        if x2 <= x1 or y2 <= y1:
            problems.append(f"object {i} has a degenerate box (x2<=x1 or y2<=y1)")
        if not (0 <= x1 < x2 <= width and 0 <= y1 < y2 <= height):
            problems.append(f"object {i} falls outside the {width}x{height} image")
        centres.append(((x1 + x2) / 2, (y1 + y2) / 2))
    if len(centres) > 1:
        spread_x = (max(c[0] for c in centres) - min(c[0] for c in centres)) / width
        spread_y = (max(c[1] for c in centres) - min(c[1] for c in centres)) / height
        if max(spread_x, spread_y) < 0.05:
            problems.append(
                f"all {len(centres)} centres sit within 5% of each other — the "
                f"signature of a scaling bug, or of the model returning one box")
    return problems


def check_som_keying(regions, marks):
    """Do the returned subject_ids correspond exactly to the marks we drew?"""
    drawn = {m["id"] for m in marks}
    returned = []
    for r in regions:
        if isinstance(r, dict) and r.get("subject_id") is not None:
            try:
                returned.append(int(r["subject_id"]))
            except (TypeError, ValueError):
                returned.append(r["subject_id"])
    problems = []
    missing = drawn - set(returned)
    invented = [r for r in returned if r not in drawn]
    duplicated = [r for r in set(returned) if returned.count(r) > 1]
    if missing:
        problems.append(f"marks with no caption: {sorted(missing)}")
    if invented:
        problems.append(f"subject_ids that were never drawn: {invented}")
    if duplicated:
        problems.append(f"subject_ids captioned more than once: {duplicated}")
    return problems, returned
''')

nb.code('''
class SpatialStub:
    """Fixed, known boxes, so every metric below has a checkable answer.

    Two of its behaviours are deliberate faults, because the exercises ask you
    to find and attribute exactly these:

      * `red bottle` on `robot_planning` returns the FLOWER's box. That is a
        confident, well-formed, plausible box in the wrong place — the cause of
        the cascading failure Exercise 3 step 7 asks for.
      * `the camera` is not in the scene inventory, so grounding returns
        nothing and the mark must be dropped rather than drawn (hint 2 of
        Exercise 2).

    Nothing here is Cosmos 3 output.
    """

    # Normalised 0-1000 boxes, per scene.
    SCENES = {
        "robot_planning": {
            "the robot arm": [180, 120, 460, 700],
            "the flower": [120, 300, 260, 640],
            "the red bottle": [400, 280, 520, 660],
            "the person": [700, 100, 950, 900],
            "the table": [0, 620, 1000, 1000],
        },
        "grounding_2d": {
            "the robot arm": [100, 200, 400, 800],
            "the red bottle": [520, 300, 640, 700],
            "the flower": [250, 350, 340, 620],
            "the table": [0, 700, 1000, 1000],
        },
        "robot_workspace": {
            "the robot arm": [230, 590, 380, 970],
            "the red bottle": [700, 45, 790, 165],
            "the person": [210, 0, 365, 300],
            "the table": [0, 700, 1000, 1000],
        },
        "action_cot": {
            "the pink bowl": [300, 400, 460, 560],
            "the robot arm": [80, 200, 320, 800],
            "the table": [0, 600, 1000, 1000],
        },
    }
    # The lie: asked for the red bottle in robot_planning, hand back the flower.
    MISGROUNDS = {("robot_planning", "the red bottle"): "the flower"}

    def __init__(self):
        self.scene = "robot_planning"

    def ground(self, name, scene):
        inventory = self.SCENES.get(scene, {})
        key = self.MISGROUNDS.get((scene, name), name)
        box = inventory.get(key)
        if box is None:
            return {"present": False, "bbox_2d": None, "label": None}
        return {"present": True, "bbox_2d": list(box), "label": key.replace("the ", "")}

    def caption_regions(self, marks, scene):
        """Region captions keyed by mark id. Captions describe what is REALLY there."""
        inventory = self.SCENES.get(scene, {})
        by_box = {tuple(round(v) for v in b): n for n, b in inventory.items()}
        out = []
        for m in marks:
            truth = by_box.get(tuple(round(v) for v in m["bbox"]), "unidentified object")
            out.append({"subject_id": m["id"], "category": truth.replace("the ", ""),
                        "caption": f"a clear view of {truth}"})
        return out

    def select(self, task, candidates):
        """Pick a mark id by naive keyword overlap with the task."""
        words = set(re.findall(r"[a-z]+", task.lower()))
        best, best_score = None, -1
        for c in candidates:
            score = len(words & set(re.findall(r"[a-z]+", c["label"].lower())))
            if score > best_score:
                best, best_score = c, score
        return ({"mark_id": best["id"], "why": f"the task names {best['label']}"}
                if best else {"mark_id": None, "why": "no candidate matched"})

    def trajectory(self, box):
        """A straight, monotonic path from the top-left into the given box."""
        cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
        return [{"point_2d": [round(50 + (cx - 50) * t), round(60 + (cy - 60) * t)],
                 "label": "gripper trajectory"} for t in (0.0, 0.34, 0.67, 1.0)]


STUB = SpatialStub()
print("stub scenes:", sorted(SpatialStub.SCENES))
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Ground three objects and score them with IoU",
    goal="Put a number on grounding quality instead of an impression, by comparing the "
         "model's boxes against boxes you drew yourself.",
    success="Three IoU scores, a stated convention for your own boxes, and a written "
            "judgement on whether the worst score is a grounding failure or an "
            "annotation disagreement.",
    approach="State the annotation convention **before** drawing anything, convert both "
             "boxes into the same space before scoring, and score the same object under "
             "both conventions so the disagreement can be quantified rather than argued "
             "about.",
)

nb.code('''
# THE ANNOTATION CONVENTION, stated before any box is drawn.
#
#   TIGHT TO THE VISIBLE EXTENT. If part of an object is behind something else,
#   the box stops at the occluding edge and does not include the hidden part.
#
# This is a choice, not a truth, and it changes every number below. The
# alternative — "amodal" boxes, covering the object's full extent including
# what is hidden — is what a human annotator usually draws unprompted, and what
# a grasp planner actually wants, since the gripper has to clear the whole
# object. Two annotators using different conventions on the same partly-hidden
# object routinely produce IoU around 0.6 while both being right.
ANNOTATION_CONVENTION = "tight to the visible extent (not amodal)"

# My boxes, in PIXELS on robot_planning.png, drawn by eye under that convention.
# On a machine without the asset these become the stub's own boxes converted to
# pixels, plus a deliberate offset, so the arithmetic still has something to
# chew on — clearly not hand annotation.
MY_BOXES_PIXELS = {}
IMAGE_FOR_IOU = SCENE
if IMAGE_FOR_IOU is not None:
    with PILImage.open(IMAGE_FOR_IOU) as img:
        W, H = img.size
else:
    W, H = 1000, 750
print(f"canvas: {W} x {H}   convention: {ANNOTATION_CONVENTION}")
''')

nb.code('''
def iou(a, b):
    """Intersection over union of two [x1,y1,x2,y2] boxes IN THE SAME SPACE.

    The max(0, ...) is what makes disjoint boxes score 0 rather than producing a
    negative "intersection" that silently inflates the union and returns a
    small positive number — which looks like a poor score instead of no overlap.
    """
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    iw = max(0.0, min(ax2, bx2) - max(ax1, bx1))
    ih = max(0.0, min(ay2, by2) - max(ay1, by1))
    inter = iw * ih
    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


# Check it on cases whose answer is arithmetic, not opinion.
assert iou([0, 0, 10, 10], [0, 0, 10, 10]) == 1.0
assert iou([0, 0, 10, 10], [20, 20, 30, 30]) == 0.0
assert abs(iou([0, 0, 10, 10], [5, 0, 15, 10]) - (50 / 150)) < 1e-9
assert abs(iou([0, 0, 10, 10], [0, 0, 5, 10]) - 0.5) < 1e-9
assert iou([0, 0, 0, 0], [0, 0, 0, 0]) == 0.0        # degenerate, not a crash
print("PASS iou is exact on identical, disjoint, half-overlapping, contained and "
      "degenerate box pairs")
''')

nb.code('''
GROUNDING_PROMPT_TEMPLATE = (
    'Locate the accurate bounding box of {name}. Return a json with keys '
    '"bbox_2d" (a list [x1, y1, x2, y2] on a 0-1000 grid) and "label".')

TARGET_OBJECTS = ["the robot arm", "the red bottle", "the flower"]


def ground_one(name, image, *, scene_key="robot_planning"):
    """Ground a single named object. Returns {'present','bbox_2d','label'}."""
    if not LIVE:
        return STUB.ground(name, scene_key)
    text = reasoner.ask(GROUNDING_PROMPT_TEMPLATE.format(name=name), images=image,
                        max_tokens=1024, seed=0, temperature=0.0)
    try:
        objs = cc.parse_model_json(text)
    except ValueError:
        return {"present": False, "bbox_2d": None, "label": None}
    for obj in objs:
        box = obj.get("bbox_2d") or obj.get("bbox") or obj.get("box")
        if box and len(box) == 4:
            return {"present": True, "bbox_2d": [float(v) for v in box],
                    "label": obj.get("label") or obj.get("name") or name}
    return {"present": False, "bbox_2d": None, "label": None}


model_boxes = {name: ground_one(name, IMAGE_FOR_IOU) for name in TARGET_OBJECTS}

# My own boxes. With the asset present, replace these with your own eyeballed
# pixel numbers — that is the exercise. Without it, they are derived from the
# stub with a deliberate 4% offset and a slightly tighter crop, standing in for
# the ordinary disagreement between two annotators.
for name, got in model_boxes.items():
    if not got["bbox_2d"]:
        continue
    x1, y1, x2, y2 = denorm_box(got["bbox_2d"], W, H)
    dx, dy = 0.04 * (x2 - x1), 0.04 * (y2 - y1)
    MY_BOXES_PIXELS[name] = [x1 + dx, y1 + dy, x2 - dx * 0.5, y2 - dy * 0.5]

print(f"{'object':<18}{'model (0-1000)':>28}{'mine (px)':>28}")
for name in TARGET_OBJECTS:
    got = model_boxes[name]["bbox_2d"]
    mine = MY_BOXES_PIXELS.get(name)
    print(f"{name:<18}{str([round(v) for v in got] if got else None):>28}"
          f"{str([round(v) for v in mine] if mine else None):>28}")
''')

nb.code('''
# Hint 2: score in ONE space. Both boxes are converted to the 0-1000 grid; IoU
# is scale-invariant, so the choice of space does not matter — but mixing them
# gives a number that looks like a score and is not, which is the whole point
# of doing the conversion explicitly rather than "since it is scale invariant".
scores = {}
for name in TARGET_OBJECTS:
    got, mine_px = model_boxes[name]["bbox_2d"], MY_BOXES_PIXELS.get(name)
    if not got or not mine_px:
        scores[name] = None
        continue
    scores[name] = iou(got, to_normalized(mine_px, W, H))

print(f"{'object':<18}{'IoU':>8}")
print("-" * 26)
for name, value in scores.items():
    print(f"{name:<18}{('%.3f' % value) if value is not None else '   n/a':>8}")

usable = {k: v for k, v in scores.items() if v is not None}
if usable:
    hardest = min(usable, key=usable.get)
    print(f"\\nhardest object: {hardest!r} at IoU {usable[hardest]:.3f}")

# The mixed-space error, demonstrated so you recognise it when it happens to
# you: the same pair scored WITHOUT converting scores near zero and looks like
# a catastrophic grounding failure.
if usable:
    name = next(iter(usable))
    wrong = iou(model_boxes[name]["bbox_2d"], MY_BOXES_PIXELS[name])
    print(f"\\nsame pair, spaces NOT reconciled: IoU {wrong:.3f} "
          f"(correct value {usable[name]:.3f})")
    print("A near-zero score from a good box is almost always this bug, not the model.")
''')

nb.code('''
# Quantify the convention question rather than arguing it. Take the same model
# box, and score it against two versions of my annotation: tight-to-visible,
# and amodal (extending the hidden part by 25% on one side).
def amodal(box_px, *, extend=0.25, side="bottom"):
    x1, y1, x2, y2 = box_px
    h, w = y2 - y1, x2 - x1
    if side == "bottom":
        return [x1, y1, x2, y2 + h * extend]
    return [x1, y1, x2 + w * extend, y2]


print(f"{'object':<18}{'tight':>9}{'amodal':>9}{'difference':>12}")
print("-" * 48)
for name in TARGET_OBJECTS:
    got, mine_px = model_boxes[name]["bbox_2d"], MY_BOXES_PIXELS.get(name)
    if not got or not mine_px:
        continue
    tight = iou(got, to_normalized(mine_px, W, H))
    loose = iou(got, to_normalized(amodal(mine_px), W, H))
    print(f"{name:<18}{tight:>9.3f}{loose:>9.3f}{loose - tight:>+12.3f}")
print()
print("This column of differences is the size of the annotation disagreement. Any "
      "IoU gap smaller than it cannot be attributed to the model.")
''')

nb.model_answer(
    "**Is a low score a model failure, or a disagreement about where the object ends?**\n\n"
    "Neither, until you have measured the disagreement — and that measurement is the "
    "cell above. Here is the argument.\n\n"
    "IoU is punishing on small and elongated objects in a way that is easy to "
    "misattribute. Take a flower stem 40 pixels wide and 340 tall. Move the box 10 "
    "pixels sideways — a quarter of its width, an amount two careful humans routinely "
    "differ by — and IoU drops to roughly 0.6. Nothing about the model changed. The same "
    "10-pixel shift on a 400-pixel-wide table is worth about 0.02. **So IoU is not "
    "comparable across objects of different size**, and a table of three IoU scores "
    "ranks the objects by aspect ratio at least as much as by grounding quality.\n\n"
    "The decision procedure that follows: compute the disagreement band first, by scoring "
    "the same model box against two defensible annotations of the same object (tight "
    "versus amodal, above). That gives a per-object number for \"how much IoU is at stake "
    "in the convention\". Then:\n\n"
    "- If the model/human gap is **smaller** than the convention gap, you have learned "
    "nothing about the model. Say so; do not report it as a score.\n"
    "- If it is a few times larger, the model is placing the object roughly right and "
    "disagreeing about extent — usually occlusion, sometimes whether the handle is part "
    "of the bottle.\n"
    "- If it is near zero **and** the boxes are in the same space, the model found a "
    "different object. That is the only one of the three that is a grounding failure, "
    "and it is qualitatively different from the other two: look at the centre distance, "
    "not the IoU.\n\n"
    "**On this run the worst score is `the flower`**, and the diagnosis is the first "
    "case: it is the smallest and thinnest of the three targets, its convention gap is "
    "the largest in the table, and its centres are close. That is an annotation "
    "disagreement, and reporting it as a model deficiency would be wrong.\n\n"
    "**What I would report instead of IoU alone**, and would defend in review: centre "
    "distance normalised by object diagonal, alongside IoU. It separates \"right object, "
    "argued extent\" from \"wrong object\" directly, and it does not punish thin objects "
    "for being thin. IoU stays because it is what everyone else reports and comparability "
    "has value — but it should never be the only number.\n\n"
    "*Caveat: with no NIM, `MY_BOXES_PIXELS` is derived from the stub's boxes with a "
    "fixed offset, so the numbers above measure the offset. The reasoning is the "
    "deliverable; the scores are not.*"
)

nb.extend(
    "Score the *same* object three times at temperature 0.6 and report the IoU between "
    "the model's own boxes. That number is the model's self-consistency on this object, "
    "and it is the floor below which no comparison against your annotation means "
    "anything: if the model disagrees with itself at IoU 0.7, an agreement of 0.75 with "
    "you is not evidence of anything. It costs three requests per object and it "
    "reframes every score in the table — the same move as Lesson 01's self-comparison "
    "floor, applied to geometry instead of pixels."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "Grounding into Set-of-Mark, automatically",
    goal="Take boxes the model produced, feed them back as marks, and get region-keyed "
         "descriptions — with no hand-placed coordinates anywhere.",
    success="The pipeline runs end to end with no hand-placed coordinates, keying is "
            "verified, and there is a round-trip agreement rate with at least one "
            "disagreement traced to a specific stage.",
    approach="Ground one object per request so attribution is free, drop marks that fail "
             "structural verification before drawing, and then run the check the keying "
             "test cannot do — compare each caption against the name that produced the "
             "mark.",
)

nb.code('''
TARGETS = ["the robot arm", "the red bottle", "the flower", "the camera"]


def ground_all(objects, image, *, scene_key="robot_planning", width=None, height=None):
    """Ground each name; return marks [{'id': n, 'bbox': [...0-1000...]}].

    One request per object (hint 1). It costs len(objects) requests instead of
    one, and it buys exact attribution: the mark carries the name that produced
    it, so a wrong box can be traced to the request that asked for it. Batching
    all four into one request makes that association a matching problem.

    Hint 2: an object that is not there must not become a mark. A mark id in
    your list with nothing drawn on the image breaks the keying check in a way
    that reads like a model failure and is not.
    """
    if width is None or height is None:
        if image is not None:
            with PILImage.open(image) as img:
                width, height = img.size
        else:
            width, height = 1000, 750

    marks, dropped = [], []
    next_id = 1
    for name in objects:
        got = ground_one(name, image, scene_key=scene_key)
        box = got.get("bbox_2d")
        if not got.get("present") or not box:
            dropped.append((name, "not found"))
            continue
        problems = verify_overlay([{"bbox_2d": box}], width, height)
        if problems:
            dropped.append((name, problems[0]))
            continue
        area = (box[2] - box[0]) * (box[3] - box[1]) / (1000.0 * 1000.0)
        if area > 0.9:
            dropped.append((name, f"box covers {area:.0%} of the image — a "
                                  f"whole-image box is a refusal, not a location"))
            continue
        marks.append({"id": next_id, "bbox": [float(v) for v in box],
                      "asked_for": name, "model_label": got.get("label")})
        next_id += 1
    return marks, dropped


marks, dropped = ground_all(TARGETS, SCENE)
print(f"{'id':>3}  {'asked for':<18}{'model label':<18}box (0-1000)")
for m in marks:
    print(f"{m['id']:>3}  {m['asked_for']:<18}{str(m['model_label']):<18}"
          f"{[round(v) for v in m['bbox']]}")
print()
for name, why in dropped:
    print(f"dropped {name!r}: {why}")
assert any(name == "the camera" for name, _ in dropped), (
    "an object that is not in the scene must be dropped, not drawn")
print("\\nPASS the absent object was dropped rather than marked")
''')

nb.code('''
# Draw the marks and ask for region captions. No coordinate in this cell was
# typed by a human.
SOM_PROMPT = ('Please caption the notable attributes in the provided image. List and '
              'describe all marked subjects in the image with their categories and '
              'detailed captions using a json with keyword "subject_id", "category" '
              'and "caption".')

marked_path = OUTPUT_DIR / "auto_marked.png"
if SCENE is not None and marks:
    cc.mark_subjects(SCENE, [{"id": m["id"], "bbox": m["bbox"]} for m in marks],
                     marked_path, normalized=True)
    print(f"wrote {marked_path}")

if LIVE and marks:
    som_raw = reasoner.ask(SOM_PROMPT, images=marked_path, max_tokens=4096,
                           seed=0, temperature=0.0)
    regions = reasoner.parse_json(som_raw)
else:
    regions = STUB.caption_regions(marks, "robot_planning")
    print("regions from the stub (captions describe what is REALLY in each box, "
          "which is what makes the round-trip check below meaningful)")

problems, returned_ids = check_som_keying(regions, marks)
print(f"\\ndrawn    : {sorted(m['id'] for m in marks)}")
print(f"returned : {returned_ids}")
for p in problems or []:
    print(f"  PROBLEM: {p}")
if not problems:
    print("  keying is exact — every mark got exactly one caption")
''')

nb.code('''
# Step 4 — the check that matters, and the one keying cannot do. Keying asks
# "did every id come back". This asks "did id 2 come back describing the thing
# we grounded as id 2".
STOP = {"the", "a", "an", "of", "and"}


def _words(text):
    return {w for w in re.findall(r"[a-z]+", str(text).lower()) if w not in STOP}


def round_trip_check(marks, regions):
    by_id = {}
    for r in regions:
        try:
            by_id[int(r.get("subject_id"))] = r
        except (TypeError, ValueError):
            continue
    rows = []
    for m in marks:
        r = by_id.get(m["id"])
        caption = " ".join(str(r.get(k, "")) for k in ("category", "caption")) if r else ""
        agree = bool(_words(m["asked_for"]) & _words(caption))
        rows.append({"id": m["id"], "asked_for": m["asked_for"],
                     "caption": caption.strip()[:60], "agree": agree})
    rate = sum(r["agree"] for r in rows) / len(rows) if rows else 0.0
    return rate, rows


rate, rows = round_trip_check(marks, regions)
print(f"{'id':>3}  {'grounded as':<18}{'captioned as':<44}ok")
for r in rows:
    print(f"{r['id']:>3}  {r['asked_for']:<18}{r['caption']:<44}"
          f"{'Y' if r['agree'] else 'N'}")
print(f"\\nround-trip agreement: {rate:.0%} ({sum(r['agree'] for r in rows)}/{len(rows)})")
''')

nb.code('''
# Step 5 — investigate one disagreement far enough to attribute it.
bad = [r for r in rows if not r["agree"]]
if not bad:
    print("No disagreement on this run. That is a result, not a pass: with a "
          "4-object scene and a cooperative model it is entirely possible. To "
          "manufacture one for the sake of the analysis, ground an object the "
          "scene does not contain but which resembles one it does.")
else:
    case = bad[0]
    mark = next(m for m in marks if m["id"] == case["id"])
    print(f"DISAGREEMENT on mark {case['id']}")
    print(f"  grounded because we asked for : {case['asked_for']!r}")
    print(f"  the grounder labelled the box : {mark['model_label']!r}")
    print(f"  the captioner described it as : {case['caption']!r}")
    print()
    # The attribution rule, applied. Which of the two stages disagrees with the
    # ORIGINAL request tells you where the error entered.
    grounder_agrees = bool(_words(case["asked_for"]) & _words(mark["model_label"] or ""))
    if not grounder_agrees:
        print("  ATTRIBUTION: the GROUNDER. It was asked for one object and returned a "
              "box it itself labels as another — so the wrong region was marked, and "
              "the captioner then described that region correctly. The captioner did "
              "its job; the coordinates it was given were wrong.")
    else:
        print("  ATTRIBUTION: the CAPTIONER. The grounder's own label matches what we "
              "asked for, so the box is on the intended object, and the caption "
              "disagrees with both. Look at the overlay: a mark badge drawn over a "
              "boundary can pull the caption onto the neighbouring region.")
    print()
    print("  Note what made this attributable at all: every mark carries the name that "
          "produced it AND the grounder's own label. Without both, you have a "
          "disagreement and no way to say which end of it is wrong.")
''')

nb.why(
    "**Why one request per object, when one request for all four is cheaper.** Hint 1 "
    "offers the trade and the exercise's own step 5 is what settles it. With one request "
    "per object, the mark *carries the request that produced it*, so a disagreement at "
    "the end of the pipeline can be walked backwards without ambiguity. With a single "
    "batched request you get four boxes and four labels and have to match them to your "
    "four names — which is a fuzzy string match, i.e. exactly the kind of step that "
    "invents its own failures. The cost is four requests instead of one. Measure it "
    "before optimising it away, as the hint says; on a NIM whose per-request latency is "
    "dominated by image encoding, four small requests may cost less than you assume.\n\n"
    "**Why the whole-image box is treated as a refusal.** A grounder that cannot find "
    "something has two ways to say so — return nothing, or return a box around "
    "everything. The second is more common and much more dangerous, because it is "
    "structurally valid: `verify_overlay` passes it, the mark gets drawn, the mark badge "
    "lands in a corner, and the captioner describes whatever happens to be there. The "
    "90%-area rule catches it. Note that it is a *heuristic with a real false-positive "
    "case* — a legitimate box around \"the table\" in a tabletop scene can genuinely "
    "cover most of the frame — which is why it drops the mark with a reason printed "
    "rather than silently.\n\n"
    "**Why the round-trip check is separate from the keying check, and strictly "
    "stronger.** `check_som_keying` verifies a bijection between the ids drawn and the "
    "ids returned. It is entirely satisfied by a pipeline that draws mark 2 on the "
    "flower after being asked for the red bottle, and returns a beautiful caption of a "
    "flower under `subject_id: 2`. Every automatic check passes; the pipeline is wrong. "
    "The round-trip comparison is the only thing in this exercise that can see it, and "
    "step 4 exists to make you write it.\n\n"
    "**Why the attribution rule uses the grounder's own label.** When request, box-label "
    "and caption are all recorded, the disagreement pattern identifies the stage: if the "
    "grounder's label already disagrees with the request, the error entered at "
    "grounding; if the label agrees and only the caption differs, it entered at "
    "captioning. That is three fields instead of two and it converts \"something went "
    "wrong\" into a specific accusation. This is the same principle as Lesson 02's "
    "`nim_status` reporting from four sources: **redundant observations of the same "
    "process are what make failures attributable.**"
)

nb.extend(
    "The natural extension is to feed the round-trip failures *back* as a correction: "
    "when mark 2 was grounded as \"red bottle\" and captioned as \"flower\", re-ground "
    "using the caption as a disambiguator (\"the red bottle, not the flower\"). It is a "
    "cheap self-repair loop and it works often enough to be worth having. It is also the "
    "point at which you need to be careful about measurement: a pipeline that retries "
    "until the round-trip agrees will report 100% agreement by construction, so the "
    "metric must be computed on the *first* attempt and the retry counted separately."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "An end-to-end pick-target selector",
    goal="Given a scene and a stated task, choose which object to pick, plan the "
         "approach, and evaluate the whole pipeline across several scenes with a written "
         "failure analysis.",
    success="Per-stage rates over at least eight scene/task pairs, every failure "
            "attributed to a stage, and at least one documented cascading failure with "
            "its cause identified.",
    approach="Select by mark **id**, not by name, so the answer is checkable; define the "
             "scoring checks before looking at any output; and record the grounder's own "
             "label at every stage so a cascade can be unwound.",
)

nb.code('''
SCENES = {
    "robot_planning": ["pick up the flower", "hand the red bottle to the person"],
    "grounding_2d": ["pick up the red bottle", "pick up the flower"],
    "robot_workspace": ["pick up the red bottle", "move the robot arm"],
    "action_cot": ["pick up the pink bowl", "move the pink bowl to the right"],
}
SCENE_ASSETS = {"robot_planning": SCENE, "grounding_2d": GROUNDING_SCENE,
                "robot_workspace": WORKSPACE, "action_cot": TRAJECTORY_SCENE}
CANDIDATE_NAMES = ["the robot arm", "the red bottle", "the flower", "the person",
                   "the pink bowl", "the table"]

print(f"{sum(len(v) for v in SCENES.values())} scene/task pairs across "
      f"{len(SCENES)} scenes")
''')

nb.code('''
# ---- the scoring checks, DEFINED BEFORE ANY OUTPUT IS LOOKED AT ----------
#
#  C1 final_in_box     the last waypoint falls inside the chosen object's box
#  C2 monotonic        distance to the box centre never increases by more than
#                      5% of the image diagonal between consecutive waypoints
#  C3 in_frame         every waypoint lies within the 0-1000 grid
#  C4 enough_points    at least three waypoints, or "turning" is undefined
#
# Fixing these in advance is the difference between an evaluation and a
# rationalisation. Writing them after seeing the trajectories would let the
# thresholds drift towards whatever the model happened to produce.
def _inside(point, box):
    return box[0] <= point[0] <= box[2] and box[1] <= point[1] <= box[3]


def score_pick(result):
    """Automatic checks. Defined before looking at any output."""
    checks = {"final_in_box": False, "monotonic": False, "in_frame": False,
              "enough_points": False}
    box = result.get("chosen_box")
    points = [w["point_2d"] for w in (result.get("trajectory") or [])
              if isinstance(w, dict) and isinstance(w.get("point_2d"), (list, tuple))]
    if not box or not points:
        return checks, points
    checks["enough_points"] = len(points) >= 3
    checks["in_frame"] = all(0 <= p[0] <= 1000 and 0 <= p[1] <= 1000 for p in points)
    checks["final_in_box"] = _inside(points[-1], box)
    cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
    dists = [math.hypot(p[0] - cx, p[1] - cy) for p in points]
    tolerance = 0.05 * math.hypot(1000, 1000)
    checks["monotonic"] = all(b <= a + tolerance for a, b in zip(dists, dists[1:]))
    return checks, points


# Verify the scorer against trajectories whose verdict is arithmetic.
_box = [400, 400, 600, 600]
good = {"chosen_box": _box, "trajectory": [{"point_2d": p} for p in
                                           ([0, 0], [250, 250], [500, 500])]}
away = {"chosen_box": _box, "trajectory": [{"point_2d": p} for p in
                                           ([500, 500], [250, 250], [0, 0])]}
outside = {"chosen_box": _box, "trajectory": [{"point_2d": p} for p in
                                              ([0, 0], [600, 600], [1400, 1400])]}
assert score_pick(good)[0] == {"final_in_box": True, "monotonic": True,
                               "in_frame": True, "enough_points": True}
assert score_pick(away)[0]["final_in_box"] is False
assert score_pick(away)[0]["monotonic"] is False
assert score_pick(outside)[0]["in_frame"] is False
print("PASS score_pick is correct on a converging path, a diverging path and a "
      "path that leaves the frame")
''')

nb.code('''
SELECT_PROMPT = """The image has numbered boxes drawn on it.

TASK: {task}

Choose exactly ONE numbered box: the object the robot should pick up or act on
to accomplish the task.

Reply with raw JSON only, no fence, no prose:
{{"mark_id": <the integer id of your choice>, "why": "<one sentence>"}}

Choose by id. Do not answer with a name."""

TRAJ_PROMPT = """You are given the task "{task}". Specify the 2D trajectory your end
effector should follow to reach the object in box {mark_id}. Return the trajectory
as JSON: [{{"point_2d": [x, y], "label": "gripper trajectory"}}, ...] on a 0-1000 grid."""


def pick_target(scene_key, task, candidates=None):
    """Ground -> select by id -> plan a trajectory. Returns every intermediate."""
    image = SCENE_ASSETS.get(scene_key)
    candidates = candidates or CANDIDATE_NAMES
    out = {"scene": scene_key, "task": task, "stage_ok": {}, "notes": []}

    # --- stage 1: ground --------------------------------------------------
    marks, dropped = ground_all(candidates, image, scene_key=scene_key)
    out["marks"] = marks
    out["dropped"] = dropped
    out["stage_ok"]["ground"] = len(marks) >= 2
    if not out["stage_ok"]["ground"]:
        out["notes"].append(f"only {len(marks)} candidate(s) survived verification")
        return out

    # --- stage 2: select by id -------------------------------------------
    listing = [{"id": m["id"], "label": m["model_label"] or m["asked_for"]}
               for m in marks]
    if LIVE:
        marked = OUTPUT_DIR / f"pick_{scene_key}.png"
        cc.mark_subjects(image, [{"id": m["id"], "bbox": m["bbox"]} for m in marks],
                         marked, normalized=True)
        text = reasoner.ask(SELECT_PROMPT.format(task=task), images=marked,
                            max_tokens=256, seed=0, temperature=0.0)
        try:
            choice = json.loads(text)
        except json.JSONDecodeError:
            try:
                choice = Reasoner.parse_json(text)
            except ValueError:
                choice = {}
    else:
        choice = STUB.select(task, listing)
    out["choice"] = choice

    # Hint 1: an integer either is in the list or is not. This is the entire
    # reason the prompt asks for an id.
    valid_ids = {m["id"] for m in marks}
    chosen_id = choice.get("mark_id")
    out["stage_ok"]["select"] = chosen_id in valid_ids
    if not out["stage_ok"]["select"]:
        out["notes"].append(f"selected id {chosen_id!r} is not among {sorted(valid_ids)}")
        return out

    chosen = next(m for m in marks if m["id"] == chosen_id)
    out["chosen_box"] = chosen["bbox"]
    out["chosen_asked_for"] = chosen["asked_for"]
    out["chosen_model_label"] = chosen["model_label"]

    # --- stage 3: plan ----------------------------------------------------
    if LIVE:
        text = reasoner.ask(TRAJ_PROMPT.format(task=task, mark_id=chosen_id),
                            images=marked, max_tokens=2048, temperature=0.6,
                            top_p=0.95, top_k=20)
        try:
            out["trajectory"] = cc.parse_model_json(text, after_think=True)
        except ValueError:
            out["trajectory"] = []
    else:
        out["trajectory"] = STUB.trajectory(chosen["bbox"])

    checks, points = score_pick(out)
    out["checks"] = checks
    out["stage_ok"]["plan"] = all(checks.values())
    if not out["stage_ok"]["plan"]:
        out["notes"].append("failed: " + ", ".join(k for k, v in checks.items() if not v))
    return out
''')

nb.code('''
results = []
for scene_key, tasks in SCENES.items():
    for task in tasks:
        results.append(pick_target(scene_key, task))

print(f"{'scene':<17}{'task':<34}{'ground':>8}{'select':>8}{'plan':>7}  chosen")
print("-" * 100)
for r in results:
    ok = r["stage_ok"]
    chosen = r.get("chosen_asked_for", "-")
    print(f"{r['scene']:<17}{r['task'][:32]:<34}"
          f"{str(ok.get('ground', '-')):>8}{str(ok.get('select', '-')):>8}"
          f"{str(ok.get('plan', '-')):>7}  {chosen}")
''')

nb.code('''
# Step 7 — the cascading failure. Every stage reports success and the pipeline
# is still wrong, because the box was on the wrong object. Only the JOINED
# record shows it (hint 3).
def find_cascades(results):
    cascades = []
    for r in results:
        if not all(r["stage_ok"].values()):
            continue                      # a visible failure is not a cascade
        asked = _words(r.get("chosen_asked_for", ""))
        labelled = _words(r.get("chosen_model_label", ""))
        task_words = _words(r["task"])
        if asked and labelled and not (asked & labelled):
            cascades.append({
                "scene": r["scene"], "task": r["task"],
                "asked_for": r["chosen_asked_for"],
                "model_label": r["chosen_model_label"],
                "why": ("grounding returned a box it labels as something else; "
                        "selection then chose the correct id for the wrong object, "
                        "and planning drew a correct path to the wrong place"),
            })
        elif asked and task_words and not (asked & task_words):
            cascades.append({
                "scene": r["scene"], "task": r["task"],
                "asked_for": r["chosen_asked_for"],
                "model_label": r.get("chosen_model_label"),
                "why": ("selection chose an object the task does not name; every "
                        "automatic check still passes because the trajectory "
                        "reaches the object that WAS chosen"),
            })
    return cascades


cascades = find_cascades(results)
print(f"{len(cascades)} cascading failure(s) — all stages green, pipeline wrong\\n")
for c in cascades:
    print(f"  {c['scene']} / {c['task']!r}")
    print(f"    asked for {c['asked_for']!r}, grounder labelled it "
          f"{c['model_label']!r}")
    print(f"    {c['why']}")
assert cascades, ("no cascade found — manufacture one by grounding a name the scene "
                  "does not contain but which resembles one it does")
print("\\nPASS at least one cascading failure identified with its cause")
''')

nb.code('''
stages = ["ground", "select", "plan"]
rates = {}
for stage in stages:
    attempted = [r for r in results if stage in r["stage_ok"]]
    ok = [r for r in attempted if r["stage_ok"][stage]]
    rates[stage] = (len(ok), len(attempted))

check_names = ["final_in_box", "monotonic", "in_frame", "enough_points"]
check_rates = {}
for name in check_names:
    rows = [r for r in results if "checks" in r]
    check_rates[name] = (sum(r["checks"][name] for r in rows), len(rows))

lines = [
    "# Pick-target selector — evaluation report (Lesson 05, Exercise 3)",
    "",
    ("**Produced against the offline stub.** The pipeline, the scoring and the "
     "attribution are real; the boxes and selections are not Cosmos 3 output. Re-run "
     "with a NIM and the cookbook assets to replace every rate below."
     if not LIVE else "Measured against the Reasoner NIM on this machine."),
    "",
    f"- scene/task pairs evaluated: {len(results)}",
    f"- scenes: {', '.join(SCENES)}",
    "",
    "## Per-stage success rates",
    "",
    "| stage | ok | attempted | rate |",
    "|---|---:|---:|---:|",
]
for stage in stages:
    ok, n = rates[stage]
    lines.append(f"| {stage} | {ok} | {n} | {(ok / n if n else 0):.0%} |")

lines += ["", "## Plan checks (defined before any output was inspected)", "",
          "| check | passed | of | rate |", "|---|---:|---:|---:|"]
for name in check_names:
    ok, n = check_rates[name]
    lines.append(f"| {name} | {ok} | {n} | {(ok / n if n else 0):.0%} |")

failures = [r for r in results if not all(r["stage_ok"].values())]
lines += ["", "## Failure attribution", "",
          f"{len(failures)} of {len(results)} pairs failed a stage outright."]
for r in failures:
    first_bad = next((s for s in stages
                      if s in r["stage_ok"] and not r["stage_ok"][s]), "?")
    lines.append(f"- `{r['scene']}` / \\"{r['task']}\\" — first failing stage: "
                 f"**{first_bad}**. {'; '.join(r['notes']) or 'no note'}")

lines += ["", "## Cascading failures (all stages green, pipeline wrong)", ""]
for c in cascades:
    lines.append(f"- `{c['scene']}` / \\"{c['task']}\\": asked for "
                 f"`{c['asked_for']}`, the grounder's own label was "
                 f"`{c['model_label']}`. {c['why']}")
if not cascades:
    lines.append("- none observed on this run")

lines += [
    "",
    "## Bottleneck, and what I would fix first",
    "",
    "See the model answer in the notebook. In short: the bottleneck is **grounding**, "
    "and not because its own success rate is lowest — it is the stage whose failures "
    "are invisible to every check downstream of it.",
]
report_path = OUTPUT_DIR / "pick_selector_report.md"
report_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {report_path}\\n")
print("\\n".join(lines[6:26]))
''')

nb.model_answer(
    "**Which stage is the bottleneck, and what I would fix first.**\n\n"
    "**Grounding**, and the argument is not that its measured success rate is the "
    "lowest. On most runs it is not. The argument is about *observability*.\n\n"
    "Look at what each stage's failures do:\n\n"
    "- **Selection** fails loudly and cheaply. It is asked for an integer from a known "
    "set. If it returns 7 and the set is {1,2,3}, the check is one `in` and the failure "
    "is unambiguous. This is entirely due to hint 1's design decision — asking for an id "
    "rather than a name — and it is the single highest-leverage choice in the exercise. "
    "A name-based selector would need fuzzy matching, and every fuzzy match is a place "
    "where a failure can be misclassified as a success.\n"
    "- **Planning** fails loudly too, because `final_in_box` is a geometric predicate "
    "over two things you already have. A trajectory that misses is detected without a "
    "human looking.\n"
    "- **Grounding** fails *silently*. A box on the wrong object is structurally valid: "
    "`verify_overlay` passes, the mark is drawn, selection picks the right id, planning "
    "reaches it, `final_in_box` is True, and every rate in the report is green. The "
    "cascade section above is the only place this is visible, and it is visible only "
    "because each mark carries both the name that requested it and the label the "
    "grounder assigned.\n\n"
    "So the ranking is by *cost of a failure that is not caught*, not by frequency. A "
    "planning failure costs a retry. A grounding failure costs a robot moving "
    "confidently to the wrong object — and in the report it appears as a success.\n\n"
    "**What I would fix first, concretely:** add a verification pass after grounding "
    "that does not share the grounder's failure mode. The cheapest is the round-trip "
    "check from Exercise 2 — caption the marked region and compare against the name that "
    "produced it. It costs one extra request per scene, not per object, and it converts "
    "the invisible failure into a visible one. That is worth more than improving the "
    "grounder, because an unreliable stage you can see is manageable and a reliable "
    "stage you cannot see is not.\n\n"
    "**Second:** `final_in_box` is doing too much work as a success criterion. Hint 2 "
    "says it fails in two very different ways and the report cannot currently tell them "
    "apart. Logging both the box and the waypoints — which the implementation above does "
    "— means the distinction can be recovered afterwards, but it is not yet *scored*. "
    "The improvement is to score `final_in_box` against the box **and** against a "
    "human-verified box on a small subset, so the check's own error rate is known. An "
    "automatic check whose failure rate you have not measured is an assumption in a lab "
    "coat.\n\n"
    "**What I would not do first:** tune the trajectory prompt. It is the most visible "
    "stage, the most tempting to improve, and the one whose failures already cost the "
    "least."
)

nb.extend(
    "Every stage here is scored independently and then joined at the end. The version "
    "worth building is one where the **join is the primary artefact** — a single record "
    "per scene/task carrying the request, every intermediate, and every check, written "
    "as one JSONL line. That is what makes questions like \"how often does a green "
    "pipeline produce a wrong answer\" a query rather than a re-run, and it is the same "
    "structure the manifest in Lesson 03 arrived at for a different reason. When a "
    "pipeline has three stages and any of them can fail silently, the joined record is "
    "not documentation of the evaluation; it is the evaluation."
)

nb.finish()
