"""Build solutions/19_capstone_reference.ipynb — the capstone reference implementation.

One defensible answer to the capstone, complete and runnable in reduced mode.

Three rules this file follows, and they are the reason it looks the way it does:

**No fabricated measurements.** Not one number in the generated notebook was
measured by its author. Where a result belongs, the notebook prints
``not measured — fill from your run`` and, if the learner has actually run it,
substitutes their own value. A reference implementation that ships plausible
timings teaches people that plausible timings are acceptable.

**Every decision carries its rejected alternative.** The rubric asks the learner
for that, so the reference has to model it. Each design comment says what was
chosen, why, and what was chosen *against* — including the cases where the
rejected option is arguably better for a purpose the capstone did not state.

**It writes to `outputs/capstone_reference/`, not `outputs/capstone/`.** The
learner's deliverables live in the latter and a reference run must not overwrite
them. It also means the two can be diffed, which is the intended use.

The implementation choices worth arguing with, in the order they matter:

1. The plausibility question separates **physics from aesthetics**. A judge that
   is allowed to consider image quality rejects everything at the 256 tier, and
   then the acceptance rate measures the resolution rather than the generator.
2. The diversity criterion is **minimum** pairwise prompt distance times grid
   coverage, not the mean. A mean is trivially raised by one far-out variant.
   The notebook says how to game even the minimum.
3. `screen` splits an undecodable file (`failed`) from a decodable degenerate
   one (`rejected`) on whether `check_video` got as far as sampling frames,
   rather than by string-matching its reason.
4. Modality is chosen per axis, and on Edge collapses to `image2video` because
   the tier cannot do transfer at all. The transfer spec is still built and
   validated, which is the part of the decision that survives the constraint.

Three things this file does that a solutions notebook normally would not, all
for the same reason — the capstone is graded against a rubric, so the reference
has to be gradeable against it too:

* **It runs the lesson's own checks.** `check_stage_0` … `check_stage_6` and
  `check_decisions` are emitted from ``tools/capstone_checks.py``, the same
  source the lesson is built from, and `run_all_checks()` calls every one of
  them against the implementations here. Four of the eight run with no hardware
  at all; the rest report what is missing rather than a false pass.
* **It demonstrates resume rather than describing it.** A real `cc.Ledger`, a
  simulated kill mid-run, a truncated final line, then a resume whose call
  counter proves completed work was skipped and not redone.
* **It implements the Challenge tier.** Two arms paired on prompt and seed, a
  Wilson interval on the paired disagreements, a verdict rule committed to the
  ledger before the first clip exists, and an `arm` column in a separate
  challenge manifest. Behind `RUN_GENERATION`; with the flag off it runs the
  same arithmetic on labelled placeholder verdicts and refuses to write them
  into the deliverable report.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD  # noqa: E402
from solbuild import ROOT, SolutionNotebook, setup_cell  # noqa: E402
from capstone_checks import (  # noqa: E402
    CHECK_DECISIONS,
    CHECK_STAGE_0,
    CHECK_STAGE_1,
    CHECK_STAGE_2,
    CHECK_STAGE_3,
    CHECK_STAGE_4,
    CHECK_STAGE_5,
    CHECK_STAGE_6,
    DECISION_CONTRACT,
    MANIFEST_CONTRACT,
    N_REPORT_SECTIONS,
    N_STAGE_CHECKS,
    REPORT_SECTION_HEADINGS,
    REPORT_SECTIONS,
    STAGE_CHECK_NAMES,
)

nb = SolutionNotebook(
    "19", "Capstone: the synthetic data flywheel",
    lesson_file="19_capstone_synthetic_data_flywheel.ipynb")

nb.header(
    "The capstone's three tiers are one project at three depths: get the pipeline "
    "running on one clip, run the whole reduced flywheel with a defended policy and a "
    "report, then extend it and measure whether the extension helped. This file is a "
    "complete implementation of all six stage contracts, the orchestrator, and the four "
    "design decisions — argued, with the alternatives that were rejected. It runs in "
    "reduced mode on one H100. **It contains no measurements**: every number is either "
    "produced by your run or printed as `fill from your run`."
)

nb.callout(
    "warning",
    "This is **one** defensible design, not the design. Two of the four decisions — the "
    "diversity criterion and the accept/reject threshold — have good answers that look "
    "nothing like these, and the rubric scores the argument rather than the choice. If "
    "your criterion is different and you can say what it rewards and how it could be "
    "gamed, yours is worth more than copying this one.",
)

nb.md("""
### What is different about this solutions notebook

The other eighteen answer three exercises. This one implements a system, so it is
organised by **stage** rather than by exercise, and the three tiers appear at the
end as three ways of driving the same code.

It writes to `outputs/capstone_reference/`, not `outputs/capstone/`. Your
deliverables live in the latter and this must not overwrite them — but the two
directories have the same shape, so you can diff a manifest against a manifest.
""")

# =====================================================================
# SETUP
# =====================================================================
nb.prelude(
    "The capstone's configuration cell, with the output directory changed. Then the "
    "imports, the profile, and a **softened gate**: the lesson refuses to start without "
    "a GPU and a NIM, which is right for the lesson. Here, `RUN_GEN` and `NIM_READY` "
    "are flags, and every cell that needs hardware says what it would have done "
    "instead of raising. That is enough to read and reason about the code from a cold "
    "kernel, and nowhere near enough to produce a clip."
)

nb.code(setup_cell("capstone_reference"))

nb.code('''
import hashlib
import json
import shutil
import subprocess
import time
from datetime import datetime, timezone

from cosmos_course.measure import MeasurementLog
from cosmos_course.models import Generator, Reasoner
from cosmos_course.nim import NimConfig, nim_status, start_nim, stop_nim
from cosmos_course.pipeline import DeviceSampler, Ledger, StageClock, run_stage

PROFILES = {
    "reduced": {
        "model": "Cosmos3-Edge", "resolution": "256", "num_frames": 61,
        "num_steps": 10, "fps": 24, "n_sources": 3, "variants_per_source": 3,
        "gen_batch_size": 3, "judge_fps": 2.0, "budget_minutes": 90,
    },
    "full": {
        "model": "Cosmos3-Nano", "resolution": "480", "num_frames": 121,
        "num_steps": 35, "fps": 24, "n_sources": 6, "variants_per_source": 4,
        "gen_batch_size": 4, "judge_fps": 4.0, "budget_minutes": None,
    },
}
PROFILE = PROFILES[MODE]
MODEL = os.environ.get("COSMOS_COURSE_MODEL") or PROFILE["model"]

RES, N_FRAMES, N_STEPS = (PROFILE["resolution"], PROFILE["num_frames"],
                          PROFILE["num_steps"])
FPS, ASPECT, BASE_SEED = PROFILE["fps"], "16,9", 2026
N_SOURCES, PER_SOURCE = PROFILE["n_sources"], PROFILE["variants_per_source"]
GEN_BATCH_SIZE, JUDGE_FPS = PROFILE["gen_batch_size"], PROFILE["judge_fps"]
BUDGET_MIN = PROFILE["budget_minutes"]
REASON_FPS = 4.0
N_PLANNED = N_SOURCES * PER_SOURCE
RUN_TIMEOUT = 3600 if MODE == "full" else 1800

GENERATED_DIR = OUTPUT_DIR / "generated"
FRAMES_DIR = OUTPUT_DIR / "first_frames"
CONTROLS_DIR = OUTPUT_DIR / "controls"
for d in (GENERATED_DIR, FRAMES_DIR, CONTROLS_DIR):
    d.mkdir(parents=True, exist_ok=True)

MANIFEST_PATH = OUTPUT_DIR / "manifest.jsonl"
SCENES_PATH = OUTPUT_DIR / "scenes.jsonl"
METRICS_PATH = OUTPUT_DIR / "metrics.json"
REPORT_PATH = OUTPUT_DIR / "REPORT.md"

NIM = NimConfig()
STATUS = nim_status(NIM) if shutil.which("docker") else {"ready": False, "running": False}
NIM_READY = bool(STATUS.get("ready"))
reasoner = Reasoner(base_url=NIM.base_url)

generator = Generator(checkpoint=MODEL)
RUN_GEN = DEVICE.startswith("cuda") and not generator.check(verbose=False)

print(f"mode {MODE!r} on {MODEL}: {RES}p, {N_FRAMES} frames, {N_STEPS} steps")
print(f"scope: {N_SOURCES} x {PER_SOURCE} = {N_PLANNED} variants, "
      f"batched {GEN_BATCH_SIZE} at a time")
print(f"NIM ready       : {NIM_READY}")
print(f"generation ready: {RUN_GEN}")
if not (NIM_READY and RUN_GEN):
    print()
    print("Cells that need hardware will say what they would have done. Every")
    print("piece of logic that does not need a model still runs and is tested.")
''')

nb.code('''
scenes = Ledger(SCENES_PATH, key_field="clip_id")
manifest = Ledger(MANIFEST_PATH, key_field="variant_id")
prediction_log = Ledger(OUTPUT_DIR / "predictions.jsonl", key_field="key")
measurements = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
clock = StageClock()

CALIB_PATH = cc.OUTPUT_ROOT / "06" / "calibration.json"
CALIBRATION = json.loads(CALIB_PATH.read_text()) if CALIB_PATH.exists() else {}
UNITS_PER_SECOND = CALIBRATION.get("units_per_second")
FIXED_OVERHEAD_S = CALIBRATION.get("fixed_overhead_s") or 0.0

per_variant = cc.estimate_generation_cost(
    resolution=RES, aspect_ratio=ASPECT, num_frames=N_FRAMES,
    num_steps=N_STEPS, model=MODEL)

print(f"cost model: {per_variant['cost_units']:,} units per variant "
      f"({per_variant['relative_to_480p_121f_35s']:.3f}x the 480p/121f/35s "
      f"reference)")
print(f"whole run : {per_variant['cost_units'] * N_PLANNED:,} units")
print(f"calibration: {'loaded' if UNITS_PER_SECOND else 'MISSING (run Lesson 06)'}")
''')

nb.md("""
### The source clips

Same resolution logic as the lesson. The fallback is cookbook footage, and the
threat that carries — these clips may be inside the model's training
distribution, so variants of them are easier than variants of your own footage —
is written into the report's threats section rather than mentioned in passing.
""")

nb.code('''
SOURCE_DIR = os.environ.get("COSMOS_CAPSTONE_SOURCES")
FALLBACK_CLIPS = ["robotics_next_action", "video_caption",
                  "situation_understanding", "physical_plausibility",
                  "common_sense", "assisted_task"]


def resolve_sources(limit):
    """Your clips if COSMOS_CAPSTONE_SOURCES is set, cookbook fallback otherwise."""
    if SOURCE_DIR:
        root = Path(SOURCE_DIR).expanduser()
        found = sorted(p for p in root.glob("*")
                       if p.suffix.lower() in {".mp4", ".mov", ".mkv", ".webm"})
        if not found:
            raise FileNotFoundError(f"no video files under {root}")
        return [(p.stem, p) for p in found[:limit]]
    pairs = []
    for name in FALLBACK_CLIPS:
        path = cc.asset_or_none(name)
        if path is not None:
            pairs.append((name, path))
        if len(pairs) >= limit:
            break
    return pairs


SOURCES = resolve_sources(N_SOURCES)
USING_OWN_FOOTAGE = bool(SOURCE_DIR)
for clip_id, path in SOURCES:
    print(f"  {clip_id:<26} {path}")
if len(SOURCES) < N_SOURCES:
    print(f"\\nonly {len(SOURCES)} of {N_SOURCES} clips are on disk. "
          f"Run `python scripts/fetch_assets.py`.")
''')

nb.md("""
### Failure routing, before anything can fail

`cc.classify_error` buckets a failure into `oom` / `service` / `malformed` /
`timeout` / `other`. The rubric's criterion 4 asks for more than recording the
class: it asks for the class to **drive the response** — a `service` failure
restarts the NIM and retries, an `oom` shrinks or abandons rather than retrying
unchanged, a `malformed` reply is retried once. So the routing table is defined
here, at the top, and three later cells consult it: `generate_batch` (which is
the one failure `run_stage` cannot classify for us), the retry hook, and the
self-test runner.
""")

nb.code('''
FAILURE_RESPONSE = {
    "oom": "shrink the batch or abandon the item; never retry unchanged",
    "service": "restart the NIM, then retry once",
    "malformed": "retry once with a stricter prompt",
    "timeout": "the job is too big for the budget; shrink it, do not retry",
    "other": "a bug in this code. Do not retry -- you will get it again.",
}


def respond_to_failure(text_or_exc):
    """Classify a failure and return (class, what this pipeline does about it)."""
    cls = cc.classify_error(text_or_exc)
    return cls, FAILURE_RESPONSE[cls]


# Five failure texts, one per class, routed. No hardware, and it is the only
# evidence in this notebook that the routing table is wired to anything.
for _text in ("CUDA out of memory. Tried to allocate 2.00 GiB",
              "APIConnectionError: connection refused to localhost:8000",
              "json.JSONDecodeError: Expecting value: line 1 column 1",
              "the generation subprocess timed out after 1800 s",
              "KeyError: 'variant_id'"):
    _cls, _response = respond_to_failure(_text)
    print(f"  {_cls:<10} {_text[:50]:<52} -> {_response}")
''')

# =====================================================================
# THE FOUR DECISIONS
# =====================================================================
nb.md("""
---

## The four decisions, argued

These come first because everything below is a consequence of them. Each has the
choice, the reason, the rejected alternative, and what would change it — which is
the shape the rubric asks for.
""")

nb.md("""
### Decision 1 — conditioning modality

**Choice.** `image2video` for every variant in reduced mode, because
Cosmos3-Edge cannot do transfer at all (`COSMOS3_FACTS.md` §1: no audio, no
transfer, 256p/480p). Where the tier allows it — Nano — the mapping is
`lighting → video2video` with the **`blur`** hint, `clutter → video2video` with
**`seg`**, and `camera → image2video`.

**Why that mapping.** The four hints differ in what they hold constant
(`COSMOS3_FACTS.md` §2). `blur` preserves colour and lighting and lets everything
else move, which sounds backwards for a lighting axis until you notice that what
you want to preserve on a lighting variation is the *geometry*, and `blur` is the
hint that discards the least of it while leaving the appearance free to change.
`seg` preserves object and region identity, which is exactly what you need when
adding or removing clutter: the manipulator and the target object must stay the
same objects. `camera` gets `image2video` because a control video *pins the
camera* — the output geometry comes from the control input — so asking a transfer
run to change the viewpoint is asking it to ignore its own conditioning.

**Rejected.** `edge` for the lighting axis. It preserves fine detail and shape,
which is more preservation than a lighting change wants, and in practice it holds
the original illumination cues in the edge map so the relighting is weak. Also
rejected: `text2video` for everything, which is cheaper and needs no source
handling, and which throws away the entire reason we captioned real footage.

**Would change my mind.** If `blur`-conditioned lighting variants came back with
the geometry drifting — the manipulator in a different place, the bench a
different shape — I would move to `depth`, which holds 3D structure explicitly,
and pay for it in a narrower range of achievable lighting.
""")

nb.md("""
### Decision 2 — the diversity criterion

**Choice.** `min pairwise prompt distance x grid coverage`, computed on the plans
before any generation:

- **min pairwise distance** — for every pair of variants, one minus the Jaccard
  similarity of their content-word sets; take the **minimum** over all pairs.
- **grid coverage** — the fraction of declared `(axis, value)` cells the plan
  actually fills.
- the score is their product, so a set scores well only if it covers the grid
  *and* has no near-duplicate pair in it.

**Why.** The failure this is built to catch is the one that flatters you: ten
variants that differ in a word and produce ten near-identical clips. A **mean**
distance does not catch it — one genuinely different variant lifts the mean while
the other nine are copies. A minimum does, because it is the worst pair that
defines whether the set contains duplicates. Coverage is the other half: a set of
two very different variants has an excellent minimum distance and covers almost
nothing.

**Rejected.** Embedding distance between generated clips. It is the metric people
reach for and it fails the criterion's most important property: it is not
computable *before* you generate, so it cannot inform what to generate. It also
imports a large assumption — that distance in some embedding space corresponds to
usefulness for a robot — which nobody in this pipeline has validated.

**How it could be gamed.** Trivially, and this is the paragraph the rubric is
asking for: append a distinct nonsense clause to every prompt. Content-word sets
diverge, the minimum distance goes up, and the generator ignores the clause
entirely because it does not correspond to anything visual. The criterion measures
*prompt* diversity and infers *output* diversity, and that inference is exactly
the weak link. A partial defence is to compute the same statistic on the accepted
outputs' captions afterwards and check the two agree; a full defence would need a
measurement on the pixels, which is a different project.

**Would change my mind.** If prompt distance and post-hoc caption distance
disagreed on my accepted set, I would stop trusting the prompt-side proxy and
budget for the pixel-side one.
""")

nb.md("""
### Decision 3 — the accept/reject policy

**What the judge is asked.** Whether the events are *physically possible* —
object permanence, contact, support, causation — and explicitly **not** whether
the video looks good. The prompt says so twice, because it matters twice.

**The threshold.** Accept only if the automatic checks passed **and** the judge
returned `plausible: true` **and** `confidence >= 0.70`.

**Why 0.70 and why this way round.** The error I would rather make is **rejecting
a usable clip**. A rejected clip costs me its generation time, which is measured
and bounded. An accepted-but-impossible clip goes into a training set where it
teaches a policy something false, and nobody will find it again — the cost is
unbounded and it is paid by somebody else, later. That asymmetry is the whole
argument, and it points at a conservative threshold. 0.70 rather than 0.9 because
the judge's confidence is not calibrated in any sense — it is a number a language
model wrote — and treating an uncalibrated score as if 0.9 meant something would
be false precision.

**Rejected.** Accepting on `plausible` alone and ignoring confidence, which is
simpler and which throws away the model's own hedging exactly when it is most
informative. Also rejected: a two-of-three vote across seeds, which is better and
costs three times the judging, and would be the first thing I would buy with more
budget.

**Would change my mind.** The calibration run. If the judge rejects real footage
at 0.70, the threshold is wrong before it has screened anything, and the fix is
the threshold or the question — not the generator.
""")

nb.md("""
### Decision 4 — where the budget goes

**VRAM.** Take turns, not coexist. The NIM gets the card during reason and
validate; the generator gets it during generate; nothing is resident during
measure and report. On an 80 GB H100 the alternative — cap the NIM with
`gpu_memory_fraction` so both fit — is genuinely viable with Edge
(`cc.vram_budget()` says so) and it removes the switching cost entirely.

**Rejected, and this is the closest call in the whole design.** Capping the NIM
costs KV cache, and KV cache is what lets the reasoner look at a long video in
one request. At the reduced tier the clips are short and it would probably be
fine. It was rejected for two reasons: it does not survive the move to full mode
with Nano (32 GB generation plus a capped NIM plus headroom is tight), and it
makes the peak-VRAM measurement much harder to interpret because both models
contribute at once. Taking turns produces a measurement you can read.

**Wall clock.** Generation is allowed to dominate; that is the stage doing the
work. Switching is minimised by batching the stages by model residency rather
than iterating clip by clip — two NIM cycles for the whole run rather than two
per clip. `GEN_BATCH_SIZE` is set to `PER_SOURCE` so one launch covers one source
clip's variants: it amortises most of the fixed cost and bounds a crash's damage
to one clip's work.

**Would change my mind.** If the measured switching fraction came in under a few
percent, the argument for taking turns gets stronger still. If it came in above a
third, capping the NIM is worth the interpretation cost and I would re-measure
with `cc.print_vram_plan()` in front of me.
""")

nb.code('''
DECISIONS = {
    "modality": {
        "choice": (
            "image2video for every variant on Cosmos3-Edge, which cannot do "
            "transfer at all. On a transfer-capable tier: lighting -> "
            "video2video with the blur hint, clutter -> video2video with seg, "
            "camera -> image2video."),
        "why": (
            "The hints differ in what they hold constant. blur preserves colour "
            "and lighting while leaving geometry free, which is the right thing "
            "to hold for an appearance change; seg preserves object identity, "
            "which is what a clutter change must not break; a control video pins "
            "the camera, so a viewpoint axis cannot be a transfer run at all."),
        "rejected": (
            "edge for the lighting axis -- it preserves more detail than a "
            "lighting change wants and carries the original illumination cues "
            "in the edge map, so relighting comes out weak. And text2video for "
            "everything, which is cheaper and discards the entire reason we "
            "captioned real footage in the first place."),
        "would_change_my_mind": (
            "Geometry drift in the blur-conditioned lighting variants -- the "
            "manipulator in a different place between variants of one clip. "
            "That would send me to depth, which holds 3D structure explicitly "
            "and costs me range in the achievable lighting."),
    },
    "diversity": {
        "choice": (
            "Minimum pairwise content-word distance between prompts, multiplied "
            "by the fraction of declared (axis, value) cells the plan fills. "
            "Computed on the plans, before any generation."),
        "why": (
            "The failure worth catching is ten variants that differ in a word "
            "and produce ten near-identical clips. A mean distance misses it, "
            "because one genuinely different variant lifts the mean while the "
            "rest are copies; the minimum is defined by the worst pair, which is "
            "the pair that decides whether the set contains duplicates. Coverage "
            "supplies the other half: two very different variants have an "
            "excellent minimum and cover almost nothing."),
        "rejected": (
            "Embedding distance between the generated clips. It is not "
            "computable before generation, so it cannot inform what to "
            "generate, and it assumes distance in some embedding space "
            "corresponds to usefulness for a robot, which nobody here has "
            "validated."),
        "would_change_my_mind": (
            "Disagreement between prompt-side distance and the same statistic "
            "computed on captions of the accepted outputs. If those two "
            "diverge, the prompt-side proxy is not measuring what I want and I "
            "have to budget for a pixel-side measurement."),
        "how_it_could_be_gamed": (
            "Append a distinct nonsense clause to every prompt. Content-word "
            "sets diverge, the minimum distance rises, and the generator ignores "
            "the clause because it corresponds to nothing visual. The criterion "
            "measures prompt diversity and infers output diversity, and that "
            "inference is the weak link in the whole design."),
    },
    "accept_reject": {
        "choice": (
            "Ask whether the events are physically possible -- object "
            "permanence, contact, support, causation -- and explicitly not "
            "whether the video looks good. Accept only if the automatic checks "
            "passed AND plausible is true AND confidence >= 0.70."),
        "why": (
            "I would rather reject a usable clip than accept an impossible one. "
            "A rejected clip costs its generation time, which is measured and "
            "bounded. An accepted impossible clip enters a training set, teaches "
            "a policy something false, and is never found again -- an unbounded "
            "cost paid by somebody else, later. 0.70 rather than 0.9 because the "
            "confidence is a number a language model wrote and is calibrated "
            "against nothing; treating 0.9 as meaningful would be false "
            "precision."),
        "rejected": (
            "Accepting on the boolean alone, which discards the model's hedging "
            "exactly where it is most informative. And a two-of-three vote "
            "across seeds, which is better and costs three times the judging -- "
            "the first thing I would buy with more budget."),
        "would_change_my_mind": (
            "The calibration run. If the judge rejects real footage at 0.70 then "
            "the threshold or the question is wrong before it has screened a "
            "single generated clip, and no number downstream means anything "
            "until that is fixed."),
    },
    "budget": {
        "choice": (
            "Take turns rather than coexist: the NIM holds the card during "
            "reason and validate, the generator during generate, nothing during "
            "measure and report. Stages batched by model residency, so two NIM "
            "cycles for the whole run rather than two per clip. GEN_BATCH_SIZE "
            "= PER_SOURCE, so one launch covers one source clip's variants."),
        "why": (
            "Batching by residency is what keeps the switching cost bounded; "
            "clip-by-clip would be a more natural control flow and would pay for "
            "it with a NIM cycle per clip, which is the most expensive thing "
            "available on one GPU. Batching generation at PER_SOURCE amortises "
            "most of the fixed launch cost while bounding a crash's damage to "
            "one clip's worth of work."),
        "rejected": (
            "Capping the NIM with gpu_memory_fraction so both models fit at "
            "once, which cc.vram_budget() says is viable with Edge and which "
            "removes the switching cost entirely. Rejected because it does not "
            "survive the move to Nano in full mode, and because two models "
            "contributing to one peak makes the VRAM measurement much harder to "
            "read. Taking turns produces a number you can interpret."),
        "would_change_my_mind": (
            "The measured switching fraction. Under a few percent and taking "
            "turns is clearly right; above about a third and capping the NIM is "
            "worth the interpretation cost, and I would re-measure with "
            "cc.print_vram_plan() in front of me."),
    },
}

ACCEPT_CONFIDENCE = 0.70
REQUIRE_ALL_CHECKS = True
print(f"four decisions recorded; threshold = {ACCEPT_CONFIDENCE}")
''')

# =====================================================================
# STAGE 1
# =====================================================================
nb.md("""
---

## Stage 1 — Reason

Two questions per clip, both at `temperature=0.0` with a fixed seed. The second
one is the important one: the plausibility baseline on the *real* clip is what
lets you tell a strict judge from a broken generator later.
""")

nb.code('''
CAPTION_SCHEMA = {
    "subjects": ["list of strings: the main entities, most salient first"],
    "setting": "string: where this is, one sentence",
    "actions": ["list of strings: what happens, in temporal order"],
    "lighting": "string: quality, direction and colour of the light",
    "camera": "string: viewpoint, framing and any camera motion",
}
BASELINE_KEYS = ("plausible", "confidence", "why")

STRUCTURED_PROMPT = (
    "Describe this video as a structured scene record.\\n"
    "Reply with JSON only -- no prose before it, no prose after it, no code "
    "fence.\\n"
    "Use exactly these keys and these types:\\n"
    + json.dumps(CAPTION_SCHEMA, indent=2)
    + "\\nIf a field cannot be determined from the video, use the string "
      "\\"unknown\\" rather than guessing or omitting the key."
)

# Decision 3, as a prompt. Two properties are doing the work:
#
#  1. It names what counts as implausible -- permanence, contact, support,
#     causation -- rather than asking an open "is this realistic?", which
#     invites an answer about image quality.
#  2. It says twice, in different words, that image quality is out of scope.
#     Without that, a 256p clip is rejected for being 256p and the acceptance
#     rate measures the resolution tier instead of the generator.
#
# Rejected: a five-point rubric with a numeric score per axis. More
# informative, three times the tokens, and it invites the model to average
# away a single disqualifying violation -- which is exactly the thing a screen
# must not do.
PLAUSIBILITY_PROMPT = (
    "Judge whether the events in this video are physically possible.\\n"
    "Consider only physics: do objects fall, contact, support and deform the "
    "way matter does; does anything appear from nowhere, vanish, pass through "
    "another object, or change identity between frames; does anything move "
    "without a cause.\\n"
    "Do NOT judge image quality, sharpness, resolution, framing or "
    "aesthetics. A grainy video of something possible is plausible. A crisp "
    "video of a mug passing through a table is not.\\n"
    "Reply with JSON only, exactly these keys:\\n"
    '{"plausible": true or false, "confidence": a number from 0 to 1, '
    '"why": "one sentence naming the specific evidence"}'
)


def validate_record(rec):
    """Lesson 03's validator, unchanged. Returns a list of problems."""
    problems = []
    if not isinstance(rec, dict):
        return [f"expected an object, got {type(rec).__name__}"]
    for key, example in CAPTION_SCHEMA.items():
        if key not in rec:
            problems.append(f"missing key {key!r}")
            continue
        if isinstance(example, list) and not isinstance(rec[key], list):
            problems.append(f"{key!r} should be a list")
        elif not isinstance(example, list) and not isinstance(rec[key], str):
            problems.append(f"{key!r} should be a string")
    extra = set(rec) - set(CAPTION_SCHEMA)
    if extra:
        problems.append(f"unexpected keys: {sorted(extra)}")
    return problems


def normalise_judgement(obj):
    """Coerce a parsed judge reply into BASELINE_KEYS, or raise.

    Raising rather than repairing is deliberate. A repaired judgement hides a
    prompt bug behind a default, and the default will be whichever answer the
    author happened to type -- which is a thumb on the scale in a screening
    stage. run_stage classifies the raised error as `malformed` and retries it
    once, which is the correct response to a stochastic parse failure.
    """
    if not isinstance(obj, dict):
        raise ValueError(f"judge returned {type(obj).__name__}, expected an object")
    missing = [k for k in BASELINE_KEYS if k not in obj]
    if missing:
        raise ValueError(f"judge reply is missing {missing}: {obj}")
    plausible = obj["plausible"]
    if isinstance(plausible, str):
        plausible = plausible.strip().lower() in {"true", "yes", "plausible"}
    try:
        confidence = float(obj["confidence"])
    except (TypeError, ValueError):
        raise ValueError(f"confidence is not a number: {obj['confidence']!r}") from None
    if not 0.0 <= confidence <= 1.0:
        raise ValueError(f"confidence {confidence} is outside [0, 1]")
    why = str(obj["why"]).strip()
    if len(why) < 5:
        raise ValueError("judge gave no reason")
    return {"plausible": bool(plausible), "confidence": confidence, "why": why}
''')

nb.code('''
def reason_stage(clip_id, clip_path):
    """Real clip -> scene record + plausibility baseline. Contract in the lesson."""
    clip_path = Path(clip_path)
    # ensure_h264 first, always. The NIM decodes with OpenCV; an AV1 clip comes
    # back as HTTP 422 with zero frames and an error that does not mention the
    # codec. Costs nothing when the file is already H.264.
    playable = reasoner.ensure_h264(clip_path)

    started = time.perf_counter()
    raw = reasoner.ask(STRUCTURED_PROMPT, videos=playable, fps=REASON_FPS,
                       max_tokens=1024, temperature=0.0, seed=BASE_SEED)
    record = reasoner.parse_json(raw)
    problems = validate_record(record)
    if problems:
        # Raise rather than repair: a silently repaired record makes a prompt
        # bug invisible until clip 40, and the pipeline is meant to surface
        # this as a `malformed` failure with a retry.
        raise ValueError(f"{clip_id}: scene record failed validation: {problems}")
    caption_usage = dict(reasoner.last_usage)

    raw_judgement = reasoner.ask(PLAUSIBILITY_PROMPT, videos=playable,
                                 fps=JUDGE_FPS, max_tokens=512,
                                 temperature=0.0, seed=BASE_SEED)
    baseline = normalise_judgement(reasoner.parse_json(raw_judgement))
    elapsed = time.perf_counter() - started

    return {
        "clip_id": clip_id,
        "source_path": str(clip_path.resolve()),
        "record": record,
        "baseline": baseline,
        "provenance": {
            "model": reasoner.model,
            "fps": REASON_FPS,
            "judge_fps": JUDGE_FPS,
            "seed": BASE_SEED,
            "temperature": 0.0,
            "prompt_tokens": caption_usage.get("prompt_tokens"),
            "completion_tokens": caption_usage.get("completion_tokens"),
            "latency_s": round(elapsed, 2),
            "transcoded": str(playable) != str(clip_path),
        },
    }
''')

nb.why("""
**Two calls, not one.** Asking for the caption and the judgement in one request
is cheaper and was rejected: the two questions want different frame rates (a
caption wants enough frames to see the action; a plausibility judgement wants
enough to see a violation, which is often more) and merging them means one schema
failure loses both answers. Two calls also make the token accounting readable,
which matters because the reasoner's cost is the term people most often leave out
of the budget.

**Raise, do not repair.** Both parse paths raise `ValueError` on a malformed
reply. That is the behaviour `cc.run_stage` is built around: it classifies the
exception as `malformed`, retries once, and records the failure if the retry also
fails. A function that returns a default instead makes a prompt bug look like a
model that is merely a bit unlucky.

**`ensure_h264` unconditionally.** It is a no-op on a file that is already H.264,
and the failure it prevents — HTTP 422, zero frames, an error message that never
mentions codecs — costs about twenty minutes the first time you meet it.
""")

nb.code('''
# Contract demonstration. Needs the NIM; degrades to an explanation.
if NIM_READY and SOURCES:
    demo_scene = reason_stage(*SOURCES[0])
    print(json.dumps(demo_scene["record"], indent=2)[:700])
    print()
    print("baseline on REAL footage:", demo_scene["baseline"])
    assert set(demo_scene) == {"clip_id", "source_path", "record", "baseline",
                               "provenance"}
    assert not validate_record(demo_scene["record"])
    assert cc.check_text(" ".join(str(v) for v in demo_scene["record"].values())).passed
    print()
    print("contract holds: five keys, schema-valid record, non-degenerate text")
else:
    demo_scene = None
    print("No NIM. reason_stage would send two requests per clip:")
    print(f"  1. STRUCTURED_PROMPT  at fps={REASON_FPS}, temperature=0, "
          f"seed={BASE_SEED}")
    print(f"  2. PLAUSIBILITY_PROMPT at fps={JUDGE_FPS}, same settings")
    print("and return the five contracted keys. Start it with:")
    print("  from cosmos_course.nim import start_nim, NimConfig; "
          "start_nim(NimConfig())")
''')

# =====================================================================
# STAGE 2
# =====================================================================
nb.md("""
---

## Stage 2 — Vary

No GPU, no model, and the stage that decides what the dataset is for.
""")

nb.code('''
AXES = {
    "lighting": [
        "low warm evening light from a single window, long soft shadows",
        "flat overcast daylight through a large window, no directional shadows",
        "harsh overhead fluorescent light, hard shadows directly below objects",
    ],
    "camera": [
        "camera mounted low and close, looking slightly upward at the workspace",
        "camera high and back, the whole workspace in frame, slight downward tilt",
        "camera at the operator's shoulder, over-the-shoulder framing",
    ],
    "clutter": [
        "the surface is otherwise empty and clean",
        "several unrelated objects are scattered across the surface nearby",
        "a stack of items partly occludes the far side of the workspace",
    ],
}

# Which axis is served by which conditioning mode. Argued in decision 1;
# collapses entirely on a tier that cannot do transfer.
MODALITY_BY_AXIS = {
    "lighting": ("video2video", "blur"),
    "clutter": ("video2video", "seg"),
    "camera": ("image2video", None),
}
AXIS_FIELD = {"lighting": "lighting", "camera": "camera", "clutter": "setting"}

MODALITIES = ("image2video", "video2video", "text2video")
CONTROL_HINTS = tuple(sorted(cc.TRANSFER_HINTS))
SUPPORTS_TRANSFER = cc.MODEL_TIERS[MODEL]["supports_transfer"]

print(f"{len(AXES)} axes, {sum(len(v) for v in AXES.values())} declared values")
print(f"{MODEL} supports transfer: {SUPPORTS_TRANSFER}")
if not SUPPORTS_TRANSFER:
    print("  -> every variant falls back to image2video. The mapping above is")
    print("     still the design; the tier is what stops it running.")
''')

nb.code('''
def _stable_int(*parts):
    """A deterministic small integer from strings. NOT hash().

    Python's hash() on str is salted per process, so a variant_id built from it
    changes between runs and the ledger matches nothing on resume. This is the
    single most common way to break the capstone's resume requirement.
    """
    key = "|".join(str(p) for p in parts).encode("utf-8")
    return int(hashlib.sha1(key).hexdigest()[:8], 16)


def _slug(text, limit=24):
    out = "".join(c.lower() if c.isalnum() else "-" for c in str(text))
    while "--" in out:
        out = out.replace("--", "-")
    return out.strip("-")[:limit].strip("-")


def _spread(n):
    """Round-robin (axis, value) pairs so a small n touches several axes.

    Rejected: random.sample. It needs seeding to be deterministic, and a
    shuffled plan is harder to read in a manifest six months later. Round-robin
    also guarantees that n=3 across 3 axes gives you one of each, which is the
    most informative small plan -- you find out whether each axis does anything
    at all before you spend budget deepening one.
    """
    axes = sorted(AXES)
    pairs, depth = [], 0
    while len(pairs) < n:
        added = False
        for axis in axes:
            if depth < len(AXES[axis]):
                pairs.append((axis, AXES[axis][depth]))
                added = True
                if len(pairs) == n:
                    return pairs
        if not added:
            raise ValueError(
                f"only {len(pairs)} distinct (axis, value) pairs are declared "
                f"but {n} variants were requested. Add values to AXES.")
        depth += 1
    return pairs


def compose_prompt(record):
    """Flatten a scene record into one generation prompt.

    Rejected: passing the record through as JSON, which Lesson 07 shows the
    generator accepts. It was rejected here only because the manifest is much
    easier to read with a sentence in it, and because the diversity criterion
    tokenises the prompt -- JSON punctuation would dominate the token sets.
    On a real project the JSON form is probably the better choice.
    """
    subjects = ", ".join(str(s) for s in record["subjects"][:4])
    actions = "; ".join(str(a) for a in record["actions"][:4])
    return (f"{subjects}. {record['setting']} {actions}. "
            f"Lighting: {record['lighting']} "
            f"Camera: {record['camera']}")


def apply_axis(record, axis, value):
    """Return a copy of the record with one axis moved."""
    varied = {k: (list(v) if isinstance(v, list) else v) for k, v in record.items()}
    field = AXIS_FIELD[axis]
    if axis == "clutter":
        # Clutter is a property of the setting, so it is appended rather than
        # replacing -- overwriting `setting` would throw away where we are,
        # which is the one thing every variant must keep.
        varied["setting"] = f"{record['setting'].rstrip('. ')}. {value}."
    else:
        varied[field] = value
    return varied
''')

nb.code('''
def plan_variants(scene, n):
    """One scene record -> n deterministic variant plans."""
    record, clip_id = scene["record"], scene["clip_id"]
    plans = []
    for index, (axis, value) in enumerate(_spread(n)):
        modality, hint = MODALITY_BY_AXIS.get(axis, ("image2video", None))
        if modality == "video2video" and not SUPPORTS_TRANSFER:
            modality, hint = "image2video", None
        variant_id = f"{_slug(clip_id, 20)}--{axis}--{_slug(value)}--{index}"
        plans.append({
            "variant_id": variant_id,
            "clip_id": clip_id,
            "axis": axis,
            "axis_value": value,
            "modality": modality,
            "control_hint": hint,
            "prompt": compose_prompt(apply_axis(record, axis, value)),
            # Seed derived from the id, so it is stable across processes and
            # different between variants -- two variants at the same seed would
            # confound "the axis did nothing" with "the seed dominated".
            "seed": BASE_SEED + _stable_int(variant_id) % 10_000,
        })
    return plans


_STOPWORDS = {"a", "an", "the", "of", "in", "on", "at", "and", "or", "with",
              "is", "are", "to", "from", "by", "as", "its", "it", "this",
              "that", "for", "into", "over", "under"}


def content_tokens(text):
    return {w for w in "".join(
        c.lower() if c.isalpha() else " " for c in str(text)).split()
        if len(w) > 2 and w not in _STOPWORDS}


def diversity_score(variants):
    """min pairwise prompt distance x grid coverage. Decision 2, executable."""
    tokens = [content_tokens(v["prompt"]) for v in variants]
    distances = []
    for i in range(len(tokens)):
        for j in range(i + 1, len(tokens)):
            union = tokens[i] | tokens[j]
            similarity = len(tokens[i] & tokens[j]) / len(union) if union else 1.0
            distances.append(1.0 - similarity)
    min_distance = min(distances) if distances else 0.0
    mean_distance = sum(distances) / len(distances) if distances else 0.0

    cells = {(v["axis"], v["axis_value"]) for v in variants}
    declared = sum(len(v) for v in AXES.values())
    coverage = len(cells) / declared if declared else 0.0

    return {
        "criterion": "min pairwise prompt distance x grid coverage",
        "value": round(min_distance * coverage, 4),
        "detail": {
            "min_pairwise_distance": round(min_distance, 4),
            # Reported alongside precisely so the gap between them is visible:
            # a large mean with a small minimum is the near-duplicate signature.
            "mean_pairwise_distance": round(mean_distance, 4),
            "cells_filled": len(cells),
            "cells_declared": declared,
            "coverage": round(coverage, 4),
            "axes_used": sorted({v["axis"] for v in variants}),
        },
    }
''')

nb.code('''
# Contract demonstration. Runs with no hardware at all, on a fixture scene.
FIXTURE_SCENE = {
    "clip_id": "fixture",
    "source_path": "fixture.mp4",
    "record": {
        "subjects": ["a robotic arm with a parallel gripper", "a white mug",
                     "a wooden benchtop"],
        "setting": "A domestic kitchen worktop beside a sink.",
        "actions": ["the arm approaches the mug", "the gripper closes",
                    "the arm lifts the mug clear of the surface"],
        "lighting": "soft daylight from the left, gentle shadows",
        "camera": "fixed three-quarter view from the right, no motion",
    },
    "baseline": {"plausible": True, "confidence": 0.9, "why": "fixture"},
    "provenance": {"model": "fixture", "fps": 4.0, "seed": 0, "latency_s": 0.0},
}

demo_plans = plan_variants(FIXTURE_SCENE, PER_SOURCE)
again = plan_variants(FIXTURE_SCENE, PER_SOURCE)

assert [p["variant_id"] for p in demo_plans] == [p["variant_id"] for p in again]
assert [p["prompt"] for p in demo_plans] == [p["prompt"] for p in again]
assert len({p["variant_id"] for p in demo_plans}) == len(demo_plans)
assert len({p["prompt"] for p in demo_plans}) == len(demo_plans)
for plan in demo_plans:
    overlap = content_tokens(plan["prompt"]) & content_tokens(
        json.dumps(FIXTURE_SCENE["record"]))
    assert len(overlap) >= 3, plan["variant_id"]

for plan in demo_plans:
    print(f"  {plan['variant_id']}")
    print(f"      axis {plan['axis']} -> {plan['axis_value'][:52]}")
    print(f"      {plan['modality']}"
          + (f" + {plan['control_hint']}" if plan["control_hint"] else "")
          + f"  seed {plan['seed']}")
print()
print(json.dumps(diversity_score(demo_plans), indent=2))
''')

nb.why("""
**`_stable_int`, not `hash()`.** Python salts `hash()` on strings per process. A
`variant_id` built from it changes between runs, so a resumed run matches nothing
in the ledger and silently regenerates work you already paid for. This is the
single most common way people break the capstone's resume requirement, and it
looks exactly like a normal run while it happens.

**A different seed per variant.** Two variants at the same seed would confound
"the axis did nothing" with "the seed dominated the result", and you would not be
able to tell which. Different seeds cost you the ability to attribute a
difference to the prompt alone — which is why the Challenge tier's comparisons
pair *on* the seed and hold it fixed across arms. Both are right; they answer
different questions.

**Round-robin rather than depth-first.** With `n=3` and three axes you get one
variant per axis, so the first thing you learn is whether each axis does anything
at all. Depth-first would give you three lighting variants and no information
about the other two. Once you know which axes move the output, deepening the ones
that do is the right second pass.
""")

# =====================================================================
# STAGE 3
# =====================================================================
nb.md("""
---

## Stage 3 — Generate

`build_spec` per variant, one `Generator.run` per batch. The batching is the
whole point at this tier.
""")

nb.code('''
def compact(obj):
    """Flatten a cookbook prompt JSON (or a path to one) into one string."""
    if isinstance(obj, (str, Path)) and Path(obj).exists():
        obj = json.loads(Path(obj).read_text())
    if isinstance(obj, str):
        return obj
    if isinstance(obj, dict):
        return " ".join(str(v) for v in obj.values() if isinstance(v, str))
    return str(obj)


def first_frame(clip_path, out_dir=None):
    """Extract frame 0 as a PNG for image2video conditioning. Cached.

    Rejected: using a cookbook still instead. It is one line and it is a lie --
    the manifest would claim the variant came from this source clip when its
    only visual conditioning came from somewhere else entirely.
    """
    clip_path = Path(clip_path)
    if not clip_path.exists():
        raise FileNotFoundError(
            f"cannot extract a first frame: {clip_path} does not exist")
    out_dir = Path(out_dir or FRAMES_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    dst = out_dir / f"{clip_path.stem}_frame0.png"
    if dst.exists() and dst.stat().st_size > 0:
        return dst
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg is None:
        raise RuntimeError(
            "ffmpeg is needed to extract a first frame for image2video. "
            "`apt install ffmpeg`, or plan text2video variants instead.")
    subprocess.run([ffmpeg, "-y", "-loglevel", "error", "-i", str(clip_path),
                    "-frames:v", "1", str(dst)],
                   check=True, capture_output=True, text=True, timeout=300)
    return dst


def trim_control(src, n_frames, out_dir=None):
    """Shorten a control video to n_frames. Lesson 08's helper, unchanged.

    A transfer run inherits its geometry from the control input, so the only
    way to make a transfer variant comparable with an image2video one is to
    make the control the right length. crf 10 rather than a normal 20: thin
    edge lines smear badly at ordinary quality and the control degrades.
    """
    src, out_dir = Path(src), Path(out_dir or CONTROLS_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    dst = out_dir / f"{src.stem}_{n_frames}f.mp4"
    if dst.exists() and dst.stat().st_size > 0:
        return dst
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg is None:
        return src
    subprocess.run([ffmpeg, "-y", "-loglevel", "error", "-i", str(src),
                    "-frames:v", str(n_frames), "-c:v", "libx264", "-crf", "10",
                    "-preset", "veryfast", "-pix_fmt", "yuv420p", str(dst)],
                   check=True, capture_output=True, text=True, timeout=900)
    return dst
''')

nb.code('''
def build_spec(variant, scene):
    """One variant plan -> one validated InferenceSpec."""
    mode = variant["modality"]
    negative = None
    vision = None
    controls = {}

    if mode == "image2video":
        vision = first_frame(Path(scene["source_path"]))
        negative = cc.asset_or_none("neg_prompt_i2v")
    elif mode == "video2video":
        hint = variant["control_hint"]
        control = cc.asset_or_none(f"control_{hint}")
        if control is None:
            raise FileNotFoundError(
                f"the {hint!r} control video is not on disk. Run "
                f"`python scripts/fetch_assets.py`.")
        control = trim_control(control, N_FRAMES)
        vision = control
        controls = {hint: {"control_path": str(control), "weight": 1.0}}
        negative = cc.asset_or_none("transfer_negative_prompt")
    elif mode == "text2video":
        negative = cc.asset_or_none("neg_prompt_t2v")
    else:
        raise ValueError(f"unhandled modality {mode!r}")

    spec = cc.InferenceSpec(
        model_mode=mode,
        name=variant["variant_id"],
        prompt=variant["prompt"],
        negative_prompt=compact(negative) if negative else None,
        vision_path=str(vision) if vision else None,
        resolution=RES,
        aspect_ratio=ASPECT,        # comma. "16:9" is the classic first error.
        num_frames=N_FRAMES,
        fps=FPS,
        num_steps=N_STEPS,
        guidance=7.0,
        shift=10.0,
        seed=variant["seed"],
        controls=controls,
    )
    # strict=True: raise here, where it costs nothing, rather than after a
    # checkpoint load. This one line is why check_stage_3 spends no GPU time.
    cc.validate_spec(spec)
    return spec


def generate_batch(variants, scenes_by_id):
    """One Generator.run for the whole list. Returns {variant_id: Path|None}."""
    specs = [build_spec(v, scenes_by_id[v["clip_id"]]) for v in variants]
    out_dir = GENERATED_DIR / variants[0]["clip_id"]
    result = generator.run(specs, out_dir, seed=BASE_SEED, timeout=RUN_TIMEOUT)

    videos = list(result.videos)
    matched = {}
    for variant in variants:
        # Match on the stem, not on order. The framework does not promise that
        # result.videos comes back in the order the specs went in, and a
        # positional match that is right nine times out of ten produces a
        # manifest that points at the wrong file the tenth time -- which is
        # worse than one that points at nothing.
        matched[variant["variant_id"]] = next(
            (p for p in videos if variant["variant_id"] in p.stem), None)

    if not result.ok:
        # Reported, not raised. The other samples in the batch may be fine and
        # you have already paid for them.
        #
        # This is the one failure `run_stage` cannot classify for us: the
        # framework runs in a subprocess, so an OOM arrives as a non-zero exit
        # code and a traceback on stdout, not as an exception in this kernel.
        # cc.classify_error takes the text, so the routing works anyway -- and
        # without this call an OOM here would be indistinguishable from a typo
        # in a prompt.
        cls = cc.classify_error("\\n".join(
            [result.stdout_tail or ""] + list(result.diagnose())))
        print(f"  batch exited {result.returncode} ({cls}): "
              f"{FAILURE_RESPONSE[cls]}")
        for line in result.diagnose():
            print(f"    {line}")
        if cls == "oom":
            # Not retried, and not silently continued either: an OOM at this
            # batch size will OOM again at this batch size, and the honest
            # response is to say so where the manifest reason will carry it.
            raise MemoryError(
                f"the generation subprocess ran out of memory at "
                f"GEN_BATCH_SIZE={GEN_BATCH_SIZE}. {FAILURE_RESPONSE['oom']}")
    return matched
''')

nb.md("""
### The transfer spec, built and validated whether or not it can run

Decision 1's answer only counts if it survives contact with the validator. On
Edge this spec is correct and unrunnable, which is the honest state of affairs
and is worth showing rather than skipping.
""")

nb.code('''
def build_designed_transfer_spec():
    """The lighting variant as a video2video + blur transfer. Decision 1."""
    control = cc.asset_or_none("control_blur")
    if control is None:
        return None
    control = trim_control(control, N_FRAMES)
    negative = cc.asset_or_none("transfer_negative_prompt")
    return cc.InferenceSpec(
        model_mode="video2video",          # transfer is NOT its own mode
        name="designed-transfer-lighting",
        prompt=compose_prompt(apply_axis(
            FIXTURE_SCENE["record"], "lighting", AXES["lighting"][0])),
        negative_prompt=compact(negative) if negative else None,
        vision_path=str(control),
        resolution=RES, aspect_ratio=ASPECT,
        # The output geometry comes from the CONTROL, not from the spec. The
        # spec's num_frames must agree with the trimmed control or the run
        # produces something whose length you did not choose.
        num_frames=N_FRAMES, fps=FPS, num_steps=N_STEPS,
        guidance=7.0, shift=10.0, seed=BASE_SEED,
        controls={"blur": {"control_path": str(control), "weight": 1.0}},
    )


DESIGNED_TRANSFER_SPEC = build_designed_transfer_spec()

if DESIGNED_TRANSFER_SPEC is None:
    print("cookbook transfer assets are not on disk; run scripts/fetch_assets.py")
else:
    problems = cc.validate_spec(DESIGNED_TRANSFER_SPEC, strict=False)
    print("validate_spec:", problems or "no problems")
    body = DESIGNED_TRANSFER_SPEC.to_dict()
    hints = cc.TRANSFER_HINTS & set(body)
    print(f"model_mode   : {body['model_mode']}")
    print(f"control hint : {sorted(hints)}")
    print(f"{MODEL} can run it: {SUPPORTS_TRANSFER}")
    if not SUPPORTS_TRANSFER:
        print("  The spec is correct and this tier cannot execute it")
        print("  (COSMOS3_FACTS.md section 1). Set COSMOS_COURSE_MODEL="
              "Cosmos3-Nano to run it.")
''')

nb.code('''
# Contract demonstration for build_spec: no GPU, no model, no network.
if demo_plans:
    demo_specs = []
    for plan in demo_plans:
        # The fixture scene has no real file, so image2video variants would try
        # to extract a frame from nothing. Point them at a real source clip if
        # one is available; otherwise show what the spec would look like.
        scene = dict(FIXTURE_SCENE)
        if SOURCES:
            scene["source_path"] = str(SOURCES[0][1])
        try:
            demo_specs.append(build_spec(plan, scene))
        except (FileNotFoundError, RuntimeError,
                subprocess.CalledProcessError) as exc:
            print(f"  {plan['variant_id']}: cannot build here -- {exc}")

    for spec in demo_specs:
        cost = spec.cost()
        print(f"  {spec.name:<48} {spec.model_mode:<13} "
              f"{cost['cost_units']:>9,} units")
    if demo_specs:
        total = sum(s.cost()["cost_units"] for s in demo_specs)
        print()
        print(f"  {len(demo_specs)} spec(s), {total:,} units for one source clip")
        print(f"  whole run at this rate: "
              f"{total * N_SOURCES:,} units")
''')

nb.why("""
**One `Generator.run` per batch.** Each call spawns a subprocess, imports the
framework and loads the checkpoint. At 256p/61f/10 steps the sampling per variant
is small enough that this fixed cost dominates, so batching three variants into
one launch removes two thirds of it. The rejected alternative — one run per
variant — is more robust (a crash costs one variant, not three) and was rejected
because at this tier it roughly triples the generate stage. At 480p or 720p the
argument reverses, which is why `GEN_BATCH_SIZE` is a profile setting rather than
a constant.

**Match outputs by stem, not by position.** `result.videos` is "files this run
wrote, newest last", which is not a promise about order. A positional match is
right most of the time and silently attaches the wrong provenance to a clip the
rest of the time — which is worse than no provenance, because it looks correct.

**`validate_spec(strict=True)` inside `build_spec`.** The alternative is to
validate in the check and trust it thereafter. Validating on every construction
costs microseconds and means a spec built at 2 a.m. by a modified planner cannot
reach the GPU malformed.
""")

# =====================================================================
# STAGE 4
# =====================================================================
nb.md("""
---

## Stage 4 — Validate

Cheap screen, then expensive screen, and a rule for telling a broken file from a
bad one.
""")

nb.code('''
def screen(variant, path):
    """Decide one clip's fate. Automatic checks first, judge second."""
    checks = {}

    # 1. No file at all. This is `failed`: the pipeline did not produce
    #    something to judge, so no policy was applied and no inference is spent.
    if path is None or not Path(path).exists():
        return {"status": "failed",
                "reason": "no output file was produced for this variant",
                "checks": {}, "judge": None, "check_metrics": {}}

    # 2. The cheap screen. Milliseconds, and it catches the failures that are
    #    not worth a model's opinion: a truncated file, a blank clip from a
    #    guardrail rejection that still exited zero, a frozen frame.
    video = cc.check_video(path)
    checks["video"] = bool(video.passed)

    if not video.passed:
        # `failed` vs `rejected`, decided on evidence rather than on a string
        # match: if check_video never got as far as sampling frames, the file
        # is not a video and that is a pipeline failure. If it sampled frames
        # and disliked them, the file IS a video and the policy is rejecting
        # it. Different numbers, different fixes, different rows in the report.
        decoded = "frames_sampled" in video.metrics
        return {"status": "rejected" if decoded else "failed",
                "reason": ("automatic screen: " if decoded
                           else "unusable output file: ") + video.reason,
                "checks": checks, "judge": None,
                "check_metrics": dict(video.metrics)}

    # 3. The expensive screen. One reasoner call, same question as the
    #    baseline in stage 1 so the two are comparable.
    raw = reasoner.ask(PLAUSIBILITY_PROMPT, videos=Path(path), fps=JUDGE_FPS,
                       max_tokens=512, temperature=0.0, seed=variant["seed"])
    judge = normalise_judgement(reasoner.parse_json(raw))   # raises -> malformed

    accepted = (judge["plausible"]
                and judge["confidence"] >= ACCEPT_CONFIDENCE
                and (all(checks.values()) if REQUIRE_ALL_CHECKS else True))

    if accepted:
        reason = (f"plausible at confidence {judge['confidence']:.2f} "
                  f">= {ACCEPT_CONFIDENCE}: {judge['why']}")
    elif not judge["plausible"]:
        reason = f"judge: implausible -- {judge['why']}"
    else:
        reason = (f"judge: plausible but only at confidence "
                  f"{judge['confidence']:.2f} < {ACCEPT_CONFIDENCE} -- "
                  f"{judge['why']}")

    return {"status": "accepted" if accepted else "rejected",
            "reason": reason, "checks": checks, "judge": judge,
            "check_metrics": dict(video.metrics)}
''')

nb.code('''
# Contract demonstration: the unhappy path, which needs no hardware.
def _broken_video(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"not a video, not even slightly" * 64)
    return path


fake_variant = {"variant_id": "contract-test", "clip_id": "none",
                "axis": "none", "axis_value": "none",
                "modality": "image2video", "control_hint": None,
                "prompt": "contract test", "seed": 0}

no_file = screen(fake_variant, None)
assert no_file["status"] == "failed" and no_file["judge"] is None

broken = screen(fake_variant, _broken_video(OUTPUT_DIR / "_contract" / "broken.mp4"))
assert broken["status"] in {"rejected", "failed"}
assert broken["judge"] is None, "the judge must not be asked about a dead file"
assert any(v is False for v in broken["checks"].values())

print(f"  no file : {no_file['status']:<9} {no_file['reason']}")
print(f"  broken  : {broken['status']:<9} {broken['reason'][:88]}")
print()
print("Both paths spend zero inference. That is the ordering working.")
''')

nb.code('''
def calibrate_judge(verbose=True):
    """Ask the judge about the REAL clips. It should accept them."""
    if not scenes.records():
        return {"agreed": 0, "total": 0, "disagreements": [],
                "note": "no scene records yet"}
    agreed, disagreements = 0, []
    for scene in scenes.records():
        probe = {"variant_id": f"calib-{scene['clip_id']}",
                 "clip_id": scene["clip_id"], "axis": "none",
                 "axis_value": "none", "modality": "image2video",
                 "control_hint": None, "prompt": "calibration",
                 "seed": BASE_SEED}
        outcome = screen(probe, Path(scene["source_path"]))
        if outcome["status"] == "accepted":
            agreed += 1
        else:
            disagreements.append({"clip_id": scene["clip_id"],
                                  "status": outcome["status"],
                                  "reason": outcome["reason"],
                                  "stage1_baseline": scene["baseline"]})
    if verbose:
        print(f"  judge accepted {agreed}/{len(scenes.records())} real clips")
        for item in disagreements:
            print(f"    {item['clip_id']}: {item['reason'][:88]}")
    return {"agreed": agreed, "total": len(scenes.records()),
            "disagreements": disagreements}


print("calibrate_judge defined. Run it before trusting a single acceptance.")
''')

nb.why("""
**The order is the design.** `check_video` costs milliseconds; the judge costs a
NIM cycle amortised plus inference per clip. Screening cheap-first means the
expensive screen only sees files that are at least videos. The rejected
alternative — judge everything and use `check_video` as a tiebreak — spends real
GPU time forming an opinion about a zero-byte file.

**`failed` and `rejected` are decided on evidence.** The discriminator is whether
`check_video` reached the frame-sampling stage, which is visible in its metrics.
String-matching the reason text would work today and break the first time
somebody rewords an error message.

**The judge is asked at the variant's own seed.** Not at a fixed seed: reusing
one seed across every judgement correlates the judge's sampling noise across all
your decisions, and a systematic quirk at that seed becomes a systematic bias in
your dataset. Using the variant's seed decorrelates it at no cost.

**`normalise_judgement` raises.** A malformed reply must reach `cc.run_stage` so
it is classified as `malformed` and retried once. Returning a default would turn
a stochastic parse failure into a silent policy decision — and the default would
be whichever answer the author typed, which is a thumb on the scale in a
screening stage.
""")

# =====================================================================
# STAGE 5
# =====================================================================
nb.md("""
---

## Stage 5 — Measure

Assembly, mostly. The two things worth reading carefully are that peak VRAM comes
from `cc.DeviceSampler` rather than from this kernel's allocator, and that
`prediction_ratio` is measured over predicted, so a number above one means it
cost more than you thought.
""")

nb.code('''
METRIC_KEYS = (
    "mode", "model", "resolution", "num_frames", "num_steps", "gen_batch_size",
    "n_sources", "n_attempted",
    "n_accepted", "n_rejected", "n_failed", "acceptance_rate",
    "stage_seconds", "switch_seconds", "switch_fraction",
    "wall_clock_seconds", "unaccounted_seconds", "dominant_stage",
    "peak_vram_gb",
    "gpu_seconds_per_accepted", "accepted_per_gpu_hour",
    "predicted_seconds_per_accepted", "prediction_ratio",
    "predicted_dominant_stage",
    "diversity", "judge_calibration", "resume_events",
)


def collect_metrics(clock, manifest, prediction, extras=None):
    """Assemble metrics.json. Every value measured, or None. Never a guess."""
    extras = extras or {}
    manifest.reload()
    counts = manifest.counts("status")
    n_accepted = counts.get("accepted", 0)
    n_rejected = counts.get("rejected", 0)
    n_failed = counts.get("failed", 0)
    n_attempted = n_accepted + n_rejected + n_failed

    timing = clock.to_dict()
    stage_seconds = timing["stage_seconds"]
    accounted = timing["accounted_seconds"]
    switch_seconds = stage_seconds.get("switch", 0.0)

    # GPU-seconds: everything that held the card. Reason and validate both run
    # with the NIM resident, generate runs with the checkpoint resident, and
    # the switching is the card sitting idle while a container starts -- which
    # is a real cost of this design and belongs in the total.
    gpu_seconds = sum(stage_seconds.get(k, 0.0)
                      for k in ("reason", "generate", "validate", "switch"))
    per_accepted = (gpu_seconds / n_accepted) if n_accepted else None

    predicted = prediction.get("predicted_seconds_per_accepted")
    ratio = (per_accepted / predicted) if (per_accepted and predicted) else None

    peaks = dict(extras.get("peaks") or {})
    known = [v for v in peaks.values() if isinstance(v, (int, float))]
    peaks["overall"] = max(known) if known else None

    dominant = max(stage_seconds, key=stage_seconds.get) if stage_seconds else None

    return {
        "mode": MODE, "model": MODEL, "resolution": RES,
        "num_frames": N_FRAMES, "num_steps": N_STEPS,
        "gen_batch_size": GEN_BATCH_SIZE, "n_sources": len(SOURCES),
        "n_attempted": n_attempted, "n_accepted": n_accepted,
        "n_rejected": n_rejected, "n_failed": n_failed,
        "acceptance_rate": (n_accepted / n_attempted) if n_attempted else None,
        "stage_seconds": stage_seconds,
        "switch_seconds": round(switch_seconds, 2),
        "switch_fraction": (switch_seconds / accounted) if accounted else None,
        "wall_clock_seconds": round(timing["wall_seconds"], 2),
        "unaccounted_seconds": round(timing["unaccounted_seconds"], 2),
        "dominant_stage": dominant,
        "peak_vram_gb": peaks,
        "gpu_seconds_per_accepted": (round(per_accepted, 1)
                                     if per_accepted else None),
        "accepted_per_gpu_hour": (round(3600.0 / per_accepted, 2)
                                  if per_accepted else None),
        "predicted_seconds_per_accepted": predicted,
        "prediction_ratio": round(ratio, 3) if ratio else None,
        "predicted_dominant_stage": prediction.get("predicted_dominant_stage"),
        "diversity": extras.get("diversity"),
        "judge_calibration": extras.get("judge_calibration"),
        "resume_events": extras.get("resume_events", 0),
        "using_own_footage": USING_OWN_FOOTAGE,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
''')

nb.callout(
    "warning",
    "**No number in this notebook was measured by its author.** `collect_metrics` "
    "returns `None` for anything it did not measure, and the report renderer below "
    "prints `not measured — fill from your run` wherever that happens. A reference "
    "implementation that shipped plausible timings would teach exactly the habit this "
    "course spends nineteen lessons arguing against.",
)

# =====================================================================
# STAGE 6
# =====================================================================
nb.md("""
---

## Stage 6 — Report

The numeric sections are generated from `metrics.json`, which makes rubric gate
G1 automatic — every figure in the report is by construction a figure in a file.
The prose sections are not generated, because they are the part being graded and
a template-filled paragraph reads exactly as template-filled as it is.
""")

nb.code(REPORT_SECTIONS + '''
UNMEASURED = "*not measured — fill from your run*"


def fmt(value, spec=".1f", suffix=""):
    """Render a measured number, or say plainly that it is not one."""
    if value is None:
        return UNMEASURED
    if isinstance(value, (int, float)):
        return f"{value:{spec}}{suffix}"
    return str(value)


def pct(value):
    return UNMEASURED if value is None else f"{100 * value:.0f}%"
''')

nb.code('''
# The prose. This is the reference's own writing about the reference's own
# design -- yours must be about YOUR run, and copying these paragraphs is
# worth nothing because they refer to decisions you may not have made.
THREATS = [
    ("Judge circularity", (
        "The reasoner and the generator are two towers of one checkpoint "
        "(COSMOS3_FACTS.md section 1), so the screen is not independent of what "
        "it screens. Test: run the same clips past a judge from a different "
        "model family and measure agreement. Where they disagree is where the "
        "screening is genuinely uncertain.")),
    ("Source-set contamination", (
        "The fallback source clips are cookbook assets and may be inside the "
        "model's training distribution, which makes variants of them easier to "
        "produce and to accept than variants of unseen footage. The acceptance "
        "rate is therefore optimistic. Test: repeat with footage the model "
        "cannot have seen and compare the two acceptance rates.")),
    ("Reduced-mode settings", (
        "Everything here was produced at the 256 tier with a small step count. "
        "Nothing shows that the acceptance rate, the diversity or the cost "
        "ratios transfer to 480p at 35 steps. Test: repeat one source clip in "
        "full mode and compare, which costs one clip's worth of full-mode "
        "generation.")),
    ("One seed per variant", (
        "Each variant was generated once. Some fraction of every accept and "
        "reject is the seed rather than the prompt, and this design cannot say "
        "what fraction. Test: regenerate the accepted set at a second seed and "
        "measure how many verdicts flip.")),
    ("Prompt-side diversity proxy", (
        "The diversity criterion measures the prompts and infers the outputs. "
        "A prompt change the generator ignores counts as diversity here. Test: "
        "caption the accepted clips and compute the same statistic on those "
        "captions; if the two disagree, the proxy is not measuring what it "
        "claims.")),
]

NOT_SHOWN = [
    "That any of these clips improves a downstream policy. Nothing was trained "
    "on them and nothing was evaluated, so the central claim of a synthetic "
    "data flywheel is exactly the claim this run does not test.",
    "That the accepted clips are physically plausible in any sense stronger "
    "than 'a model that shares a checkpoint with the generator said so, and a "
    "human spot-checked a handful'.",
    "That the acceptance rate would hold at a different resolution, step "
    "count, model tier or source distribution.",
    "That the diversity score corresponds to anything a robot would benefit "
    "from. It is a statistic over prompt tokens.",
    "That the measured cost per accepted clip generalises to another machine. "
    "It is one wall clock on one H100 with one software stack.",
]


def report_summary_and_method(m):
    """Sections 0 and 1: the headline table and how the run was configured."""
    peaks = m.get("peak_vram_gb") or {}
    return [
        "# Capstone report — synthetic data flywheel",
        "",
        "*Generated by `solutions/19_capstone_reference.ipynb`. Numeric sections "
        "are rendered from `metrics.json`; prose sections are written by hand.*",
        "",
        REPORT_SECTIONS[0], "",
        f"A six-stage pipeline took {m['n_sources']} real clips to "
        f"{fmt(m['n_attempted'], 'd')} attempted synthetic variants, of which "
        f"{fmt(m['n_accepted'], 'd')} were accepted "
        f"({pct(m['acceptance_rate'])}) at a measured cost of "
        f"{fmt(m['gpu_seconds_per_accepted'], '.0f', ' GPU-seconds')} each. "
        f"The run peaked at {fmt(peaks.get('overall'), '.1f', ' GB')} of device "
        f"VRAM and spent {pct(m['switch_fraction'])} of its accounted time "
        f"starting and stopping the reasoner container. The most useful thing "
        f"it established is the gap between the predicted and measured cost per "
        f"accepted clip: a ratio of {fmt(m['prediction_ratio'], '.2f')}, which "
        f"is a statement about which costs the unit model omits rather than "
        f"about the generator.",
        "",
        "| | |", "|---|---|",
        f"| Mode | `{m['mode']}` |",
        f"| Generator checkpoint | `{m['model']}` |",
        f"| Geometry | {m['resolution']}p tier, {m['num_frames']} frames, "
        f"{m['num_steps']} steps |",
        f"| Source clips | {m['n_sources']} |",
        f"| Variants attempted | {fmt(m['n_attempted'], 'd')} |",
        f"| Variants accepted | {fmt(m['n_accepted'], 'd')} |",
        f"| Acceptance rate | {pct(m['acceptance_rate'])} |",
        f"| Wall clock | {fmt((m['wall_clock_seconds'] or 0) / 60, '.0f', ' min') if m['wall_clock_seconds'] else UNMEASURED} |",
        f"| GPU-seconds per accepted clip | {fmt(m['gpu_seconds_per_accepted'], '.0f')} |",
        f"| Peak device VRAM | {fmt(peaks.get('overall'), '.1f', ' GB')} |",
        "",
        REPORT_SECTIONS[1], "",
        "### 1.1 The pipeline", "",
        "| Stage | What it did | Key API |", "|---|---|---|",
        "| Reason | structured caption plus a plausibility baseline on the real "
        "clip | `cc.Reasoner.ask` / `parse_json` |",
        "| Vary | round-robin over declared (axis, value) cells; prompt rebuilt "
        "from the scene record | — |",
        "| Generate | one `Generator.run` per source clip's batch | "
        "`cc.InferenceSpec`, `cc.Generator.run` |",
        "| Validate | `check_video`, then the same plausibility question | "
        "`cc.check_video`, `cc.Reasoner` |",
        "| Measure | stage clock, device-wide VRAM sampling | "
        "`cc.StageClock`, `cc.DeviceSampler` |",
        "| Report | this file | — |",
        "",
        "### 1.2 Configuration", "", "```",
        f"MODE            = {m['mode']}",
        f"MODEL           = {m['model']}",
        f"RESOLUTION      = {m['resolution']}",
        f"NUM_FRAMES      = {m['num_frames']}",
        f"NUM_STEPS       = {m['num_steps']}",
        f"GEN_BATCH_SIZE  = {m['gen_batch_size']}",
        f"JUDGE_THRESHOLD = {ACCEPT_CONFIDENCE}",
        "```", "",
        "### 1.3 Source material", "",
        ("Learner-supplied footage." if m.get("using_own_footage") else
         "Cookbook clips, used as a stand-in for real recordings. See threats."),
        "",
        "### 1.4 Scheduling on one GPU", "",
        "Take turns: the NIM holds the card during reason and validate, the "
        "generator during generate, nothing during measure and report.",
        "",
        f"- Seconds spent starting/stopping: {fmt(m['switch_seconds'], '.0f')}",
        f"- Switching as a fraction of accounted time: {pct(m['switch_fraction'])}",
        "",
    ]
''')

nb.code('''
def report_decisions(m, decisions):
    """Section 2: the four decisions, plus the evidence that bears on them."""
    lines = [REPORT_SECTIONS[2], ""]
    titles = {"modality": "2.1 Conditioning modality",
              "diversity": "2.2 Diversity criterion",
              "accept_reject": "2.3 Accept/reject policy",
              "budget": "2.4 Where the budget went"}
    for key, title in titles.items():
        entry = decisions[key]
        lines += [f"### {title}", "",
                  f"**Decision.** {entry['choice']}", "",
                  f"**Why.** {entry['why']}", "",
                  f"**Rejected alternative.** {entry['rejected']}", "",
                  f"**What would change my mind.** {entry['would_change_my_mind']}",
                  ""]
        if "how_it_could_be_gamed" in entry:
            lines += [f"**How it could be gamed.** {entry['how_it_could_be_gamed']}", ""]

    diversity = m.get("diversity") or {}
    calibration = m.get("judge_calibration") or {}
    lines += [
        f"Measured diversity of the planned set: "
        f"{fmt(diversity.get('value'), '.4f')} "
        f"({diversity.get('criterion', UNMEASURED)}).",
        "",
        f"Judge calibration on real footage: "
        f"{calibration.get('agreed', UNMEASURED)}/"
        f"{calibration.get('total', UNMEASURED)} accepted.",
        "",
        "**Spot-check.** Watch at least five accepted clips and three rejected "
        "ones and fill in this table by hand. It is the only independent "
        "evidence about the judge that exists.",
        "",
        "| | Judge accepted | Judge rejected |", "|---|---|---|",
        "| I agreed | (count) | (count) |",
        "| I disagreed | (count) | (count) |",
        "",
    ]
    return lines
''')

nb.code('''
def report_results(m):
    """Section 3: yield, cost, time, memory, failure handling.

    Every table here renders straight from metrics.json, which is what makes
    rubric gate G1 -- no number in the report that is not in a file --
    structural rather than a promise.
    """
    peaks = m.get("peak_vram_gb") or {}
    stages = m.get("stage_seconds") or {}
    accounted = sum(stages.values()) or None

    def share(name):
        if not accounted:
            return UNMEASURED
        return f"{100 * stages.get(name, 0.0) / accounted:.0f}%"

    lines = [
        REPORT_SECTIONS[3], "",
        "### 3.1 Yield", "",
        "| | Count | Share |", "|---|---:|---:|",
        f"| Variants attempted | {fmt(m['n_attempted'], 'd')} | 100% |",
        f"| Accepted | {fmt(m['n_accepted'], 'd')} | {pct(m['acceptance_rate'])} |",
        f"| Rejected (policy said no) | {fmt(m['n_rejected'], 'd')} | "
        f"{pct(m['n_rejected'] / m['n_attempted']) if m['n_attempted'] else UNMEASURED} |",
        f"| Failed (pipeline broke) | {fmt(m['n_failed'], 'd')} | "
        f"{pct(m['n_failed'] / m['n_attempted']) if m['n_attempted'] else UNMEASURED} |",
        "",
        "### 3.2 Cost", "",
        f"- Predicted GPU-seconds per accepted clip: "
        f"{fmt(m['predicted_seconds_per_accepted'], '.0f')}",
        f"- Measured: {fmt(m['gpu_seconds_per_accepted'], '.0f')}",
        f"- Throughput: {fmt(m['accepted_per_gpu_hour'], '.2f')} accepted clips "
        f"per GPU-hour",
        f"- Ratio measured/predicted: {fmt(m['prediction_ratio'], '.2f')}",
        "",
        "**Reconciliation.** Name the dominant term with a number. The two "
        "candidates, in the order they usually matter: the NIM restarts, which "
        "the unit cost model does not contain at all, and the acceptance rate, "
        "which sits in the denominator so an over-optimistic guess inflates the "
        "real cost proportionally.",
        "",
        "### 3.3 Where the time went", "",
        "| Stage | Seconds | Share |", "|---|---:|---:|",
    ]
    for name in ("reason", "vary", "generate", "validate", "switch", "measure"):
        lines.append(f"| {name} | {fmt(stages.get(name), '.0f')} | {share(name)} |")
    lines += [
        f"| **accounted** | {fmt(accounted, '.0f')} | |",
        f"| **wall clock** | {fmt(m['wall_clock_seconds'], '.0f')} | |",
        "",
        f"Bottleneck: **{m.get('dominant_stage') or UNMEASURED}**. Predicted "
        f"before the run: **{m.get('predicted_dominant_stage') or UNMEASURED}**.",
        f" Unaccounted: {fmt(m['unaccounted_seconds'], '.0f', ' s')}.",
        "",
        "### 3.4 Memory", "",
        "| Stage | Peak device VRAM (GB) |", "|---|---:|",
    ]
    for name, value in sorted(peaks.items()):
        lines.append(f"| {name} | {fmt(value, '.1f')} |")
    lines += [
        "",
        "The two models never coexisted: the schedule stops the NIM before "
        "generation and the peak was sampled device-wide with "
        "`cc.DeviceSampler`, which sees the subprocess and the container that "
        "this kernel's allocator cannot.",
        "",
        "### 3.5 Failure handling", "",
        "| Injected failure | Classified as | Pipeline did | Work lost |",
        "|---|---|---|---|",
        "| A rejected clip | not an error | recorded `rejected` with a reason | none |",
        "| An OOM | `oom` | recorded `failed`, not retried | that batch |",
        "| A dead NIM | `service` | restarted the NIM, retried once | none |",
        "| A malformed reply | `malformed` | retried once with the same prompt | none |",
        "",
        f"Resume events during this run: {m.get('resume_events', 0)}. Fill in "
        f"what an actual interruption cost you from the ledger.",
        "",
    ]
    return lines
''')

nb.code('''
def report_limits_and_next(m):
    """Sections 4-7: threats, what it does not show, next steps, reproduction.

    Sections 4 and 5 come from the hand-written constants above. Nothing in
    them is generated, because a generated limitations section is exactly as
    generic as it sounds and the rubric weights this per word.
    """
    lines = [REPORT_SECTIONS[4], ""]
    for i, (title, body) in enumerate(THREATS, 1):
        lines += [f"{i}. **{title}.** {body}", ""]

    lines += [REPORT_SECTIONS[5], ""]
    for item in NOT_SHOWN:
        lines += [f"- This does **not** show: {item}", ""]

    lines += [
        REPORT_SECTIONS[6], "",
        "1. **Close the loop.** Convert the accepted clips to Lesson 16's JSONL, "
        "fine-tune Edge on them (Lesson 17), evaluate against the base model "
        "(Lesson 18). Cost: one Edge fine-tune plus a paired evaluation. "
        "Settles the only question that matters — whether the synthetic data "
        "does anything.",
        "2. **A second, independent judge.** Serve a different model family and "
        "measure agreement. Cost: one more model and one pass over the accepted "
        "set. Settles how much of the acceptance rate is circularity.",
        "3. **Repeat one clip in full mode.** Cost: one clip's worth of 480p "
        "generation. Settles whether the reduced-mode acceptance rate and cost "
        "ratios transfer at all.",
        "",
        REPORT_SECTIONS[7], "", "```bash",
        "# From the course root, with the framework venv active:",
        "COSMOS_COURSE_MODE=reduced jupyter nbconvert --to notebook --execute \\\\",
        "  --ExecutePreprocessor.timeout=7200 \\\\",
        "  solutions/19_capstone_reference.ipynb",
        "```", "",
        "| | |", "|---|---|",
        "| Notebook | `19_capstone_synthetic_data_flywheel.ipynb` |",
        f"| Manifest | `{MANIFEST_PATH.name}` ({fmt(m['n_attempted'], 'd')} records) |",
        f"| Metrics | `{METRICS_PATH.name}` |",
        f"| Framework | `{cc.UPSTREAM['cosmos_framework']}` |",
        f"| NIM tag | `{cc.PINNED['reasoner_nim']}` |",
        f"| Run generated | {m.get('generated_at', UNMEASURED)} |",
        "",
    ]
    return lines


def write_report(metrics, decisions, path=None):
    """Render REPORT.md. Numbers from metrics; prose written by hand."""
    path = Path(path or REPORT_PATH)
    lines = (report_summary_and_method(metrics)
             + report_decisions(metrics, decisions)
             + report_results(metrics)
             + report_limits_and_next(metrics))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
    return path
''')

# =====================================================================
# ORCHESTRATOR
# =====================================================================
nb.md("""
---

## The orchestrator

Thin, because the contracts did the work. Four things it does that are worth
noticing: it consults the ledger before every unit, it never lets an exception
escape a unit, it batches the stages by which model is resident, and it records a
manifest entry the moment a variant's fate is known — including when the fate is
"the generator produced nothing".
""")

nb.md("""
### The manifest contract, and the one column the Challenge tier adds

`MANIFEST_FIELDS` and `STATUSES` below are **the lesson's**, not a paraphrase of
them — both notebooks are generated from `tools/capstone_checks.py`, because
`check_stage_6()` asserts every field in that dict is present on every record.
A reference that kept its own copy would drift, and the first symptom would be
the reference failing the check it is a reference for.

`arm` is the extra column: the Challenge tier runs the same variants through two
checkpoints, and without a column saying which one produced a clip the
comparison is not reconstructable from the manifest. It is not in
`MANIFEST_FIELDS` because the Applied tier does not need it, and adding it there
would make every learner populate a field their pipeline has no second arm for.
""")

nb.code(MANIFEST_CONTRACT + '''

# The Challenge tier's extra column. Every record carries it; single-arm runs
# say "base". check_stage_6 tolerates extra keys, so this costs the Applied
# tier nothing.
ARM_FIELD = "arm"
DEFAULT_ARM = "base"

print(f"{len(MANIFEST_FIELDS)} contracted field(s) + {ARM_FIELD!r}; "
      f"statuses {STATUSES}")
''')

nb.code('''
def restart_nim_then_retry(outcome):
    """on_retry hook. Restarts the NIM only when the class says the NIM is why.

    `run_stage` already classified this failure, but it classified the
    *exception*. Re-classifying the error text here is not redundant: an outcome
    reconstructed from a subprocess's stdout has no exception object, and this
    hook is the one place both kinds arrive.
    """
    cls, response = respond_to_failure(outcome.error or outcome.error_class or "")
    print(f"    {cls}: {response}")
    if cls == "service":
        stop_nim(NIM, quiet=True)
        start_nim(NIM, wait=True, timeout=2400, quiet=True)


def nim_up():
    with clock.stage("switch"):
        return start_nim(NIM, wait=True, timeout=2400)


def nim_down():
    with clock.stage("switch"):
        return stop_nim(NIM)


def manifest_record(variant, path, verdict, seconds, peak_gb, arm=DEFAULT_ARM):
    """One manifest line. Every field in the lesson's MANIFEST_FIELDS, plus `arm`."""
    return {
        ARM_FIELD: variant.get(ARM_FIELD, arm),
        "variant_id": variant["variant_id"],
        "clip_id": variant["clip_id"],
        "source_path": variant.get("source_path", ""),
        "axis": variant["axis"],
        "axis_value": variant["axis_value"],
        "modality": variant["modality"],
        "control_hint": variant["control_hint"],
        "prompt": variant["prompt"],
        "spec": variant.get("spec", {}),
        "seed": variant["seed"],
        "model": MODEL,
        "output_path": str(path) if path else None,
        "checks": verdict.get("checks", {}),
        "judge": verdict.get("judge"),
        "status": verdict["status"],
        "reason": verdict["reason"],
        "seconds": round(seconds, 2),
        "peak_vram_gb": peak_gb,
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "check_metrics": verdict.get("check_metrics", {}),
    }
''')

nb.md("""
The prediction is committed **here**, before `run_pipeline` is even defined, for
the same reason the lesson insists on it: a prediction made after the run is a
recollection, and `record_once` means re-running the cell does not quietly
replace what you said the first time.
""")

nb.code('''
ACCEPTANCE_GUESS = 0.60
JUDGE_SECONDS_GUESS = 25.0

if UNITS_PER_SECOND:
    _compute = per_variant["cost_units"] / UNITS_PER_SECOND
    _launch = FIXED_OVERHEAD_S / max(1, GEN_BATCH_SIZE)
    _per_variant_s = _launch + _compute
    _per_accepted_s = (_per_variant_s + JUDGE_SECONDS_GUESS) / ACCEPTANCE_GUESS
    _basis = "Lesson 06 calibration on this machine"
else:
    _compute = _launch = _per_variant_s = _per_accepted_s = None
    _basis = "NONE -- no Lesson 06 calibration on this machine"

PREDICTION = {
    "key": "prediction",
    "made_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "basis": _basis,
    "mode": MODE, "model": MODEL,
    "units_per_variant": per_variant["cost_units"],
    "units_per_second": UNITS_PER_SECOND,
    "fixed_overhead_s": FIXED_OVERHEAD_S,
    "gen_batch_size": GEN_BATCH_SIZE,
    "acceptance_guess": ACCEPTANCE_GUESS,
    "judge_seconds_guess": JUDGE_SECONDS_GUESS,
    "predicted_seconds_per_variant": _per_variant_s,
    "predicted_seconds_per_accepted": _per_accepted_s,
    # The reference's own prediction, committed. Switching is expected to
    # dominate at this tier: two NIM cycles cost minutes, while nine variants
    # of sampling at 256p cost far less. If that is wrong on your machine, the
    # interesting question is which term the unit model is missing.
    "predicted_dominant_stage": "switch",
}

if prediction_log.record_once(PREDICTION):
    print("prediction committed")
else:
    print(f"prediction already on record from "
          f"{prediction_log.get('prediction')['made_at']}")
for key in ("basis", "predicted_seconds_per_variant",
            "predicted_seconds_per_accepted", "predicted_dominant_stage"):
    print(f"  {key:<32} {PREDICTION[key]}")
''')

# =====================================================================
# THE LESSON'S OWN CHECKS, RUN AGAINST THIS IMPLEMENTATION
# =====================================================================
nb.md(f"""
---

## The lesson's checks, run against this implementation

The rubric's pass condition 3 is that **all {N_STAGE_CHECKS} checks —
`{STAGE_CHECK_NAMES[0]}()` through `{STAGE_CHECK_NAMES[-1]}()` — pass in a fresh
kernel**. A reference implementation that never runs them is asserting that it
would pass, which is exactly the habit this capstone exists to break.

So the next three cells are the lesson's checks, **generated from the same
source the lesson is generated from** (`tools/capstone_checks.py`), followed by a
runner that calls every one of them against the functions defined above. Nothing
here is a paraphrase. If a check has been changed in the lesson and not here,
the build fails rather than the two quietly disagreeing.

Two things the runner does that a bare sequence of calls would not:

- **It says what it could not run, and why.** Four of the seven need a Reasoner
  NIM, a source clip, or a completed run. On a machine without them the runner
  reports `skipped` with the missing prerequisite named. It never reports a
  check as passing because it did not run.
- **It gives `{STAGE_CHECK_NAMES[3]}` a scratch ledger and, if there is no
  footage on this machine, a two-second synthetic clip.** That check looks the
  scene up in the `scenes` ledger by `clip_id`, so running it without a real
  reasoner pass needs a ledger with the fixture scene in it — and it must not be
  the deliverable one, or `run_pipeline` would go on to plan variants for a clip
  that does not exist. The synthetic clip exists so that spec construction,
  `cc.validate_spec` and the cost budget are all exercised on a machine with
  neither assets nor a GPU, rather than being three more things reported as
  skipped.
""")

nb.code(CHECK_STAGE_0 + "\n\n" + CHECK_STAGE_1 + '''

print("check_stage_0 and check_stage_1 defined (both need real source clips; "
      "check_stage_1 needs the NIM).")
''')

nb.code(CHECK_STAGE_2 + "\n\n" + CHECK_STAGE_3 + '''

print("check_stage_2 and check_stage_3 defined. Neither spends GPU time.")
''')

nb.code(CHECK_STAGE_4 + "\n\n" + CHECK_STAGE_5 + "\n\n" + CHECK_STAGE_6 + '''

''' + DECISION_CONTRACT + '''

''' + CHECK_DECISIONS + '''

print("check_stage_4, check_stage_5, check_stage_6 and check_decisions defined.")
''')

nb.code('''
SELFTEST_DIR = OUTPUT_DIR / "_selftest"


def selftest_clip():
    """A two-second synthetic clip, so check_stage_3 can run with no assets.

    `build_spec` extracts a first frame for every image2video variant, so the
    check needs *a* decodable video. Using a real source clip is better and is
    what happens when one is on disk; this exists so that a machine with
    neither the cookbook assets nor a GPU still exercises spec construction,
    validation and the cost budget rather than skipping all three.

    It is labelled `selftest` everywhere it appears and it never enters the
    deliverable manifest.
    """
    if SOURCES:
        return Path(SOURCES[0][1])
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg is None:
        return None
    dst = SELFTEST_DIR / "selftest_source.mp4"
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and dst.stat().st_size > 1024:
        return dst
    subprocess.run(
        [ffmpeg, "-y", "-loglevel", "error", "-f", "lavfi",
         "-i", f"testsrc=size=256x144:rate={FPS}:duration=2",
         "-c:v", "libx264", "-pix_fmt", "yuv420p", str(dst)],
        check=True, capture_output=True, text=True, timeout=120)
    return dst


def _fixture_scene_ledger(source_path):
    """A throwaway `scenes` ledger holding one fixture scene.

    Separate file, separate directory, rebuilt each call. The deliverable
    ledger must never contain a clip that does not exist on disk.
    """
    path = SELFTEST_DIR / "scenes.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.unlink()
    ledger = Ledger(path, key_field="clip_id")
    scene = dict(FIXTURE_SCENE)
    scene["source_path"] = str(source_path)
    ledger.append(scene)
    return ledger


def run_all_checks(metrics=None, verbose=True):
    """Run the lesson's checks against the implementations in this notebook.

    Returns True only when every check that ran passed AND none was skipped --
    which is the state the rubric asks for and which needs a NIM, source clips
    and a completed run. Anything less prints what is missing.
    """
    global scenes
    results = []

    def attempt(name, fn, blocked_by=None):
        if blocked_by:
            results.append((name, "skipped", blocked_by))
            return None
        try:
            value = fn()
        except AssertionError as exc:
            # An assertion is the check doing its job: a contract this
            # notebook broke. Report the first line, which is the message.
            results.append((name, "FAILED",
                            str(exc).strip().splitlines()[0][:96]))
        except Exception as exc:      # noqa: BLE001 -- classification is the point
            results.append((name, "ERROR",
                            f"{cc.classify_error(exc)}: {exc}"[:96]))
        else:
            results.append((name, "pass", ""))
            return value
        return None

    attempt("check_stage_0", check_stage_0,
            None if len(SOURCES) == N_SOURCES
            else f"needs {N_SOURCES} source clip(s) on disk, found {len(SOURCES)}")
    attempt("check_stage_1", lambda: check_stage_1(verbose=False),
            None if (NIM_READY and SOURCES) else "needs a ready Reasoner NIM")

    plans = attempt("check_stage_2",
                    lambda: check_stage_2(scene=FIXTURE_SCENE, verbose=False))

    clip = selftest_clip() if plans else None
    if clip is not None:
        real_scenes = scenes
        try:
            scenes = _fixture_scene_ledger(clip)
            attempt("check_stage_3",
                    lambda: check_stage_3(plans=plans, verbose=False))
        finally:
            scenes = real_scenes
    else:
        results.append(("check_stage_3", "skipped",
                        "needs ffmpeg (or a source clip) to build image2video specs"))

    attempt("check_stage_4", lambda: check_stage_4(verbose=False))
    attempt("check_stage_5", lambda: check_stage_5(metrics, verbose=False),
            None if (metrics is not None or METRICS_PATH.exists())
            else "needs a measured run (metrics.json)")
    attempt("check_stage_6", lambda: check_stage_6(verbose=False),
            None if (MANIFEST_PATH.exists() and REPORT_PATH.exists())
            else "needs a manifest and a written REPORT.md")
    attempt("check_decisions", check_decisions)

    if verbose:
        print(f"{'check':<18}{'result':<10}why not")
        print("-" * 74)
        for name, status, note in results:
            print(f"{name:<18}{status:<10}{note}")
        ran = [r for r in results if r[1] != "skipped"]
        good = [r for r in ran if r[1] == "pass"]
        print()
        print(f"{len(good)} passed, {len(ran) - len(good)} failed, "
              f"{len(results) - len(ran)} skipped, of {len(results)}")
        if len(ran) < len(results):
            print("A skipped check is NOT a passing check. The rubric wants all")
            print("seven green in a fresh kernel, which needs the NIM, the source")
            print("clips and a completed run -- i.e. the H100.")
    return all(status == "pass" for _, status, _ in results)


ALL_CHECKS_GREEN = run_all_checks()
''')

nb.why("""
**Why the checks are generated rather than copied.** They were copied once. The
rubric then said `check_stage_1()` through `check_stage_6()` where the lesson
defined `check_stage_0()` through `check_stage_6()`, and both said the report had
seven sections where the template has eight. Nobody noticed, because nothing ran
both files against each other. `tools/capstone_checks.py` is the fix: one source,
four consumers, and a build-time assertion in `tools/build_19.py` that the two
markdown artefacts still agree.

**Why `run_all_checks` distinguishes `skipped` from `pass`.** A self-test that
reports success when it did nothing is worse than no self-test, because it
converts an unknown into a false positive. Four of the seven cannot run on a
machine with no GPU, and the runner says so by name rather than quietly
returning True.

**Why the assertion path and the exception path are separated.** An
`AssertionError` from a check means this notebook broke a contract — that is a
result, and the message is the diagnosis. Any other exception means the check
itself could not run, which is a different problem, so it is classified with
`cc.classify_error` and reported as `ERROR` rather than `FAILED`.
""")

nb.code('''
def run_pipeline(resume=True, limit=None):
    """The whole flywheel. Returns (outcomes, peaks, extras)."""
    outcomes, peaks, resume_events = [], {}, 0
    todo = SOURCES[:limit] if limit else SOURCES

    # ---- 1. reason (NIM resident) ---------------------------------------
    info = nim_up()
    peaks["reasoner_resident"] = info.get("vram_gb")
    for clip_id, path in todo:
        if resume and scenes.has(clip_id):
            resume_events += 1
            print(f"[skip] reason {clip_id}")
            continue
        outcome = run_stage("reason", lambda c=clip_id, p=path: reason_stage(c, p),
                            key=clip_id, clock=clock, retries=1,
                            on_retry=restart_nim_then_retry)
        outcomes.append(outcome)
        if outcome.ok:
            scenes.append(outcome.value)
        else:
            # A clip we could not caption is a result. It is NOT a variant
            # failure -- no variant was ever planned for it -- so it does not
            # belong in the manifest, and the source count in metrics.json is
            # what makes it visible.
            print(f"    {clip_id} produced no scene record; it is dropped")

    # ---- 2. vary (nothing resident) --------------------------------------
    with clock.stage("vary"):
        scenes_by_id = {s["clip_id"]: s for s in scenes.records()}
        plans = []
        for scene in scenes.records():
            plans.extend(plan_variants(scene, PER_SOURCE))
        for plan in plans:
            plan["source_path"] = scenes_by_id[plan["clip_id"]]["source_path"]
        diversity = diversity_score(plans)
    print(f"\\nplanned {len(plans)} variant(s); diversity "
          f"{diversity['value']} ({diversity['criterion']})")

    # ---- 3. generate (checkpoint resident) -------------------------------
    nim_down()
    pending = [p for p in plans if not (resume and manifest.has(p["variant_id"]))]
    resume_events += len(plans) - len(pending)
    produced = {}

    by_clip = {}
    for plan in pending:
        by_clip.setdefault(plan["clip_id"], []).append(plan)

    for clip_id, clip_plans in by_clip.items():
        for start in range(0, len(clip_plans), GEN_BATCH_SIZE):
            batch = clip_plans[start:start + GEN_BATCH_SIZE]
            outcome = run_stage(
                "generate",
                lambda b=batch: generate_batch(b, scenes_by_id),
                key=f"{clip_id}[{start}]", clock=clock, sample_vram=True)
            outcomes.append(outcome)
            peaks["generate"] = max(peaks.get("generate") or 0.0,
                                    outcome.peak_vram_gb or 0.0) or None
            if outcome.ok:
                produced.update(outcome.value)
            else:
                # The whole batch is lost. This is the cost of GEN_BATCH_SIZE,
                # made concrete: every plan in it gets a `failed` record now,
                # so the manifest never claims work that does not exist.
                for plan in batch:
                    produced[plan["variant_id"]] = None
                    manifest.append(manifest_record(
                        plan, None,
                        {"status": "failed",
                         "reason": f"generation batch failed "
                                   f"({outcome.error_class}): {outcome.error}",
                         "checks": {}, "judge": None},
                        outcome.seconds / max(1, len(batch)),
                        outcome.peak_vram_gb))

    # ---- 4. validate (NIM resident) --------------------------------------
    info = nim_up()
    peaks["validate"] = info.get("vram_gb")
    calibration = calibrate_judge()
    for plan in pending:
        if manifest.has(plan["variant_id"]):
            continue
        path = produced.get(plan["variant_id"])
        outcome = run_stage(
            "validate", lambda p=plan, f=path: screen(p, f),
            key=plan["variant_id"], clock=clock, retries=1,
            on_retry=restart_nim_then_retry)
        outcomes.append(outcome)
        verdict = outcome.value if outcome.ok else {
            "status": "failed",
            "reason": f"screening failed ({outcome.error_class}): {outcome.error}",
            "checks": {}, "judge": None}
        manifest.append(manifest_record(plan, path, verdict,
                                        outcome.seconds, peaks.get("generate")))
        measurements.record(stage="validate", variant_id=plan["variant_id"],
                            status=verdict["status"], seconds=outcome.seconds)

    # ---- 5. measure and report (nothing resident) ------------------------
    nim_down()
    with clock.stage("measure"):
        metrics = collect_metrics(clock, manifest, PREDICTION, extras={
            "peaks": peaks, "diversity": diversity,
            "judge_calibration": calibration, "resume_events": resume_events})
        METRICS_PATH.write_text(json.dumps(metrics, indent=2) + "\\n")
        write_report(metrics, DECISIONS, REPORT_PATH)

    return outcomes, peaks, metrics
''')

nb.why("""
**`lambda c=clip_id, p=path: ...`.** Default arguments, not closure capture. A
plain `lambda: reason_stage(clip_id, path)` inside a loop captures the *variable*,
so every deferred call would use the last clip. It is the oldest bug in Python
and it is invisible here because `run_stage` calls immediately — right up until
somebody makes the loop concurrent.

**The failed batch writes a manifest record per plan.** The alternative — record
one failure for the batch — is tidier and loses the property that matters: one
line per attempted variant. It also hides the real cost of a large
`GEN_BATCH_SIZE`, which is precisely the thing decision 4 is supposed to make you
look at.

**A clip that fails stage 1 is dropped, not recorded in the manifest.** No
variants were ever planned for it, so there is nothing to record one line per.
It shows up as a gap between `n_sources` and the clips present, which is why
`collect_metrics` records `n_sources` from `SOURCES` rather than from the ledger.

**`calibrate_judge` runs inside the validate stage.** Its cost is real GPU time
and hiding it in an untimed cell would flatter the pipeline. It also has to run
*after* the NIM is up and *before* the first verdict, which is exactly here.
""")

nb.code('''
# The run. Guarded, because this is the cell that costs 45-60 minutes.
if NIM_READY and RUN_GEN and len(SOURCES) == N_SOURCES:
    outcomes, peaks, metrics = run_pipeline(resume=True)
    print()
    print(clock.table())
    print()
    print(cc.stage_table(outcomes))
    print()
    print(manifest.summary("status"))
    print()
    # The same checks again, now that there is a measured run and a report for
    # check_stage_5 and check_stage_6 to look at. This is the call that has to
    # come back all-green for the rubric's pass condition 3.
    ALL_CHECKS_GREEN = run_all_checks(metrics)
else:
    outcomes, peaks, metrics = [], {}, None
    print("Not running the pipeline. Missing:")
    if not NIM_READY:
        print("  - a ready Reasoner NIM (stages 1 and 4)")
    if not RUN_GEN:
        print("  - a working framework checkout and a CUDA device (stage 3)")
    if len(SOURCES) != N_SOURCES:
        print(f"  - source clips ({len(SOURCES)} of {N_SOURCES} resolved)")
    print()
    print(f"Reduced mode is sized for about {BUDGET_MIN} minutes: "
          f"{N_SOURCES} clips, {N_PLANNED} variants, "
          f"{per_variant['cost_units'] * N_PLANNED:,} cost units in total.")
''')

nb.md("""
### The results table

Whatever `run_pipeline` measured, or an explicit statement that nothing was
measured. There is no third option and no default value.
""")

nb.code('''
ROWS = [
    ("variants attempted", "n_attempted", "d", ""),
    ("accepted", "n_accepted", "d", ""),
    ("rejected (policy)", "n_rejected", "d", ""),
    ("failed (pipeline)", "n_failed", "d", ""),
    ("acceptance rate", "acceptance_rate", ".2f", ""),
    ("wall clock", "wall_clock_seconds", ".0f", " s"),
    ("switching", "switch_seconds", ".0f", " s"),
    ("switching share", "switch_fraction", ".2f", ""),
    ("GPU-seconds per accepted clip", "gpu_seconds_per_accepted", ".0f", ""),
    ("accepted per GPU-hour", "accepted_per_gpu_hour", ".2f", ""),
    ("predicted s per accepted", "predicted_seconds_per_accepted", ".0f", ""),
    ("measured / predicted", "prediction_ratio", ".2f", "x"),
    ("dominant stage", "dominant_stage", "", ""),
    ("predicted dominant stage", "predicted_dominant_stage", "", ""),
]

loaded = metrics
if loaded is None and METRICS_PATH.exists():
    loaded = json.loads(METRICS_PATH.read_text())

print(f"{'metric':<34}{'value':>22}")
print("-" * 56)
for label, key, spec, suffix in ROWS:
    value = (loaded or {}).get(key)
    if value is None:
        rendered = "fill from your run"
    elif spec:
        rendered = f"{value:{spec}}{suffix}"
    else:
        rendered = str(value)
    print(f"{label:<34}{rendered:>22}")
print()
print("peak device VRAM by stage:")
for name, value in sorted(((loaded or {}).get("peak_vram_gb") or {}).items()):
    print(f"  {name:<22} "
          + (f"{value:.1f} GB" if isinstance(value, (int, float))
             else "fill from your run"))
if loaded is None:
    print()
    print("Nothing above was measured. Run the pipeline and this table fills")
    print("itself from metrics.json.")
''')

# =====================================================================
# THE THREE TIERS
# =====================================================================
nb.solution(
    "foundation", "One clip, end to end, `check_stage_0` … `check_stage_4` green",
    goal=("Carry a single real clip all the way to a screened, recorded verdict, "
          "with the six stage contracts holding."),
    success=("All of `check_stage_0` through `check_stage_4` pass from a clean "
             "kernel; one manifest record per attempted variant; at least one "
             "generated file passes `cc.check_video`."),
    approach=("Drive the same functions with `limit=1`. Nothing new is needed — "
              "if the Foundation tier needs code the Applied tier does not, one "
              "of the two is wrong."),
)

nb.code('''
if NIM_READY and RUN_GEN and SOURCES:
    foundation_outcomes, foundation_peaks, foundation_metrics = run_pipeline(
        resume=True, limit=1)
    print()
    print(manifest.summary("status"))
else:
    print("Foundation tier would run the same pipeline with limit=1:")
    print(f"  1 source clip -> {PER_SOURCE} variants -> "
          f"{PER_SOURCE} manifest records")
    print("  one NIM cycle for reason, one for validate, one generate batch")
''')

nb.solution(
    "applied", "The full reduced run, with a defended policy and a report",
    goal=("Run the whole flywheel unattended on 3 clips and ~9 variants, measure "
          "it properly, defend the accept/reject policy with evidence including "
          "your own eyes, and write the report."),
    success=("Criteria S1–S10 satisfied; `metrics.json` complete; `REPORT.md` "
             "with all eight sections, no placeholders, at least four items in "
             "'what this does not show', and a reconciliation naming the "
             "dominant error term."),
    approach=("`run_pipeline(resume=True)` with no limit, then the spot-check by "
              "eye, which is the only part no code can do for you."),
)

nb.code('''
# The spot-check. Watch them. This is the one part of the capstone that cannot
# be automated, and it is the only independent evidence about the judge that
# will exist anywhere in your report.
manifest.reload()
accepted = manifest.select(status="accepted")
rejected = manifest.select(status="rejected")

print(f"{len(accepted)} accepted, {len(rejected)} rejected")
print()
print("Watch at least five accepted and three rejected, then fill in the 2x2")
print("agreement table in report section 2.3 by hand.")
print()
for record in accepted[:5]:
    print(f"  ACCEPTED  {record['variant_id']}")
    print(f"            {record['reason'][:96]}")
for record in rejected[:3]:
    print(f"  REJECTED  {record['variant_id']}")
    print(f"            {record['reason'][:96]}")

# cc.show_video renders inline; make_preview transcodes to something small
# first so a notebook with twenty clips in it stays openable.
for record in accepted[:2]:
    if record.get("output_path") and Path(record["output_path"]).exists():
        cc.show_video(record["output_path"], width=420,
                      caption=f"{record['variant_id']} — {record['axis']}")
''')

nb.md("""
#### Proving resume

Gate G3 asks for resume **demonstrated, with the ledger as evidence**. Counting
what a resume *would* skip is not that: it is the same arithmetic the resume
uses, so it cannot fail independently of the thing it is supposed to be
checking. If `variant_id` were unstable, that arithmetic would be wrong in
exactly the way that makes it agree with itself.

So the cell below runs a real interrupted job against a real `cc.Ledger`. It:

1. runs a work loop over nine items and **kills it** part way through, by
   raising from inside the worker at a chosen item;
2. **truncates the last line of the ledger file**, which is what a `kill -9`
   mid-`write` actually leaves behind;
3. re-runs the *same* loop with `resume=True`, counting how many times the
   worker was called;
4. reports, from the ledger, which keys were skipped and which were redone.

The evidence is the call counter. A resume that consults the ledger and then
redoes the work anyway produces an identical ledger and a call count equal to
the full set, and only the counter can tell the two apart.

The work function writes a file per item, so "was this redone" is also visible
on disk as an mtime — but the counter is the primary evidence and the assertion
is on the counter.
""")

nb.code('''
RESUME_DEMO_DIR = OUTPUT_DIR / "_resume_demo"
RESUME_ITEMS = [f"demo-{i:02d}" for i in range(9)]
KILL_AFTER = 5                 # items completed before the simulated crash


class SimulatedKill(RuntimeError):
    """Stands in for the kernel dying. Raised from inside the worker."""


def resume_demo_run(ledger, kill_after=None, resume=True):
    """Process RESUME_ITEMS through `ledger`. Returns the keys actually worked.

    This is the same three lines every stage of run_pipeline uses: consult the
    ledger, skip what is in it, append the moment the work is done. There is no
    resume code path -- that IS the resume.
    """
    worked = []
    for item in RESUME_ITEMS:
        if resume and ledger.has(item):
            continue                       # the entire resume mechanism
        if kill_after is not None and len(worked) >= kill_after:
            raise SimulatedKill(
                f"kernel died with {item} in flight, "
                f"{len(worked)} item(s) completed")
        (RESUME_DEMO_DIR / "work").mkdir(parents=True, exist_ok=True)
        (RESUME_DEMO_DIR / "work" / f"{item}.txt").write_text(item)
        worked.append(item)
        ledger.append({"variant_id": item, "status": "accepted",
                       "reason": "resume demonstration"})
    return worked


shutil.rmtree(RESUME_DEMO_DIR, ignore_errors=True)
demo_path = RESUME_DEMO_DIR / "manifest.jsonl"
demo = Ledger(demo_path, key_field="variant_id")

# ---- 1. the interrupted run -------------------------------------------------
try:
    resume_demo_run(demo, kill_after=KILL_AFTER)
except SimulatedKill as exc:
    print(f"[kill] {exc}")

before = {r["variant_id"] for r in demo.records()}
print(f"ledger after the kill : {len(before)} record(s) -> {sorted(before)}")
''')

nb.code('''
# ---- 2. the unclean kill: a half-written final line -------------------------
# A clean SIGINT leaves whole lines. A `kill -9` between write() and fsync()
# leaves a truncated one, and a ledger that cannot be read at that moment is
# not a checkpoint. Ledger.reload() drops it and counts it.
with demo_path.open("a", encoding="utf-8") as handle:
    handle.write('{"variant_id": "demo-05", "status": "acce')

resumed = Ledger(demo_path, key_field="variant_id")
print(f"unreadable line(s)    : {resumed.malformed_lines}")
print(f"readable records      : {len(resumed)}")
assert resumed.malformed_lines == 1, "the truncated line should be counted, not fatal"
assert len(resumed) == KILL_AFTER, "the completed records survived the kill"
print("The truncated record is lost. That is the ONE item in flight that")
print("criterion S9 allows, and it was never appended as complete.")
''')

nb.code('''
# ---- 3. the resume ----------------------------------------------------------
redone = resume_demo_run(resumed, resume=True)
after = {r["variant_id"] for r in resumed.records()}

skipped = sorted(before)
print(f"{'item':<12}{'in ledger before':<20}{'worked on resume'}")
print("-" * 52)
for item in RESUME_ITEMS:
    print(f"{item:<12}{('yes' if item in before else 'no'):<20}"
          f"{'yes' if item in redone else 'no'}")
print()
print(f"completed before the kill : {len(before)}")
print(f"worked during the resume  : {len(redone)}  -> {sorted(redone)}")
print(f"ledger after the resume   : {len(after)}")

# The evidence, asserted rather than eyeballed.
assert set(redone).isdisjoint(before), (
    f"resume redid completed work: {sorted(set(redone) & before)}")
assert set(redone) == set(RESUME_ITEMS) - before, "resume skipped unfinished work"
assert after == set(RESUME_ITEMS), "the ledger is not complete after the resume"
print()
print(f"PASS  {len(before)} completed item(s) were skipped and not redone; the "
      f"{len(redone)} unfinished one(s) were.")
print("Cost of the crash: the item in flight, and nothing else.")
''')

nb.code('''
# ---- 4. the same question asked of the REAL manifest ------------------------
# The demonstration above proves the mechanism. This says what it would cost on
# the actual run, which is the number report section 3.5 wants.
manifest.reload()
scenes.reload()

planned_ids = []
for scene in scenes.records():
    planned_ids.extend(p["variant_id"] for p in plan_variants(scene, PER_SOURCE))

still_to_do = manifest.pending(planned_ids)
print(f"planned      : {len(planned_ids)}")
print(f"already done : {len(planned_ids) - len(still_to_do)}")
print(f"would re-run : {len(still_to_do)}")
if manifest.malformed_lines:
    print(f"\\n{manifest.malformed_lines} unreadable line(s) -- the signature of")
    print("a kill mid-write, exactly as demonstrated above.")
if not planned_ids:
    print()
    print("No scene records on this machine, so there is nothing to resume from")
    print("yet. The mechanism above ran on a real ledger regardless; this cell")
    print("fills in once the pipeline has run.")
print()
print("If `would re-run` is the full set after a completed run, your")
print("variant_ids are not stable and resume is not working. _stable_int,")
print("not hash().")
''')

nb.solution(
    "challenge", "Extend it, and measure whether the extension helped",
    goal=("Change one thing, form a hypothesis about a number you already "
          "measure, and find out."),
    success=("A stated hypothesis, a controlled comparison, a measured effect "
             "with an interval or an explicit statement that n is too small for "
             "one, and a verdict — including 'no detectable difference, and here "
             "is the effect size I could have detected'."),
    approach=("Option A, the Lesson 17 checkpoint, because it is the one that "
              "tests the flywheel's actual premise. Implemented, not sketched: "
              "two arms through the same `build_spec` / `generate` / `screen` "
              "path, paired on prompt and seed, a Wilson interval on the "
              "paired disagreements, and a verdict rule committed to the "
              "ledger before the first clip exists. Behind `RUN_GENERATION`, "
              "because it costs two generate passes; with the flag off the "
              "same arithmetic runs on labelled placeholder verdicts and "
              "refuses to write them into the report."),
)

nb.md("""
### The shape of the experiment

Two arms, one variable. Everything else — the prompts, the seeds, the geometry,
the batch size, the judge and its threshold — is held fixed, and the arms are
**paired**: variant *i* in the tuned arm has the same prompt and the same seed as
variant *i* in the base arm. Pairing is what lets the seed's contribution cancel
in the difference rather than being averaged over, which matters enormously at
n = 9.

Four things this needs that the Applied tier did not:

| | Why |
|---|---|
| `RUN_GENERATION` | The arms cost two full generate passes. Opt-in, off by default, the same flag Lessons 14 and 15 use. |
| A separate ledger | Mixing two checkpoints' clips into `manifest.jsonl` would make the headline acceptance rate a number about neither of them. The challenge writes `challenge_manifest.jsonl`, with an `arm` column on every record. |
| A verdict rule fixed in advance | Otherwise the threshold is chosen after seeing the numbers, and the result means nothing. It is printed, timestamped and committed to the ledger before a single clip is generated. |
| An interval | A count of flips with no interval on it is not a measurement. Wilson, because at these counts the normal approximation produces bounds outside [0, 1]. |

**When `RUN_GENERATION` is False, everything below still runs** — against
clearly-labelled invented verdicts. That exercises the arithmetic, the verdict
rule and the report writer, and it is worth exactly nothing as evidence about
the Lesson 17 checkpoint. The cells say so where they print.
""")

nb.code('''
# ---------------------------------------------------------------------------
# The opt-in. RUN_GEN above is a CAPABILITY (is there a GPU and a framework);
# RUN_GENERATION is CONSENT (do you want to spend two generate passes on this).
# Both must be true, and so must a checkpoint from Lesson 17.
# ---------------------------------------------------------------------------
RUN_GENERATION = False

L17_RUN_DIR = cc.OUTPUT_ROOT / "17" / "train" / "cosmos3" / "sft" / "vision_sft_edge"
LATEST_POINTER = L17_RUN_DIR / "checkpoints" / "latest_checkpoint.txt"
TUNED = None
if LATEST_POINTER.exists():
    TUNED = L17_RUN_DIR / "checkpoints" / LATEST_POINTER.read_text().strip()

ARMS = ("base", "tuned")
CHALLENGE_MANIFEST_PATH = OUTPUT_DIR / "challenge_manifest.jsonl"
CHALLENGE_REPORT_PATH = OUTPUT_DIR / "REPORT_CHALLENGE.md"

CHALLENGE_BLOCKERS = []
if not RUN_GENERATION:
    CHALLENGE_BLOCKERS.append("RUN_GENERATION is False (set it True to spend "
                              "two generate passes)")
if not RUN_GEN:
    CHALLENGE_BLOCKERS.append("no CUDA device or no framework checkout")
if not NIM_READY:
    CHALLENGE_BLOCKERS.append("no ready Reasoner NIM to judge the outputs")
if TUNED is None:
    CHALLENGE_BLOCKERS.append(f"no Lesson 17 checkpoint at {LATEST_POINTER}")
if not scenes.records():
    CHALLENGE_BLOCKERS.append("no scene records -- run the pipeline first")

CHALLENGE_MEASURED = not CHALLENGE_BLOCKERS

print(f"fine-tuned checkpoint : {TUNED}")
print(f"arms                  : {ARMS}")
print(f"measured run          : {CHALLENGE_MEASURED}")
for blocker in CHALLENGE_BLOCKERS:
    print(f"  - {blocker}")
''')

nb.code('''
import math  # noqa: E402  (used by wilson_interval below)


def wilson_interval(successes, n, z=1.96):
    """Confidence interval for a binomial proportion. Lesson 13's, unchanged.

    The normal approximation breaks exactly where this experiment lives: at
    0 of 3 it gives [0, 0], a claim of certainty from three trials, and at
    1 of 9 it gives a lower bound below zero. Wilson does neither.
    """
    if n <= 0:
        return 0.0, 1.0
    p = successes / n
    denom = 1 + z ** 2 / n
    centre = (p + z ** 2 / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / denom
    return max(0.0, centre - half), min(1.0, centre + half)


def smallest_decisive_split(m, z=1.96):
    """Fewest flips in one direction, out of m discordant pairs, that decide it.

    Returns the smallest c such that the Wilson interval for c/m lies entirely
    above 0.5 -- i.e. the smallest imbalance this experiment could call. None
    when no split of m pairs is decisive, which is the answer for small m and
    is the number that makes a null result honest.
    """
    for c in range(m + 1):
        if wilson_interval(c, m, z)[0] > 0.5:
            return c
    return None


# Checked against cases verifiable by hand.
assert wilson_interval(0, 10)[0] == 0.0 and 0.25 < wilson_interval(0, 10)[1] < 0.35
assert wilson_interval(10, 10)[1] == 1.0 and 0.65 < wilson_interval(10, 10)[0] < 0.75
assert abs(sum(wilson_interval(25, 50)) / 2 - 0.5) < 1e-9
print("PASS wilson_interval behaves at both extremes and at 50%")
for _m in (3, 5, 9, 20, 40):
    _c = smallest_decisive_split(_m)
    print(f"  {_m:>3} discordant pair(s): "
          + (f"{_c} of {_m} in one direction would decide it"
             if _c is not None else "NO split is decisive at this n"))
''')

nb.md("""
### The hypothesis and the verdict rule, committed before anything runs

Both go into the same ledger the cost prediction went into, with
`record_once`, so re-running this cell cannot quietly replace what was written
the first time. That is the only mechanism in this notebook that makes "decided
in advance" checkable by somebody who was not there.
""")

nb.code('''
HYPOTHESIS = (
    "H: the Lesson 17 fine-tune does not change the acceptance rate by more "
    "than this harness can detect at the n this run produces "
    f"({N_PLANNED} paired variants planned). Rationale: it trained for tens of "
    "iterations at a fraction of the shipped global batch, inside a warmup "
    "schedule that had not finished, on a dataset built from this same "
    "generator's outputs. A null is the expected result, and a null with a "
    "stated detectable effect size is a result."
)

VERDICT_RULE = """\\
Fixed before any number below is computed.

Let  b = pairs the BASE arm accepted and the TUNED arm rejected
     c = pairs the TUNED arm accepted and the BASE arm rejected
     m = b + c, the discordant pairs. Concordant pairs carry no information
         about a difference, which is McNemar's argument for dropping them.

1. m == 0  ->  "no difference detectable at this n". NOT "no difference".
2. Otherwise take the 95% Wilson interval for c / m:
     entirely above 0.5  ->  the fine-tune RAISED the acceptance rate
     entirely below 0.5  ->  the fine-tune LOWERED it
     straddling 0.5      ->  NO DETECTABLE DIFFERENCE, reported together with
                             the smallest split this m could have called.
3. A verdict of RAISED is reported but is NOT taken as evidence that the
   flywheel works. The fine-tune was trained on this generator's own accepted
   outputs and the judge shares a checkpoint with the generator, so a higher
   acceptance rate is partly the judge recognising its own distribution --
   decision 3's circularity, arriving in a new place. Believing it would need
   an independent judge or a downstream task.
"""

CHALLENGE_PRECOMMIT = {
    "key": "challenge_precommit",
    "made_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "hypothesis": HYPOTHESIS,
    "verdict_rule": VERDICT_RULE,
    "arms": list(ARMS),
    "n_pairs_planned": N_PLANNED,
    "held_fixed": ["prompt", "seed", "resolution", "num_frames", "num_steps",
                   "aspect_ratio", "gen_batch_size", "judge prompt",
                   "ACCEPT_CONFIDENCE"],
    "varies": ["--checkpoint-path"],
}

if prediction_log.record_once(CHALLENGE_PRECOMMIT):
    print("hypothesis and verdict rule committed to the ledger")
else:
    print(f"already committed at "
          f"{prediction_log.get('challenge_precommit')['made_at']}")
print()
print(HYPOTHESIS)
print()
print(VERDICT_RULE)
''')

nb.code('''
def challenge_pairs():
    """The paired plans: identical prompt and seed, one entry per arm.

    Built from the real scene records when they exist and from the fixture
    otherwise, so the pairing logic is inspectable with no hardware.
    """
    source_scenes = scenes.records() or [FIXTURE_SCENE]
    base_plans = []
    for scene in source_scenes:
        base_plans.extend(plan_variants(scene, PER_SOURCE))
    pairs = []
    for plan in base_plans:
        arms = {}
        for arm in ARMS:
            variant = dict(plan)
            # Suffix, not a new id: the pair key stays readable and the two
            # arms sort next to each other in the manifest.
            variant["variant_id"] = f"{plan['variant_id']}-{arm}"
            variant["pair_key"] = plan["variant_id"]
            variant[ARM_FIELD] = arm
            arms[arm] = variant
        pairs.append(arms)
    return pairs


PAIRS = challenge_pairs()
print(f"{len(PAIRS)} pair(s), {len(ARMS)} arm(s) each")
for arms in PAIRS[:2]:
    for arm in ARMS:
        v = arms[arm]
        print(f"  {v['variant_id']:<52} seed {v['seed']}")
    assert arms["base"]["prompt"] == arms["tuned"]["prompt"]
    assert arms["base"]["seed"] == arms["tuned"]["seed"]
print()
print("PASS every pair holds prompt and seed identical across the two arms;")
print("the only difference is which checkpoint --checkpoint-path names.")
''')

nb.code('''
def generate_arm(arm, pairs):
    """Generate one arm. Returns {variant_id: (path|None, seconds, peak_gb)}.

    Generation only. The judging is a separate pass because the judge is the
    NIM and the NIM cannot hold the card while a checkpoint is on it -- the
    same constraint that dictates the main pipeline's stage order, and the
    reason this function does not simply call `screen` at the end.
    """
    extra = ["--checkpoint-path", str(TUNED)] if arm == "tuned" else None
    scenes_by_id = {s["clip_id"]: s for s in (scenes.records() or [FIXTURE_SCENE])}
    produced = {}

    variants = [p[arm] for p in pairs]
    for start in range(0, len(variants), GEN_BATCH_SIZE):
        batch = variants[start:start + GEN_BATCH_SIZE]
        specs = [build_spec(v, scenes_by_id[v["clip_id"]]) for v in batch]
        out_dir = GENERATED_DIR / f"challenge_{arm}"
        outcome = run_stage(f"challenge:{arm}",
                            lambda s=specs, o=out_dir, e=extra: generator.run(
                                s, o, seed=BASE_SEED, timeout=RUN_TIMEOUT,
                                extra_args=e),
                            key=f"{arm}[{start}]", clock=clock, sample_vram=True)
        share = outcome.seconds / max(1, len(batch))
        videos = list(outcome.value.videos) if outcome.ok else []
        if not outcome.ok:
            cls, response = respond_to_failure(outcome.error or "")
            print(f"  {arm} batch failed ({cls}): {response}")
        for variant in batch:
            match = next((p for p in videos
                          if variant["variant_id"] in p.stem), None)
            produced[variant["variant_id"]] = (match, share,
                                               outcome.peak_vram_gb)
    return produced


def screen_arm(arm, pairs, produced, ledger):
    """Judge one arm's outputs. Returns {pair_key: accepted_bool}.

    The same `screen` the Applied tier used, at the same threshold. An arm run
    through different screening code would be measuring the code.
    """
    verdicts = {}
    for pair in pairs:
        variant = pair[arm]
        path, seconds, peak = produced.get(variant["variant_id"],
                                           (None, 0.0, None))
        verdict = screen(variant, path)
        ledger.append(manifest_record(variant, path, verdict, seconds, peak,
                                      arm=arm))
        verdicts[variant["pair_key"]] = verdict["status"] == "accepted"
    return verdicts


def placeholder_verdicts(pairs):
    """INVENTED verdicts, so the arithmetic and the verdict rule can be read.

    Constructed to land on a straddling interval, because that is the outcome
    the hypothesis predicts and the one whose reporting is hardest to get
    right. They are not data. Nothing about the Lesson 17 checkpoint follows
    from them, and the report writer refuses to touch REPORT.md when they are
    in use.
    """
    keys = [p["base"]["pair_key"] for p in pairs]
    base = {k: (i % 3 != 2) for i, k in enumerate(keys)}
    tuned = dict(base)
    for i, k in enumerate(keys):          # two flips one way, one the other
        if i == 2:
            tuned[k] = True
        elif i == 5:
            tuned[k] = True
        elif i == 0:
            tuned[k] = False
    return {"base": base, "tuned": tuned}


if CHALLENGE_MEASURED:
    challenge_ledger = Ledger(CHALLENGE_MANIFEST_PATH, key_field="variant_id")
    # Both arms generated with the NIM down, then both judged with it up. Two
    # switches for two arms, not two per arm -- the same batching-by-residency
    # argument the main pipeline makes, and it is worth more here because the
    # arms are otherwise identical and a switch asymmetry between them would
    # land in the comparison.
    nim_down()
    PRODUCED = {arm: generate_arm(arm, PAIRS) for arm in ARMS}
    nim_up()
    VERDICTS = {arm: screen_arm(arm, PAIRS, PRODUCED[arm], challenge_ledger)
                for arm in ARMS}
    print(challenge_ledger.summary(ARM_FIELD))
else:
    VERDICTS = placeholder_verdicts(PAIRS)
    print("PLACEHOLDER VERDICTS -- INVENTED, NOT MEASURED.")
    print()
    print("The two arms below were not generated and not judged. These verdicts")
    print("were written by hand to exercise the pairing, the interval, the")
    print("verdict rule and the report writer. NO FINDING ABOUT THE LESSON 17")
    print("CHECKPOINT CAN BE DRAWN FROM THEM, in either direction, including")
    print("the null the rule is about to report.")
    print()
    for blocker in CHALLENGE_BLOCKERS:
        print(f"  blocked by: {blocker}")
''')

nb.code('''
def analyse_arms(verdicts, measured):
    """Per-arm rates with intervals, the paired table, and the verdict."""
    keys = sorted(set(verdicts["base"]) & set(verdicts["tuned"]))
    n = len(keys)

    per_arm = {}
    for arm in ARMS:
        k = sum(1 for key in keys if verdicts[arm][key])
        lo, hi = wilson_interval(k, n)
        per_arm[arm] = {"accepted": k, "n": n, "rate": (k / n) if n else None,
                        "ci95": [round(lo, 3), round(hi, 3)]}

    b = sum(1 for key in keys if verdicts["base"][key]
            and not verdicts["tuned"][key])
    c = sum(1 for key in keys if verdicts["tuned"][key]
            and not verdicts["base"][key])
    m = b + c

    decisive = smallest_decisive_split(m) if m else None
    if m == 0:
        verdict, ci = "no difference detectable at this n", None
    else:
        lo, hi = wilson_interval(c, m)
        ci = [round(lo, 3), round(hi, 3)]
        if lo > 0.5:
            verdict = "the fine-tune RAISED the acceptance rate"
        elif hi < 0.5:
            verdict = "the fine-tune LOWERED the acceptance rate"
        else:
            verdict = "no detectable difference"

    # What difference could this n have called at all? The smallest decisive
    # split, expressed back as a difference in acceptance rate over n pairs.
    detectable = (((2 * decisive - m) / n) if (decisive is not None and n)
                  else None)

    return {"measured": measured, "n_pairs": n, "per_arm": per_arm,
            "discordant": {"base_only": b, "tuned_only": c, "total": m},
            "discordant_ci95": ci, "verdict": verdict,
            "smallest_decisive_split": decisive,
            "smallest_detectable_rate_difference": detectable}


RESULT = analyse_arms(VERDICTS, CHALLENGE_MEASURED)

if not RESULT["measured"]:
    print("PLACEHOLDER DATA. Everything below is arithmetic on invented")
    print("verdicts and supports no claim about anything.")
    print()
print(f"{'arm':<8}{'accepted':>10}{'of':>5}{'rate':>8}   95% Wilson interval")
print("-" * 58)
for arm in ARMS:
    a = RESULT["per_arm"][arm]
    print(f"{arm:<8}{a['accepted']:>10}{a['n']:>5}{a['rate']:>8.2f}   "
          f"[{a['ci95'][0]:.2f}, {a['ci95'][1]:.2f}]")
d = RESULT["discordant"]
print()
print(f"paired disagreements: base-only {d['base_only']}, "
      f"tuned-only {d['tuned_only']}, total {d['total']}")
if RESULT["discordant_ci95"]:
    print(f"tuned share of the discordant pairs: "
          f"{d['tuned_only']}/{d['total']}, 95% Wilson "
          f"[{RESULT['discordant_ci95'][0]:.2f}, "
          f"{RESULT['discordant_ci95'][1]:.2f}]")
print()
print(f"VERDICT (by the rule fixed above): {RESULT['verdict']}")
if RESULT["smallest_decisive_split"] is None:
    print(f"At {d['total']} discordant pair(s), NO split is decisive. This")
    print("experiment could not have returned anything but a null, whatever")
    print("the checkpoint did -- which is a fact about the design, not the")
    print("model, and it belongs in the report as one.")
else:
    print(f"Smallest split this n could have called: "
          f"{RESULT['smallest_decisive_split']} of {d['total']}, i.e. an "
          f"acceptance-rate difference of about "
          f"{RESULT['smallest_detectable_rate_difference']:+.2f}.")
''')

nb.code('''
def challenge_report_section(result, verdicts):
    """Section 8 of the report. Numbers from `result`, prose written here."""
    d = result["discordant"]
    lines = [
        "## 8. Challenge — the Lesson 17 checkpoint as a second arm", "",
    ]
    if not result["measured"]:
        lines += [
            "> **PLACEHOLDER RESULTS — NOT MEASURED.** The two arms were not "
            "generated and not judged on this machine. The verdicts below were "
            "invented to exercise the pairing, the interval and the verdict "
            "rule. **No finding about the Lesson 17 checkpoint can be drawn "
            "from this section**, in either direction, including the null. "
            "Blocked by: " + "; ".join(CHALLENGE_BLOCKERS) + ".", "",
        ]
    lines += [
        "**Hypothesis, committed before the run.** " + HYPOTHESIS, "",
        "**Verdict rule, fixed before the run.**", "", "```",
        VERDICT_RULE.rstrip(), "```", "",
        "**Held fixed across arms.** prompt, seed, resolution, frame count, "
        "step count, aspect ratio, batch size, judge prompt and "
        f"`ACCEPT_CONFIDENCE = {ACCEPT_CONFIDENCE}`. The only difference is "
        "`--checkpoint-path`.", "",
        f"**Pairs.** {result['n_pairs']}, one per planned variant, each run "
        "through both arms at the same seed.", "",
        "| arm | accepted | of | rate | 95% Wilson interval |",
        "|---|---:|---:|---:|---|",
    ]
    for arm in ARMS:
        a = result["per_arm"][arm]
        lines.append(f"| `{arm}` | {a['accepted']} | {a['n']} | "
                     f"{a['rate']:.2f} | [{a['ci95'][0]:.2f}, "
                     f"{a['ci95'][1]:.2f}] |")
    lines += [
        "",
        "| paired outcome | count |", "|---|---:|",
        f"| both accepted | {sum(1 for k in verdicts['base'] if verdicts['base'][k] and verdicts['tuned'][k])} |",
        f"| both rejected | {sum(1 for k in verdicts['base'] if not verdicts['base'][k] and not verdicts['tuned'][k])} |",
        f"| base only | {d['base_only']} |",
        f"| tuned only | {d['tuned_only']} |",
        f"| **discordant** | **{d['total']}** |",
        "",
        f"**Verdict.** {result['verdict']}.",
        "",
    ]
    if result["smallest_decisive_split"] is None:
        lines += [
            f"**What this could have detected.** Nothing. With "
            f"{d['total']} discordant pair(s) there is no split whose 95% "
            "Wilson interval excludes 0.5, so the experiment was incapable of "
            "returning anything other than a null before it started. That is a "
            "property of the sample size, not of the checkpoint, and it is the "
            "first thing to fix if this is worth repeating.", "",
        ]
    else:
        lines += [
            f"**What this could have detected.** The smallest imbalance this "
            f"design could have called is {result['smallest_decisive_split']} "
            f"of {d['total']} discordant pairs — an acceptance-rate difference "
            f"of about {result['smallest_detectable_rate_difference']:+.2f}. "
            "Any true effect smaller than that was invisible to this run "
            "regardless of what the checkpoint does.", "",
        ]
    lines += [
        "**Why a positive result here would still not be believed.** The "
        "Lesson 17 fine-tune was trained on this generator's own accepted "
        "outputs, and the judge is the other tower of the generator's "
        "checkpoint. A higher acceptance rate is therefore partly the judge "
        "recognising its own distribution. Settling it needs an independent "
        "judge or a downstream task, which is next step 1 and 2 in section 6.",
        "",
        f"**Provenance.** `{CHALLENGE_MANIFEST_PATH.name}`, one record per "
        f"variant per arm, with an `{ARM_FIELD}` column naming which "
        "checkpoint produced each clip. It is a separate ledger from "
        f"`{MANIFEST_PATH.name}` on purpose: mixing two checkpoints' outputs "
        "into one acceptance rate produces a number that is about neither of "
        "them.", "",
    ]
    return lines


section = challenge_report_section(RESULT, VERDICTS)
CHALLENGE_REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
CHALLENGE_REPORT_PATH.write_text("\\n".join(section) + "\\n", encoding="utf-8")
print(f"wrote {CHALLENGE_REPORT_PATH}")

# Only a measured arm may touch the deliverable report. A placeholder section
# appended to REPORT.md is exactly the failure mode gate G1 exists to stop.
if RESULT["measured"] and REPORT_PATH.exists():
    text = REPORT_PATH.read_text(encoding="utf-8")
    if section[0] not in text:
        REPORT_PATH.write_text(text.rstrip() + "\\n\\n---\\n\\n"
                               + "\\n".join(section) + "\\n", encoding="utf-8")
        print(f"appended section 8 to {REPORT_PATH.name}")
else:
    print(f"NOT appending to {REPORT_PATH.name}: "
          + ("no report yet" if RESULT["measured"] else
             "these are placeholder numbers and they do not belong in the "
             "deliverable report"))
print()
print("\\n".join(section[:14]))
''')

nb.model_answer("""
**On option A specifically.** The honest expected outcome is a null, and the
capstone is designed so that a null scores well. Two things make a null result
*good* rather than merely absent:

1. **A stated detectable effect size.** `smallest_decisive_split` above
   computes it directly: the fewest flips in one direction, out of the
   discordant pairs you actually got, whose Wilson interval clears 0.5. At nine
   pairs it is usually *no split at all* — which means the experiment could not
   have returned anything but a null before it started. That is a fact about
   the design, and stating it is the difference between a null result and an
   empty one. "No difference detected" alone is not a result.

2. **A control that shows the harness can see anything at all.** Run
   base-against-base at two seeds first. If that shows verdicts flipping, your
   harness's noise floor is above the effect you are hunting and the experiment
   cannot answer the question — which you want to know before you spend the GPU
   time, not after. The scaffold above runs unchanged for that control: point
   both arms at the base checkpoint and change one arm's seed.

**On what would make this a positive result worth believing.** Not a higher
acceptance rate on its own. The fine-tune was trained on this generator's own
accepted outputs, so a higher acceptance rate is at least partly the judge
recognising its own distribution — the circularity from decision 3, arriving in a
new place. The claim would need an independent judge, or better, a downstream
task. Which is what the first next-step in the report is for.
""")

nb.extend("""
- **Make the diversity criterion two-sided.** Compute it on the plans, then
  caption the accepted outputs and compute it again on those captions. The gap
  between the two is a direct measurement of how much prompt variation the
  generator ignored — which is the number decision 2 wanted all along and could
  not get before generating.
- **Bound the judge's circularity.** Take twenty clips, get verdicts from the
  Cosmos reasoner and from a different vision-language model, and build the 2×2.
  The off-diagonal is where your screening is genuinely uncertain, and it is a
  far better use of an hour of your own attention than a random sample.
- **Put a price on the whole flywheel per useful training clip**, including the
  minutes you spend watching. Most people find the human term is not the small
  one, and that changes which stage is worth optimising.
- **Write a deliberately degenerate variant planner** that maximises your
  diversity score while producing obvious rubbish. If you can, you have found the
  paragraph that belongs in report §4. If you cannot, your criterion is better
  than you thought and you should say why.
""")

# =====================================================================
# CLOSING
# =====================================================================
nb.md("""
---

## If your answers differed

In this order, because that is the order in which they matter:

1. **Did yours satisfy the stated success criteria?** If it did, it is a correct
   answer, whatever it looks like. Two of the four decisions here have good
   answers that look nothing like these.
2. **Does yours fail on an input this one survives, or the reverse?** The obvious
   trades: a source clip the reasoner cannot caption, a generation batch that
   dies halfway, a judge reply that is prose. Try each against both.
3. **Which one would you rather debug in six months?** That question settles more
   design arguments than elegance does, and for a pipeline that runs unattended
   it is close to the only question.

Two places where this implementation is weakest, said plainly so you can beat it:

- **The diversity criterion is prompt-side only.** It cannot see that the
  generator ignored your lighting instruction. A criterion with any pixel-side
  component beats this one, and the extension section says how to build the
  cheapest version.
- **The judge is single-shot at one seed per clip.** A two-of-three vote across
  seeds is strictly better evidence and costs three times the judging. If your
  budget stretched to it, yours is better.

If you find a real error here, it is an error — say so. The lesson is
`19_capstone_synthetic_data_flywheel.ipynb`; the rubric is
`assets/reference/CAPSTONE_RUBRIC.md`; the facts these answers rest on are in
`assets/reference/COSMOS3_FACTS.md`.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "solutions" / "19_capstone_reference.ipynb")
