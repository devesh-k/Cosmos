"""Build 08_generation_control.ipynb.

Derived from the source DLI course `S-OV-57-V1`, notebook 03, section 4
(cells 16-20): the edge-control transfer run from the shipped cookbook spec.
Its assets, its spec and its example are preserved.

What this lesson CORRECTS. The source presents "data augmentation" as though
transfer were a mode of the model. It is not. Transfer is
`model_mode: "video2video"` plus a control-hint block in the spec, and the
framework selects the transfer path by detecting that block. Getting this wrong
means a learner goes looking for a `transfer` entry in `ModelMode`, does not
find one, and concludes their checkout is broken.

What it adds: the geometry consequence the source states in one sentence and
never demonstrates (the control video, not your spec, decides the output's frame
count and shape), a measured comparison of what each hint preserves, the honest
status of multi-control, and an opt-in path for anyone who does not want to pull
34.9 GB.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 08 — Control-conditioned generation and augmentation")

# =====================================================================
# Title and objectives
# =====================================================================
nb.md("""
# Lesson 08 — Control-conditioned generation and augmentation

**What you will build.** `outputs/08/augmentation_set/` — one source clip
re-rendered through several control hints, with a measured comparison of what
each one preserved, plus a transfer spec you wrote by hand.

| | |
|---|---|
| **Time** | ~2 hours. Transfer runs are among the longest in this course. |
| **GPU** | 1 × H100 80 GB, exclusively. |
| **Downloads** | **Cosmos3-Nano, 34.9 GB.** Read the next paragraph before you start. |
| **Prerequisites** | Lesson 07, including `outputs/06/calibration.json`. |

<div style="border-left:4px solid #c92a2a;padding:.6em 1em;margin:1em 0;background:rgba(128,128,128,.08);border-radius:0 4px 4px 0">

**Warning — this lesson needs a 34.9 GB download.** Cosmos3-Edge **cannot do
transfer at all** (`COSMOS3_FACTS.md` §1: `supports_transfer: False`), and
Cosmos3-Super cannot either. Transfer is a Nano-only capability, and Nano is
34.9 GB on top of what you already have. On a slow link that is an hour.

The download is **opt-in**. Everything that does not need a GPU — the enum
proof, the shipped specs, the control-video geometry, the cost arithmetic, the
multi-control discussion and the whole first half of the debugging lab — runs
without it. If you do not want the 34.9 GB, work through the read-only path and
come back later; the notebook tells you at each point which one you are on.

</div>
""")

nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **State** that transfer is `model_mode: "video2video"` plus a control-hint
   block, and **demonstrate** it by writing a transfer spec from scratch.
2. **Name** the four members of `TransferHintKey` and match each to what it
   preserves, and explain the status of `wsm`.
3. **Predict** which hint best preserves object identity, then run two hints on
   one clip and judge with a metric rather than an impression.
4. **Demonstrate** that the control video — not your spec — determines the
   output's frame count and geometry.
5. **Diagnose** a frame-count mismatch between the control and the spec, from
   the output rather than from the exit code.
6. **Design** an augmentation pass: one source clip, N on-distribution variants,
   with a stated argument for which hint suits which variation.
7. **Report** honestly on multi-control, including which parts of the upstream
   documentation describe files that do not exist.
""")

# =====================================================================
# The correction
# =====================================================================
nb.md("""
## Transfer is not a mode

Here is the sentence the source material gets wrong, and it is worth being blunt
because the wrong version sends people looking for something that is not there.

> Transfer is **`model_mode: "video2video"`** plus a **control-hint block** in
> the same spec. The framework detects the block and takes the transfer path.
> There is no `transfer` entry in `ModelMode` and there never was.

A transfer spec looks like this:

```json
{
  "model_mode": "video2video",
  "name": "edge_transfer",
  "prompt": "<structured JSON, as a string>",
  "negative_prompt": "<...>",
  "edge": { "control_path": "/abs/path/control_edge.mp4", "weight": 1.0 }
}
```

The `edge` key at the top level is the whole mechanism. Change it to `depth` and
you get depth-conditioned transfer with the same model, the same mode and the
same launch command.
""")

nb.callout("upstream", """
Several upstream pages and the source DLI course describe transfer as a thing
you *select*, and the cookbook's `transfer/README.md` compounds this by
referring to an `assets/multi_control/` directory that does not exist in the
checkout. The rule this course keeps repeating applies here too: **trust the
enum, not the prose.** The cell below has you check it in your own installation
rather than believe this page. If your enum disagrees with what you read here,
your enum is right and this page needs an issue opened against it.
""")

nb.code('''
# This cell runs BEFORE the standard configuration cell, because settling a
# documentation dispute should not require a GPU, a model or a download. It
# imports the course package directly and touches nothing else.
import json
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

import numpy as np

COURSE_ROOT_PROBE = Path.cwd()
while not (COURSE_ROOT_PROBE / "cosmos_course").is_dir() \\
        and COURSE_ROOT_PROBE != COURSE_ROOT_PROBE.parent:
    COURSE_ROOT_PROBE = COURSE_ROOT_PROBE.parent
sys.path.insert(0, str(COURSE_ROOT_PROBE))
import cosmos_course as cc0

print("Is 'transfer' a model mode?")
print(f"  'transfer' in MODEL_MODES : {'transfer' in cc0.MODEL_MODES}")
print(f"  modes that exist          : {', '.join(sorted(cc0.MODEL_MODES))}")
print()
print("Control hints (TransferHintKey):")
for hint, meaning in cc0.TRANSFER_HINTS.items():
    print(f"  {hint:<6} {meaning}")
print()
print("And the validator enforces the pairing. A hint on the wrong mode:")
wrong = {"model_mode": "text2video", "name": "nope", "prompt": "a road",
         "edge": {"control_path": "control.mp4"}}
for problem in cc0.validate_spec(wrong, strict=False):
    print("  " + problem)
''')

nb.md("""
### The four hints, and a fifth thing that is not one

| Hint | Preserves | Lets you change | Good for |
|---|---|---|---|
| `edge` | shape, layout, fine detail | everything about surfaces and light | material and texture changes |
| `blur` | colour, lighting, overall look | fine detail and texture | subtle appearance edits |
| `depth` | 3D structure, spatial scale | surfaces, materials, illumination | relighting, surface changes |
| `seg` | object and region identity | the appearance of each region | replacing objects or backgrounds |

Read that table as a trade. Every hint is a **lossy summary of the source
video**, and what it throws away is exactly what you are free to change. An edge
map has no colour, so colour is yours. A depth map has no texture, so texture is
yours. A segmentation map has no geometry within a region, so the inside of each
region is yours. This is the whole idea, and once you see it you can predict a
hint's behaviour without running it.

**`wsm` — world scenario map.** The cookbook ships a fifth asset family under
`assets/wsm/` using the same mechanism, and it is **not a member of the
`TransferHintKey` enum**. `cosmos_course.specs.TRANSFER_HINTS` includes it
because the course wants specs containing it to validate; `cosmos_course.config.
TRANSFER_HINTS` documents only the four that are in the enum. If you find those
two lists disagreeing, that disagreement is deliberate and this is the reason.

**A naming collision worth defusing now.** `Cosmos3-Edge` is a model tier.
`edge` is a control hint. They have nothing to do with each other, and the
Edge *tier* is the one tier that **cannot run the edge *hint***. Say "the Edge
checkpoint" and "the edge control" out loud a few times; you will meet this
confusion in your own notes otherwise.
""")

# =====================================================================
# Environment
# =====================================================================
nb.md("""
## Environment, and the 34.9 GB decision

The setup cell is the standard one. The cell after it overrides `MODEL`,
because this lesson has no choice: Edge cannot do transfer, Super needs about
128 GB of VRAM for framework inference and will not fit an 80 GB card, so Nano
it is.

That cell reports the download size and then stops. Nothing downloads until you
set `ALLOW_NANO_DOWNLOAD = True` yourself.
""")

nb.code('# This lesson writes to outputs/08/. The setup cell below reads this name.\n'
        '__lesson__ = "08"\n\n' + SETUP_CELL)

nb.code('''
from cosmos_course.measure import MeasurementLog
from cosmos_course.models import Generator

# --- the tier decision, made explicit -------------------------------------
for tier, facts in cc.MODEL_TIERS.items():
    print(f"{tier:<14} transfer={str(facts['supports_transfer']):<5} "
          f"vram~{facts['inference_vram_gb']:>3} GB  download {facts['download_gb']:>6.1f} GB")
print()
MODEL = "Cosmos3-Nano"          # overrides the setup cell: nothing else can do this
print(f"this lesson uses {MODEL}, and has no alternative")


def hf_cache_dir(repo_id):
    root = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface")) / "hub"
    return root / ("models--" + repo_id.replace("/", "--"))


def dir_size_gb(path):
    path = Path(path)
    if not path.exists():
        return 0.0
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file()) / 1e9


# ---------------------------------------------------------------------
# Set this True ONLY if you have read the size below and want the download.
# ---------------------------------------------------------------------
ALLOW_NANO_DOWNLOAD = False

cached_gb = dir_size_gb(hf_cache_dir(cc.MODEL_TIERS[MODEL]["hf_repo"]))
needs_download = cached_gb < 5.0
print()
print(f"{MODEL} in the local cache: {cached_gb:.1f} GB")
if needs_download:
    print(f"A run will download about {cc.MODEL_TIERS[MODEL]['download_gb']} GB.")
    print("Free disk check:")
    free_gb = shutil.disk_usage(COURSE_ROOT).free / 1e9
    print(f"  {free_gb:.0f} GB free — "
          + ("enough" if free_gb > 60 else "TIGHT. See scripts/cleanup.sh first."))
else:
    print("Already cached; no download needed.")

generator = Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=True)

RUN = ((not framework_problems) and DEVICE.startswith("cuda")
       and (not needs_download or ALLOW_NANO_DOWNLOAD))
print()
print(f"generation enabled : {RUN}")
print(f"read-only path     : {not RUN}  (everything except the transfers still runs)")
''')

nb.md("""
Now the run settings and the measurement harness. Two things are specific to
this lesson.

**Reduced mode trims the control video.** The shipped controls are 121 frames at
30 FPS, and a full-length transfer takes long enough that a first pass through
this lesson would be mostly waiting. Trimming the control to a third is not a
neutral convenience — it is a *demonstration*, because the output will follow the
trimmed control's length rather than anything in your spec. That is the point of
the whole geometry section, and you get it for free.

**Re-encoding a control map is lossy, and that matters more here than usual.**
An edge map is a thin-line image; H.264 at a normal quality setting smears thin
lines. The trim below uses a high quality setting to limit the damage, and you
should not do this in a production augmentation pipeline — generate the control
at the length you want instead.
""")

nb.code('''
if MODE == "full":
    CONTROL_FRAMES, N_STEPS = None, 35        # None = use the control's own length
else:
    CONTROL_FRAMES, N_STEPS = 33, 10

RES = "480"
RUN_TIMEOUT = 5400 if MODE == "full" else 2400

CALIB_PATH = cc.OUTPUT_ROOT / "06" / "calibration.json"
CALIB = json.loads(CALIB_PATH.read_text()) if CALIB_PATH.exists() else {}
log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
RUNS = {}


def predict_seconds(resolution, num_frames, num_steps, aspect_ratio="16,9"):
    ups = CALIB.get("units_per_second")
    if not ups:
        return None
    units = cc.estimate_generation_cost(resolution=resolution, num_frames=num_frames,
                                        num_steps=num_steps,
                                        aspect_ratio=aspect_ratio)["cost_units"]
    return (CALIB.get("fixed_overhead_s") or 0.0) + units / ups


class GpuSampler:
    """Poll device-wide VRAM on a thread; report the peak, in GB."""

    def __init__(self, interval=1.0, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_gb()
            if value is not None:
                self.samples.append(value)

    def __enter__(self):
        self.samples = [self._read_gb() or 0.0]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None


print(f"mode {MODE!r}: {RES}p, "
      + (f"{CONTROL_FRAMES} control frames" if CONTROL_FRAMES else "full control length")
      + f", {N_STEPS} steps")
''')

nb.code('''
def run_and_verify(spec, subdir, *, label=None, timeout=None):
    """Predict, run, sample VRAM, verify by content, record."""
    label = label or (spec.get("name") if isinstance(spec, dict) else spec.name)
    if not RUN:
        print(f"skipped {label!r}: read-only path (Nano is not available)")
        return None

    body = spec if isinstance(spec, dict) else spec.to_dict()
    for problem in cc.validate_spec(body, strict=False):
        print("  spec warning:", problem)

    predicted = predict_seconds(body.get("resolution", RES),
                                body.get("num_frames") or 33,
                                body.get("num_steps") or N_STEPS,
                                body.get("aspect_ratio", "16,9"))
    print(f"{label}: predicted "
          + (f"{predicted / 60:.1f} min" if predicted else "n/a (no calibration)"))

    with GpuSampler() as sampler:
        with cc.timer(label, track_memory=False) as timing:
            result = generator.run(spec, OUTPUT_DIR / subdir,
                                   seed=int(body.get("seed") or 0), timeout=timeout or RUN_TIMEOUT)

    RUNS[label] = {"seconds": timing.seconds, "peak_gb": sampler.peak_gb,
                   "predicted_s": predicted, "result": result}
    log.record(label=label, model=MODEL, mode=MODE,
               **{k: v for k, v in RUNS[label].items() if k != "result"})
    print(f"\\n  measured {timing.seconds / 60:.1f} min, peak {sampler.peak_gb:.1f} GB")
    print()
    cc.verify_result(result)
    return result


print("harness ready")
''')

# =====================================================================
# The shipped spec and control geometry
# =====================================================================
nb.md("""
## Read the shipped spec before writing one

The cookbook ships a ready-made spec per hint under `transfer/specs/`, and each
one pairs with a control video and a prompt under `transfer/assets/<hint>/`.
Read the shipped spec first: it is the authoritative example, and anything you
write by hand should be checked against it rather than against your memory of
this page.

Note the path handling. The framework resolves conditioning paths **relative to
the spec file**, and the source course dealt with that by `cd`-ing into the
cookbook directory before launching. This course runs the generator with its
working directory in the framework repo, so a relative `control_path` in the
shipped spec would not resolve. `cosmos_course.specs.write_spec` rewrites
`vision_path`, `action_path`, `sound_path` and every hint's `control_path` to
absolute paths for exactly this reason — but the shipped file on disk is still
relative, so read it with that in mind.
""")

nb.code('''
def compact(obj):
    """Serialise a structured prompt as the single string the framework wants."""
    if isinstance(obj, (str, Path)):
        obj = json.loads(Path(obj).read_text())
    return json.dumps(obj, ensure_ascii=True, separators=(",", ":"))


shipped_path = cc.asset_or_none("spec_edge")
if shipped_path is None:
    shipped = None
    print("transfer/specs/edge.json is not on disk.")
    print("Run `python scripts/fetch_assets.py` to clone the cookbook, then re-run.")
else:
    shipped = json.loads(shipped_path.read_text())
    print(f"{shipped_path}\\n")
    print(json.dumps(shipped, indent=2)[:1400])
    print()
    hints_present = sorted(set(shipped) & set(cc.TRANSFER_HINTS))
    print(f"top-level keys : {', '.join(sorted(shipped))}")
    print(f"model_mode     : {shipped.get('model_mode')!r}")
    print(f"control hints  : {hints_present or 'NONE FOUND — read the file above'}")
    print()
    print("If model_mode is 'video2video' and exactly one hint key is present,")
    print("you have just verified the correction at the top of this lesson against")
    print("a file NVIDIA shipped, rather than against this notebook.")
''')

nb.md("""
### The control video decides the geometry

This is the sentence the source states once and never demonstrates, and it is
the source of the debugging lab at the end of this lesson:

> **The output's frame count, frame rate and pixel geometry come from the
> control video, not from your spec.**

That is not a quirk. The control is a per-frame conditioning signal; there is
one control frame per output frame, by construction. Asking for 61 output frames
while supplying 121 control frames is not a request the pipeline can honour, and
it does not fail — it follows the control.

So the first thing to do with any control video is measure it. The shipped
controls are documented as 121 frames at 30 FPS, except `wsm` at 101 frames and
10 FPS. Check that on your own disk rather than believing it.
""")

nb.code('''
def probe_video(path):
    """Frames, fps and pixel geometry of a video file, however we can get them."""
    path = Path(path)
    out = {"file": path.name, "frames": None, "fps": None, "width": None, "height": None}
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        try:
            raw = subprocess.run(
                [ffprobe, "-v", "error", "-select_streams", "v:0", "-count_frames",
                 "-show_entries", "stream=width,height,nb_read_frames,r_frame_rate",
                 "-of", "json", str(path)],
                capture_output=True, text=True, timeout=300, check=True).stdout
            stream = json.loads(raw)["streams"][0]
            num, _, den = stream.get("r_frame_rate", "0/1").partition("/")
            out.update(frames=int(stream.get("nb_read_frames", 0)),
                       width=stream.get("width"), height=stream.get("height"),
                       fps=round(float(num) / float(den or 1), 3))
            return out
        except Exception:
            pass
    try:                                   # fallback: count by decoding
        import imageio.v3 as iio
        frames = sum(1 for _ in iio.imiter(path))
        first = next(iter(iio.imiter(path)))
        out.update(frames=frames, height=first.shape[0], width=first.shape[1])
    except Exception as exc:
        out["error"] = f"{type(exc).__name__}: {exc}"
    return out


CONTROL_ASSETS = ["control_edge", "control_blur", "control_depth", "control_seg", "control_wsm"]
controls = {}
print(f"{'asset':<16} {'file':<22} {'frames':>7} {'fps':>7} {'w x h':>12}")
for name in CONTROL_ASSETS:
    path = cc.asset_or_none(name)
    if path is None:
        print(f"{name:<16} MISSING — run scripts/fetch_assets.py")
        continue
    info = probe_video(path)
    controls[name] = {"path": path, **info}
    print(f"{name:<16} {info['file']:<22} {str(info['frames']):>7} "
          f"{str(info['fps']):>7} {str(info['width']) + 'x' + str(info['height']):>12}")

print()
print("A clip's duration is frames / fps. Note wsm: fewer frames at a much lower")
print("frame rate, so it covers MORE wall-clock time than the others despite")
print("being shorter. If you mix control families in one augmentation set, that")
print("difference propagates into your data and nothing warns you about it.")
''')

nb.md("""
### Trimming, and why it is also the demonstration

In reduced mode the control gets trimmed to `CONTROL_FRAMES`. The spec below
deliberately asks for a *different* frame count than the trimmed control has, so
that the first transfer you run already answers the geometry question. Read the
output frame count when it finishes; it will not be the number in your spec.
""")

nb.code('''
def trim_control(src, n_frames, out_dir=None):
    """Return a shortened copy of a control video. Cached; needs ffmpeg."""
    src = Path(src)
    if not n_frames:
        return src
    out_dir = Path(out_dir or OUTPUT_DIR / "controls")
    out_dir.mkdir(parents=True, exist_ok=True)
    dst = out_dir / f"{src.stem}_{n_frames}f.mp4"
    if dst.exists() and dst.stat().st_size > 0:
        return dst
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg is None:
        print("ffmpeg is not installed, so the control cannot be trimmed. Falling")
        print("back to the full-length control — expect a much longer run.")
        return src
    subprocess.run(
        [ffmpeg, "-y", "-loglevel", "error", "-i", str(src),
         "-frames:v", str(n_frames),
         # crf 10 rather than a normal 20-23: thin edge lines smear badly at
         # ordinary quality settings and the control would degrade.
         "-c:v", "libx264", "-crf", "10", "-preset", "veryfast",
         "-pix_fmt", "yuv420p", str(dst)],
        check=True, capture_output=True, text=True, timeout=900)
    return dst


def transfer_spec(hint, *, name, prompt_obj, num_frames_request, seed=2026,
                  weight=1.0, control_override=None):
    """A transfer spec: video2video plus ONE control-hint block. Nothing else."""
    key = f"control_{hint}"
    if control_override is None and key not in controls:
        raise FileNotFoundError(
            f"the {hint!r} control video is not on disk, so no transfer can be built "
            f"from it.\\n  Run `python scripts/fetch_assets.py` to clone the Cosmos "
            f"cookbook, or set COSMOS_ROOT to an existing checkout.\\n  Available "
            f"here: {sorted(k.replace('control_', '') for k in controls) or 'none'}")
    control = control_override or trim_control(controls[key]["path"], CONTROL_FRAMES)
    negative = cc.asset_or_none("transfer_negative_prompt")
    return cc.InferenceSpec(
        model_mode="video2video",                 # <- the mode. Not "transfer".
        name=name,
        prompt=compact(prompt_obj),
        negative_prompt=compact(negative) if negative else None,
        vision_path=str(control),
        resolution=RES, aspect_ratio="16,9",
        num_frames=num_frames_request, fps=24,
        num_steps=N_STEPS, guidance=7.0, shift=10.0, seed=seed,
        controls={hint: {"control_path": str(control), "weight": weight}},
    )


edge_prompt = cc.asset_or_none("transfer_prompt_edge")
edge_prompt_obj = json.loads(edge_prompt.read_text()) if edge_prompt else {
    "description": "The same scene rendered with polished metal surfaces under "
                   "cold overcast light.",
}

edge_control = trim_control(controls["control_edge"]["path"], CONTROL_FRAMES) \\
    if "control_edge" in controls else None
if edge_control is not None:
    print("control after trimming:", json.dumps(probe_video(edge_control), indent=2))
    cc.show_video(edge_control, width=420, caption="the edge control map")
''')

nb.code('''
REQUESTED_FRAMES = 61          # deliberately not the control's length
edge_spec = None
edge_result = None
if "control_edge" in controls:
    edge_spec = transfer_spec("edge", name="transfer_edge",
                              prompt_obj=edge_prompt_obj,
                              num_frames_request=REQUESTED_FRAMES)
    print(edge_spec.describe())
    print()
    print("control block:", json.dumps(edge_spec.controls, indent=2))
    print()
    edge_result = run_and_verify(edge_spec, "augmentation_set", label="transfer_edge")
else:
    print("The edge control video is not on disk, so no transfer can run here.")
    print("Run `python scripts/fetch_assets.py`, then re-run from the control-probe")
    print("cell onwards. Everything conceptual above this point already ran.")

if edge_result is not None and edge_result.video_path:
    produced = probe_video(edge_result.video_path)
    control_info = probe_video(edge_control)
    print()
    print(f"you asked for         : {REQUESTED_FRAMES} frames")
    print(f"the control has       : {control_info['frames']} frames")
    print(f"the output has        : {produced['frames']} frames")
    print(f"geometry: control {control_info['width']}x{control_info['height']} -> "
          f"output {produced['width']}x{produced['height']}")
    print()
    print("Whichever of those the output matched is your answer, and it is a")
    print("property of your build rather than of this notebook. Write it down.")
    cc.show_video(edge_result.video_path, width=520, caption="edge transfer output")
''')

# =====================================================================
# Hand-written spec
# =====================================================================
nb.md("""
### Write one by hand, and check it against the shipped one

`transfer_spec()` above already builds specs from scratch, which is the
objective — but building one and *believing* it are different things. Compare
the field set against the shipped file and look at what differs. Differences are
not necessarily errors: the shipped spec is tuned for a full-length run at
higher quality, and yours is deliberately reduced. The point is to know which
differences you chose.
""")

nb.code('''
mine = edge_spec.to_dict() if edge_spec is not None else {}
print(f"{'field':<20} {'shipped':<34} {'yours':<34}")
if shipped is None or not mine:
    print("(nothing to compare: the shipped spec or the control video is missing)")
else:
    for key in sorted(set(shipped) | set(mine)):
        a = json.dumps(shipped.get(key, "<absent>"))
        b = json.dumps(mine.get(key, "<absent>"))
        mark = " " if a == b else "*"
        print(f"{mark}{key:<19} {a[:33]:<34} {b[:33]:<34}")
    print()
    print("* marks a difference. Expected differences: prompt/negative_prompt are")
    print("  compacted here, control_path is absolute here, and the sampling")
    print("  settings are reduced. Anything else is worth understanding before you")
    print("  build an augmentation pipeline on it.")

print()
if edge_spec is not None:
    print("validate_spec on the hand-written one:",
          cc.validate_spec(edge_spec, strict=False) or "no problems")
''')

# =====================================================================
# Depth, and what survived
# =====================================================================
nb.md("""
## The same clip through a different hint

Change one key. Same mode, same model, same command, same prompt. The
difference in the output is entirely the difference between what an edge map
retains about the source and what a depth map retains.

Predict before you run: an edge map carries thin high-frequency lines, so it
pins the *outline* of everything including small detail. A depth map carries a
smooth surface at each pixel, so it pins where things are in space but says
nothing about texture or fine boundaries.
""")

nb.code('''
depth_prompt = cc.asset_or_none("transfer_prompt_depth")
depth_prompt_obj = json.loads(depth_prompt.read_text()) if depth_prompt else edge_prompt_obj

depth_result = None
if "control_depth" in controls:
    depth_spec = transfer_spec("depth", name="transfer_depth",
                               prompt_obj=depth_prompt_obj,
                               num_frames_request=REQUESTED_FRAMES)
    depth_result = run_and_verify(depth_spec, "augmentation_set", label="transfer_depth")
    if depth_result is not None and depth_result.video_path:
        cc.show_video(depth_result.video_path, width=520, caption="depth transfer output")
else:
    print("control_depth is missing — run scripts/fetch_assets.py")
''')

nb.md("""
### Measuring what survived

Two metrics, both crude, both transparent, and each biased in a way you should
say out loud when you report it.

**Structure retention** correlates the gradient-magnitude map of the output
against the gradient-magnitude map of the control, frame by frame. It is biased
in favour of `edge`, because an edge control map *is* essentially a gradient
map. Do not use it to rank hints against each other; use it to check that a
given run followed its own control at all.

**Motion agreement** correlates the per-frame change profile of the output
against that of the control — how much moved, when. This one is control-agnostic:
whatever the hint, a transfer that ignored the source will have a different
motion profile. It is the better cross-hint comparison, and it is insensitive to
appearance, which is exactly what you are deliberately changing.

Neither is a quality metric. Both answer "did the conditioning have an effect",
which is the question `check_video` explicitly cannot answer.
""")

nb.code('''
def read_frames(path, count=8):
    """Sample up to `count` grayscale frames, evenly spaced, as float arrays."""
    frames = []
    try:
        import imageio.v3 as iio
        allf = []
        for i, frame in enumerate(iio.imiter(path)):
            allf.append(frame)
            if i > 400:
                break
        if allf:
            step = max(1, len(allf) // count)
            frames = [np.asarray(f).astype(np.float64) for f in allf[::step][:count]]
    except Exception:
        pass
    if not frames:
        return []
    out = []
    for f in frames:
        g = f.mean(axis=2) if f.ndim == 3 else f
        out.append(g)
    return out


def resize_to(a, shape=(90, 160)):
    from PIL import Image
    return np.asarray(Image.fromarray(a.astype(np.uint8)).resize((shape[1], shape[0])),
                      dtype=np.float64)


def correlate(a, b):
    x, y = a.ravel(), b.ravel()
    if x.std() < 1e-6 or y.std() < 1e-6:
        return float("nan")
    return float(((x - x.mean()) * (y - y.mean())).mean() / (x.std() * y.std()))


def gradient_magnitude(a):
    gy, gx = np.gradient(a)
    return np.hypot(gx, gy)


print("frame helpers ready")
''')

nb.code('''
def structure_retention(video_path, control_path, count=6):
    """Gradient-map correlation, output against control. Biased toward `edge`.

    NaN comes back when a frame has no gradient variation at all — a flat frame
    has no structure to correlate with. That is a real answer, not an error, so
    the undefined frames are dropped rather than poisoning the mean.
    """
    v = [resize_to(f) for f in read_frames(video_path, count)]
    c = [resize_to(f) for f in read_frames(control_path, count)]
    n = min(len(v), len(c))
    values = [correlate(gradient_magnitude(v[i]), gradient_magnitude(c[i])) for i in range(n)]
    values = [x for x in values if x == x]          # x != x is True only for NaN
    return float(np.mean(values)) if values else float("nan")


def motion_profile(path, count=12):
    frames = [resize_to(f) for f in read_frames(path, count)]
    return np.array([np.abs(frames[i + 1] - frames[i]).mean()
                     for i in range(len(frames) - 1)]) if len(frames) > 1 else np.array([])


def motion_agreement(video_path, control_path):
    a, b = motion_profile(video_path), motion_profile(control_path)
    n = min(len(a), len(b))
    return correlate(a[:n], b[:n]) if n >= 3 else float("nan")


SURVIVED = {}
for label, res, hint in (("edge", edge_result, "edge"), ("depth", depth_result, "depth")):
    if res is None or not res.video_path:
        continue
    control = trim_control(controls[f"control_{hint}"]["path"], CONTROL_FRAMES)
    SURVIVED[label] = {
        "structure_retention": structure_retention(res.video_path, control),
        "motion_agreement": motion_agreement(res.video_path, control),
    }

if SURVIVED:
    print(f"{'hint':<8} {'structure retention':>21} {'motion agreement':>19}")
    for label, row in SURVIVED.items():
        print(f"{label:<8} {row['structure_retention']:>21.4f} "
              f"{row['motion_agreement']:>19.4f}")
    print()
    print("Expect edge to score higher on structure retention almost regardless of")
    print("how well the transfer worked. That is the bias, not a result. Motion")
    print("agreement is the number to compare across hints.")
else:
    print("Nothing to measure — the transfers did not run (read-only path).")
''')

nb.md("""
## Why any of this matters

Here is the argument, and it is the one the whole capstone rests on.

You have one real recording. It cost money to make: a rig, a driver, a
permission, a day. It shows one lighting condition, one weather, one set of
surfaces. A perception model trained on it will fail the first time the sun
comes out from a different angle.

Control-conditioned transfer turns that one recording into many. The **geometry,
the motion and the timing are preserved by the control**, so every variant is a
recording of the same event — the car is in the same place at the same moment,
the pedestrian steps off the kerb at the same frame. What changes is exactly
what the hint threw away: the light, the materials, the weather, the surfaces.

That is what "on-distribution variation" means, and it is why this is different
from generating a thousand unrelated clips. The variants are *labelled by
construction*: if you had a bounding box on frame 40 of the source, it is still
correct on frame 40 of every variant, because the control pinned the geometry.
That property is worth more than the pixels.

The honest limitation, which you should write into any report you produce from
this: every variant inherits the source's composition, its camera trajectory and
its scene layout. A hundred variants of one clip is not a hundred clips. It is
one clip with a hundred appearances, and a model can overfit to the shared
structure just as it can overfit to a single image.
""")

# =====================================================================
# Predict-run-explain 1
# =====================================================================
nb.predict_run_explain(
    predict=(
        "You are about to run the same clip through `seg` and compare it against "
        "the `edge` run you already have. Predict which of the two better "
        "preserves **object identity** — a car still being recognisably that car, "
        "a person still being a person in the same pose. Commit to one, and to a "
        "reason drawn from what each control map physically contains."
    ),
    change=(
        "Nothing to edit. Note that this is a genuinely uncertain question and "
        "the two hints preserve different things, so 'it depends' is only an "
        "acceptable answer if you say what it depends on."
    ),
    explain=(
        "Judge with your eyes first, then with `motion_agreement`, then say "
        "whether the number agreed with you. If it did not, decide which of the "
        "two you trust and why — that decision is the actual skill here."
    ),
    hint=(
        "A segmentation map says 'this region is a car' but says nothing about "
        "the shape of the car within the region. An edge map says nothing about "
        "what anything IS, but pins every outline. So one of them can keep the "
        "silhouette while losing the category, and the other can keep the "
        "category while losing the silhouette. Which failure looks worse depends "
        "on what you are training."
    ),
)

nb.code('''
seg_prompt = cc.asset_or_none("transfer_prompt_seg")
seg_prompt_obj = json.loads(seg_prompt.read_text()) if seg_prompt else edge_prompt_obj

seg_result = None
if "control_seg" in controls:
    seg_spec = transfer_spec("seg", name="transfer_seg", prompt_obj=seg_prompt_obj,
                             num_frames_request=REQUESTED_FRAMES)
    seg_result = run_and_verify(seg_spec, "augmentation_set", label="transfer_seg")
    if seg_result is not None and seg_result.video_path:
        SURVIVED["seg"] = {
            "structure_retention": structure_retention(
                seg_result.video_path, trim_control(controls["control_seg"]["path"], CONTROL_FRAMES)),
            "motion_agreement": motion_agreement(
                seg_result.video_path, trim_control(controls["control_seg"]["path"], CONTROL_FRAMES)),
        }
        cc.show_video(seg_result.video_path, width=520, caption="seg transfer output")
else:
    print("control_seg is missing — run scripts/fetch_assets.py")

if SURVIVED:
    print()
    print(f"{'hint':<8} {'structure retention':>21} {'motion agreement':>19}")
    for label, row in SURVIVED.items():
        print(f"{label:<8} {row['structure_retention']:>21.4f} "
              f"{row['motion_agreement']:>19.4f}")
''')

# =====================================================================
# Predict-run-explain 2
# =====================================================================
nb.predict_run_explain(
    predict=(
        "Now ask for something the control map forbids. The edge control pins "
        "every outline in the scene; the prompt below asks for the road to be "
        "empty and for the vehicles to be gone. Predict what you get: an empty "
        "road, the original vehicles unchanged, or something in between — and if "
        "in between, what does 'in between' look like?"
    ),
    change=(
        "Nothing to edit. Then decide what you would measure to distinguish your "
        "three candidate answers from each other, before you look."
    ),
    explain=(
        "Compare `structure_retention` for this run against the honest edge run. "
        "If the control still dominated, the number will barely move. Explain "
        "why, in terms of where the control enters the model relative to where "
        "the prompt does."
    ),
    hint=(
        "The control is a per-frame conditioning signal applied throughout "
        "denoising, at every spatial position. The prompt is a single global "
        "text embedding. When they disagree, the one with per-pixel authority "
        "usually wins — but 'usually' is doing work in that sentence and the "
        "interesting part is where it does not."
    ),
)

nb.code('''
forbidden_prompt = {
    "description": ("A completely empty stretch of road. No vehicles, no people, "
                    "no objects of any kind. Bare tarmac and open sky."),
    "subjects": [],
    "scene": {"location": "empty road", "surfaces": "bare tarmac"},
    "lighting": "flat overcast daylight",
    "camera": {"motion": "as in the source", "framing": "unchanged"},
}

forbidden_result = None
if "control_edge" in controls:
    forbidden_spec = transfer_spec("edge", name="transfer_forbidden",
                                   prompt_obj=forbidden_prompt,
                                   num_frames_request=REQUESTED_FRAMES)
    forbidden_result = run_and_verify(forbidden_spec, "augmentation_set",
                                      label="transfer_forbidden")

if forbidden_result is not None and forbidden_result.video_path:
    control = trim_control(controls["control_edge"]["path"], CONTROL_FRAMES)
    value = structure_retention(forbidden_result.video_path, control)
    honest = SURVIVED.get("edge", {}).get("structure_retention", float("nan"))
    print()
    print(f"structure retention, prompt agrees with control    : {honest:.4f}")
    print(f"structure retention, prompt contradicts control    : {value:.4f}")
    print(f"difference                                          : {value - honest:+.4f}")
    print()
    print("A small difference means the control won and the prompt was largely")
    print("ignored where the two conflicted. A large one means the prompt pulled")
    print("the appearance away from the control's structure. Look at the video")
    print("before you decide which story the number is telling.")
    cc.show_video(forbidden_result.video_path, width=520,
                  caption="prompt asks for what the control forbids")
''')

# =====================================================================
# Multi-control
# =====================================================================
nb.md("""
## Multi-control, and an honest note about it

More than one hint can be supplied at once. `TransferArgs.weight` exists to
balance them: each control block carries a `weight`, and the framework
aggregates their attention contributions accordingly. Two controls at weight 1.0
each are not the same as one at 2.0; the weights are relative influence, not
gain.

The honest part: **the cookbook's `transfer/README.md` refers to an
`assets/multi_control/` directory that does not exist in the checkout**
(`COSMOS3_FACTS.md` §7). So there is no shipped example to copy, and this course
will not invent one and present it as documented. What follows builds a
multi-control spec, validates it, and stops there — the mechanism is real and
the example is not.

Two hints on one clip also needs two control maps that agree frame for frame.
If your edge map is 121 frames and your depth map is 101, you have a problem the
validator cannot see, which is the debugging lab you are about to do.
""")

nb.code('''
multi_dir = cc.COOKBOOK / "generator" / "transfer" / "assets" / "multi_control"
print(f"cookbook multi-control directory : {multi_dir}")
print(f"exists                           : {multi_dir.exists()}")
print(f"shipped multi-control spec       : "
      f"{cc.asset_or_none('spec_multi_control') or 'not present'}")
print()
print("The README references it. The checkout does not contain it. Reporting")
print("that gap is more useful than quietly inventing a replacement.")
print()

available = [n.replace("control_", "") for n in controls]
if len(available) >= 2:
    a, b = available[0], available[1]
    multi = cc.InferenceSpec(
        model_mode="video2video", name="multi_control_example",
        prompt=compact(edge_prompt_obj),
        vision_path=str(controls[f"control_{a}"]["path"]),
        resolution=RES, aspect_ratio="16,9", num_frames=REQUESTED_FRAMES,
        fps=24, num_steps=N_STEPS, guidance=7.0, shift=10.0, seed=2026,
        controls={
            a: {"control_path": str(controls[f"control_{a}"]["path"]), "weight": 1.0},
            b: {"control_path": str(controls[f"control_{b}"]["path"]), "weight": 0.5},
        },
    )
    print(json.dumps(multi.to_dict(), indent=2)[:900])
    print()
    print("validate_spec:", cc.validate_spec(multi, strict=False) or "no problems")
    print()
    frames = {k: controls[f"control_{k}"]["frames"] for k in (a, b)}
    print(f"control frame counts: {frames}")
    if len(set(frames.values())) > 1:
        print("  These disagree. Two controls of different lengths on one run is")
        print("  not something the validator checks, and it is the next section.")
else:
    print("Need at least two control assets present to build a multi-control example.")
''')

# =====================================================================
# Debugging lab
# =====================================================================
nb.md("""
## Debugging lab — the control your spec disagrees with

### Symptom

You built an augmentation set. Every spec says `num_frames: 61`. Every run
exited 0. Every output passed `check_video`. You loaded the set into a training
pipeline and it rejected half of it for having the wrong sequence length — and
when you looked, your clips were not 61 frames. Some were 121. One was 17.

Nothing in your generation pipeline reported a problem, because from its point
of view there was not one. The control videos had different lengths, and the
outputs followed the controls.

The lab below reproduces this on purpose with a very short control, so it costs
minutes rather than an afternoon.
""")

nb.code('''
# Deliberately wrong: a 17-frame control with a spec asking for 61 frames.
SHORT_FRAMES = 17
mismatch_result = None
if "control_edge" in controls:
    short_control = trim_control(controls["control_edge"]["path"], SHORT_FRAMES)
    print("control:", json.dumps(probe_video(short_control), indent=2))
    mismatch_spec = transfer_spec("edge", name="transfer_mismatch",
                                  prompt_obj=edge_prompt_obj,
                                  num_frames_request=61,
                                  control_override=short_control)
    print()
    print("validate_spec:", cc.validate_spec(mismatch_spec, strict=False) or "no problems")
    print()
    print("The validator is happy. It checks that num_frames is legal for the")
    print("tier; it has no way to know what is inside the control file.")
    print()
    mismatch_result = run_and_verify(mismatch_spec, "debug", label="transfer_mismatch")
''', tags=["teaching-antipattern"])

nb.md("""
### Hypothesis, diagnosis, repair

Hypothesis: the output frame count equals the **control's** frame count, not the
spec's.

The diagnostic is three numbers side by side — what you asked for, what the
control contains, what came out. Two of the three will agree, and which two is
the whole answer. Note that this diagnosis needs no GPU and no model: it is
`ffprobe` on files you already have, which means it belongs at the *front* of
your pipeline as a precondition, not at the back as a post-mortem.

The repair is to stop specifying the frame count at all and derive it from the
control. A number you derived cannot disagree with the thing you derived it
from. `assert_control_matches` below is the shape of the check to put in a
pipeline — it fails before a run rather than after one, which on a 40-minute
transfer is the difference between a nuisance and a lost morning.
""")

nb.code('''
def diagnose_frames(result, spec, control_path):
    """Compare requested, control and produced frame counts."""
    requested = spec.num_frames if hasattr(spec, "num_frames") else None
    control_n = probe_video(control_path)["frames"]
    produced_n = probe_video(result.video_path)["frames"] if (
        result is not None and result.video_path) else None
    print(f"  requested (spec)  : {requested}")
    print(f"  control video     : {control_n}")
    print(f"  produced output   : {produced_n}")
    if produced_n is None:
        print("  -> the run produced no video; this is a different failure")
    elif produced_n == control_n and produced_n != requested:
        print("  -> the output followed the CONTROL. Your spec's num_frames was ignored.")
    elif produced_n == requested and produced_n != control_n:
        print("  -> the output followed the SPEC on this build. Record that; it")
        print("     contradicts the documented behaviour and is worth an issue.")
    else:
        print("  -> all three agree, or none do. Read the run log.")
    return {"requested": requested, "control": control_n, "produced": produced_n}


def assert_control_matches(control_path, num_frames=None, fps=None):
    """Precondition for a transfer run. Raises BEFORE anything expensive."""
    info = probe_video(control_path)
    problems = []
    if num_frames is not None and info["frames"] not in (None, num_frames):
        problems.append(f"control has {info['frames']} frames, spec asks for {num_frames}. "
                        f"The output will follow the control.")
    if fps is not None and info["fps"] and abs(info["fps"] - fps) > 0.51:
        problems.append(f"control is {info['fps']} fps, spec asks for {fps} fps. "
                        f"Duration will not be what you expect.")
    if problems:
        raise ValueError("control/spec mismatch:\\n  - " + "\\n  - ".join(problems))
    return info


if mismatch_result is not None:
    print("mismatched run:")
    diagnose_frames(mismatch_result, mismatch_spec, short_control)
    print()
    try:
        assert_control_matches(short_control, num_frames=61)
    except ValueError as exc:
        print("precondition check, run BEFORE launching:")
        print(f"  {exc}")
elif "control_edge" in controls:
    print("The mismatch run was skipped (read-only path), but the precondition")
    print("check needs no GPU. Here it is on the files you already have:")
    try:
        assert_control_matches(trim_control(controls["control_edge"]["path"], SHORT_FRAMES),
                               num_frames=61)
    except ValueError as exc:
        print(f"  {exc}")
''')

nb.code('''
repaired_result = None
if "control_edge" in controls:
    control = trim_control(controls["control_edge"]["path"], CONTROL_FRAMES)
    info = probe_video(control)
    derived_frames = info["frames"]
    print(f"deriving num_frames from the control: {derived_frames}")

    repaired_spec = transfer_spec("edge", name="transfer_repaired",
                                  prompt_obj=edge_prompt_obj,
                                  num_frames_request=derived_frames,
                                  control_override=control)
    assert_control_matches(control, num_frames=repaired_spec.num_frames)
    print("precondition passes: spec and control agree before we spend anything")
    print()
    repaired_result = run_and_verify(repaired_spec, "debug", label="transfer_repaired")
    if repaired_result is not None:
        print()
        print("repaired run:")
        diagnose_frames(repaired_result, repaired_spec, control)
''')

nb.checkpoint(
    "You should have at least one verified transfer output and a recorded answer "
    "to the frame-count question. On the read-only path you should still have "
    "control geometry for every shipped hint and a working precondition check.",
    '''
print(f"transfers run   : {len(RUNS)}")
verified = [n for n, e in RUNS.items()
            if e["result"] is not None
            and all(c.passed for c in cc.verify_result(e["result"], verbose=False))]
print(f"verified        : {len(verified)}  {verified}")
print(f"controls probed : {len(controls)}  {sorted(controls)}")
print(f"survival metrics: {sorted(SURVIVED)}")
if not RUN:
    print()
    print("Read-only path. Everything above is real; the transfers were not run.")
''')

# =====================================================================
# Exercises
# =====================================================================
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "Two controls, one clip, one table",
    goal=(
        "Tabulate concretely what changes between two control hints on the same "
        "source, so that the table in this lesson stops being something you read "
        "and becomes something you verified."
    ),
    instructions=(
        "1. Pick two hints you have not already compared directly.\n"
        "2. Run both with the **same prompt** — not the shipped per-hint prompts, "
        "which differ from each other and would confound the comparison.\n"
        "3. Derive `num_frames` from each control rather than typing it.\n"
        "4. Build a table with one row per hint: structure retention, motion "
        "agreement, output geometry, wall clock, peak VRAM.\n"
        "5. Add a column that is *your own* judgement on a stated three-point "
        "scale — for example how well object identity survived — and say what "
        "your scale means before you score anything.\n"
        "6. Write two sentences on where your judgement and the numbers "
        "disagreed."
    ),
    success=(
        "A table with at least five columns and two rows, both runs verified, "
        "the shared prompt shown, and a written note on a disagreement between "
        "your eyes and a metric."
    ),
    starter='''
PAIR = ["blur", "depth"]        # or any two you have control videos for
SHARED_PROMPT = {
    "description": "The same scene under warm low evening sun with long shadows.",
    "lighting": "warm low sun from the left, long shadows, golden cast",
    "style": "documentary realism, natural colour",
}

comparison = []
for hint in PAIR:
    key = f"control_{hint}"
    if key not in controls:
        print(f"{hint}: control missing — run scripts/fetch_assets.py")
        continue
    # control = trim_control(controls[key]["path"], CONTROL_FRAMES)
    # derived = probe_video(control)["frames"]
    # spec = transfer_spec(hint, name=f"cmp_{hint}", prompt_obj=SHARED_PROMPT,
    #                      num_frames_request=derived, control_override=control)
    # res = run_and_verify(spec, "compare", label=f"cmp_{hint}")
    # comparison.append({...})
    pass

print(f"{len(comparison)} row(s)")
''',
    hints=[
        "Using the shipped per-hint prompts would be the obvious shortcut and it "
        "invalidates the comparison: you would be measuring the difference "
        "between two prompts as well as two controls. One shared prompt, chosen "
        "so it is plausible for both.\n\n"
        "Score your three-point scale on the videos *before* you print the "
        "metric table. Once you have seen a number it is very hard to judge "
        "independently of it.",
    ],
    solution_ref="solutions/08_solutions.ipynb",
)

nb.exercise(
    "applied",
    "Make your own control map",
    goal=(
        "Generate an edge control from an arbitrary video with ffmpeg or OpenCV, "
        "and drive a transfer with it. This is what turns transfer from a demo "
        "into something you can point at your own footage."
    ),
    instructions=(
        "1. Take any video you have. `cc.asset('video_car_driving_plain')` works "
        "if you have nothing else, and so does a clip you generated in Lesson 07.\n"
        "2. Produce an edge map from it. `cv2.Canny` per frame is the "
        "straightforward route; ffmpeg's `edgedetect` filter is the "
        "no-Python-dependency route. Either is fine; say which you used.\n"
        "3. Encode the result as a video whose frame count and frame rate match "
        "the source **exactly**. Verify with `probe_video` rather than assuming.\n"
        "4. Run a transfer with it, deriving `num_frames` from your own control, "
        "and passing `assert_control_matches` before launching.\n"
        "5. Report `structure_retention` against your control, and compare it "
        "against the figure the shipped cookbook control achieved. If yours is "
        "much lower, diagnose it: thresholds too tight, too much compression, "
        "wrong colour space, or a genuine frame misalignment.\n"
        "6. State what you would change about your edge extraction for a real "
        "augmentation run."
    ),
    success=(
        "A control video you generated, passing `assert_control_matches`, "
        "driving a verified transfer, with `structure_retention` reported "
        "alongside the cookbook control's figure and a diagnosis of any gap."
    ),
    starter='''
def make_edge_control(src, dst, *, low=100, high=200):
    """Turn a video into a Canny edge map with the same length and frame rate.

    Two failure modes to guard against, because both are silent:
      * dropping or duplicating a frame, which misaligns everything after it;
      * compressing thin lines away, which weakens the conditioning without
        producing any error.
    """
    raise NotImplementedError


SOURCE = cc.asset_or_none("video_car_driving_plain")
MY_CONTROL = OUTPUT_DIR / "controls" / "my_edge.mp4"

# make_edge_control(SOURCE, MY_CONTROL)
# print(probe_video(SOURCE))
# print(probe_video(MY_CONTROL))
# assert_control_matches(MY_CONTROL, num_frames=probe_video(SOURCE)["frames"])
''',
    hints=[
        "Read and write with the same library. Mixing an OpenCV reader with an "
        "imageio writer is where the off-by-one frame counts come from, and a "
        "one-frame offset in a control map is invisible in a still and obvious "
        "in motion.\n\n"
        "Encode at a high quality setting — `-crf 10` or lower, or a lossless "
        "codec. The default settings are tuned for natural images and treat "
        "one-pixel-wide white lines on black as noise to be removed.",
    ],
    solution_ref="solutions/08_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "An augmentation pipeline with a quality gate",
    goal=(
        "Produce N screened variants of one clip across controls and prompts, "
        "with an automated gate, and a report on which combinations failed and "
        "why they failed."
    ),
    instructions=(
        "1. Define the variation space: at least two controls and at least four "
        "prompt variations, giving eight or more combinations. Cost it with your "
        "Lesson 06 calibration **before** running anything, and say what you cut "
        "to make it affordable.\n"
        "2. Write `augment(control, prompt, seed)` that builds the spec, runs the "
        "precondition check, runs the transfer, and returns a record containing "
        "the spec, the output path, the check results and the survival metrics.\n"
        "3. Write `gate(record)` — an automated quality gate combining "
        "`cc.verify_result`, a `motion_agreement` floor you choose and justify, "
        "and a geometry check. It must return a reason, not just a boolean.\n"
        "4. Run the set unattended. Log every failure with its gate reason.\n"
        "5. Report: overall yield, yield per control, yield per prompt, and the "
        "single most common failure reason. Then say which of your gate "
        "thresholds you would move, in which direction, and what that would cost "
        "you in false accepts.\n"
        "6. Write the honest limitations paragraph. Every variant shares one "
        "camera trajectory and one scene layout — say what that means for a "
        "model trained on the set, and what real data you would still need."
    ),
    success=(
        "N ≥ 8 attempted variants, a gate that returns reasons, a per-control and "
        "per-prompt yield table, a stated threshold you would move with its "
        "consequence, and a limitations paragraph that names the shared-structure "
        "problem."
    ),
    starter='''
CONTROLS = ["edge", "depth"]
PROMPT_VARIANTS = {
    # "night": {...}, "rain": {...}, "snow": {...}, "dusk": {...},
}

def augment(hint, prompt_name, prompt_obj, seed=0):
    """One variant: precondition, run, verify, measure. Returns a record."""
    raise NotImplementedError


def gate(record):
    """Automated quality gate. Return (passed: bool, reason: str)."""
    raise NotImplementedError


def report(records):
    """Yield overall, per control, per prompt; plus the top failure reason."""
    raise NotImplementedError
''',
    hints=[
        "Cost the design first. Two controls by four prompts is eight transfers, "
        "and your calibration will tell you in minutes what that means. If it is "
        "more than you have, cut prompts rather than controls — the control axis "
        "is the one carrying the pedagogical content.",
        "A gate that returns `False` teaches you nothing. A gate that returns "
        "`(False, 'motion_agreement 0.11 below floor 0.35')` lets you see, at "
        "the end, that one control was responsible for most rejections — which "
        "is the actual finding.",
    ],
    solution_ref="solutions/08_solutions.ipynb",
)

# =====================================================================
# Assessment
# =====================================================================
nb.md("""
## Assessment and reflection

### Knowledge check

1. Write the two things that make a spec a transfer spec. Not three things.
2. Someone tells you their transfer run failed with "unknown model_mode:
   transfer". What did they do, and what is the one-line fix?
3. For each of `edge`, `blur`, `depth` and `seg`: name one thing it preserves
   and one thing it deliberately discards.
4. What is `wsm`, and why does it appear in one of this course's hint lists and
   not the other?
5. Your spec says 61 frames, your control has 121, and the output has 121.
   Explain why, and give the check that would have caught it before the run.
6. Why is `structure_retention` a poor way to rank `edge` against `seg`?
7. State the synthetic-data argument in three sentences, then state its main
   limitation in one.
8. `Cosmos3-Edge` and the `edge` hint. Which can do which?
9. Multi-control is documented and its example assets are missing. What do you
   do — and what do you write down?

### Practical completion test

1. Verify from your own installation that `transfer` is not a model mode.
2. Run at least one transfer and verify it by content.
3. Report the control geometry of every shipped hint on your disk.
4. Reproduce the frame-count mismatch and diagnose it from the output.
5. Repair it by deriving the frame count from the control, and show the
   precondition check passing.
""")

nb.code('''
def lesson_08_complete():
    passed, notes = [], []

    assert "transfer" not in cc.MODEL_MODES, "the enum should not contain 'transfer'"
    assert "video2video" in cc.MODEL_MODES
    passed.append("verified from the installed package: transfer is not a mode")

    problems = cc.validate_spec(
        {"model_mode": "text2video", "name": "x", "prompt": "y",
         "edge": {"control_path": "c.mp4"}}, strict=False)
    assert any("video2video" in p for p in problems), \\
        "the validator did not reject a hint on the wrong mode"
    passed.append("the validator enforces hint + video2video")

    if controls:
        passed.append(f"probed {len(controls)} control video(s): "
                      + ", ".join(f"{k.replace('control_', '')}={v['frames']}f"
                                  for k, v in controls.items()))
    else:
        notes.append("no control videos on disk — run scripts/fetch_assets.py")

    verified = [n for n, e in RUNS.items()
                if e["result"] is not None
                and all(c.passed for c in cc.verify_result(e["result"], verbose=False))]
    if verified:
        passed.append(f"{len(verified)} verified transfer(s): {', '.join(verified)}")
    else:
        notes.append("no verified transfers — read-only path, or the runs failed")

    if mismatch_result is not None:
        facts = diagnose_frames(mismatch_result, mismatch_spec, short_control)
        assert facts["produced"] is not None, "the mismatch run produced no video"
        passed.append(f"frame-count mismatch reproduced: asked {facts['requested']}, "
                      f"control {facts['control']}, got {facts['produced']}")
    else:
        notes.append("frame-count mismatch not reproduced (read-only path)")

    if SURVIVED:
        passed.append(f"survival metrics for {len(SURVIVED)} hint(s)")

    for item in passed:
        print(f"  PASS  {item}")
    for item in notes:
        print(f"  ----  {item}")
    return passed, notes


_ = lesson_08_complete()
''')

nb.md("""
### Summary

- **Transfer is `model_mode: "video2video"` plus a control-hint block.** There
  is no `transfer` mode. The framework detects the block and takes that path.
- Four hints: `edge` (shape and layout), `blur` (colour and lighting), `depth`
  (3D structure), `seg` (object identity). Each is a lossy summary of the source,
  and **what it discards is what you are free to change**.
- `wsm` uses the same mechanism, ships as a cookbook asset family, and is not a
  member of the enum.
- Only **Cosmos3-Nano** can do transfer. Edge cannot, Super cannot. The `edge`
  hint and the `Cosmos3-Edge` tier are unrelated and easy to confuse.
- **The control video decides the output's frame count, frame rate and
  geometry.** Derive `num_frames` from the control; never type it.
- A control/spec mismatch is a clean-exit failure. `check_video` passes, the
  file is fine, the length is wrong. Check it as a precondition, before you
  spend the compute.
- Measure what survived with metrics you can explain, and state their biases.
  `structure_retention` favours `edge` by construction; `motion_agreement` is the
  fairer cross-hint comparison.
- The synthetic-data argument: one recording becomes many on-distribution
  variants whose geometry, motion and timing are pinned, so existing labels stay
  correct. The limitation: they all share one camera and one layout.
- Multi-control is real and its shipped example is missing. Report the gap.

### Common misconceptions

| Belief | Correction |
|---|---|
| "Transfer is a model mode" | It is `video2video` plus a hint block. Check the enum. |
| "`edge` is for the Edge model" | Unrelated. The Edge tier is the one tier that cannot run any hint. |
| "The control is a style reference" | It is a per-frame structural constraint applied throughout denoising. |
| "`num_frames` controls the output length" | The control video does. Your value is ignored or overridden. |
| "`check_video` passed, so the clip is usable" | It has structure and it moves. Its length, geometry and adherence are separate questions. |
| "More controls is more control" | Two conflicting controls fight, and their weights are relative influence, not gain. |
| "A hundred variants is a hundred training clips" | It is one clip with a hundred appearances. Say so in your report. |
| "The cookbook README lists it, so it exists" | `assets/multi_control/` does not. Verify before you build on it. |

### Suggested extensions

- Sweep `weight` on a single control from 0.1 to 2.0 and find where the
  conditioning stops mattering and where it starts fighting the prompt.
- Feed the *output* of one transfer back as the source for an edge map and run a
  second transfer on it. Two generations deep, measure how much of the original
  geometry survives.
- Take a clip with a known bounding-box annotation, transfer it, and check by
  eye whether the box is still correct on the variant. That is the claim the
  synthetic-data argument rests on, and it is worth testing rather than
  assuming.

### Mastery checklist

- [ ] I can write a transfer spec from scratch without looking it up.
- [ ] I verified against my own enum that `transfer` is not a mode.
- [ ] I can match each hint to what it preserves and what it discards.
- [ ] I demonstrated that the control decides the output geometry.
- [ ] I have a precondition check that runs before the expensive part.
- [ ] I measured what survived, and I can state each metric's bias.
- [ ] I can state the synthetic-data argument and its main limitation.

### Next

Lesson 09 adds sound, and then introduces the component that has been silently
sitting in every run you have done so far: the guardrail. It is the one gated
repository in the whole Cosmos 3 stack, it is on by default, and when it rejects
something it does so with a return code of zero. That last fact is the strongest
argument this course can make for `cosmos_course.checks`.

## Free the card, and say why

Nano is a 16B checkpoint and the runs above have been the heaviest in the course
so far. The generator ran as a subprocess so the operating system reclaimed its
VRAM on exit — but a transfer that timed out may have left a worker behind, and
an orphaned worker holding 30 GB looks exactly like a healthy machine until the
next launch fails for no visible reason.
""")

nb.code('''
import gc

gc.collect()
try:
    import torch as _torch
    if _torch.cuda.is_available():
        _torch.cuda.empty_cache()
        free_b, total_b = _torch.cuda.mem_get_info()
        print(f"device: {free_b / 1e9:.1f} GB free of {total_b / 1e9:.1f} GB")
        if free_b / total_b < 0.7:
            print()
            print("Under 70% free while this kernel holds almost nothing. Look for an")
            print("orphan:   ps aux | grep cosmos_framework   then   nvidia-smi")
except Exception as exc:
    print(f"could not read device memory: {type(exc).__name__}: {exc}")

print()
print(f"outputs/08          : {dir_size_gb(OUTPUT_DIR):.2f} GB")
print(f"Nano in the HF cache: "
      f"{dir_size_gb(hf_cache_dir(cc.MODEL_TIERS['Cosmos3-Nano']['hf_repo'])):.1f} GB")
print()
print("Keep the Nano weights: Lesson 09 needs them, and re-downloading 34.9 GB to")
print("save disk you were not short of is a poor trade. The generated videos are")
print("the disposable part — scripts/cleanup.sh removes those and leaves the cache.")
''')

nb.md(FOOTER_MD)

nb.write(ROOT / "08_generation_control.ipynb")
