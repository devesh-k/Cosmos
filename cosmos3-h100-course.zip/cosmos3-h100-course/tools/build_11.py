"""Build 11_action_inverse_dynamics.ipynb.

Derived from the source DLI course `S-OV-57-V1`, notebook 04, cells 11-15:
inverse dynamics on an AV clip, then `pose_rel_to_abs` and a 3-D trajectory plot.

The source drops a 60-line `visualize_pose` block and a one-line call to
`pose_rel_to_abs(poses_rel, rotation_format="rot6d",
pose_convention="backward_framewise", translation_scale=1.35)` with no
explanation of any argument. This lesson teaches the mathematics first, has the
learner implement the integration themselves, and only then compares against the
framework's version.

Verified against upstream `main` (August 2026),
`cosmos_framework/data/generator/action/utils/pose_utils.py`:
  * `pose_rel_to_abs(poses_rel, rotation_format="rot9d",
    pose_convention="backward_framewise", initial_pose=None,
    normalize_rotation=True, translation_scale=1.0, rotation_scale=1.0)`
  * `backward_framewise` encodes `delta_T = T_i^{-1} @ T_{i+1}` and decodes
    `T_{i+1} = T_i @ delta_T`
  * translation is DIVIDED by `translation_scale` on decode
  * rot6d decode is `col2 = cross(col0, col1)` followed by an optional SVD
    projection onto SO(3) with a determinant fix — not textbook Gram-Schmidt
  * the module has MOVED: the source notebook's
    `cosmos_framework.data.vfm.action.pose_utils` is no longer the path. The
    notebook probes both rather than hard-coding either.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 11 — Inverse dynamics and pose mathematics")

# --------------------------------------------------------------- title block
nb.md("""
# Lesson 11 — Inverse dynamics and pose mathematics

**What you will build.** `outputs/11/` containing a recovered camera trajectory
from a real clip, your own from-scratch implementation of relative-to-absolute
pose integration reconciled against the framework's, a 3-D and bird's-eye plot,
and a quantified round-trip comparison.

| | |
|---|---|
| **Time** | ~105 minutes |
| **GPU** | 1 × H100 80 GB. Cosmos3-Nano, already downloaded in Lesson 10. |
| **Downloads** | None if you completed Lesson 10. |
| **Prerequisites** | Lesson 10. You should be able to read a 9-D action vector. |

Lesson 10 gave the model actions and asked what would happen. This lesson asks
the opposite question — *given this video, what actions produced it?* — and in
answering it confronts the pose mathematics that Lesson 10 stood carefully next
to.
""")

# ---------------------------------------------------------------- objectives
nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Write** an `inverse_dynamics` spec and explain why it has no `action_path`.
2. **Read** a 4×4 homogeneous transform: which block is rotation, which column
   is translation, which column is the heading, and what multiplying two of them
   means.
3. **Implement** relative-to-absolute pose integration from first principles,
   and **reconcile** your implementation against the framework's to within a
   stated tolerance.
4. **Explain** `rotation_format`, `pose_convention` and `translation_scale`, and
   **prove** that `translation_scale` changes the size of a trajectory and not
   its shape.
5. **Plot** a recovered camera path in 3-D with frustums and as a bird's-eye
   view, and **diagnose** a plot drawn with the wrong vertical axis.
6. **Quantify** a round trip — inverse dynamics then forward dynamics — against
   the original clip, and say what the residual does and does not tell you.
""")

# ------------------------------------------------------------- environment
# The configuration cell runs before the mathematics, not after it. The pose
# sections that follow each end in a few lines of arithmetic you can check by
# hand, and none of them needs the GPU or the checkpoint — so the download
# gate stays where it is, further down, after the theory.
nb.md("""
## Environment

Configuration first, before the mathematics, because everything below reads from
it. Same cell as Lesson 10: it finds the course root, imports `cosmos_course`,
detects your GPU and creates `outputs/11/`. Nothing downloads here, and the
opt-in for Cosmos3-Nano comes later, once the theory is behind you. If you
completed Lesson 10 the checkpoint is already cached.
""")

nb.code('__lesson__ = "11"   # OUTPUT_DIR resolves to outputs/11\n\n' + SETUP_CELL)

# ---------------------------------------------------- conceptual foundation 1
nb.md("""
## The inverse question

Forward dynamics: frame plus actions in, video out. Inverse dynamics: video in,
actions out. Same checkpoint, same entry point, one field changed.

The spec loses `action_path`, because the action is now the thing being
predicted rather than the thing being supplied. Everything else stays: you still
declare `domain_name`, because the model still needs to know which embodiment's
action space to answer in, and you still declare `fps` and `image_size`, because
the meaning of "one step" depends on the frame rate.

The output is not a video. It lands in `sample_outputs.json`, at
`outputs[0].content["action"]`, as a `[T−1, 9]` array of relative pose deltas —
one row per transition between consecutive frames, which is exactly the
definition of an action token from Lesson 10. `T−1` rather than `T` because
there are one fewer gaps than frames.

And a `[T−1, 9]` array of deltas is not a trajectory yet. Turning it into one is
the rest of this lesson.

The claim about the missing field is checkable without a GPU. Do that now.
""")

nb.code('''
# The two specs side by side, before either of them runs. The paths here are
# placeholders -- the real ones come from cc.asset() further down -- because
# what matters at this point is which KEYS the framework receives.
fwd_shape_spec = cc.InferenceSpec(
    model_mode="forward_dynamics", name="shape_demo_forward",
    vision_path="start_frame.jpg", action_path="trajectory.json",
    domain_name="av", view_point="ego_view", action_chunk_size=30,
    fps=10, image_size=480,
)
inv_shape_spec = cc.InferenceSpec(
    model_mode="inverse_dynamics", name="shape_demo_inverse",
    vision_path="clip.mp4",
    domain_name="av", view_point="ego_view", action_chunk_size=30,
    fps=10, image_size=480,
)

fwd_keys = set(fwd_shape_spec.to_dict())
inv_keys = set(inv_shape_spec.to_dict())

print("forward_dynamics sends:", sorted(fwd_keys))
print()
print("inverse_dynamics sends:", sorted(inv_keys))
print()
print("in forward and not in inverse:", sorted(fwd_keys - inv_keys))
print("in inverse and not in forward:", sorted(inv_keys - fwd_keys))

assert fwd_keys - inv_keys == {"action_path"}
print()
print("One field. Everything describing the embodiment and the sampling rate")
print("stays, because the model still has to answer in the right units.")
''')

# ---------------------------------------------------- conceptual foundation 2
nb.md("""
## Homogeneous transforms, from zero

Almost everything from here to the end of the theory is arithmetic you can check
by hand, and each section finishes with a cell that does. That is deliberate.
Pose bugs are silent: a wrong convention produces a trajectory that plots
without error and is completely wrong, and the only defence is being able to
verify small cases yourself.

A **pose** is a position and an orientation together. Writing them as separate
objects is a nuisance, because composing two poses then needs two different
rules. The homogeneous 4×4 matrix packs both into one object with one rule.

```
        +-           -+
        |  R      t   |     R is 3x3, a rotation
   T =  |  (3x3) (3x1)|     t is 3x1, a position
        |  0      1   |     bottom row is always [0 0 0 1]
        +-           -+
```

Three things to read off it, and you will use all three constantly:

| Slice | What it is |
|---|---|
| `T[:3, :3]` | the rotation block |
| `T[:3, 3]` | the position — where the camera is |
| `T[:3, 2]` | the third **column** of R: which way the camera is *looking* |

Why is column 2 the heading? Because the columns of a rotation matrix are the
images of the coordinate axes. Column 0 is where the camera's local +X points in
world coordinates, column 1 is local +Y, column 2 is local +Z. Cosmos 3 uses the
**+Z-forward** camera convention — the camera looks down its own +Z axis — so
column 2 is the viewing direction expressed in world coordinates.
""")

nb.code('''
# One pose, built by hand, read three ways. NumPy is imported here rather than
# assumed: the configuration cell above does not import it.
import numpy as np

T_demo = np.eye(4)
T_demo[:3, 3] = [5.0, 0.0, 0.0]      # five units along world X, facing world +Z

print("T_demo, a camera-to-world pose:")
print(T_demo)
print()
print("rotation block  T[:3, :3] :")
print(T_demo[:3, :3])
print()
print(f"position        T[:3, 3]  : {T_demo[:3, 3]}")
print(f"heading         T[:3, 2]  : {T_demo[:3, 2]}   (+Z forward)")
print(f"bottom row      T[3, :]   : {T_demo[3, :]}")

assert np.allclose(T_demo[3, :], [0.0, 0.0, 0.0, 1.0]), "that is not a pose"
print()
print("The bottom row is the cheapest sanity check you have. If it is not")
print("[0 0 0 1] you are holding something that is not a pose.")
''')

nb.md("""
### Composition is matrix multiplication

If `T` is a pose and `D` is a small movement expressed **in the moving frame's
own coordinates**, then the new pose is `T @ D`. Multiplying on the right means
"relative to where I am now". Multiplying on the left, `D @ T`, would mean
"relative to the world origin" — a different and usually wrong thing.

Write it out and the two parts fall into place:

```
   T @ D  =  [ R_T  t_T ] [ R_D  t_D ]  =  [ R_T R_D    R_T t_D + t_T ]
             [  0    1  ] [  0    1  ]     [    0             1       ]
```

The new orientation is the old one composed with the turn. The new position is
the old position **plus the step rotated into world coordinates** — which is why
driving forward one metre moves you in a different world direction depending on
which way you were facing. That single term is the entire reason poses cannot be
added.
""")

nb.code('''
# The same two matrices in both orders. A quarter turn about the camera's own Y
# axis, plus one unit forward along the camera's own +Z. D is a delta: it says
# how you moved, and nothing about where you were.
theta = np.radians(90.0)
R_yaw = np.array([[np.cos(theta),  0.0, np.sin(theta)],
                  [0.0,            1.0, 0.0],
                  [-np.sin(theta), 0.0, np.cos(theta)]])

D_demo = np.eye(4)
D_demo[:3, :3] = R_yaw
D_demo[:3, 3] = [0.0, 0.0, 1.0]        # one unit forward IN THE MOVING FRAME

right = T_demo @ D_demo                # "relative to where I am now"
wrong = D_demo @ T_demo                # "relative to the world origin"

print(f"started at            : {T_demo[:3, 3]}")
print(f"T @ D  position       : {np.round(right[:3, 3], 6)}")
print(f"D @ T  position       : {np.round(wrong[:3, 3], 6)}")
print()
print(f"T @ D  heading        : {np.round(right[:3, 2], 6)}   (was [0 0 1])")

assert np.allclose(right[:3, 3], [5.0, 0.0, 1.0])
assert not np.allclose(right[:3, 3], wrong[:3, 3])
print()
print("One step of one unit was taken. Only one of those two positions is one")
print("unit from where you started, and matrix multiplication will not tell you")
print("which — it is happy to compute either.")
''')

nb.md("""
### Camera-to-world, and its inverse

A pose is a map between two coordinate systems, and it matters which way round.

- **Camera-to-world** (`T_cw`): give it a point in camera coordinates, get world
  coordinates. Its translation column is the camera's position in the world.
- **World-to-camera** (`T_wc = T_cw⁻¹`): the map a renderer needs. Its
  translation column is *not* the camera position, and reading it as one gives
  you a mirrored, rotated path that looks superficially plausible.

Everything in this lesson is camera-to-world. The framework returns
camera-to-world, and `plot_camera_trajectory` reads position from `[:3, 3]`
accordingly.
""")

nb.callout("gotcha", """
`T_cw⁻¹` is not `T_cw` transposed. The rotation block inverts by transposing,
but the translation does not: `T⁻¹ = [[Rᵀ, −Rᵀt], [0, 1]]`. Using `T.T` on a
4×4 pose produces a matrix whose bottom row is no longer `[0 0 0 1]`, which is
the fastest way to notice you have done it.
""")

nb.code('''
# Build the inverse from the formula, then check it against the definition: a
# pose composed with its inverse is the identity, or it is not an inverse.
R_demo = right[:3, :3]
t_demo = right[:3, 3]

T_inv_demo = np.eye(4)
T_inv_demo[:3, :3] = R_demo.T
T_inv_demo[:3, 3] = -R_demo.T @ t_demo

print("T_cw @ T_wc, which should be the identity:")
print(np.round(right @ T_inv_demo, 9))
print()
print(f"camera position, from T_cw[:3, 3] : {np.round(t_demo, 4)}")
print(f"translation column of T_wc        : {np.round(T_inv_demo[:3, 3], 4)}")
print("                                     ^ not the camera position")
print()
print(f"bottom row of T.T (the shortcut)  : {right.T[3, :]}")

assert np.allclose(right @ T_inv_demo, np.eye(4))
assert not np.allclose(right.T[3, :], [0.0, 0.0, 0.0, 1.0])
print()
print("Reading the second line as a position gives you a path that is mirrored")
print("and rotated, plots without error, and is wrong.")
''')

# ---------------------------------------------------- conceptual foundation 3
nb.md("""
## Relative deltas and the `backward_framewise` convention

The model predicts **relative** deltas, not absolute poses. Converting between
the two is a choice, and `pose_convention` names which choice was made. The
framework supports several; the one used throughout the action stack is
`backward_framewise`, which means exactly this:

```
   encode:   D_i  =  T_i⁻¹ @ T_{i+1}          each delta is relative to the previous pose
   decode:   T_{i+1}  =  T_i @ D_i            compose them back up, one at a time
```

`backward_anchored` would instead measure every delta from the **first** pose,
and `backward_chunk_anchored_8f`/`_16f` re-anchor every 8 or 16 steps. Decoding
with the wrong one produces a trajectory that is smooth, plausible, and wrong —
so the convention has to travel with the data.

Why predict relatively at all? Two reasons. Relative deltas are small numbers
near zero, which is a far easier regression target than absolute positions that
grow without bound. And they are translation-invariant: the same manoeuvre has
the same representation wherever in the world it happens, so the model does not
have to learn it separately for every location.

The cost is that errors **compound**. Each pose is built on the previous one, so
a small bias in the deltas becomes a growing drift in the path. You will see
that in the round trip at the end of this lesson, and it is the same mechanism
that makes open-loop control fail in Lesson 13.
""")

nb.code('''
# The convention on two poses: encode a delta the way backward_framewise says,
# decode it back, and check nothing was lost. T0 and T1 are the poses from the
# composition cell above -- T1 is where T0 ended up after one step.
T0_demo = T_demo
T1_demo = right

D_encoded = np.linalg.inv(T0_demo) @ T1_demo     # encode:  D = T0^-1 @ T1
T1_decoded = T0_demo @ D_encoded                 # decode:  T1 = T0 @ D

print("the delta this convention stores:")
print(np.round(D_encoded, 6))
print()
print(f"decoded T1 matches the original : {np.allclose(T1_decoded, T1_demo)}")
print(f"and it is the delta we composed : {np.allclose(D_encoded, D_demo)}")
print()

# Apply the SAME delta twice. The second application lands somewhere the first
# did not, because it is applied in the frame the first one left you in.
T2_demo = T1_demo @ D_encoded
print(f"pose 0 position : {np.round(T0_demo[:3, 3], 4)}")
print(f"pose 1 position : {np.round(T1_demo[:3, 3], 4)}")
print(f"pose 2 position : {np.round(T2_demo[:3, 3], 4)}")

assert np.allclose(D_encoded, D_demo)
assert np.allclose(T1_decoded, T1_demo)
print()
print("One delta, applied twice, moved you along two different world")
print("directions. That is what translation-invariant buys, and it is also why")
print("an error in an early delta moves every pose after it.")
''')

# ------------------------------------------------------------- environment
nb.md("""
### The checkpoint, the framework and the assets

The theory is behind you, so now the parts that cost something. The next cell
opts in to Cosmos3-Nano, checks that the framework is usable from this kernel,
and confirms the cookbook clips are on disk. It stops with an explanation rather
than failing halfway through a model load.
""")

nb.code('''
import json
import subprocess

import numpy as np

from cosmos_course.models import Generator

ACTION_MODEL = "Cosmos3-Nano"
tier = cc.MODEL_TIERS[ACTION_MODEL]
ALLOW_NANO_DOWNLOAD = os.environ.get("COSMOS_COURSE_ALLOW_NANO", "0") == "1"

print(f"checkpoint     : {tier['hf_repo']}  ({tier['download_gb']} GB, "
      f"{tier['inference_vram_gb']} GB VRAM)")
print(f"already cached : {(Path.home() / '.cache/huggingface/hub').exists()} "
      f"(check du -sh ~/.cache/huggingface for the real answer)")
print(f"ALLOW_NANO_DOWNLOAD = {ALLOW_NANO_DOWNLOAD}")

cc.require(
    ALLOW_NANO_DOWNLOAD,
    "Cosmos3-Nano has not been opted into.",
    fix=("export COSMOS_COURSE_ALLOW_NANO=1 and restart the kernel, or set\\n"
         "        ALLOW_NANO_DOWNLOAD = True above. Lesson 10 covers the download."),
)

gen = Generator(checkpoint=ACTION_MODEL)
cc.require(not gen.check(verbose=True), "The Cosmos Framework is not usable.",
           fix="See scripts/setup.sh, or set COSMOS3_REPO.")

report = cc.check_assets(["av_video", "av_video_2", "av_traj_forward"], verbose=True)
cc.require(not report["missing"], f"Missing assets: {report['missing']}",
           fix="python3 scripts/fetch_assets.py")

MODE_CHUNK = 30 if MODE == "reduced" else 60
TIMEOUT_S = 1800 if MODE == "reduced" else 3600
AV_PROMPT = "You are an autonomous vehicle planning system."
print()
print(f"action_chunk_size for this run: {MODE_CHUNK}   (MODE={MODE})")
''')

nb.md("""
### Talking to the framework's virtualenv

Twice in this lesson you need a fact that lives inside the framework's own
environment — which module holds `pose_rel_to_abs`, and what it returns. This
kernel cannot import the framework; the two environments have different torch
builds on purpose (see the module docstring of `cosmos_course/models.py`).

So ask the framework's interpreter directly, one small question at a time, and
read the answer back as JSON. This is a generally useful technique and worth
having in your hands.
""")

nb.code('''
def framework_eval(snippet, args=(), *, timeout=300):
    """Run a snippet in the framework venv; return stdout. Raises on failure."""
    proc = subprocess.run(
        [str(gen.python), "-c", snippet, *[str(a) for a in args]],
        cwd=str(gen.repo),
        env={**os.environ, "LD_LIBRARY_PATH": "", "PYTHONNOUSERSITE": "1"},
        capture_output=True, text=True, timeout=timeout,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"framework venv failed (exit {proc.returncode}):\\n"
            f"{proc.stderr.strip()[-1500:]}"
        )
    return proc.stdout.strip()

# The source course imports pose_rel_to_abs from
# cosmos_framework.data.vfm.action.pose_utils. On current main it lives at
# cosmos_framework.data.generator.action.utils.pose_utils. Probe, do not assume.
POSE_MODULE_CANDIDATES = [
    "cosmos_framework.data.generator.action.utils.pose_utils",
    "cosmos_framework.data.vfm.action.pose_utils",
]

LOCATE = """
import json, sys
found = []
for name in sys.argv[1:]:
    try:
        mod = __import__(name, fromlist=["pose_rel_to_abs"])
        found.append({"module": name, "has_pose_rel_to_abs": hasattr(mod, "pose_rel_to_abs")})
    except Exception as exc:
        found.append({"module": name, "error": type(exc).__name__})
print(json.dumps(found))
"""

located = json.loads(framework_eval(LOCATE, POSE_MODULE_CANDIDATES))
for entry in located:
    print(entry)

POSE_MODULE = next(
    (e["module"] for e in located if e.get("has_pose_rel_to_abs")), None
)
cc.require(
    POSE_MODULE is not None,
    "Neither known import path for pose_rel_to_abs works in your checkout.",
    fix=("Search for it:  grep -rn 'def pose_rel_to_abs' $COSMOS3_REPO\\n"
         "      Then add the path you find to POSE_MODULE_CANDIDATES. This is "
         "normal;\\n      upstream moves modules and the source course's import "
         "path is already stale."),
)
print()
print(f"pose_rel_to_abs lives in: {POSE_MODULE}")
''')

nb.callout("upstream", """
The source DLI notebook imports `pose_rel_to_abs` from
`cosmos_framework.data.vfm.action.pose_utils`. That path no longer exists on
`main`; the module moved to
`cosmos_framework.data.generator.action.utils.pose_utils`. The cell above
probes both and tells you which one your checkout has, which is the habit worth
keeping: an import path is a fact about your checkout, not about the
documentation.
""")

# ------------------------------------------------------ inverse dynamics run
nb.md("""
## Running inverse dynamics

The spec, with the field that is missing being the interesting part.
""")

nb.code('''
AV_CLIP = cc.asset("av_video")          # av_0.mp4

inv_spec = cc.InferenceSpec(
    model_mode="inverse_dynamics",
    name="av_inverse_0",
    prompt=AV_PROMPT,
    vision_path=str(AV_CLIP),
    # no action_path: the action is the output, not the input
    domain_name="av",
    view_point="ego_view",
    action_chunk_size=MODE_CHUNK,
    fps=10,
    image_size=480,
    seed=0,
)
print(inv_spec.describe())
print()
print("the JSON the framework will receive - note what is NOT in it:")
print(json.dumps(inv_spec.to_dict(), indent=2))
print()
print("required fields for this mode:",
      sorted(cc.specs.REQUIRED_FIELDS["inverse_dynamics"])
      if hasattr(cc, "specs") else "{domain_name, vision_path}")
print()
cc.show_video(AV_CLIP, width=480, caption="av_0.mp4 - the clip to explain")
''')

nb.predict_run_explain(
    predict=(
        "You are about to run inverse dynamics on this clip, then feed the "
        "actions it predicts straight back into forward dynamics from the same "
        "starting frame. Before running either: (a) will the round-trip video "
        "match the original clip frame for frame, roughly, or not at all? "
        "(b) name the *two* separate sources of error in that round trip and say "
        "which you expect to dominate. (c) will the difference between the two "
        "clips grow, shrink, or stay flat as the clip goes on?"
    ),
    change=(
        "Nothing to edit yet. Write your three answers down, then run the "
        "inverse-dynamics cell and everything after it."
    ),
    explain=(
        "You will get a per-frame difference curve at the end of the round trip. "
        "Compare its shape against your answer to (c), and use it to argue which "
        "of your two error sources is dominating. A curve that rises steadily is "
        "evidence of compounding; a curve that is high from frame one is "
        "evidence of something else."
    ),
    hint=(
        "The two sources are not 'the model' and 'noise'. One is the "
        "inverse-dynamics estimate being imperfect; the other is forward "
        "dynamics being a generative model that will invent plausible detail "
        "rather than reproduce the original pixels. They fail in different "
        "ways and the difference curve looks different for each."
    ),
)

nb.code('''
with cc.timer("inverse_dynamics av_0", quiet=True) as t_inv:
    inv_result = gen.run(inv_spec, OUTPUT_DIR / "av_inverse_0",
                         seed=0, timeout=TIMEOUT_S)

cc.verify_result(inv_result)
cc.require(inv_result.ok, "inverse dynamics produced no usable output.",
           fix="Read the diagnosis printed above.")
print()
print(f"wall clock: {t_inv.seconds:.1f} s")
''')

nb.code('''
# The prediction lives at outputs[0].content["action"] in sample_outputs.json.
sample = inv_result.sample_outputs
poses_rel = np.asarray(sample["outputs"][0]["content"]["action"], dtype=np.float64)

print(f"predicted action shape : {poses_rel.shape}   [steps, dims]")
print(f"steps                  : {poses_rel.shape[0]}")
print(f"dims                   : {poses_rel.shape[1]}  (av is 9-D: 3 translation + 6 rotation)")
print()
print("first two steps:")
print(np.round(poses_rel[:2], 5))
print()
print(cc.check_action(poses_rel, expected_dims=9))

(OUTPUT_DIR / "predicted_action.json").write_text(
    json.dumps(poses_rel.tolist())
)
print()
print(f"saved: {OUTPUT_DIR / 'predicted_action.json'}")
''')

# --------------------------------------------------------- implement it first
nb.md("""
## Implement the integration yourself, before looking at theirs

You now have `[T−1, 9]` relative deltas and you want `[T, 4, 4]` absolute poses.
Everything you need is in the conceptual section:

1. Start from the identity: `T_0 = I`. The first pose is the origin because
   there is no absolute information in the data — only differences.
2. For each row, build the delta transform `D_i`:
   - rotation: decode the 6 numbers into a 3×3 matrix;
   - translation: the first 3 numbers, divided by `translation_scale`.
3. Compose: `T_{i+1} = T_i @ D_i`.
4. Stack. You end up with one more pose than you had deltas.

Write it. Then, and only then, compare against the framework's version.
""")

nb.code('''
def rot6d_to_matrix_gram_schmidt(vec6):
    """The textbook 6-D decode (Zhou et al. 2019), by Gram-Schmidt.

    Take the two 3-vectors as the first two columns of a rotation matrix,
    orthonormalise them against each other, and take the cross product for the
    third column. Everything here is forced: given two nearly-perpendicular unit
    vectors there is exactly one proper rotation matrix nearby.
    """
    a = np.asarray(vec6[:3], dtype=np.float64)
    b = np.asarray(vec6[3:6], dtype=np.float64)

    c0 = a / np.linalg.norm(a)                 # normalise the first column
    b_perp = b - (c0 @ b) * c0                 # remove b's component along c0
    c1 = b_perp / np.linalg.norm(b_perp)       # normalise what is left
    c2 = np.cross(c0, c1)                      # third column is forced
    return np.stack([c0, c1, c2], axis=-1)     # COLUMNS, not rows


def my_pose_rel_to_abs(poses_rel, *, translation_scale=1.0, initial_pose=None):
    """Compose relative deltas into absolute camera-to-world poses.

    Returns [T, 4, 4] where T = len(poses_rel) + 1.
    """
    poses_rel = np.asarray(poses_rel, dtype=np.float64)
    current = np.eye(4) if initial_pose is None else np.asarray(initial_pose, float)
    out = [current]

    for row in poses_rel:
        delta = np.eye(4)
        delta[:3, :3] = rot6d_to_matrix_gram_schmidt(row[3:9])
        delta[:3, 3] = row[:3] / translation_scale
        current = current @ delta          # right-multiply: relative to where we are
        out.append(current)

    return np.stack(out)

mine = my_pose_rel_to_abs(poses_rel, translation_scale=1.35)
print(f"deltas in : {poses_rel.shape}")
print(f"poses out : {mine.shape}   (one more pose than deltas)")
print()
print("last pose:")
print(np.round(mine[-1], 4))
''')

nb.md("""
### A worked example you can check on paper

Before trusting a hundred steps, verify three. Drive one unit forward, turn 90°
about the vertical axis, drive one unit forward again. Work out where you end up
before you run the cell.

With +Z forward and +Y up, starting at the origin looking along +Z:

- after step 1 you are at `(0, 0, 1)`, still looking along +Z;
- after the 90° yaw you are still at `(0, 0, 1)` but now looking along +X
  (the rotation matrix `R_y(90°)` has third column `(1, 0, 0)`);
- after step 2 you move one unit along your *new* forward, so you end at
  `(1, 0, 1)`.

If your implementation returns anything else, the bug is in the composition
order or in the column/row convention, and finding it here costs a minute rather
than an afternoon.
""")

nb.code('''
def yaw_rot6d(degrees):
    """Rotation about +Y (the vertical axis), as the first two matrix columns."""
    th = np.radians(degrees)
    R = np.array([
        [np.cos(th), 0.0, np.sin(th)],
        [0.0,        1.0, 0.0       ],
        [-np.sin(th), 0.0, np.cos(th)],
    ])
    return np.concatenate([R[:, 0], R[:, 1]])   # first two COLUMNS

toy = np.array([
    np.concatenate([[0.0, 0.0, 1.0], yaw_rot6d(0)]),    # forward 1, no turn
    np.concatenate([[0.0, 0.0, 0.0], yaw_rot6d(90)]),   # turn 90, no move
    np.concatenate([[0.0, 0.0, 1.0], yaw_rot6d(0)]),    # forward 1, no turn
])

toy_abs = my_pose_rel_to_abs(toy)
for i, T in enumerate(toy_abs):
    print(f"pose {i}: position={np.round(T[:3, 3], 4)}  heading={np.round(T[:3, 2], 4)}")

expected_final = np.array([1.0, 0.0, 1.0])
assert np.allclose(toy_abs[-1][:3, 3], expected_final, atol=1e-9), (
    f"expected to finish at {expected_final}, got {toy_abs[-1][:3, 3]}"
)
print()
print("matches the hand calculation")
''')

# ------------------------------------------------------ reconcile with theirs
nb.md("""
## Now compare against the framework's version

Yours and theirs should agree. Where they do not, one of you is wrong and it is
worth knowing which. Run the framework's `pose_rel_to_abs` in its own
interpreter, on the same input, with the same arguments the source course used.
""")

nb.code('''
FRAMEWORK_POSE = """
import json, sys
import numpy as np
mod = __import__(sys.argv[1], fromlist=["pose_rel_to_abs"])
poses_rel = np.array(json.load(open(sys.argv[2])), dtype=np.float32)
poses_abs = mod.pose_rel_to_abs(
    poses_rel,
    rotation_format="rot6d",
    pose_convention="backward_framewise",
    translation_scale=float(sys.argv[3]),
)
print(json.dumps(np.asarray(poses_abs).tolist()))
"""

theirs = np.asarray(
    json.loads(framework_eval(
        FRAMEWORK_POSE,
        [POSE_MODULE, OUTPUT_DIR / "predicted_action.json", 1.35],
    )),
    dtype=np.float64,
)

print(f"mine   : {mine.shape}")
print(f"theirs : {theirs.shape}")
print()

pos_diff = np.abs(mine[:, :3, 3] - theirs[:, :3, 3])
rot_diff = np.abs(mine[:, :3, :3] - theirs[:, :3, :3])
print(f"max position difference : {pos_diff.max():.3e} m")
print(f"max rotation difference : {rot_diff.max():.3e}")
print()
print("The framework computes in float32; this notebook computes in float64.")
print("Differences at the 1e-6 level are that, not a disagreement. Differences")
print("at the 1e-2 level are a convention bug, and the first thing to check is")
print("whether you decoded columns or rows.")
''')

nb.md("""
### Where the two implementations genuinely differ

Yours orthonormalises by Gram–Schmidt. The framework does something slightly
different: it takes the cross product for the third column and then, if
`normalize_rotation=True` (the default), projects the whole matrix onto SO(3)
with an SVD and a determinant fix.

On a well-behaved input the two agree to rounding, because a nearly-orthonormal
input has nearly one answer. On a badly-behaved input they do not: Gram–Schmidt
privileges the first column and fixes up the second, while the SVD projection
finds the closest rotation in a least-squares sense and treats both columns
even-handedly. Feed both a deliberately skewed input and watch them separate.
""")

nb.code('''
def rot6d_to_matrix_svd(vec6):
    """The framework's decode: cross product, then SVD projection onto SO(3)."""
    c0 = np.asarray(vec6[:3], dtype=np.float64)
    c1 = np.asarray(vec6[3:6], dtype=np.float64)
    c2 = np.cross(c0, c1)
    R = np.stack([c0, c1, c2], axis=-1)
    U, _, Vt = np.linalg.svd(R)
    Rn = U @ Vt
    if np.linalg.det(Rn) < 0:            # reflection, not a rotation
        U[:, -1] *= -1
        Rn = U @ Vt
    return Rn

clean = yaw_rot6d(30)
skewed = clean + np.array([0.0, 0.0, 0.0, 0.25, 0.0, 0.0])   # push column 1 off

for label, vec in (("clean", clean), ("skewed", skewed)):
    gs = rot6d_to_matrix_gram_schmidt(vec)
    sv = rot6d_to_matrix_svd(vec)
    print(f"{label:<7} max |gram_schmidt - svd| = {np.abs(gs - sv).max():.3e}   "
          f"det(gs)={np.linalg.det(gs):+.6f}  det(svd)={np.linalg.det(sv):+.6f}")

print()
print("Both always produce a proper rotation - determinant +1. They disagree")
print("about WHICH rotation is nearest when the input is not already one.")
print("Neither is wrong; they answer slightly different questions. What would")
print("be wrong is assuming the model's raw output is already orthonormal.")
''')

nb.md("""
**Checkpoint.** Your integration agrees with the framework's on real data, and
you can explain the one place they differ.
""")

nb.code('''
assert mine.shape == theirs.shape, "shapes disagree: check T = len(deltas) + 1"
assert np.abs(mine[:, :3, 3] - theirs[:, :3, 3]).max() < 1e-3, (
    "positions disagree beyond float32 rounding - suspect a convention bug"
)
assert abs(np.linalg.det(rot6d_to_matrix_gram_schmidt(clean)) - 1.0) < 1e-9
print("checkpoint passed: independent implementation reconciled with the framework")
''')

# ------------------------------------------------------- translation_scale
nb.md("""
## `translation_scale`, honestly

The source course passes `translation_scale=1.35` and says nothing about it. So:
what is it, and where does 1.35 come from?

Mechanically it is a divisor. On decode, `delta.translation = row[:3] /
translation_scale`. It exists because the action values a model emits are in
whatever units the dataset normaliser used during training, and turning those
back into metres needs a constant.

The honest answer to "where does 1.35 come from" is: it is a calibration
constant, and the framework's own docstring says to prefer denormalising with
the dataset's action normaliser rather than passing a scalar here. A single
number cannot be right for every dataset. Treat 1.35 as "the number that made
the cookbook's AV example come out at a plausible size" — because that is what
it is.

**What follows from that, and it is the useful part.** Because the constant only
divides the translations, it cannot change the *shape* of the trajectory. You
can prove this rather than believe it:

```
   position_n  =  Σ  R_i · (t_i / s)  =  (1/s) · Σ R_i · t_i
```

The rotations `R_i` never see `s`, so they are identical for every choice of it,
and the positions are the same path scaled uniformly. Therefore:

- the **shape** of a recovered trajectory is meaningful — turns, curvature, the
  ratio of lateral to forward motion;
- its **absolute size in metres** is not, unless you know the constant is right
  for your data.

Never report "the vehicle travelled 47 metres" from one of these without saying
where the scale came from.
""")

nb.predict_run_explain(
    predict=(
        "The next cell recomputes the absolute poses at "
        "`translation_scale` = 0.5, 1.0 and 1.35. Predict: (a) the ratio of "
        "total path lengths between the 0.5 and 1.35 runs; (b) whether the "
        "heading vectors change at all; (c) whether the bird's-eye path drawn "
        "from each would look different in shape."
    ),
    change="Nothing to edit. Commit to (a) as an actual number.",
    explain=(
        "The cell measures all three. If your (a) was right, you understood the "
        "algebra above. If (b) surprised you, re-read which part of the delta "
        "the constant touches. Then answer this: given that the shape is "
        "scale-invariant, what claim about a recovered trajectory is it never "
        "safe to make?"
    ),
    hint=(
        "Everything about a rotation matrix is determined by the six rotation "
        "numbers in the row. The constant divides the three translation numbers "
        "and nothing else."
    ),
)

nb.code('''
def path_length(poses):
    steps = np.diff(poses[:, :3, 3], axis=0)
    return float(np.linalg.norm(steps, axis=1).sum())

scales = [0.5, 1.0, 1.35]
scaled = {s: my_pose_rel_to_abs(poses_rel, translation_scale=s) for s in scales}

print(f"{'scale':>7}{'path length':>15}{'max |heading diff vs s=1|':>30}")
print("-" * 52)
base_heading = scaled[1.0][:, :3, 2]
for s in scales:
    poses = scaled[s]
    hdiff = np.abs(poses[:, :3, 2] - base_heading).max()
    print(f"{s:>7.2f}{path_length(poses):>15.4f}{hdiff:>30.3e}")

print()
ratio = path_length(scaled[0.5]) / path_length(scaled[1.35])
print(f"length(0.5) / length(1.35) = {ratio:.6f}")
print(f"1.35 / 0.5                 = {1.35 / 0.5:.6f}")
print()
rescaled = scaled[1.35][:, :3, 3] * 1.35
print("shape identical after undoing the scale:",
      bool(np.allclose(rescaled, scaled[1.0][:, :3, 3], atol=1e-9)))
''')

# ------------------------------------------------------------ visualisation
nb.md("""
## Seeing the trajectory

Two views, because they answer different questions. The 3-D plot with camera
frustums shows whether the path is plausible in space and which way the camera
pointed along it. The bird's-eye view collapses the vertical axis and shows the
steering, which is what you actually want when comparing a left turn against a
right one.

`cc.plot_camera_trajectory` draws both. It expects `[T, 4, 4]` camera-to-world
poses and reads position from `[:3, 3]` and heading from `[:3, 2]` — the two
slices you learned at the top of this lesson. It also remaps world `(X, Y, Z)`
to plot `(X, Z, Y-up)`, so that "forward" runs into the page and "up" is up.
That remap is the subject of the debugging lab, so notice that it exists.
""")

nb.code('''
poses_abs = scaled[1.35]
fig = cc.plot_camera_trajectory(
    poses_abs,
    title=f"Recovered camera trajectory ({len(poses_abs)} frames, av_0.mp4)",
)
np.save(OUTPUT_DIR / "poses_abs.npy", poses_abs)
print(f"saved {OUTPUT_DIR / 'poses_abs.npy'}")
''')

# --------------------------------------------------------------- round trip
nb.md("""
## The round trip

Here is a thing the source course does not do and should. You have a video, and
a set of actions the model believes produced it. Feed those actions back into
forward dynamics from the same starting clip. If the two directions are
consistent, the regenerated video should resemble the original.

This is the closest thing to an offline metric that exists for this stack.
`cosmos_framework/evaluation/` is listed in upstream's `docs/code_structure.md`
as `[planned]` and is not present in this release: there is no action-MSE
script, no validation-loss loop, no offline harness. Round-trip consistency is
something you can build yourself out of the two modes you already have.

Be clear about what it measures. A good round trip is evidence that the forward
and inverse directions agree with **each other**. It is not evidence that either
one is right about the world. Two models can be consistently wrong together, and
this metric cannot see that.
""")

nb.code('''
roundtrip_action_path = OUTPUT_DIR / "roundtrip_action.json"
roundtrip_action_path.write_text(json.dumps(poses_rel.tolist()))

rt_spec = cc.InferenceSpec(
    model_mode="forward_dynamics",
    name="av_roundtrip",
    prompt=AV_PROMPT,
    vision_path=str(AV_CLIP),                 # same clip the actions came from
    action_path=str(roundtrip_action_path),   # ...and the actions it explained
    domain_name="av",
    view_point="ego_view",
    action_chunk_size=min(MODE_CHUNK, len(poses_rel)),
    fps=10,
    image_size=480,
    seed=0,
)
print(cc.validate_spec(rt_spec, strict=False) or "spec valid")

with cc.timer("forward_dynamics roundtrip", quiet=True) as t_rt:
    rt_result = gen.run(rt_spec, OUTPUT_DIR / "av_roundtrip",
                        seed=0, timeout=TIMEOUT_S, stream_logs=False)
cc.verify_result(rt_result)
''')

nb.code('''
def read_frames_gray(path, count=24):
    """Decode up to `count` evenly spaced frames as float grayscale arrays.

    imageio first because it is already a dependency of the preview helper;
    OpenCV as a fallback. Returning None rather than raising keeps a decode
    problem from looking like a metric problem.
    """
    try:
        import imageio.v3 as iio
        frames = [np.asarray(f) for f in iio.imiter(str(path))]
    except Exception:
        try:
            import cv2
            cap = cv2.VideoCapture(str(path))
            frames = []
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                frames.append(frame[:, :, ::-1])
            cap.release()
        except Exception:
            return None
    if not frames:
        return None
    step = max(1, len(frames) // count)
    picked = frames[::step][:count]
    return [f.astype(np.float64).mean(axis=2) if f.ndim == 3 else f.astype(np.float64)
            for f in picked]


def compare_clips(a_path, b_path, count=24):
    """Per-frame mean absolute difference between two clips, on 0-255 grayscale."""
    a = read_frames_gray(a_path, count)
    b = read_frames_gray(b_path, count)
    if a is None or b is None:
        return None
    n = min(len(a), len(b))
    diffs = []
    for i in range(n):
        fa, fb = a[i], b[i]
        if fa.shape != fb.shape:                       # resolutions differ
            h = min(fa.shape[0], fb.shape[0])
            w = min(fa.shape[1], fb.shape[1])
            fa, fb = fa[:h, :w], fb[:h, :w]
        diffs.append(float(np.abs(fa - fb).mean()))
    return diffs

diffs = compare_clips(AV_CLIP, rt_result.video_path) if rt_result.video_path else None
if diffs:
    print(f"frames compared : {len(diffs)}")
    print(f"mean abs diff   : {np.mean(diffs):.2f}  (0-255 grayscale)")
    print(f"first frame     : {diffs[0]:.2f}")
    print(f"last frame      : {diffs[-1]:.2f}")
    print(f"trend           : {'rising' if diffs[-1] > diffs[0] else 'flat or falling'}")
    print()
    print("per-frame difference:")
    for i, d in enumerate(diffs):
        bar = "#" * int(d / max(max(diffs), 1e-9) * 50)
        print(f"  {i:>3} {d:6.2f} {bar}")
else:
    print("could not decode one of the clips; install imageio or opencv-python")
''')

nb.code('''
roundtrip = {
    "clip": str(AV_CLIP),
    "action_steps": int(poses_rel.shape[0]),
    "action_dims": int(poses_rel.shape[1]),
    "inverse_seconds": round(t_inv.seconds, 1),
    "forward_seconds": round(t_rt.seconds, 1),
    "per_frame_abs_diff": [round(d, 3) for d in diffs] if diffs else None,
    "mean_abs_diff": round(float(np.mean(diffs)), 3) if diffs else None,
    "translation_scale_used": 1.35,
    "note": (
        "Round-trip consistency measures agreement between the forward and "
        "inverse directions of ONE model. It is not evidence that either is "
        "correct about the world."
    ),
}
(OUTPUT_DIR / "roundtrip.json").write_text(json.dumps(roundtrip, indent=2))
print(json.dumps({k: v for k, v in roundtrip.items() if k != "per_frame_abs_diff"},
                 indent=2))
''')

nb.code('''
if rt_result.video_path:
    cc.show_video(rt_result.video_path, width=480,
                  caption="round trip: inverse dynamics, then forward dynamics")
''')

# ----------------------------------------------------------- debugging lab
nb.md("""
## Debugging lab: the car that drove into the sky

**Symptom.** A colleague plots a recovered AV trajectory in 3-D and sends you
the picture. The path climbs steadily away from the ground plane for the whole
clip. Their message says "the model thinks the car is flying". Nothing errored;
the plot rendered; the numbers are finite.

The plotting code is below, and it is deliberately wrong.
""")

nb.code('''
# DELIBERATELY WRONG: plots world (X, Y, Z) straight onto (x, y, z-up).
import matplotlib.pyplot as plt

positions = poses_abs[:, :3, 3]

fig_bad = plt.figure(figsize=(6, 5))
ax_bad = fig_bad.add_subplot(projection="3d")
ax_bad.plot(positions[:, 0], positions[:, 1], positions[:, 2], lw=2)
ax_bad.scatter(*positions[0], color="lime", s=60, edgecolor="k")
ax_bad.scatter(*positions[-1], color="red", s=60, edgecolor="k")
ax_bad.set_xlabel("X")
ax_bad.set_ylabel("Y")
ax_bad.set_zlabel("Z  <- labelled as 'up'")
ax_bad.set_title("The car appears to climb")
plt.show()
''', tags=["teaching-antipattern"])

nb.md("""
**Hypothesis.** Two coordinate conventions are in play and they disagree about
which axis is vertical.

- **Z-up** is the convention in most robotics and simulation stacks: X and Y are
  the ground plane, Z is altitude.
- **Y-up** is the convention in graphics and in most camera frames, including
  Cosmos 3's: X is right, Y is down or up depending on the sub-convention, and
  **Z is forward, out of the lens**.

Matplotlib's 3-D axes are neutral — whatever you hand to `zs` is drawn upwards.
Hand it the forward axis and forward motion becomes altitude. A car driving in a
straight line becomes a car ascending in a straight line, which is exactly the
picture that arrived.

**Diagnostic step.** Do not squint at the plot. Ask the data which axis is
which. A road vehicle travels a long way forward, wanders a bit sideways, and
changes altitude hardly at all. So rank the three world axes by how far the path
extends along each: the largest is forward, the smallest is up.
""")

nb.code('''
def identify_axes(positions):
    """Rank world axes by extent. For a ground vehicle: largest = forward, smallest = up."""
    extent = positions.max(axis=0) - positions.min(axis=0)
    order = np.argsort(extent)[::-1]           # descending
    names = ["X", "Y", "Z"]
    return {
        "extent": {names[i]: round(float(extent[i]), 4) for i in range(3)},
        "likely_forward": names[order[0]],
        "likely_lateral": names[order[1]],
        "likely_vertical": names[order[2]],
        "forward_to_vertical_ratio": (
            round(float(extent[order[0]] / max(extent[order[2]], 1e-12)), 1)
        ),
    }

diagnosis = identify_axes(positions)
print(json.dumps(diagnosis, indent=2))
print()
print("A ground vehicle's forward-to-vertical extent ratio should be large.")
print("If the axis you plotted upwards is the one with the LARGEST extent,")
print("you plotted forward as up. That is this bug.")
print()
print(f"the buggy plot put {diagnosis['likely_forward']} on the vertical axis"
      if diagnosis["likely_forward"] == "Z" else
      "on this clip the axes happen not to separate cleanly - see the note below")
''')

nb.md("""
**Repair.** Remap before plotting: world `(X, Y, Z)` becomes plot
`(X, Z, Y)` — lateral across, forward into the page, vertical up. That is
precisely the `remap = [0, 2, 1]` line inside `cc.plot_camera_trajectory`, which
is why the plot you drew earlier looked sane.

**Verification.** Not "it looks flatter now". Two checks a program can run:

1. the extent along the axis you drew upwards is the *smallest* of the three;
2. the heading vectors, projected onto the plane you called "ground", have
   non-trivial length — if the heading is mostly vertical in your plot frame,
   your ground plane is wrong.

The second matters because a path can be flat by accident. A clip of a car
stopped at traffic lights has small extent on every axis and passes check 1 for
the wrong reason.
""")

nb.code('''
def verify_plot_frame(poses, vertical_axis):
    """Check that `vertical_axis` (0=X,1=Y,2=Z) is a plausible 'up' for this path."""
    pos = poses[:, :3, 3]
    heading = poses[:, :3, 2]
    extent = pos.max(axis=0) - pos.min(axis=0)
    ground = [i for i in range(3) if i != vertical_axis]

    problems = []
    if extent[vertical_axis] > extent[ground].min():
        problems.append(
            f"axis {vertical_axis} has extent {extent[vertical_axis]:.4f}, which is "
            f"not the smallest ({extent.round(4).tolist()}). It is unlikely to be 'up'."
        )
    ground_heading = np.linalg.norm(heading[:, ground], axis=1).mean()
    if ground_heading < 0.5:
        problems.append(
            f"mean heading length in the chosen ground plane is {ground_heading:.3f}; "
            f"the camera is mostly looking along the axis you called vertical."
        )
    return problems

print("treating Z as up (the bug):")
for p in verify_plot_frame(poses_abs, 2) or ["  (no problems - see the caveat above)"]:
    print(f"  {p}")
print()
print("treating Y as up (correct for this camera convention):")
for p in verify_plot_frame(poses_abs, 1) or ["  (no problems)"]:
    print(f"  {p}")
''')

# -------------------------------------------------------------- exercises
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "Recovered against commanded, step by step",
    goal=(
        "Get a real error number by comparing a recovered trajectory against a "
        "trajectory you know, because you commanded it."
    ),
    instructions=(
        "1. Take the video Lesson 10 generated from `av_traj_forward.json` "
        "(`outputs/10/av_forward/`). You commanded those actions, so you have "
        "ground truth — something the cookbook clips do not come with.\n"
        "2. Run inverse dynamics on that generated video with the same "
        "`domain_name`, `fps` and `image_size` you used to make it.\n"
        "3. Align the two arrays. They may differ in length; say how you "
        "handled that and why your choice is not cheating.\n"
        "4. Compute and plot per-step translation error — the Euclidean "
        "distance between the commanded and recovered `[tx, ty, tz]` — for "
        "every step.\n"
        "5. Plot both integrated trajectories on one bird's-eye view.\n"
        "6. Answer: is the error roughly constant per step, or growing? What "
        "does each answer imply?"
    ),
    success=(
        "A per-step error plot, both trajectories on one bird's-eye view, and a "
        "written answer to step 6 that distinguishes per-step noise from "
        "accumulating drift."
    ),
    starter='''
LESSON_10_VIDEO = cc.OUTPUT_ROOT / "10" / "av_forward" / "av_forward" / "vision.mp4"
COMMANDED = np.asarray(json.loads(cc.asset("av_traj_forward").read_text()))

print("commanded:", COMMANDED.shape)
print("lesson 10 video present:", LESSON_10_VIDEO.exists())
if not LESSON_10_VIDEO.exists():
    print("  -> run Lesson 10 first, or point this at any forward-dynamics output")

def per_step_translation_error(commanded, recovered):
    """Euclidean distance between commanded and recovered translation, per step."""
    raise NotImplementedError
''',
    hints=[
        "Per-step error and accumulated error are different measurements and "
        "answer different questions. Compare the raw delta rows for the first; "
        "integrate both to absolute poses and compare positions for the second. "
        "Do both — the pair is far more informative than either alone.",
        "Length mismatch is not a nuisance, it is information. "
        "`action_chunk_size` decides how many steps come back, and the video has "
        "however many frames it has. Truncating the longer one to match is "
        "defensible; padding the shorter one with zeros is not, because a zero "
        "row means 'did not move' and you are inventing data.",
    ],
    solution_ref="solutions/11_solutions.ipynb",
)

nb.exercise(
    "applied",
    "An action-space metric",
    goal=(
        "Build a metric that compares two action sequences properly, including "
        "the rotation part, and use it on two different clips."
    ),
    instructions=(
        "1. Implement `action_error(a, b)` returning at least: mean per-step "
        "translation error (Euclidean, in whatever units the actions are in) "
        "and mean per-step **rotation geodesic distance** in degrees.\n"
        "2. The geodesic distance between rotations `R1` and `R2` is the angle "
        "of the rotation that takes one to the other: "
        "`theta = arccos((trace(R1^T R2) - 1) / 2)`. Clip the argument to "
        "[-1, 1] before the arccos, and say in a comment why that clip is "
        "necessary rather than defensive.\n"
        "3. Validate the metric before trusting it: `action_error(a, a)` must be "
        "zero on both components, and a sequence rotated by a known angle must "
        "come back with that angle.\n"
        "4. Run inverse dynamics on `av_0.mp4` and `av_1.mp4`, and report the "
        "metric between each clip's prediction and the round-trip re-estimate "
        "of the same clip.\n"
        "5. State which of the two numbers — translation or rotation — you trust "
        "more, and why. One of them is affected by `translation_scale` and the "
        "other is not."
    ),
    success=(
        "The metric passes both self-tests, is reported for two clips, and you "
        "have written down which component is scale-dependent and what that "
        "means for comparing across datasets."
    ),
    starter='''
def geodesic_degrees(R1, R2):
    """Angle of the rotation taking R1 to R2, in degrees."""
    raise NotImplementedError

def action_error(a, b, *, rotation_slice=slice(3, 9)):
    """Return {'translation_mean': ..., 'rotation_deg_mean': ..., ...}."""
    raise NotImplementedError

# Self-tests first. A metric you have not tested is a number, not a measurement.
sample_a = np.asarray(json.loads(cc.asset("av_traj_forward").read_text()))
print("identity:", action_error(sample_a, sample_a))
''',
    hints=[
        "`trace(R1^T R2)` can come out at 3.0000000004 in floating point, and "
        "`arccos` of anything above 1 is a NaN. That NaN then propagates through "
        "your mean and turns a perfect match into a missing number — which is "
        "why the clip is load-bearing rather than tidy.",
        "Translation error is measured in units that depend on "
        "`translation_scale`, so it is not comparable across datasets or across "
        "different values of that constant. Rotation geodesic distance is in "
        "degrees and is comparable everywhere. That asymmetry is the point of "
        "step 5.",
    ],
    solution_ref="solutions/11_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "A round-trip evaluation harness",
    goal=(
        "Turn the one-off round trip in this lesson into a harness that runs "
        "over several clips, reports a distribution rather than a number, and "
        "supports an argument about the model's failure modes."
    ),
    instructions=(
        "1. Build `roundtrip(clip, **spec_overrides)` that runs inverse "
        "dynamics, writes the predicted actions, runs forward dynamics from the "
        "same clip, and returns a record: the action array, the per-frame "
        "difference curve, both wall-clock times, and every spec field used.\n"
        "2. Run it over at least four inputs. `av_0.mp4` and `av_1.mp4` from the "
        "cookbook, plus at least two videos **you** generated in Lesson 10 from "
        "known trajectories.\n"
        "3. Report the **distribution**: per-clip mean difference, the spread "
        "across clips, and the shape of the difference-versus-frame-index curve "
        "averaged over clips.\n"
        "4. Vary one thing deliberately and hold everything else fixed — "
        "`action_chunk_size`, or `seed`, or `fps`. Use the variation to "
        "estimate how much of your between-clip spread is just run-to-run "
        "variance. A difference smaller than your seed variance is not a "
        "difference.\n"
        "5. Write `outputs/11/roundtrip_report.md` arguing what the errors tell "
        "you about the model's failure modes. Distinguish, with evidence: "
        "inverse-dynamics estimation error, forward-dynamics generative "
        "divergence, compounding drift, and scale ambiguity. Say which of the "
        "four your harness can and cannot separate.\n"
        "6. State the metric's blind spot explicitly. There is at least one "
        "failure mode that a round trip is structurally incapable of detecting; "
        "name it."
    ),
    success=(
        "At least four clips through the harness, a reported distribution with "
        "a variance estimate from a deliberate control, and a report that "
        "attributes error to specific mechanisms and names what the method "
        "cannot see."
    ),
    starter='''
def roundtrip(clip_path, *, chunk=None, seed=0, tag="rt"):
    """Inverse then forward on one clip. Return a full record."""
    raise NotImplementedError

CLIPS = [cc.asset("av_video"), cc.asset("av_video_2")]
print("cookbook clips:", [p.name for p in CLIPS])
print("add at least two of your own Lesson 10 outputs to this list")
''',
    hints=[
        "Run the same clip through the harness three times at three seeds "
        "before comparing different clips. If the seed spread is comparable to "
        "the clip spread, your between-clip differences are noise and the report "
        "should say so rather than interpreting them.",
        "The structural blind spot: a round trip compares the model against "
        "itself. If inverse dynamics systematically under-estimates turning and "
        "forward dynamics systematically under-turns by the same amount, the "
        "round trip is perfect and the model is wrong. Only ground truth — a "
        "commanded trajectory, or real vehicle odometry — can see that, which "
        "is why step 2 asks for clips you generated yourself.",
    ],
    solution_ref="solutions/11_solutions.ipynb",
)

# ------------------------------------------------------------- assessment
nb.md("""
## Assessment and reflection

### Knowledge check

1. An `inverse_dynamics` spec has no `action_path`. Why not, and which fields
   does it still need?
2. Given a 4×4 pose `T`, which slice is the camera position and which is the
   direction it is looking? Why is the second one a column and not a row?
3. Why is `T @ D` the right composition for a movement expressed in the moving
   frame, and what would `D @ T` mean?
4. Write down the inverse of `[[R, t], [0, 1]]`. Why is it not the transpose?
5. State `backward_framewise` in both directions, encode and decode.
6. Two identical action sequences are integrated with `translation_scale=1.0`
   and `2.0`. Which of the following change: positions, headings, path shape,
   path length, turn radius measured in metres?
7. Your round trip has a mean difference that is flat across frames rather than
   rising. What does that rule out?
8. A colleague reports "the recovered path is 47 m long". What do you ask them?

### Practical completion test

1. Implement relative-to-absolute integration from scratch and verify it on the
   three-step hand example.
2. Reconcile it against the framework's version and state the tolerance.
3. Explain the one place the two orthonormalisations differ.
4. Show that `translation_scale` scales a path and does not reshape it.
5. Diagnose a wrong-vertical-axis plot from the data rather than from the
   picture.
""")

nb.code('''
def self_test():
    passed = []

    assert inv_result.ok, "inverse dynamics produced no output"
    assert poses_rel.ndim == 2 and poses_rel.shape[1] == 9, \\
        f"expected [steps, 9] AV actions, got {poses_rel.shape}"
    passed.append(f"inverse dynamics returned {poses_rel.shape[0]} 9-D steps")

    assert np.allclose(toy_abs[-1][:3, 3], [1.0, 0.0, 1.0], atol=1e-9)
    passed.append("hand-checked three-step example matches")

    assert np.abs(mine[:, :3, 3] - theirs[:, :3, 3]).max() < 1e-3
    passed.append("own implementation reconciled with the framework's")

    assert np.allclose(scaled[1.35][:, :3, 3] * 1.35, scaled[1.0][:, :3, 3], atol=1e-9)
    assert np.allclose(scaled[0.5][:, :3, 2], scaled[1.35][:, :3, 2], atol=1e-12)
    passed.append("translation_scale proven to scale without reshaping")

    assert (OUTPUT_DIR / "poses_abs.npy").exists()
    assert (OUTPUT_DIR / "roundtrip.json").exists()
    rt = json.loads((OUTPUT_DIR / "roundtrip.json").read_text())
    if rt.get("mean_abs_diff") is None:
        passed.append("NOTE: round trip ran but frames could not be decoded "
                      "- install imageio or opencv-python and re-run")
    else:
        passed.append(f"round trip measured, mean abs diff {rt['mean_abs_diff']}")

    for item in passed:
        print(f"  PASS  {item}" if not item.startswith("NOTE") else f"  ----  {item}")
    return passed

_ = self_test()
''')

nb.md("""
### Summary

- `inverse_dynamics` drops `action_path` and keeps `domain_name`, `fps` and
  `image_size`. The prediction lands at `outputs[0].content["action"]` in
  `sample_outputs.json` as `[T−1, 9]` relative deltas.
- A pose is a 4×4 homogeneous transform. `[:3, 3]` is position, `[:3, :3]` is
  rotation, `[:3, 2]` is the heading because Cosmos 3's camera looks down its
  own +Z.
- Composition is matrix multiplication, and the side matters. `T @ D` applies
  `D` in the moving frame; the position update contains `R_T · t_D`, which is
  why poses cannot be added.
- `backward_framewise` means `D_i = T_i⁻¹ T_{i+1}` on encode and
  `T_{i+1} = T_i D_i` on decode. Decoding with the wrong convention gives a
  smooth, plausible, wrong path.
- Relative prediction keeps targets small and location-independent, and it makes
  errors compound. That compounding is visible in a rising round-trip difference
  curve, and it is the same mechanism that breaks open-loop control.
- `translation_scale` is an arbitrary calibration constant. It divides the
  translations and touches nothing else, so trajectory **shape** is meaningful
  and absolute **size in metres** is not.
- The framework orthonormalises with cross-product plus an SVD projection, not
  textbook Gram–Schmidt. They agree on clean input and separate on skewed input.
- Round-trip consistency is the best offline signal available — upstream ships
  no evaluation harness — and it compares the model against itself, which is a
  real and stateable limitation.

### Common misconceptions

| Belief | Correction |
|---|---|
| "Poses can be averaged or added" | Rotations do not add. Compose transforms; interpolate rotations on the manifold if you must. |
| "`T⁻¹` is `T.T`" | Only the rotation block transposes. `T⁻¹ = [[Rᵀ, −Rᵀt], [0, 1]]`. |
| "The recovered path is in metres" | It is in units of an undocumented calibration constant. The shape is trustworthy; the scale is not. |
| "A smooth trajectory is a correct trajectory" | Decoding with the wrong `pose_convention` produces a perfectly smooth wrong answer. |
| "Round-trip consistency proves the model is accurate" | It proves the two directions agree. Consistently wrong is still consistent. |
| "Plotting error is cosmetic" | A wrong vertical axis turns forward motion into altitude and reverses the conclusion you draw. |
| "6-D rotations from the model are already orthonormal" | Nothing constrains the network's output. Project before you use it. |

### Suggested extensions

- Integrate the *same* deltas with `pose_convention="backward_anchored"` — treat
  each delta as measured from the first pose instead of the previous one — and
  plot both. The difference is the cost of getting the convention wrong.
- Add small Gaussian noise to the deltas and integrate. Plot final-position
  error against noise magnitude. The curve is the compounding argument made
  quantitative, and it is the best possible preparation for Lesson 13.
- Recover trajectories for the same clip at three seeds and plot all three.
  How much of what you would have called model error is sampling variance?

### Mastery checklist

- [ ] I can read every slice of a 4×4 pose and say what it means.
- [ ] I implemented relative-to-absolute integration and verified it by hand.
- [ ] I reconciled my version with the framework's and know where they differ.
- [ ] I can prove that `translation_scale` does not change trajectory shape.
- [ ] I plotted a camera path in 3-D and as a bird's-eye view.
- [ ] I diagnosed a wrong-axis plot from the data rather than the picture.
- [ ] I ran a round trip, quantified it, and can state what it cannot detect.

Lesson 12 runs the third mode: observation plus instruction in, video **and**
actions out. It is also where the source course is broken, and where you fix it.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "11_action_inverse_dynamics.ipynb")
