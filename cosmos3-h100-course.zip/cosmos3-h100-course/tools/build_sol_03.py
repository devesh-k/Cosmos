"""Build solutions/03_solutions.ipynb — reference answers for Lesson 03."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("03", "Reasoning: captioning",
                      lesson_file="03_reasoning_captioning.ipynb")

nb.header(
    "Lesson 03 turns a video into a structured record. The three exercises push on the "
    "three places that breaks: the **schema** stops describing the world when you point "
    "it at a different kind of clip; the **conversion** from a scene record to a "
    "generation prompt has a decision in it that nobody can make for you; and the "
    "**batch loop** that works for six clips does not survive a directory of six hundred "
    "without caching, retry and a manifest."
)

nb.prelude(
    "The lesson's setup, its schema and validator, and a **softened** NIM gate. Lesson "
    "03 refuses to start without a NIM, which is right for the lesson. Here it sets "
    "`NIM_READY` instead, and every cell that needs the model degrades to a fake that "
    "exercises the same code path — which is enough to prove the logic and not enough "
    "to produce a caption."
)
nb.code(setup_cell("03"))

nb.code('''
import json
import random
import re
import shutil
import time

from cosmos_course.models import Reasoner
from cosmos_course.nim import NimConfig, nim_status

NIM = NimConfig()
STATUS = nim_status(NIM) if shutil.which("docker") else {"ready": False}
NIM_READY = bool(STATUS.get("ready"))
reasoner = Reasoner(base_url=NIM.base_url) if NIM_READY else None

print(f"NIM ready : {NIM_READY}")
if NIM_READY:
    print(f"model     : {reasoner.model}")
else:
    print("No reasoner. Cells that would caption print what they would have sent, and "
          "the logic around them is exercised against fakes.")
''')

nb.code('''
# The lesson's schema and validator, unchanged. Everything below is written
# against these, so they are repeated rather than assumed.
CAPTION_SCHEMA = {
    "subjects": ["list of strings: the main entities, most salient first"],
    "setting": "string: where this is, one sentence",
    "actions": ["list of strings: what happens, in temporal order"],
    "lighting": "string: quality, direction and colour of the light",
    "camera": "string: viewpoint, framing and any camera motion",
}

STRUCTURED_PROMPT = (
    "Describe this video as a structured scene record.\\n"
    "Reply with JSON only — no prose before it, no prose after it, no code "
    "fence.\\n"
    "Use exactly these keys and these types:\\n"
    + json.dumps(CAPTION_SCHEMA, indent=2)
    + "\\nIf a field cannot be determined from the video, use the string "
      "\\"unknown\\" rather than guessing or omitting the key."
)


def validate_record(rec):
    """Check one scene record against CAPTION_SCHEMA. Returns a list of problems."""
    problems = []
    if not isinstance(rec, dict):
        return [f"expected an object, got {type(rec).__name__}"]
    for key, example in CAPTION_SCHEMA.items():
        if key not in rec:
            problems.append(f"missing key {key!r}")
            continue
        want_list = isinstance(example, list)
        got_list = isinstance(rec[key], list)
        if want_list and not got_list:
            problems.append(f"{key!r} should be a list, got {type(rec[key]).__name__}")
        elif not want_list and not isinstance(rec[key], str):
            problems.append(f"{key!r} should be a string, got {type(rec[key]).__name__}")
    extra = set(rec) - set(CAPTION_SCHEMA)
    if extra:
        problems.append(f"unexpected keys: {sorted(extra)}")
    return problems


print(f"schema fields: {list(CAPTION_SCHEMA)}")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Three clips, one schema, and what does not fit",
    goal="Find out where a fixed schema stops describing the world, by applying it to "
         "clips it was not designed around.",
    success="A filled table, one field identified as low-value with a reason, and one "
            "proposed field with a named downstream consumer. A proposed field nobody "
            "downstream would read does not count.",
    approach="Make the specific/generic/unknown judgement a function rather than an eye "
             "test, so the table is reproducible and the criterion is written down "
             "where it can be argued with.",
)

nb.code('''
COMPARE = ["robotics_next_action", "drive_scene_next_action", "temporal_localization"]

# Words that describe any scene of this kind and therefore distinguish none of
# them. This list IS the criterion, which is why it is a named constant rather
# than buried in an if-statement: someone who disagrees with the table should be
# able to disagree with this instead.
GENERIC_TERMS = {
    "camera": {"static", "fixed", "stationary", "tripod", "shot", "medium",
               "wide", "standard", "third", "person", "eye", "level", "view",
               "movement", "motion", "angle", "normal"},
    "lighting": {"even", "neutral", "natural", "indoor", "ambient", "bright",
                 "lit", "light", "lighting", "daylight", "normal", "well"},
    "setting": {"indoor", "outdoor", "room", "environment", "scene", "place",
                "location", "area"},
}
STOPWORDS = {"a", "an", "the", "at", "in", "of", "on", "with", "and", "or", "to",
             "from", "is", "are", "it", "its", "this", "that", "no", "not"}
MIN_SPECIFIC_WORDS = 4
GENERIC_RATIO = 0.6


def classify_value(field, value):
    """Is this value specific, generic, or unknown? Returns (label, why).

    Three tests, in order:
      unknown  — the model said so, or the field is empty
      generic  — short, and every content word is in GENERIC_TERMS for this field
      specific — anything else

    The word-count floor matters as much as the vocabulary: "soft overcast light
    from a window on the left" and "natural" can both be true, and only one of
    them tells a generator what to draw.
    """
    if value is None:
        return "unknown", "field absent"
    if isinstance(value, list):
        if not value:
            return "unknown", "empty list"
        joined = "; ".join(str(v) for v in value)
        if all(str(v).strip().lower() in {"unknown", ""} for v in value):
            return "unknown", "every element is 'unknown'"
        words = len(re.findall(r"[a-z]+", joined.lower()))
        return ("specific" if words >= MIN_SPECIFIC_WORDS else "generic",
                f"{len(value)} item(s), {words} words")
    text = str(value).strip().lower()
    if text in {"", "unknown", "n/a", "none"}:
        return "unknown", f"literal {text!r}"
    words = [w for w in re.findall(r"[a-z][a-z-]*", text) if w not in STOPWORDS]
    if len(words) < MIN_SPECIFIC_WORDS:
        return "generic", f"{len(words)} content word(s) — too short to constrain anything"
    vocab = GENERIC_TERMS.get(field, set())
    hits = sorted({w for w in words if w in vocab})
    if hits and len(hits) / len(words) >= GENERIC_RATIO:
        return "generic", f"{len(hits)}/{len(words)} words are stock terms ({', '.join(hits[:3])})"
    return "specific", f"{len(words)} content words, {len(hits)} stock"


def field_table(records_by_clip):
    """clip x field -> (label, why). Prints the grid."""
    fields = list(CAPTION_SCHEMA)
    print(f"{'clip':<28}" + "".join(f"{f:<12}" for f in fields))
    table = {}
    for clip, rec in records_by_clip.items():
        row = {f: classify_value(f, (rec or {}).get(f)) for f in fields}
        table[clip] = row
        print(f"{clip:<28}" + "".join(f"{row[f][0]:<12}" for f in fields))
    return table
''')

nb.code('''
# The classifier has to be right before the table means anything, and it can be
# checked exactly — these are the three judgements it is being asked to make.
assert classify_value("camera", "unknown")[0] == "unknown"
assert classify_value("camera", "static")[0] == "generic"
assert classify_value("camera", "fixed tripod, medium shot")[0] == "generic"
assert classify_value("camera", "static third-person view, no motion")[0] == "generic"
assert classify_value("camera", "low tripod behind the bench, slow push-in over "
                                "the first two seconds")[0] == "specific"
assert classify_value("actions", [])[0] == "unknown"
assert classify_value("actions", ["unknown"])[0] == "unknown"
assert classify_value("actions", ["reaches for the mug", "lifts it clear of the "
                                  "bench", "sets it on the tray"])[0] == "specific"
assert classify_value("lighting", "natural")[0] == "generic"
print("PASS classify_value agrees with all nine hand-made judgements")
print()
for probe in ["static", "natural", "low tripod behind the bench, slow push-in"]:
    label, why = classify_value("camera", probe)
    print(f"  {probe[:46]:<48} -> {label:<9} ({why})")
''')

nb.code('''
def caption_clip(name, *, fps=4, seed=0):
    """Caption one named cookbook clip. Returns the parsed record, or None."""
    if not NIM_READY:
        return None
    path = cc.asset_or_none(name)
    if path is None:
        print(f"  {name}: asset not on disk — run scripts/fetch_assets.py")
        return None
    text = reasoner.ask(STRUCTURED_PROMPT, videos=path, fps=fps,
                        max_tokens=1024, seed=seed, temperature=0.0)
    return reasoner.parse_json(text)


records_by_clip = {}
for name in COMPARE:
    rec = caption_clip(name)
    records_by_clip[name] = rec
    if rec is not None:
        problems = validate_record(rec)
        print(f"  {name:<28} {'ok' if not problems else problems}")

if not any(records_by_clip.values()):
    # ILLUSTRATIVE RECORDS — not model output. They exist so the table below has
    # something to classify and so the shape of the answer is visible. Replace
    # them by running this with a NIM: the interesting part is which cells in
    # YOUR table say "generic".
    print("No captions available. Falling back to illustrative records — these are "
          "written by hand to show the shape of the finding, NOT model output.\\n")
    records_by_clip = {
        "robotics_next_action": {
            "subjects": ["a single-arm robot", "a blue towel", "a stainless counter"],
            "setting": "an industrial kitchen work surface seen from the side",
            "actions": ["grips the towel", "lifts it", "begins to fold it in half"],
            "lighting": "even overhead fluorescent light, few shadows",
            "camera": "static",
        },
        "drive_scene_next_action": {
            "subjects": ["a white sedan ahead", "lane markings", "a road sign"],
            "setting": "a multi-lane highway in daylight",
            "actions": ["the ego vehicle closes on the sedan", "the sedan changes lane"],
            "lighting": "bright overcast daylight, flat contrast",
            "camera": "forward-facing dashcam, moving with the vehicle",
        },
        "temporal_localization": {
            "subjects": ["a person", "a handheld object"],
            "setting": "unknown",
            "actions": ["an event occurs partway through the clip"],
            "lighting": "natural",
            "camera": "static",
        },
    }

table = field_table(records_by_clip)
print()
for clip, row in table.items():
    for field, (label, why) in row.items():
        if label != "specific":
            print(f"  {clip:<28} {field:<10} {label:<9} {why}")
''')

nb.model_answer(
    "**3. One field that carries almost no information, and why.**\n\n"
    "`camera`, on `robotics_next_action`. Hint 1 points at it and the reason is worth "
    "being precise about: a field's information content is a property of the *set* of "
    "things you point it at, not of any one value. Across a corpus of fixed-tripod "
    "manipulation clips, `camera` reads \"static\" every time. A field whose value you "
    "can predict without looking at the video has told you nothing — its entropy across "
    "the corpus is close to zero — so it costs output tokens, costs a validation branch, "
    "and buys nothing.\n\n"
    "The trap that hint 1 sets is the inference \"therefore drop it\". That is wrong, and "
    "the reason it is wrong is the most useful thing in this exercise. On "
    "`drive_scene_next_action` the same field reads \"forward-facing dashcam, moving with "
    "the vehicle\", which is the single most consequential fact about that clip — it is "
    "what makes it a driving scene rather than a scene containing a car. And Lesson 07 "
    "conditions generation on exactly this field. So the honest finding is *\"`camera` "
    "carries no information for this clip family\"*, not *\"`camera` is a low-value "
    "field\"*. Those are different claims with different consequences, and a schema "
    "trimmed on the basis of one corpus is a schema that fails on the next one.\n\n"
    "Runner-up: `lighting` on `temporal_localization`, which comes back as \"natural\" — "
    "generic for the same reason, but less interesting, because unlike `camera` it is "
    "not something a downstream lesson conditions on tightly.\n\n"
    "**4. One additional field that would earn its place, and its consumer.**\n\n"
    "**`audio`** — a one-sentence description of the expected soundscape ("
    "\"continuous water pouring into a metal container, faint extractor-fan hum\"). "
    "The named consumer is **Lesson 09**, which runs `audio_image2video` and needs a "
    "prompt that describes sound, not just picture; the cookbook ships "
    "`robot_pouring_water_audio.json` as a separate prompt file precisely because the "
    "visual prompt does not carry this. Adding it to the caption schema means one pass "
    "over a corpus produces prompts usable for both silent and sounded generation, "
    "instead of two.\n\n"
    "It also passes hint 2's test, which is the real filter: **the generator can vary "
    "it.** Cosmos3-Nano and Super support audio (`supports_audio: true` in "
    "`cc.MODEL_TIERS`); a field describing something the generator cannot control is a "
    "field you will never use. Note the honest caveat — Edge cannot, so on an "
    "Edge-only pipeline this field is dead weight and you should not add it.\n\n"
    "**The runner-up, and why it lost.** `negative` — what must *not* appear. Every "
    "cookbook video prompt ships with a negative prompt, so the consumer (Lesson 06's "
    "`negative_prompt` field) is unambiguous. It lost to `audio` only because a good "
    "negative prompt is mostly about *artefacts* — flicker, warping, morphing limbs — "
    "which are properties of the generator rather than of the source clip, so a "
    "captioner is the wrong thing to be asking. A field the captioner cannot fill from "
    "the video is as useless as a field nobody reads.\n\n"
    "**A proposal that fails the test, for contrast:** `estimated_mass_of_objects`. It "
    "is specific, it varies across clips, and nothing downstream in this course can act "
    "on it. Interesting is not the same as useful."
)

nb.extend(
    "The table is a snapshot; the useful version is a monitor. Run `classify_value` over "
    "every record in a captioning run and track the fraction of `generic` and `unknown` "
    "cells per field over time. A field whose generic rate climbs is a field the model "
    "has stopped being able to fill — usually because the corpus drifted, sometimes "
    "because the prompt did. That is a cheap, quantitative early warning for exactly "
    "the failure this exercise found by hand, and it costs nothing per clip."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "Caption to generation prompt",
    goal="Write `record_to_prompt(record)` converting a scene record into a structured "
         "Cosmos 3 generation prompt, plus a validator that catches a bad conversion "
         "before it costs a generation run.",
    success="Every record either converts to a prompt that passes `validate_prompt`, or "
            "is rejected with a stated reason. Nothing converts silently into a prompt "
            "containing the word 'unknown'.",
    approach="Drop unknown fields rather than passing the word through; render "
             "`actions` as an explicitly ordered sentence rather than a comma list; and "
             "make the validator refuse anything carrying schema vocabulary.",
)

nb.code('''
kitchen_path = cc.asset_or_none("prompt_robot_kitchen")
if kitchen_path:
    kitchen = json.loads(kitchen_path.read_text())
    print(json.dumps(kitchen, indent=2)[:900])
    TARGET_KEYS = list(kitchen)
else:
    print("cookbook prompt not fetched (scripts/fetch_assets.py). Using the shape "
          "Lesson 06 works with, which was read off this same file:")
    TARGET_KEYS = ["description", "subjects", "scene", "lighting", "camera", "style"]
    print(f"  {TARGET_KEYS}")
''')

nb.code('''
UNKNOWNS = {"unknown", "n/a", "none", "", "not visible", "cannot determine"}
# Vocabulary that only ever appears in the SCHEMA, never in a real description.
# If any of it survives into a prompt, the conversion copied a placeholder.
PLACEHOLDER_MARKERS = ("list of strings", "string:", "one sentence", "<", "TODO",
                       "quality, direction and colour")


def _is_unknown(value):
    if value is None:
        return True
    if isinstance(value, list):
        return not value or all(str(v).strip().lower() in UNKNOWNS for v in value)
    return str(value).strip().lower() in UNKNOWNS


def _ordered_actions(actions):
    """Render a temporal list as a sequence, not a simultaneity.

    Hint 2's point: "reaches, lifts, places" reads to a generator as three
    things happening at once, and you get an arm in an impossible pose. The
    fix is cheap — say the order out loud. Five seconds of video holds about
    three beats, so anything past the third is dropped rather than compressed;
    a prompt describing more than the clip can contain is a prompt that will
    be partly ignored, and you do not get to choose which part.
    """
    items = [str(a).strip().rstrip(".") for a in actions if str(a).strip()]
    items = [a for a in items if a.lower() not in UNKNOWNS][:3]
    if not items:
        return None
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"first {items[0]}, then {items[1]}"
    return f"first {items[0]}, then {items[1]}, and finally {items[2]}"


def record_to_prompt(record, *, style=None):
    """Convert one scene record into a structured generation prompt.

    THE 'unknown' DECISION, made and justified:

    Unknown fields are DROPPED, not passed through. The generator reads its
    prompt as a description of a scene, so the string "camera: unknown" is an
    instruction to render a scene in which the camera is unknown — and diffusion
    models are obliging about nonsense. Dropping the key instead leaves that
    degree of freedom to the sampler, which is what "we could not determine it"
    actually means.

    WHEN I WOULD DO THE OPPOSITE: when the prompt is going into a dataset for
    post-training rather than into a generation run. There, "unknown" is a real
    label carrying real information — this clip's lighting was not determinable
    — and dropping it makes an ambiguous record look like a confident one. The
    rule generalises: drop unknowns on the way to a model, keep them on the way
    to a file.
    """
    if not isinstance(record, dict):
        return None, [f"expected a dict, got {type(record).__name__}"]

    prompt, dropped = {}, []
    for field in CAPTION_SCHEMA:
        if _is_unknown(record.get(field)):
            dropped.append(field)

    subjects = record.get("subjects") or []
    if not _is_unknown(subjects):
        # The cookbook's subjects are objects with name/appearance/action, not
        # bare strings. The action goes on the FIRST subject only: it is the one
        # the caption listed as most salient, and attaching the same action to
        # every subject describes a scene where the towel also does the folding.
        action_text = _ordered_actions(record.get("actions") or [])
        prompt["subjects"] = [
            {"name": str(s).strip(),
             **({"action": action_text} if (i == 0 and action_text) else {})}
            for i, s in enumerate(subjects) if str(s).strip()
        ]

    setting = record.get("setting")
    if not _is_unknown(setting):
        prompt["scene"] = {"location": str(setting).strip()}
    if not _is_unknown(record.get("lighting")):
        prompt["lighting"] = str(record["lighting"]).strip()
    if not _is_unknown(record.get("camera")):
        prompt["camera"] = {"framing": str(record["camera"]).strip()}
    if style:
        prompt["style"] = style

    # `description` is the field the framework leans on hardest, so it is
    # composed rather than copied: subjects + ordered actions + setting.
    bits = []
    if prompt.get("subjects"):
        bits.append(", ".join(s["name"] for s in prompt["subjects"][:3]))
    action_text = _ordered_actions(record.get("actions") or [])
    if action_text:
        bits.append(action_text)
    if not _is_unknown(setting):
        bits.append(f"in {str(setting).strip()}")
    if bits:
        prompt["description"] = ". ".join(bits[:1] + [" ".join(bits[1:])]).strip()
    return (prompt or None), dropped
''')

nb.code('''
REQUIRED = ("description", "subjects")


def validate_prompt(prompt):
    """Return a list of problems; empty means the prompt is usable."""
    problems = []
    if not isinstance(prompt, dict) or not prompt:
        return ["prompt is empty or not an object"]

    for key in REQUIRED:
        if key not in prompt:
            problems.append(f"missing required field {key!r}")

    blob = json.dumps(prompt).lower()
    if "unknown" in blob:
        problems.append("the literal word 'unknown' survived into the prompt")
    for marker in PLACEHOLDER_MARKERS:
        if marker.lower() in blob:
            problems.append(f"schema placeholder text leaked through: {marker!r}")

    def walk(node, path="") :
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{path}.{k}" if path else k)
        elif isinstance(node, list):
            if not node:
                problems.append(f"{path or 'prompt'} is an empty list")
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")
        elif isinstance(node, str) and not node.strip():
            problems.append(f"{path or 'prompt'} is an empty string")

    walk(prompt)
    if isinstance(prompt.get("description"), str) and \\
            len(prompt["description"].split()) < 6:
        problems.append("description is under six words — too thin to condition on")
    return problems
''')

nb.code('''
# Exhaustive check on records whose correct outcome is known, including the two
# that must be REJECTED. A converter is only trustworthy if you have seen it
# refuse something.
CASES = [
    ("complete", {
        "subjects": ["a single-arm robot", "a blue towel"],
        "setting": "an industrial kitchen work surface",
        "actions": ["grips the towel", "lifts it", "folds it in half"],
        "lighting": "even overhead fluorescent light",
        "camera": "static side view at counter height",
    }, True),
    ("some unknowns", {
        "subjects": ["a person", "a handheld object"],
        "setting": "unknown",
        "actions": ["an event occurs partway through"],
        "lighting": "unknown",
        "camera": "unknown",
    }, True),
    ("all unknown", {
        "subjects": ["unknown"], "setting": "unknown", "actions": ["unknown"],
        "lighting": "unknown", "camera": "unknown",
    }, False),
    ("schema echoed back", {
        "subjects": ["list of strings: the main entities, most salient first"],
        "setting": "string: where this is, one sentence",
        "actions": ["list of strings: what happens, in temporal order"],
        "lighting": "string: quality, direction and colour of the light",
        "camera": "string: viewpoint, framing and any camera motion",
    }, False),
]

for label, rec, should_pass in CASES:
    prompt, dropped = record_to_prompt(rec, style="documentary realism, natural colour")
    problems = validate_prompt(prompt) if prompt else ["conversion produced nothing"]
    ok = not problems
    mark = "PASS" if ok == should_pass else "FAIL"
    print(f"{mark} {label:<20} converts={bool(prompt)} dropped={dropped} "
          f"usable={ok}")
    if problems:
        for p in problems[:3]:
            print(f"        rejected: {p}")
    assert ok == should_pass, (label, problems)

print()
print(json.dumps(record_to_prompt(CASES[0][1], style="documentary realism")[0], indent=2))
''')

nb.code('''
# Instruction 4 and 5: run it over the JSONL the lesson wrote, report the
# conversion rate, and save the result.
jsonl = OUTPUT_DIR / "scene_records.jsonl"
if jsonl.exists():
    rows = [json.loads(line) for line in jsonl.read_text(encoding="utf-8").splitlines()
            if line.strip()]
    source = str(jsonl)
else:
    rows = [{"clip": clip, "record": rec} for clip, rec in records_by_clip.items() if rec]
    source = "the three records from Exercise 1"

converted, rejected = [], []
for row in rows:
    prompt, dropped = record_to_prompt(row.get("record") or {},
                                       style="documentary realism, natural colour")
    problems = validate_prompt(prompt) if prompt else ["conversion produced nothing"]
    if problems:
        rejected.append({"clip": row.get("clip"), "reasons": problems})
    else:
        converted.append({"clip": row.get("clip"), "dropped_fields": dropped,
                          "prompt": prompt})

print(f"source   : {source}")
print(f"records  : {len(rows)}")
print(f"converted: {len(converted)}")
print(f"rejected : {len(rejected)}")
for r in rejected:
    print(f"  {r['clip']}: {r['reasons'][0]}")

out = OUTPUT_DIR / "generation_prompts.json"
out.write_text(json.dumps({"converted": converted, "rejected": rejected},
                          indent=2, ensure_ascii=False) + "\\n", encoding="utf-8")
print(f"\\nwrote {out}")

# The success criterion, asserted rather than eyeballed.
assert len(converted) + len(rejected) == len(rows), "a record vanished"
for entry in converted:
    assert "unknown" not in json.dumps(entry["prompt"]).lower(), entry["clip"]
print("PASS every record either converted or was rejected with a reason, and no "
      "converted prompt contains the word 'unknown'")
''')

nb.why(
    "**The `unknown` decision is the exercise, and hint 1 says neither answer is "
    "universally right.** This solution drops. The argument: a generation prompt is not "
    "a record, it is an *instruction*, and there is no way to instruct a diffusion model "
    "to leave something undetermined. Feed it \"camera: unknown\" and it will render "
    "something — most likely something influenced by the token \"unknown\", which is not "
    "in any training caption describing a real camera. Omitting the key is the only "
    "faithful encoding of \"we do not know\", because an absent condition genuinely is a "
    "free variable to the sampler.\n\n"
    "The condition under which I would switch is written into the docstring, and it is "
    "the more interesting half: **when the prompt is going into a dataset rather than "
    "into a run.** For a post-training corpus, \"unknown\" is a label with content — this "
    "clip's lighting was not determinable — and dropping it makes an uncertain record "
    "indistinguishable from a confident one, which corrupts the statistics you are about "
    "to train on. Drop unknowns on the way to a model; keep them on the way to a file.\n\n"
    "**Why `actions` becomes \"first X, then Y, and finally Z\".** Hint 2 flags that "
    "comma-joining reads as simultaneous, and the failure is concrete: \"reaches, lifts, "
    "places\" produces an arm attempting all three poses at once, which looks like a "
    "physics failure and is actually a prompt failure. Spelling out the order costs "
    "three words and removes the ambiguity. The truncation to three beats is a separate "
    "judgement: a 5-second clip cannot contain six sequential actions, and a prompt "
    "describing more than the clip can hold will be partially ignored in a way you do not "
    "get to choose. Better to choose it yourself.\n\n"
    "**Why the action attaches to the first subject only.** The cookbook's `subjects` are "
    "objects with `name`, `appearance` and `action`. Copying the same action string onto "
    "every subject describes a scene in which the towel also does the folding. The "
    "captioner was asked for subjects \"most salient first\", so the first one is the "
    "actor by construction. This is the kind of assumption that should be visible: if "
    "your captions do not obey the salience ordering, this mapping is wrong and the "
    "resulting prompts will be subtly odd.\n\n"
    "**Why the validator checks for schema vocabulary.** The failure it catches is real "
    "and specific: a model asked to fill a schema sometimes echoes the schema back, and "
    "`validate_record` passes it — the types are all correct. The result is a "
    "syntactically perfect prompt asking the generator to render \"string: where this is, "
    "one sentence\". It costs a full generation run to discover. `PLACEHOLDER_MARKERS` "
    "makes it a free check, and the `schema echoed back` test case above proves it fires."
)

nb.extend(
    "The converter currently ignores the *tier*. `record_to_prompt` could take a `model` "
    "argument and refuse to emit an `audio` block for Edge (`supports_audio: False`), or "
    "warn when the described camera motion needs more frames than the tier's "
    "`frames_range` allows. That turns the validator from \"is this prompt well-formed\" "
    "into \"is this prompt runnable on the machine I have\", which is the check that "
    "actually saves the run — and it is the same predicate Lesson 00's `will_it_fit` "
    "exercise built, pointed at a different input."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "A batch captioner with caching, retry and a manifest",
    goal="Turn the captioning loop into something you would leave running unattended "
         "over a directory of clips, and report its measured throughput.",
    success="A second run over the same directory does almost no model work. The "
            "manifest accounts for every input file. You can state measured throughput "
            "at both worker counts and say which is faster on your machine, with the "
            "numbers to back it.",
    approach="Inject the captioning call. Everything the exercise actually grades — "
             "cache hits, retry policy, manifest completeness, resumption after a "
             "mid-run outage — is harness behaviour, and injection is what lets all of "
             "it be proven in seconds instead of assumed after an hour.",
)

nb.code('''
class NimDown(RuntimeError):
    """The server has stopped answering at all.

    A control-flow signal, not a per-file failure: it says the RUN cannot
    continue, so `with_retry` re-raises it instead of classifying it. Without
    that exemption it falls into "unclassified, therefore permanent", is
    recorded as one file's failure, and the loop cheerfully carries on failing
    every remaining clip against a dead server. That was a real bug in the
    first draft of this notebook and the outage test below is what caught it.
    """


# ---- retry policy -------------------------------------------------------
# Classified by exception NAME and HTTP status rather than by importing the
# openai exception classes, so the policy is readable and testable without the
# openai package installed. The names are the ones hint 2 lists.
TRANSIENT_NAMES = {"APIConnectionError", "APITimeoutError", "RateLimitError",
                   "InternalServerError", "ConnectionError", "TimeoutError",
                   "ReadTimeout", "ServiceUnavailableError"}
PERMANENT_NAMES = {"UnprocessableEntityError", "BadRequestError", "NotFoundError",
                   "AuthenticationError", "PermissionDeniedError", "ValueError"}
TRANSIENT_STATUS = {408, 409, 429, 500, 502, 503, 504}
PERMANENT_STATUS = {400, 401, 403, 404, 415, 422}


def is_transient(exc):
    """Worth retrying? Returns (bool, why).

    A 422 retried four times is four times the wait for the same error: the
    request is wrong and will stay wrong. A connection reset is worth retrying
    because the request was never wrong, the wire was.
    """
    status = getattr(exc, "status_code", None) or getattr(exc, "status", None)
    if status in PERMANENT_STATUS:
        return False, f"HTTP {status} — the request is wrong and will stay wrong"
    if status in TRANSIENT_STATUS:
        return True, f"HTTP {status} — the request may succeed unchanged"
    name = type(exc).__name__
    if name in PERMANENT_NAMES:
        return False, f"{name} is a client-side error"
    if name in TRANSIENT_NAMES:
        return True, f"{name} is a transport-level failure"
    return False, f"{name} is unclassified — not retried, because retrying an " \\
                  f"unknown error is how you turn one failure into four"


def with_retry(fn, *, attempts=4, base_delay=0.5, sleep=time.sleep):
    """Call fn(), retrying transient failures with exponential backoff.

    Returns (result, retries_used, error). `sleep` is injectable so the tests
    below run in milliseconds instead of in seconds of real backoff.
    """
    delay = base_delay
    for attempt in range(attempts):
        try:
            return fn(), attempt, None
        except NimDown:
            raise                       # the run is over; do not retry, do not record
        except Exception as exc:
            transient, why = is_transient(exc)
            if not transient or attempt == attempts - 1:
                return None, attempt, f"{type(exc).__name__}: {exc} [{why}]"
            sleep(delay + random.uniform(0, base_delay))   # jitter, so parallel
            delay *= 2                                     # workers do not sync
    return None, attempts - 1, "exhausted"
''')

nb.code('''
def cache_key(path, *, fps, seed):
    """Content key. Includes the SETTINGS, not just the file.

    A re-run at a different fps is different work and must not hit the cache —
    that is the bug this key shape exists to prevent, and it is invisible until
    someone changes fps and gets yesterday's captions back.
    """
    st = path.stat()
    return f"{path.name}:{st.st_size}:{st.st_mtime_ns}:fps{fps}:seed{seed}"


def caption_directory(src_dir, out_dir, *, fps=4, workers=1, seed=0,
                      caption_fn=None, attempts=4, sleep=time.sleep):
    """Caption every video under src_dir into one JSONL record each.

    Returns the manifest dict. Also writes records.jsonl and manifest.json.
    `caption_fn(path, fps=..., seed=...) -> dict` is injected so the harness can
    be tested without a NIM; the default calls the real reasoner.
    """
    from concurrent.futures import ThreadPoolExecutor

    src_dir, out_dir = Path(src_dir), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = out_dir / "manifest.json"
    records_path = out_dir / "records.jsonl"

    if caption_fn is None:
        def caption_fn(path, *, fps=fps, seed=seed):
            text = reasoner.ask(STRUCTURED_PROMPT, videos=path, fps=fps,
                                max_tokens=1024, seed=seed, temperature=0.0)
            return reasoner.parse_json(text)

    # Resume: a prior manifest's successful entries are the cache.
    prior = {}
    if manifest_path.exists():
        try:
            prior = {e["cache_key"]: e
                     for e in json.loads(manifest_path.read_text()).get("entries", [])
                     if e.get("status") == "ok"}
        except (json.JSONDecodeError, KeyError):
            prior = {}

    clips = sorted(p for p in src_dir.rglob("*")
                   if p.is_file() and p.suffix.lower() in {".mp4", ".mov", ".mkv", ".webm"})
    entries, records, aborted = [], [], None

    def do_one(path):
        key = cache_key(path, fps=fps, seed=seed)
        if key in prior:
            hit = dict(prior[key])
            hit["cache"] = "hit"
            hit["latency_s"] = 0.0
            hit["retries"] = 0
            return hit, None
        started = time.perf_counter()
        result, retries, error = with_retry(
            lambda: caption_fn(path, fps=fps, seed=seed),
            attempts=attempts, sleep=sleep)
        entry = {
            "file": path.name, "cache_key": key, "cache": "miss",
            "retries": retries, "latency_s": round(time.perf_counter() - started, 3),
            "status": "ok" if error is None else "failed",
            "error": error,
            "prompt_tokens": None, "completion_tokens": None,
        }
        if error is None and reasoner is not None:
            usage = getattr(reasoner, "last_usage", {}) or {}
            entry["prompt_tokens"] = usage.get("prompt_tokens")
            entry["completion_tokens"] = usage.get("completion_tokens")
        if error is not None:
            entry["cause"] = error.split(":")[0]
        return entry, (None if error else {"file": path.name, "record": result})

    wall_start = time.perf_counter()
    try:
        if workers <= 1:
            for path in clips:
                entry, rec = do_one(path)
                entries.append(entry)
                if rec:
                    records.append(rec)
        else:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for entry, rec in pool.map(do_one, clips):
                    entries.append(entry)
                    if rec:
                        records.append(rec)
    except NimDown as exc:
        # Instruction 6: stop cleanly, and leave the manifest consistent so a
        # re-run resumes. Entries already collected are kept; the rest are
        # simply absent and will be attempted next time.
        aborted = str(exc)

    wall = time.perf_counter() - wall_start
    done = [e for e in entries if e["status"] == "ok"]
    failed = [e for e in entries if e["status"] != "ok"]
    causes = {}
    for e in failed:
        causes[e.get("cause", "unknown")] = causes.get(e.get("cause", "unknown"), 0) + 1

    manifest = {
        "summary": {
            "src_dir": str(src_dir), "files_found": len(clips),
            "attempted": len(entries), "ok": len(done), "failed": len(failed),
            "cache_hits": sum(1 for e in entries if e["cache"] == "hit"),
            "cache_misses": sum(1 for e in entries if e["cache"] == "miss"),
            "retries_total": sum(e["retries"] for e in entries),
            "wall_seconds": round(wall, 3),
            "clips_per_minute": round(60 * len(entries) / wall, 2) if wall > 0 else None,
            "workers": workers, "fps": fps, "seed": seed,
            "failure_causes": causes,
            "aborted": aborted,
            "complete": aborted is None and len(entries) == len(clips),
        },
        "entries": entries,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\\n", encoding="utf-8")
    with records_path.open("w", encoding="utf-8") as fh:
        for rec in records:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\\n")
    return manifest
''')

nb.code('''
# A fake captioner, so every graded behaviour can be PROVEN rather than hoped
# for. It is deterministic, it is slow enough to measure, and it fails in the
# two ways that matter.
class FlakyError(Exception):
    def __init__(self, msg, status):
        super().__init__(msg)
        self.status_code = status


class FakeCaptioner:
    """Fails transiently twice on one file, permanently on another, then works."""

    def __init__(self, *, work_seconds=0.05, down_after=None):
        self.calls = 0
        self.attempts_per_file = {}
        self.work_seconds = work_seconds
        self.down_after = down_after

    def __call__(self, path, *, fps=4, seed=0):
        self.calls += 1
        if self.down_after is not None and self.calls > self.down_after:
            raise NimDown("the NIM stopped answering")
        n = self.attempts_per_file.get(path.name, 0) + 1
        self.attempts_per_file[path.name] = n
        time.sleep(self.work_seconds)          # stands in for network + inference
        if "av1" in path.name:
            raise FlakyError("this video could not be decoded", 422)
        if "flaky" in path.name and n <= 2:
            raise FlakyError("connection reset", 503)
        return {"subjects": [f"subject from {path.name}"], "setting": "a test fixture",
                "actions": ["exists"], "lighting": "even", "camera": "static"}


CORPUS = OUTPUT_DIR / "sol_corpus"
shutil.rmtree(CORPUS, ignore_errors=True)
CORPUS.mkdir(parents=True, exist_ok=True)
for name in ["clip_a.mp4", "clip_b.mp4", "clip_flaky.mp4", "clip_av1.mp4",
             "clip_c.mp4", "clip_d.mp4"]:
    (CORPUS / name).write_bytes(b"not a real video, and nothing here decodes it")
print(f"fixture corpus: {len(list(CORPUS.glob('*.mp4')))} files in {CORPUS.name}")
''')

nb.code('''
# ---- cache: a second run must do almost no model work -------------------
run_dir = OUTPUT_DIR / "batch_test"
shutil.rmtree(run_dir, ignore_errors=True)

fake = FakeCaptioner()
first = caption_directory(CORPUS, run_dir, workers=1, caption_fn=fake,
                          sleep=lambda s: None)
calls_first = fake.calls

fake2 = FakeCaptioner()
second = caption_directory(CORPUS, run_dir, workers=1, caption_fn=fake2,
                           sleep=lambda s: None)

print(f"run 1: {first['summary']['ok']} ok, {first['summary']['failed']} failed, "
      f"{first['summary']['cache_hits']} hits, {calls_first} model calls")
print(f"run 2: {second['summary']['ok']} ok, {second['summary']['failed']} failed, "
      f"{second['summary']['cache_hits']} hits, {fake2.calls} model calls")

assert first["summary"]["cache_hits"] == 0
assert second["summary"]["cache_hits"] == first["summary"]["ok"], second["summary"]
assert fake2.calls < calls_first, (fake2.calls, calls_first)
print("PASS the second run is dominated by cache hits; only the permanently-failing "
      "file is re-attempted, which is correct — a failure is not a result to cache")

# Settings are part of the key: a different fps must MISS.
fake3 = FakeCaptioner()
third = caption_directory(CORPUS, run_dir, workers=1, fps=8, caption_fn=fake3,
                          sleep=lambda s: None)
assert third["summary"]["cache_hits"] == 0, third["summary"]
print("PASS changing fps invalidates the cache — different settings are different work")
''')

nb.code('''
# ---- retry: transient recovers, permanent is not retried ----------------
shutil.rmtree(run_dir, ignore_errors=True)
fake = FakeCaptioner()
m = caption_directory(CORPUS, run_dir, workers=1, caption_fn=fake, sleep=lambda s: None)
by_file = {e["file"]: e for e in m["entries"]}

assert by_file["clip_flaky.mp4"]["status"] == "ok", by_file["clip_flaky.mp4"]
assert by_file["clip_flaky.mp4"]["retries"] == 2, by_file["clip_flaky.mp4"]
print("PASS a 503 was retried twice and then succeeded")

assert by_file["clip_av1.mp4"]["status"] == "failed"
assert by_file["clip_av1.mp4"]["retries"] == 0, by_file["clip_av1.mp4"]
assert fake.attempts_per_file["clip_av1.mp4"] == 1, fake.attempts_per_file
print("PASS a 422 was attempted exactly once — retrying it would be four times the "
      "wait for the same error")
print(f"     recorded cause: {by_file['clip_av1.mp4']['cause']}")

# ---- manifest accounts for every input file ------------------------------
s = m["summary"]
assert s["files_found"] == len(list(CORPUS.glob("*.mp4")))
assert s["attempted"] == s["files_found"]
assert s["ok"] + s["failed"] == s["attempted"]
assert s["complete"] is True
print(f"PASS manifest accounts for all {s['files_found']} files "
      f"({s['ok']} ok, {s['failed']} failed, causes={s['failure_causes']})")
''')

nb.code('''
# ---- the NIM goes down mid-run: stop cleanly, resume on re-run ----------
shutil.rmtree(run_dir, ignore_errors=True)
dying = FakeCaptioner(down_after=2)
partial = caption_directory(CORPUS, run_dir, workers=1, caption_fn=dying,
                            sleep=lambda s: None)
print(f"aborted after {partial['summary']['attempted']} of "
      f"{partial['summary']['files_found']} files: {partial['summary']['aborted']}")
assert partial["summary"]["aborted"], partial["summary"]
assert partial["summary"]["complete"] is False
assert (run_dir / "manifest.json").exists()

# The manifest must still parse, and a re-run must pick up where it stopped.
recovered = FakeCaptioner()
resumed = caption_directory(CORPUS, run_dir, workers=1, caption_fn=recovered,
                            sleep=lambda s: None)
print(f"resumed run: {resumed['summary']['cache_hits']} hit(s), "
      f"{recovered.calls} model calls, complete={resumed['summary']['complete']}")
assert resumed["summary"]["cache_hits"] == partial["summary"]["ok"], resumed["summary"]
assert resumed["summary"]["complete"] is True
print("PASS an outage leaves a consistent manifest, and the re-run redoes only the "
      "work that never finished")
''')

nb.code('''
# ---- throughput at workers=1 and workers=4 ------------------------------
# IMPORTANT: with the fake captioner this measures THE HARNESS, not the NIM.
# The fake sleeps, which releases the GIL exactly as a network wait does, so
# the scaling shape is real; the absolute numbers are not a Cosmos measurement
# and must not be quoted as one.
def timed(workers, *, caption_fn_factory, label):
    d = OUTPUT_DIR / f"batch_w{workers}"
    shutil.rmtree(d, ignore_errors=True)
    fn = caption_fn_factory()
    started = time.perf_counter()
    man = caption_directory(CORPUS, d, workers=workers, caption_fn=fn,
                            sleep=lambda s: None)
    elapsed = time.perf_counter() - started
    rate = 60 * man["summary"]["attempted"] / elapsed
    print(f"  {label:<26} workers={workers}  {elapsed:6.2f} s  "
          f"{rate:7.1f} clips/min")
    return rate


print("Harness scaling (fake captioner — NOT a Cosmos throughput measurement):")
r1 = timed(1, caption_fn_factory=lambda: FakeCaptioner(work_seconds=0.15),
           label="fixture")
r4 = timed(4, caption_fn_factory=lambda: FakeCaptioner(work_seconds=0.15),
           label="fixture")
print(f"\\n  speedup with 4 workers: {r4 / r1:.2f}x on the fixture")
assert r4 > r1, "threads should help when the work is a sleep"
print("  PASS concurrency reaches the worker pool at all — which is the only thing "
      "this fixture can prove")

print()
if NIM_READY:
    print("A NIM is available. Replace caption_fn with the real one and re-run the "
          "two timings to get YOUR number:")
    print("    r1 = timed(1, caption_fn_factory=lambda: None, label='real')")
    print("    r4 = timed(4, caption_fn_factory=lambda: None, label='real')")
    print("  (passing caption_fn=None makes caption_directory call the reasoner.)")
else:
    print("No NIM, so there is no real throughput number to report. What to expect "
          "when you run it, stated as a prediction to be checked:")
print("  The NIM batches internally, so a second client thread may add throughput "
      "(the server had idle capacity) or none at all (it was already saturated by "
      "one stream). Which of those you see depends on your clip lengths and fps, "
      "and it is not predictable from the docs. Measure it; do not assume the 4x.")
''')

nb.why(
    "**Why the captioning call is injected.** Every behaviour the exercise grades — "
    "cache hit on the second run, retry only on transient errors, a manifest that "
    "accounts for every file, clean abort and resume after an outage — is a property of "
    "the *harness*, not of the model. Testing them through a real NIM means each "
    "assertion costs seconds of inference, the flaky-503 case cannot be produced on "
    "demand at all, and \"the NIM went down mid-run\" requires you to actually kill the "
    "container at the right moment. With `caption_fn` injected, all six run in under a "
    "second and the outage case is one constructor argument. This is the same move as "
    "Exercise 2 of Lesson 02, and it is worth naming as a habit: **when the thing you "
    "are building is a harness around an expensive call, the expensive call must be a "
    "parameter.**\n\n"
    "**The cache key includes the settings, and that is not decoration.** "
    "`name:size:mtime_ns` alone caches the file. The bug it permits is nasty: you change "
    "`fps` from 4 to 8, re-run, get instant results, and they are yesterday's captions at "
    "the old sampling rate. Nothing errors. The `fps` cell above asserts a MISS after "
    "the change, which is the only way to know the key is right.\n\n"
    "**Why failures are not cached.** The second run re-attempts `clip_av1.mp4` and the "
    "test asserts that. A failure is not a result — the file may have been replaced, the "
    "server may have been upgraded, the 422 may have been about a codec you have since "
    "transcoded. Caching failures makes an unattended job permanently blind to its own "
    "recovery. The cost is that a genuinely broken file is retried on every run, which is "
    "one wasted request per run and worth it.\n\n"
    "**Why unclassified exceptions are treated as permanent.** `is_transient` returns "
    "`False` for anything it does not recognise. The alternative default — retry unless "
    "known-permanent — turns every new failure mode into four failures and four backoff "
    "waits, and it does that *silently*, at 3 a.m., in a job you left running. Defaulting "
    "to \"do not retry\" makes an unknown error appear once, fast, in the manifest's "
    "`failure_causes` block, where you will see it. This is the same asymmetry as the "
    "hidden-GPU check in Lesson 00: when two behaviours are both defensible, pick the one "
    "whose failure is visible.\n\n"
    "**Why the throughput number is fenced off so carefully.** The fixture measures "
    "`time.sleep` under a thread pool. The *shape* it demonstrates is real — sleeping "
    "releases the GIL exactly as a socket wait does, so if concurrency did not help here "
    "it would not help there either. The magnitude is meaningless. Hint 3 and instruction "
    "5 both invite a claim about whether four client threads beat one against the real "
    "NIM, and the honest answer is that it depends on whether one stream already "
    "saturates the server's internal batching, which depends on your clip lengths and "
    "fps. That is a measurement, and this notebook is not allowed to make it for you.\n\n"
    "**One thing this implementation gets only half right.** `pool.map` preserves input "
    "order but does not yield results until each completes in order, so a single slow "
    "clip blocks the manifest's growth even though other workers have finished. "
    "`as_completed` would stream results and let a partially-complete run be flushed "
    "incrementally — which matters for instruction 6, because an outage 400 clips into a "
    "500-clip directory currently loses nothing but also writes nothing until the abort. "
    "If your version flushed the manifest every N entries, yours is more robust than "
    "this one."
)

nb.extend(
    "The manifest is currently written once, at the end. For a job you would genuinely "
    "leave unattended, write it **append-only** — one JSON line per completed clip — and "
    "rebuild the summary on load. That removes the last failure mode this design still "
    "has: a hard kill (`SIGKILL`, an OOM killer, a machine reboot) loses everything since "
    "the run started, because `finally` does not run and the manifest was never touched. "
    "An append-only log survives all three, and turns \"resume\" from a feature into a "
    "property of the file format. The cost is that reading the manifest becomes a fold "
    "rather than a `json.load`, which is a small price for a job measured in hours."
)

nb.finish()
