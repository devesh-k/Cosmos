"""Compile every code cell in the course notebooks. Catches syntax errors
without needing a kernel, a GPU, or any of the heavy dependencies."""
import ast, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
paths = sorted(ROOT.glob("*.ipynb")) + sorted(ROOT.glob("exercises/*.ipynb")) + sorted(ROOT.glob("solutions/*.ipynb"))
if len(sys.argv) > 1:
    paths = [ROOT / a for a in sys.argv[1:]]

bad = 0
for p in paths:
    nb = json.loads(p.read_text())
    errs = []
    n = 0
    for i, cell in enumerate(nb["cells"]):
        if cell["cell_type"] != "code":
            continue
        n += 1
        src = "".join(cell["source"])
        # Skip IPython magics/shell escapes, which aren't valid Python.
        if any(line.lstrip().startswith(("%", "!")) for line in src.splitlines()):
            continue
        try:
            ast.parse(src)
        except SyntaxError as e:
            errs.append(f"    cell {i}: line {e.lineno}: {e.msg}")
    status = "ok  " if not errs else "FAIL"
    print(f"[{status}] {p.name}  ({n} code cells)")
    for e in errs:
        print(e)
    bad += len(errs)
print(f"\n{bad} syntax error(s)")
sys.exit(1 if bad else 0)
