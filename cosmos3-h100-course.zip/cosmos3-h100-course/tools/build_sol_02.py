"""Build solutions/02_solutions.ipynb — reference answers for Lesson 02."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("02", "Serving the reasoner",
                      lesson_file="02_serving_the_reasoner.ipynb")

nb.header(
    "All three exercises circle the same fact: **one card, two tenants.** The NIM does "
    "not politely take what it needs — it sizes a KV cache pool against whatever is "
    "free when it starts, and then the generator cannot get in. The foundation exercise "
    "makes that a number you measured. The applied one builds the context manager that "
    "makes taking turns safe. The challenge one measures where coexistence actually "
    "breaks, rather than trusting the arithmetic."
)

nb.prelude(
    "The lesson's setup, plus a **softened** version of its prerequisite cell. The "
    "lesson raises when docker or `NGC_API_KEY` is missing, which is right for a lesson "
    "you are about to spend an hour on. Here it sets a flag instead, because a "
    "solutions notebook that refuses to open on a machine without docker is a solutions "
    "notebook nobody can read."
)
nb.code(setup_cell("02"))

nb.code('''
import json
import shutil
import subprocess
import time
from contextlib import contextmanager

from cosmos_course.nim import (
    NIM_MEMORY_ENV,
    NimConfig,
    nim_status,
    start_nim,
    stop_nim,
    suggest_memory_fraction,
)

NIM = NimConfig()

# What is actually available on this machine. Nothing below raises on a missing
# piece; every gated cell prints what it would have done instead.
HAVE_DOCKER = shutil.which("docker") is not None
HAVE_SMI = shutil.which("nvidia-smi") is not None
HAVE_NGC_KEY = bool(os.environ.get("NGC_API_KEY"))
STATUS = nim_status(NIM) if HAVE_DOCKER else {"ready": False, "running": False,
                                              "gpu_used_gb": None, "gpu_total_gb": None,
                                              "vram_gb": None}
NIM_READY = bool(STATUS.get("ready"))
CAN_START_NIM = HAVE_DOCKER and HAVE_SMI and HAVE_NGC_KEY

print(f"docker      : {HAVE_DOCKER}")
print(f"nvidia-smi  : {HAVE_SMI}")
print(f"NGC_API_KEY : {'set (value never printed)' if HAVE_NGC_KEY else 'not set'}")
print(f"NIM ready   : {NIM_READY}")
print(f"can start   : {CAN_START_NIM}")
if not CAN_START_NIM:
    print("\\nThe NIM cannot be driven from here. Cells that need it will say so and "
          "run their logic against a simulated NIM instead — which is enough to "
          "prove the logic correct, and not enough to produce a measurement.")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Stop, measure, start, measure",
    goal="Observe the full VRAM cycle, so that \"the NIM holds memory\" becomes a "
         "number you produced rather than a claim you read.",
    success="Three measurements and two deltas, the freed amount close to the amount "
            "held, and a written explanation for any difference between the first and "
            "third readings.",
    approach="Measure independently of `stop_nim`'s own reporting, then compare the two "
             "— checking the helper rather than trusting it is the whole point of hint "
             "1 — and format the table with a pure function so it can be tested without "
             "a NIM.",
)

nb.code('''
def read_used_gb():
    """VRAM in use on the whole card, from nvidia-smi, in GB. None if unreadable.

    Deliberately NOT torch.cuda.memory_allocated: that reports what THIS process
    has allocated through PyTorch, and the NIM is a different process. The whole
    lesson turns on that distinction, so the measurement has to respect it.
    """
    if not HAVE_SMI:
        return None
    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=20, check=True).stdout
        return float(out.strip().splitlines()[0]) / 1024.0
    except Exception:
        return None


def render_cycle(readings):
    """Format the three readings and two deltas. Pure: no GPU, no docker.

    Separated from the measurement so the arithmetic and the formatting can be
    checked on invented numbers, which is what the cell after this one does.
    """
    lines = ["  stage                     GPU used (GB)"]
    for stage in ("with_nim", "after_stop", "after_restart"):
        value = readings.get(stage)
        shown = f"{value:8.2f}" if isinstance(value, (int, float)) else "     n/a"
        lines.append(f"  {stage:<24} {shown}")
    deltas = {}
    if all(isinstance(readings.get(k), (int, float)) for k in ("with_nim", "after_stop")):
        deltas["freed_by_stop"] = readings["with_nim"] - readings["after_stop"]
    if all(isinstance(readings.get(k), (int, float))
           for k in ("after_stop", "after_restart")):
        deltas["taken_by_restart"] = readings["after_restart"] - readings["after_stop"]
    if all(isinstance(readings.get(k), (int, float))
           for k in ("with_nim", "after_restart")):
        deltas["restart_vs_original"] = readings["after_restart"] - readings["with_nim"]
    lines.append("")
    for name, value in deltas.items():
        lines.append(f"  {name:<24} {value:+8.2f}")
    return "\\n".join(lines), deltas
''')

nb.code('''
# Check the arithmetic on numbers whose answer is known, before running it on a
# machine where a wrong delta would look like a discovery.
_text, _d = render_cycle({"with_nim": 74.0, "after_stop": 2.0, "after_restart": 70.0})
assert _d["freed_by_stop"] == 72.0, _d
assert _d["taken_by_restart"] == 68.0, _d
assert _d["restart_vs_original"] == -4.0, _d
print(_text)
print("\\nPASS deltas computed correctly on synthetic readings")

# And the degenerate case: a machine where nvidia-smi cannot be read must give a
# table, not a traceback.
_text2, _d2 = render_cycle({"with_nim": None, "after_stop": None, "after_restart": None})
assert _d2 == {}, _d2
print("\\nPASS unreadable readings render as n/a with no deltas")
''')

nb.code('''
readings = {}
stop_report = {}

if NIM_READY:
    readings["with_nim"] = read_used_gb()
    print(f"with NIM running : {readings['with_nim']:.2f} GB")

    # stop_nim polls, because the driver does not hand memory back the instant
    # the process dies — the CUDA context is torn down first, and a reading
    # taken immediately after `docker rm` catches the card mid-teardown.
    stop_report = stop_nim(NIM)
    readings["after_stop"] = read_used_gb()
    print(f"after stop       : {readings['after_stop']:.2f} GB")

    start_nim(NIM, wait=True, timeout=2400)
    readings["after_restart"] = read_used_gb()
    print(f"after restart    : {readings['after_restart']:.2f} GB")
else:
    print("No running NIM, so there is nothing to stop. The cycle below reports "
          "n/a rather than inventing numbers.")
    readings = {"with_nim": None, "after_stop": None, "after_restart": None}

table, deltas = render_cycle(readings)
print()
print(table)
''')

nb.code('''
# Hint 1: stop_nim already reports vram_before/after/freed. Use those to CHECK
# the independent measurement rather than to replace it. Two instruments
# agreeing is evidence; one instrument is an assumption.
if stop_report:
    print(f"stop_nim says freed : {stop_report.get('vram_freed_gb')} GB")
    print(f"we measured freed   : {deltas.get('freed_by_stop', float('nan')):.2f} GB")
    if isinstance(stop_report.get("vram_freed_gb"), (int, float)) \\
            and "freed_by_stop" in deltas:
        gap = abs(stop_report["vram_freed_gb"] - deltas["freed_by_stop"])
        print(f"disagreement        : {gap:.2f} GB")
        print("A gap of a few hundred MB is expected — the two readings are taken at "
              "different moments in the teardown. A gap of several GB means one of "
              "the two is measuring the wrong thing, and the one to distrust is the "
              "one you did not write.")
else:
    print("No stop was performed, so there is no helper figure to check against.")
''')

nb.model_answer(
    "**Was the restart figure the same as the original? Why might it differ?**\n\n"
    "Expect it to be *close but not equal*, and expect the second reading to be the "
    "**smaller** one more often than the larger. The mechanism, which hint 2 points at "
    "and which is worth stating precisely:\n\n"
    "The NIM sizes its KV cache pool at startup as a fraction of the VRAM that is "
    "**free at that moment**, not as a fixed number of gigabytes. So the pool size is a "
    "function of the state of the card when the container came up. Between your first "
    "reading and your restart, several things can have changed that state:\n\n"
    "- A Python kernel that touched CUDA in between holds a context — roughly 300–500 MB "
    "that was not held the first time.\n"
    "- A generator process that has not fully exited still owns memory the driver has "
    "not reclaimed.\n"
    "- Your own `read_used_gb()` call is free, but anything you ran between the "
    "measurements was not.\n\n"
    "A smaller pool is not a failure. It is the same policy applied to a different "
    "starting condition, and it is exactly why the coexistence strategy in Exercise 3 "
    "has to be *measured* rather than computed: the quantity you are trying to control "
    "depends on the state of the machine at the instant of a race you do not schedule.\n\n"
    "**What would be alarming**, and worth stopping to investigate: `after_stop` "
    "materially above the pre-NIM baseline. That means something other than the NIM is "
    "holding the card — usually a generator subprocess from an earlier cell that "
    "outlived its parent. `nim_status()` reports `gpu_used_gb` alongside the "
    "container's own `vram_gb` precisely so you can see that difference, and the fix is "
    "to find the PID with `nvidia-smi` and kill it, not to restart the NIM."
)

nb.extend(
    "The measurement above is two points in a cycle you cannot see between. Sampling "
    "`read_used_gb()` on a background thread every 200 ms across the whole stop/start "
    "sequence turns it into a curve, and the curve has a feature the two-point version "
    "cannot show: the shape of the teardown. If memory drops in one step, the CUDA "
    "context went with the process. If it drops in two, with a plateau, you are seeing "
    "the driver reclaim the context after the process has already exited — which is the "
    "reason `stop_nim` polls instead of measuring once, and seeing it happen is more "
    "convincing than reading that it does."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "A context manager that restores the prior state",
    goal="Write `nim_running()`, a context manager that guarantees the NIM is up inside "
         "the block and leaves the machine in the state it found it.",
    success="`test_nim_running()` prints four passing assertions: (a) inside the block "
            "the reasoner answers, (b) an already-running NIM survives the block, (c) a "
            "NIM you started is stopped on exit, (d) an exception raised inside the "
            "block still triggers the correct cleanup.",
    approach="Take the three NIM operations as injectable parameters. That is the only "
             "way to test all four cases in seconds rather than in model loads, and it "
             "is what lets this notebook prove the logic on a machine with no docker.",
)

nb.code('''
@contextmanager
def nim_running(cfg=None, *, status_fn=nim_status, start_fn=start_nim,
                stop_fn=stop_nim, reasoner_factory=None, timeout=2400):
    """Ensure a NIM is serving for the duration of the block, then restore.

    Restores rather than imposes: if the NIM was already up when you entered, it
    is still up when you leave. Only a NIM this function started gets stopped.

    The `*_fn` parameters exist for testability. See the commentary below for
    why that is worth the extra signature.
    """
    cfg = cfg or NimConfig()

    # The entire entry decision, in one line. Everything else follows from it.
    was_already_up = bool(status_fn(cfg).get("ready"))

    if not was_already_up:
        start_fn(cfg, wait=True, timeout=timeout)

    if reasoner_factory is None:
        from cosmos_course.models import Reasoner

        def reasoner_factory(c):
            return Reasoner(base_url=c.base_url)

    try:
        yield reasoner_factory(cfg)
    finally:
        # `finally`, not `except`. Cleanup must run whether the block returned
        # normally or raised, and an exception must still reach the caller.
        if not was_already_up:
            stop_fn(cfg)
''')

nb.code('''
class FakeNim:
    """A NIM that starts and stops instantly and remembers what happened.

    Case (c) — "a NIM you started is stopped on exit" — honestly tested against
    the real thing costs one model load per assertion. Against this it costs
    microseconds, and it tests the same branch of the same code.
    """

    def __init__(self, ready=False):
        self.ready = ready
        self.starts = 0
        self.stops = 0

    def status(self, cfg=None):
        return {"ready": self.ready, "running": self.ready}

    def start(self, cfg=None, wait=True, timeout=None):
        self.starts += 1
        self.ready = True
        return {"already_running": False, "startup_seconds": 0.0}

    def stop(self, cfg=None, quiet=False):
        self.stops += 1
        self.ready = False
        return {"stopped": True, "vram_freed_gb": 0.0}


class FakeReasoner:
    def __init__(self, cfg):
        self.base_url = cfg.base_url

    def health(self):
        return True

    def ask(self, prompt, **kwargs):
        return "a fake reasoner answered"
''')

nb.code('''
def test_nim_running():
    """Assert the four behaviours and print each one that passes."""
    passed = []

    # (a) inside the block the reasoner answers
    fake = FakeNim(ready=False)
    with nim_running(NIM, status_fn=fake.status, start_fn=fake.start,
                     stop_fn=fake.stop, reasoner_factory=FakeReasoner) as r:
        assert r.health() is True
        assert "answered" in r.ask("anything")
    passed.append("(a) the block yields a reasoner that answers")

    # (b) an already-running NIM survives the block
    fake = FakeNim(ready=True)
    with nim_running(NIM, status_fn=fake.status, start_fn=fake.start,
                     stop_fn=fake.stop, reasoner_factory=FakeReasoner):
        pass
    assert fake.starts == 0, "started a NIM that was already up"
    assert fake.stops == 0, "stopped a NIM it did not start"
    assert fake.ready is True, "left an already-running NIM stopped"
    passed.append("(b) an already-running NIM is neither restarted nor stopped")

    # (c) a NIM you started is stopped on exit
    fake = FakeNim(ready=False)
    with nim_running(NIM, status_fn=fake.status, start_fn=fake.start,
                     stop_fn=fake.stop, reasoner_factory=FakeReasoner):
        assert fake.ready is True, "did not start a stopped NIM"
    assert fake.starts == 1 and fake.stops == 1, (fake.starts, fake.stops)
    assert fake.ready is False, "left behind a NIM it started"
    passed.append("(c) a NIM this function started is stopped on exit")

    # (d) an exception inside the block still triggers the correct cleanup,
    #     AND still propagates.
    fake = FakeNim(ready=False)
    propagated = False
    try:
        with nim_running(NIM, status_fn=fake.status, start_fn=fake.start,
                         stop_fn=fake.stop, reasoner_factory=FakeReasoner):
            raise ValueError("deliberate failure inside the block")
    except ValueError:
        propagated = True
    assert propagated, "the context manager swallowed the exception"
    assert fake.stops == 1, "cleanup did not run after an exception"
    assert fake.ready is False, "an exception leaked a running container"
    passed.append("(d) an exception cleans up AND propagates")

    for line in passed:
        print("PASS " + line)
    return len(passed) == 4


assert test_nim_running(), "all four behaviours must hold"
''')

nb.code('''
# The fakes prove the LOGIC. They cannot prove the logic is wired to the right
# functions — a typo binding `stop_fn` to the wrong callable would pass every
# test above. So exercise it once against the real NIM when one is available.
if NIM_READY:
    before = nim_status(NIM)["ready"]
    with nim_running(NIM) as reasoner:
        print(f"inside the block: healthy={reasoner.health()}  model={reasoner.model}")
    after = nim_status(NIM)["ready"]
    assert before == after is True, (before, after)
    print("PASS the real NIM was already up, and is still up after the block")
elif CAN_START_NIM:
    print("A NIM could be started here, and the honest test of case (c) is to do it "
          "once and time it. That costs a full model load, so it is left as a "
          "deliberate opt-in:")
    print()
    print("    t0 = time.perf_counter()")
    print("    with nim_running(NIM) as reasoner:")
    print("        print(reasoner.ask('Reply with the single word: ready'))")
    print("    print(f'cold start + one call + stop: {time.perf_counter() - t0:.0f} s')")
    print()
    print("Record what you get. Do not copy a number from anywhere, including here.")
else:
    print("No NIM available, so the real-wiring check is skipped. The four logical "
          "cases above are still proven; what is unproven is that the defaults "
          "point at the real start_nim/stop_nim, which you can confirm by reading "
          "the signature.")
''')

nb.why(
    "**Why the operations are injectable, when the exercise did not ask for it.** "
    "Hint 2 concedes the problem: honestly testing case (c) means starting from a "
    "stopped NIM, which costs a model load. With four cases and a couple of minutes per "
    "cold start, an honest test suite takes ten minutes and you will stop running it. "
    "A test you stop running is not a test.\n\n"
    "Parameterising `status_fn`, `start_fn` and `stop_fn` makes all four cases run in "
    "microseconds against `FakeNim`, and — the part that matters for this course — makes "
    "them run *at all* on a machine with no docker. The cost is three extra keyword "
    "arguments in a signature nobody will pass. That is a good trade, and it is the same "
    "trade the standard library makes everywhere it accepts an `opener` or a `key`.\n\n"
    "What the fakes cannot prove is that the defaults are wired to the right functions, "
    "so the cell above exercises the real path once. Fakes for logic, one real call for "
    "wiring — that division is worth internalising, because a test suite made entirely "
    "of fakes passes on a completely disconnected program.\n\n"
    "**Why `finally` and not `except`.** Hint 2 flags this as the case people get wrong, "
    "and the failure is specific. With `except`, either you re-raise (in which case you "
    "have written `finally` the long way) or you do not, and then a failure inside the "
    "block is silently swallowed — the caller sees a clean exit from a block that threw. "
    "Test (d) asserts *both* halves: cleanup ran, and the `ValueError` still reached the "
    "caller. Asserting only the first would pass on a context manager that eats "
    "exceptions, which is the exact bug.\n\n"
    "**Why \"restore, do not impose\" is the right policy.** The alternative — always "
    "stop the NIM on exit — is simpler and is wrong for a specific, common situation: "
    "you are working in a notebook with a NIM you deliberately left running, you call "
    "one helper that happens to use `nim_running` internally, and your NIM is gone. "
    "You then pay a cold start for a decision a library made on your behalf. A context "
    "manager should leave the world as it found it; that is the contract that makes it "
    "safe to nest and safe to call from code you did not read.\n\n"
    "**One thing this implementation does not do**, and a reasonable answer might: it "
    "does not verify readiness *after* `start_fn` returns. `start_nim(wait=True)` "
    "already blocks on the health endpoint, so the check would be redundant against the "
    "real implementation — but it would catch a `start_fn` that lies, and if your "
    "version re-checks `status_fn(cfg)['ready']` after starting and raises a clear error "
    "when it is still False, yours fails better than this one."
)

nb.extend(
    "The obvious next version takes a `memory_fraction` argument and starts the NIM "
    "capped, so a block can declare \"I need the reasoner *and* 12 GB for generation\". "
    "That turns the context manager from a scheduler into a budget, and it is what "
    "Exercise 3 is measuring the feasibility of. Worth writing only after you have run "
    "Exercise 3 and know whether the cap works on your image — a budget enforced by a "
    "flag the server ignores is worse than no budget, because it reads as a guarantee."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "Find the dual-tenancy frontier empirically",
    goal="Determine by measurement the largest NIM memory fraction under which a "
         "Cosmos3-Edge generation still succeeds on your machine, and report the "
         "frontier with its uncertainty.",
    success="A fraction and a confidence interval, evidence that the cap has a "
            "measurable effect on held VRAM, and a report explaining any gap between "
            "the measured frontier and the predicted one.",
    approach="Verify the knob before searching it; bracket the search from "
             "`vram_budget()`; repeat the boundary; and write the report from whatever "
             "evidence actually exists, labelled as measured or predicted. The "
             "criterion's \"confidence interval\" needs care: bisection returns a "
             "bracket, whose width is set by the stopping rule and not by the data, so "
             "the interval is obtained separately by repeating the whole search.",
)

nb.code('''
budget = cc.vram_budget()
total_gb = budget["total_gb"]
edge_need = budget["generator"]["Cosmos3-Edge"]
predicted_fraction = suggest_memory_fraction("Cosmos3-Edge", total_gb=total_gb)

print(json.dumps(budget, indent=1))
print()
print(f"predicted coexistence fraction for Edge : {predicted_fraction}")
print()
# The bracket, justified rather than picked. The lower end is where the NIM
# cannot hold its own weights (about 8 GB at FP8, so ~0.10 of an 80 GB card);
# the upper end is 1.0, where it takes everything and generation certainly
# fails. The predicted frontier must lie strictly inside that, or the arithmetic
# in vram_budget() is already telling you coexistence is impossible.
LOW = round(max(0.10, (budget["nim_weights_fp8_gb"] + 1.0) / total_gb), 3)
HIGH = 0.95
print(f"search bracket : [{LOW}, {HIGH}]")
print(f"  low  = the NIM's own FP8 weights ({budget['nim_weights_fp8_gb']} GB) plus 1 GB")
print(f"  high = 0.95; above this the generator's {edge_need} GB cannot fit whatever "
      f"the NIM does")
assert LOW < HIGH
if predicted_fraction is not None:
    print(f"  arithmetic predicts the frontier near {predicted_fraction:.2f}")
''')

nb.code('''
def cap_takes_effect(fraction, *, baseline_vram_gb=None):
    """Instruction 2: does the cap do anything at all on this image?

    Returns (verdict, detail). Verdict is one of "works", "no effect",
    "unmeasurable". This runs BEFORE any search, because a search over a knob
    that is ignored produces a confident number describing nothing.
    """
    if not CAN_START_NIM:
        return "unmeasurable", "no docker / no NGC key / no nvidia-smi on this machine"
    stop_nim(NIM, quiet=True)
    capped = NimConfig(gpu_memory_fraction=fraction)
    start_nim(capped, wait=True, timeout=2400)
    held = nim_status(capped)["vram_gb"]
    if held is None:
        return "unmeasurable", ("nvidia-smi cannot attribute per-process VRAM here; "
                                "fall back to whole-card used minus baseline")
    if baseline_vram_gb is None:
        return "works", f"held {held:.1f} GB at fraction {fraction} (no baseline to compare)"
    if abs(held - baseline_vram_gb) < 1.0:
        return "no effect", (
            f"held {held:.1f} GB capped vs {baseline_vram_gb:.1f} GB uncapped — the "
            f"env var {NIM_MEMORY_ENV} is not the knob this image reads. Run "
            f"cosmos_course.nim.discover_memory_env() to ask the image which names "
            f"it understands, and set COSMOS_COURSE_NIM_MEMORY_ENV to the right one. "
            f"Until then this experiment measures nothing, which is a reportable "
            f"result and not a failure.")
    return "works", (f"held {held:.1f} GB at fraction {fraction} vs "
                     f"{baseline_vram_gb:.1f} GB uncapped — a {baseline_vram_gb - held:.1f} GB "
                     f"difference, so the knob is real")
''')

nb.code('''
SMALL_SPEC = dict(model_mode="text2image", name="frontier_probe",
                  prompt="A plain grey calibration target on a white background.",
                  resolution="256", aspect_ratio="16,9", num_frames=1,
                  num_steps=8, seed=0)


def dual_tenancy(fraction, *, trials=1, generator=None):
    """Cap the NIM at `fraction`, then attempt an Edge generation `trials` times.

    Returns fraction, measured_nim_vram_gb, successes, failures, diagnoses and a
    note on whether the cap appeared to take effect.
    """
    out = {"fraction": fraction, "measured_nim_vram_gb": None, "successes": 0,
           "failures": 0, "diagnoses": [], "cap_note": "", "simulated": False}

    if not CAN_START_NIM:
        out["cap_note"] = "NIM cannot be started here; nothing was measured"
        return out

    stop_nim(NIM, quiet=True)
    capped = NimConfig(gpu_memory_fraction=fraction)
    start_nim(capped, wait=True, timeout=2400)
    st = nim_status(capped)
    out["measured_nim_vram_gb"] = st["vram_gb"]
    free_gb = (st["gpu_total_gb"] or total_gb) - (st["gpu_used_gb"] or 0.0)
    out["free_gb"] = round(free_gb, 2)

    generator = generator or cc.Generator(checkpoint="Cosmos3-Edge")
    problems = generator.check(verbose=False)
    if problems:
        # Hint 3: no checkpoint means predict rather than observe, and SAY so.
        out["cap_note"] = ("no usable generator (" + problems[0][:80] + "); using the "
                           "admission check instead of a real run — the frontier is "
                           "PREDICTED, not observed")
        fits = free_gb >= edge_need
        out["successes"] = trials if fits else 0
        out["failures"] = 0 if fits else trials
        out["simulated"] = True
        return out

    for trial in range(trials):
        spec = cc.InferenceSpec(**{**SMALL_SPEC, "name": f"probe_f{fraction}_t{trial}"})
        run = generator.run(spec, OUTPUT_DIR / f"frontier_{fraction}_{trial}",
                            seed=0, timeout=1800)
        # Instruction 5: a zero exit code is not success. Verify the artefact.
        checks = cc.verify_result(run, verbose=False)
        if run.ok and all(bool(c) for c in checks):
            out["successes"] += 1
        else:
            out["failures"] += 1
            out["diagnoses"].append(run.diagnose())
    return out
''')

nb.code('''
import random

# One generator, created once, drawn from on every call. Constructing
# random.Random(0) *inside* the probe would hand back the same draw every time,
# which looks like noise in the source and is a constant in the output — and
# then repeating a trial three times would prove nothing, because all three
# trials would be the same trial.
SIM_RNG = random.Random(0)


def simulated_probe(fraction, *, card_gb=None, nim_floor_gb=8.0, generator_need_gb=None,
                    reserve_gb=3.0, jitter_gb=0.6, rng=None):
    """A machine model, used ONLY when there is no machine to measure.

    The NIM takes max(its weights, fraction * card). The generator needs its
    working set plus a reserve, and its true peak varies run to run — which is
    why the exercise insists on repeating the boundary. `jitter_gb` stands in
    for that variance. Pass your own `rng` to get an independent replicate.
    Everything this returns is SIMULATED and is labelled as such wherever it is
    reported.
    """
    rng = rng or SIM_RNG
    card_gb = card_gb or total_gb
    generator_need_gb = generator_need_gb or edge_need
    nim_holds = max(nim_floor_gb, fraction * card_gb)
    free = card_gb - nim_holds - reserve_gb
    need = generator_need_gb + rng.gauss(0.0, jitter_gb)
    return free >= need


def find_frontier(probe, low, high, *, tolerance=0.02, trials=3, max_steps=8):
    """Binary-search the largest fraction at which generation still succeeds.

    `probe(fraction) -> bool` is one trial. The boundary is confirmed by
    repeating it `trials` times: a frontier established from a single trial is
    a coin flip, because the generator's peak allocation is not deterministic.

    Returns a BRACKET, not a confidence interval. `bracket` is [lo, hi] where
    lo passed every trial and hi did not, so the boundary is somewhere between
    them. Its width is whatever `tolerance` was set to — it is a property of
    the stopping rule, not of the machine. The key is named `bracket_width`
    rather than `uncertainty` for that reason: calling it uncertainty invites
    it to be read as an error bar, and it is not one. See the note below.
    """
    history = []
    lo, hi = low, high
    for _ in range(max_steps):
        if hi - lo <= tolerance:
            break
        mid = (lo + hi) / 2
        results = [bool(probe(mid)) for _ in range(trials)]
        rate = sum(results) / len(results)
        history.append({"fraction": round(mid, 4), "successes": sum(results),
                        "trials": len(results), "success_rate": rate})
        # "Succeeds" means every trial succeeded. A fraction that works two
        # times in three is not a frontier you would build on.
        if rate == 1.0:
            lo = mid
        else:
            hi = mid
    return {"frontier": round(lo, 4), "bracket_width": round(hi - lo, 4),
            "bracket": [round(lo, 4), round(hi, 4)], "history": history}
''')

nb.md(
    "### A bracket is not a confidence interval\n\n"
    "The exercise asks for \"a fraction and a confidence interval\". What `find_frontier` "
    "returns is a **bracket**. Reporting one as the other is the easiest piece of "
    "dishonesty to miss in this whole solution, so it gets its own section.\n\n"
    "A bracket says: *the answer is somewhere between these two values, and I stopped "
    "looking when the gap got small enough.* Its width is whatever you set `tolerance` "
    "to — a decision made before any data arrived. A confidence interval says something "
    "different: *if this whole experiment were repeated many times, the answers would "
    "mostly land in this range.* Its width comes from how much the answer actually moves "
    "between repeats, which is a property of the machine and not of your patience.\n\n"
    "**The tell is that the bracket shrinks for free.** Change `tolerance=0.02` to "
    "`tolerance=0.001` and it comes back more than ten times narrower after a handful of "
    "extra probes — and nothing has been learned about variability in between, because "
    "those extra probes went to *new* fractions to locate the boundary more precisely, "
    "not to re-measuring anything. No confidence interval behaves like that: halving a CI "
    "takes roughly four times as many observations of the same quantity, and there is no "
    "keyword argument that will do it.\n\n"
    "The next cell shows both. It drives `tolerance` down and watches the bracket "
    "collapse, then repeats the entire search twenty times against independent replicates "
    "of the simulated machine and reports the spread across those repeats. **That spread "
    "is the interval the exercise was asking for.** Watch where it ends up relative to the "
    "narrowest bracket: the bracket is far tighter than the answer's actual run-to-run "
    "variation, which is precisely why reporting a bracket as a CI is a problem — it "
    "makes the result look more settled than it is.\n\n"
    "**On real hardware the replicate route is expensive, and the answer changes shape.** "
    "One search is about six bisection steps at three trials each, and every trial stops "
    "and restarts the NIM, so twenty replicates is on the order of 360 restarts and 360 "
    "generations. Two honest options: replicate the search a handful of times and report "
    "a crude spread, or — cheaper, and usually the more useful number — fix the fraction "
    "at the frontier the single search found, run n generations there, and report a "
    "binomial confidence interval on the success rate at that one fraction. The second "
    "costs n generations with no restarts and answers the question you will actually be "
    "asked, which is \"if I cap the NIM here, how often does generation start?\""
)

nb.code('''
import statistics


def search_with_seed(seed, *, tolerance=0.02, max_steps=20):
    """One complete search against an independent replicate of the machine.

    The generator is built once per search and passed in, so successive probes
    within a search draw fresh values rather than repeating one draw.
    """
    rng = random.Random(seed)
    return find_frontier(lambda f: simulated_probe(f, rng=rng), LOW, HIGH,
                         tolerance=tolerance, trials=3, max_steps=max_steps)


# Demonstration 1: bracket width follows the stopping rule. Same seed, same
# machine, same noise process on every row — only `tolerance` changes.
print("SIMULATED. Bracket width is set by `tolerance`, not by the machine:\\n")
print(f"{'tolerance':>10}{'probes':>8}{'bracket width':>15}{'frontier':>10}")
for tol in (0.05, 0.02, 0.005, 0.001):
    r = search_with_seed(11, tolerance=tol)
    print(f"{tol:>10}{len(r['history']):>8}{r['bracket_width']:>15.4f}"
          f"{r['frontier']:>10.4f}")
narrowest = search_with_seed(11, tolerance=0.001)["bracket_width"]

# Demonstration 2, and the actual answer to "report a confidence interval":
# repeat the WHOLE search on independent replicates and see how far the answer
# moves. That spread is sampling variability, which is what an interval is for.
#
# The replicates run at a FINER tolerance than the hardware search would use.
# A bisection can only report answers on a grid as coarse as its tolerance, so
# at 0.02 the grid is about as wide as the spread being measured and hides it.
# Probes are free against the model, so there is no reason to pay that here.
REPLICATES = 20
SEARCH_TOLERANCE = 0.005
replicate_frontiers = sorted(
    search_with_seed(1000 + s, tolerance=SEARCH_TOLERANCE)["frontier"]
    for s in range(REPLICATES))
deciles = statistics.quantiles(replicate_frontiers, n=10)
REPLICATE_INTERVAL = [round(deciles[0], 4), round(deciles[-1], 4)]
replicate_median = round(statistics.median(replicate_frontiers), 4)

print(f"\\n{REPLICATES} independent replicate searches at tolerance "
      f"{SEARCH_TOLERANCE} (SIMULATED):")
print(f"  median frontier          : {replicate_median:.4f}")
print(f"  middle 80% of replicates : [{REPLICATE_INTERVAL[0]:.4f}, "
      f"{REPLICATE_INTERVAL[1]:.4f}]   width "
      f"{REPLICATE_INTERVAL[1] - REPLICATE_INTERVAL[0]:.4f}")
print(f"  full range               : [{replicate_frontiers[0]:.4f}, "
      f"{replicate_frontiers[-1]:.4f}]")
print(f"  standard deviation       : {statistics.stdev(replicate_frontiers):.4f}")
print(f"\\nThe comparison that matters: the tightest bracket above is "
      f"{narrowest:.4f} wide, while the answer itself moves over "
      f"{replicate_frontiers[-1] - replicate_frontiers[0]:.4f} between repeats. "
      f"A bracket can be made as narrow as you like and it never finds that out.")
print("Twenty replicates is enough to see the spread and not enough to pin its "
      "edges — the two endpoints above are themselves noisy. Read it as the "
      "size of the variability, not as a precise boundary. And it is variability "
      "of a SIMULATED machine; on hardware the method is the same and the "
      "numbers are not.")
''')

nb.code('''
# Verify the SEARCH before using it, against a machine model whose answer is
# known by construction: with no jitter, the frontier is exactly where free
# VRAM stops covering the generator's need.
def _noiseless(fraction):
    return simulated_probe(fraction, jitter_gb=0.0)


exact = (total_gb - 3.0 - edge_need) / total_gb
found = find_frontier(_noiseless, LOW, HIGH, tolerance=0.005, trials=1)
print(f"analytic frontier : {exact:.4f}")
print(f"searched frontier : {found['frontier']:.4f}  "
      f"(bracket {found['bracket_width']:.4f} wide)")
assert abs(found["frontier"] - exact) <= 0.01, (found, exact)
print("PASS the binary search finds the analytic frontier of a noiseless machine")

# And with noise, the frontier must come out CONSERVATIVE — below the noiseless
# one — because requiring all three trials to pass excludes the marginal band.
noisy = find_frontier(simulated_probe, LOW, HIGH, tolerance=0.005, trials=3)
print(f"\\nnoisy frontier    : {noisy['frontier']:.4f} "
      f"(bracket {noisy['bracket_width']:.4f} wide)")
assert noisy["frontier"] <= found["frontier"] + 1e-9, (noisy, found)
print("PASS requiring 3/3 trials yields a frontier at or below the noiseless one — "
      "the conservative direction, which is what you want from an admission limit")
''')

nb.code('''
# Now the real thing, if the machine allows it.
frontier_result = None
cap_verdict, cap_detail = "unmeasurable", "not attempted"
uncapped_hold = STATUS.get("vram_gb")

if CAN_START_NIM:
    cap_verdict, cap_detail = cap_takes_effect(0.5, baseline_vram_gb=uncapped_hold)
    print(f"cap check: {cap_verdict} — {cap_detail}")
    if cap_verdict == "works":
        def real_probe(fraction):
            r = dual_tenancy(fraction, trials=1)
            return r["successes"] > 0
        frontier_result = find_frontier(real_probe, LOW, HIGH, tolerance=0.02, trials=3)
        # One search gives a bracket and nothing more. Replicating it on real
        # hardware would cost roughly 120 NIM restarts, so it is not run here
        # and the report says so instead of dressing the bracket up as an
        # interval.
        frontier_result = {**frontier_result, "simulated": False,
                           "replicates": 1, "replicate_median": None,
                           "replicate_interval": None}
        print(json.dumps(frontier_result, indent=1))
    else:
        print("Not searching: instruction 2 says a knob that does not move is a "
              "reportable result, and searching it anyway would produce a number "
              "with no referent.")
else:
    print(f"cap check: {cap_verdict} — {cap_detail}")
    print("Falling back to the simulated machine for the report below, clearly "
          "labelled as predicted.")
    # One representative search supplies the bracket; the twenty replicates
    # above supply the interval. `noisy` is not reused here — it exists to
    # verify the search, at a tolerance chosen for that job, not to answer the
    # question.
    sim_single = search_with_seed(1000, tolerance=SEARCH_TOLERANCE)
    frontier_result = {
        "frontier": sim_single["frontier"],
        "bracket": sim_single["bracket"],
        "bracket_width": sim_single["bracket_width"],
        "history": sim_single["history"],
        "simulated": True,
        "replicates": REPLICATES,
        "replicate_median": replicate_median,
        "replicate_interval": REPLICATE_INTERVAL,
    }
''')

nb.code('''
report_path = OUTPUT_DIR / "dual_tenancy.md"
simulated = bool((frontier_result or {}).get("simulated"))

lines = [
    "# Dual-tenancy frontier — Cosmos3-Edge alongside the Reasoner NIM",
    "",
    ("**These numbers are SIMULATED.** No NIM could be started on this machine, so "
     "the frontier below comes from the machine model in `simulated_probe`, not from "
     "measurement. Re-run on a machine with docker, an NGC key and the Edge "
     "checkpoint to replace it."
     if simulated else
     "Measured on this machine. Every number below came from a run, not from arithmetic."),
    "",
    "## Method",
    "",
    "1. Verify the cap has an effect at all before searching "
    f"(`{NIM_MEMORY_ENV}`); a search over an ignored knob measures nothing.",
    f"2. Bracket the search at [{LOW}, {HIGH}], justified from `cc.vram_budget()`: the "
    f"low end is the NIM's own FP8 weights plus 1 GB, the high end is where "
    f"Cosmos3-Edge's {edge_need} GB cannot fit under any policy.",
    "3. Binary-search, requiring **3 of 3** trials to succeed before accepting a "
    "fraction. Generation peak allocation varies run to run, so a frontier from one "
    "trial is a coin flip.",
    "4. Confirm each success with `cc.verify_result()`, not the exit code.",
    "5. Report the bisection **bracket** and the interval across repeats as two "
    "separate things, because they are two separate things. The bracket is where "
    "the boundary sits given the stopping rule; the interval is how far the answer "
    "moves when the whole search is repeated.",
    "",
    "## Result",
    "",
    f"- cap verification: **{cap_verdict}** — {cap_detail}",
]
if frontier_result:
    lines += [
        f"- frontier: **{frontier_result['frontier']:.3f}**",
        f"- bisection bracket: [{frontier_result['bracket'][0]:.3f}, "
        f"{frontier_result['bracket'][1]:.3f}] — the lower bound passed 3/3, the "
        f"upper bound did not",
        f"- bracket width: {frontier_result['bracket_width']:.3f}, which is the "
        f"`tolerance` the search stopped at. **This is not a confidence interval.** "
        f"Tightening `tolerance` narrows it without collecting any new information "
        f"about how much the answer varies, so it must not be reported as one.",
        f"- probes run: {len(frontier_result['history'])}",
    ]
    if frontier_result.get("replicate_interval"):
        lo_r, hi_r = frontier_result["replicate_interval"]
        lines.append(
            f"- **interval across repeats**: [{lo_r:.3f}, {hi_r:.3f}] — the middle "
            f"80% of {frontier_result['replicates']} replicate searches, median "
            f"{frontier_result['replicate_median']:.3f}. This one *is* a statement "
            f"about variability: it is how far the answer moved when the entire "
            f"search was repeated on independent replicates. Simulated, like every "
            f"other number in this section, and crude at "
            f"{frontier_result['replicates']} replicates — the endpoints are "
            f"themselves noisy.")
    else:
        lines.append(
            "- **interval across repeats**: not computed. The search was run once. "
            "Every probe stops and restarts the NIM, so twenty replicates would "
            "cost on the order of 360 restarts and 360 generations. To put a real "
            "interval on this number, either replicate "
            "the whole search a handful of times and report the spread, or hold the "
            "fraction at the frontier, run n generations there and report a binomial "
            "interval on the success rate at that fraction. The bracket above is not "
            "a substitute for either, and the exercise's confidence-interval "
            "criterion is not met by it.")
else:
    lines.append("- frontier: not determined (see cap verification above)")

lines += [
    "",
    "## Prediction vs measurement",
    "",
    f"`cc.vram_budget()` predicts a coexistence fraction of "
    f"**{predicted_fraction if predicted_fraction is not None else 'not feasible'}** "
    f"for Cosmos3-Edge on a {total_gb:.0f} GB card, from "
    f"total - reserve({budget['reserve_gb']} GB) - generator({edge_need} GB).",
    "",
    "Expected sources of disagreement, in the order they are likely to matter:",
    "",
    "1. **The reserve is a guess.** 3 GB covers the CUDA context and cuDNN "
    "workspaces of a typical run. Guardrail models load alongside the generator and "
    "are not in that figure.",
    "2. **The generator's need is a documented figure, not a measurement.** Edge's "
    f"{edge_need} GB is a working estimate; Lesson 06 measures the real peak.",
    "3. **The NIM's pool is sized against free VRAM at startup**, so the same "
    "fraction gives a different absolute hold depending on what else was resident "
    "when it started — which is why the frontier moves between sessions.",
    "",
    "A measured frontier *below* the prediction means the reserve is too small. "
    "A measured frontier *above* it means the generator needs less than the "
    "documented figure, which is worth knowing and worth re-measuring in Lesson 14.",
]
report_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {report_path}\\n")
print("\\n".join(lines))
''')

nb.why(
    "**Instruction 2 is the whole exercise, and it is easy to skip.** Binary-searching a "
    "flag the server ignores produces a clean, confident number that means nothing — and "
    "it will look exactly like a result. `COSMOS3_FACTS.md` does not fix the name of the "
    "memory environment variable, and `cosmos_course.nim` says as much: `NIM_MEMORY_ENV` "
    "defaults to `NIM_MAX_GPU_MEMORY_UTILIZATION` and there is a "
    "`NIM_MEMORY_ENV_CANDIDATES` list plus a `discover_memory_env()` helper precisely "
    "because the right name is uncertain. So `cap_takes_effect` runs first, compares "
    "capped against uncapped held VRAM, and returns `\"no effect\"` as a *legitimate "
    "final answer* rather than a failure to be worked around.\n\n"
    "**Why 3 of 3 and not majority.** `find_frontier` accepts a fraction only when every "
    "trial succeeds. A fraction that works two times in three is not a frontier; it is "
    "the middle of the transition band. Since the number is going to be used as an "
    "admission limit — \"cap the NIM here and generation will still start\" — the "
    "conservative reading is the useful one. The simulated check asserts this property "
    "directly: with noise, the 3/3 frontier must land at or below the noiseless "
    "frontier. That assertion is worth more than the frontier itself, because it "
    "verifies the *search* rather than the machine.\n\n"
    "**Why the bracket is reported as a bracket, and where the interval comes from.** "
    "The exercise asks for a confidence "
    "interval, and the obvious thing to do is print `[lo, hi]` from the bisection under "
    "that heading. It would be wrong. `[lo, hi]` is a bracket: `lo` passed every trial, "
    "`hi` did not, and the gap between them is `tolerance` — a number chosen before any "
    "probe ran. A confidence interval is a claim about sampling variability, and the "
    "bracket contains no information about variability at all. The demonstration cell "
    "makes that concrete by shrinking `tolerance` until the bracket is an order of "
    "magnitude narrower than the run-to-run spread of the answer, which is the shape of "
    "the error: a bracket reported as a CI overstates how settled the number is, and it "
    "overstates it by however much you tightened the stopping rule. So the report prints "
    "both, under separate headings, and where no replicates were run it says so rather "
    "than promoting the bracket.\n\n"
    "**Why the search is verified against a model before being run for real.** Each real "
    "probe costs a NIM restart plus a generation — call it minutes. A bug in the "
    "bisection (an off-by-one in the bracket update, accepting on `rate > 0` instead of "
    "`rate == 1`) would cost an hour and produce a wrong number that looks fine. "
    "`simulated_probe` with `jitter_gb=0` has an analytically known frontier, so the "
    "search can be checked to within 0.01 in milliseconds. This is the same move as "
    "Lesson 01's fake checkpoint, and it is the single most transferable habit in these "
    "three exercises: **build the cheap thing whose answer you already know, and use it "
    "to check the expensive thing whose answer you do not.**\n\n"
    "**Why `cc.verify_result` and not `returncode == 0`.** A run that the guardrail "
    "rejected exits zero and writes a blank frame. Under memory pressure — which is "
    "exactly the regime being searched — the interesting failures are the quiet ones. "
    "Accepting exit code 0 as success would place the frontier above the point where "
    "output stops being usable, which is the worst possible direction to be wrong in "
    "for a limit you are going to configure against.\n\n"
    "**The alternative approach that was rejected: a linear sweep.** Stepping the "
    "fraction from 0.10 to 0.95 in increments of 0.05 is simpler, needs no bracket "
    "argument, and gives you the whole response curve rather than one boundary. It also "
    "costs 18 probes instead of about 6. If each probe were cheap, the sweep would be "
    "the better experiment — you would see whether the transition is sharp or gradual, "
    "which the bisection cannot tell you. At minutes per probe, bisection wins. If you "
    "swept, you got more information for more time, and that is a defensible trade "
    "rather than a wrong answer."
)

nb.extend(
    "The frontier found here is for one generation shape — 256p, one frame, eight "
    "steps. It is not one number, it is a curve: the frontier against a 121-frame 480p "
    "video sits materially lower, because activation memory scales with the token count "
    "while the NIM's hold does not. Running the search at three job sizes and plotting "
    "frontier against `cost_units` turns \"cap the NIM at 0.55\" into \"cap the NIM at "
    "0.55 for stills and 0.35 for video\", which is the form the answer needs to be in "
    "before you would configure anything against it."
)

nb.finish()
