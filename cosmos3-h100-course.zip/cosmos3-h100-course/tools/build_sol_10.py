"""Build solutions/10_solutions.ipynb — reference answers for Lesson 10."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("10", "Action: forward dynamics",
                      lesson_file="10_action_forward_dynamics.ipynb")

nb.header(
    "Forward dynamics turns an action sequence into video, and the thing that makes it "
    "treacherous is that **a well-formed action array is not a correct one**. The "
    "foundation exercise proves that directly: a camera trajectory and an AV trajectory "
    "are both 60x9, so the width preflight cannot tell them apart. The applied one has "
    "you author a trajectory from scratch and — more importantly — write the validator "
    "that would have caught your own mistakes. The challenge one edits trajectories and "
    "then asks the harder question: how do you know the edit reached the video?"
)

nb.callout(
    "warning",
    "**This lesson needs Cosmos3-Nano** (~35 GB) and the cookbook action assets, and the "
    "lesson gates it behind `ALLOW_NANO_DOWNLOAD`. That gate is respected here. The "
    "trajectory mathematics — rot6d encoding and decoding, the validator, the edits, the "
    "determinant check — is pure numpy and runs and is verified on any machine. Where a "
    "generated video is needed, the cell says what it would have produced.",
)

nb.prelude(
    "The lesson's configuration, its trajectory loader, its spec builder and the "
    "embodiment/action-width table."
)
nb.code(setup_cell("10"))

nb.code('''
import json
import math
import subprocess
import time

import numpy as np

from cosmos_course.models import Generator

ACTION_MODEL = "Cosmos3-Nano"
ALLOW_NANO_DOWNLOAD = os.environ.get("COSMOS_COURSE_ALLOW_NANO", "0") == "1"
gen = cc.Generator(checkpoint=ACTION_MODEL)
framework_problems = gen.check(verbose=False)

CHUNK = 30 if MODE == "reduced" else 60
TIMEOUT_S = 1800 if MODE == "reduced" else 3600
AV_PROMPT = "You are an autonomous vehicle planning system."
RUN = (ALLOW_NANO_DOWNLOAD and not framework_problems
       and DEVICE.startswith("cuda"))

print(f"checkpoint : {ACTION_MODEL} ({cc.MODEL_TIERS[ACTION_MODEL]['download_gb']} GB)")
print(f"RUN        : {RUN}")
for p in framework_problems:
    print(f"  ! {p}")

ASSET_NAMES = ["av_start_frame", "av_traj_forward", "av_traj_left", "av_traj_right",
               "camera_action"]
assets = {name: cc.asset_or_none(name) for name in ASSET_NAMES}
missing = [n for n, p in assets.items() if p is None]
print(f"assets     : {'all present' if not missing else 'missing ' + str(missing)}")
''')

nb.code('''
def load_trajectory(path):
    """Read an action JSON into a [steps, dims] float array."""
    rows = json.loads(Path(path).read_text())
    arr = np.asarray(rows, dtype=np.float64)
    if arr.ndim != 2:
        raise ValueError(f"{Path(path).name}: expected a list of equal-length rows, "
                         f"got shape {arr.shape}")
    return arr


def av_forward_spec(name, action_path, chunk=None, *, domain_name="av",
                    vision_path=None, fps=10):
    """A forward_dynamics spec. `domain_name` is a PARAMETER here, not a constant —
    Exercise 1 turns entirely on being able to vary it."""
    return cc.InferenceSpec(
        model_mode="forward_dynamics", name=name, prompt=AV_PROMPT,
        vision_path=str(vision_path or assets["av_start_frame"]),
        action_path=str(action_path), domain_name=domain_name,
        view_point="ego_view", action_chunk_size=chunk or CHUNK,
        fps=fps, image_size=480, seed=0,
    )


def run_and_verify(spec, subdir, *, label=None):
    """Run one action job and verify by content. None when generation is off."""
    label = label or spec.name
    if not RUN:
        print(f"skipped {label!r}: generation is disabled "
              f"(ALLOW_NANO_DOWNLOAD is False, no GPU, or no framework)")
        return None
    for problem in cc.validate_spec(spec, strict=False):
        print("  spec warning:", problem)
    with cc.timer(label, track_memory=False) as timing:
        result = gen.run(spec, OUTPUT_DIR / subdir, seed=spec.seed or 0,
                         timeout=TIMEOUT_S)
    print(f"  {timing.seconds:.1f} s")
    cc.verify_result(result)
    return result


# The embodiment -> raw action width table. Read from the installed framework
# when it is there; otherwise from COSMOS3_FACTS.md section 5, LABELLED as the
# fallback. The lesson's point is to look it up rather than to remember it, and
# a hard-coded copy presented as authoritative would undo that.
DIMS_FALLBACK = {"av": 9, "camera_pose": 9, "bridge_orig_lerobot": 10,
                 "droid_lerobot": 10, "umi": 10, "agibotworld": 29}
dims, dims_source = DIMS_FALLBACK, "COSMOS3_FACTS.md section 5 (framework not readable here)"
if not framework_problems:
    try:
        proc = subprocess.run(
            [str(gen.python), "-c", (
                "import json\\n"
                "mod=None\\n"
                "for n in ('cosmos_framework.data.generator.action.utils.domain_utils',"
                "'cosmos_framework.data.vfm.action.domain_utils'):\\n"
                "    try:\\n"
                "        mod=__import__(n, fromlist=['x']); break\\n"
                "    except Exception: pass\\n"
                "print(json.dumps(dict(sorted(mod.EMBODIMENT_TO_RAW_ACTION_DIM.items()))"
                ") if mod else '{}')")],
            cwd=str(gen.repo), capture_output=True, text=True, timeout=180, check=True)
        parsed = json.loads(proc.stdout.strip().splitlines()[-1])
        if parsed:
            dims, dims_source = parsed, "the installed framework"
    except Exception as exc:
        print(f"could not query the framework ({type(exc).__name__}); using the fallback")

print(f"action widths from: {dims_source}")
print(f"9-D domains: {[k for k, v in dims.items() if v == 9]}")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "The third trajectory, and a different embodiment",
    goal="Complete the AV set, then run something that is not an AV trajectory and "
         "discover that a correct action width is necessary and not sufficient.",
    success="Four videos exist, all verified with `verify_result`, and the limitation of "
            "the width check is written down.",
    approach="Look the domain up in the framework's own table rather than remembering "
             "it, and show — from the numbers in the two files — that they are "
             "distinguishable to a human and not to a width check.",
)

nb.code('''
CAMERA_TRAJ = assets["camera_action"]
CAMERA_IMAGES = sorted((cc.COOKBOOK / "generator/action/assets/images").glob("*_720.png")) \\
    if cc.COOKBOOK.exists() else []
print("candidate start images:", [p.name for p in CAMERA_IMAGES] or "(cookbook not fetched)")
print("9-D domains in the framework table:", [k for k, v in dims.items() if v == 9])

# The lookup, made explicit. Two domains are 9-D; only one of them describes a
# free camera move rather than a vehicle on a road.
CAMERA_DOMAIN = "camera_pose"
assert dims.get(CAMERA_DOMAIN) == 9, dims
print(f"\\ncamera_action.json belongs to domain_name={CAMERA_DOMAIN!r} "
      f"({dims[CAMERA_DOMAIN]}-D), NOT 'av' ({dims['av']}-D) — same width, "
      f"different semantics")

# A start image that suits a camera move rather than a road. The cookbook ships
# three 720p stills for exactly this; a road frame would confound the
# comparison, because an AV-domain run on a road frame can look plausible for
# the wrong reason.
CAMERA_IMAGE = next((p for p in CAMERA_IMAGES if "lighthouse" in p.name),
                    CAMERA_IMAGES[0] if CAMERA_IMAGES else None)
print(f"start image: {CAMERA_IMAGE.name if CAMERA_IMAGE else 'none available'}")
''')

nb.code('''
# Hint 2: plot the translation columns of both files before running anything.
# This is the evidence that the two files are different, and it costs nothing.
def translation_summary(path, label):
    arr = load_trajectory(path)
    t = arr[:, :3]
    print(f"{label:<22} shape {arr.shape}   "
          f"per-step |t| mean {np.linalg.norm(t, axis=1).mean():.4f}")
    print(f"{'':<22} accumulated (x, y, z): {np.round(t.sum(axis=0), 4)}")
    return arr


if assets["av_traj_forward"] and CAMERA_TRAJ:
    av_arr = translation_summary(assets["av_traj_forward"], "av_traj_forward")
    cam_arr = translation_summary(CAMERA_TRAJ, "camera_action")
    print()
    print(f"same width? {av_arr.shape[1] == cam_arr.shape[1]}   "
          f"-> a width check cannot separate them")
    dom_axis_av = int(np.argmax(np.abs(av_arr[:, :3].sum(axis=0))))
    dom_axis_cam = int(np.argmax(np.abs(cam_arr[:, :3].sum(axis=0))))
    print(f"dominant translation axis: av -> column {dom_axis_av}, "
          f"camera -> column {dom_axis_cam}")
    print("Different dominant axes mean different motion conventions, and that "
          "difference IS visible in the file — just not to a width check.")
else:
    print("Cookbook action assets are not on disk; run scripts/fetch_assets.py.")
    av_arr = cam_arr = None
''')

nb.code('''
def run_camera(domain, image, chunk=15, *, name=None):
    """Build, validate and run a camera_pose forward-dynamics job."""
    if CAMERA_TRAJ is None or image is None:
        print("camera assets are not on disk; nothing to run")
        return None
    arr = load_trajectory(CAMERA_TRAJ)
    expected = dims.get(domain)
    # The width preflight, run explicitly so its verdict is visible. It PASSES
    # for both domains, which is the whole point of the exercise.
    if expected is not None and arr.shape[1] != expected:
        raise ValueError(f"{CAMERA_TRAJ.name} is {arr.shape[1]}-D but domain "
                         f"{domain!r} expects {expected}-D")
    print(f"width preflight for domain={domain!r}: PASSES "
          f"({arr.shape[1]}-D matches {expected}-D)")
    spec = av_forward_spec(name or f"camera_{domain}", CAMERA_TRAJ, chunk=chunk,
                           domain_name=domain, vision_path=image,
                           fps=30)   # hint 2: the camera file is 30 fps, not 10
    return run_and_verify(spec, "camera", label=spec.name)


results = {}
if assets["av_traj_right"]:
    results["right"] = run_and_verify(
        av_forward_spec("av_right", assets["av_traj_right"]), "av", label="av_right")
results["camera_wrong"] = run_camera("av", CAMERA_IMAGE, name="camera_wrong_domain")
results["camera_right"] = run_camera(CAMERA_DOMAIN, CAMERA_IMAGE,
                                     name="camera_right_domain")

produced = {k: v for k, v in results.items() if v is not None}
print(f"\\n{len(produced)} video(s) produced")
for label, res in produced.items():
    checks = cc.verify_result(res, verbose=False)
    print(f"  {label:<20} {'all checks pass' if all(c.passed for c in checks) else [c.name for c in checks if not c.passed]}")
if not produced:
    print("  (generation is off, so no videos. The width-preflight verdicts above "
          "are the part of this exercise that does not need a GPU, and they are "
          "the part the written answer is about.)")
''')

nb.model_answer(
    "**What the width preflight does and does not protect you from.**\n\n"
    "*It protects you from* the class of error where the array's shape and the model's "
    "expectation disagree — a 10-D LeRobot trajectory fed to a 9-D AV domain, a "
    "transposed array, a file that lost a column in conversion. Those produce either a "
    "loud framework error or, worse, a silent reinterpretation of column boundaries, and "
    "a width check catches all of them before any GPU time is spent. That is worth "
    "having and it is cheap.\n\n"
    "*It does not protect you from* the semantics. `av` and `camera_pose` are both 9-D — "
    "`COSMOS3_FACTS.md` §5 lists them on the same line — so every width check in the "
    "world passes for both, and the model will happily consume a camera trajectory as if "
    "it were a vehicle's ego-motion. The output is well-formed video, exits zero, and "
    "passes `verify_result`, because `check_video` asks whether frames decode and change, "
    "not whether they changed in the commanded way. As `COSMOS3_FACTS.md` puts it: "
    "getting `domain_name` wrong produces well-formed, meaningless actions and a clean "
    "exit.\n\n"
    "**The general form, which is the point:** a shape check validates the *container*; "
    "nothing in the file validates the *interpretation*. The interpretation lives in your "
    "head and `domain_name` is where you write it down. Hint 1 says this exactly — the "
    "distinguishing information is not in the file at all.\n\n"
    "**What I would add, given that the width check cannot do it.** Two cheap "
    "statistical preflights that *are* computable from the file:\n\n"
    "1. **Dominant-axis check.** AV ego-motion accumulates almost everything on +Z "
    "(forward). A camera move that accumulates mostly on X is not a car. The cell above "
    "computes this in two lines and it separates the two files.\n"
    "2. **Magnitude-range check.** Per-step translation magnitudes for a shipped AV file "
    "sit in a narrow band; a camera move at 30 fps has a different scale entirely. A "
    "range check against the shipped exemplars catches a trajectory authored in the wrong "
    "units — which is the mistake you are most likely to make yourself in Exercise 2.\n\n"
    "Neither is a proof of correct domain. Both would have flagged this case, and both "
    "cost microseconds against a job that costs minutes."
)

nb.extend(
    "The two checks above are per-file heuristics. The version that generalises is a "
    "**fingerprint per domain**, computed once from the shipped exemplars: for each "
    "`domain_name`, the distribution of per-step translation magnitude, the dominant "
    "axis, and the typical fps. A new trajectory is then scored against every domain's "
    "fingerprint and the preflight reports *which domain it most resembles* rather than "
    "merely whether the width matches. When that disagrees with the `domain_name` you "
    "typed, you want to know before the run, not after."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "Author your own trajectory: a gentle S-curve",
    goal="Write a 9-D action trajectory from scratch that steers left then right, "
         "validate its format before spending GPU time, and generate from it.",
    success="`validate_trajectory` accepts all three shipped AV files and your own; the "
            "JSON generates without error; the output passes `verify_result`; and there "
            "is a written verdict on whether the S is visible.",
    approach="Calibrate the validator against the shipped files **first** — if it "
             "rejects `av_traj_forward.json`, the validator is wrong — and pick the "
             "magnitude tolerance from those files rather than from taste.",
)

nb.code('''
def yaw_to_rot6d(yaw_rad):
    """Rotation about the vertical (Y) axis, as the first two matrix columns.

    Hint 1's convention, and it is worth being explicit about which columns:
    `COSMOS3_FACTS.md` section 5 records that rot6d is the first two COLUMNS of
    the rotation matrix, not the first two rows. For a yaw about +Y,

        R = [[ cos,  0,  sin],
             [   0,  1,    0],
             [-sin,  0,  cos]]

    so col0 = (cos, 0, -sin) and col1 = (0, 1, 0). At yaw = 0 that is
    [1,0,0, 0,1,0], which is exactly row 0 of the shipped files — the sanity
    check hint 1 offers, and the reason to trust the convention rather than
    the derivation.
    """
    c, s = math.cos(yaw_rad), math.sin(yaw_rad)
    return np.array([c, 0.0, -s, 0.0, 1.0, 0.0], dtype=np.float64)


def rot6d_to_matrix(vec6):
    """Decode rot6d to a 3x3 rotation, the way the framework does.

    Gram-Schmidt on the two columns, then the third by cross product. Note that
    COSMOS3_FACTS.md section 5 records that upstream's decoder projects onto
    SO(3) with an SVD rather than using textbook Gram-Schmidt; on clean input
    the two agree to ~1e-16, and on skewed input they differ materially. This
    is the Gram-Schmidt form because it is what makes the orthogonality
    requirement in the validator meaningful — a decoder that projects would
    silently repair exactly the malformed input the validator exists to catch.
    """
    a, b = np.asarray(vec6[:3], float), np.asarray(vec6[3:6], float)
    e0 = a / (np.linalg.norm(a) or 1.0)
    b_perp = b - np.dot(e0, b) * e0
    e1 = b_perp / (np.linalg.norm(b_perp) or 1.0)
    e2 = np.cross(e0, e1)
    return np.column_stack([e0, e1, e2])


assert np.allclose(yaw_to_rot6d(0.0), [1, 0, 0, 0, 1, 0]), yaw_to_rot6d(0.0)
R = rot6d_to_matrix(yaw_to_rot6d(math.radians(30)))
assert abs(np.linalg.det(R) - 1.0) < 1e-9, np.linalg.det(R)
assert np.allclose(R @ R.T, np.eye(3), atol=1e-9)
print("PASS yaw 0 encodes to [1,0,0, 0,1,0]; a 30-degree yaw decodes to a proper "
      "rotation (det = +1, orthonormal)")
''')

nb.code('''
def make_s_curve(steps=30, speed=0.04, max_yaw_deg=1.5):
    """Return a [steps, 9] AV action trajectory that bends left then right.

    Hint 2's point drives the shape: these are PER-STEP DELTAS. The yaw in each
    row is the small turn made during that one step, not the heading so far. A
    smooth S is therefore a yaw that ramps positive over the first half and
    negative over the second — one full period of a sine — and the accumulated
    heading is its integral, which returns to zero at the end. That is what
    makes it an S rather than a C.
    """
    t = np.linspace(0.0, 1.0, steps)
    yaw_rad = np.radians(max_yaw_deg) * np.sin(2 * np.pi * t)
    rows = []
    for k in range(steps):
        translation = np.array([0.0, 0.0, speed])     # +Z is forward
        rows.append(np.concatenate([translation, yaw_to_rot6d(yaw_rad[k])]))
    return np.asarray(rows, dtype=np.float64)


s_curve = make_s_curve()
print(f"shape {s_curve.shape}")
print("first row :", np.round(s_curve[0], 5))
print("mid row   :", np.round(s_curve[len(s_curve) // 4], 5))
print(f"accumulated heading over the clip: "
      f"{math.degrees(sum(math.atan2(-r[2], r[0]) for r in s_curve)):.2f} degrees")
print("Near zero, as an S should be: the two bends cancel. A C-curve would "
      "accumulate.")
''')

nb.code('''
# STEP 3, DONE BEFORE ANYTHING ELSE: measure the shipped files, and take the
# tolerance from them. Picking a tolerance by taste and then discovering it
# rejects av_traj_forward.json is the failure the exercise is warning about.
shipped = {}
for name in ("av_traj_forward", "av_traj_left", "av_traj_right"):
    if assets.get(name):
        shipped[name] = load_trajectory(assets[name])

if shipped:
    all_rows = np.vstack(list(shipped.values()))
    mags = np.linalg.norm(all_rows[:, :3], axis=1)
    col_norms = np.concatenate([np.linalg.norm(all_rows[:, 3:6], axis=1),
                                np.linalg.norm(all_rows[:, 6:9], axis=1)])
    dots = np.abs(np.einsum("ij,ij->i", all_rows[:, 3:6], all_rows[:, 6:9]))
    print(f"shipped per-step |translation| : min {mags.min():.5f}  "
          f"max {mags.max():.5f}  mean {mags.mean():.5f}")
    print(f"shipped rot-column norms       : min {col_norms.min():.8f}  "
          f"max {col_norms.max():.8f}")
    print(f"shipped |col0 . col1|          : max {dots.max():.2e}")
    MAG_RANGE = (float(mags.min()) * 0.5, float(mags.max()) * 2.0)
    TOL = max(1e-4, float(max(abs(col_norms - 1).max(), dots.max())) * 10)
else:
    print("Shipped AV files are not on disk, so the tolerance cannot be calibrated "
          "from them. Falling back to values that are stated rather than measured.")
    MAG_RANGE, TOL = (0.001, 0.5), 1e-3

print(f"\\nchosen orthonormality tolerance : {TOL:.2e}")
print(f"chosen |translation| range      : {MAG_RANGE[0]:.5f} to {MAG_RANGE[1]:.5f}")
print("Both are DERIVED from the shipped files with a safety factor, not chosen. "
      "The tolerance is 10x the worst deviation the shipped files show, which "
      "leaves room for float32 round-tripping through JSON without accepting "
      "anything that is actually skewed.")
''')

nb.code('''
def validate_trajectory(arr, *, expected_dims=9, tol=None, mag_range=None):
    """Return a list of problems. Empty list means the format is sound."""
    tol = TOL if tol is None else tol
    mag_range = MAG_RANGE if mag_range is None else mag_range
    problems = []
    arr = np.asarray(arr, dtype=np.float64)

    if arr.ndim != 2:
        return [f"expected a 2-D array, got shape {arr.shape}"]
    if arr.shape[1] != expected_dims:
        problems.append(f"width is {arr.shape[1]}, expected {expected_dims}")
        return problems                    # the column split below is meaningless
    if arr.shape[0] < 1:
        problems.append("no steps")
    if not np.isfinite(arr).all():
        bad = np.argwhere(~np.isfinite(arr))
        problems.append(f"{len(bad)} non-finite value(s), first at "
                        f"row {bad[0][0]} col {bad[0][1]}")
        return problems

    col0, col1 = arr[:, 3:6], arr[:, 6:9]
    n0, n1 = np.linalg.norm(col0, axis=1), np.linalg.norm(col1, axis=1)
    off0 = np.abs(n0 - 1.0).max()
    off1 = np.abs(n1 - 1.0).max()
    if max(off0, off1) > tol:
        problems.append(f"rotation columns are not unit length (worst deviation "
                        f"{max(off0, off1):.2e} > tol {tol:.2e})")
    dots = np.abs(np.einsum("ij,ij->i", col0, col1))
    if dots.max() > tol:
        problems.append(f"rotation columns are not perpendicular (worst "
                        f"|dot| {dots.max():.2e} > tol {tol:.2e})")

    mags = np.linalg.norm(arr[:, :3], axis=1)
    lo, hi = mag_range
    out_of_range = int(((mags < lo) | (mags > hi)).sum())
    if out_of_range:
        problems.append(f"{out_of_range}/{len(mags)} per-step translation "
                        f"magnitudes outside {lo:.5f}..{hi:.5f} "
                        f"(min {mags.min():.5f}, max {mags.max():.5f})")
    return problems


# Calibrate against the shipped files BEFORE trusting the validator.
for name, arr in shipped.items():
    problems = validate_trajectory(arr)
    print(f"{name:<20} {problems or 'ok'}")
    assert not problems, (name, problems)
print(f"{'my s_curve':<20} {validate_trajectory(s_curve) or 'ok'}")
assert not validate_trajectory(s_curve)
print("\\nPASS the validator accepts all shipped AV files and the authored S-curve")
''')

nb.code('''
# A validator that accepts everything is not a validator. Feed it each of the
# malformations it claims to catch and confirm each is rejected for its own
# reason.
NEGATIVES = {
    "wrong width": s_curve[:, :8],
    "not finite": np.where(np.arange(s_curve.size).reshape(s_curve.shape) == 5,
                           np.nan, s_curve),
    "rotation columns not unit": np.hstack([s_curve[:, :3], s_curve[:, 3:] * 1.7]),
    "rotation columns not perpendicular": np.hstack(
        [s_curve[:, :3], s_curve[:, 3:6], s_curve[:, 3:6]]),
    "translation out of range": np.hstack(
        [s_curve[:, :3] * 500.0, s_curve[:, 3:]]),
    "not 2-D": s_curve.ravel(),
}
for label, bad in NEGATIVES.items():
    problems = validate_trajectory(bad)
    assert problems, f"{label} was accepted"
    print(f"PASS rejected {label:<36} -> {problems[0][:64]}")
''')

nb.code('''
# Write it in the same bare-list format the cookbook uses, then generate.
MY_TRAJ = OUTPUT_DIR / "my_s_curve.json"
MY_TRAJ.parent.mkdir(parents=True, exist_ok=True)
MY_TRAJ.write_text(json.dumps([[float(v) for v in row] for row in s_curve]))
print(f"wrote {MY_TRAJ} ({MY_TRAJ.stat().st_size} bytes)")

# Round-trip: what comes back off disk must still validate. JSON goes through
# decimal text, and a validator run only on the in-memory array would not see a
# precision loss introduced by serialisation.
round_tripped = load_trajectory(MY_TRAJ)
assert not validate_trajectory(round_tripped), validate_trajectory(round_tripped)
assert np.allclose(round_tripped, s_curve)
print("PASS the file round-trips and still validates")

s_result = run_and_verify(
    av_forward_spec("my_s_curve", MY_TRAJ, chunk=min(CHUNK, len(s_curve))),
    "authored", label="my_s_curve")
''')

nb.model_answer(
    "**Does the generated video show the S you asked for?**\n\n"
    "Answer the question in three parts, because \"no\" has three different meanings and "
    "only one of them is a failure of the model.\n\n"
    "**1. Did the trajectory command an S at all?** Check before looking at any video. "
    "The accumulated heading — the sum of per-step yaws — should go positive, come back "
    "through zero and go negative, ending near zero. The cell above prints it. If it "
    "does not, you wrote a C or a wobble and the video is right.\n\n"
    "**2. Is the S within the model's range?** Hint 2 is explicit that a degree or two "
    "per step at 10 fps is already brisk, and `max_yaw_deg=1.5` over 30 steps is a total "
    "swing of a few degrees each way — deliberately gentle. If you turn it up and the "
    "video becomes incoherent, **that is a finding to write down, not a bug to fix**: you "
    "have located an edge of the training distribution. The honest report is \"the model "
    "follows yaw up to about X degrees per step and degrades beyond it\", with X "
    "measured by a sweep.\n\n"
    "**3. Can you see a few degrees of yaw in a 3-second clip?** This is the part most "
    "likely to make the answer \"no\" for an uninteresting reason. A gentle S at these "
    "magnitudes moves the horizon by a small fraction of the frame width. Watching for it "
    "is genuinely hard, and \"I cannot see it\" is weak evidence either way.\n\n"
    "**So the verdict I would defend:** the trajectory is correct by construction and "
    "validated; whether the model followed it is *not reliably answerable by eye at this "
    "magnitude*, and the correct response is to measure rather than to squint — which is "
    "exactly what Exercise 3 goes on to build. If you want a version you can see, "
    "increase `max_yaw_deg` until the effect is obvious, confirm the model follows it "
    "there, and then note that this tells you about the visible regime and not about the "
    "gentle one.\n\n"
    "**On the tolerance, since the exercise asks.** It is `10x` the worst orthonormality "
    "deviation observed in the shipped files, floored at `1e-4`. The reasoning: the "
    "shipped files are correct by definition, so whatever deviation they show is the "
    "noise level of the format — float32 storage, JSON decimal round-tripping, whatever "
    "produced them. A tolerance below that rejects valid data. A factor of ten leaves "
    "room for one more round-trip without admitting anything genuinely skewed, since a "
    "real error (a mis-transposed matrix, a normalisation left out) is off by order 1, "
    "not by 1e-6. Note the floor: if the shipped files happened to be exactly orthonormal "
    "the derived tolerance would be zero, and a zero tolerance rejects your own file the "
    "moment it passes through JSON."
)

nb.extend(
    "The validator checks format. What it cannot check is whether the trajectory is "
    "*dynamically plausible* — a real vehicle cannot yaw 30 degrees in one step at 10 fps "
    "while travelling forward at 0.04 units, because that implies a lateral acceleration "
    "no tyre can produce. Adding a curvature check (yaw rate divided by forward speed, "
    "against a maximum) would catch trajectories that are perfectly well-formed and "
    "physically impossible, and those are precisely the ones that will produce incoherent "
    "video. It is also the check that transfers directly to Lesson 12's action model, "
    "where the trajectories are generated rather than authored and nobody has looked at "
    "them."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "A trajectory editor, and evidence that the edit landed",
    goal="Build a tool that loads a trajectory, applies a named transform and "
         "regenerates — then produce quantitative evidence about whether the video "
         "reflects the edit.",
    success="Three transforms implemented and validated, at least one edit generated per "
            "transform, at least two evaluation measures with one computed from the "
            "video, and a report naming a specific blind spot in the evaluation.",
    approach="Mirror by conjugation (`R' = M R M`) so the determinant stays +1, re-encode "
             "from the repaired matrix, and evaluate with one trajectory-side measure and "
             "one video-side measure that fail differently.",
)

nb.code('''
def matrix_to_rot6d(R):
    """Encode a 3x3 rotation as the first two COLUMNS, flattened."""
    R = np.asarray(R, dtype=np.float64)
    return np.concatenate([R[:, 0], R[:, 1]])


def determinant_of_rot6d(vec6):
    """Decode and return det(R). A proper rotation has +1; a reflection has -1."""
    return float(np.linalg.det(rot6d_to_matrix(vec6)))


MIRROR = np.diag([-1.0, 1.0, 1.0])


def edit_trajectory(arr, op, **kwargs):
    """Return a transformed copy of a [steps, 9] trajectory."""
    arr = np.asarray(arr, dtype=np.float64).copy()
    if op == "scale_speed":
        k = float(kwargs.get("k", 1.5))
        arr[:, 2] *= k                     # +Z is forward
        return arr
    if op == "truncate":
        n = int(kwargs.get("n", max(1, arr.shape[0] // 2)))
        return arr[:n].copy()
    if op == "mirror_steering":
        # Hint 1: mirroring a rotation is a CONJUGATION, R' = M R M with
        # M = diag(-1, 1, 1). Negating individual entries of the rot6d vector
        # produces det(R) = -1 — a reflection, which is not a rotation and which
        # the framework will decode into something meaningless.
        out = arr.copy()
        out[:, 0] *= -1.0                  # lateral translation flips
        for i in range(arr.shape[0]):
            R = rot6d_to_matrix(arr[i, 3:9])
            out[i, 3:9] = matrix_to_rot6d(MIRROR @ R @ MIRROR)
        return out
    raise ValueError(f"unknown op {op!r}")


# The naive mirror, kept so the failure it produces is visible rather than
# described. This is what "negate the corresponding rotation term" gets you.
def naive_mirror(arr):
    out = np.asarray(arr, float).copy()
    out[:, 0] *= -1.0
    out[:, 3] *= -1.0                      # the "corresponding rotation term"
    return out


yawed = make_s_curve(steps=12, max_yaw_deg=8.0)
good = edit_trajectory(yawed, "mirror_steering")
bad = naive_mirror(yawed)

dets_good = [determinant_of_rot6d(r[3:9]) for r in good]
dets_bad = [determinant_of_rot6d(r[3:9]) for r in bad]
print(f"conjugation  det range: {min(dets_good):+.9f} .. {max(dets_good):+.9f}")
print(f"naive negate det range: {min(dets_bad):+.9f} .. {max(dets_bad):+.9f}")
assert all(abs(d - 1.0) < 1e-9 for d in dets_good), dets_good

# HERE IS THE FINDING, and it is not what hint 1 leads you to expect.
# det(R) is +1 for BOTH. It cannot be anything else: rot6d_to_matrix derives
# the third column as e0 x e1, and a cross product always produces a
# right-handed frame. Upstream's decoder projects onto SO(3) with an SVD, which
# has the same effect. So the reflection introduced by a naive negation is
# SILENTLY REPAIRED by the decoder, and the determinant check that hint 1 asks
# for passes on the broken edit.
assert all(abs(d - 1.0) < 1e-6 for d in dets_bad), dets_bad
print("\\nBOTH are det = +1. The determinant check cannot see the bug, because the")
print("decoder builds the third column by cross product and therefore CANNOT")
print("return an improper rotation. See the commentary for what to do instead.")


def mirror_error(orig6, edited6):
    """How far the edited rotation is from the intended mirrored one.

    The check that actually works: decode both, form the intended M R M, and
    measure the Frobenius distance. Zero means the edit is the mirror; anything
    of order one means it is some other rotation that happens to decode cleanly.
    """
    R = rot6d_to_matrix(orig6)
    intended = MIRROR @ R @ MIRROR
    return float(np.linalg.norm(rot6d_to_matrix(edited6) - intended))


err_good = max(mirror_error(o[3:9], e[3:9]) for o, e in zip(yawed, good))
err_bad = max(mirror_error(o[3:9], e[3:9]) for o, e in zip(yawed, bad))
print(f"\\nworst |R_edited - M R M|, conjugation  : {err_good:.2e}")
print(f"worst |R_edited - M R M|, naive negate : {err_bad:.2e}")
assert err_good < 1e-9, err_good
assert err_bad > 1e-3, err_bad
print("PASS the conjugation IS the mirror to machine precision; the naive "
      "negation is a different rotation entirely — and only this check can "
      "tell them apart")
''')

nb.code('''
# Every transform must return something the Exercise 2 validator still accepts.
base = shipped.get("av_traj_left", s_curve)
edited = {
    "scale_speed_x2": edit_trajectory(base, "scale_speed", k=2.0),
    "mirror_steering": edit_trajectory(base, "mirror_steering"),
    "truncate_half": edit_trajectory(base, "truncate",
                                     n=max(2, base.shape[0] // 2)),
}
for label, arr in edited.items():
    problems = validate_trajectory(arr)
    print(f"{label:<20} shape {str(arr.shape):<10} {problems or 'validates'}")

# scale_speed is the one that can legitimately break the magnitude check, and
# the honest handling is to say so rather than to widen the range until it
# passes. Doubling the speed doubles |t|, and MAG_RANGE was derived with a 2x
# headroom on the shipped maximum, so k=2 sits right at the boundary by
# construction.
# The multiplier is DERIVED from the calibrated range rather than picked, so
# this check works whether MAG_RANGE came from the shipped files or from the
# stated fallback.
current_max = float(np.linalg.norm(base[:, :3], axis=1).max())
k_big = round(3.0 * MAG_RANGE[1] / max(current_max, 1e-9), 2)
big = edit_trajectory(base, "scale_speed", k=k_big)
problems = validate_trajectory(big)
assert problems, f"a {k_big}x speed edit should leave the magnitude range"
print(f"\\nPASS a {k_big}x speed edit is REJECTED: {problems[0][:88]}")
print("     That is the validator working, not the edit failing. Widening "
      "MAG_RANGE to admit it would silently remove the only check that can "
      "catch a trajectory authored in the wrong units.")

# Mirroring should reverse the accumulated lateral motion and leave forward
# motion untouched. Check both.
lat_before = base[:, 0].sum()
lat_after = edited["mirror_steering"][:, 0].sum()
fwd_before = base[:, 2].sum()
fwd_after = edited["mirror_steering"][:, 2].sum()
print(f"\\naccumulated lateral: {lat_before:+.5f} -> {lat_after:+.5f}")
print(f"accumulated forward: {fwd_before:+.5f} -> {fwd_after:+.5f}")
assert np.isclose(lat_after, -lat_before), (lat_before, lat_after)
assert np.isclose(fwd_after, fwd_before), (fwd_before, fwd_after)
print("PASS mirroring negates lateral motion and leaves forward motion alone")
''')

nb.code('''
edit_results = {}
for label, arr in edited.items():
    path = OUTPUT_DIR / f"edit_{label}.json"
    path.write_text(json.dumps([[float(v) for v in row] for row in arr]))
    spec = av_forward_spec(f"edit_{label}", path,
                           chunk=min(CHUNK, arr.shape[0]))
    edit_results[label] = run_and_verify(spec, "edits", label=f"edit_{label}")

baseline_result = run_and_verify(
    av_forward_spec("edit_baseline", assets["av_traj_left"]) if assets["av_traj_left"]
    else av_forward_spec("edit_baseline", MY_TRAJ), "edits", label="edit_baseline")
print(f"\\n{sum(1 for v in edit_results.values() if v is not None)} edit video(s)")
''')

nb.code('''
# ---- MEASURE 1: trajectory-side. Cheap, exact, and measures my own arithmetic.
def trajectory_measures(arr):
    t = np.asarray(arr, float)[:, :3]
    yaws = [math.atan2(-r[2], r[0]) for r in np.asarray(arr, float)[:, 3:9]]
    return {"steps": int(arr.shape[0]),
            "forward_total": float(t[:, 2].sum()),
            "lateral_total": float(t[:, 0].sum()),
            "heading_total_deg": float(math.degrees(sum(yaws))),
            "path_length": float(np.linalg.norm(t, axis=1).sum())}


# ---- MEASURE 2: video-side. Independent of my arithmetic, and much weaker.
def video_measures(path, count=48):
    """Total motion and its left/right asymmetry, from the pixels.

    `total_motion` is the sum of frame-to-frame mean absolute difference — a
    crude proxy for how much happened, which should rise with speed.

    `lr_asymmetry` is the difference between mean motion in the left and right
    thirds of the frame, normalised. For an ego-view camera turning left, the
    optical flow is not symmetric, so a steering change should flip its sign.
    This is the closest a cheap pixel statistic gets to measuring DIRECTION,
    and it is still weak — see the blind spots below.
    """
    frames = []
    try:
        import imageio.v3 as iio
        for i, f in enumerate(iio.imiter(path)):
            arr = np.asarray(f)
            frames.append(arr.mean(axis=2) if arr.ndim == 3 else arr)
            if len(frames) >= count:
                break
    except Exception:
        return None
    if len(frames) < 3:
        return None
    diffs = [np.abs(frames[i + 1] - frames[i]) for i in range(len(frames) - 1)]
    w = diffs[0].shape[1]
    left = float(np.mean([d[:, :w // 3].mean() for d in diffs]))
    right = float(np.mean([d[:, -w // 3:].mean() for d in diffs]))
    total = float(sum(d.mean() for d in diffs))
    return {"total_motion": total, "left_motion": left, "right_motion": right,
            "lr_asymmetry": (left - right) / (left + right) if (left + right) else 0.0}


def evaluate_edit(original_video, edited_video):
    """Return a dict of measures comparing two generated clips."""
    a, b = video_measures(original_video), video_measures(edited_video)
    if a is None or b is None:
        return {"error": "could not decode one of the clips"}
    return {"total_motion_ratio": b["total_motion"] / a["total_motion"]
            if a["total_motion"] else float("nan"),
            "lr_asymmetry_before": a["lr_asymmetry"],
            "lr_asymmetry_after": b["lr_asymmetry"],
            "asymmetry_flipped": (a["lr_asymmetry"] * b["lr_asymmetry"]) < 0}


print(f"{'edit':<20}{'steps':>7}{'forward':>10}{'lateral':>10}{'heading deg':>13}")
print("-" * 62)
print(f"{'baseline':<20}" + "".join(
    f"{v:>10.4f}" if isinstance(v, float) else f"{v:>7}"
    for k, v in trajectory_measures(base).items() if k != "path_length"))
for label, arr in edited.items():
    m = trajectory_measures(arr)
    print(f"{label:<20}" + "".join(
        f"{v:>10.4f}" if isinstance(v, float) else f"{v:>7}"
        for k, v in m.items() if k != "path_length"))
''')

nb.code('''
video_rows = {}
if baseline_result is not None and baseline_result.video_path:
    for label, res in edit_results.items():
        if res is not None and res.video_path:
            video_rows[label] = evaluate_edit(baseline_result.video_path,
                                              res.video_path)

if not video_rows:
    # PLACEHOLDER VIDEO MEASURES — invented, so the report and the blind-spot
    # analysis run. NOT measurements. The pattern encodes what the mechanism
    # predicts: more speed means more motion; mirroring flips the asymmetry;
    # truncation reduces total motion without changing direction.
    print("PLACEHOLDER VIDEO MEASURES — invented, not measurements.\\n")
    video_rows = {
        "scale_speed_x2": {"total_motion_ratio": 1.83, "lr_asymmetry_before": 0.11,
                           "lr_asymmetry_after": 0.12, "asymmetry_flipped": False},
        "mirror_steering": {"total_motion_ratio": 1.02, "lr_asymmetry_before": 0.11,
                            "lr_asymmetry_after": -0.09, "asymmetry_flipped": True},
        "truncate_half": {"total_motion_ratio": 0.51, "lr_asymmetry_before": 0.11,
                          "lr_asymmetry_after": 0.10, "asymmetry_flipped": False},
    }

print(f"{'edit':<20}{'motion ratio':>14}{'asym before':>13}{'asym after':>12}"
      f"{'flipped':>9}")
print("-" * 68)
for label, m in video_rows.items():
    print(f"{label:<20}{m['total_motion_ratio']:>14.3f}"
          f"{m['lr_asymmetry_before']:>13.3f}{m['lr_asymmetry_after']:>12.3f}"
          f"{str(m['asymmetry_flipped']):>9}")

# The predictions, stated as assertions so a disagreement is loud.
print()
if "scale_speed_x2" in video_rows:
    print(f"PREDICTED: doubling forward speed raises total motion. "
          f"OBSERVED ratio {video_rows['scale_speed_x2']['total_motion_ratio']:.2f}"
          f" -> {'consistent' if video_rows['scale_speed_x2']['total_motion_ratio'] > 1.2 else 'NOT consistent — investigate'}")
if "mirror_steering" in video_rows:
    print(f"PREDICTED: mirroring flips left/right asymmetry. "
          f"OBSERVED flipped={video_rows['mirror_steering']['asymmetry_flipped']}"
          f" -> {'consistent' if video_rows['mirror_steering']['asymmetry_flipped'] else 'NOT consistent — the edit may not have reached the model'}")
if "truncate_half" in video_rows:
    print(f"PREDICTED: truncation reduces total motion roughly in proportion. "
          f"OBSERVED ratio {video_rows['truncate_half']['total_motion_ratio']:.2f}")
''')

nb.code('''
lines = [
    "# Trajectory editor — Lesson 10, Exercise 3",
    "",
    ("**PLACEHOLDER VIDEO NUMBERS.** No Nano generation ran on this machine. The "
     "transforms, the determinant check, the validator and the trajectory-side "
     "measures are real and were executed; the video-side numbers are invented."
     if not (baseline_result and baseline_result.video_path)
     else "Measured on this machine."),
    "",
    "## Transforms",
    "",
    "| op | what it changes | still validates |",
    "|---|---|---|",
    "| `scale_speed(k)` | multiplies the +Z translation column | yes for k up to ~2; "
    "REJECTED at k=6 because the magnitude leaves the shipped range |",
    "| `mirror_steering` | negates lateral translation and conjugates the rotation "
    "(`R' = M R M`, `M = diag(-1,1,1)`) | yes, det stays +1 on every row |",
    "| `truncate(n)` | keeps the first n steps | yes |",
    "",
    "### The determinant trap",
    "",
    "Negating individual entries of the rot6d vector — the obvious reading of "
    "'negate the corresponding rotation term' — produces a *reflection* in intent. "
    "But `determinant_of_rot6d` returns +1 for it anyway, because the decoder builds "
    "the third column as `e0 x e1` (upstream projects onto SO(3) with an SVD, with the "
    "same effect), so an improper rotation is silently repaired into some proper one. "
    "The determinant check is therefore necessary and NOT sufficient. The check that "
    "works is `mirror_error`: decode both, form the intended `M R M`, and measure the "
    "distance. Conjugation gives ~1e-16; naive negation gives order 1.",
    "",
    "## Measures",
    "",
    "1. **Trajectory-side** (`trajectory_measures`): accumulated forward, accumulated "
    "lateral, accumulated heading, step count. Exact and cheap. It measures my own "
    "arithmetic and says nothing about the model.",
    "2. **Video-side** (`video_measures`): total frame-to-frame motion, and the "
    "left/right asymmetry of that motion across the frame. Independent of the "
    "arithmetic, and much weaker.",
    "",
    "| edit | motion ratio | asymmetry before | after | flipped |",
    "|---|---:|---:|---:|---|",
]
for label, m in video_rows.items():
    lines.append(f"| {label} | {m['total_motion_ratio']:.3f} | "
                 f"{m['lr_asymmetry_before']:.3f} | {m['lr_asymmetry_after']:.3f} | "
                 f"{m['asymmetry_flipped']} |")

lines += [
    "",
    "## What these measures cannot detect",
    "",
    "**The blind spot, named specifically: neither measure can distinguish "
    "'the model followed the trajectory' from 'the model produced plausible motion "
    "that happens to correlate with it'.**",
    "",
    "Concretely:",
    "",
    "- `total_motion` rises with speed and also rises with lighting change, camera "
    "shake, a scene cut, or the model simply hallucinating more activity. A 1.8x "
    "motion ratio after a 2x speed edit is *consistent with* the edit landing and is "
    "not evidence that it did.",
    "- `lr_asymmetry` is a two-thirds-of-the-frame statistic on an ego view. It is "
    "confounded by anything asymmetric in the scene — a building on one side, a "
    "vehicle entering from the left — and those are present in the source frame, "
    "identical across both clips, and therefore contribute a constant bias that a "
    "sign flip may or may not overcome.",
    "- **Neither measure can detect a scale error.** If the model followed the "
    "direction of every edit and applied half the magnitude, every number above would "
    "look the same.",
    "- Both are aggregates over the clip, so an edit honoured for the first ten frames "
    "and abandoned afterwards scores as an edit honoured.",
    "",
    "## The measure I did not use, and why",
    "",
    "Running Lesson 11's inverse dynamics on my own generated video would recover an "
    "estimated action sequence and compare it against the commanded one — far more "
    "direct than any pixel statistic, and the only measure here that could catch a "
    "scale error. It is not used as the primary measure because it has a worse "
    "problem: the same model family is grading its own homework. If the forward model "
    "and the inverse model share a bias, they will agree with each other and both be "
    "wrong, and the agreement will look like validation. It is the right SECOND "
    "measure, run alongside a pixel statistic that fails differently — which is "
    "exactly the point of having two measures rather than one good one.",
]
report_path = OUTPUT_DIR / "editor_report.md"
report_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {report_path}")
print("\\n".join(lines[-16:]))
''')

nb.why(
    "**Why mirroring is a conjugation.** Hint 1 gives the formula and the reason is "
    "worth stating: mirroring is a change of coordinates, and a rotation expressed in "
    "mirrored coordinates is `M R M⁻¹`, which for `M = diag(-1,1,1)` is `M R M` since "
    "`M⁻¹ = M`. Because `det(M) = -1`, the two factors contribute `(-1)(-1) = +1` and "
    "the result is still a proper rotation.\n\n"
    "**Where this solution disagrees with hint 1, and why.** The hint says to detect the "
    "broken edit by checking `determinant_of_rot6d` on every row. Run it: **it returns "
    "+1 for the broken edit too.** The reason is structural. `rot6d_to_matrix` derives "
    "the third column as `e0 x e1`, and a cross product always yields a right-handed "
    "frame — so the decoder is *incapable* of returning an improper rotation. Upstream's "
    "decoder projects onto SO(3) with an SVD (`COSMOS3_FACTS.md` §5), which has the same "
    "effect for the same reason. The reflection is silently repaired into some proper "
    "rotation that is not the one you meant, and every determinant is +1.\n\n"
    "So the determinant check is necessary and **not sufficient**, and a solution that "
    "stops there has verified a property that cannot fail. The check that works is "
    "`mirror_error`: decode the original, form the intended `M R M`, and measure the "
    "distance to the decoded edit. Conjugation gives 0 to machine precision; naive "
    "negation gives order 1. The naive version is kept in the notebook so that the "
    "determinant check can be seen passing on it — a passing check on broken input is "
    "much more instructive than a failing one.\n\n"
    "**Why the magnitude check is allowed to reject a legitimate edit.** `scale_speed(6)` "
    "fails `validate_trajectory`, and the temptation is to widen `MAG_RANGE` until it "
    "passes. That would remove the only check capable of catching a trajectory authored "
    "in the wrong units — the exact mistake you are most likely to make when writing one "
    "by hand. The right response is to *state* that the edit leaves the shipped "
    "distribution, which is a real fact about the edit, and decide deliberately whether "
    "to run it anyway. A validator you tune until your data passes is a validator that "
    "validates nothing.\n\n"
    "**Why two measures, one of which is bad.** Step 4 requires at least one measure "
    "computed from the video, and the reason is sharp: a trajectory-side measure "
    "verifies your own arithmetic and nothing else. If `edit_trajectory` doubled the "
    "wrong column, `trajectory_measures` would confirm it doubled beautifully. Only a "
    "video-side measure can tell you the edit reached the model. The video-side measure "
    "used here is weak — a frame-difference statistic — and hint 2 says so in advance. "
    "That is acceptable *because the two fail differently*: the trajectory measure is "
    "exact and irrelevant, the video measure is relevant and noisy, and an edit that "
    "moves both in the predicted direction is better evidence than either alone.\n\n"
    "**Why the predictions are stated before the numbers are printed.** The three "
    "`PREDICTED:` lines are written from the mechanism — more speed means more motion, "
    "mirroring flips asymmetry, truncation reduces total motion — and then compared "
    "against what came out. Printing the numbers first and interpreting them afterwards "
    "produces a story every time, because these statistics always move somehow. A "
    "prediction you committed to is the only thing that makes \"NOT consistent\" a "
    "possible outcome.\n\n"
    "**Why the inverse-dynamics measure is named and not used.** It would be the "
    "strongest measure available and it has a circularity that a pixel statistic does "
    "not: the same model family generating and grading. The report says this explicitly "
    "rather than quietly preferring the weaker tool — a limitation you chose is a "
    "different thing from one you did not notice."
)

nb.extend(
    "The editor applies one transform at a time. The experiment it is built for is a "
    "**dose-response curve**: `scale_speed` at k = 0.5, 1, 1.5, 2, 3, measuring "
    "`total_motion` at each. A model that follows the command produces a monotone, "
    "roughly proportional response; a model that merely produces plausible motion "
    "produces something flat or saturating. That single curve is stronger evidence than "
    "any number of paired comparisons, because a confound would have to scale with k to "
    "survive it — and the point at which it stops being proportional is the edge of the "
    "model's action range, which is a number worth having."
)

nb.finish()
