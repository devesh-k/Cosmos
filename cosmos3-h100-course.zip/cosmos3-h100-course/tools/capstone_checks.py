"""The capstone's stage checks, in one place so four artefacts cannot drift.

``19_capstone_synthetic_data_flywheel.ipynb`` states the contracts and gives the
learner the checks; ``solutions/19_capstone_reference.ipynb`` has to pass those
same checks, because a reference implementation that cannot satisfy the rubric it
is a reference for is worse than no reference. When the two files each carried
their own copy of the counts, they disagreed — and so did
``assets/reference/CAPSTONE_RUBRIC.md``, which named six checks where the lesson
defined seven, and said the report had seven sections where
``CAPSTONE_REPORT_TEMPLATE.md`` has eight.

So the check bodies, the counts and the report headings live here, and both
``tools/build_19.py`` and ``tools/build_sol_19.py`` emit them. The two markdown
artefacts are prose and cannot import anything, so ``consistency_report()``
prints the numbers they have to agree with; run it whenever you touch either
file.

Nothing here is course material. It is build-time text that *becomes* course
material, which is why the checks are string constants rather than a module the
notebooks import at run time — the learner has to be able to read the check in
the cell next to the thing it checks.

    from capstone_checks import CHECK_STAGE_1
    nb.code(CHECK_STAGE_1 + "\\n\\nprint('check_stage_1 is defined.')")
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# The counts. Every artefact that states one has to state these.
# ---------------------------------------------------------------------------
STAGE_CHECK_NAMES = (
    "check_stage_0", "check_stage_1", "check_stage_2", "check_stage_3",
    "check_stage_4", "check_stage_5", "check_stage_6",
)
N_STAGE_CHECKS = len(STAGE_CHECK_NAMES)              # 7

# The Foundation tier stops at stage 4: it never measures and never reports, so
# check_stage_5 and check_stage_6 have nothing to look at. This subset is the
# reason the count is easy to get wrong -- five checks for one tier, seven for
# the other, six stages, and none of those three numbers is the same.
FOUNDATION_CHECK_NAMES = STAGE_CHECK_NAMES[:5]
N_FOUNDATION_CHECKS = len(FOUNDATION_CHECK_NAMES)    # 5

N_STAGES = 6            # reason, vary, generate, validate, measure, report


CHECK_STAGE_0 = '''\
def check_stage_0():
    """Sources resolve, ledgers are writable, deliverable paths exist."""
    passed = []
    assert len(SOURCES) == N_SOURCES, \\
        f"expected {N_SOURCES} sources, resolved {len(SOURCES)}"
    passed.append(f"{len(SOURCES)} source clip(s) resolved")

    for clip_id, path in SOURCES:
        assert Path(path).exists(), f"{clip_id}: {path} does not exist"
        assert Path(path).stat().st_size > 1024, f"{clip_id}: file is suspiciously small"
    passed.append("every source file exists and is non-trivial")

    assert len({c for c, _ in SOURCES}) == len(SOURCES), "duplicate clip_id"
    passed.append("clip_ids are unique")

    for ledger in (scenes, manifest, prediction_log):
        assert ledger.path.parent.exists(), f"{ledger.path.parent} is missing"
    passed.append("ledgers are open and their directory exists")

    assert prediction_log.has("prediction"), \\
        "no prediction on record -- run the budget cell before the pipeline"
    passed.append("a cost prediction is committed")

    for line in passed:
        print(f"  ok  {line}")
    return True
'''

CHECK_DECISIONS = '''\
def check_decisions(minimum=MIN_JUSTIFICATION_CHARS):
    """Every decision answered, at length, with no TODO left.

    This checks that you wrote something substantial. It cannot check that the
    argument is any good -- the rubric caps you at 'adequate' for passing this
    and nothing more.
    """
    problems = []
    for name, entry in DECISIONS.items():
        for key in REQUIRED_DECISION_KEYS:
            text = str(entry.get(key, ""))
            if "TODO" in text:
                problems.append(f"{name}.{key} still says TODO")
            elif len(text.strip()) < minimum:
                problems.append(
                    f"{name}.{key} is {len(text.strip())} chars; "
                    f"{minimum} is the floor")
    if "how_it_could_be_gamed" in DECISIONS["diversity"]:
        text = DECISIONS["diversity"]["how_it_could_be_gamed"]
        if "TODO" in text or len(text.strip()) < minimum:
            problems.append("diversity.how_it_could_be_gamed is not answered")

    for item in problems:
        print(f"  MISSING  {item}")
    if not problems:
        print("  ok  all four decisions are answered")
    return not problems
'''

CHECK_STAGE_1 = '''\
def check_stage_1(clip=None, verbose=True):
    """Contract test for reason_stage. Needs the NIM up."""
    clip_id, path = clip or SOURCES[0]
    if not nim_status(NIM)["ready"]:
        nim_up()

    scene = reason_stage(clip_id, Path(path))
    passed = []

    assert set(scene) == {"clip_id", "source_path", "record", "baseline",
                          "provenance"}, \\
        f"reason_stage returned keys {sorted(scene)}; the contract is exactly " \\
        f"clip_id, source_path, record, baseline, provenance"
    passed.append("returns exactly the five contracted keys")

    assert scene["clip_id"] == clip_id, "clip_id was not echoed back"
    assert Path(scene["source_path"]).exists(), "source_path does not exist"
    passed.append("clip_id and source_path are correct")

    record = scene["record"]
    for key, example in CAPTION_SCHEMA.items():
        assert key in record, f"record is missing {key!r}"
        if isinstance(example, list):
            assert isinstance(record[key], list), f"{key!r} should be a list"
            assert record[key], f"{key!r} is an empty list"
        else:
            assert isinstance(record[key], str), f"{key!r} should be a string"
            assert record[key].strip(), f"{key!r} is empty"
    assert not (set(record) - set(CAPTION_SCHEMA)), \\
        f"unexpected keys in record: {sorted(set(record) - set(CAPTION_SCHEMA))}"
    passed.append("record matches CAPTION_SCHEMA exactly")

    blob = " ".join(str(v) for v in record.values())
    text_check = cc.check_text(blob)
    assert text_check.passed, f"caption is degenerate: {text_check.reason}"
    passed.append(f"caption passes check_text ({text_check.reason})")

    baseline = scene["baseline"]
    for key in BASELINE_KEYS:
        assert key in baseline, f"baseline is missing {key!r}"
    assert isinstance(baseline["plausible"], bool), "plausible must be a bool"
    assert 0.0 <= float(baseline["confidence"]) <= 1.0, \\
        "confidence must be in [0, 1]"
    assert len(str(baseline["why"]).strip()) >= 20, \\
        "why is too short to be a reason"
    passed.append("baseline has the contracted shape")

    prov = scene["provenance"]
    for key in ("model", "fps", "seed", "latency_s"):
        assert key in prov, f"provenance is missing {key!r}"
    passed.append("provenance records model, fps, seed and latency")

    if verbose:
        for line in passed:
            print(f"  ok  {line}")
        print()
        print(f"  baseline on REAL footage: plausible={baseline['plausible']} "
              f"confidence={baseline['confidence']}")
        if not baseline["plausible"]:
            print("  NOTE: your judge says genuine footage is implausible.")
            print("  Fix the question before you screen anything with it.")
    return scene
'''

CHECK_STAGE_2 = '''\
_STOPWORDS = {"a", "an", "the", "of", "in", "on", "at", "and", "or", "with",
              "is", "are", "to", "from", "by", "as", "its", "it", "this",
              "that", "for", "into", "over", "under"}


def _content_tokens(text):
    """Lowercase alphabetic tokens with the obvious function words removed."""
    return {w for w in "".join(
        c.lower() if c.isalpha() else " " for c in str(text)).split()
        if len(w) > 2 and w not in _STOPWORDS}


def check_stage_2(scene=None, verbose=True):
    """Contract test for plan_variants and diversity_score. No GPU needed."""
    if scene is None:
        assert len(scenes), \\
            "no scene records yet -- run stage 1 first, or pass a scene dict"
        scene = scenes.records()[0]

    assert len(AXES) >= 3, \\
        f"{len(AXES)} axis/axes defined. Three is the floor: one axis is not a " \\
        f"design, it is a knob."
    assert all(len(v) >= 2 for v in AXES.values()), \\
        "every axis needs at least two values"

    plans = plan_variants(scene, PER_SOURCE)
    again = plan_variants(scene, PER_SOURCE)
    passed = []

    assert len(plans) == PER_SOURCE, \\
        f"asked for {PER_SOURCE} variants, got {len(plans)}"
    passed.append(f"returns exactly {PER_SOURCE} plans")

    required = {"variant_id", "clip_id", "axis", "axis_value", "modality",
                "control_hint", "prompt", "seed"}
    for plan in plans:
        missing = required - set(plan)
        assert not missing, f"variant is missing {sorted(missing)}"
    passed.append("every plan has the contracted keys")

    ids = [p["variant_id"] for p in plans]
    assert len(set(ids)) == len(ids), f"duplicate variant_id: {ids}"
    assert ids == [p["variant_id"] for p in again], \\
        "plan_variants is not deterministic -- resume will not work. Build " \\
        "variant_id from the inputs, not from uuid4() or the clock."
    assert [p["prompt"] for p in plans] == [p["prompt"] for p in again], \\
        "prompts are not deterministic"
    passed.append("variant_ids and prompts are unique and stable across calls")

    for plan in plans:
        assert plan["axis"] in AXES, f"unknown axis {plan['axis']!r}"
        assert plan["axis_value"] in AXES[plan["axis"]], \\
            f"{plan['axis_value']!r} is not a declared value of {plan['axis']!r}"
        assert plan["modality"] in MODALITIES, \\
            f"unknown modality {plan['modality']!r}"
        if plan["modality"] == "video2video":
            assert plan["control_hint"] in CONTROL_HINTS, \\
                f"video2video needs a control hint from {CONTROL_HINTS}"
        assert isinstance(plan["seed"], int), "seed must be an int"
    passed.append("axes, values, modalities and hints are all declared ones")

    prompts = [p["prompt"] for p in plans]
    assert len(set(prompts)) == len(prompts), \\
        "two variants have identical prompts -- the axis did not reach the text"
    assert all(len(p) >= 40 for p in prompts), "a prompt under 40 chars is a label"
    passed.append("prompts are distinct and substantial")

    scene_tokens = _content_tokens(json.dumps(scene["record"]))
    for plan in plans:
        overlap = _content_tokens(plan["prompt"]) & scene_tokens
        assert len(overlap) >= 3, (
            f"variant {plan['variant_id']!r} shares only {len(overlap)} content "
            f"word(s) with its scene record. The prompt is supposed to be "
            f"DERIVED from the record, not written next to it.")
    passed.append("every prompt is derived from the scene record")

    axes_used = {p["axis"] for p in plans}
    if len(axes_used) < 2 and PER_SOURCE > 2:
        print(f"  note: all {PER_SOURCE} variants move along one axis "
              f"({axes_used}). Defensible, but say why in decision 2.")

    score = diversity_score(plans)
    assert set(score) >= {"criterion", "value", "detail"}, \\
        "diversity_score must return criterion, value and detail"
    assert isinstance(score["value"], (int, float)), "value must be numeric"
    passed.append(f"diversity_score -> {score['criterion']}: {score['value']}")

    if verbose:
        for line in passed:
            print(f"  ok  {line}")
    return plans
'''

CHECK_STAGE_3 = '''\
MAX_UNITS_BUDGET = per_variant["cost_units"] * N_PLANNED * 1.25


def check_stage_3(plans=None, verbose=True):
    """Every spec validates and the whole run fits the budget. No GPU spent."""
    if plans is None:
        assert len(scenes), "run stage 1 first"
        plans = []
        for scene in scenes.records():
            plans.extend(plan_variants(scene, PER_SOURCE))

    passed = []
    total_units = 0
    seen = set()

    for plan in plans:
        scene = scenes.get(plan["clip_id"])
        assert scene is not None, f"no scene record for {plan['clip_id']!r}"
        spec = build_spec(plan, scene)

        problems = cc.validate_spec(spec, strict=False)
        assert not problems, (
            f"{plan['variant_id']}: spec is invalid:\\n  - "
            + "\\n  - ".join(problems))

        assert spec.name == plan["variant_id"], (
            f"spec.name is {spec.name!r} but variant_id is "
            f"{plan['variant_id']!r}. Outputs are matched by name; these must "
            f"agree or the manifest will point at the wrong file.")
        assert spec.name not in seen, f"duplicate spec name {spec.name!r}"
        seen.add(spec.name)

        assert spec.model_mode == plan["modality"], "modality/spec mismatch"
        assert str(spec.resolution) == RES, \\
            f"{spec.name}: resolution {spec.resolution!r}, config says {RES!r}"
        assert spec.num_frames == N_FRAMES, f"{spec.name}: frame count drift"
        assert spec.num_steps == N_STEPS, f"{spec.name}: step count drift"
        assert spec.seed == plan["seed"], f"{spec.name}: seed drift"

        if spec.model_mode == "video2video":
            assert cc.MODEL_TIERS[MODEL]["supports_transfer"], (
                f"{spec.name} is a video2video spec but {MODEL} does not "
                f"support transfer (COSMOS3_FACTS.md section 1). Either plan "
                f"image2video here, or set COSMOS_COURSE_MODEL=Cosmos3-Nano.")

        total_units += spec.cost()["cost_units"]

    passed.append(f"{len(plans)} spec(s) built and validated, names unique")
    passed.append("geometry, seed and modality match the plan and the config")

    assert total_units <= MAX_UNITS_BUDGET, (
        f"{total_units:,} cost units exceeds the budget of "
        f"{MAX_UNITS_BUDGET:,.0f}. Something is bigger than the config cell "
        f"says -- check num_frames and resolution on every spec.")
    passed.append(f"{total_units:,} cost units, budget {MAX_UNITS_BUDGET:,.0f}")

    if verbose:
        for line in passed:
            print(f"  ok  {line}")
    return plans
'''

CHECK_STAGE_4 = '''\
def _broken_video(path):
    """A file with an .mp4 extension and no video in it. Deterministic."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"not a video, not even slightly" * 64)
    return path


def check_stage_4(verbose=True):
    """Contract test for screen. Structural only -- no GPU, no NIM."""
    passed = []

    assert ACCEPT_CONFIDENCE is not None, \\
        "ACCEPT_CONFIDENCE is still None. Decision 3 needs a number."
    assert 0.0 < float(ACCEPT_CONFIDENCE) <= 1.0, \\
        "ACCEPT_CONFIDENCE must be in (0, 1]"
    passed.append(f"threshold is set: confidence >= {ACCEPT_CONFIDENCE}")

    fake = {"variant_id": "contract-test", "clip_id": "none", "axis": "none",
            "axis_value": "none", "modality": "image2video",
            "control_hint": None, "prompt": "contract test", "seed": 0}

    # 1. No file at all -> failed, and nothing is asked of the reasoner.
    outcome = screen(fake, None)
    assert outcome["status"] in STATUSES, f"bad status {outcome['status']!r}"
    assert outcome["status"] == "failed", \\
        "a missing file is a `failed`, not a `rejected` -- nothing was judged"
    assert outcome["judge"] is None, "no file should mean no judge call"
    passed.append("a missing file is classified `failed` and costs no inference")

    # 2. A file that is not a video -> rejected by the automatic screen.
    broken = _broken_video(OUTPUT_DIR / "_contract" / "broken.mp4")
    outcome = screen(fake, broken)
    assert outcome["status"] in {"rejected", "failed"}, \\
        f"an undecodable file must not be accepted; got {outcome['status']!r}"
    assert outcome["checks"], "checks dict is empty -- what did you screen with?"
    assert any(v is False for v in outcome["checks"].values()), \\
        "no automatic check failed on a file that is not a video"
    assert outcome["judge"] is None, \\
        "the judge was asked about a file that failed the cheap screen. That " \\
        "is a NIM restart and an inference call spent on a known-bad clip."
    assert len(outcome["reason"]) >= 15, "reason is too short to act on"
    passed.append("an undecodable file is rejected by the cheap screen alone")

    # 3. The return shape.
    assert set(outcome) >= {"status", "reason", "checks", "judge"}, \\
        f"screen returned {sorted(outcome)}"
    passed.append("returns the contracted keys")

    if verbose:
        for line in passed:
            print(f"  ok  {line}")
        print()
        print(f"  reason on the broken file: {outcome['reason']!r}")
    return True
'''

CHECK_STAGE_5 = '''\
def check_stage_5(metrics=None, verbose=True):
    """metrics.json is complete, internally consistent, and honest."""
    if metrics is None:
        assert METRICS_PATH.exists(), \\
            f"{METRICS_PATH} does not exist -- run collect_metrics first"
        metrics = json.loads(METRICS_PATH.read_text())

    passed = []
    missing = [k for k in METRIC_KEYS if k not in metrics]
    assert not missing, f"metrics.json is missing: {missing}"
    passed.append(f"all {len(METRIC_KEYS)} metric keys present")

    n_att = metrics["n_attempted"]
    total = metrics["n_accepted"] + metrics["n_rejected"] + metrics["n_failed"]
    assert total == n_att, (
        f"accepted + rejected + failed = {total} but {n_att} were attempted. "
        f"Every attempt needs exactly one verdict.")
    passed.append(f"{n_att} attempts, all accounted for")

    assert metrics["n_attempted"] >= (8 if MODE == "reduced" else 24), \\
        f"criterion S2: {metrics['n_attempted']} attempted variants is under " \\
        f"the bar for {MODE} mode"
    passed.append("attempt count meets criterion S2")

    stage_total = sum(metrics["stage_seconds"].values())
    wall = metrics["wall_clock_seconds"]
    assert stage_total <= wall * 1.02, (
        f"stage seconds sum to {stage_total:.0f} but the wall clock is "
        f"{wall:.0f}. Stages are being double-counted -- StageClock does not "
        f"nest, so something is being timed twice.")
    passed.append(f"stage seconds ({stage_total:.0f}s) fit the wall clock "
                  f"({wall:.0f}s)")

    peak = metrics["peak_vram_gb"]
    overall = peak["overall"] if isinstance(peak, dict) else peak
    assert overall is not None, \\
        "peak VRAM is None. cc.DeviceSampler, not torch.cuda.max_memory_allocated."
    assert overall <= 75.0, (
        f"criterion S6: peak device VRAM was {overall:.1f} GB, over the 75 GB "
        f"ceiling. Either the NIM and the generator overlapped, or something "
        f"from an earlier notebook is still resident. Check nvidia-smi.")
    passed.append(f"peak device VRAM {overall:.1f} GB, under the 75 GB ceiling")

    assert metrics["gpu_seconds_per_accepted"] is not None, \\
        "cost per accepted clip is the headline number and it is None"
    assert metrics["prediction_ratio"] is not None, \\
        "criterion S8: you predicted, so reconcile. measured / predicted."
    passed.append(
        f"cost per accepted clip {metrics['gpu_seconds_per_accepted']:.0f} s, "
        f"{metrics['prediction_ratio']:.2f}x the prediction")

    assert "TODO" not in str(metrics["predicted_dominant_stage"]), \\
        "predicted_dominant_stage still says TODO. Go back to the budget cell " \\
        "and commit a prediction before reading the answer."
    passed.append("a dominant-stage prediction was committed before the run")

    if BUDGET_MIN and wall > BUDGET_MIN * 60:
        print(f"  note: criterion S7 wanted {BUDGET_MIN} min, this took "
              f"{wall / 60:.0f} min. Not a failure of the code -- a sign the "
              f"configuration is bigger than 'reduced'. Say which knob you "
              f"would turn.")

    if verbose:
        for line in passed:
            print(f"  ok  {line}")
        print()
        print(f"  predicted dominant stage: {metrics['predicted_dominant_stage']}")
        print(f"  measured  dominant stage: {metrics['dominant_stage']}")
        print(f"  switching was {metrics['switch_fraction']:.0%} of accounted time")
    return True
'''

CHECK_STAGE_6 = '''\
def check_stage_6(verbose=True):
    """The two deliverables: a complete manifest and a complete report."""
    passed = []

    # ---- the manifest -----------------------------------------------------
    manifest.reload()
    records = manifest.records()
    assert records, f"{MANIFEST_PATH} is empty"
    assert manifest.malformed_lines == 0, \\
        f"{manifest.malformed_lines} unreadable line(s) -- a truncated write " \\
        f"from an unclean kill. Fine to resume from; not fine to ship."

    ids = [r["variant_id"] for r in records]
    assert len(set(ids)) == len(ids), "duplicate variant_id in the manifest"
    passed.append(f"{len(records)} manifest record(s), ids unique")

    for record in records:
        missing = set(MANIFEST_FIELDS) - set(record)
        assert not missing, \\
            f"{record.get('variant_id')}: manifest record missing {sorted(missing)}"
        assert record["status"] in STATUSES, \\
            f"{record['variant_id']}: status {record['status']!r} is not one of {STATUSES}"
        assert str(record["reason"]).strip(), \\
            f"{record['variant_id']}: no reason recorded"
        if record["status"] == "accepted":
            assert record["output_path"], "an accepted variant with no file"
            assert Path(record["output_path"]).exists(), \\
                f"{record['variant_id']}: output_path does not exist"
            assert record["checks"], "an accepted variant with no check evidence"
    passed.append("every record has all fields, a status and a readable reason")

    counts = manifest.counts("status")
    accepted = counts.get("accepted", 0)

    # S4 is about the GENERATOR, not the policy: how many attempts produced a
    # file that decodes, holds together spatially and moves. A strict threshold
    # should cost you acceptances without failing the criterion, or the bar
    # would be quietly pressuring you to loosen decision 3 -- which is exactly
    # the thing the rubric is trying to stop.
    alive = sum(1 for r in records if (r.get("checks") or {}).get("video") is True)
    floor = 6 if MODE == "reduced" else 18
    assert alive >= floor, (
        f"criterion S4: {alive} attempt(s) produced a file cc.check_video "
        f"accepts, and {floor} is the bar for {MODE} mode. This counts the "
        f"generator, not your threshold -- a strict policy costs you "
        f"acceptances, not this criterion.")
    passed.append(f"criterion S4: {alive} live output(s) (bar is {floor})")

    assert accepted >= 1, (
        "no variant was accepted, so there is no cost-per-accepted-clip and "
        "half the report has no denominator. Before you touch the threshold, "
        "run calibrate_judge(): a judge that rejects real footage rejects "
        "everything, and that is a different bug.")
    passed.append(f"{accepted} accepted, "
                  f"{counts.get('rejected', 0)} rejected by policy, "
                  f"{counts.get('failed', 0)} failed")

    # ---- the report -------------------------------------------------------
    assert REPORT_PATH.exists(), f"{REPORT_PATH} does not exist"
    text = REPORT_PATH.read_text(encoding="utf-8")

    absent = [s for s in REPORT_SECTIONS if s not in text]
    assert not absent, f"report is missing section(s): {absent}"
    passed.append(f"all {len(REPORT_SECTIONS)} report sections present")

    assert "[FILL]" not in text, \\
        f"{text.count('[FILL]')} [FILL] placeholder(s) left in the report"
    leftovers = [line.strip() for line in text.splitlines()
                 if "<" in line and ">" in line and "TODO" not in line
                 and line.strip().startswith("<")]
    assert not leftovers, \\
        f"{len(leftovers)} template placeholder(s) left, first: {leftovers[0][:80]!r}"
    passed.append("no placeholders left")

    # Section 5, by content rather than by keyword. The rubric asks for four or
    # more items, so count them -- a heading with one sentence under it is the
    # commonest way this section gets written and the least useful.
    section5 = text[text.index(REPORT_SECTIONS[5]):text.index(REPORT_SECTIONS[6])]
    bullets = [line for line in section5.splitlines()
               if line.strip().startswith(("-", "*", "1.", "2.", "3.", "4."))]
    assert len(bullets) >= 4, (
        f"section 5 has {len(bullets)} item(s); four is the bar. This section "
        f"is weighted more per word than any other in the rubric, and a "
        f"heading with one sentence under it is the least useful way to write "
        f"it.")
    passed.append(f"section 5 lists {len(bullets)} things the evidence does not "
                  f"support")

    if verbose:
        for line in passed:
            print(f"  ok  {line}")
        print()
        print(f"  yield: {counts}")

    # ---- advisory: gate G1 ------------------------------------------------
    # Not an assertion, because number formatting is a matter of taste and an
    # over-eager check here would cost you more time than it saves. But a
    # reviewer WILL do this by hand, so do it first.
    if METRICS_PATH.exists():
        metrics = json.loads(METRICS_PATH.read_text())
        untraced = []
        for key, value in metrics.items():
            if isinstance(value, float) and value == value:
                for rendering in (f"{value:.0f}", f"{value:.1f}", f"{value:.2f}"):
                    if rendering in text:
                        break
                else:
                    untraced.append(key)
        if untraced:
            print()
            print("  advisory (rubric gate G1): these measured values do not")
            print("  appear anywhere in the report. Either use them or say why not:")
            for key in untraced[:12]:
                print(f"    {key} = {metrics[key]}")
    return True
'''


# check_decisions()'s two thresholds. The reference has to be graded by the
# same floor the learner is.
DECISION_CONTRACT = '''\
REQUIRED_DECISION_KEYS = ("choice", "why", "rejected", "would_change_my_mind")
MIN_JUSTIFICATION_CHARS = 120
'''

# The manifest contract. check_stage_6 asserts every field in
# MANIFEST_FIELDS is present on every record and that status is one of
# STATUSES, so the lesson and the reference have to share this list or the
# reference cannot pass the check the lesson ships.
MANIFEST_CONTRACT = '''\
MANIFEST_FIELDS = {
    "variant_id":  "str, unique, stable across runs",
    "clip_id":     "str, which source clip this came from",
    "source_path": "str, the real file on disk",
    "axis":        "str, which diversity axis was varied",
    "axis_value":  "str, what it was varied to",
    "modality":    "str, one of image2video / video2video / text2video",
    "control_hint": "str or null; only for video2video (edge/blur/depth/seg)",
    "prompt":      "str, the exact prompt sent to the generator",
    "spec":        "dict, the exact InferenceSpec body that was run",
    "seed":        "int",
    "model":       "str, the checkpoint",
    "output_path": "str or null",
    "checks":      "dict, check name -> bool, from cc.verify_result",
    "judge":       "dict or null, {plausible, confidence, why}",
    "status":      "str, one of accepted / rejected / failed",
    "reason":      "str, why -- readable by a person, not a stack trace",
    "seconds":     "float, wall clock attributable to this variant",
    "peak_vram_gb": "float or null, device-wide during its batch",
    "timestamp":   "str, ISO 8601",
}

# Three statuses, and the difference between the last two is graded:
#   accepted -- passed every check and the judge
#   rejected -- the POLICY said no. The pipeline worked.
#   failed   -- the pipeline broke. Different problem, different fix.
STATUSES = ("accepted", "rejected", "failed")
'''

# The report template has eight sections, "## 0." through "## 7.". They are
# listed once, here; the source both notebooks emit is generated from this
# tuple, so a section cannot be added to one file and missed in the other.
REPORT_SECTION_HEADINGS = (
    "## 0. One-paragraph summary",
    "## 1. Method",
    "## 2. Design decisions",
    "## 3. Results",
    "## 4. Threats to validity",
    "## 5. What this evidence does **not** support",
    "## 6. Next steps",
    "## 7. Reproducing this",
)
N_REPORT_SECTIONS = len(REPORT_SECTION_HEADINGS)     # 8

REPORT_SECTIONS = (
    "REPORT_SECTIONS = (\n"
    + "".join(f'    "{h}",\n' for h in REPORT_SECTION_HEADINGS)
    + ")\n"
)


def consistency_report() -> str:
    """The numbers the four capstone artefacts have to agree on.

    Run this after editing the rubric or the report template. Those two are
    markdown and cannot import anything, so this is the only cross-check there
    is.
    """
    return "\n".join([
        f"stage checks        : {N_STAGE_CHECKS}  "
        f"({STAGE_CHECK_NAMES[0]} .. {STAGE_CHECK_NAMES[-1]})",
        f"foundation subset   : {N_FOUNDATION_CHECKS}  "
        f"({FOUNDATION_CHECK_NAMES[0]} .. {FOUNDATION_CHECK_NAMES[-1]})",
        f"pipeline stages     : {N_STAGES}",
        f"report sections     : {N_REPORT_SECTIONS}  "
        f"(## 0. .. ## {N_REPORT_SECTIONS - 1}.)",
    ])


if __name__ == "__main__":
    print(consistency_report())
