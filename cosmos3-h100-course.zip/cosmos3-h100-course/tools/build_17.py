"""Build 17_posttraining_one_gpu.ipynb.

The experiment at the centre of Module 5: take the one shipped recipe that the
arithmetic in Lesson 16 said might fit, shrink it from eight GPUs to one, and
find out. **This is undocumented by NVIDIA and the notebook says so repeatedly.**
A failed run that produces the report is a pass.

Everything quoted was read out of upstream `main` in August 2026:

`examples/toml/sft_config/vision_sft_edge.toml` — reproduced verbatim in the
notebook so the lesson works without a checkout, and diffed against the
learner's own copy when they have one. Field values that matter:
  * `[model] max_num_tokens_after_packing = 45056`, `joint_attn_implementation
    = "two_way"`, `precision = "bfloat16"`
  * `[model.ema] enabled = true`, `rate = 0.1`
  * `[model.parallelism] data_parallel_shard_degree = -1`,
    `data_parallel_replicate_degree = 1`
  * `[model.compile] enabled = true`, `compile_dynamic = true`  <- note TRUE
    here even though the schema default is false
  * `[model.activation_checkpointing] mode = "full"`, `save_ops_regex =
    ["fmha"]` — so the FAQ's rung 2 is ALREADY APPLIED in this recipe
  * `[optimizer] keys_to_select = [moe_gen, time_embedder, vae2llm, llm2vae,
    k_norm_und_for_gen]`, `lr = 1.0e-4`, `fused = true`, `betas = [0.9, 0.95]`
  * `[scheduler] cycle_lengths = [1000]`, `warm_up_steps = [50]`
  * `[trainer] grad_accum_iter = 2`, `logging_iter = 1`, `max_iter = 500`
  * `[trainer.callbacks.grad_clip] clip_norm = 0.1`, `force_finite = true`
  * `[checkpoint] keys_to_skip_loading = ["net_ema."]`, `save_iter = 100`
  * `[dataloader_train] max_sequence_length = 45056`, `max_caption_tokens = 2048`
    — and `max_caption_tokens` does NOT appear in docs/sft_config.md's
    `[dataloader_train]` table, which is a genuine documentation gap given
    `extra="forbid"`. The notebook has the learner check their own schema.

`docs/training.md` — Step 1 (dataset + Wan VAE downloads with the pinned
revision `40d018ac1c1a2a4b9734f17fdb21f3d933c49a01`), Step 2
(`convert_model_to_dcp`), Step 3 Option B (raw torchrun, and the explicit
warning that raw torchrun does NOT auto-resolve DATASET_PATH /
BASE_CHECKPOINT_PATH / WAN_VAE_PATH), the `$RUN_DIR` layout, and `export_model`.
Also: "Cosmos3-Edge is only 2B and also fits a 4-GPU node — e.g.
NPROC_PER_NODE=4 ... (tested on 4xGB200)". That is the smallest documented
claim anywhere, and it is still four times what we have.

`examples/_sft_launcher_common.sh` — `NPROC_PER_NODE` default 8, `MASTER_PORT`
default 50012, and the `TRAILING_ARGS=(-- "${TAIL_OVERRIDES[@]}")` construction
that inserts the `--` separator before Hydra tail overrides. The course helper
`finetune.build_train_command` does not insert that separator; the notebook
makes the learner notice and fix it rather than papering over it.

`docs/faq.md` — the SFT OOM ladder, whose rungs 3 and 4 both require more GPUs.

Nothing runs without an explicit opt-in. Default state of the notebook: prints
commands, computes predictions, and executes nothing that downloads or trains.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 17 — Shrinking an 8-GPU recipe to one")

# --------------------------------------------------------------- title block
nb.md("""
# Lesson 17 — Shrinking an 8-GPU recipe to one

**What you will build.** `outputs/17/` containing a written prediction made
*before* you ran anything, the overrides you applied and why, a training log
with a loss curve and a peak-memory figure, and `training_report.md` — an
honest account of what happened, whether or not it worked.

| | |
|---|---|
| **Time** | ~3 hours, and this is the lesson most likely to overrun. |
| **GPU** | 1 × H100 80 GB, **exclusively**. Stop the NIM. Nothing else resident. |
| **Downloads** | **All opt-in.** Dataset 0.65 GB · Wan2.2 VAE 2.82 GB · Edge 9.1 GB · a DCP (Distributed Checkpoint) copy of Edge (~8–10 GB) · one checkpoint per `save_iter` (20–40 GB each — measure yours). |
| **Prerequisites** | Lessons 14 and 16. You need Lesson 16's arithmetic and Lesson 14's allocated/reserved distinction. |

Set the environment up first. The caveats come immediately after it, before
anything has been spent.
""")

# ---------------------------------------------------------------- objectives
nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Read** `vision_sft_edge.toml` field by field and **explain** what each
   setting costs in memory, throughput or quality.
2. **State** the parallelism degree-product invariant and **verify** that world
   size 1 satisfies it trivially.
3. **Predict**, in writing and before running anything, whether the recipe fits
   on one card and what peak memory you expect.
4. **Derive** each single-GPU override from the FAQ's OOM ladder, and
   **identify** the two rungs that require hardware you do not have.
5. **Assemble** the exact `torchrun` invocation, **inspect** it before it runs,
   and **name** the two things the course helper leaves out.
6. **Run** the smoke configuration and **parse** its log into a loss curve and a
   peak-memory figure.
7. **Reconcile** measured peak memory against your prediction, and **attribute**
   the gap to activations.
8. **Diagnose** an OOM from *where* in the run it happened, and **choose** the
   correct rung rather than the first one you remember.
9. **Export** a trained checkpoint and **compare** it against the base model at
   a fixed prompt and seed.
10. **Report** the outcome honestly, including what your evidence cannot show.
""")

# ------------------------------------------------------------- environment
#
# The environment cells come BEFORE the conceptual foundation on purpose. The
# authoring guide's section order is title -> objectives -> concepts ->
# environment; putting six hundred words of caveat ahead of the first runnable
# cell is how a beginner stops reading. Title and objectives stay at the top,
# the caveats move to just after setup — still before anything is downloaded.
nb.md("""
## Environment and prerequisites

`MODE` decides how long the run is. `reduced` is a 20-iteration smoke test that
finishes in minutes and tells you whether the configuration *fits*. `full` is
100 iterations and tells you whether the loss moves. Neither is a real
fine-tune; the shipped recipe runs 500.
""")

nb.code('__lesson__ = "17"   # OUTPUT_DIR resolves to outputs/17\n\n' + SETUP_CELL)

nb.code('''
# ---------------------------------------------------------------------------
# Lesson configuration. Every expensive action is opt-in and named here.
# ---------------------------------------------------------------------------
import json
import shutil
import subprocess
import time

from cosmos_course import finetune

# Where the framework checkout lives. Set COSMOS3_REPO in your shell to move it.
REPO = cc.COSMOS3_REPO

# --- opt-in switches. All default OFF. -------------------------------------
#   export COSMOS_COURSE_ALLOW_SFT_DOWNLOAD=1   # ~12 GB of downloads
#   export COSMOS_COURSE_RUN_SFT=1              # actually train
ALLOW_DOWNLOADS = os.environ.get("COSMOS_COURSE_ALLOW_SFT_DOWNLOAD", "0") == "1"
RUN_TRAINING    = os.environ.get("COSMOS_COURSE_RUN_SFT", "0") == "1"

# --- the knobs this lesson tunes -------------------------------------------
MAX_ITER   = 20 if MODE == "reduced" else 100
SAVE_ITER  = MAX_ITER            # exactly one checkpoint, at the end
TOKEN_CAP  = 12288               # down from the shipped 45056. Bisect this.
GRAD_ACCUM = 8                   # up from 2, to recover the global batch

# --- paths, all relative to the framework repo, per docs/training.md --------
DATASET_PATH  = REPO / "examples/data/BridgeData2-Subset-Synthetic-Captions/sft_dataset_bridge"
BASE_CKPT     = REPO / "examples/checkpoints/Cosmos3-Edge"
WAN_VAE       = REPO / "examples/checkpoints/wan22_vae/Wan2.2_VAE.pth"
TRAIN_OUT     = OUTPUT_DIR / "train"
RUN_DIR       = TRAIN_OUT / "cosmos3" / "sft" / "vision_sft_edge"
LOG_PATH      = OUTPUT_DIR / "vision_sft_edge_1gpu.log"

print(f"framework repo   : {REPO}   exists={REPO.exists()}")
print(f"dataset          : exists={DATASET_PATH.exists()}")
print(f"base DCP ckpt    : exists={BASE_CKPT.exists()}")
print(f"Wan2.2 VAE       : exists={WAN_VAE.exists()}")
print()
print(f"MODE={MODE}  ->  max_iter={MAX_ITER}, save_iter={SAVE_ITER}")
print(f"token cap {TOKEN_CAP}, grad_accum {GRAD_ACCUM}")
print(f"ALLOW_DOWNLOADS={ALLOW_DOWNLOADS}   RUN_TRAINING={RUN_TRAINING}")
''')

nb.code('''
# ---------------------------------------------------------------------------
# Preflight. Fails loudly and usefully rather than 40 minutes into a download.
# ---------------------------------------------------------------------------
problems = []
if not REPO.exists():
    problems.append(
        f"no framework checkout at {REPO}. git clone "
        "https://github.com/NVIDIA/cosmos-framework (note NVIDIA/, not "
        "nvidia-cosmos/), or export COSMOS3_REPO=<path>.")
elif not (REPO / ".venv" / "bin" / "python").exists():
    problems.append(f"no venv at {REPO}/.venv — run scripts/setup.sh first.")

free_gb = shutil.disk_usage(COURSE_ROOT).free / 1e9
if free_gb < 60:
    problems.append(
        f"only {free_gb:.0f} GB free. This lesson can consume 60+ GB "
        "(base weights, a DCP copy, and a checkpoint carrying optimizer state).")

if DEVICE != "cuda" and RUN_TRAINING:
    problems.append("RUN_TRAINING is on but DEVICE is not cuda.")

for p in problems:
    print(f"  ! {p}")
if not problems:
    print(f"preflight ok — {free_gb:.0f} GB free")

# Reading and predicting works without any of this. Training does not.
print()
print("The rest of this notebook reads configs and computes predictions either")
print("way. Only the cells marked as gated need the items above.")
''')

# ------------------------------------------------- conceptual foundation
nb.md("""
## Read this before anything else

**NVIDIA documents no single-GPU training path for Cosmos 3.** Every shipped
recipe is an 8-GPU configuration, tested on 8 × H100 80 GB. The smallest claim
NVIDIA makes anywhere is in `docs/training.md`: *"Cosmos3-Edge is only 2B and
also fits a 4-GPU node — e.g. `NPROC_PER_NODE=4 bash
examples/launch_sft_vision_edge.sh` (tested on 4×GB200)."* Four is the floor
anyone has published, and it is four times what you have.

What follows is therefore **an experiment with a predicted outcome, not a
promise.** The course's position is that the arithmetic says it is plausible,
that plausible is not proven, and that the honest thing to do is predict,
attempt, and report. If your run OOMs at iteration 3 and you can say which
setting caused it, you have completed this lesson.

By default this notebook **downloads nothing and trains nothing.** Every
expensive step is behind an environment variable, and each one prints its size
or expected duration before it starts.

The cell below prints what the course module records about the recipe you are
about to shrink. Read the GPU counts before you read anything else.
""")

nb.code('''
recipe_facts = finetune.SHIPPED_RECIPES["vision_sft_edge"]
for key in ("toml", "launcher", "base_model", "trainable", "dataset",
            "documented_gpus", "smallest_documented", "max_iter", "token_cap"):
    print(f"  {key:<20s} {recipe_facts[key]}")

print()
print(f"  {'you have':<20s} 1 GPU")
print(f"  {'verdict':<20s} {recipe_facts['single_gpu']}")
print()
print("Every other recipe in the framework documents 8 GPUs or more:")
print(" ", {name: spec["documented_gpus"]
            for name, spec in sorted(finetune.SHIPPED_RECIPES.items())})
''')

nb.md("""
## What an 8-GPU recipe assumes, and what breaks when you take seven away

A shipped recipe is not a list of preferences. It is a set of numbers that were
chosen together, on a particular machine, and several of them encode the
machine.

- **`max_num_tokens_after_packing = 45056`** was sized so that the activations
  for one **rank** — one GPU process in the job — fit, given that FSDP (Fully
  Sharded Data Parallel, which splits parameters and optimizer state across the
  GPUs instead of copying them onto each one) had already divided the *state* by
  eight. On one GPU the state is not divided and the token budget is the only
  thing left to cut.
- **`grad_accum_iter = 2`** was chosen with world size 8 to hit a target global
  batch. Global batch is `grad_accum_iter × per-rank batch × world_size`. Drop
  world size from 8 to 1 and, if you change nothing else, you have divided your
  global batch by eight — a different optimisation problem, not a slower version
  of the same one.
- **`ema.enabled = true`** is affordable when the EMA copy is sharded eight
  ways. It is a whole extra fp32 copy when it is not.
- **`compile.enabled = true`** trades memory for speed on shapes someone has
  compiled before. You are about to feed it shapes nobody has.

So shrinking the recipe is not "set `nproc_per_node=1`". It is four separate
decisions, each with a reason, and one of them (`grad_accum_iter`) exists purely
to keep the *statistics* comparable while the hardware changes underneath.
""")

# ------------------------------------------------------- the shipped TOML
nb.md("""
## The recipe, field by field

Here is `examples/toml/sft_config/vision_sft_edge.toml` as it ships. It is
reproduced in full so this lesson works without a checkout — and then diffed
against your own copy, because a course that hands you a cached file is exactly
the failure mode `COSMOS3_FACTS.md` exists to prevent.
""")

nb.code('''
SHIPPED_EDGE_TOML = """\\
# vision_sft_edge - T2V / I2V / V2V vision-only SFT (Nemotron-2B-Dense-VL / Cosmos3-Edge)

[job]
task         = "vfm"
experiment   = "vision_sft_edge"
project      = "cosmos3"
group        = "sft"
name         = "vision_sft_edge"
wandb_mode   = "disabled"

[model]
max_num_tokens_after_packing = 45056
joint_attn_implementation    = "two_way"
precision                    = "bfloat16"

[model.ema]
enabled         = true
rate            = 0.1
iteration_shift = 0

[model.parallelism]
data_parallel_shard_degree      = -1
data_parallel_replicate_degree  = 1

[model.compile]
enabled                         = true
compile_dynamic                 = true

[model.activation_checkpointing]
mode                = "full"
save_ops_regex      = ["fmha"]
preserve_rng_state  = true
determinism_check   = "default"

[model.tokenizer]
vae_path = "${oc.env:WAN_VAE_PATH}"

[optimizer]
betas         = [0.9, 0.95]
eps           = 1.0e-6
fused         = true
keys_to_select = ["moe_gen", "time_embedder", "vae2llm", "llm2vae", "k_norm_und_for_gen"]
lr            = 1.0e-4
weight_decay  = 0

[scheduler]
cycle_lengths      = [1000]
f_max              = [1.0]
f_min              = [0.0]
f_start            = [0.0]
verbosity_interval = 0
warm_up_steps      = [50]

[trainer]
distributed_parallelism = "fsdp"
grad_accum_iter         = 2
logging_iter            = 1
max_iter                = 500

[trainer.callbacks.compile_tokenizer]
compile_after_iterations = 3
enabled                  = false

[trainer.callbacks.grad_clip]
clip_norm    = 0.1
force_finite = true

[checkpoint]
keys_to_skip_loading = ["net_ema."]
load_path            = "${oc.env:BASE_CHECKPOINT_PATH}"
save_iter            = 100

[dataloader_train]
max_sequence_length = 45056
max_caption_tokens  = 2048
"""

TOML_REL = "examples/toml/sft_config/vision_sft_edge.toml"
local_toml = REPO / TOML_REL

# Prefer YOUR checkout over the cached copy. If they differ, that is the news.
if local_toml.exists():
    text = local_toml.read_text()
    print(f"using your checkout: {local_toml}")
else:
    text = SHIPPED_EDGE_TOML
    print("no checkout found — using the copy cached in this notebook.")
    print("Diff it against upstream yourself before you trust any number here.")

WORK_TOML = OUTPUT_DIR / "vision_sft_edge.toml"
WORK_TOML.write_text(text)

try:
    recipe = finetune.read_toml(WORK_TOML)
except ImportError as exc:
    # tomllib is stdlib from Python 3.11. This course's floor is 3.10, and the
    # framework's is too, so this is a real possibility rather than a formality.
    raise RuntimeError(
        f"{exc}\\n\\n  How to fix it: pip install tomli\\n"
        "  (Python 3.11+ has tomllib in the standard library and needs nothing.)"
    ) from exc

print()
print("sections:", ", ".join(recipe))
''')

nb.md("""
### `[job]` and `[model]`

| Field | Value | What it does |
|---|---|---|
| `task` | `"vfm"` | Picks the base config tree. `vfm` is the generator, `vlm` the reasoner. Also selects the VFM↔VLM path-remap rules — which is why the LoRA keys work here and would be silently skipped on `vlm`. |
| `experiment` | `"vision_sft_edge"` | Names a registered Python SKU under `configs/base/experiment/sft/`. The dataloader class, dataset wiring and model instance live there, not in the TOML. |
| `project` / `group` / `name` | `cosmos3` / `sft` / `vision_sft_edge` | Output directory is `$IMAGINAIRE_OUTPUT_ROOT/<project>/<group>/<name>/`. |
| `max_num_tokens_after_packing` | `45056` | **The activation driver.** Sequence packing fills a buffer of this many tokens with as many samples as fit. Bigger means better GPU utilisation and more activation memory. `-1` disables the cap entirely. |
| `joint_attn_implementation` | `"two_way"` | Understanding/generation blocks with cross-attention. `three_way` needs NATTEN (Blackwell); `flex` is legacy. |
| `precision` | `"bfloat16"` | Forward/backward compute dtype. Master weights stay fp32 regardless — this field does not change your memory bill's fp32 rows. |

### `[model.ema]`, `[model.compile]`, `[model.activation_checkpointing]`

`ema.enabled = true` keeps a second fp32 copy of the trainable parameters,
updated as `ema_w = (1 - rate^k)·w + rate^k·ema_w`. Inference uses the EMA
weights; training continues on the live ones. Over 500 iterations that is a
real quality knob. Over 20 it is 8 GB of nothing.

`compile.enabled = true` is the surprise in this file. The **schema default is
`false`** (`docs/sft_config.md`, `[model.compile]`), and the Super recipe
explicitly turns it off. Edge leaves it on. `torch.compile` costs memory during
tracing and autotuning, adds several minutes to startup, and is one of the more
common first-run failures on an unusual shape configuration.

`activation_checkpointing.mode = "full"` — note this carefully. **The FAQ's OOM
rung 2 is already applied in this recipe.** If you reach for "turn on activation
checkpointing" when this OOMs, you will discover it has been on the whole time.
That is worth knowing before you waste an hour on it.
""")

nb.code('''
def field(path, default="(absent)"):
    """Read a dotted path out of the parsed TOML."""
    node = recipe
    for part in path.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node

for path in ("job.task", "job.experiment",
             "model.max_num_tokens_after_packing", "model.precision",
             "model.ema.enabled", "model.ema.rate",
             "model.compile.enabled", "model.compile.compile_dynamic",
             "model.activation_checkpointing.mode",
             "model.activation_checkpointing.save_ops_regex"):
    print(f"  {path:<48s} {field(path)!r}")

print()
print("Two things to notice, because both cost you:")
print(f"  ema.enabled     = {field('model.ema.enabled')!r}"
      "   -> a full fp32 copy of the trainable params")
print(f"  compile.enabled = {field('model.compile.enabled')!r}"
      "   -> schema DEFAULT is false; this recipe overrides it to true")
print(f"  ac.mode         = {field('model.activation_checkpointing.mode')!r}"
      "  -> the FAQ's OOM rung 2 is ALREADY ON")
''')

nb.md("""
### `[model.parallelism]` and the degree-product invariant

`data_parallel_shard_degree = -1` means "auto-fit from `WORLD_SIZE`", which is
the number of ranks in the job. That is the single line that makes this recipe
run unchanged at any rank count, and it is why the parallelism block needs no
override from you.

The two degrees combine into what the LIBERO recipe's comment calls **HSDP**,
Hybrid Sharded Data Parallel: shard the model within a group of GPUs, then
replicate that sharded group. `shard = 8` with `replicate = 2` is 16 ranks
arranged as two copies of an eight-way shard. At `WORLD_SIZE = 1` both degrees
are 1 and there is nothing to shard or replicate.

The invariant is where the documentation contradicts itself, so read both and
then read the code.
""")

nb.code('''
def resolve_shard(world_size, shard=-1, replicate=1, cp=1, cfg=1):
    """How `-1` resolves under each of the two documented readings.

    sft_config.md : shard x replicate x cp x cfg == WORLD_SIZE
    faq.md        : shard x replicate == WORLD_SIZE, cp and cfg are overlays
    """
    if shard != -1:
        return shard, shard
    return (world_size // (replicate * cp * cfg),      # four-factor reading
            world_size // replicate)                   # two-factor reading


print(f"{'world':>6s} {'cp':>3s} {'shard (x4 rule)':>16s} {'shard (x2 rule)':>16s}"
      "  configuration")
for ws, kw, label in (
    (1, {}, "your machine, shipped Edge recipe"),
    (8, {}, "shipped Edge recipe as tested"),
    (8, {"cp": 2}, "shipped Super recipe (context_parallel = 2)"),
    (16, {"shard": 8, "replicate": 2}, "shipped LIBERO recipe, HSDP 2x8"),
):
    four, two = resolve_shard(ws, **kw)
    flag = "  <- READINGS DISAGREE" if four != two else ""
    print(f"{ws:>6d} {kw.get('cp', 1):>3d} {four:>16d} {two:>16d}  {label}{flag}")

print()
print("At world size 1 both readings resolve the shard degree to 1 and the")
print("invariant holds trivially, so you can ignore the argument entirely.")
print("At world size 8 with cp=2 they resolve it to 4 and to 8 -- a real")
print("difference in how the mesh is built, decided by a file, not a document.")
''')

nb.callout(
    "upstream",
    "`docs/sft_config.md` states the invariant as `shard × replicate × "
    "context_parallel × cfg_parallel == WORLD_SIZE`. `docs/faq.md` states it as "
    "`replicate × shard == WORLD_SIZE` **always**, with `context_parallel` and "
    "`cfg_parallel` described as *overlay axes that share dp rank slots, not "
    "separate mesh dims*, and cites `cosmos_framework/utils/generator/"
    "parallelism.py` as the source. The shipped `vision_sft_super.toml` has "
    "shard `-1`, replicate `1`, cp `2` on 8 GPUs — which resolves shard to 4 under "
    "one rule and 8 under the other. Do not settle this from prose. Open "
    "`parallelism.py` in your checkout and read the assertion. It costs one "
    "minute and it is the habit this whole course is trying to build.",
)

nb.code('''
# The callout says to read the source. This finds it and shows you the lines
# that mention the degrees, so "read parallelism.py" is one cell rather than a
# scavenger hunt. Without a checkout it says so and moves on.
PARALLELISM_PY = REPO / "cosmos_framework/utils/generator/parallelism.py"

if PARALLELISM_PY.exists():
    hits = [(n, line.strip())
            for n, line in enumerate(PARALLELISM_PY.read_text().splitlines(), 1)
            if "degree" in line and ("assert" in line or "world" in line.lower())]
    print(f"{PARALLELISM_PY.relative_to(REPO)} — {len(hits)} relevant line(s)")
    for n, line in hits[:12]:
        print(f"  {n:>5d}  {line[:96]}")
    if not hits:
        print("  no line matched. Read the file yourself; the heuristic above is")
        print("  a convenience, not an authority.")
else:
    print(f"not found: {PARALLELISM_PY}")
    print("Set COSMOS3_REPO to your checkout and re-run. Until then, note which")
    print("claim you are trusting and why -- that is the actual skill here.")
''')

nb.md("""
### `[optimizer]`, `[scheduler]`, `[trainer]`, `[checkpoint]`, `[dataloader_train]`

`keys_to_select` is the substring allowlist you costed in Lesson 16. Five
entries, roughly half the model, and everything else frozen at 2 bytes per
parameter.

**Two upstream descriptions to reconcile before you trust a number.**
`docs/training.md` calls this recipe a *"Full fine-tune of the
Nemotron-2B-Dense-VL backbone (Cosmos3-Edge)"* and says elsewhere *"Cosmos3-Edge
is only 2B"*. The TOML in front of you restricts the optimizer to five
substrings, which is not a full fine-tune of anything — and Hugging Face reports
3,858,999,728 parameters for `nvidia/Cosmos3-Edge`, not two billion.

Both statements are defensible and neither is what you need. NVIDIA's "2B" names
the *Nemotron dense backbone*; the checkpoint also carries the generation
pathway and the SigLIP2 vision tower, which is where the rest of the 3.86B
lives. "Full fine-tune" describes the recipe relative to the Super tier, which
is LoRA-only. For memory arithmetic, use the number that decides the bill:
**3.86B resident in bf16, of which `keys_to_select` makes roughly half
trainable.** That is what Lesson 16 costed and it is what the estimator uses.
When prose and a config disagree, cost the config.

`lr = 1.0e-4` carries a comment in the shipped file: *"tuned via LR sweep: full
fine-tune converges faster at 1e-4 than 2e-5 (LoRA super stays 5e-4)."* Note
that the Nano recipe uses `2.0e-5` for the same task — learning rate is not
transferable between tiers.

`scheduler.warm_up_steps = [50]` against `trainer.max_iter = 500` means the
first 10% of the run is warmup, and `f_start = [0.0]` means it starts from
**zero** learning rate. **This matters enormously for a 20-iteration smoke
run:** at iteration 20 you are at 40% of peak LR and still climbing. A flat
loss over 20 iterations tells you almost nothing about whether learning works.

`grad_accum_iter = 2` and `logging_iter = 1` — the latter is unusually
aggressive and is a gift here: you get a loss line every optimizer step, so a
20-iteration run still produces a curve.

`clip_norm = 0.1` is tight. `force_finite = true` replaces NaN and Inf
gradients with zero, which converts a numerical explosion into a silent no-op —
remember that when the loss goes flat rather than to NaN.

`checkpoint.keys_to_skip_loading = ["net_ema."]` masks EMA tensors at load,
because the base checkpoint has none yet.
""")

nb.code('''
for path in ("optimizer.keys_to_select", "optimizer.lr", "optimizer.fused",
             "optimizer.betas", "optimizer.weight_decay",
             "scheduler.warm_up_steps", "scheduler.cycle_lengths",
             "scheduler.f_start", "scheduler.f_max",
             "trainer.grad_accum_iter", "trainer.logging_iter",
             "trainer.max_iter", "trainer.distributed_parallelism",
             "trainer.callbacks.grad_clip.clip_norm",
             "trainer.callbacks.grad_clip.force_finite",
             "checkpoint.save_iter", "checkpoint.keys_to_skip_loading",
             "dataloader_train.max_sequence_length",
             "dataloader_train.max_caption_tokens"):
    print(f"  {path:<48s} {field(path)!r}")

warm = field("scheduler.warm_up_steps", [0])[0]
print()
print(f"warmup is {warm} steps. Your smoke run is {MAX_ITER} steps, i.e. "
      f"{min(MAX_ITER / warm, 1.0):.0%} of the way through warmup.")
print("Interpret its loss curve accordingly, and say so in your report.")
''')

nb.callout(
    "gotcha",
    "`[dataloader_train].max_caption_tokens = 2048` is in the shipped TOML and "
    "is **not** in `docs/sft_config.md`'s `[dataloader_train]` table, which lists "
    "only `max_samples_per_batch`, `max_sequence_length` and `seed`. Since every "
    "sub-model sets `extra=\"forbid\"`, the field must exist in the pydantic "
    "schema or this recipe would not load at all — so the reference table is "
    "incomplete, not the TOML. Confirm it for yourself: grep "
    "`max_caption_tokens` in `cosmos_framework/configs/toml_config/sft_config.py`. "
    "This also tells you what `extra=\"forbid\"` buys: a typo in a config key is a "
    "`ValidationError` before training starts, not a silently ignored setting "
    "that costs you a night.",
)

# -------------------------------------------------- predict / run / explain 1
nb.md("""
## Predict, in writing, before you touch anything

This is the part of the lesson people skip, and it is the part that makes the
result mean something. A prediction you wrote down is falsifiable. A feeling you
had is not.
""")

nb.predict_run_explain(
    predict=(
        "Three numbers, written down before you run the cell below. (a) **State "
        "memory** in GB for `vision_sft_edge` with our overrides — Edge is 4B, "
        "roughly half trainable, EMA off. (b) **Peak memory** you expect to see "
        "reported by the run, which is state plus activations. (c) A **yes/no** on "
        "whether it will complete 20 iterations without OOM, and the single "
        "setting you think is most likely to be the one that kills it."
    ),
    change=(
        "Nothing yet. Run the cell to record your prediction to disk — you will "
        "compare against it after the run, and having it on disk means you cannot "
        "quietly revise it afterwards."
    ),
    explain=(
        "The estimator models **state only**. It says nothing about activations, "
        "which depend on `max_num_tokens_after_packing`, the packer's batch and "
        "the checkpointing mode. So the difference between your (a) and your (b) "
        "*is* your activation estimate — write down how you arrived at it, because "
        "you are going to measure it later."
    ),
    hint=(
        "Lesson 16 gave you 40 GB of state for Edge with EMA off. On an 80 GB card "
        "with ~4 GB of context and fragmentation reserve, that leaves about 36 GB. "
        "Is 12288 tokens of packed sequence, with `activation_checkpointing.mode = "
        "\"full\"`, going to fit in 36 GB? You genuinely do not know, and neither "
        "does the course. That is the experiment."
    ),
)

nb.code('''
est = finetune.estimate_sft_memory(
    "Cosmos3-Edge", trainable_fraction=0.5, ema=False, card_gb=80.0)
print(est)

# YOUR numbers. Edit these before running -- that is the whole exercise.
PREDICTION = {
    "predicted_state_gb": est.state_gb,          # from the estimator
    "my_predicted_peak_gb": 55.0,                # <- EDIT ME
    "my_predicted_activations_gb": 55.0 - est.state_gb,
    "will_it_fit": "unknown",                    # <- EDIT ME: yes / no / unknown
    "most_likely_blocker": "max_num_tokens_after_packing",   # <- EDIT ME
    "reasoning": "EDIT ME: two sentences on why.",
    "config": {"max_iter": MAX_ITER, "token_cap": TOKEN_CAP,
               "grad_accum": GRAD_ACCUM, "ema": False, "compile": False},
    "recorded_at": time.strftime("%Y-%m-%d %H:%M:%S"),
}
pred_path = OUTPUT_DIR / "prediction.json"
pred_path.write_text(json.dumps(PREDICTION, indent=2))
print()
print(f"prediction recorded -> {pred_path.relative_to(COURSE_ROOT)}")
print("Do not edit it after the run. Edit your understanding instead.")
''')

# ------------------------------------------------------------- overrides
nb.md("""
## The overrides, one at a time

`finetune.single_gpu_overrides()` produces the set. None of it is documented by
NVIDIA; it is the FAQ's OOM ladder with the two multi-GPU rungs removed, plus
two savings the ladder does not mention.

| Override | From | Why |
|---|---|---|
| `model.config.ema.enabled=false` | not in the ladder | A whole fp32 copy of the trainable parameters, bought for a quality effect you cannot observe in 20–100 iterations. Largest free saving available. |
| `model.config.compile.enabled=false` | not in the ladder | Trades memory for speed, which is the wrong direction, and compiles shapes nobody has compiled. Also removes several minutes of startup from every debugging cycle. |
| `model.config.activation_checkpointing.mode=full` | rung 2 | **Already `full` in this recipe.** Set explicitly so the intent is visible and so the override set is correct for recipes where it is not. Expect zero saving here. |
| `model.config.max_num_tokens_after_packing=12288` | rung 5, adapted | The activation driver, cut from 45056 to about a quarter. This is the number you will bisect. |
| `dataloader_train.max_sequence_length=12288` | rung 5 | Must track the token cap; leaving them inconsistent gives the packer a budget the model will not honour. |
| `trainer.grad_accum_iter=8` | not in the ladder | Recovers global batch: `2 × 8 ranks` becomes `8 × 1 rank`. Mathematically the same gradient, four times the wall-clock. |
| `model.config.parallelism.data_parallel_shard_degree=-1` | — | Already the default. Set explicitly so the world-size resolution is visible in the command line. |
| `PYTORCH_ALLOC_CONF=expandable_segments:True` | rung 1 | Free. Set in the child process's environment by `build_train_command`, which is the only place it can work — Lesson 14 covered why you cannot turn it on from a running kernel. |

Not on the list, and not available at any setting: raising the FSDP shard degree
(rung 3), raising the context-parallel degree (rung 4), CPU offload of anything,
and an 8-bit optimizer. The first two need more GPUs; the last two do not exist
in `SFTExperimentConfig`.
""")

nb.code('''
overrides = finetune.single_gpu_overrides(
    token_cap=TOKEN_CAP,
    grad_accum=GRAD_ACCUM,
    max_iter=MAX_ITER,
    save_iter=SAVE_ITER,
)

# Show each override next to what the shipped recipe had, so the delta is the
# thing you read rather than the absolute.
SHIPPED_EQUIVALENT = {
    "model.config.ema.enabled": field("model.ema.enabled"),
    "model.config.compile.enabled": field("model.compile.enabled"),
    "model.config.activation_checkpointing.mode":
        field("model.activation_checkpointing.mode"),
    "model.config.max_num_tokens_after_packing":
        field("model.max_num_tokens_after_packing"),
    "dataloader_train.max_sequence_length":
        field("dataloader_train.max_sequence_length"),
    "trainer.grad_accum_iter": field("trainer.grad_accum_iter"),
    "trainer.max_iter": field("trainer.max_iter"),
    "checkpoint.save_iter": field("checkpoint.save_iter"),
    "model.config.parallelism.data_parallel_shard_degree":
        field("model.parallelism.data_parallel_shard_degree"),
    "model.config.parallelism.data_parallel_replicate_degree":
        field("model.parallelism.data_parallel_replicate_degree"),
}

print(f"{'key':<58s} {'shipped':>10s}  ->  {'ours':<10s}")
print("-" * 92)
for key, new in overrides.items():
    old = SHIPPED_EQUIVALENT.get(key, "(default)")
    mark = "   " if old == new else " * "
    print(f"{mark}{key:<55s} {str(old):>10s}  ->  {str(new):<10s}")
print()

# Global batch: the thing grad_accum_iter is protecting.
#
# global_batch = grad_accum_iter x per_rank_batch x world_size
#
# per_rank_batch is set by the packer's token budget, not by a config field, so
# it is not knowable in advance -- it depends on how many samples fit in
# max_num_tokens_after_packing. Model it as proportional to the token cap and
# see what the substitution costs.
shipped_cap    = field("model.max_num_tokens_after_packing", 45056)
shipped_accum  = field("trainer.grad_accum_iter", 2)

def relative_global_batch(cap, accum, world):
    """Proportional model only. The constant cancels; the ratio does not."""
    return accum * (cap / shipped_cap) * world

base = relative_global_batch(shipped_cap, shipped_accum, 8)
ours = relative_global_batch(TOKEN_CAP, GRAD_ACCUM, 1)

print(f"shipped (8 GPUs) : accum {shipped_accum}, cap {shipped_cap}, "
      f"relative global batch {base:.2f}")
print(f"ours    (1 GPU)  : accum {GRAD_ACCUM}, cap {TOKEN_CAP}, "
      f"relative global batch {ours:.2f}")
print(f"ratio            : {ours / base:.2f} x the shipped global batch")
print()
need = shipped_accum * 8 * (shipped_cap / TOKEN_CAP)
print(f"To match it exactly you would need grad_accum_iter = {need:.0f},")
print(f"i.e. {need:.0f} forward/backward passes per optimizer step. At "
      f"{MAX_ITER} steps that is {need * MAX_ITER:.0f} passes.")
print("This is the honest trade: you can have the statistics or the wall-clock.")
''')

# --------------------------------------------------------- the command
nb.md("""
## The command, printed before it runs

A training run is long. You should see exactly what starts.
""")

nb.code('''
argv, env = finetune.build_train_command(
    WORK_TOML, repo=REPO, nproc=1, overrides=overrides,
    output_root=TRAIN_OUT, master_port=50012,
)

print("environment additions:")
for k, v in env.items():
    print(f"  {k}={v}")
print()
print("argv:")
for a in argv:
    print(f"  {a}")
''')

nb.md("""
### Two things the helper leaves out, and how to know

Read that command against `examples/_sft_launcher_common.sh`, which is what
NVIDIA actually runs. Two differences:

**1. The `--` separator.** The launcher builds
`TRAILING_ARGS=(-- "${TAIL_OVERRIDES[@]}")` and appends it after
`--sft-toml=...`. Hydra tail overrides go *after* a bare `--`; without it,
`argparse` sees them as positional arguments to `train.py` and you get an
unhelpful error — or worse, they are ignored and your run silently uses the
shipped 45056 token cap and OOMs for a reason you will misdiagnose.

**2. The three environment variables.** `docs/training.md` is explicit that raw
`torchrun` **does not** auto-resolve `DATASET_PATH`, `BASE_CHECKPOINT_PATH` or
`WAN_VAE_PATH` from `examples/` — only the launch shell does that. The TOML
reads two of them through `${oc.env:...}`; the third is consumed inside the
experiment SKU Python. Miss one and you get an OmegaConf interpolation error
naming a variable you have never heard of.

If you see `_COSMOS_COURSE_WARNING` in that environment dict, it is a
diagnostic the helper attaches when it cannot find the framework's venv — not
something to export into the child process. `finalise()` drops it.

Fix both. Do not fix them by editing `finetune.py` — fix them here, visibly, so
the next person reading your notebook can see what the real command needs.
""")

nb.checkpoint(
    "Assemble the real command and assert both fixes are in it. If either "
    "assertion fails, stop — a run launched without them will either die "
    "immediately or, worse, run to completion having ignored every override you "
    "spent this lesson deriving.",
    '''
def finalise(argv, env):
    """Insert the `--` separator and the three required env vars."""
    argv = list(argv)
    i = next(k for k, a in enumerate(argv) if a.startswith("--sft-toml="))
    if "--" not in argv:
        argv = argv[:i + 1] + ["--"] + argv[i + 1:]

    env = dict(env)
    env.update({
        "DATASET_PATH": str(DATASET_PATH),
        "BASE_CHECKPOINT_PATH": str(BASE_CKPT),
        "WAN_VAE_PATH": str(WAN_VAE),
    })
    env.pop("_COSMOS_COURSE_WARNING", None)
    return argv, env


ARGV, ENV = finalise(argv, env)

print("$ " + " \\\\\\n    ".join(
    [f"{k}={v}" for k, v in sorted(ENV.items()) if v] + list(ARGV)))
print()
assert "--" in ARGV, "the Hydra separator is missing"
assert all(k in ENV for k in ("DATASET_PATH", "BASE_CHECKPOINT_PATH", "WAN_VAE_PATH"))
print("command assembled. Nothing has run.")
''')

# ------------------------------------------------------- downloads (opt-in)
nb.md("""
## Step 1 and Step 2 — data and checkpoint

`docs/training.md` splits setup into two steps, and both are gated here.

**Step 1: the dataset and the VAE.** `nvidia/BridgeData2-Subset-Synthetic-Captions`
is 0.65 GB — 1,222 training clips at 256×256 with synthetic structured captions,
and 51 validation clips. It is by a wide margin the smallest dataset NVIDIA
ships for this, which is why the course uses it. The Wan2.2 VAE is a further
2.82 GB. Note the pinned dataset revision in the documented command: use it, or
you are training on a different dataset than the docs describe.

**Step 2: DCP conversion.** Training does not read Hugging Face safetensors. It
reads a PyTorch Distributed Checkpoint, and `convert_model_to_dcp` produces one.
This downloads Cosmos3-Edge (9.1 GB) if you do not have it and writes a second
copy in DCP layout (~8–10 GB). Budget for both.
""")

nb.code('''
DOWNLOAD_STEPS = [
    ("dataset (0.65 GB, pinned revision)", [
        "uvx", "hf@latest", "download", "--repo-type", "dataset",
        "nvidia/BridgeData2-Subset-Synthetic-Captions",
        "--revision", "40d018ac1c1a2a4b9734f17fdb21f3d933c49a01",
        "--local-dir", "examples/data/BridgeData2-Subset-Synthetic-Captions",
        "--quiet"]),
    ("Wan2.2 VAE (2.82 GB)", [
        "uvx", "hf@latest", "download", "Wan-AI/Wan2.2-TI2V-5B",
        "Wan2.2_VAE.pth", "--local-dir", "examples/checkpoints/wan22_vae",
        "--quiet"]),
    ("Edge -> DCP (9.1 GB down, ~8-10 GB written)", [
        "python", "-m", "cosmos_framework.scripts.convert_model_to_dcp",
        "-o", "examples/checkpoints/Cosmos3-Edge",
        "--checkpoint-path", "Cosmos3-Edge"]),
]

print("These run in the framework repo, in its venv. Total ~12 GB down,")
print("~20 GB written. Expect 10-40 minutes depending on your link.")
print()
for label, cmd in DOWNLOAD_STEPS:
    print(f"# {label}")
    print("  " + " ".join(cmd))
print()
print(f"ALLOW_DOWNLOADS = {ALLOW_DOWNLOADS}")
if not ALLOW_DOWNLOADS:
    print("Set COSMOS_COURSE_ALLOW_SFT_DOWNLOAD=1 and restart the kernel to run them,")
    print("or paste the commands into a shell in the repo. Either is fine.")
''')

nb.code('''
# Gated. Runs nothing unless you opted in.
if ALLOW_DOWNLOADS and REPO.exists():
    venv_bin = REPO / ".venv" / "bin"
    for label, cmd in DOWNLOAD_STEPS:
        exe = str(venv_bin / cmd[0]) if (venv_bin / cmd[0]).exists() else cmd[0]
        print(f"\\n>>> {label}")
        t0 = time.time()
        rc = subprocess.run([exe] + cmd[1:], cwd=REPO).returncode
        print(f"    exit {rc} in {time.time() - t0:.0f}s")
        if rc != 0:
            print("    stopping — fix this before continuing")
            break
else:
    print("skipped (ALLOW_DOWNLOADS is off, or no framework checkout)")

for label, path in (("dataset", DATASET_PATH), ("base DCP", BASE_CKPT),
                    ("Wan VAE", WAN_VAE)):
    print(f"  {label:<10s} {'present' if path.exists() else 'MISSING':<8s} {path}")
''', tags=["expensive"])

# ------------------------------------------------------------- the run
nb.md("""
## Run it

What you are about to start, stated plainly:

- **`MODE="reduced"`** — 20 iterations. Minutes, not hours, on an H100 once the
  model has loaded. It answers exactly one question: *does this configuration
  fit?* It does not answer whether the fine-tune works.
- **`MODE="full"`** — 100 iterations. Long enough for the loss to leave warmup
  and start moving. Still a fifth of the shipped recipe.

Model loading and DCP restore dominate a short run's wall-clock, so do not read
the total time as throughput.

**Before you start:** the GPU must be empty. Stop the Reasoner NIM
(`cc.nim.stop_nim()` if you have one running), close other notebooks' kernels,
and check with `nvidia-smi`. A NIM holding 40 GB will turn a run that would have
fitted into an OOM you then misdiagnose as an activation problem.
""")

nb.code('''
def gpu_is_clear(threshold_gb=2.0):
    """Anything already resident comes out of your training budget."""
    if not shutil.which("nvidia-smi"):
        return None, "nvidia-smi not available"
    out = subprocess.run(
        ["nvidia-smi", "--query-gpu=memory.used,memory.total",
         "--format=csv,noheader,nounits"],
        capture_output=True, text=True).stdout.strip().splitlines()
    used_mib, total_mib = (float(x) for x in out[0].split(","))
    used_gb = used_mib * (1024 ** 2) / 1e9
    total_gb = total_mib * (1024 ** 2) / 1e9
    return used_gb < threshold_gb, f"{used_gb:.1f} GB used of {total_gb:.1f} GB"

clear, detail = gpu_is_clear()
print(f"GPU: {detail}")
if clear is False:
    print("  ! Something is already holding VRAM. Find it with:")
    print("      nvidia-smi --query-compute-apps=pid,used_memory --format=csv")
    print("  and stop it before you train. This is the single most common")
    print("  cause of an OOM that has nothing to do with your configuration.")


def run_training(argv, env, log_path, timeout_s=None):
    """Run the training subprocess, tee its output, and return the exit code.

    Tees rather than capturing, because a run you cannot watch is a run you
    cannot abandon early -- and the log file is what TrainingWatch reads.
    """
    full_env = {**os.environ, **env}
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print("$ " + " ".join(argv))
    print(f"  logging to {log_path}")
    print("-" * 72)
    t0 = time.time()
    with log_path.open("w") as log:
        proc = subprocess.Popen(argv, cwd=REPO, env=full_env, text=True,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, bufsize=1)
        try:
            for line in proc.stdout:
                log.write(line)
                log.flush()
                print(line.rstrip())
            proc.wait(timeout=timeout_s)
        except KeyboardInterrupt:
            proc.terminate()
            print("\\ninterrupted — the partial log is still on disk")
    print("-" * 72)
    print(f"exit {proc.returncode} after {time.time() - t0:.0f}s")
    return proc.returncode
''')

nb.code('''
# THE RUN. Gated. Everything above works without it.
READY = all(p.exists() for p in (DATASET_PATH, BASE_CKPT, WAN_VAE))

if RUN_TRAINING and READY:
    print(f"starting: max_iter={MAX_ITER}, token_cap={TOKEN_CAP}, "
          f"grad_accum={GRAD_ACCUM}, ema=off, compile=off")
    print("This is undocumented and unvalidated by NVIDIA. Report what happens.")
    RETURNCODE = run_training(ARGV, ENV, LOG_PATH)
else:
    RETURNCODE = None
    if not RUN_TRAINING:
        print("RUN_TRAINING is off. Set COSMOS_COURSE_RUN_SFT=1 and restart the")
        print("kernel to attempt it.")
    if not READY:
        print("Inputs are missing — see the preflight table above.")
    print()
    print("A sample log ships with the course so the parsing cells below still")
    print("run. It is SYNTHETIC and labelled as such; do not report its numbers.")
''', tags=["expensive"])

# ------------------------------------------------------------ watching
nb.md("""
## Watching it

`finetune.TrainingWatch` parses the log with regexes rather than hooking the
trainer, because a long run is usually watched from a second terminal and the
log is the thing that is definitely there. If the framework's log format has
drifted, the parser will find nothing and say so — open the log and fix the
regexes, which is a five-minute job and a good habit.

One drift to expect specifically: the memory regex is
`([\\d.]+)\\s*GB.*(?:peak|reserved|allocated)`, which requires the **number
before** the keyword. A trainer that logs `peak reserved 61.4 GB` rather than
`61.4 GB peak reserved` will parse as *no peak reported at all*, and you will
conclude your build does not log memory when it does. Read the log with your
own eyes once before you trust any parser over it.
""")

nb.code('''
SYNTHETIC_LOG = """\\
[SYNTHETIC LOG - not a real run. Do not report these numbers.]
[INFO] loading checkpoint from examples/checkpoints/Cosmos3-Edge
[INFO] trainable parameters: 1.94B of 3.86B (keys_to_select)
[INFO] iter: 1  loss: 0.4132  lr: 2.0e-06
[INFO] iter: 2  loss: 0.4098  lr: 4.0e-06
[INFO] iter: 5  loss: 0.4011  lr: 1.0e-05
[INFO] iter: 10 loss: 0.3874  lr: 2.0e-05
[INFO] iter: 15 loss: 0.3810  lr: 3.0e-05
[INFO] iter: 20 loss: 0.3722  lr: 4.0e-05
[INFO] memory: 61.4 GB peak reserved (allocated 58.9 GB)
[INFO] saving checkpoint to checkpoints/iter_000000020
[INFO] training complete
"""

if LOG_PATH.exists() and RETURNCODE is not None:
    watch_path = LOG_PATH
    print(f"parsing YOUR run: {watch_path}")
else:
    watch_path = OUTPUT_DIR / "synthetic_example.log"
    watch_path.write_text(SYNTHETIC_LOG)
    print("parsing the SYNTHETIC example — your run has not happened yet")

watch = finetune.TrainingWatch(watch_path).parse()
print()
print(watch.summary())

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

if plt is not None and watch.iters:
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.4))
    ax[0].plot(watch.iters, watch.losses, marker="o", ms=3)
    ax[0].set_xlabel("iteration")
    ax[0].set_ylabel("loss")
    ax[0].set_title("loss" + (" (SYNTHETIC)" if watch_path != LOG_PATH else ""))
    ax[0].grid(alpha=.3)
    ax[1].plot(watch.iters, watch.lrs, marker="o", ms=3, color="tab:orange")
    ax[1].set_xlabel("iteration")
    ax[1].set_ylabel("learning rate")
    ax[1].set_title("LR schedule — note it is still in warmup")
    ax[1].grid(alpha=.3)
    fig.tight_layout()
    plt.show()
elif not watch.iters:
    print("nothing parsed. Open the log and adjust TrainingWatch's regexes.")
else:
    print("matplotlib not available; the numbers are in watch.losses")
''')

# -------------------------------------------------- predict / run / explain 2
nb.predict_run_explain(
    predict=(
        "Two predictions. (1) **Peak memory.** You predicted a number before the "
        "run. The estimator predicted state only. The gap between measured peak "
        "and predicted state is activations plus allocator overhead — predict "
        "that gap in GB before you look. (2) **The loss.** Predict whether loss "
        "falls over 20 iterations, and — separately — state what a fall would and "
        "would not establish."
    ),
    change=(
        "Nothing. Run the reconciliation cell, which reads back the prediction "
        "you wrote to disk and compares it against the log."
    ),
    explain=(
        "On (1): the estimator does not model activations, so a measured peak "
        "above predicted state is expected and *informative* — it is your first "
        "real measurement of activation cost at this token cap, and it is what "
        "lets you bisect intelligently rather than by halving blindly. On (2): a "
        "falling loss over 20 iterations at 40% of peak learning rate mostly "
        "establishes that gradients are flowing and the data pipeline is "
        "connected. It does not establish that the model got better at anything "
        "you care about. Lesson 18 is about that gap."
    ),
    hint=(
        "Peak *allocated* and peak *reserved* are different numbers, and the log "
        "may report either. Lesson 14's distinction applies exactly: reserved "
        "includes the allocator's cached blocks, so reserved-minus-allocated is "
        "not activation memory."
    ),
)

nb.code('''
prediction = json.loads(pred_path.read_text())
measured_peak = watch.peak_mem_gb

print(f"predicted state (estimator) : {prediction['predicted_state_gb']:.1f} GB")
print(f"your predicted peak         : {prediction['my_predicted_peak_gb']:.1f} GB")
if measured_peak:
    gap = measured_peak - prediction["predicted_state_gb"]
    err = measured_peak - prediction["my_predicted_peak_gb"]
    print(f"measured peak               : {measured_peak:.1f} GB"
          + ("   [SYNTHETIC]" if watch_path != LOG_PATH else ""))
    print(f"  peak - predicted state    : {gap:+.1f} GB   <- activations + overhead")
    print(f"  peak - YOUR prediction    : {err:+.1f} GB   <- how wrong you were")
    print()
    print(f"activation cost per 1000 packed tokens, roughly: "
          f"{gap / (TOKEN_CAP / 1000):.2f} GB")
    print("Use that to extrapolate before you bisect. It is linear enough to be")
    print("useful and non-linear enough that you must still verify.")
else:
    print("measured peak               : not reported in this log")
    print("  Not every build logs peak memory. If yours does not, sample")
    print("  nvidia-smi from a second process during the run -- Lesson 14's")
    print("  applied exercise built exactly that profiler.")
''')

# ------------------------------------------------------------ the ladder
nb.md("""
## When it OOMs

Not *if*. This configuration is a guess, and the first guess in a memory-bound
job is usually wrong. Here is the ladder, in the order to try it, with what each
rung costs.

**Rung 1 — `PYTORCH_ALLOC_CONF=expandable_segments:True`.** Free.
`build_train_command` already sets it in the child environment. Confirm it
arrived: if the OOM message says several GB are free but the allocation still
failed, this is a fragmentation OOM and this rung is the one that fixes it.

**Rung 2 — activation checkpointing `full`.** Already on in this recipe. Verify
rather than assume; if you inherited a recipe where it is `selective` or `none`,
this is worth 30% of throughput and a lot of memory.

**Rung 3 — halve `max_num_tokens_after_packing`, double `grad_accum_iter`.**
This is your main lever. Halving the token cap roughly halves activation memory;
doubling grad accumulation keeps the global batch where it was. Cost is
wall-clock, linearly.

**Rung 4 — LoRA.** Changes what you are training, not just how. Cost is model
capability: rank-16 adapters on four projection matrices cannot express every
update a full fine-tune can.

**Not available, at any setting:** raising `data_parallel_shard_degree`,
raising `context_parallel_shard_degree`, CPU offload of parameters/optimizer
state/activations, and 8-bit optimizers. The first two need more GPUs; the last
two do not exist in `SFTExperimentConfig`. If you find advice online that starts
with "just increase the shard degree", it was written for a node.
""")

nb.code('''
# Note what this prints: the first five rungs are the INFERENCE ladder
# (resolution, frames, steps), because that is what most learners hit first.
# The training rungs are appended at the end under "Training-only rungs".
# Read those, and ignore the advice to lower the resolution tier -- there is no
# such knob in an SFT config.
cc.oom_advice(measured_peak, model="Cosmos3-Edge", training=True,
              total_gb=80.0)

print()
print("=" * 72)
# Rung 4, spelled out. LoRA changes four config keys, and the fourth is the one
# people forget: without keys_to_skip_loading the loader looks for adapter
# tensors in a base checkpoint that has none.
lora_overrides = finetune.single_gpu_overrides(
    token_cap=TOKEN_CAP, grad_accum=GRAD_ACCUM,
    max_iter=MAX_ITER, save_iter=SAVE_ITER,
    lora=True, lora_rank=16,
)
for key in sorted(set(lora_overrides) - set(overrides)):
    print(f"  + {key} = {lora_overrides[key]}")

lora_est = finetune.estimate_sft_memory(
    "Cosmos3-Edge", lora=True, lora_rank=16, ema=False, card_gb=80.0)
print()
print(f"state with LoRA : {lora_est.state_gb:.1f} GB "
      f"(vs {est.state_gb:.1f} GB with keys_to_select)")
print(f"activation room : {lora_est.activation_budget_gb:.1f} GB "
      f"(vs {est.activation_budget_gb:.1f} GB)")
print()
print("Note what LoRA does NOT remove: the bf16 weights, all 8 GB of them.")
print("And note the honest caveat -- lora_target_modules defaults to the four")
print("generation-expert attention projections, so the vae2llm / llm2vae")
print("projections that keys_to_select trains get no adapter at all. These are")
print("not the same fine-tune at a different memory point.")
''')

# --------------------------------------------------------- debugging lab
nb.md("""
## Debugging lab — it OOMed at iteration 3

### Symptom

The run loads, logs two iterations, and dies on the third.
""")

nb.code('''
OOM_TRACEBACK = """\\
[INFO] loading checkpoint from examples/checkpoints/Cosmos3-Edge
[INFO] checkpoint loaded in 41.2s
[INFO] trainable parameters: 1.94B of 3.86B (keys_to_select)
[INFO] iter: 1  loss: 0.4140  lr: 2.0e-06
[INFO] iter: 2  loss: 0.4121  lr: 4.0e-06
Traceback (most recent call last):
  File "cosmos_framework/trainer/trainer.py", line 288, in train
    loss = self.model.training_step(batch, iteration)
  File "cosmos_framework/model/vfm.py", line 610, in training_step
    out = self.net(x, timesteps=t, context=ctx)
torch.OutOfMemoryError: CUDA out of memory. Tried to allocate 4.62 GiB.
GPU 0 has a total capacity of 79.15 GiB of which 3.11 GiB is free.
Of the allocated memory 68.90 GiB is allocated by PyTorch, and 2.84 GiB
is reserved by PyTorch but unallocated.
"""
oom_log = OUTPUT_DIR / "oom_iter3.log"
oom_log.write_text(OOM_TRACEBACK)
print(OOM_TRACEBACK)
''', tags=["teaching-antipattern"])

nb.md("""
### Hypothesis — read *where* it failed, not just *that* it failed

Three facts in that traceback, and each one narrows it:

1. **It got to iteration 3.** So the checkpoint loaded, the optimizer was
   constructed, and two complete forward/backward/step cycles ran. **State
   fits.** Every rung that reduces state — LoRA, `keys_to_select`, EMA — is
   therefore addressing a problem you do not have. This single observation
   eliminates half the ladder.
2. **It died inside `training_step` → `self.net(...)`.** That is the forward
   pass. The allocation that failed is an activation.
3. **`allocated 68.90 GiB`, `reserved but unallocated 2.84 GiB`, `free 3.11
   GiB`.** The reserved-but-unallocated figure is small, so this is *not* a
   fragmentation OOM — `expandable_segments` will not save you. The memory is
   genuinely in use.

Why iteration 3 rather than 1? Because the packer's batches vary. Sequence
packing fills a token budget with whatever samples fit, so batch 3 may hold more
samples, or longer ones, than batches 1 and 2. **The peak is set by the worst
batch in the dataset, not the first.** A configuration that survives ten
iterations can still die at four hundred, which is the argument for running the
smoke test on a shuffled dataset and for leaving real headroom.

So: an activation problem, at a token cap that is too high for this card.
Rung 3.
""")

nb.code('''
def diagnose_oom(log_text):
    """Classify an OOM as state or activation, from the traceback alone."""
    import re
    reached = [int(m) for m in re.findall(r"iter:\\s*(\\d+)", log_text)]
    in_forward = "training_step" in log_text or "self.net(" in log_text
    in_load = "load_state_dict" in log_text or "optimizer" in log_text.split(
        "Traceback")[-1][:400]
    # \\s+ rather than a space: the figure and the phrase are often split across
    # a line break in a real traceback, and a plain space silently reports 0.00.
    frag = re.search(r"([\\d.]+) GiB\\s+is reserved by PyTorch but unallocated",
                     log_text)
    frag_gb = float(frag.group(1)) if frag else 0.0
    want = re.search(r"Tried to allocate ([\\d.]+) GiB", log_text)

    verdict = []
    if reached:
        verdict.append(
            f"reached iteration {max(reached)} -> state fits; this is ACTIVATION")
    elif in_load:
        verdict.append("failed before iteration 1 -> this is STATE")
    else:
        verdict.append("could not tell from the log — where did it fail?")
    if in_forward:
        verdict.append("failed inside the forward pass")
    verdict.append(
        f"fragmentation: {frag_gb:.2f} GiB reserved-unallocated -> "
        + ("expandable_segments may help" if frag_gb > 5
           else "NOT fragmentation; expandable_segments will not help"))
    if want:
        verdict.append(f"the failed allocation wanted {want.group(1)} GiB")
    return verdict


for line in diagnose_oom(oom_log.read_text()):
    print("  -", line)
''')

nb.md("""
### Repair

Apply rung 3, and size it from evidence rather than by reflex. The traceback
says 3.11 GiB was free and the failed allocation wanted 4.62 GiB — so you are
short by roughly 1.5 GB at the peak, out of a working set of about 69 GB. That
is a 2% overshoot, not a 50% one.

Halving the token cap would work and would also double your wall-clock for no
reason. Cut by a third instead, and raise `grad_accum_iter` in **inverse
proportion** so the global batch lands where it was — cutting the cap by a
third means multiplying accumulation by 3/2, not by 2. Then re-run. If it
survives, *then* bisect upward to find the real frontier, which is the applied
exercise.
""")

nb.code('''
REPAIRED_CAP = int(TOKEN_CAP * 2 / 3)                      # 12288 -> 8192
# Inverse proportion, not a reflex doubling. Doubling would OVERSHOOT the
# previous global batch by a third and cost you a third more wall-clock for it.
REPAIRED_ACCUM = round(GRAD_ACCUM * TOKEN_CAP / REPAIRED_CAP)

repaired = finetune.single_gpu_overrides(
    token_cap=REPAIRED_CAP, grad_accum=REPAIRED_ACCUM,
    max_iter=MAX_ITER, save_iter=SAVE_ITER)

print(f"token cap  {TOKEN_CAP} -> {REPAIRED_CAP}")
print(f"grad accum {GRAD_ACCUM} -> {REPAIRED_ACCUM}  "
      f"(reflex doubling would have given {GRAD_ACCUM * 2})")
print(f"relative global batch: "
      f"{relative_global_batch(REPAIRED_CAP, REPAIRED_ACCUM, 1) / ours:.2f} x "
      f"the previous attempt "
      f"(doubling: "
      f"{relative_global_batch(REPAIRED_CAP, GRAD_ACCUM * 2, 1) / ours:.2f} x)")
print()

repaired_argv, repaired_env = finalise(*finetune.build_train_command(
    WORK_TOML, repo=REPO, nproc=1, overrides=repaired,
    output_root=TRAIN_OUT, master_port=50012))
print("$ " + " ".join(repaired_argv))
''')

nb.md("""
### Verification

Re-running and not crashing is weak evidence, because the batch that killed you
may simply not have come up again. Verify properly:

1. **Run at least twice the iterations that reached the OOM**, and preferably
   past one full pass over the dataset, so the worst batch has had a chance to
   appear.
2. **Record peak memory** and check the headroom is more than a couple of GB.
   Peak *allocated* is not peak *reserved*; treat anything under about 5 GB of
   headroom as none.
3. **Check the loss is still finite and moving.** `force_finite = true` will
   happily convert a NaN into a zero gradient and keep going, so a run that no
   longer crashes but has stopped learning looks identical to a healthy one from
   the exit code.
4. **Confirm the override actually applied.** Grep the resolved config that the
   trainer writes to `$RUN_DIR/config.yaml` for the token cap. If your `--`
   separator was missing, the value there will be 45056 and you will have
   "fixed" nothing.
""")

nb.code('''
def verify_run(run_dir, watch, *, expect_token_cap, min_headroom_gb=5.0):
    """Four checks. Passing all four is weak evidence; failing one is strong."""
    results = []
    cfg = run_dir / "config.yaml"
    if cfg.exists():
        blob = cfg.read_text()
        applied = str(expect_token_cap) in blob
        results.append((applied,
                        f"resolved config mentions token cap {expect_token_cap}"))
    else:
        results.append((None, f"no config.yaml at {cfg} — run has not started"))

    results.append((not watch.oom, "no OOM in the log"))
    if watch.peak_mem_gb:
        head = 80.0 - watch.peak_mem_gb
        results.append((head >= min_headroom_gb,
                        f"headroom {head:.1f} GB >= {min_headroom_gb} GB"))
    else:
        results.append((None, "peak memory not reported"))
    if watch.losses:
        finite = all(l == l and abs(l) < 1e6 for l in watch.losses)
        moving = watch.losses[-1] != watch.losses[0]
        results.append((finite and moving, "loss finite and not constant"))
    else:
        results.append((None, "no loss values parsed"))

    for ok, label in results:
        mark = {True: "pass", False: "FAIL", None: "n/a "}[ok]
        print(f"  [{mark}] {label}")
    return results


_ = verify_run(RUN_DIR, watch, expect_token_cap=TOKEN_CAP)
''')

# ---------------------------------------------------------- export and use
nb.md("""
## Export the result, and use it

A DCP checkpoint is not something you can run inference with. Two steps, both
from `docs/training.md`:

1. Read `$RUN_DIR/checkpoints/latest_checkpoint.txt`, which holds a directory
   name like `iter_000000020`.
2. `export_model` converts that DCP into Hugging Face safetensors at
   `$RUN_DIR/model`, which `--checkpoint-path` accepts directly.

For Cosmos3-Edge the export is **self-contained**: it bundles the SigLIP2 vision
tower into `model/vision_encoder/` and the processor and tokenizer files into
the export root, so inference from it runs offline with no Hub download. Pass
`--no-vit` for a generation-only export that is about 1 GB smaller, and
`--verify` to smoke-test it on this node's GPU before you trust it.
""")

nb.code('''
def export_commands(run_dir):
    latest = run_dir / "checkpoints" / "latest_checkpoint.txt"
    if not latest.exists():
        return None, (f"no checkpoint yet at {latest}.\\n"
                      "  Either the run has not happened, or save_iter is larger\\n"
                      "  than max_iter and nothing was ever written. Check both.")
    iter_name = latest.read_text().strip()
    ckpt = run_dir / "checkpoints" / iter_name
    size_gb = sum(f.stat().st_size for f in ckpt.rglob("*") if f.is_file()) / 1e9
    cmd = ["python", "-m", "cosmos_framework.scripts.export_model",
           "--checkpoint-path", str(ckpt),
           "--config-file", str(run_dir / "config.yaml"),
           "-o", str(run_dir / "model")]
    return cmd, (f"checkpoint {iter_name} is {size_gb:.1f} GB on disk.\\n"
                 "  That is weights PLUS optimizer state PLUS scheduler and RNG\\n"
                 "  state -- which is why a DCP checkpoint is several times the\\n"
                 "  size of the exported safetensors.")


cmd, note = export_commands(RUN_DIR)
print(note)
if cmd:
    print()
    print("$ " + " ".join(cmd))
''')

nb.code('''
# Gated: exporting needs a completed run. Then compare base against fine-tuned
# at a FIXED prompt and a FIXED seed -- the only comparison that means anything.
from cosmos_course.specs import InferenceSpec

COMPARISON_PROMPT = (
    "A robotic arm on a wooden countertop picks up a small metal object and "
    "moves it to the left, static camera, bright even indoor lighting."
)
COMPARISON_SEED = 0

compare_spec = InferenceSpec(
    model_mode="text2video", name="ft_compare",
    prompt=COMPARISON_PROMPT, resolution="256", aspect_ratio="1,1",
    num_frames=61, fps=5, seed=COMPARISON_SEED,
)

if RUN_TRAINING and cmd and (RUN_DIR / "model").exists():
    from cosmos_course.models import Generator
    for label, ckpt in (("base", "Cosmos3-Edge"),
                        ("finetuned", str(RUN_DIR / "model"))):
        gen = Generator(repo=REPO, checkpoint=ckpt)
        res = gen.run(compare_spec, OUTPUT_DIR / f"compare_{label}",
                      seed=COMPARISON_SEED)
        for check in cc.verify_result(res):
            print(f"  {label:<10s} {check}")
else:
    print("skipped — needs a completed run and an export.")
    print()
    print("The comparison, when you do run it:")
    print(f"  prompt : {COMPARISON_PROMPT}")
    print(f"  seed   : {COMPARISON_SEED}   (fixed, both runs)")
    print("  models : Cosmos3-Edge  vs  $RUN_DIR/model")
    print()
    print("One prompt at one seed is an anecdote, not evidence. Lesson 18 turns")
    print("it into something you could defend.")
''', tags=["expensive"])

nb.callout(
    "warning",
    "Everything in this lesson from the overrides onward is **undocumented and "
    "unvalidated by NVIDIA**. The shipped recipe is 8 GPUs; the smallest published "
    "claim is 4. The course's position is that the arithmetic makes 1 plausible "
    "for this specific recipe with these specific overrides, that plausible is not "
    "proven, and that you should write down what actually happened on your card. "
    "If it OOMed, that is a result. Report it with the setting that caused it and "
    "you have completed the lesson.",
)

# ------------------------------------------------------------ exercises
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "Run the smoke configuration and report it",
    goal=(
        "Execute the 20-iteration configuration, or document precisely why you "
        "could not, and produce a loss curve and a peak-memory figure."
    ),
    instructions=(
        "1. Confirm the GPU is empty and record what `nvidia-smi` said.\n"
        "2. Set `COSMOS_COURSE_ALLOW_SFT_DOWNLOAD=1`, restart the kernel, and run "
        "   Step 1 and Step 2. Record how long each took and how much disk each "
        "   consumed.\n"
        "3. Set `COSMOS_COURSE_RUN_SFT=1`, restart, and run with `MODE=\"reduced\"`.\n"
        "4. Parse the log with `TrainingWatch`, plot loss and learning rate, and "
        "   report peak memory.\n"
        "5. Write `outputs/17/training_report.md` with: your prediction (quoted "
        "   from `prediction.json`, unedited), the overrides you used, what "
        "   happened, the measured peak, and one paragraph on whether the "
        "   prediction was right and why.\n\n"
        "If it OOMed, the report says so, names the setting, and quotes the "
        "traceback. That is a complete answer."
    ),
    success=(
        "`training_report.md` exists and contains a prediction made before the "
        "run, the exact command that ran, and either a loss curve or a traceback "
        "with a named cause. Someone else could reproduce your run from it."
    ),
    starter='''
REPORT = OUTPUT_DIR / "training_report.md"

def write_report(watch, prediction, overrides, returncode, *, extra=""):
    """Assemble the report. Facts only; interpretation goes in `extra`."""
    lines = [
        "# Lesson 17 — single-GPU SFT attempt",
        "",
        "**This configuration is undocumented by NVIDIA.** It is an experiment.",
        "",
        "## Prediction (recorded before the run)",
        "```json", json.dumps(prediction, indent=2), "```",
        "",
        "## Configuration",
        "```", *[f"{k}={v}" for k, v in overrides.items()], "```",
        "",
        "## Outcome",
        f"- exit code: {returncode}",
        f"- iterations parsed: {len(watch.iters)}",
        f"- OOM: {watch.oom}",
        f"- peak memory: {watch.peak_mem_gb}",
    ]
    # TODO: add the loss curve numbers, the wall-clock, and your paragraph.
    lines += ["", "## Interpretation", extra or "TODO"]
    REPORT.write_text("\\n".join(lines))
    return REPORT

# TODO: call it once you have a run (or a documented failure) to report.
''',
    hints=[
        "If the run dies before iteration 1 with an OmegaConf interpolation error "
        "naming `BASE_CHECKPOINT_PATH` or `WAN_VAE_PATH`, you launched without the "
        "environment variables — raw `torchrun` does not resolve them, only the "
        "launch shell does. `finalise()` in this notebook adds them.\n\n"
        "If it dies complaining about unrecognised arguments, the `--` separator "
        "is missing. If it runs but `config.yaml` shows a token cap of 45056, the "
        "separator was missing *and* the overrides were silently dropped, which is "
        "the worse failure because it looks like success.",
    ],
    solution_ref="solutions/17_solutions.ipynb",
)

nb.exercise(
    "applied",
    "Find the token-cap frontier by bisection",
    goal=(
        "Determine the largest `max_num_tokens_after_packing` that completes a "
        "short run on your card, and report the frontier with its uncertainty."
    ),
    instructions=(
        "Bisect between a cap you know works and one you know fails. Rules that "
        "make the result mean something:\n\n"
        "1. **Hold everything else fixed.** Same `max_iter`, same seed, same "
        "   dataset, EMA and compile off throughout.\n"
        "2. **Adjust `grad_accum_iter` inversely** so the global batch stays "
        "   roughly constant, and say what you did.\n"
        "3. **Run enough iterations that the worst batch appears.** The OOM at "
        "   iteration 3 in the debugging lab exists because packed batches vary. "
        "   A cap that survives 5 iterations is not a cap that survives 500.\n"
        "4. **Record peak memory at every point**, not just pass/fail. The "
        "   peak-versus-cap curve is the useful artefact, and its slope predicts "
        "   the frontier better than the bisection does.\n"
        "5. **Report the frontier as an interval**, not a number: the largest cap "
        "   that passed and the smallest that failed."
    ),
    success=(
        "You have a table of (token cap, grad accum, iterations survived, peak "
        "memory, outcome) with at least five rows, a plotted peak-versus-cap "
        "curve, and a stated interval. You can say how much headroom you would "
        "leave for a 500-iteration run and justify the margin."
    ),
    starter='''
FRONTIER = OUTPUT_DIR / "frontier.jsonl"

def attempt(token_cap, grad_accum, max_iter=20):
    """One bisection step. Returns a record; appends it to FRONTIER."""
    ov = finetune.single_gpu_overrides(
        token_cap=token_cap, grad_accum=grad_accum,
        max_iter=max_iter, save_iter=max_iter * 10)   # never save while probing
    a, e = finalise(*finetune.build_train_command(
        WORK_TOML, repo=REPO, nproc=1, overrides=ov,
        output_root=TRAIN_OUT, master_port=50012))
    log = OUTPUT_DIR / f"probe_{token_cap}.log"
    # TODO: run it, parse it, and return
    #   {"token_cap":..., "grad_accum":..., "iters":..., "peak_gb":...,
    #    "oom":..., "seconds":...}
    raise NotImplementedError

# TODO: bisect. Start from a cap that worked and one that failed.
# TODO: plot peak memory against token cap and fit a line through it.
# TODO: report the interval and the margin you would leave.
''',
    hints=[
        "Set `save_iter` far larger than `max_iter` while probing. Otherwise every "
        "failed attempt writes a 20–40 GB checkpoint and you fill the disk halfway "
        "through the bisection.\n\n"
        "The peak-versus-cap relationship is close to linear at fixed batch "
        "composition but is not exactly linear, because the packer fits a "
        "different number of samples at each cap and attention cost is quadratic "
        "in sequence length within a sample. Fit the line, then verify the "
        "extrapolation rather than trusting it.",
    ],
    solution_ref="solutions/17_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "Base versus fine-tuned, argued properly",
    goal=(
        "Run both models over a held-out prompt set at fixed seeds and make a "
        "defensible argument about whether the fine-tune helped — including an "
        "explicit statement of what your evidence cannot establish."
    ),
    instructions=(
        "1. **Build a held-out prompt set.** At least eight prompts, none of them "
        "   drawn from the training captions. Say how you ensured that.\n"
        "2. **Fix the seeds.** Run every prompt at the same seed for both models, "
        "   then run a subset at three additional seeds so you can estimate seed "
        "   variance.\n"
        "3. **Verify every output** with `cc.verify_result` before you look at "
        "   any of them. A blank frame that passes your eye test is worse than "
        "   one that fails a check.\n"
        "4. **Compare.** Choose your comparison method and state its bias — "
        "   side-by-side viewing, a frame-difference statistic, a reasoner-as-judge "
        "   score, whatever you can defend.\n"
        "5. **Write the argument.** State the claim, the method, the sample size, "
        "   the confounds, and — this is the part that is actually hard — a list "
        "   of things your evidence does not support.\n\n"
        "You should expect to find no detectable difference after 20 or 100 "
        "iterations at a reduced global batch. **That is a real result and it is "
        "the one to report** if it is what you got."
    ),
    success=(
        "A written argument with a stated claim, a sample size, a seed-variance "
        "estimate, and a limitations section naming at least three things you "
        "cannot conclude. If you claim an improvement, you have shown it exceeds "
        "seed variance. If you cannot, you say so plainly."
    ),
    starter='''
HELD_OUT = [
    # Eight prompts you wrote, none from the training captions. Vary what you
    # are probing: in-domain (robot manipulation), near-domain (a human hand
    # doing the same task), out-of-domain (a landscape).
    "A robotic gripper lifts a red cube from a white tray, static camera.",
    # TODO: seven more, with a note on which category each belongs to.
]
SEEDS = [0, 1, 2, 3]

def sweep(checkpoint, prompts, seeds, out_dir):
    """Generate every (prompt, seed) pair and verify each output."""
    # TODO: build an InferenceSpec per pair, run it, verify_result it,
    # and record {"checkpoint","prompt_index","seed","path","checks"}.
    raise NotImplementedError

# TODO: sweep base, sweep fine-tuned, compare, estimate seed variance,
# and write outputs/17/comparison.md.
''',
    hints=[
        "The cheapest defensible comparison is paired: for each (prompt, seed), "
        "you have exactly one base output and one fine-tuned output produced under "
        "identical conditions. Paired comparisons need far fewer samples than "
        "unpaired ones because the prompt and seed effects cancel.\n\n"
        "For 'what the evidence cannot establish', start here: it cannot "
        "establish that the fine-tune generalises beyond your eight prompts; it "
        "cannot separate a real improvement from your knowing which video is "
        "which; and it cannot tell you whether a longer run would have helped, "
        "because you only ran one length.",
    ],
    solution_ref="solutions/17_solutions.ipynb",
)

# ------------------------------------------------------------ assessment
nb.md("""
## Assessment

### Knowledge check

1. A run OOMs during checkpoint loading, before iteration 1. Which rungs of the
   ladder are relevant and which are certainly not?
2. `activation_checkpointing.mode` is already `"full"` in this recipe. What does
   that tell you about the FAQ's rung 2 as a response to an OOM here?
3. You halve `max_num_tokens_after_packing` and change nothing else. What
   happens to the effective global batch, and why does that matter for
   interpreting the loss curve?
4. Why does `compile.enabled = true` in a recipe whose schema default is
   `false`, and why do you turn it off?
5. The degree-product invariant is satisfied trivially at world size 1. Name a
   configuration where it is not trivial and the two documented readings
   disagree.
6. Your run completes 20 iterations and the loss falls from 0.41 to 0.37. What
   have you established, and what have you not?
""")

nb.code('''
# Write your answers here first, in your own words, and run the cell. An answer
# you have committed to is worth several times one you nod along with.
MY_ANSWERS = {
    1: "",   # OOM during checkpoint load: which rungs are relevant, which are not
    2: "",   # activation checkpointing already "full": what does rung 2 buy here?
    3: "",   # halve the token cap alone: what happens to the global batch?
    4: "",   # compile.enabled = true against a schema default of false
    5: "",   # a configuration where the two invariant readings disagree
    6: "",   # loss 0.41 -> 0.37 over 20 iterations: shown, and not shown
}

answered = [k for k, v in MY_ANSWERS.items() if v.strip()]
answers_path = OUTPUT_DIR / "knowledge_check.json"
answers_path.write_text(json.dumps(MY_ANSWERS, indent=2))

print(f"answered {len(answered)} of {len(MY_ANSWERS)}"
      f"  ->  {answers_path.relative_to(COURSE_ROOT)}")
if len(answered) < len(MY_ANSWERS):
    print("Fill in the blanks and re-run before you open the answers below.")
''')

nb.answer("""
1. **State rungs are relevant; activation rungs are not.** Failing before
   iteration 1 means the optimizer state did not fit — activations do not exist
   yet. So: `keys_to_select`, LoRA, disabling EMA, or more GPUs. Cutting the
   token cap will change nothing at all, and a lot of people spend an hour on it.

2. **It tells you rung 2 is already spent.** Turning on something that is
   already on buys nothing. Verify the resolved config rather than the TOML —
   an override could have changed it — but do not expect a saving.

3. Effective global batch **falls with the token cap**, because the packer fits
   fewer samples per micro-batch. You have changed the optimisation problem, not
   just the memory. A loss curve from a smaller global batch is noisier and not
   directly comparable to the shipped recipe's. Compensate with
   `grad_accum_iter` and say what you did.

4. `torch.compile` is a throughput optimisation, and the Edge recipe is the one
   most likely to be run on a small allocation where throughput matters. You
   turn it off because it costs memory during tracing, adds minutes to every
   startup while you are debugging, and is a common first-run failure on shapes
   nobody has compiled. You are optimising for "fits" and "fast iteration", not
   for steady-state speed.

5. `vision_sft_super.toml` on 8 GPUs: shard `-1`, replicate `1`,
   `context_parallel_shard_degree = 2`. Under `docs/sft_config.md`'s four-factor
   rule, shard auto-resolves to 4. Under `docs/faq.md`'s two-factor rule it
   resolves to 8. Read `parallelism.py`.

6. You have established that **the pipeline works**: the checkpoint loaded, the
   dataset produced batches, gradients flowed, the optimizer stepped, and memory
   held. That is genuinely worth knowing and it is the whole point of a smoke
   run. You have **not** established that the model is better at anything — at
   iteration 20 the learning rate is still climbing through a 50-step warmup
   from zero, the global batch is a fraction of the shipped one, and a falling
   training loss is not a claim about held-out behaviour. Lesson 18 is about
   that gap.
""")

nb.code('''
# ---------------------------------------------------------------------------
# What outputs/17 holds, and the numbers this lesson turned on. Read back from
# disk or recomputed, so the summary below is checkable rather than trusted.
# ---------------------------------------------------------------------------
ARTEFACTS = {
    "prediction.json":      "written before the run, and not edited after",
    "vision_sft_edge.toml": "the recipe you worked from",
    LOG_PATH.name:          "the log from your own run",
    "training_report.md":   "the report (foundation exercise)",
}
for rel, what in ARTEFACTS.items():
    path = OUTPUT_DIR / rel
    print(f"  [{'ok     ' if path.exists() else 'MISSING'}] {rel:<26s} {what}")

print()
print(f"token cap    shipped {shipped_cap:>7d}   ours {TOKEN_CAP:>7d}")
print(f"grad accum   shipped {shipped_accum:>7d}   ours {GRAD_ACCUM:>7d}")
print(f"max_iter     shipped {field('trainer.max_iter'):>7d}   ours {MAX_ITER:>7d}")
print(f"predicted state      {est.state_gb:>7.1f} GB")
print(f"activation budget    {est.activation_budget_gb:>7.1f} GB")
print(f"warmup               {warm:>7d} steps, i.e. {min(MAX_ITER / warm, 1.0):.0%} "
      f"of it covered by this run")
''')

nb.md("""
### Practical completion test

You have finished when `outputs/17/` contains:

- `prediction.json`, written before the run and not edited after;
- the exact command that ran, environment variables included;
- a training log, and either a loss curve or a traceback;
- `training_report.md` that someone else could reproduce your run from.

**A failed run with a precise account of why is a pass.** A successful run with
no prediction to compare it against is not.

### Summary

- The shipped recipe encodes its machine. `max_num_tokens_after_packing`,
  `grad_accum_iter`, `ema.enabled` and `compile.enabled` were all chosen with
  eight ranks in mind.
- **Predict before you run**, in writing, on disk. The estimator predicts state;
  the gap between state and measured peak is your first real activation number.
- The available levers are `expandable_segments`, activation checkpointing
  (already on here), the token cap paired with grad accumulation, and LoRA.
  Shard degree, context-parallel degree, CPU offload and 8-bit optimizers are
  not available at any setting.
- **Diagnose an OOM by where it happened.** Before iteration 1 is state; inside
  `training_step` is activations. That one observation halves the search.
- Packed batches vary, so **the peak is set by the worst batch**, not the first.
  Surviving five iterations proves very little.
- `build_train_command` omits the Hydra `--` separator and the three required
  environment variables. Verify the resolved `config.yaml`, because overrides
  that were silently dropped look exactly like overrides that were applied.
- A DCP checkpoint carries optimizer state and is several times the size of the
  exported safetensors. `export_model` produces a self-contained directory for
  Edge, vision tower included.
- **This configuration is undocumented and unvalidated by NVIDIA.** Report what
  happened on your card, not what you hoped would happen.
""")

nb.code('''
# The claim that "where it failed" halves the search, tested on two logs. Same
# classifier, one failure before iteration 1 and one at iteration 3.
LOAD_TIME_OOM = """[INFO] loading checkpoint from examples/checkpoints/Cosmos3-Edge
[INFO] building the fused AdamW optimizer over 1.94B trainable parameters
torch.OutOfMemoryError: CUDA out of memory. Tried to allocate 7.24 GiB.
GPU 0 has a total capacity of 79.15 GiB of which 0.88 GiB is free.
Of the allocated memory 71.30 GiB is allocated by PyTorch, and 0.42 GiB
is reserved by PyTorch but unallocated.
"""

print("A: died while building the optimizer")
for line in diagnose_oom(LOAD_TIME_OOM):
    print("   -", line)

print()
print("B: died at iteration 3 (the debugging lab above)")
for line in diagnose_oom(oom_log.read_text()):
    print("   -", line)

print()
print("Same tool, opposite verdicts, opposite repairs. A cuts trainable")
print("parameters; B cuts the token cap. Neither fix helps the other case.")
''')

nb.md("""
### Common misconceptions

| Belief | Correction |
|---|---|
| "Set `nproc_per_node=1` and it is a single-GPU recipe" | Four other settings encode the eight-GPU assumption, and one of them (`grad_accum_iter`) changes the optimisation problem rather than the memory. |
| "Turn on gradient checkpointing when you OOM" | It is already `full` here, and it does nothing for a state OOM regardless. |
| "It survived 20 iterations, so the config is safe" | The packer's worst batch may not have appeared. Run past a full pass before believing it. |
| "The loss fell, so the fine-tune worked" | At iteration 20 you are still in warmup on a reduced global batch. It shows gradients flow. |
| "`expandable_segments` fixes OOM" | Only fragmentation OOM. If reserved-minus-allocated is small, the memory is genuinely in use. |
| "LoRA is just a smaller version of the same fine-tune" | Different modules are trained. The default targets are four attention projections; `keys_to_select` also trains `vae2llm` and `llm2vae`. |
| "The command printed, so the overrides applied" | Without the `--` separator they may be dropped. Grep `$RUN_DIR/config.yaml`. |

### Suggested extensions

- Sample `nvidia-smi` from a second process at 1 Hz through a whole run and plot
  memory against iteration. The shape tells you which phase is the peak —
  loading, first forward, or steady state — and that is the thing your estimator
  cannot model.
- Run the same smoke configuration twice with the same seed and diff the loss
  curves. Anything that differs is non-determinism you have not accounted for,
  and `preserve_rng_state` under activation checkpointing is the first place to
  look.
- Try `MODE="full"` overnight with a token cap two-thirds of your frontier, and
  see whether 100 iterations produces anything Lesson 18 can detect. Be prepared
  for the answer to be no.
""")

nb.code('''
# Objective 10, made mechanical: what your evidence supports, computed from what
# is actually on disk rather than from how the run felt.
report_path = OUTPUT_DIR / "training_report.md"
own_run = watch_path == LOG_PATH          # not the synthetic example
EVIDENCE = [
    (pred_path.exists(), "a prediction recorded before the run"),
    (own_run, "a log from your own run rather than the synthetic example"),
    (own_run and bool(watch.iters), "iterations parsed out of your own log"),
    (own_run and watch.peak_mem_gb is not None, "a measured peak-memory figure"),
    (report_path.exists(), "a written report"),
]
for ok, label in EVIDENCE:
    print(f"  [{'yes' if ok else 'no '}] {label}")

print()
print("Claims this evidence cannot support, however the run went:")
for claim in ("that the fine-tune improved anything a viewer would notice",
              "that the configuration is safe for a 500-iteration run",
              "that another card, dataset or seed would behave the same"):
    print(f"  - {claim}")
''')

nb.md("""
### Mastery checklist

- [ ] I can explain every field in `vision_sft_edge.toml`.
- [ ] I wrote a prediction to disk before running anything.
- [ ] I can name each override and the rung of the ladder it comes from.
- [ ] I know which two rungs need hardware I do not have, and why.
- [ ] I found the two things `build_train_command` leaves out.
- [ ] I ran the smoke configuration, or documented exactly what stopped me.
- [ ] I reconciled measured peak memory against predicted state.
- [ ] I can classify an OOM as state or activation from the traceback alone.
- [ ] I can state, without hedging, what a 20-iteration loss drop does not show.
- [ ] My report is honest about this being an unvalidated configuration.

Lesson 18 asks whether it actually got better — in a repository that ships no
way to ask.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "17_posttraining_one_gpu.ipynb")
