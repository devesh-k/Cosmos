"""Build 13_action_closed_loop.ipynb.

The source DLI course `S-OV-57-V1`, notebook 04, spends five sentences (cell 25)
saying closed-loop control exists and is out of scope. This lesson expands that
into a real lesson: what closed-loop control is, what the architecture actually
is, what genuinely runs on one H100, and what does not and why.

Everything quoted here was read out of upstream `main` in August 2026 rather
than paraphrased:

`docs/action_policy_libero_posttrain.md`
  * server: `python -m cosmos_framework.scripts.action_policy_server_libero
    --experiment action_policy_libero_nano --checkpoint-path <trained DCP>
    --action-normalization quantile_rot --action-stats-path ...
    --raw-action-dim 10 --fps 20 --port 8000`
  * "Start the policy server on a **trained** checkpoint (the base DCP has no
    action heads)"
  * client venv: `uv venv --python 3.10 .libenv`, LIBERO checkout,
    `robosuite==1.4.1`, `mujoco==2.3.7`, `torch<2.6`
  * eval: `cosmos_framework/simulation/libero/closed_loop_eval.py --server_url
    ... --task_suite libero_10 --num_trials_per_task 50 --num_envs 8 --camera
    agentview,wrist --image_size 256 --action_space frame_wise_relative
    --rotation_space 6d --action_dim 10`
  * the four "Eval parity" items, verbatim in substance: concat layout, gripper
    `1 - 2g`, sim frames rotated 180 degrees vs training, and
    `--action-normalization quantile_rot`

`docs/action_policy_droid_server.md`
  * `python -m cosmos_framework.scripts.action_policy_server_robolab --port 8000`
    (defaults to Cosmos3-Nano-Policy-DROID)
  * Edge variant adds `--checkpoint-path nvidia/Cosmos3-Edge-Policy-DROID
    --format-prompt-as-json True --guidance-interval 960 1001`
  * needs `--group=policy-server`

`cosmos_framework/scripts/action_policy_server_libero.py` module docstring and
handler:
  * `POST /predict` in: {"image": "<base64_png>", "prompt": "<task>",
    "domain_name": "<name>", "image_size": <int>}
  * out: {"action": [[...]], "video": ["<base64_png>", ...]}
  * `GET /` -> {"status": "ok"};  `GET /info` -> runtime info;  404 otherwise
  * POST paths: "/", "/predict", "/predict_batch"; non-JSON content type -> 415
  * `http_400_on_error` defaults False: "Default is HTTP 200 with an empty
    action list, matching the legacy simulator client expectations."

`cosmos_framework/scripts/action_policy_server_robolab.py`
  * openpi `WebsocketPolicyServer`; `ws://host:port/` with an HTTP health check
    at `http://host:port/healthz`

The hands-on core is a faithful mock of the LIBERO HTTP schema, which runs with
no GPU and no checkpoint, plus an opt-in start of the real RoboLab server.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 13 — Closed-loop control")

# --------------------------------------------------------------- title block
nb.md("""
# Lesson 13 — Closed-loop control

**What you will build.** `outputs/13/` containing a working policy-server client
you wrote against the documented HTTP schema, a measured compounding-error
simulation, a parity checklist, and `closed_loop_notes.md` — your written
account of what ran on this machine, what did not, and the specific constraint
that stopped each thing.

| | |
|---|---|
| **Time** | ~90 minutes |
| **GPU** | Most of this lesson needs none. One opt-in section uses the H100. |
| **Downloads** | None by default. `Cosmos3-Edge-Policy-DROID` (~9 GB) is opt-in. |
| **Prerequisites** | Lesson 12. Lesson 02's second-venv experience transfers directly. |

Lesson 12 ended with an unsatisfying result: one observation in, sixteen actions
out, execute all sixteen, hope. This lesson explains the fix, shows you the real
architecture that implements it, and is honest about which parts of it fit on
one machine in a classroom.

Some of what follows you will read rather than run. That is stated plainly each
time, with the specific reason. A course that pretends a two-machine system fits
on one machine is not doing you a favour.
""")

# ---------------------------------------------------------------- objectives
nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Explain** closed-loop control as re-querying a policy every chunk against a
   stepped environment, and **derive** why feedback bounds an error that open
   loop lets grow.
2. **Measure** how open-loop error grows with horizon, and **relate** the result
   to your Lesson 11 round-trip and Lesson 12 rollout.
3. **Describe** the server/client architecture, name both shipped policy
   servers, and state the real command line for each.
4. **Explain** the dependency conflict that forces two virtualenvs, and
   **demonstrate** it from the versions installed on your own machine.
5. **Start** a policy server and **query** it with a hand-made HTTP request,
   documenting its request and response schema from the wire rather than from
   prose.
6. **Diagnose** train/serve skew by working through four documented parity
   gotchas, and **explain** what each one is a symptom of.
7. **State** which parts of this lesson you ran and which you read, with the
   constraint that stopped each.
""")

# ------------------------------------------------- conceptual foundation (1)
nb.md("""
## Closed-loop control

Open loop, which is what Lesson 12 did:

```
   observe once  ->  policy  ->  a_0 ... a_15  ->  execute all 16  ->  stop
```

Closed loop:

```
        +-------------------------------------------------------+
        |                                                       |
        v                                                       |
   observe  ->  policy  ->  a_0 ... a_k  ->  execute k steps  ---+
                                              (then observe again)
```

The loop is the entire difference. Every `k` steps the controller throws away
whatever remained of its plan, looks at the world as it actually is, and asks
again.

### Why feedback bounds the error

Suppose each predicted action carries a small systematic bias `b` — the model
consistently under-turns, or under-reaches, by a fixed amount. Under open loop
those biases accumulate across the whole horizon:

```
   open loop, N steps:      error  ~  N * b
```

Under closed loop, each re-observation resets the accumulation, because the new
observation reflects where the system *actually* is rather than where the plan
assumed it would be. Error accumulates only within one chunk:

```
   closed loop, chunk k:    error  ~  k * b        regardless of how long you run
```

That is the whole argument, and it is worth noticing what it is *not*. It is not
"closed loop is more accurate". It is that open-loop error grows without bound
in the horizon while closed-loop error is bounded by the chunk length. A model
with `b = 0` needs no feedback; every real model has `b > 0`.

Random error behaves differently and is worth separating. Zero-mean noise of
scale `σ` accumulates as a random walk, so open-loop error from noise grows like
`σ√N` rather than `σN`. Slower, still unbounded. You will simulate both and see
which dominates at which horizon.

### And the two things feedback fixes that bias alone does not explain

**Disturbance.** Someone moves the pot. An open-loop plan continues executing a
sequence computed for a world that no longer exists. No amount of model quality
helps, because the model was never wrong — the world changed.

**Its own mistakes.** If action 3 lands the gripper two centimetres off, actions
4 through 16 were computed for the intended pose. Every later action is applied
from the wrong starting point. Closed loop notices at the next observation;
open loop cannot notice at all, because noticing requires looking.
""")

# ------------------------------------------------- conceptual foundation (2)
nb.md("""
## The architecture

Closed-loop evaluation is two processes, and the split is not arbitrary.

```
   +--------------------------+            +-----------------------------+
   |  POLICY SERVER           |            |  SIMULATOR CLIENT           |
   |                          |  obs ->    |                             |
   |  Cosmos3 policy weights  |            |  MuJoCo / robosuite / LIBERO|
   |  on the GPU              |  <- action |  or Isaac Sim via RoboLab   |
   |                          |            |                             |
   |  framework venv          |            |  a DIFFERENT venv           |
   |  torch >= 2.6, CUDA 13   |            |  torch < 2.6, mujoco 2.3.7  |
   +--------------------------+            +-----------------------------+
```

The server holds the model and answers "given this observation and this
instruction, what should I do". The client owns the world: it steps the
simulator, renders observations, sends them, receives an action chunk, applies
it, and repeats. The loop lives in the client.

Upstream ships two servers, for two different simulators:

| Script | Simulator | Transport | Checkpoint |
|---|---|---|---|
| `cosmos_framework.scripts.action_policy_server_libero` | LIBERO (robosuite + MuJoCo) | plain **HTTP**, JSON | one you post-trained yourself |
| `cosmos_framework.scripts.action_policy_server_robolab` | RoboLab (Isaac Sim 5.0 + Isaac Lab 2.2.0) | **WebSocket**, with an HTTP `/healthz` | `Cosmos3-{Nano,Edge}-Policy-DROID` |

Those transports matter for what you can do by hand. The LIBERO server speaks
ordinary JSON over HTTP, so you can talk to it with `urllib` and read the schema
off the wire. The RoboLab server speaks msgpack over a WebSocket, so a hand-made
request is not a one-liner — but its health endpoint is plain HTTP and that is
enough to prove the process is alive and holding weights.
""")

# ------------------------------------------------------------- environment
nb.md("""
## Environment

No model download by default. This cell and the next establish what your machine
has, so that later sections can say precisely why something will or will not run
here.
""")

nb.code('__lesson__ = "13"   # OUTPUT_DIR resolves to outputs/13\n\n' + SETUP_CELL)

nb.code('''
import json
import shutil
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request

import numpy as np

from cosmos_course.models import Generator

gen = Generator(checkpoint="Cosmos3-Edge")   # only used to locate the venv
framework_problems = gen.check(verbose=False)

print(f"framework repo   : {gen.repo}")
print(f"framework python : {gen.python}")
print(f"usable           : {not framework_problems}")
for problem in framework_problems:
    print(f"    ! {problem}")

SERVER_SCRIPTS = {
    "libero": gen.repo / "cosmos_framework" / "scripts" / "action_policy_server_libero.py",
    "robolab": gen.repo / "cosmos_framework" / "scripts" / "action_policy_server_robolab.py",
}
EVAL_SCRIPT = gen.repo / "cosmos_framework" / "simulation" / "libero" / "closed_loop_eval.py"

print()
print("shipped closed-loop pieces in your checkout:")
for name, path in {**SERVER_SCRIPTS, "closed_loop_eval": EVAL_SCRIPT}.items():
    print(f"    {name:<18} {'present' if path.exists() else 'MISSING'}   {path.name}")
print()
print(f"uv on PATH       : {shutil.which('uv') is not None}")
print("ports            : assigned by the OS on demand, never hard-coded")
''')

nb.md("""
### The real commands

These are upstream's, from `docs/action_policy_libero_posttrain.md` §3 and
`docs/action_policy_droid_server.md`, with the placeholders left visible so you
can see which parts are yours to supply. Read them; they are the specification
for everything that follows.

One placeholder needs a word of explanation before you meet it. `<trained DCP
dir>` is where *your* post-trained checkpoint would live. **DCP** is PyTorch's
Distributed Checkpoint format — a directory of shards rather than a single file,
which is what the trainer writes. You do not have one yet; producing it is
Lesson 17's job, and Lesson 16 explains the format and why it is not
interchangeable with Hugging Face safetensors.
""")

nb.code('''
LIBERO_SERVER_CMD = """\\
python -m cosmos_framework.scripts.action_policy_server_libero \\\\
  --experiment action_policy_libero_nano \\\\
  --experiment-overrides "model.config.tokenizer.vae_path=$WAN_VAE_PATH" \\\\
  --checkpoint-path <trained DCP dir>/checkpoints/iter_000001500 \\\\
  --action-normalization quantile_rot \\\\
  --action-stats-path cosmos_framework/data/generator/action/normalizer_stats/\\
libero_native_frame_wise_relative_rot6d.json \\\\
  --raw-action-dim 10 --fps 20 --port 8000"""

ROBOLAB_SERVER_CMD = """\\
python -m cosmos_framework.scripts.action_policy_server_robolab \\\\
  --port 8000
      # defaults to nvidia/Cosmos3-Nano-Policy-DROID

python -m cosmos_framework.scripts.action_policy_server_robolab \\\\
  --checkpoint-path nvidia/Cosmos3-Edge-Policy-DROID \\\\
  --port 8000 \\\\
  --format-prompt-as-json True \\\\
  --guidance-interval 960 1001"""

LIBERO_EVAL_CMD = """\\
MUJOCO_GL=egl PYTHONPATH=$PWD:$PWD/LIBERO $VV \\\\
  cosmos_framework/simulation/libero/closed_loop_eval.py \\\\
  --server_url http://localhost:8000 \\\\
  --task_suite libero_10 --num_trials_per_task 50 --num_envs 8 \\\\
  --camera agentview,wrist --image_size 256 \\\\
  --action_space frame_wise_relative --rotation_space 6d --action_dim 10 \\\\
  --output_dir results/libero_closed_loop_10"""

print("LIBERO policy server:\\n")
print(LIBERO_SERVER_CMD)
print("\\n\\nRoboLab policy server:\\n")
print(ROBOLAB_SERVER_CMD)
print("\\n\\nLIBERO closed-loop eval client (SECOND venv, $VV):\\n")
print(LIBERO_EVAL_CMD)

(OUTPUT_DIR / "commands.txt").write_text(
    f"{LIBERO_SERVER_CMD}\\n\\n{ROBOLAB_SERVER_CMD}\\n\\n{LIBERO_EVAL_CMD}\\n"
)
''')

# ---------------------------------------------------- the dependency conflict
nb.md("""
## Why you cannot just run this: dependency conflict as an engineering problem

The eval client needs `robosuite==1.4.1`, `mujoco==2.3.7`, `torch<2.6` and a
LIBERO checkout. The framework needs a recent torch built against CUDA 13, with
a matching flash-attention build. Those two sets have no common solution.

It is worth being precise about *why*, because "dependency conflict" is usually
said as if it were an inconvenience rather than a constraint.

A Python environment can hold exactly one version of any package. `torch` is a
compiled extension linked against a specific CUDA runtime and a specific ABI, so
"one version" is not a formality. `robosuite==1.4.1` pins an old numpy and an
old torch because its own compiled dependencies were built against them. The
framework pins a new torch because flash-attention-3 for Hopper exists only for
new torch. There is no version of torch that satisfies both. No resolver can
find one, because none exists.

So the choice is not "which pins do I relax". It is architectural:

- **two virtualenvs, two processes, a socket between them** — which is exactly
  why the closed-loop design is a server and a client rather than one script;
- or one environment and a rewrite of one side.

Upstream chose the first, and the HTTP boundary you will use in a moment is a
direct consequence of a dependency conflict. That is worth remembering the next
time you meet one: an unresolvable pin is sometimes telling you where a process
boundary belongs.

Demonstrate it on your own machine rather than believing the paragraph.
""")

nb.code('''
VERSIONS = """
import json
out = {}
for name in ("torch", "numpy", "robosuite", "mujoco"):
    try:
        mod = __import__(name)
        out[name] = getattr(mod, "__version__", "installed, version unknown")
    except Exception:
        out[name] = None
print(json.dumps(out))
"""

def framework_eval(snippet, args=(), *, timeout=300):
    """Run a snippet in the framework venv; return stdout."""
    proc = subprocess.run(
        [str(gen.python), "-c", snippet, *[str(a) for a in args]],
        cwd=str(gen.repo),
        env={**os.environ, "LD_LIBRARY_PATH": "", "PYTHONNOUSERSITE": "1"},
        capture_output=True, text=True, timeout=timeout,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"framework venv failed:\\n{proc.stderr.strip()[-1200:]}")
    return proc.stdout.strip()

CLIENT_PINS = {"robosuite": "1.4.1", "mujoco": "2.3.7", "torch": "<2.6"}

if framework_problems:
    print("framework venv not available; skipping the live comparison.")
    installed = {}
else:
    installed = json.loads(framework_eval(VERSIONS))
    print("installed in the FRAMEWORK venv:")
    for name, version in installed.items():
        print(f"    {name:<12} {version}")

print()
print("required by the LIBERO EVAL CLIENT:")
for name, pin in CLIENT_PINS.items():
    print(f"    {name:<12} {pin}")

torch_version = installed.get("torch")
if torch_version:
    major_minor = tuple(int(x) for x in torch_version.split("+")[0].split(".")[:2])
    conflict = major_minor >= (2, 6)
    print()
    print(f"framework torch {torch_version} vs client requirement torch<2.6")
    print(f"    -> {'CONFLICT. No single venv satisfies both.' if conflict else 'no conflict on this machine - check the other pins too'}")
''')

nb.callout("warning", """
Do not test this by installing the client pins into the framework venv. `uv`
will either refuse — which proves the point and costs you nothing — or, if you
force it, succeed by downgrading torch and leaving you with a framework
installation that imports and then fails at the first flash-attention call. A
half-broken environment is much more expensive to diagnose than a refused
install. Build the second venv somewhere else, as upstream's instructions do
with `uv venv --python 3.10 .libenv`.
""")

# ------------------------------------------------- post-trained checkpoints
nb.md("""
## Post-trained checkpoints, and why the base model cannot be served

There is a hard constraint here that decides what is runnable on this machine.

> "Start the policy server on a **trained** checkpoint (the base DCP has no
> action heads)."
> — `docs/action_policy_libero_posttrain.md` §3

The base `Cosmos3-Nano` you have been using all module *can* run `wam` through
`cosmos_framework.scripts.inference`, because that path uses the generator
towers. The **policy server** wants action heads that only exist after
post-training for a specific embodiment. You cannot serve what is not there.

Two post-trained checkpoints ship publicly, and neither is gated:

| Checkpoint | Params | Download | Server |
|---|---|---|---|
| `nvidia/Cosmos3-Nano-Policy-DROID` | 16B | ~30 GB | `action_policy_server_robolab` (default) |
| `nvidia/Cosmos3-Edge-Policy-DROID` | 4B | ~9 GB | `action_policy_server_robolab --checkpoint-path ...` |

There is no public LIBERO-post-trained checkpoint. So the LIBERO HTTP server —
the one with the schema you can hand-write requests against — needs a checkpoint
**you** produced, which is Module 5's territory. That is not an accident of
packaging; it is why Module 5 exists.

The practical consequence for this lesson: the schema work below runs against a
faithful mock, and the real-server section uses the RoboLab server with the Edge
policy checkpoint, opt-in.
""")

nb.code('''
POLICY_CHECKPOINTS = {
    "nvidia/Cosmos3-Nano-Policy-DROID": 30,
    "nvidia/Cosmos3-Edge-Policy-DROID": 9,
}
for repo, gb in POLICY_CHECKPOINTS.items():
    print(f"{repo}  (~{gb} GB)")
    cc.check_hf_access(repo)
    print()
print("Neither is gated. The only gated repo in the Cosmos 3 stack is")
print("nvidia/Cosmos-Guardrail1, and it is not involved in policy serving.")
''')

# ------------------------------------------------------------ the HTTP schema
nb.md("""
## The HTTP schema, from the source

This is the hands-on core of the lesson. The LIBERO policy server is a plain
`ThreadingHTTPServer`, and its module docstring states the contract:

```
POST /predict
  in : {"image": "<base64_png>", "prompt": "<task>",
        "domain_name": "<name>", "image_size": <int>}
  out: {"action": [[a0, a1, ...], ...], "video": ["<base64_png>", ...]}

GET  /info    model / runtime info (run_name, checkpoint, sampling params, ...)
GET  /        {"status": "ok"}
```

Reading the handler rather than the docstring adds four things the docstring
does not say, and every one of them will bite someone:

1. `POST` is accepted on `/`, `/predict` **and** `/predict_batch`. Any other
   path is a 404.
2. A `Content-Type` that is not `application/json` gets a **415**, not a 400.
3. `/predict_batch` returns `{"actions": [...]}` — plural, different key.
4. **An inference error returns HTTP 200** with `{"action": [], "error": ...}`.
   The server has an `--http-400-on-error` flag, and it defaults to *off*
   because the legacy simulator client expected 200. So the status code is not
   a success signal — which is the same lesson `verify_result` has been teaching
   you all course, arriving from a completely different direction.

You are going to build a client against that contract. To test it without a
post-trained checkpoint, the next cell implements a server that follows the same
contract exactly and returns synthetic actions. It needs no GPU and no weights.
A mock is not the real thing, and its value is precise: it lets you get the
client, the schema and the error handling right *before* spending 30 GB and an
hour finding out you got the field names wrong.
""")

nb.code('''
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ACTION_DIM = 10          # bridge/DROID/LIBERO end-effector width
CHUNK = 16

class MockPolicyHandler(BaseHTTPRequestHandler):
    """Implements the documented LIBERO policy-server contract, exactly.

    Including the parts that are easy to get wrong: 415 on a bad content type,
    404 on an unknown path, and HTTP 200 with an empty action list when
    inference fails.
    """

    def log_message(self, fmt, *args):
        pass                                  # keep the notebook output readable

    def _send(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/info":
            self._send(200, {
                "run_name": "mock", "checkpoint": "none (synthetic)",
                "action_chunk_size": CHUNK, "raw_action_dim": ACTION_DIM,
                "fps": 20, "action_normalization": "quantile_rot",
            })
        elif self.path == "/":
            self._send(200, {"status": "ok"})
        else:
            self._send(404, {"error": "Not found"})

    def do_POST(self):
        if self.path not in ("/", "/predict", "/predict_batch"):
            self._send(404, {"error": "Not found"})
            return
        content_type = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if content_type != "application/json":
            self._send(415, {"error": "Content-Type must be application/json"})
            return

        length = int(self.headers.get("Content-Length") or 0)
        try:
            req = json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError as exc:
            self._send(200, {"action": [], "error": f"bad json: {exc}"})
            return

        if "image" not in req or "prompt" not in req:
            # The real server's default: 200 with an empty action list.
            self._send(200, {"action": [], "error": "missing 'image' or 'prompt'"})
            return

        rng = np.random.default_rng(abs(hash(req["prompt"])) % (2 ** 32))
        act = np.zeros((CHUNK, ACTION_DIM))
        act[:, :3] = rng.normal(0, 0.01, size=(CHUNK, 3))
        act[:, 3:9] = np.tile([1, 0, 0, 0, 1, 0], (CHUNK, 1))
        act[:, 9] = (np.arange(CHUNK) >= CHUNK // 2).astype(float)
        time.sleep(0.05)                       # stand in for denoising

        if self.path == "/predict_batch":
            self._send(200, {"actions": [act.tolist()]})
        else:
            self._send(200, {"action": act.tolist(), "video": []})


def start_mock_server():
    """Bind an OS-assigned port and serve in a daemon thread."""
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), MockPolicyHandler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    return httpd, f"http://127.0.0.1:{httpd.server_address[1]}"

mock_server, MOCK_URL = start_mock_server()
print(f"mock policy server listening at {MOCK_URL}")
print("Shut down at the end of this section; it is a daemon thread, so a kernel")
print("restart also takes it with it.")
''')

nb.predict_run_explain(
    predict=(
        "You are about to send six requests to that server. Write down the HTTP "
        "status code you expect for each, before running: (1) `GET /`; "
        "(2) `GET /nonexistent`; (3) `POST /predict` with correct JSON; "
        "(4) `POST /predict` with `Content-Type: text/plain`; "
        "(5) `POST /somewhere-else` with correct JSON; (6) `POST /predict` with "
        "valid JSON that is **missing the image field** — that is, a request the "
        "server accepts and cannot answer."
    ),
    change=(
        "Nothing to edit. Commit to six numbers, then run. Number 6 is the one "
        "worth thinking hardest about."
    ),
    explain=(
        "Check your six against the results. Then answer the real question: "
        "given the status code you got for (6), what would a client have to do "
        "to detect that inference failed? Write the check. This is the same "
        "argument `verify_result` makes about generation exit codes, arriving "
        "from a completely different direction, and noticing that the two are "
        "the same argument is the point of the exercise."
    ),
    hint=(
        "The server's own flag is called `--http-400-on-error` and it defaults "
        "to off. A flag that exists to make errors visible, defaulting to "
        "invisible, is a strong hint about what the default behaviour is and "
        "about why it is that way — the comment in the source says it matches "
        "legacy client expectations."
    ),
)

nb.code('''
def call(url, path="/", method="GET", payload=None, content_type="application/json",
         timeout=30):
    """One hand-made HTTP request. Returns (status, parsed_body_or_text, seconds)."""
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url + path, data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", content_type)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status, raw = resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        status, raw = exc.code, exc.read().decode("utf-8", "replace")
    elapsed = time.perf_counter() - started
    try:
        return status, json.loads(raw), elapsed
    except json.JSONDecodeError:
        return status, raw, elapsed

# A tiny valid PNG, base64-encoded, so the request is well formed without
# needing an image file. 1x1 pixel; the mock does not look at it.
TINY_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmM"
    "IQAAAABJRU5ErkJggg=="
)
GOOD_REQUEST = {
    "image": TINY_PNG_B64,
    "prompt": "Put the pot to the left of the purple item.",
    "domain_name": "bridge_orig_lerobot",
    "image_size": 256,
}

probes = [
    ("1  GET  /",                    lambda: call(MOCK_URL, "/")),
    ("2  GET  /nonexistent",         lambda: call(MOCK_URL, "/nonexistent")),
    ("3  POST /predict  (good)",     lambda: call(MOCK_URL, "/predict", "POST", GOOD_REQUEST)),
    ("4  POST /predict  (text/plain)",
     lambda: call(MOCK_URL, "/predict", "POST", GOOD_REQUEST, content_type="text/plain")),
    ("5  POST /somewhere-else",      lambda: call(MOCK_URL, "/somewhere-else", "POST", GOOD_REQUEST)),
    ("6  POST /predict  (no image)",
     lambda: call(MOCK_URL, "/predict", "POST", {k: v for k, v in GOOD_REQUEST.items()
                                                 if k != "image"})),
]

results = {}
for label, fn in probes:
    status, body, elapsed = fn()
    preview = json.dumps(body)[:70] if not isinstance(body, str) else body[:70]
    print(f"{label:<32} {status}   {elapsed * 1000:6.1f} ms   {preview}")
    results[label] = {"status": status, "seconds": round(elapsed, 4)}
''')

nb.md("""
### What probe 6 means

A 200 with an empty `action` list is a **successful HTTP transaction reporting a
failed inference**. A client that checks `resp.status == 200` and moves on will
send an empty action chunk to a robot.

So write the check the status code cannot do for you. It is three lines, and it
belongs in every policy client you ever write.
""")

nb.code('''
def check_prediction(status, body, *, expected_dim=ACTION_DIM, expected_chunk=None):
    """Decide whether a policy response is usable. Returns a list of problems."""
    problems = []
    if status != 200:
        problems.append(f"HTTP {status}")
    if not isinstance(body, dict):
        return problems + ["body is not a JSON object"]
    if body.get("error"):
        problems.append(f"server reported: {body['error']}")

    action = body.get("action")
    if action is None:
        problems.append("no 'action' key (a /predict_batch response uses 'actions')")
    elif not action:
        problems.append("empty action list - inference failed behind a 200")
    else:
        arr = np.asarray(action, dtype=float)
        if arr.ndim != 2:
            problems.append(f"expected [chunk, dims], got shape {arr.shape}")
        else:
            if arr.shape[1] != expected_dim:
                problems.append(f"width {arr.shape[1]}, expected {expected_dim}")
            if expected_chunk and arr.shape[0] != expected_chunk:
                problems.append(f"chunk {arr.shape[0]}, expected {expected_chunk}")
            if not np.isfinite(arr).all():
                problems.append("non-finite values in the action")
    return problems

for label in ("3  POST /predict  (good)", "6  POST /predict  (no image)"):
    payload = GOOD_REQUEST if label.startswith("3") else {
        k: v for k, v in GOOD_REQUEST.items() if k != "image"
    }
    status, body, _ = call(MOCK_URL, "/predict", "POST", payload)
    problems = check_prediction(status, body, expected_dim=ACTION_DIM, expected_chunk=CHUNK)
    print(f"{label:<32} status={status}  usable={not problems}")
    for p in problems:
        print(f"        problem: {p}")
''')

nb.md("""
**Checkpoint.** You have a client that talks the documented schema and a
verifier that does not trust the status code.
""")

nb.code('''
status_ok, body_ok, _ = call(MOCK_URL, "/predict", "POST", GOOD_REQUEST)
assert status_ok == 200 and not check_prediction(status_ok, body_ok), "the good path failed"

status_info, body_info, _ = call(MOCK_URL, "/info")
assert status_info == 200 and "raw_action_dim" in body_info, "/info did not answer"

status_404, _, _ = call(MOCK_URL, "/nope")
assert status_404 == 404, "unknown paths should be 404"

status_415, _, _ = call(MOCK_URL, "/predict", "POST", GOOD_REQUEST, content_type="text/plain")
assert status_415 == 415, "a non-JSON content type should be 415, not 400"

(OUTPUT_DIR / "schema_probe.json").write_text(json.dumps(results, indent=2))
print("checkpoint passed: schema documented from the wire, and a real usability check")
''')

# ------------------------------------------------------------ the real server
nb.md("""
## Starting the real server

This part uses the GPU and downloads a checkpoint, so it is opt-in. What it
proves is worth the nine gigabytes: that the policy-serving plumbing works on
your machine, without a simulator anywhere in sight.

Two preconditions, both checked before anything downloads:

1. The `policy-server` dependency group must be installed in the framework venv.
   The RoboLab server imports openpi's `WebsocketPolicyServer`, which is not part
   of the base install. Upstream's own instructions run
   `uv sync --all-extras --group=cu130-torch213-train --group=policy-server`.
2. About 9 GB of disk for `Cosmos3-Edge-Policy-DROID`, and enough free VRAM to
   hold it. NVIDIA publishes no inference figure for this checkpoint. The
   working estimate this course uses elsewhere — ~12 GB — is for the **Edge
   base** checkpoint, and a post-trained policy checkpoint is a different model
   with action heads attached, so treat ~12 GB as a lower bound rather than a
   budget. Watch `nvidia-smi` while the server loads and record what you
   actually see; that number is the one worth having.

The smoke test itself is one HTTP GET to `/healthz`. Inference on this server is
msgpack over a WebSocket, so a hand-made inference request is not a one-liner —
that is why the schema work above used the LIBERO contract, which is plain JSON.
""")

nb.code('''
POLICY_SERVER_IMPORT = """
import json
ok, how = False, None
for name in ("openpi_server.websocket_policy_server",
             "openpi.serving.websocket_policy_server"):
    try:
        __import__(name); ok, how = True, name; break
    except Exception:
        continue
print(json.dumps({"available": ok, "module": how}))
"""

if framework_problems:
    ws_info = {"available": False, "module": None}
    print("framework venv unavailable; cannot check.")
else:
    ws_info = json.loads(framework_eval(POLICY_SERVER_IMPORT))

print(f"WebsocketPolicyServer available : {ws_info['available']}  ({ws_info['module']})")
if not ws_info["available"]:
    print()
    print("Not installed. To add it, from the framework checkout:")
    print("    uv sync --all-extras --group=cu130-torch213-train --group=policy-server")
    print("This is an extra install into the FRAMEWORK venv and is compatible")
    print("with it - unlike the simulator client's pins.")
''')

nb.code('''
# OPT-IN. ~9 GB download the first time, plus GPU memory for the life of the server.
RUN_REAL_POLICY_SERVER = os.environ.get("COSMOS_COURSE_RUN_POLICY_SERVER", "0") == "1"
POLICY_CHECKPOINT = "nvidia/Cosmos3-Edge-Policy-DROID"

print(f"RUN_REAL_POLICY_SERVER = {RUN_REAL_POLICY_SERVER}")
print(f"checkpoint             = {POLICY_CHECKPOINT}  (~9 GB)")
print()
if not RUN_REAL_POLICY_SERVER:
    print("Skipping. To run it: export COSMOS_COURSE_RUN_POLICY_SERVER=1 and")
    print("restart the kernel, or set RUN_REAL_POLICY_SERVER = True above.")
    print("Everything after this section works either way.")

def free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])

server_proc = None
server_report = {"attempted": bool(RUN_REAL_POLICY_SERVER), "healthy": None}
''')

nb.code('''
if RUN_REAL_POLICY_SERVER and ws_info["available"] and not framework_problems:
    port = free_port()
    argv = [
        str(gen.python), "-m", "cosmos_framework.scripts.action_policy_server_robolab",
        "--checkpoint-path", POLICY_CHECKPOINT,
        "--port", str(port),
        "--format-prompt-as-json", "True",
        "--guidance-interval", "960", "1001",
    ]
    print("$ " + " ".join(argv))
    print()
    print("First start downloads the checkpoint and loads it. Expect several")
    print("minutes before /healthz answers. Watching nvidia-smi in another")
    print("terminal tells you which phase you are in: 0% utilisation means it")
    print("is still downloading.")

    log_path = OUTPUT_DIR / "policy_server.log"
    log_file = log_path.open("w")
    server_proc = subprocess.Popen(
        argv, cwd=str(gen.repo),
        env={**os.environ, "LD_LIBRARY_PATH": "", "PYTHONNOUSERSITE": "1"},
        stdout=log_file, stderr=subprocess.STDOUT, text=True,
    )

    health_url = f"http://127.0.0.1:{port}/healthz"
    deadline = time.time() + (45 * 60)
    healthy = False
    while time.time() < deadline and server_proc.poll() is None:
        try:
            with urllib.request.urlopen(health_url, timeout=5) as resp:
                if resp.status == 200:
                    healthy = True
                    break
        except Exception:
            time.sleep(10)
    server_report.update({
        "healthy": healthy, "url": health_url, "port": port,
        "exit_code": server_proc.poll(), "log": str(log_path),
    })
    print()
    print(f"/healthz answered 200 : {healthy}")
    if not healthy:
        print(f"Read {log_path} - the last lines say which phase it died in.")
else:
    print("not started (see the flags above)")
''', tags=["expensive"])

nb.code('''
# Always give the card back. A policy server holds its weights for its lifetime.
if server_proc is not None and server_proc.poll() is None:
    server_proc.terminate()
    try:
        server_proc.wait(timeout=60)
    except subprocess.TimeoutExpired:
        server_proc.kill()
    print(f"policy server stopped (exit {server_proc.returncode})")
else:
    print("no policy server process to stop")

(OUTPUT_DIR / "policy_server_report.json").write_text(json.dumps(server_report, indent=2))
print(json.dumps(server_report, indent=2))
''')

# ---------------------------------------------------------- compounding error
nb.md("""
## How fast does open loop actually fall apart?

You now have the argument. Get the numbers, because "error grows" is not
actionable and "error exceeds your 2 cm tolerance at step 40" is.

The simulation below is deliberately simple and needs no GPU: a controller
issuing 3-D translation deltas, each carrying a systematic bias `b` and
zero-mean noise `σ`. Open loop accumulates for the whole horizon. Closed loop
re-observes every `k` steps, which resets the accumulated error to zero because
the fresh observation reports the true state.

It is a model, not a measurement of Cosmos 3. Its job is to make the *shape* of
the two curves concrete so that the numbers you get from a real system have
somewhere to land.
""")

nb.predict_run_explain(
    predict=(
        "Before running: (a) sketch, in words, how open-loop error grows with "
        "horizon when there is bias but no noise, and when there is noise but no "
        "bias. (b) At what horizon do you expect noise to stop dominating and "
        "bias to take over? (c) If you halve the chunk size in the closed-loop "
        "case, what happens to the steady-state error? "
        "Then relate it: your Lesson 11 round trip produced a per-frame "
        "difference curve. Was it flat or rising, and which of these two terms "
        "does that implicate?"
    ),
    change=(
        "Change `BIAS` and `NOISE` to values you think are realistic for a "
        "model that is 'nearly right', run, and see whether the crossover lands "
        "where you predicted."
    ),
    explain=(
        "Read the crossover horizon off the table. Then answer the question "
        "that matters operationally: given a task that takes 200 steps and a "
        "tolerance you pick, what is the largest chunk size you could get away "
        "with? That number is a control-frequency requirement, and it is the "
        "kind of thing that decides whether a policy is deployable."
    ),
    hint=(
        "A bias adds the same amount every step, so its contribution is linear "
        "in N. Zero-mean noise cancels on average, so its contribution grows "
        "like the square root of N. Two curves, one linear and one square-root, "
        "cross exactly once, and everything about where depends on the ratio of "
        "the two constants."
    ),
)

nb.code('''
BIAS = 0.002        # systematic error per step, in whatever units the action is in
NOISE = 0.010       # zero-mean per-step noise, same units
TRIALS = 400
HORIZONS = (5, 10, 20, 40, 80, 160, 320)
CHUNKS = (1, 4, 16, 64)
rng = np.random.default_rng(0)

def open_loop_error(horizon, trials=TRIALS):
    """Final position error after `horizon` uncorrected steps."""
    steps = rng.normal(BIAS, NOISE, size=(trials, horizon, 3))
    return np.linalg.norm(steps.sum(axis=1), axis=1)

def closed_loop_error(horizon, chunk, trials=TRIALS):
    """Worst error within a chunk, when every `chunk` steps the state is re-observed."""
    worst = np.zeros(trials)
    for start in range(0, horizon, chunk):
        n = min(chunk, horizon - start)
        steps = rng.normal(BIAS, NOISE, size=(trials, n, 3))
        drift = np.linalg.norm(np.cumsum(steps, axis=1), axis=2).max(axis=1)
        worst = np.maximum(worst, drift)       # error is reset at each re-observation
    return worst

print(f"bias={BIAS} per step, noise={NOISE} per step, {TRIALS} trials")
print()
header = f"{'horizon':>8}{'open loop':>12}" + "".join(f"{'k=' + str(k):>10}" for k in CHUNKS)
print(header)
print("-" * len(header))
rows = []
for horizon in HORIZONS:
    open_err = float(open_loop_error(horizon).mean())
    closed = [float(closed_loop_error(horizon, k).mean()) for k in CHUNKS]
    rows.append({"horizon": horizon, "open_loop": round(open_err, 5),
                 **{f"chunk_{k}": round(c, 5) for k, c in zip(CHUNKS, closed)}})
    print(f"{horizon:>8}{open_err:>12.4f}" + "".join(f"{c:>10.4f}" for c in closed))

print()
print("Read the columns where k is at least the horizon with care: there the")
print("chunk covers the whole run, so closed loop IS open loop, and these")
print("columns report the worst error at ANY point rather than the error at the")
print("end - which lets them sit slightly above the open-loop column. The")
print("informative columns are the ones where k is much smaller than N.")
''')

nb.code('''
# Separate the two mechanisms, since they grow at different rates.
print(f"{'horizon':>8}{'bias only':>12}{'noise only':>12}{'ratio':>10}")
print("-" * 42)
crossover = None
for horizon in HORIZONS:
    bias_term = BIAS * horizon * np.sqrt(3)          # 3 axes, all biased the same way
    noise_term = NOISE * np.sqrt(horizon) * np.sqrt(3)
    ratio = bias_term / max(noise_term, 1e-12)
    if crossover is None and ratio >= 1.0:
        crossover = horizon
    print(f"{horizon:>8}{bias_term:>12.4f}{noise_term:>12.4f}{ratio:>10.2f}")
print()
analytic = (NOISE / BIAS) ** 2 if BIAS > 0 else float("inf")
print(f"bias overtakes noise at roughly N = (noise/bias)^2 = {analytic:.0f} steps")
print(f"first tabulated horizon where it has : {crossover}")
print()
print("Below the crossover, open loop looks acceptable and the problem is")
print("invisible. Above it, error grows linearly and no amount of averaging")
print("helps. That is why a policy that behaves on short clips can fail badly")
print("on a long task, and why horizon must be reported with any success rate.")

(OUTPUT_DIR / "compounding.json").write_text(json.dumps({
    "bias": BIAS, "noise": NOISE, "trials": TRIALS,
    "analytic_crossover_steps": round(float(analytic), 1),
    "rows": rows,
}, indent=2))
''')

# ------------------------------------------------------------- parity gotchas
nb.md("""
## The four parity gotchas

Upstream's LIBERO guide ends with a section headed "Eval parity — the
client/server already handle these; verify if accuracy is low". Four items. Read
them once as a list, then notice that they are all the same bug:

| # | Gotcha | What upstream says |
|---|---|---|
| 1 | **Concat layout** | Run with `--camera agentview,wrist --image_size 256` so the 256×512 concat matches training; the server snaps it to 192×320 identically. |
| 2 | **Gripper sign** | The model emits `[0, 1]`; the environment wants `[-1, 1]`, negative = open. The client applies `1 − 2·g`. Flip the sign if the gripper never opens. |
| 3 | **Image orientation** | Sim frames are rotated 180° versus training; the client rotates them back. |
| 4 | **Normalization** | Start the server with `--action-normalization quantile_rot` and the bundled rot6d stats, or actions come out at the wrong scale. |

Every one of these is **train/serve skew**: the data the model sees at serving
time is not in the form it saw during training, or its output is interpreted
differently than it was supervised.

- Two cameras concatenated side by side into one 256×512 image is a *format*.
  The model learned to read the left half as third-person and the right half as
  wrist. Swap them, or send one camera, or resize differently, and every pixel
  is in the wrong place as far as the model is concerned. The image is still a
  perfectly valid image.
- The gripper channel is a *convention*. Lesson 12 refused to tell you which end
  meant closed, and this is why. `1 − 2·g` maps `[0, 1]` onto `[1, −1]`, which
  both rescales and reverses.
- A 180° rotation is a *pose convention* between two coordinate systems that
  disagree about which way is up. Same class of bug as Lesson 11's
  drove-into-the-sky plot, in a different place.
- Normalisation is a *units* problem. The model was supervised on normalised
  actions; serving them raw produces the right shape at the wrong scale, which
  is precisely the failure mode `translation_scale` had in Lesson 11.

The transferable lesson: **whatever transformation was applied to build the
training data must be applied identically at serving time, and the inverse must
be applied to the output.** Every one of these four is that sentence with a
different noun.

None of them raises an exception. All four produce a policy that runs, returns
well-formed numbers and performs badly.
""")

nb.code('''
PARITY_CHECKS = [
    {
        "id": "concat_layout",
        "question": "Are both cameras present, in the training order, at the training size?",
        "expected": "agentview + wrist, each 256x256, concatenated to 256x512",
        "symptom_if_wrong": "plausible but poor actions; often worse on tasks that need the wrist view",
        "how_to_check": "log the observation the client actually sends and look at it",
    },
    {
        "id": "gripper_sign",
        "question": "Is the gripper mapped from the model's range to the environment's?",
        "expected": "1 - 2*g applied; negative means open in the environment",
        "symptom_if_wrong": "the gripper never opens, or never closes, and nothing is ever picked up",
        "how_to_check": "command a known open and a known close, watch the simulator",
    },
    {
        "id": "image_orientation",
        "question": "Are simulator frames rotated 180 degrees back to the training orientation?",
        "expected": "client rotates before sending",
        "symptom_if_wrong": "the policy reaches in the wrong direction, consistently and confidently",
        "how_to_check": "render one frame from the client and one from the training set side by side",
    },
    {
        "id": "action_normalization",
        "question": "Was the server started with --action-normalization quantile_rot and the rot6d stats?",
        "expected": "quantile_rot + libero_native_frame_wise_relative_rot6d.json",
        "symptom_if_wrong": "correct shape, wrong scale: motions far too small or too large",
        "how_to_check": "GET /info and read action_normalization back off the server",
    },
]

for check in PARITY_CHECKS:
    print(f"[{check['id']}]")
    print(f"    ask     : {check['question']}")
    print(f"    expect  : {check['expected']}")
    print(f"    symptom : {check['symptom_if_wrong']}")
    print(f"    check by: {check['how_to_check']}")
    print()

(OUTPUT_DIR / "parity_checklist.json").write_text(json.dumps(PARITY_CHECKS, indent=2))
''')

# ----------------------------------------------------------- debugging lab
nb.md("""
## Debugging lab: it works in evaluation and fails in simulation

**Symptom.** A colleague post-trained a policy. Their offline numbers look
right: the predicted actions match held-out data closely, and the round-trip
check from Lesson 11 is clean. They stand up the server, point the LIBERO client
at it, and the success rate is close to zero. The robot moves smoothly and
purposefully to the wrong places. Nothing errors. The server returns 200 for
every request.

**Hypothesis.** Offline evaluation and simulation differ in exactly one respect:
offline, the observations come from the same pipeline that produced the training
data; in simulation, they come from the simulator through the client. So the
model is fine and something between the simulator and the model's input is not.
That is train/serve skew, and there are four documented candidates.

**Diagnostic step.** Work the four in order of how cheaply they can be ruled
out, not in the order they are listed. Start with the one you can settle with a
single HTTP request.
""")

nb.code('''
# 1. NORMALIZATION - cheapest to check, because the server will tell you.
status, info, _ = call(MOCK_URL, "/info")
print("GET /info ->")
print(json.dumps(info, indent=2))
print()
norm = info.get("action_normalization") if isinstance(info, dict) else None
print(f"action_normalization reported : {norm!r}")
print(f"expected                      : 'quantile_rot'")
print(f"verdict                       : {'consistent' if norm == 'quantile_rot' else 'MISMATCH - restart the server with the right flag'}")
print()
print("Symptom if this is the fault: motions the right SHAPE at the wrong")
print("SCALE. If the gripper path looks like the task traced in miniature,")
print("this is your bug and the other three are innocent.")
''')

nb.code('''
# 2. GRIPPER SIGN - settled by arithmetic, no simulator needed.
model_range = np.linspace(0.0, 1.0, 5)
env_values = 1 - 2 * model_range

print(f"{'model g':>10}{'1 - 2g':>10}   meaning in the environment")
print("-" * 55)
for g, e in zip(model_range, env_values):
    print(f"{g:>10.2f}{e:>10.2f}   {'open' if e < 0 else 'closed' if e > 0 else 'neutral'}")
print()
print("So model g=0 -> env +1 -> closed, and model g=1 -> env -1 -> open.")
print()
print("Now the diagnostic. Take the gripper polarity you recorded in Lesson 12")
print("and ask whether it agrees. If your model closes at HIGH g and the")
print("environment reads high-g-mapped values as closed, you are consistent.")
print("If they disagree, the gripper will do the opposite of what is intended")
print("for the entire episode, and the visible symptom is that it never opens")
print("- which is exactly the sentence upstream's own note ends with.")

prev = cc.OUTPUT_ROOT / "12" / "gripper_polarity.json"
if prev.exists():
    print()
    print("your Lesson 12 record:")
    print(json.dumps(json.loads(prev.read_text()), indent=2)[:600])
else:
    print()
    print("(no Lesson 12 gripper record found; run Lesson 12 to produce one)")
''')

nb.code('''
# 3. IMAGE ORIENTATION and 4. CONCAT LAYOUT - both need you to look at the
#    observation the client actually sends, not the one you think it sends.
def describe_observation(image_hw, cameras, expected_single=(256, 256)):
    """Sanity-check an observation's geometry against the training contract."""
    h, w = image_hw
    problems = []
    n = len(cameras)
    expected_w = expected_single[1] * n
    if (h, w) != (expected_single[0], expected_w):
        problems.append(
            f"observation is {h}x{w}; {n} camera(s) at {expected_single} concatenated "
            f"side by side should be {expected_single[0]}x{expected_w}"
        )
    if n != 2:
        problems.append(f"training used 2 cameras (agentview, wrist); this has {n}")
    if list(cameras) != ["agentview", "wrist"]:
        problems.append(f"camera ORDER is {list(cameras)}; training order is "
                        f"['agentview', 'wrist'] and the halves are not interchangeable")
    return problems

cases = [
    ("correct",              (256, 512), ["agentview", "wrist"]),
    ("wrist only",           (256, 256), ["wrist"]),
    ("cameras swapped",      (256, 512), ["wrist", "agentview"]),
    ("resized by the client", (224, 448), ["agentview", "wrist"]),
]
for label, hw, cams in cases:
    problems = describe_observation(hw, cams)
    print(f"{label:<24} {'OK' if not problems else 'PROBLEM'}")
    for p in problems:
        print(f"        {p}")
print()
print("Orientation cannot be caught by geometry at all: a 180-degree rotation")
print("preserves every dimension. The only diagnostic is to LOOK - render one")
print("client frame and one training frame side by side. A checkable version:")
print("compare the mean brightness of the top and bottom thirds. Indoor scenes")
print("are lit from above, so an inverted frame usually has that ratio flipped.")
''')

nb.md("""
**Repair.** In order of what the four cases actually require:

1. `--action-normalization quantile_rot --action-stats-path <the bundled rot6d
   stats>` on the server command line.
2. Apply `1 − 2·g` in the client, and flip it if the gripper never opens.
3. Rotate simulator frames 180° in the client before sending.
4. Run the client with `--camera agentview,wrist --image_size 256` so the concat
   matches training.

Upstream's client and server already do all four. You are checking them because
"already handled" is a claim about a version, and you are running some version.

**Verification.** The honest verification is a success rate in simulation, which
needs the second machine. What you *can* verify without one:

- the server reports the expected normalisation from `/info`;
- the gripper mapping is consistent with the polarity you measured in Lesson 12;
- the observation geometry matches the training contract;
- and — the one people skip — the **whole loop** has been exercised end to end
  at least once with a mock, so that a failure in simulation is a policy problem
  rather than a plumbing problem.

That last point is why the mock exists.
""")

nb.code('''
def parity_report(info_body, observation_hw, cameras, gripper_polarity_path=None):
    """Run every parity check that does not need a simulator. Returns a report."""
    report = {}
    norm = info_body.get("action_normalization") if isinstance(info_body, dict) else None
    report["action_normalization"] = {
        "reported": norm, "expected": "quantile_rot", "ok": norm == "quantile_rot",
    }
    geometry_problems = describe_observation(observation_hw, cameras)
    report["observation_geometry"] = {
        "shape": list(observation_hw), "cameras": list(cameras),
        "problems": geometry_problems, "ok": not geometry_problems,
    }
    report["gripper_mapping"] = {
        "transform": "1 - 2*g",
        "model_range": [0.0, 1.0],
        "env_range": [1.0, -1.0],
        "lesson_12_record_found": bool(
            gripper_polarity_path and Path(gripper_polarity_path).exists()
        ),
        "ok": None,
        "note": "cannot be settled without watching the gripper move; check by hand",
    }
    report["image_orientation"] = {
        "ok": None,
        "note": "a 180-degree rotation preserves shape; only a visual or "
                "brightness-profile check can see it",
    }
    report["verifiable_without_a_simulator"] = [
        k for k, v in report.items() if isinstance(v, dict) and v.get("ok") is not None
    ]
    return report

report = parity_report(info, (256, 512), ["agentview", "wrist"], prev)
(OUTPUT_DIR / "parity_report.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
''')

# --------------------------------------------------------- what you cannot run
nb.md("""
## The parts you are reading rather than running

Below is the full simulator-client setup, verbatim from upstream. It is written
to a shell script you can inspect and take to another machine. The cell that
would actually execute it is tagged `skip-execution`, and the reason is not
squeamishness: it builds a second virtualenv, clones LIBERO, installs
`robosuite`, `mujoco` and an older torch, and then needs a working EGL context
and a post-trained checkpoint. On a single-GPU teaching machine that is thirty
minutes of installation to reach a component whose other half you cannot
provide.

Writing it out is still worth doing. When you have the second machine, this
script is the starting point, and you will already know what every line is for.
""")

nb.code('''
LIBERO_CLIENT_SETUP = """#!/usr/bin/env bash
# Second virtualenv for the LIBERO simulator client.
# Verbatim from cosmos-framework docs/action_policy_libero_posttrain.md, section 3.
# Run this from the cosmos-framework checkout, NOT inside its .venv.
set -euo pipefail

# Optional, only on a headless container without working GPU EGL:
#   export NVIDIA_DRIVER_CAPABILITIES=all
#   apt-get install -y libegl1 libglvnd0 libgl1 libglib2.0-0 ffmpeg
#   mkdir -p /usr/share/glvnd/egl_vendor.d
#   echo '{"file_format_version":"1.0.0","ICD":{"library_path":"libEGL_nvidia.so.0"}}' \\\\
#     > /usr/share/glvnd/egl_vendor.d/10_nvidia.json

uv venv --python 3.10 .libenv
VV=.libenv/bin/python

git clone https://github.com/Lifelong-Robot-Learning/LIBERO.git
uv pip install -p "$VV" -e LIBERO -r LIBERO/requirements.txt
uv pip install -p "$VV" "robosuite==1.4.1" "mujoco==2.3.7" "torch<2.6" \\\\
    loguru requests scipy pillow numpy

mkdir -p ~/.libero && touch ~/.libero/config.yaml
RS=$("$VV" -c "import robosuite, os; print(os.path.dirname(robosuite.__file__))")
"$VV" "$RS/scripts/setup_macros.py"
"$VV" -c "from libero.libero import set_libero_default_path; set_libero_default_path()"

echo "second venv ready at .libenv"
echo "the pins above are why this cannot live in the framework venv"
"""

script_path = OUTPUT_DIR / "libero_client_setup.sh"
script_path.write_text(LIBERO_CLIENT_SETUP)
script_path.chmod(0o755)
print(f"wrote {script_path}")
print()
print(LIBERO_CLIENT_SETUP)
''')

nb.code('''
# NOT RUN. Tagged skip-execution: this builds a second virtualenv, clones an
# external repository, installs an older torch alongside mujoco and robosuite,
# and then still needs a post-trained LIBERO checkpoint that does not exist
# publicly. Roughly 30 minutes and ~10 GB to reach a component whose other half
# this machine cannot supply. Nothing later in this notebook depends on it.
subprocess.run(["bash", str(script_path)], cwd=str(gen.repo), check=True)
''', tags=["skip-execution", "expensive"])

nb.code('''
# The mock has done its job. Give the port back.
mock_server.shutdown()
mock_server.server_close()
print("mock policy server stopped")
''')

# -------------------------------------------------------------- exercises
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "Document the policy-server schema from the wire",
    goal=(
        "Produce a schema document you could hand to someone writing a client, "
        "derived from observed behaviour rather than from prose."
    ),
    instructions=(
        "1. Restart the mock server (or start the real one if you opted in).\n"
        "2. Probe every documented endpoint and every documented method, "
        "including `/predict_batch`, which returns a **different key**.\n"
        "3. Probe at least four malformed requests. For each, record the status "
        "code, the body, and whether a naive client checking only the status "
        "would have noticed.\n"
        "4. Write `outputs/13/policy_server_schema.md`: every endpoint, every "
        "field with its type, every status code you observed and what caused "
        "it, and a 'how to tell a real failure from a real success' section.\n"
        "5. Include one thing the documentation does not mention that you "
        "discovered by probing."
    ),
    success=(
        "A schema document covering all three POST paths and both GET paths, "
        "with at least four error cases and at least one behaviour not stated "
        "in the module docstring."
    ),
    starter='''
mock_server, MOCK_URL = start_mock_server()
print("server at", MOCK_URL)

ENDPOINTS = [("GET", "/"), ("GET", "/info"), ("POST", "/predict"),
             ("POST", "/predict_batch"), ("POST", "/")]

def probe_all(url, endpoints, payload):
    """Return a table of (method, path, status, keys-in-response)."""
    raise NotImplementedError

# Remember to call mock_server.shutdown() when you are finished.
''',
    hints=[
        "The response key differs between `/predict` and `/predict_batch` — "
        "singular `action` versus plural `actions`. A client written against one "
        "and pointed at the other gets a 200 and a `KeyError`, or worse, a "
        "`.get('action')` that quietly returns None.",
        "For the undocumented behaviour, try a request with an extra field the "
        "server was not expecting, a very large `image_size`, and an empty JSON "
        "object. What a server does with input nobody planned for is exactly "
        "what you need to know before you trust it in a loop.",
    ],
    solution_ref="solutions/13_solutions.ipynb",
)

nb.exercise(
    "applied",
    "A mock closed-loop driver",
    goal=(
        "Build the client half of a closed-loop system — the part that owns the "
        "loop — and measure what it costs per chunk."
    ),
    instructions=(
        "1. Write `ClosedLoopDriver(server_url, chunk, fps)` with a `run(n_steps, "
        "observations)` method that: sends an observation, receives a chunk, "
        "'executes' it by advancing an index, sends the next observation, and "
        "repeats until `n_steps` have been executed.\n"
        "2. Feed it recorded observations. Frames from your Lesson 12 rollout, "
        "or from the cookbook's bridge episode, are fine — the point is that "
        "they come from somewhere and are base64-encoded PNGs, exactly as the "
        "schema requires.\n"
        "3. Log the full action stream to `outputs/13/action_stream.jsonl`: one "
        "record per chunk with the request timestamp, latency, and the actions "
        "returned.\n"
        "4. Measure per-chunk latency: median and spread over at least 20 "
        "chunks. Report both. A single mean is not a measurement.\n"
        "5. From your median latency, compute the maximum control frequency this "
        "loop could sustain, and compare it against the `fps` the server "
        "advertises. If the loop is slower than the control rate, say what that "
        "means physically.\n"
        "6. Use `check_prediction` on every response and count how many chunks "
        "would have been silently unusable."
    ),
    success=(
        "A driver that completes at least 20 chunks, a JSONL action stream, a "
        "median-and-spread latency figure, a computed maximum control frequency "
        "compared against the server's `fps`, and a count of unusable responses."
    ),
    starter='''
import base64

class ClosedLoopDriver:
    def __init__(self, server_url, chunk=16, fps=20):
        self.url, self.chunk, self.fps = server_url, chunk, fps
        self.log = []

    def observe(self, index):
        """Return a base64 PNG for step `index`. Recorded, not simulated."""
        raise NotImplementedError

    def step(self, index, prompt):
        """One iteration: observe, request, verify, return the action chunk."""
        raise NotImplementedError

    def run(self, n_steps, prompt):
        raise NotImplementedError
''',
    hints=[
        "The mock sleeps 50 ms per request to stand in for denoising, so your "
        "latency numbers describe the transport and your own code, not a model. "
        "Say so in the report. Real per-chunk latency on a diffusion policy is "
        "dominated by denoising steps, which is why the RoboLab Edge command "
        "uses `--guidance-interval 960 1001` to apply guidance on only part of "
        "the schedule.",
        "Report the median and an interval, not a mean. Latency distributions "
        "have a long right tail — one slow chunk in fifty is invisible in a mean "
        "and is exactly the one that makes a controller miss its deadline.",
    ],
    solution_ref="solutions/13_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "Design a closed-loop evaluation you could actually run",
    goal=(
        "Produce a design document and a harness skeleton for a real "
        "closed-loop evaluation on a second machine — specific enough that "
        "someone with the hardware could execute it."
    ),
    instructions=(
        "1. **Environment.** Specify both machines: what runs where, both "
        "virtualenvs with their pins, the network between them, the checkpoint, "
        "and the exact server and client commands. Start from "
        "`outputs/13/commands.txt` and make every placeholder concrete.\n"
        "2. **Metrics.** Primary and at least two secondary. Success rate is "
        "the obvious primary; define what counts as success, who decides, and "
        "at what horizon. For secondaries consider time-to-completion, "
        "per-chunk latency, and a failure taxonomy.\n"
        "3. **Sample size.** Success rate is a binomial proportion. Derive the "
        "number of trials you need for a confidence interval you would be "
        "willing to publish, and state the interval width you chose and why. "
        "Upstream's own eval runs 50 trials per task over 10 tasks — work out "
        "what interval that buys and whether it is enough for the comparison "
        "you want to make.\n"
        "4. **Confounds.** List at least five and say how you control each. The "
        "four parity gotchas are four of them. Seed, task ordering, initial "
        "state distribution, server warm-up and wall-clock timeouts are "
        "candidates for the rest.\n"
        "5. **Harness skeleton.** Working code with the model calls stubbed: "
        "trial loop, per-trial record, aggregation, confidence intervals, and a "
        "report writer. It must run end to end against the mock server and "
        "produce a report with fabricated results, so that swapping in the real "
        "server is a one-line change.\n"
        "6. **Falsifiability.** State in advance what result would make you "
        "conclude the policy is not working, and what result would make you "
        "conclude your harness is not working. Being unable to distinguish "
        "those two is the most common way an evaluation wastes a week."
    ),
    success=(
        "`outputs/13/closed_loop_design.md` covering all six points, plus a "
        "harness that runs against the mock and emits a report with confidence "
        "intervals. The sample-size section must contain a derivation, not a "
        "number."
    ),
    starter='''
from dataclasses import dataclass, field

@dataclass
class TrialRecord:
    task: str
    trial: int
    success: bool
    steps: int
    seconds: float
    failure_mode: str = ""
    notes: dict = field(default_factory=dict)

def wilson_interval(successes, n, z=1.96):
    """Confidence interval for a binomial proportion. Better than normal
    approximation at the extremes, which is where policy success rates live."""
    raise NotImplementedError

def run_trials(server_url, tasks, trials_per_task):
    """Trial loop. Stub the environment; keep the harness real."""
    raise NotImplementedError
''',
    hints=[
        "The normal approximation to a binomial interval breaks down exactly "
        "where policy evaluation lives — near 0% and near 100% — and can "
        "produce a lower bound below zero. The Wilson interval does not. Look "
        "it up, implement it, and check it against a case you can verify by "
        "hand, such as 0 successes in 10 trials.",
        "For the falsifiability section, the sharpest tool is a deliberately "
        "broken control. Run the same harness against a policy that emits zero "
        "actions and against one that emits random actions. If your harness "
        "cannot distinguish those two from the real policy, it is not measuring "
        "what you think.",
    ],
    solution_ref="solutions/13_solutions.ipynb",
)

# ------------------------------------------------------------- assessment
nb.md("""
## Assessment and reflection

### Knowledge check

1. State the difference between open-loop and closed-loop control in one
   sentence each, in terms of when the policy is queried.
2. Open-loop error from a systematic bias grows like `N`; from zero-mean noise
   like `√N`. Which dominates at long horizons, and where do they cross?
3. Closed-loop error is bounded by what quantity, and why does re-observing
   reset the accumulation?
4. Name the two shipped policy servers, their simulators, and their transports.
5. Why is the closed-loop design two processes? Give the specific pin that makes
   one process impossible.
6. Why can the base checkpoint not be served by the policy server, and which
   module does that fact motivate?
7. The policy server returns HTTP 200 with `{"action": []}`. What happened, and
   what should your client do?
8. Take each of the four parity gotchas and name the general class of bug it
   belongs to. What single sentence covers all four?
9. Your policy scores well offline and fails in simulation. Which of the four
   would you check first, and why that one?

### Practical completion test

1. Start a policy server and get a well-formed action chunk out of it with a
   hand-made HTTP request.
2. Write a client-side check that catches a failed inference behind a 200.
3. Demonstrate the dependency conflict from versions on your own machine.
4. Produce a compounding-error table and read the crossover horizon off it.
5. Fill in `outputs/13/closed_loop_notes.md` — what you ran, what you read, and
   the constraint that stopped each thing.
""")

nb.code('''
CLOSED_LOOP_NOTES = """
# Lesson 13 - what ran, what did not

## Ran on this machine

-

## Read rather than ran

-

## The constraint that stopped each thing

-

## What I would need to run the rest

-
"""

notes_path = OUTPUT_DIR / "closed_loop_notes.md"
if not notes_path.exists():
    notes_path.write_text(CLOSED_LOOP_NOTES.strip() + "\\n")
print(f"template at {notes_path} - fill it in before calling this lesson done")
print()

def self_test():
    passed = []

    schema = json.loads((OUTPUT_DIR / "schema_probe.json").read_text())
    assert schema["1  GET  /"]["status"] == 200
    assert schema["2  GET  /nonexistent"]["status"] == 404
    assert schema["4  POST /predict  (text/plain)"]["status"] == 415
    assert schema["6  POST /predict  (no image)"]["status"] == 200, (
        "the failed-inference probe should return 200 - that is the whole point"
    )
    passed.append("schema probed from the wire, including the 200-on-failure case")

    comp = json.loads((OUTPUT_DIR / "compounding.json").read_text())
    assert comp["rows"], "the compounding simulation produced no rows"
    longest = comp["rows"][-1]
    assert longest["open_loop"] > longest["chunk_1"], (
        "open loop should exceed closed loop at the longest horizon"
    )
    passed.append(
        f"compounding measured; bias overtakes noise near "
        f"N={comp['analytic_crossover_steps']:.0f} steps"
    )

    parity = json.loads((OUTPUT_DIR / "parity_report.json").read_text())
    assert len(parity["verifiable_without_a_simulator"]) >= 2
    passed.append(
        f"parity checks runnable here: {parity['verifiable_without_a_simulator']}"
    )

    srv = json.loads((OUTPUT_DIR / "policy_server_report.json").read_text())
    if srv["attempted"] and srv.get("healthy"):
        passed.append("real policy server started and answered /healthz")
    elif srv["attempted"]:
        passed.append("NOTE: real policy server was attempted and did not become "
                      "healthy - read outputs/13/policy_server.log")
    else:
        passed.append("real policy server not attempted (opt-in flag off)")

    notes = notes_path.read_text()
    if notes.count("-") <= 5:
        passed.append("NOTE: closed_loop_notes.md is still the template")
    else:
        passed.append("closed-loop notes written")

    for item in passed:
        print(f"  PASS  {item}" if not item.startswith("NOTE") else f"  ----  {item}")
    return passed

_ = self_test()
''')

nb.md("""
### Summary

- **Closed loop** means re-querying the policy every chunk against a fresh
  observation. That single change turns error that grows with the horizon into
  error bounded by the chunk length.
- Systematic bias accumulates linearly in the horizon; zero-mean noise
  accumulates like its square root. They cross once, and below the crossover an
  open-loop policy looks fine.
- Feedback also handles the two things error analysis does not cover:
  disturbances, and the policy's own mistakes changing the state the rest of the
  plan assumed.
- The architecture is a **policy server** plus a **simulator client**.
  `action_policy_server_libero` speaks JSON over HTTP; `action_policy_server_robolab`
  speaks msgpack over a WebSocket with an HTTP `/healthz`.
- The two-process split is forced by a dependency conflict:
  `robosuite==1.4.1`, `mujoco==2.3.7` and `torch<2.6` cannot share an
  environment with a CUDA-13 torch and flash-attention-3. An unresolvable pin is
  sometimes telling you where a process boundary belongs.
- The **base checkpoint has no action heads**, so only a post-trained checkpoint
  can be served. `Cosmos3-Nano-Policy-DROID` and `Cosmos3-Edge-Policy-DROID` are
  public and ungated; there is no public LIBERO one, which is what motivates
  Module 5.
- The LIBERO server returns **HTTP 200 with an empty action list** when
  inference fails, by default. Status codes are not success signals. Verify the
  payload.
- The four parity gotchas — concat layout, gripper `1 − 2·g`, 180° rotation,
  `quantile_rot` normalisation — are all **train/serve skew**: whatever
  transformation built the training data must be applied identically at serving
  time, and its inverse applied to the output. None of them raises.

### Common misconceptions

| Belief | Correction |
|---|---|
| "Closed loop is just open loop run more often" | It is open loop run more often *on fresh observations*. Re-running on stale observations changes nothing. |
| "A better model removes the need for feedback" | Only if the bias is exactly zero. Feedback bounds the error for any non-zero bias. |
| "Open loop is fine for short tasks" | Possibly, but you have to know where your crossover is, and that requires measuring your bias. |
| "The dependency conflict is a packaging annoyance" | No version of torch satisfies both sides. It is a constraint, and the architecture is its consequence. |
| "HTTP 200 means it worked" | The server's own default is 200 with an empty action list on failure, to match a legacy client. |
| "Parity gotchas are edge cases" | They are the normal failure mode of deploying a trained model, and all four are the same bug. |
| "I can evaluate this on one GPU if I try hard enough" | You can run the server. The client needs an incompatible environment, and the LIBERO server needs a checkpoint you have not trained yet. |

### Suggested extensions

- Extend the compounding simulation with a *state-dependent* bias — error that
  grows when the gripper is further from where the plan assumed. That is closer
  to reality and it makes closed loop look considerably better.
- Add artificial latency to the mock server and find the chunk size at which
  your driver can no longer keep up with a 20 Hz control rate. That number is a
  deployment requirement.
- Write the RoboLab WebSocket client. The transport is msgpack over a WebSocket
  and the openpi client is short; the exercise is in reading someone else's
  protocol from their code rather than from a specification.

### Mastery checklist

- [ ] I can explain why feedback bounds an error that open loop lets grow.
- [ ] I measured how open-loop error grows and found the crossover horizon.
- [ ] I can name both policy servers, their simulators and their transports.
- [ ] I demonstrated the dependency conflict from versions on my own machine.
- [ ] I queried a policy server by hand and documented its schema from the wire.
- [ ] I have a client-side check that does not trust the status code.
- [ ] I can state all four parity gotchas and the one sentence that covers them.
- [ ] I wrote down what I ran, what I read, and what stopped each.

**Module 3 is complete.** You can drive the model forwards, backwards and as a
policy, and you know what closing the loop would require. Module 4 measures what
all of it costs.

### Module 3 resources

The four links the source course closed its action notebook with, and where each
one is actually useful:

- **[Cosmos 3 cookbook — generator/action](https://github.com/NVIDIA/cosmos/tree/main/cookbooks/cosmos3/generator/action)** —
  the source of every record, observation and trajectory Lessons 10–13 used, and
  the reference for JSONL fields this course explained one at a time.
  `scripts/fetch_assets.py` pulls from here.
- **[Cosmos3 Action Viewer](https://huggingface.co/spaces/nvidia/Cosmos3-Action-Viewer)** —
  a Hugging Face Space that renders an action array next to its rollout video.
  The fastest way to eyeball a `[T, 9]` or `[T, 10]` array, with the standing
  caveat from Lesson 12: looking is not checking, and it is someone else's
  server.
- **[RoboLab](https://github.com/NVlabs/RoboLab)** — `NVlabs/RoboLab`, the Isaac
  Sim 5.0 / Isaac Lab 2.2.0 client this lesson could not run against a
  co-resident server. Read `policies/cosmos3/run.py` and the task definitions if
  you want to see what the client half of the closed loop looks like; the
  dependency demonstration above is why you are reading it rather than running
  it.
- **[Cosmos Framework](https://github.com/NVIDIA/cosmos-framework)** — the
  `main` branch is the arbiter for `ModelMode`, the JSONL schema and the policy
  server entry points. Every time this course says "check the enum, not the
  prose", this is the repository it means.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "13_action_closed_loop.ipynb")
