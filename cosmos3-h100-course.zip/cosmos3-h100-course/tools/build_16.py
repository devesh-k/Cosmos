"""Build 16_posttraining_concepts.ipynb.

Module 5, lesson 1 of 3. This lesson runs with **no GPU and no downloads**: it
is arithmetic, schema work and planning. That is deliberate — it is the one
post-training lesson a learner can do while still waiting for hardware, and the
arithmetic is what makes Lessons 17 and 18 make sense.

Everything asserted here was read out of upstream `main` in August 2026 rather
than paraphrased. The primary sources, and what each one supplied:

`docs/sft_config.md` — the field-by-field TOML reference
  * `[model].max_num_tokens_after_packing` default 13312, `-1` disables
  * `[model].lora_enabled` default false, `lora_rank` 16, `lora_alpha` 32,
    `lora_target_modules` default
    "q_proj_moe_gen,k_proj_moe_gen,v_proj_moe_gen,o_proj_moe_gen", **VFM only**
  * `[model.ema].enabled` default **true**; "the trainer keeps a second fp32
    copy of trainable params"
  * `[optimizer].keys_to_select` default `[]` — "Empty = train everything"
  * `extra="forbid"` on every sub-model
  * the VFM/VLM path-remap table, in which `model.{... lora_*}` is
    *(skipped — VFM-only)* on the VLM path

`docs/dataset_jsonl.md` — the generator JSONL schema
  * top-level `uuid`, `duration`, `width`, `height`, `vision_path`,
    `t2w_windows[]`
  * window: `start_frame`, `end_frame`, `temporal_interval`, `caption_json`
    (preferred) and `caption` (dense fallback)
  * `caption_json` carries `subjects[]`, `background_setting`, `cinematography`,
    `actions[]`, `temporal_caption`, `resolution`, `aspect_ratio`, `duration`,
    `fps`
  * the converter "mirrors the loader's silent filters (clips longer than 61 s,
    and windows shorter than max(61, --num-video-frames) frames)"

`examples/toml/sft_config/action_policy_libero_10_nano.toml`
  * `data_parallel_shard_degree = 8`, `data_parallel_replicate_degree = 2`
  * the comment `# HSDP 2x8 = 16 ranks (2 nodes); minimum for gbs 2048 at
    grad_accum 1` — which is the reveal for predict-run-explain #3: the rank
    count is set by the global batch size, not only by memory
  * no `keys_to_select` at all, so it is a full 16B fine-tune

`examples/toml/sft_config/vision_sft_edge.toml`
  * `keys_to_select = ["moe_gen","time_embedder","vae2llm","llm2vae",
    "k_norm_und_for_gen"]`
  * `max_num_tokens_after_packing = 45056`, `ema.enabled = true`

`docs/code_structure.md`
  * `algorithm/` (loss, reward, rl) and `evaluation/` are both **`[planned]` —
    not present in this release**. That is why the RLHF section here is honest
    about being background rather than something the learner can run.

Nothing in this lesson downloads anything or touches a GPU.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 16 — What post-training actually changes")

# --------------------------------------------------------------- title block
nb.md("""
# Lesson 16 — What post-training actually changes

**What you will build.** `outputs/16/` containing a memory model you derived by
hand and checked against the course estimator, a valid generator JSONL dataset
you built from scratch, a deliberately poisoned dataset that loads "fine" and
yields nothing, and a `plan_finetune()` planner that tells you whether a
fine-tune is possible on stated hardware — or explains precisely why it is not.

| | |
|---|---|
| **Time** | ~2 hours |
| **GPU** | **None.** Every cell in this lesson runs on a laptop. |
| **Downloads** | **None.** No checkpoints, no datasets, no containers. |
| **Prerequisites** | Modules 0–4. Lesson 14's allocated/reserved distinction is assumed. |

This is the cheapest lesson in the course and one of the most important. Lesson
17 attempts a fine-tune that NVIDIA does not document, and Lesson 18 evaluates
whatever comes out of it. Neither is meaningful without the arithmetic here.

Set the environment up first; the argument starts immediately after it.
""")

# ---------------------------------------------------------------- objectives
nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Define** pre-training, post-training, SFT, RLHF and LoRA from zero, and
   **state** which problem each one solves.
2. **Derive** the per-parameter memory bill for a mixed-precision AdamW
   fine-tune from first principles, and **compute** it by hand for Cosmos3-Edge
   and Cosmos3-Nano before you run any estimator.
3. **Explain** why activation checkpointing does not rescue a full Nano SFT,
   and **demonstrate** the arithmetic that makes that counter-intuitive claim
   true.
4. **Compute** the memory difference between a frozen and a trainable
   parameter, and **relate** it to `optimizer.keys_to_select` in the shipped
   vision recipes.
5. **Predict** the parameter count of a rank-`r` LoRA adapter for a stated
   layer shape, and **compare** your figure against
   `finetune.estimate_sft_memory(lora=True)`.
6. **Explain** what FSDP sharding does to the memory table, and **state** why
   that lever is closed to you at world size 1.
7. **Write** a valid generator JSONL record against `docs/dataset_jsonl.md` and
   **validate** it with `finetune.check_dataset`.
8. **Diagnose** a dataset whose every record is silently filtered out, from a
   training run that produced no error.
9. **Plan** a fine-tune for arbitrary hardware and **justify** a verdict of
   "not possible" with numbers.
""")

# ------------------------------------------------------------- environment
#
# The environment cells come BEFORE the conceptual foundation on purpose. The
# authoring guide's section order is title -> objectives -> concepts ->
# environment, but a lesson that opens with a thousand words of theory is a wall
# to a beginner. Title and objectives stay at the top; the motivation and the
# vocabulary now sit after the first runnable cell, broken up by things to run.
nb.md("""
## Environment

Nothing below needs CUDA. If `select_device()` prints its CPU-fallback warning,
that is fine for this lesson — it is not fine for Lesson 17.
""")

nb.code('__lesson__ = "16"   # OUTPUT_DIR resolves to outputs/16\n\n' + SETUP_CELL)

nb.code('''
# ---------------------------------------------------------------------------
# Verification. Fail here, with a useful message, rather than in cell 40.
# ---------------------------------------------------------------------------
import json
import math

from cosmos_course import finetune

cc.require(
    hasattr(finetune, "estimate_sft_memory"),
    "cosmos_course.finetune is missing estimate_sft_memory.",
    fix="You are on an old checkout. git pull, then restart the kernel.",
)

print("finetune module     : ok")
print("known model tiers   :", ", ".join(sorted(cc.MODEL_TIERS)))
print("known SFT recipes   :", ", ".join(sorted(finetune.SHIPPED_RECIPES)))
print("known datasets      :", ", ".join(sorted(finetune.DATASETS)))
print()
print(f"DEVICE is {DEVICE!r}. This lesson does not care — it is all arithmetic.")
''')

# ------------------------------------------------- conceptual foundation (1)
nb.md("""
## The headline, stated once and then earned

NVIDIA documents **no single-GPU training path for Cosmos 3.** Every shipped
recipe is an 8-GPU configuration; the LIBERO action recipes are sixteen. Full
supervised fine-tuning of Cosmos3-Nano needs roughly 350 GB of state before a
single activation byte, which is more than four H100s. This course does not
pretend otherwise. It teaches you the arithmetic that explains why, which levers
exist, which of those levers need hardware you do not have, and how to tell
whether what you did worked.

Everything after this earns that claim. Start with the vocabulary, because four
of the words involved are used interchangeably in public and mean different
things.

## Four words people use interchangeably, and should not

Almost everyone arriving at this topic conflates at least two of the following.
They are different operations solving different problems.

**Pre-training.** Start from random weights. Show the model an enormous,
weakly-curated corpus — for Cosmos 3, video with text — and optimise a generic
objective (next-token prediction, or in the generator's case flow matching from
noise to data). *The problem it solves:* the model knows nothing. It has no
prior over what a video is, what objects persist, what gravity looks like.
Pre-training is where essentially all the capability comes from, it costs
thousands of GPU-months, and **you are never going to do it.**

**Post-training.** An umbrella term for everything done to a pre-trained
checkpoint afterwards. SFT, preference optimisation, distillation, quantisation
and alignment all live under it. It is not a technique; it is a phase.

**Supervised fine-tuning (SFT).** Continue gradient descent, with the *same*
loss the model was pre-trained on, on a small curated dataset of
input/desired-output pairs. *The problem it solves:* the model is general but
your domain is specific. It generates plausible video; you want video that
looks like *your* robot in *your* kitchen. SFT is the only post-training
technique this course runs, and it is what `cosmos_framework.scripts.train`
does.

Every SFT recipe that ships is listed below with the hardware it was run on.
""")

nb.code('''
# The evidence for the claim above. Every SFT recipe in the framework, with the
# GPU count its own documentation states. There is no single-GPU row.
print(f"{'recipe':<32s} {'base model':<26s} {'documented GPUs':>16s}")
for name, spec in sorted(finetune.SHIPPED_RECIPES.items()):
    print(f"{name:<32s} {spec['base_model'][:26]:<26s} "
          f"{spec['documented_gpus']:>16d}")

counts = [spec["documented_gpus"] for spec in finetune.SHIPPED_RECIPES.values()]
smallest = min(spec.get("smallest_documented", spec["documented_gpus"])
               for spec in finetune.SHIPPED_RECIPES.values())
print()
print(f"recipes that ship           : {len(counts)}")
print(f"documented GPU counts       : {sorted(set(counts))}")
print(f"smallest published claim    : {smallest} GPUs")
print(f"what you have               : 1 GPU")
print()
print("All five are supervised fine-tuning. That is not a coincidence, and the")
print("cells below explain why the alternatives are not on the list.")
''')

nb.md("""
**RLHF (and the DPO family).** Collect human *comparisons* — "output A is
better than output B" — fit a reward model to those comparisons, and optimise
the policy against the reward with an RL algorithm, usually with a **KL
penalty**: an extra term in the loss that punishes the new model for drifting
too far from the original model's output distribution. Direct Preference
Optimisation (DPO) reformulates the same objective so no separate reward model
is needed. *The problem it solves:* you can **rank** outputs but you cannot
**write** the target. Nobody can hand-author "the correct video", but anyone can
say which of two is better.

**LoRA (Low-Rank Adaptation).** Not a training objective at all — a
*parameterisation*. Instead of updating a weight matrix `W` directly, you learn
a low-rank correction and compute `W + BA`, training only `B` and `A`. *The
problem it solves:* optimizer state is proportional to the number of
**trainable** parameters, and you have one GPU. LoRA is orthogonal to the
choice of SFT or RLHF; you can do either with it.

| | Starts from | Data it needs | Objective | Trainable params | Do you run it here? |
|---|---|---|---|---|---|
| Pre-training | random | ~everything | generic (flow matching / next token) | all | no, and never |
| SFT | pre-trained ckpt | (input, target) pairs | same as pre-training | all, or a chosen subset | **yes — Lesson 17** |
| RLHF / DPO | an SFT'd ckpt | preference comparisons | reward, with a KL leash | all, or adapters | no — see below |
| LoRA | any of the above | whatever that method needs | unchanged | `2·r·d` per matrix | yes, as a fallback |
""")


nb.callout(
    "upstream",
    "RLHF is background here, not something you can run. `docs/code_structure.md` "
    "lists `cosmos_framework/algorithm/` — containing `loss/`, `reward/` and `rl/` "
    "— as **`[planned]` — not yet present in this release**. So there is no PPO "
    "(Proximal Policy Optimization), no GRPO (Group Relative Policy Optimization) "
    "and no DPO in the Cosmos Framework today. You will find blog posts describing "
    "reward-model post-training of world models; none of it ships in `v1.2.2`. "
    "Check for yourself with the cell below, which looks for those directories in "
    "your own checkout.",
)

nb.callout(
    "gotcha",
    "the word *rank* means **two unrelated things** in this lesson. In LoRA, the "
    "rank `r` is a property of a matrix: how many independent directions a "
    "low-rank update is allowed to move in. In distributed training, a rank is the "
    "integer id of one GPU process in a job, so *16 ranks* means sixteen processes "
    "on sixteen GPUs. Nothing connects the two senses but the word.",
)

nb.code('''
# The callout above says to check for yourself, so here is the check. It needs a
# framework checkout; without one it says so and moves on. Nothing downloads.
PLANNED_DIRS = ["algorithm", "algorithm/loss", "algorithm/reward",
                "algorithm/rl", "evaluation"]

repo = cc.COSMOS3_REPO
if (repo / "cosmos_framework").is_dir():
    print(f"reading {repo / 'cosmos_framework'}")
    for rel in PLANNED_DIRS:
        present = (repo / "cosmos_framework" / rel).is_dir()
        print(f"  [{'present' if present else 'ABSENT ':<7s}] cosmos_framework/{rel}")
else:
    print(f"no framework checkout at {repo}, so there is nothing to inspect.")
    print("Set COSMOS3_REPO to your clone and re-run this cell to see which of")
    print("the directories docs/code_structure.md lists exist on disk today.")

print()
print("Either way, the plan does not change: this lesson and Lesson 17 do SFT,")
print("because SFT is the only post-training method the framework ships.")
''')

# ------------------------------------------------- conceptual foundation (2)
nb.md("""
## The memory bill, derived

Here is the question this whole module turns on: **why do the shipped recipes
need eight GPUs?**

The intuitive answer — "the model is big" — is wrong, or at least badly
incomplete. Cosmos3-Nano's weights in bf16 are 32 GB. That fits on one H100
with room to spare; you have been running inference with it since Module 2.
Training does not fail because the weights are large. It fails because of
everything else that has to exist *per parameter* while you train.

Work through what a single parameter costs during mixed-precision AdamW:

- **The bf16 weight itself (2 bytes).** This is what the forward and backward
  passes read. Every parameter pays it, frozen or not.
- **An fp32 master copy (4 bytes).** bf16 has about 8 bits of mantissa, so the
  numbers it can represent near a given magnitude are spaced far apart. That
  gap — from one representable number to the next — is one **ulp**, *unit in the
  last place*, and an update smaller than half a ulp rounds away to nothing
  rather than moving the weight. A typical update at learning rate 1e-4 is
  far smaller than one bf16 ulp at the weight's magnitude, so adding it to a
  bf16 weight leaves the weight exactly where it was and the parameter never
  moves. The optimizer therefore keeps the authoritative copy in fp32 and casts
  down for the forward pass. Only **trainable** parameters need this.
- **AdamW's first moment `m` (4 bytes).** A running mean of the gradient.
- **AdamW's second moment `v` (4 bytes).** A running mean of the *squared*
  gradient. `m` and `v` are why Adam costs 8 bytes per parameter that plain SGD
  does not.
- **Gradients (2 or 4 bytes).** Somewhere between the backward pass and the
  optimizer step, a gradient exists for every trainable parameter. Whether it
  is 2 or 4 depends on where accumulation happens; we will compute both.
- **An EMA copy (4 bytes), if `model.ema.enabled`.** An exponential moving
  average of the trainable weights, kept in fp32, used for inference while the
  live weights keep training. `docs/sft_config.md` gives its default as
  **`true`**, and the shipped `vision_sft_edge.toml` leaves it on. This is the
  single most commonly missed line item in the whole bill.

So a trainable parameter costs 2+4+4+4+(2..4)+(0 or 4) = **16 to 22 bytes**, and
a *frozen* parameter costs **2**. Hold on to that ratio; it is the lesson.
""")

nb.code('''
# The table above, as data. These are bytes per parameter, per component.
# finetune.BYTES_PER_PARAM holds the same numbers -- we write them out here so
# you compute the bill yourself before comparing against anything.
PER_PARAM = {
    "bf16 weights   (EVERY param)": 2,
    "fp32 master    (trainable)":   4,
    "AdamW m        (trainable)":   4,
    "AdamW v        (trainable)":   4,
    "gradients      (trainable)":   4,   # conservative: fp32 accumulation
    "EMA fp32 copy  (trainable)":   4,   # only if model.ema.enabled
}

for name, nbytes in PER_PARAM.items():
    print(f"  {name:<30s} {nbytes} bytes")

print()
print("  frozen parameter  :", PER_PARAM["bf16 weights   (EVERY param)"], "bytes")
print("  trainable, EMA on :", sum(PER_PARAM.values()), "bytes")
print("  ratio             :",
      sum(PER_PARAM.values()) / PER_PARAM["bf16 weights   (EVERY param)"], "x")

# Sanity-check against the module the course ships, so you know we agree.
print()
print("cosmos_course.finetune.BYTES_PER_PARAM:", dict(finetune.BYTES_PER_PARAM))


def hand_state_gb(total_params_b, trainable_params_b, *,
                  grad_bytes=4, ema=True, world_size=1):
    """State memory in decimal GB, computed the long way, on purpose.

    Everything here is a multiplication you could do on paper. That is the
    point: when a run OOMs at 3 a.m. you want to be able to reproduce this
    number without a library.

    Parameters are in BILLIONS (so Nano is 16, not 16e9).
    `world_size` divides everything, which is a first-order model of FSDP --
    good enough to explain why sixteen ranks works, wrong in the details.
    """
    P = total_params_b * 1e9
    T = trainable_params_b * 1e9
    GB = 1e9                                # decimal GB, as HF reports sizes

    parts = {
        "bf16 weights (all)":   P * 2 / GB,
        "fp32 master":          T * 4 / GB,
        "AdamW m":              T * 4 / GB,
        "AdamW v":              T * 4 / GB,
        "gradients":            T * grad_bytes / GB,
    }
    if ema:
        parts["EMA fp32 copy"] = T * 4 / GB
    if world_size > 1:
        parts = {k: v / world_size for k, v in parts.items()}
    parts["TOTAL"] = sum(parts.values())
    return parts


def show(label, parts):
    print(label)
    for k, v in parts.items():
        rule = "  " + "-" * 34 if k == "TOTAL" else ""
        if rule:
            print(rule)
        print(f"    {k:<22s} {v:8.1f} GB")
    print()
''')

# -------------------------------------------------- predict / run / explain 1
nb.predict_run_explain(
    predict=(
        "Write down, as a single number in GB, the total **state** memory for a "
        "full-parameter SFT of Cosmos3-Nano with the shipped defaults: 16 billion "
        "parameters, all of them trainable, fp32 gradients, `ema.enabled = true`. "
        "Do the six multiplications on paper first. Then write down a second "
        "number for the most optimistic reading — bf16 gradients and EMA off. "
        "Finally: how many H100 80 GB cards is the first number?"
    ),
    change=(
        "Nothing to change. Run the cell below, which does exactly the arithmetic "
        "you just did."
    ),
    explain=(
        "Compare both of your numbers against the output. If you were low, which "
        "row did you forget? Nearly everyone forgets EMA, and a lot of people "
        "forget that `m` and `v` are two separate 4-byte buffers rather than one."
    ),
    hint=(
        "16 billion parameters × 4 bytes is 64 GB, and that single product appears "
        "in the bill four separate times (master, m, v, gradients) plus once more "
        "if EMA is on."
    ),
)

nb.code('''
# Cosmos3-Nano, full-parameter SFT. This is what
# examples/toml/sft_config/action_policy_libero_10_nano.toml actually does:
# it has no `keys_to_select` at all, and an empty allowlist means TRAIN
# EVERYTHING (docs/sft_config.md, [optimizer].keys_to_select, default []).
NANO_B = cc.MODEL_TIERS["Cosmos3-Nano"]["params_total_b"]      # 16
EDGE_B = cc.MODEL_TIERS["Cosmos3-Edge"]["params_total_b"]      # 4

nano_shipped = hand_state_gb(NANO_B, NANO_B, grad_bytes=4, ema=True)
nano_best    = hand_state_gb(NANO_B, NANO_B, grad_bytes=2, ema=False)

show("Cosmos3-Nano, full SFT, shipped defaults (fp32 grads, EMA on)", nano_shipped)
show("Cosmos3-Nano, full SFT, most optimistic (bf16 grads, EMA off)", nano_best)

CARD_GB = 80.0
print(f"shipped defaults : {nano_shipped['TOTAL'] / CARD_GB:.1f} x an H100 80 GB")
print(f"most optimistic  : {nano_best['TOTAL'] / CARD_GB:.1f} x an H100 80 GB")
print()
print("and that is BEFORE a single activation byte.")
''')

nb.md("""
Those two numbers, ~256 GB and ~352 GB, are exactly the range
`COSMOS3_FACTS.md` §5 quotes as "≈256–350 GB". It is not a measurement with
error bars. It is the gap between the most and least favourable reading of two
binary choices: gradient precision, and whether EMA is on. Knowing which end
you are at is a matter of reading two config lines.

Now do the other end of the range — the recipe that might actually fit — and
then check the whole derivation against the course's estimator. If they
disagree, one of us is wrong and it matters which.
""")

nb.code('''
# vision_sft_edge trains the generation pathway only. The shipped TOML restricts
# the optimizer with:
#
#   keys_to_select = ["moe_gen", "time_embedder", "vae2llm", "llm2vae",
#                     "k_norm_und_for_gen"]
#
# which is roughly half of Cosmos3-Edge's 4B parameters. Everything else stays
# resident in bf16 for the forward pass and carries NO optimizer state.
EDGE_TRAINABLE_B = EDGE_B * 0.5          # ~2B; refine this from the checkpoint

edge_shipped = hand_state_gb(EDGE_B, EDGE_TRAINABLE_B, ema=True)
edge_ours    = hand_state_gb(EDGE_B, EDGE_TRAINABLE_B, ema=False)

show("Cosmos3-Edge, gen pathway only, EMA on  (shipped)", edge_shipped)
show("Cosmos3-Edge, gen pathway only, EMA off (our override)", edge_ours)

for label, parts in (("EMA on", edge_shipped), ("EMA off", edge_ours)):
    left = CARD_GB - 4.0 - parts["TOTAL"]        # 4 GB reserve: context, frag
    print(f"  {label:<8s} state {parts['TOTAL']:5.1f} GB  ->  "
          f"{left:5.1f} GB left for activations")

# The course estimator, for comparison. It is this same arithmetic wrapped in a
# dataclass with a verdict attached -- not an independent source of truth.
est_nano = finetune.estimate_sft_memory(
    "Cosmos3-Nano", trainable_fraction=1.0, ema=True, card_gb=80.0)
est_edge = finetune.estimate_sft_memory(
    "Cosmos3-Edge", trainable_fraction=0.5, ema=True, card_gb=80.0)

print()
print(est_nano)
print()
print(est_edge)
''')

nb.checkpoint(
    "Turning off one boolean bought back 8 GB of Edge's activation budget — a "
    "quarter of it. That is the whole argument for Lesson 17, in two lines of "
    "output. Before going on, confirm that your hand arithmetic and the estimator "
    "agree to the last decimal, because they are the same multiplications. If "
    "this assertion fails, read both and decide which one you trust.",
    '''
for label, mine, est in (
    ("Nano full SFT", nano_shipped["TOTAL"], est_nano.state_gb),
    ("Edge gen-only", edge_shipped["TOTAL"], est_edge.state_gb),
):
    delta = abs(mine - est)
    flag = "ok  " if delta < 0.15 else "MISMATCH"
    print(f"  [{flag}] {label:<16s} hand {mine:7.1f} GB   estimator {est:7.1f} GB")

assert abs(nano_shipped["TOTAL"] - est_nano.state_gb) < 0.15
assert abs(edge_shipped["TOTAL"] - est_edge.state_gb) < 0.15
print()
print("The estimator is not an oracle. It is this arithmetic in a dataclass,")
print("and you can now argue with it, which is the point.")
''')

# ---------------------------------------------- activation checkpointing
nb.md("""
## Why activation checkpointing does not save you here

This is the most counter-intuitive point in the module, and it is worth sitting
with, because the internet will tell you the opposite.

**What activations are.** During the forward pass, every layer's output is kept
in memory because the backward pass needs it to compute gradients. For a deep
network on long sequences that is a lot of memory, and it scales with batch
size and sequence length — for Cosmos 3, with
`max_num_tokens_after_packing`, the config field that caps how many tokens the
trainer packs into one training step. Raise it and you get better GPU
utilisation and more activation memory; Lesson 17 spends most of its debugging
budget on that one number.

**What activation checkpointing does.** Throw most of those intermediates away
and recompute them during the backward pass. `mode = "full"` checkpoints every
transformer block; `mode = "selective"` keeps the expensive ops (attention) and
recomputes the cheap ones. You pay roughly 30% more compute and you get most of
the activation memory back.

**Why that does not help a full Nano SFT.** Look at the numbers you just
produced. Nano's state is 352 GB on an 80 GB card. Activation checkpointing
reduces *activations*. Even if it reduced them to exactly zero, you would still
need 352 GB before the first forward pass runs. **You cannot checkpoint your way
out of optimizer state.**

The rule generalises. Ask, in order:

1. Does **state** fit? If not, no activation knob helps. Reduce trainable
   parameters — freezing, LoRA — or shard across ranks you do not have.
2. Does state **plus activations** fit? Now activation checkpointing,
   `max_num_tokens_after_packing` and batch size are exactly the right levers.

Lesson 17 is entirely in case 2, and that is why it might work.
""")

nb.callout(
    "gotcha",
    "The generic advice \"turn on gradient checkpointing when you OOM\" is not "
    "wrong, it is *unconditioned*. It assumes state already fits, which is true "
    "for the 7B-on-a-24GB-card blog posts it comes from and false here. Diagnose "
    "**where** the OOM happened before you pick a lever: an OOM during checkpoint "
    "load or optimizer construction is a state problem; an OOM at iteration 1 or 3 "
    "under a stable configuration is an activation problem. Lesson 17's debugging "
    "lab walks exactly that distinction.",
)

nb.code('''
# Make the claim falsifiable. Sweep the activation budget from "generous" to
# "zero" and see whether it ever rescues a full Nano SFT.
print("Full Cosmos3-Nano SFT on one 80 GB H100")
print("assumed activation memory  ->  total needed   fits?")
for activations_gb in (60, 30, 10, 0):
    total = est_nano.state_gb + activations_gb
    print(f"  {activations_gb:>3d} GB{'':18s}{total:8.1f} GB   "
          f"{'yes' if total <= 80 else 'NO'}")

print()
print("Cosmos3-Edge, generation pathway only, EMA off")
edge_state = hand_state_gb(EDGE_B, EDGE_TRAINABLE_B, ema=False)["TOTAL"]
for activations_gb in (60, 30, 10, 0):
    total = edge_state + activations_gb
    print(f"  {activations_gb:>3d} GB{'':18s}{total:8.1f} GB   "
          f"{'yes' if total <= 80 else 'NO'}")

print()
print("Same knob. Useless in the first table, decisive in the second.")
''')

# ------------------------------------------------------------ freezing
nb.md("""
## Freezing, and what `keys_to_select` is really for

`[optimizer].keys_to_select` is a **substring allowlist for trainable
parameters**. `docs/sft_config.md` gives its default as `[]` and says plainly:
"Empty = train everything". The shipped Edge vision recipe sets:

```toml
keys_to_select = [
    "moe_gen",
    "time_embedder",
    "vae2llm",
    "llm2vae",
    "k_norm_und_for_gen",   # und-K norm trains with the gen pathway
]
```

Read those names as a description of the architecture. Cosmos 3 is a
Mixture-of-Transformers: a *reasoner* tower that understands, and a *generator*
tower that synthesises.

Upstream has its own names for those two halves, and you need both because the
config files use them. The **VLM** — vision-language model — is the reasoner: it
takes images or video plus text and emits text. The **VFM** — video foundation
model — is the generator: it emits pixels. An SFT config picks one with
`task = "vfm"` or `task = "vlm"`, and several settings apply on one path and are
silently skipped on the other. Keep the pair straight; a claim later in this
lesson turns on it.

`moe_gen` is the generation expert. `vae2llm` and
`llm2vae` are the projections between the video VAE's latent space and the
language model's hidden space. `time_embedder` is the diffusion timestep
embedding. `k_norm_und_for_gen` is the one piece of the understanding path that
has to move with the generation path.

Everything not matched by one of those substrings is **frozen**: it stays
resident in bf16 for the forward pass, it produces no gradient, and it gets no
optimizer state. Two bytes instead of eighteen.

This is not a memory hack bolted on afterwards. It is a statement about what
the fine-tune is *for*: you are teaching the model to render your domain, not
to reason about it differently.
""")

nb.code('''
# What does the choice of frozen fraction actually buy?
print("Cosmos3-Edge (4B total), EMA off, fp32 grads")
print(f"{'trainable':>10s} {'params':>8s} {'state':>9s} {'activation budget':>19s}")
for frac in (1.0, 0.75, 0.5, 0.25, 0.1):
    parts = hand_state_gb(EDGE_B, EDGE_B * frac, ema=False)
    budget = CARD_GB - 4.0 - parts["TOTAL"]
    print(f"{frac:>9.0%} {EDGE_B * frac:>7.2f}B {parts['TOTAL']:>8.1f} GB "
          f"{budget:>17.1f} GB")

print()
print("Cosmos3-Nano (16B total), EMA off, fp32 grads")
for frac in (1.0, 0.5, 0.25, 0.1, 0.01):
    parts = hand_state_gb(NANO_B, NANO_B * frac, ema=False)
    budget = CARD_GB - 4.0 - parts["TOTAL"]
    verdict = f"{budget:>17.1f} GB" if budget > 0 else "        DOES NOT FIT"
    print(f"{frac:>9.0%} {NANO_B * frac:>7.2f}B {parts['TOTAL']:>8.1f} GB {verdict}")
''')

nb.md("""
Read the Nano table carefully. The bf16 weights are 32 GB no matter what you
freeze, because the forward pass still has to run through all of them. So even
at 1% trainable, Nano needs 32 GB before optimizer state — and that is the floor
freezing can reach. It is under 80, which is why LoRA on Nano is arithmetically
possible; it is also why the *checkpoint size itself* becomes the binding
constraint for Super, whose bf16 weights alone are 128 GB.

Freezing lowers the slope. It does not lower the intercept.
""")

nb.code('''
# The intercept, per tier: the bf16 weights that must be resident for the
# forward pass whether or not a single parameter is trainable.
print(f"{'tier':<15s} {'params':>8s} {'bf16 weights':>14s}   under an 80 GB card?")
for tier in ("Cosmos3-Edge", "Cosmos3-Nano", "Cosmos3-Super"):
    total_b = cc.MODEL_TIERS[tier]["params_total_b"]
    weights_gb = total_b * 2.0                       # 2 bytes per parameter
    print(f"{tier:<15s} {total_b:>7.0f}B {weights_gb:>13.1f} GB   "
          f"{'yes' if weights_gb < CARD_GB else 'NO'}")

print()
print("This is why LoRA is arithmetically possible on Nano and pointless on")
print("Super: adapters remove optimizer state, and Super's problem is weights.")
''')

nb.md("""
## LoRA from zero

Take one weight matrix `W` with shape `(d_out, d_in)`. Fine-tuning learns an
update `ΔW` of the same shape and uses `W + ΔW`. That update has `d_out × d_in`
free parameters, and every one of them carries the 16–22 bytes you costed
above.

LoRA's claim is that `ΔW` from a fine-tune is close to **low rank** — that the
useful change lives in a small subspace rather than filling the matrix. So
write it as a product:

```
ΔW  ≈  B @ A
        B: (d_out, r)
        A: (r,     d_in)        with  r ≪ min(d_out, d_in)
```

Train `A` and `B`; leave `W` frozen. The forward pass computes
`W x + (alpha/r)·B(Ax)`, so `W` never has to be materialised as an updated
matrix during training. Parameter count drops from `d_out·d_in` to
`r·(d_out + d_in)`, which for a square `d × d` matrix is `2rd` instead of `d²`
— a factor of `d / 2r`.

The scaling factor `alpha/r` exists so that changing `r` does not change the
effective magnitude of the update. Cosmos 3's defaults are `lora_rank = 16` and
`lora_alpha = 32`, i.e. a 2× scale.

**Where it applies here.** `docs/sft_config.md` gives
`lora_target_modules` a default of
`"q_proj_moe_gen,k_proj_moe_gen,v_proj_moe_gen,o_proj_moe_gen"` — the four
attention projection matrices of the generation expert — and marks the whole
LoRA block **VFM only**. The VFM↔VLM path-remap table shows `model.lora_*` as
*(skipped — VLM-only path)*. So: **you can LoRA the generator and you cannot
LoRA the reasoner.**
""")

nb.predict_run_explain(
    predict=(
        "A transformer attention block has four square projection matrices "
        "(`q`, `k`, `v`, `o`), each `d × d` with `d = 2048`, in each of `L = 32` "
        "layers. Predict two numbers: (a) how many parameters a full fine-tune of "
        "just those matrices trains, and (b) how many a rank-16 LoRA on the same "
        "matrices trains. Then predict the ratio."
    ),
    change=(
        "Edit `D_MODEL`, `N_LAYERS` and `RANK` in the cell below if you want to "
        "test a different shape first — the point is the ratio, not the absolute."
    ),
    explain=(
        "The ratio is `d / 2r` and does not depend on the number of layers or the "
        "number of matrices, because both sides scale identically. Say out loud "
        "why doubling the rank halves the saving, and why doubling `d` doubles it."
    ),
    hint=(
        "One matrix full: d·d = 2048² = 4,194,304. One matrix LoRA: r·(d + d) = "
        "16 · 4096 = 65,536. Now multiply both by 4 matrices and 32 layers."
    ),
)

nb.code('''
D_MODEL  = 2048     # hidden size. Read the real one from the checkpoint config.
N_LAYERS = 32
RANK     = 16
N_PROJ   = 4        # q, k, v, o -- the shipped lora_target_modules

def full_params(d_out, d_in):
    return d_out * d_in

def lora_params(d_out, d_in, r):
    """B is (d_out, r), A is (r, d_in). Both are trained; W is frozen."""
    return r * (d_out + d_in)

one_full = full_params(D_MODEL, D_MODEL)
one_lora = lora_params(D_MODEL, D_MODEL, RANK)

print(f"one {D_MODEL}x{D_MODEL} matrix")
print(f"  full fine-tune : {one_full:>12,d} parameters")
print(f"  LoRA rank {RANK:<3d}  : {one_lora:>12,d} parameters")
print(f"  ratio          : {one_full / one_lora:>12,.1f} x   "
      f"(closed form d/2r = {D_MODEL / (2 * RANK):.1f})")

total_full = one_full * N_PROJ * N_LAYERS
total_lora = one_lora * N_PROJ * N_LAYERS
print()
print(f"all {N_PROJ} projections x {N_LAYERS} layers")
print(f"  full fine-tune : {total_full / 1e9:>8.4f} B parameters")
print(f"  LoRA rank {RANK:<3d}  : {total_lora / 1e9:>8.4f} B parameters")
''')

nb.code('''
# Now the memory consequence, and the comparison with the course estimator.
lora_state = hand_state_gb(EDGE_B, total_lora / 1e9, ema=False)
show(f"Cosmos3-Edge with rank-{RANK} LoRA on the attention projections", lora_state)

est_lora = finetune.estimate_sft_memory(
    "Cosmos3-Edge", lora=True, lora_rank=RANK, ema=False, card_gb=80.0)
print(est_lora)

print()
print(f"hand-counted trainable : {total_lora / 1e9:.4f} B")
print(f"estimator's trainable  : {est_lora.trainable_params_b:.4f} B")
ratio = (total_lora / 1e9) / max(est_lora.trainable_params_b, 1e-12)
print(f"ratio                  : {ratio:.2f} x")
''')

nb.callout(
    "warning",
    "Those two trainable counts will **not** match, and the estimator's docstring "
    "says so: it models LoRA as a flat 0.1% of the base model per unit of "
    "`rank/16`, because the true count depends on which modules are targeted and "
    "on shapes it cannot see. Treat `estimate_sft_memory(lora=True)` as an "
    "order-of-magnitude check, and your hand count as the real number once you "
    "have read `d_model` and the layer count out of the checkpoint's "
    "`config.json`. Notice, though, that the *conclusion* is identical either "
    "way: LoRA state is dominated by the frozen bf16 weights, and the adapters "
    "themselves round to nothing. That robustness is why the sloppy estimate is "
    "still useful.",
)

# ------------------------------------------------------------ FSDP
nb.md("""
## FSDP in one page

Fully Sharded Data Parallel is how the shipped recipes make 352 GB tractable.

**Plain data parallelism** puts a complete copy of everything on every GPU and
splits the *batch*. Eight GPUs, eight copies of the 352 GB. That helps
throughput and does nothing at all for memory.

**FSDP** splits the *parameters* instead. Each rank owns `1/N` of every
parameter shard, `1/N` of the fp32 master, `1/N` of `m` and `v`, `1/N` of the
EMA. When a layer is needed for the forward pass, the ranks all-gather that
layer's full parameters, compute, and immediately free the gathered copy. So
every row in your memory table divides by `N` — plus a transient cost for one
unsharded layer at a time, which is small compared with the whole model.

**HSDP** — Hybrid Sharded Data Parallel — is the two-level version, and you will
meet it in the LIBERO recipe below. Shard the model within a group of GPUs, then
*replicate* that sharded group. `data_parallel_shard_degree = 8` with
`data_parallel_replicate_degree = 2` is eight-way sharding inside each of two
groups, 16 ranks in total. Replication buys throughput rather than memory, so
under HSDP it is the shard degree that divides your memory table, not the rank
count — one more way the simple model below is optimistic.

That is the entire trick, and it explains the shipped topologies exactly.
""")

nb.code('''
print("Cosmos3-Nano, FULL SFT, shipped defaults (fp32 grads, EMA on)")
print(f"{'ranks':>6s} {'state/rank':>12s} {'activation budget/rank':>24s}  verdict")
for ws in (1, 2, 4, 8, 16, 32):
    parts = hand_state_gb(NANO_B, NANO_B, ema=True, world_size=ws)
    budget = CARD_GB - 4.0 - parts["TOTAL"]
    verdict = "fits, room to work" if budget > 20 else (
        "fits, tight" if budget > 0 else "DOES NOT FIT")
    print(f"{ws:>6d} {parts['TOTAL']:>9.1f} GB {budget:>21.1f} GB  {verdict}")

print()
print("The shipped LIBERO recipe uses",
      finetune.SHIPPED_RECIPES['action_policy_libero_10_nano']['documented_gpus'],
      "ranks.")
''')

nb.md("""
Sixteen ranks puts state at about 22 GB each and leaves ~54 GB for activations,
which is a comfortable configuration rather than a heroic one. **This is the
resolution of the arithmetic, not a coincidence.**

And it is the lever you do not have. `data_parallel_shard_degree` divides state
across ranks; with one rank there is nothing to divide onto. Setting it to 8 on
a single GPU does not shard anything — it fails the world-size invariant and the
run dies before training starts. The same is true of
`context_parallel_shard_degree`. Both of NVIDIA's OOM-ladder rungs 3 and 4
require hardware.
""")

nb.callout(
    "upstream",
    "The two documents disagree about the world-size invariant, and it is worth "
    "knowing which to trust. `docs/sft_config.md` says the product "
    "`data_parallel_shard_degree × data_parallel_replicate_degree × "
    "context_parallel_shard_degree × cfg_parallel_shard_degree` must equal "
    "`WORLD_SIZE`. `docs/faq.md` says something different and cites the source: "
    "\"Runtime invariant (from `cosmos_framework/utils/generator/parallelism.py`): "
    "`data_parallel_replicate_degree × data_parallel_shard_degree == WORLD_SIZE` "
    "always holds — `context_parallel_shard_degree` and `cfg_parallel_shard_degree` "
    "are *overlay* axes that share dp rank slots, not separate mesh dims.\" "
    "The shipped `vision_sft_super.toml` settles it: shard `-1`, replicate `1`, "
    "cp `2`, cfg `1`, on 8 GPUs. Under the four-factor rule shard would have to "
    "auto-resolve to 4; under the FAQ's rule it resolves to 8. Read "
    "`parallelism.py` in your own checkout rather than either document. At "
    "`WORLD_SIZE = 1` every reading gives `1 = 1`, so the question does not "
    "arise for you — but it will the day you get a second GPU.",
)

# ------------------------------------------------------------ datasets
nb.md("""
## Datasets: two formats, one of which you will build

Cosmos 3 post-training reads two dataset shapes.

**Action data — LeRobotDataset v3.0.** Note the version. This is *not* the v2
layout you may have used with other robot-learning stacks. v3.0 is:

```
<root>/
├── data/chunk-000/file-000.parquet      chunked Parquet, many episodes per file
├── videos/<camera>/chunk-000/file-000.mp4   AV1-encoded shards
└── meta/
    ├── info.json        codebase_version, total_episodes, total_frames, fps
    ├── stats.json       per-feature normalisation statistics
    ├── tasks.parquet    task-index to natural-language instruction
    └── episodes/        per-episode index, itself chunked Parquet
```

v2 wrote one Parquet and one MP4 *per episode*, which fell over at scale, and
recorded `codebase_version: "v2.1"`. A v2 dataset will not load. The launcher
checks only that `meta/info.json` exists, which is a low bar;
`finetune.check_dataset` reads the version.

**Generator data — a JSONL manifest.** One JSON object per line, schema in
`docs/dataset_jsonl.md`. You are going to write one by hand, because the schema
has two traps in it and reading about them is not the same as hitting them.
""")

nb.code('''
# A LeRobotDataset v3.0 skeleton, so you can see what check_dataset looks for.
# We are not downloading anything -- this is the metadata only.
lerobot_root = OUTPUT_DIR / "fake_lerobot_v3"
(lerobot_root / "meta" / "episodes").mkdir(parents=True, exist_ok=True)
(lerobot_root / "meta" / "info.json").write_text(json.dumps({
    "codebase_version": "v3.0",
    "robot_type": "panda",
    "total_episodes": 379,
    "total_frames": 101469,
    "fps": 20,
    "chunks_size": 1000,
}, indent=2))
(lerobot_root / "meta" / "stats.json").write_text("{}")
(lerobot_root / "meta" / "tasks.parquet").write_bytes(b"")   # presence only

report = finetune.check_dataset(lerobot_root, kind="lerobot")
print(json.dumps(report, indent=2))

# Now break exactly one thing: the version. This is the most common way an
# otherwise-correct robotics dataset fails to load.
print()
bad_root = OUTPUT_DIR / "fake_lerobot_v2"
(bad_root / "meta").mkdir(parents=True, exist_ok=True)
(bad_root / "meta" / "info.json").write_text(json.dumps({
    "codebase_version": "v2.1", "total_episodes": 379, "fps": 20,
}, indent=2))

bad = finetune.check_dataset(bad_root, kind="lerobot")
print("ok       :", bad["ok"])
for p in bad["problems"]:
    print("problem  :", p)
for w in bad["warnings"]:
    print("warning  :", w)
''')

nb.md("""
### The generator JSONL schema

From `docs/dataset_jsonl.md`. One object per line:

| Field | Meaning |
|---|---|
| `uuid` | Unique clip id. Also the output filename stem at inference. |
| `duration` | Clip length in **seconds**. Trap #1 lives here. |
| `width`, `height` | Source pixel dimensions. |
| `vision_path` | Path to the MP4, **relative to the JSONL's own directory**. |
| `t2w_windows[]` | One or more training windows cut from the clip. |

And inside each window:

| Field | Meaning |
|---|---|
| `start_frame`, `end_frame` | Window bounds, in frames. Trap #2 lives here. |
| `temporal_interval` | Frame stride. `1` means every frame. |
| `caption_json` | The **structured** caption object. The loader prefers this. |
| `caption` | The dense narrative string. Used only as a fallback. |

`caption_json` is the model's native prompt format — the same shape you write
at inference — which is why training on it keeps the fine-tune aligned with how
you will actually use the model. It carries `subjects[]`, `background_setting`,
`cinematography`, `actions[]`, a `temporal_caption` (the dense narrative,
embedded), and the clip's media fields `resolution`, `aspect_ratio`, `duration`
and `fps`.

Write one.
""")

nb.code('''
def make_caption_json(subject, action, setting, narrative, *, w, h, fps, seconds):
    """The structured caption the SFT loader prefers, per docs/dataset_jsonl.md."""
    return {
        "subjects": [{"description": subject, "action": action}],
        "background_setting": setting,
        "cinematography": {
            "camera_motion": "static",
            "framing": "medium shot",
            "camera_angle": "slightly angled top-down",
        },
        "actions": [{"time": f"0:00-0:{int(seconds):02d}", "description": action}],
        "temporal_caption": narrative,
        "resolution": {"H": h, "W": w},
        # Aspect ratio is a COMMA string here, exactly as at inference. "1:1"
        # and 1.0 are both rejected -- the same trap as Lesson 06.
        "aspect_ratio": "1,1",
        "duration": f"{int(seconds)}s",
        "fps": fps,
    }


def make_record(uuid, *, seconds, w, h, fps, start, end, subject, action,
                setting, narrative):
    return {
        "uuid": uuid,
        "duration": float(seconds),
        "width": w,
        "height": h,
        "vision_path": f"videos/{uuid}.mp4",     # relative to the JSONL
        "t2w_windows": [{
            "start_frame": start,
            "end_frame": end,
            "temporal_interval": 1,
            "caption_json": make_caption_json(
                subject, action, setting, narrative,
                w=w, h=h, fps=fps, seconds=seconds),
            "caption": narrative,
        }],
    }
''')

nb.code('''
good_dir = OUTPUT_DIR / "my_dataset" / "train"
(good_dir / "videos").mkdir(parents=True, exist_ok=True)

records = [
    make_record(
        "episode_000001_clip000", seconds=17.4, w=256, h=256, fps=5,
        start=0, end=87,
        subject="A black robotic arm with articulated joints",
        action="grasps and relocates small objects across a white tray",
        setting="An indoor workspace with equipment on a wooden table",
        narrative=("A black robotic arm extends over a white tray on a wooden "
                   "table and repeatedly lifts and repositions small dark "
                   "objects, moving them methodically from one side to the "
                   "other under bright, even lighting."),
    ),
    make_record(
        "episode_000002_clip000", seconds=24.0, w=256, h=256, fps=5,
        start=0, end=120,
        subject="A robotic gripper with a blue accent near its base",
        action="picks up almonds and places them in a line",
        setting="A white rectangular tray on an indoor bench",
        narrative=("A robotic gripper moves over a white tray of scattered "
                   "almonds, picking each one up and setting it down in a "
                   "straight line across the tray, with the camera static "
                   "throughout."),
    ),
]

jsonl = good_dir / "video_dataset_file.jsonl"
jsonl.write_text("\\n".join(json.dumps(r) for r in records) + "\\n")

print(f"wrote {len(records)} records to {jsonl.relative_to(COURSE_ROOT)}")
print(f"{jsonl.stat().st_size} bytes")
print()
print("first record, abbreviated:")
first = json.loads(jsonl.read_text().splitlines()[0])
print(json.dumps({k: (v if k != "t2w_windows" else "[...1 window...]")
                  for k, v in first.items()}, indent=2))

print()
good = finetune.check_dataset(good_dir, kind="jsonl")
print("ok       :", good["ok"])
print("stats    :", json.dumps(good["stats"], indent=2))
for p in good["problems"]:
    print("problem  :", p)
for w in good["warnings"]:
    print("warning  :", w)
''')

# ------------------------------------------------- the silent filters
nb.md("""
## The two silent filters

`docs/dataset_jsonl.md` documents them in passing, in a sentence about the
converter: it "mirrors the loader's silent filters (clips longer than 61 s, and
windows shorter than `max(61, --num-video-frames)` frames)".

So:

- **A clip whose `duration` exceeds 61 seconds is dropped.** Whole record, gone.
- **A window shorter than 61 frames is dropped.** `end_frame - start_frame < 61`.

Neither raises. Neither warns. The dataset "loads successfully". If every record
is caught, you get an empty dataset, training starts, and the loss you see is
whatever a model does with no data — which in practice is a flat line, a
nonsense line, or an immediate `StopIteration` deep in the dataloader that gets
retried.

Note the asymmetry in the second filter: your window must be at least 61 frames
*of the source*, which at 5 FPS means at least 12 seconds of footage. If you
built your dataset from three-second clips, **every single record is invalid**
and nothing will tell you.

Build that dataset now, so you recognise it later.
""")

nb.code('''
poisoned_dir = OUTPUT_DIR / "poisoned" / "train"
poisoned_dir.mkdir(parents=True, exist_ok=True)

poisoned = [
    # Trap #1: a long clip. 75 s > 61 s, so the whole record is dropped.
    make_record(
        "episode_bad_long", seconds=75.0, w=256, h=256, fps=5,
        start=0, end=375,
        subject="A robotic arm", action="performs a long assembly sequence",
        setting="A workbench", narrative="A long, continuous assembly task."),
    # Trap #2: a short window. 40 frames < 61, so this window is dropped, and
    # since it is the record's only window the record contributes nothing.
    make_record(
        "episode_bad_short", seconds=8.0, w=256, h=256, fps=5,
        start=0, end=40,
        subject="A robotic arm", action="nudges a cup",
        setting="A workbench", narrative="A short nudge of a cup."),
]

poisoned_jsonl = poisoned_dir / "video_dataset_file.jsonl"
poisoned_jsonl.write_text("\\n".join(json.dumps(r) for r in poisoned) + "\\n")

# Every one of these is valid JSON. Every one has every required field.
for line in poisoned_jsonl.read_text().splitlines():
    rec = json.loads(line)
    win = rec["t2w_windows"][0]
    print(f"  {rec['uuid']:<20s} duration {rec['duration']:>5.1f}s  "
          f"window {win['end_frame'] - win['start_frame']:>3d} frames  "
          f"-> valid JSON, all fields present")
''')

# --------------------------------------------------------- debugging lab
nb.md("""
## Debugging lab — the dataset that loads fine and teaches nothing

### Symptom

You launch a fine-tune on the dataset above. Nothing errors. The process runs
for its full `max_iter`, writes checkpoints on schedule, and exits zero. Then
you look at the log.
""")

nb.code('''
# A synthetic log with the shape you would actually see. Read it before
# scrolling on -- what in here is wrong, and what is merely uninformative?
SYMPTOM_LOG = """\\
[INFO] loading dataset from examples/data/my_dataset/train
[INFO] dataset ready
[INFO] starting training: max_iter=100 grad_accum_iter=8
[INFO] iter: 1  loss: 0.0000  lr: 2.0e-06  grad_norm: 0.0000
[INFO] iter: 2  loss: 0.0000  lr: 4.0e-06  grad_norm: 0.0000
[INFO] iter: 3  loss: 0.0000  lr: 6.0e-06  grad_norm: 0.0000
[INFO] iter: 50 loss: 0.0000  lr: 1.0e-04  grad_norm: 0.0000
[INFO] saving checkpoint to checkpoints/iter_000000050
[INFO] iter: 100 loss: 0.0000 lr: 1.0e-04 grad_norm: 0.0000
[INFO] saving checkpoint to checkpoints/iter_000000100
[INFO] training complete
"""

log_path = OUTPUT_DIR / "symptom.log"
log_path.write_text(SYMPTOM_LOG)

watch = finetune.TrainingWatch(log_path).parse()
print(watch.summary())
''')

nb.md("""
### Hypotheses

`TrainingWatch` tells you the loss is not falling, which is true and not very
helpful. Four things produce a flat loss, and they need different fixes:

1. **The learning rate is zero or the schedule never leaves warmup.** Check
   `[scheduler].warm_up_steps` against `[trainer].max_iter`; if warmup is 500
   and you ran 100, the LR really is still climbing.
2. **`keys_to_select` matches nothing.** A typo in a substring means the
   optimizer's parameter list is empty, so nothing moves. Loss is constant,
   not zero.
3. **Gradients are being zeroed.** `[trainer.callbacks.grad_clip].force_finite`
   replaces NaN and Inf with zero — which turns a numerical explosion into a
   silent no-op.
4. **The dataset is empty.** No samples, no gradient, no movement.

Note the discriminator sitting in plain sight: `loss: 0.0000`, not
`loss: 3.9021` repeated. A model that is training on real data and failing to
improve has a *non-zero, constant* loss. A loss of exactly zero with a gradient
norm of exactly zero means **no data reached the loss function.** That points
hard at hypothesis 4.

### Diagnostic step

Check the dataset, which takes a second, before you check anything that takes
an hour.
""")

nb.code('''
diag = finetune.check_dataset(poisoned_dir, kind="jsonl")

print("ok       :", diag["ok"])
print("stats    :", json.dumps(diag["stats"], indent=2))
for p in diag["problems"]:
    print("PROBLEM  :", p)
for w in diag["warnings"]:
    print("warning  :", w)
''')

nb.md("""
### Repair

Two different faults, so two different repairs — and neither is "delete the bad
records", because that would leave you with an empty dataset either way.

**The long clip** must be *split*, not dropped. A 75-second clip at 5 FPS is 375
frames, which is six perfectly good 61-frame windows. Split it into shorter
clips (Cosmos Curator does this; so does `ffmpeg -segment`), or re-cut the
windows so each output clip's `duration` is under the limit.

**The short clip** cannot be repaired at all. Eight seconds at 5 FPS is 40
frames and the loader needs 61. You either re-encode it at a higher frame rate
so the frame count clears the bar — which invents no information but does
satisfy the filter — or you exclude it honestly and record that you did.

The general lesson: **validate before you launch.** A one-second check saves an
hour of training on nothing.
""")

nb.code('''
repaired_dir = OUTPUT_DIR / "repaired" / "train"
repaired_dir.mkdir(parents=True, exist_ok=True)

repaired = []
# Split the 75 s clip into 61-frame windows on 15 s sub-clips (5 FPS -> 75 frames).
for i in range(5):
    repaired.append(make_record(
        f"episode_bad_long_part{i}", seconds=15.0, w=256, h=256, fps=5,
        start=0, end=75,
        subject="A robotic arm", action="performs one step of an assembly",
        setting="A workbench", narrative=f"Assembly step {i + 1} of five."))

# The 8 s clip is excluded, on purpose, and we say so rather than quietly
# dropping it. An excluded clip you wrote down is data; one you forgot is a bug.
EXCLUDED = [{"uuid": "episode_bad_short",
             "reason": "8.0 s at 5 fps = 40 frames < the 61-frame window floor"}]

repaired_jsonl = repaired_dir / "video_dataset_file.jsonl"
repaired_jsonl.write_text("\\n".join(json.dumps(r) for r in repaired) + "\\n")
(repaired_dir / "excluded.json").write_text(json.dumps(EXCLUDED, indent=2))

verify = finetune.check_dataset(repaired_dir, kind="jsonl")
print("ok      :", verify["ok"])
print("stats   :", json.dumps(verify["stats"], indent=2))
print("excluded:", len(EXCLUDED), "clip(s), reasons written to excluded.json")
assert verify["ok"], "repair did not take -- read the problems above"
print()
print("VERIFIED: every remaining record survives both filters.")
''')

# ------------------------------------------------------ shipped recipes
nb.md("""
## The shipped recipes, with an honest verdict on each

Five recipes ship under `examples/toml/sft_config/`. Here is every one, with
what it trains, what it needs, and whether you can run it.

Read the `single_gpu` line on each. One says "plausible with overrides"; the
other four say no, for four different reasons. Being able to say *which* reason
applies is the difference between tuning a config and wasting a day. Two things
to look for specifically:

- **`action_policy_libero_10_nano` has no `keys_to_select` at all.** An empty
  allowlist means train everything, so this is a genuine full 16B SFT — the 352
  GB case you computed at the top of the lesson.
- **`sft_llava_ov` is the lowest-friction recipe in the repo** — no DCP
  conversion, no required environment variables, dataset streamed from the Hub —
  and it is still out of reach, because it is a full 8B fine-tune on the VLM
  (reasoner) path where LoRA is not available. Low friction is not the same as
  low cost. **DCP** there is PyTorch's *Distributed Checkpoint* format: the
  trainer loads DCP directories rather than Hugging Face safetensors, so most
  recipes need a conversion step first. Lesson 17 runs that conversion.
""")

nb.code('''
for name in sorted(finetune.SHIPPED_RECIPES):
    print(finetune.explain_recipe(name))
    print()
''')

nb.predict_run_explain(
    predict=(
        "From the arithmetic alone, predict the minimum number of GPUs the LIBERO "
        "action recipe needs. It is a full-parameter SFT of Cosmos3-Nano with EMA "
        "on. Take state per rank, divide by an 80 GB card with a 4 GB reserve, and "
        "round up. Write the number down. Then predict the number NVIDIA actually "
        "shipped."
    ),
    change=(
        "Nothing. Run the two cells below: the first computes your floor, the "
        "second shows the shipped configuration."
    ),
    explain=(
        "Your floor will be much lower than what shipped. Before you read the "
        "explanation, list three things a real rank has to hold that a pure-state "
        "calculation ignores. Then read the comment in the shipped TOML, which "
        "gives a reason you almost certainly did not think of."
    ),
    hint=(
        "352 GB divided by (80 − 4) GB per rank is about 4.6. Ceiling that. Now ask "
        "what each of those five ranks would have left for activations."
    ),
)

nb.code('''
state = est_nano.state_gb
usable_per_rank = CARD_GB - 4.0

floor = math.ceil(state / usable_per_rank)
print(f"state (full Nano SFT, EMA on) : {state:.0f} GB")
print(f"usable per rank               : {usable_per_rank:.0f} GB")
print(f"pure-state floor              : {floor} ranks")
print()
print("what each configuration leaves for activations:")
for ws in (floor, 8, 16):
    parts = hand_state_gb(NANO_B, NANO_B, ema=True, world_size=ws)
    print(f"  {ws:>2d} ranks -> state {parts['TOTAL']:5.1f} GB/rank, "
          f"activations {usable_per_rank - parts['TOTAL']:5.1f} GB/rank")

print()
# From examples/toml/sft_config/action_policy_libero_10_nano.toml, verbatim.
SHIPPED_LIBERO_PARALLELISM = """\\
[model.parallelism]
data_parallel_shard_degree     = 8
data_parallel_replicate_degree = 2    # HSDP 2x8 = 16 ranks (2 nodes); minimum for gbs 2048 at grad_accum 1

[trainer]
max_iter        = 2000
logging_iter    = 50
grad_accum_iter = 1       # global batch = max_samples 128 x (shard 8 x replicate 2) x 1 = 2048
"""
print(SHIPPED_LIBERO_PARALLELISM)

print("Predicted floor from memory alone :", floor, "ranks")
print("Shipped                           :",
      finetune.SHIPPED_RECIPES["action_policy_libero_10_nano"]["documented_gpus"],
      "ranks")
''')

nb.md("""
### Explaining the gap

Your memory floor said five. NVIDIA shipped sixteen. Three reasons, and the
third is the interesting one:

1. **Five ranks leaves ~6 GB per rank for activations**, which at
   `max_num_tokens_after_packing = 74000` is not enough to run a step. A floor
   computed from state alone is a floor, not a plan.
2. **FSDP's transient all-gather** materialises one unsharded layer at a time,
   plus communication buffers, on top of the sharded state.
3. **The global batch size chose the rank count.** Read the comment: *"minimum
   for gbs 2048 at grad_accum 1"*. They wanted a 2048-sample global batch,
   the packer fits 128 samples per rank, `grad_accum_iter` is 1, and
   `128 × 16 × 1 = 2048`. Sixteen ranks is a *statistics* decision that memory
   merely has to accommodate.

That third point matters to you directly. `grad_accum_iter` trades wall-clock
for rank count at constant global batch — which is exactly the substitution
Lesson 17 makes when it shrinks an 8-GPU recipe to one.
""")

nb.checkpoint(
    "Before moving on, confirm you can state the three numbers this lesson turns "
    "on, without scrolling up.",
    '''
answers = {
    "bytes per TRAINABLE param, EMA on, fp32 grads": 22,
    "bytes per FROZEN param": 2,
    "GB of state for a full Cosmos3-Nano SFT, shipped defaults": 352,
}
for question, value in answers.items():
    print(f"  {value:>4d}   {question}")

assert sum(finetune.BYTES_PER_PARAM.values()) == 22
assert round(est_nano.state_gb) == 352
print()
print("If any of those surprised you, re-read the derivation before Lesson 17.")
''')

# ------------------------------------------------------------ exercises
nb.md("""
## Exercises

Three, in increasing order of independence. The reference solutions are
complete and commented, but read them only after you have something of your own
to compare against.
""")

nb.exercise(
    "foundation",
    "Three memory bills, by hand",
    goal=(
        "Compute state memory for three configurations without using "
        "`estimate_sft_memory`, then check each against it and explain any "
        "difference."
    ),
    instructions=(
        "Fill in `by_hand()` below so it returns total state memory in GB. Then "
        "compute all three configurations:\n\n"
        "1. **Cosmos3-Nano, full SFT, most optimistic** — 100% trainable, bf16 "
        "   gradients (2 bytes), `ema.enabled = false`.\n"
        "2. **Cosmos3-Edge, generation pathway only** — 50% trainable, fp32 "
        "   gradients, `ema.enabled = true` (the shipped default).\n"
        "3. **Cosmos3-Super, LoRA rank 32** — assume the adapters come to 0.2% of "
        "   the 64B total, fp32 gradients, EMA off.\n\n"
        "For each, also report how much is left for activations on an 80 GB card "
        "with a 4 GB reserve, and give a one-line verdict.\n\n"
        "Then check 1 and 2 against `finetune.estimate_sft_memory`. For 3, the "
        "estimator's LoRA model will disagree with your 0.2% assumption — say by "
        "how much and which number you would defend."
    ),
    success=(
        "Configurations 1 and 2 agree with the estimator to within 0.2 GB. "
        "Configuration 3 has a written justification for the discrepancy. You can "
        "say, without looking, which single row dominates each bill."
    ),
    starter='''
def by_hand(total_b, trainable_b, *, grad_bytes=4, ema=True):
    """Return total state memory in decimal GB.

    Rows, from the derivation earlier in this lesson:
      bf16 weights   2 bytes x EVERY parameter
      fp32 master    4 bytes x trainable
      AdamW m        4 bytes x trainable
      AdamW v        4 bytes x trainable
      gradients      grad_bytes x trainable
      EMA copy       4 bytes x trainable, only when ema is True
    """
    # TODO: implement. Two lines is plenty.
    raise NotImplementedError


CONFIGS = [
    # (label, total_b, trainable_b, grad_bytes, ema)
    ("Nano full SFT, optimistic", 16, 16,          2, False),
    ("Edge gen-only, shipped",     4,  2,          4, True),
    ("Super LoRA r=32",           64, 64 * 0.002,  4, False),
]

for label, total_b, trainable_b, grad_bytes, ema in CONFIGS:
    # TODO: compute, print state, print activation budget, print a verdict.
    pass
''',
    hints=[
        "Every row except the first is `trainable_b * 1e9 * bytes / 1e9`, which "
        "simplifies to `trainable_b * bytes`. The first row is `total_b * 2`. You "
        "can write the whole function as one expression.\n\n"
        "For configuration 3, note that the bf16 weights row alone is "
        "64 × 2 = 128 GB, which is already more than the card. No adapter size "
        "changes that, so the discrepancy between your 0.2% and the estimator's "
        "heuristic does not affect the verdict at all. That is the answer you "
        "should be defending.",
    ],
    solution_ref="solutions/16_solutions.ipynb",
)

nb.exercise(
    "applied",
    "Build and validate a real JSONL dataset",
    goal=(
        "Turn video you actually have into a generator SFT dataset that survives "
        "both silent filters, with captions produced by the Module 1 reasoner "
        "rather than typed by you."
    ),
    instructions=(
        "Use clips you generated in Module 2 (`outputs/07/`, `outputs/08/`) or the "
        "cookbook assets. At least six clips.\n\n"
        "1. For each clip, read its real duration, frame count, width, height and "
        "   FPS with `ffprobe` — do not assume them. A wrong `duration` is trap #1 "
        "   waiting to happen.\n"
        "2. Caption each clip with the reasoner, using the structured-JSON schema "
        "   from Lesson 03. If the NIM is not running, fall back to the scene "
        "   records you already wrote to `outputs/03/`.\n"
        "3. Emit one JSONL record per clip in the `docs/dataset_jsonl.md` schema, "
        "   with `caption_json` populated from the reasoner's structured output "
        "   and `caption` from its narrative.\n"
        "4. Choose windows deliberately. Report, before validating, how many "
        "   records you expect each filter to remove.\n"
        "5. Validate with `finetune.check_dataset(..., kind='jsonl')` and iterate "
        "   until `ok` is True with zero warnings.\n"
        "6. Write an `excluded.json` recording every clip you dropped and why."
    ),
    success=(
        "`check_dataset` reports `ok: True`, `clips_over_61s: 0`, "
        "`windows_under_61_frames: 0`, and at least six records. Your predicted "
        "drop counts from step 4 match the reported ones. `excluded.json` accounts "
        "for every clip you started with."
    ),
    starter='''
import subprocess

def probe(path):
    """Real duration, dimensions and frame rate. Never guess these."""
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height,r_frame_rate,nb_frames",
         "-show_entries", "format=duration",
         "-of", "json", str(path)],
        capture_output=True, text=True, check=True).stdout
    info = json.loads(out)
    stream = info["streams"][0]
    num, _, den = stream["r_frame_rate"].partition("/")
    return {
        "width": int(stream["width"]),
        "height": int(stream["height"]),
        "fps": float(num) / float(den or 1),
        "frames": int(stream.get("nb_frames") or 0),
        "duration": float(info["format"]["duration"]),
    }


# TODO 1. Collect your clips.
CLIPS = sorted((cc.OUTPUT_ROOT / "07").glob("*.mp4"))

# TODO 2. Caption each one. Reuse Lesson 03's structured-caption prompt.
# TODO 3. Build records with make_record(); reuse it from earlier in this lesson.
# TODO 4. State your expected drop counts BEFORE running check_dataset.
# TODO 5. Validate and iterate.
# TODO 6. Write excluded.json.
''',
    hints=[
        "`nb_frames` is missing or wrong for a surprising number of MP4 files. "
        "Compute frames as `round(duration * fps)` and cross-check; if the two "
        "disagree by more than one, trust neither and decode the file.\n\n"
        "Windows do not have to start at frame 0, and one clip can carry several. "
        "A 200-frame clip gives you three non-overlapping 61-frame windows, which "
        "triples your record count from the same footage.",
    ],
    solution_ref="solutions/16_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "A fine-tuning feasibility planner",
    goal=(
        "Write `plan_finetune(model, gpus, vram_gb)` that returns a configuration "
        "that will fit, or an explanation of why none exists — and test it across "
        "a matrix of hardware so you find out where its reasoning breaks."
    ),
    instructions=(
        "The function takes a model tier name, a GPU count and per-GPU VRAM in GB. "
        "It returns a dict with at least: `feasible` (bool), `strategy` (one of "
        "`full`, `frozen`, `lora`, `none`), the settings that implement the "
        "strategy, the predicted state and activation budget, and `reasoning` — a "
        "list of the steps it took to get there.\n\n"
        "It must consider, in this order, and stop at the first that fits:\n"
        "1. full-parameter SFT;\n"
        "2. generation-pathway-only via `keys_to_select`;\n"
        "3. LoRA at rank 16, then 8, then 4.\n\n"
        "When nothing fits it must say **which** component is the blocker — and "
        "for the bf16-weights case it must say that no software setting can help, "
        "because that is a different kind of impossible from 'state is too big'.\n\n"
        "Then run it across the matrix in the starter and inspect every row. At "
        "least two rows should make you uncomfortable; work out whether the "
        "planner is wrong or your intuition is."
    ),
    success=(
        "Every cell of the matrix returns a verdict with reasoning attached. "
        "`plan_finetune('Cosmos3-Nano', 1, 80)` recommends LoRA or refuses. "
        "`plan_finetune('Cosmos3-Super', 1, 80)` refuses and names the bf16 "
        "weights, not the optimizer state, as the blocker. "
        "`plan_finetune('Cosmos3-Nano', 16, 80)` recommends full SFT. You have "
        "written down one case where you disagree with your own planner and why."
    ),
    starter='''
def plan_finetune(model, gpus, vram_gb, *, reserve_gb=4.0, min_activation_gb=10.0):
    """Return a feasible SFT configuration, or explain why none exists.

    Returns a dict with keys: feasible, strategy, settings, state_gb,
    activation_budget_gb, reasoning (list[str]).
    """
    tier = cc.MODEL_TIERS[model]
    total_b = float(tier["params_total_b"])
    reasoning = []

    # The floor no software setting can move: bf16 weights must be resident.
    weights_gb = total_b * 2 / gpus
    # TODO: if weights_gb alone exceeds (vram_gb - reserve_gb), refuse and say
    # that this is a wrong-hardware problem rather than a tuning problem.

    # TODO: try full SFT, then keys_to_select, then LoRA at 16 / 8 / 4.
    # TODO: for each, require at least min_activation_gb of headroom.
    raise NotImplementedError


MATRIX = [(m, g, v)
          for m in ("Cosmos3-Edge", "Cosmos3-Nano", "Cosmos3-Super")
          for g, v in ((1, 24), (1, 80), (4, 80), (8, 80), (16, 80), (8, 141))]

# TODO: run the matrix, tabulate, and read every row.
''',
    hints=[
        "`estimate_sft_memory` already takes `world_size`, `trainable_fraction`, "
        "`lora`, `lora_rank` and `card_gb`. Your planner can be mostly a search "
        "over its arguments — the value you add is the ordering, the "
        "`min_activation_gb` floor, and the explanation.\n\n"
        "The uncomfortable rows are the ones where the planner says yes and you "
        "would not: `Cosmos3-Nano` on 4×80 with LoRA, for instance. State fits "
        "there. Whether 2000 iterations at that global batch teaches the model "
        "anything is a different question, and your planner cannot answer it — so "
        "it should say so rather than imply otherwise.",
    ],
    solution_ref="solutions/16_solutions.ipynb",
)

# ------------------------------------------------------------ assessment
nb.md("""
## Assessment

### Knowledge check

Answer from memory, then open the answers.

1. A parameter is frozen by `keys_to_select`. How many bytes does it cost, and
   why is it not zero?
2. You turn `activation_checkpointing.mode` from `"none"` to `"full"` on a full
   Nano SFT that OOMs during optimizer construction. What happens, and why?
3. `ema.enabled` defaults to `true`. What does that cost, in bytes per trainable
   parameter, and what does it buy in a 100-iteration run?
4. Why can you LoRA the generator but not the reasoner?
5. A JSONL dataset has 400 records, all valid JSON, all with every required
   field. `check_dataset` reports `ok: False`. Name the two most likely causes.
6. The LIBERO recipe uses 16 ranks. Memory arithmetic suggests 5. Give the
   reason that has nothing to do with memory.
""")

nb.code('''
# Write your answers here first, in your own words, and run the cell. Checking
# an answer you have committed to is worth several times reading one you nod at.
MY_ANSWERS = {
    1: "",   # a frozen parameter costs how many bytes, and why is it not zero?
    2: "",   # activation checkpointing, on a run that OOMs building the optimizer
    3: "",   # what ema.enabled costs per parameter, and what it buys in 100 iters
    4: "",   # why LoRA is available on the generator and not on the reasoner
    5: "",   # 400 valid records, check_dataset says ok: False. Two likely causes.
    6: "",   # 16 ranks against a memory floor of 5: the reason that is not memory
}

answered = [k for k, v in MY_ANSWERS.items() if v.strip()]
answers_path = OUTPUT_DIR / "knowledge_check.json"
answers_path.write_text(json.dumps(MY_ANSWERS, indent=2))

print(f"answered {len(answered)} of {len(MY_ANSWERS)}"
      f"  ->  {answers_path.relative_to(COURSE_ROOT)}")
if len(answered) < len(MY_ANSWERS):
    print("Fill in the blanks and re-run before you open the answers below.")
''')

nb.answer("""
1. **Two bytes** — its bf16 copy. The forward pass still has to multiply by it.
   What it does not pay is the fp32 master, `m`, `v`, gradients and EMA, so it
   costs 2 rather than 22.

2. **It does not help, and it makes the run slower before it fails.** The OOM
   happened while allocating optimizer state, which is before any activation
   exists. Activation checkpointing only affects memory that is allocated
   during the forward pass. *Where* an OOM occurs tells you which lever applies.

3. **Four bytes per trainable parameter** — a full fp32 copy. It buys a smoothed
   set of weights for inference, which matters over a long run and is
   indistinguishable from noise over 100 iterations. Turn it off; it is the
   largest free saving available.

4. Because upstream chose to. `docs/sft_config.md` marks the whole
   `lora_*` block **VFM only**, and the VFM↔VLM path-remap table skips
   `model.lora_*` on the VLM path. The default `lora_target_modules` are the
   generation expert's attention projections (`q_proj_moe_gen` and siblings),
   which do not exist on the reasoner path.

5. Either **every record was filtered out** (clips over 61 s, windows under 61
   frames) or the JSONL is not where the loader expects it. `check_dataset`
   distinguishes them: the first reports non-zero `clips_over_61s` or
   `windows_under_61_frames`, the second reports that no `.jsonl` was found.

6. **Global batch size.** The shipped TOML says so in a comment: 16 ranks is
   the *minimum for gbs 2048 at grad_accum 1*. They wanted a 2048-sample global
   batch and the packer fits 128 per rank. Memory then has to accommodate a
   decision that statistics made.
""")

nb.code('''
# ---------------------------------------------------------------------------
# What this lesson produced, and the numbers it turns on. Recomputed here rather
# than remembered, so the summary below is something you can check.
# ---------------------------------------------------------------------------
ARTEFACTS = {
    "my_dataset/train/video_dataset_file.jsonl": "the dataset you wrote by hand",
    "poisoned/train/video_dataset_file.jsonl":   "the one that loads and teaches nothing",
    "repaired/train/video_dataset_file.jsonl":   "the repair",
    "symptom.log":                               "the log you diagnosed",
}
for rel, what in ARTEFACTS.items():
    path = OUTPUT_DIR / rel
    print(f"  [{'ok     ' if path.exists() else 'MISSING'}] {rel:<44s} {what}")

frozen_bytes = finetune.BYTES_PER_PARAM["weights_bf16"]
trainable_bytes = sum(finetune.BYTES_PER_PARAM.values())

print()
print(f"bytes per FROZEN parameter       : {frozen_bytes}")
print(f"bytes per TRAINABLE parameter    : {trainable_bytes}   (EMA on, fp32 grads)")
print(f"ratio                            : {trainable_bytes / frozen_bytes:.0f}x")
print(f"full Nano SFT, shipped defaults  : {est_nano.state_gb:.0f} GB of state")
print(f"full Nano SFT, most optimistic   : {nano_best['TOTAL']:.0f} GB of state")
print(f"LoRA at d={D_MODEL}, r={RANK}             : "
      f"{D_MODEL / (2 * RANK):.0f}x fewer trainable parameters per matrix")
''')

nb.md("""
### Practical completion test

You have finished this lesson when, without scrolling back:

- You can write the six-row memory table from memory and get 352 GB for a full
  Nano SFT.
- You can point at the exact line in a shipped TOML that decides whether the
  bill is 256 GB or 352 GB. (There are two: `[model.ema].enabled` and the
  gradient precision implied by `[model].precision`.)
- You can write a valid JSONL record and name both silent filters and their
  thresholds.
- `outputs/16/` contains your dataset, your poisoned dataset, and your planner.

### Summary

- **Pre-training** builds capability, **SFT** redirects it, **RLHF** optimises
  against preferences you can rank but not write, and **LoRA** is a
  parameterisation that any of them can use.
- A **trainable** parameter costs 16–22 bytes during mixed-precision AdamW; a
  **frozen** one costs 2. That 8–11× ratio is the entire economics of
  single-GPU fine-tuning.
- Full Cosmos3-Nano SFT needs **256–352 GB** of state depending on two config
  lines. That is 3–4 H100s before any activation exists.
- **Activation checkpointing cannot fix a state problem.** Diagnose where the
  OOM happened before choosing a lever.
- **FSDP divides every row of the table by the rank count**, which is exactly
  why the shipped recipes are shaped the way they are — and it is unavailable at
  world size 1.
- **LoRA replaces `d²` parameters with `2rd`**, a factor of `d/2r`. It is
  generator-only in Cosmos 3.
- Generator datasets are **JSONL** with a `caption_json` per window; action
  datasets are **LeRobotDataset v3.0**, not v2.
- Two loader filters drop data **silently**: clips over 61 seconds, windows
  under 61 frames. Validate before you launch.
- The shipped rank counts are not purely memory decisions. **Global batch size
  chose the LIBERO recipe's sixteen ranks**, and `grad_accum_iter` is how you
  substitute time for hardware.
""")

nb.code('''
# The numeric half of the misconceptions table below, tested rather than told.
nano_weights_gb = NANO_B * 2.0
super_weights_gb = cc.MODEL_TIERS["Cosmos3-Super"]["params_total_b"] * 2.0

print("1. 'The model is 32 GB, so training needs a bit more than 32 GB'")
print(f"   bf16 weights {nano_weights_gb:.0f} GB, full state {est_nano.state_gb:.0f} GB"
      f"  ->  {est_nano.state_gb / nano_weights_gb:.0f}x the weights")

print("2. 'Gradient checkpointing fixes OOM'")
verdict = "it fits" if est_nano.state_gb <= CARD_GB else "it still does not fit"
print(f"   state alone is {est_nano.state_gb:.0f} GB on an {CARD_GB:.0f} GB card:")
print(f"   with activations at exactly zero, {verdict}")

print("3. 'LoRA makes any model fit'")
print(f"   Cosmos3-Super's bf16 weights are {super_weights_gb:.0f} GB before any")
print(f"   optimizer state at all, and no adapter changes that number")
''')

nb.md("""
### Common misconceptions

| Belief | Correction |
|---|---|
| "The model is 32 GB, so training needs a bit more than 32 GB" | Training needs 8–11× the weights. The weights are the smallest line in the bill. |
| "Gradient checkpointing fixes OOM" | Only activation OOM. It does nothing for optimizer state, which is what blocks Nano. |
| "EMA is a training-quality setting" | It is also a full fp32 copy of every trainable parameter, on by default, worth nothing over 100 iterations. |
| "LoRA makes any model fit" | LoRA removes optimizer state. The frozen bf16 weights remain, and for Super those alone are 128 GB. |
| "`keys_to_select = []` trains nothing" | Empty means train **everything**. The LIBERO recipe relies on exactly that. |
| "A dataset that loads is a dataset that works" | Two filters drop records silently. A loss of exactly 0.0000 is the signature. |
| "More GPUs is a memory decision" | Sometimes it is a batch-size decision, and the shipped TOML says so in a comment. |
| "LeRobot v2 and v3 are compatible enough" | They are not. `codebase_version` is checked and a v2 dataset will not load. |

### Suggested extensions

- Read `d_model`, the layer count and the actual projection shapes out of a
  Cosmos3-Edge `config.json` and redo the LoRA count with real numbers. Compare
  against both your estimate and the course estimator's 0.1%-per-rank heuristic,
  and decide which you would put in a report.
- Extend `hand_state_gb` with an activation model: activation memory is roughly
  proportional to `max_num_tokens_after_packing × d_model × n_layers × bytes`,
  divided by roughly the layer count when checkpointing is `full`. Then predict
  Lesson 17's peak memory before you get there, and see how badly you do.
- Work out what an 8-bit optimizer would buy, then confirm from
  `SFTExperimentConfig` that Cosmos 3 does not offer one. Knowing the size of a
  lever you do not have is how you decide whether to go looking for a
  framework that does.
""")

nb.code('''
# The hand-off. This is the recipe Lesson 17 attempts and the settings it uses.
# You derive every one of them there; read them now so the derivation has
# something to land on.
print(finetune.explain_recipe("vision_sft_edge"))
print()
print("Lesson 17's overrides, previewed:")
for key, value in finetune.single_gpu_overrides(
        token_cap=12288, grad_accum=8, max_iter=20, save_iter=20).items():
    print(f"  {key} = {value}")

edge_preview = finetune.estimate_sft_memory(
    "Cosmos3-Edge", trainable_fraction=0.5, ema=False, card_gb=CARD_GB)
print()
print(f"state under those settings : {edge_preview.state_gb:.1f} GB")
print(f"left for activations       : {edge_preview.activation_budget_gb:.1f} GB")
print()
print("Write your answer down before Lesson 17: does that fit on one card?")
''')

nb.md("""
### Mastery checklist

- [ ] I derived the per-parameter memory table without looking it up.
- [ ] I computed 352 GB for a full Nano SFT by hand before running the estimator.
- [ ] I can explain why activation checkpointing does not rescue that run.
- [ ] I can state the byte cost of a frozen versus a trainable parameter.
- [ ] I predicted a LoRA parameter count and verified it.
- [ ] I know why LoRA is unavailable on the reasoner path.
- [ ] I can explain what FSDP does to each row of the table.
- [ ] I built a valid JSONL dataset and validated it.
- [ ] I diagnosed a fully-filtered dataset from a training log alone.
- [ ] I wrote a planner that refuses a job and explains which component blocks it.

Lesson 17 takes the one recipe this lesson said was plausible and attempts it.
Write your prediction down before you start.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "16_posttraining_concepts.ipynb")
