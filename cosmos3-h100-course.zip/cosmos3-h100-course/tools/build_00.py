"""Build 00_environment_check.ipynb.

Lesson 00 — "What machine am I actually on?"

The lesson that prevents three hours of confusion later. It builds
``probe_environment()`` up from its parts rather than calling it, because a
learner who has only ever called it cannot debug it in Lesson 06 when it
disagrees with reality.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
nb = Notebook("Lesson 00 — What machine am I actually on?")

# ===========================================================================
# 1. Title block
# ===========================================================================
nb.md("""
# Lesson 00 — What machine am I actually on?

**What you will build.** A written, machine-readable record of this computer —
CPU architecture, driver, CUDA, GPU identity, VRAM, disk, Docker — saved to
`outputs/00/env_report.json`, plus the ability to reconstruct every field of it
by hand when the record and reality disagree.

**Time.** About 40 minutes.

**GPU needed.** Only near the end, and only to identify itself. Nothing here
loads a model.

**Downloads.** None required. One optional Docker image pull (~200 MB) behind a
flag you set yourself.

**Prerequisites.** A Linux shell and the course environment from
`scripts/setup.sh`. Nothing Cosmos-specific — this is the first lesson.
""")

# ===========================================================================
# 2. Learning objectives
# ===========================================================================
nb.md("""
## Learning objectives

By the end of this lesson you will be able to:

- **Measure** this machine's OS, CPU architecture, glibc version and Python
  version, and **decide** from those four facts alone whether the Cosmos
  Framework can be installed here at all.
- **Distinguish** the driver CUDA version from the runtime CUDA version, and
  **predict** which mismatch breaks a run and which is harmless.
- **Detect** the GPU's compute capability and **explain** what capability 9.0
  makes available that 8.0 does not.
- **Measure** allocated, reserved and driver-reported VRAM for one known tensor,
  and **explain** why the three numbers differ without anything being wrong.
- **Compute** a VRAM and disk budget for the whole course and **compare** it
  against what this machine actually has.
- **Debug** a single-GPU machine whose only GPU has been hidden by an inherited
  `CUDA_VISIBLE_DEVICES` setting, from symptom to verified repair.
""")

# ===========================================================================
# 3. Conceptual foundation
# ===========================================================================
nb.md("""
## Why we start here

The most common failure in this field is not a bug in your code. It is
discovering, an hour into a download, that a package was built for a different
CPU architecture, or that the CUDA your PyTorch was compiled against is newer
than the driver installed on the box, or that the "80 GB" GPU already has 62 GB
held by a container you forgot about.

Every one of those failures announces itself as something else. A wheel built
for `aarch64` on an `x86_64` machine says `No matching distribution found`. A
driver older than the runtime says `CUDA error: no kernel image is available for
execution on the device`. A GPU that is already full says `CUDA out of memory`
and invites you to reduce your batch size, which will not help, because the
memory was never yours to begin with.

So the first thing this course does is write down what this machine is. Not what
it should be, or what the documentation assumed — what it is, measured, in a file
you can point at later.

### The seven things worth knowing

| # | Layer | What you measure | What it decides |
|---|---|---|---|
| 1 | Host | OS, CPU architecture, glibc, Python | Whether the framework installs at all |
| 2 | CUDA | Driver version against runtime version | Whether compiled kernels will load |
| 3 | GPU identity | Name, compute capability | Which kernels and precisions exist |
| 4 | VRAM | Total, free, reserved, allocated | Which model tiers fit |
| 5 | Budget | One card shared between two workloads | Whether you can serve and generate at once |
| 6 | Disk | Free space against the course's ~150 GB | How far you get before you run out |
| 7 | Tooling | Docker, GPU passthrough, registry login | Whether Lessons 02–05 can start |

We build each layer by hand, then — and only then — look at the helper in
`cosmos_course.config` that wraps all seven.

One design rule runs through all of it: **every probe returns `None` rather than
raising when a tool is missing.** A diagnostic that dies on the first thing it
cannot find tells you about that one thing and nothing else; a diagnostic that
degrades tells you about all seven layers and marks the gaps. The assessment at
the end asks you to argue with that choice.
""")

# ===========================================================================
# 4. Environment and prerequisites
# ===========================================================================
nb.md("""
## Environment and prerequisites

Run the configuration cell first. Everything below reads from it. It resolves the
course root by walking up from wherever Jupyter happens to be running, so it does
not care where you cloned this repository, and it never hard-codes a path.
""")

nb.code('# This lesson writes to outputs/00/. The setup cell below reads this name.\n'
        '__lesson__ = "00"\n\n' + SETUP_CELL)

nb.md("""
Now a verification cell, plus the one utility every layer below uses.

The verification's job is to fail *now*, with a message you can act on, rather
than twenty cells from now with a `NameError`. Note what it does **not** require:
a GPU. This is the lesson that tells you whether you have a working GPU, so
refusing to run without one would be circular. A missing GPU is a finding here,
not an error.

`run_cmd` is the shape every probe in this course takes: the caller gets either a
result or a sentence explaining why there is no result, and can carry on either
way.
""")

nb.code('''
import platform
import shutil
import subprocess


def run_cmd(argv, timeout=30):
    """Run a command; return (stdout, error_message). Never raises."""
    if shutil.which(argv[0]) is None:
        return None, f"{argv[0]} is not on PATH"
    try:
        done = subprocess.run(argv, capture_output=True, text=True,
                              timeout=timeout, check=True)
    except subprocess.CalledProcessError as exc:
        return None, f"{argv[0]} exited {exc.returncode}: {(exc.stderr or '').strip()[:200]}"
    except (OSError, subprocess.SubprocessError) as exc:
        return None, f"{type(exc).__name__}: {exc}"
    return done.stdout.strip(), None


problems = []
if sys.version_info < (3, 10):
    problems.append(
        f"Python {platform.python_version()} is too old; the Cosmos Framework needs "
        f">= 3.10. Re-run scripts/setup.sh and select the 'Cosmos 3 (H100)' kernel."
    )
for name in ("probe_environment", "vram_budget", "MODEL_TIERS", "memory_snapshot"):
    if not hasattr(cc, name):
        problems.append(f"cosmos_course has no attribute {name!r} — partial checkout? "
                        f"Check: print(cc.__file__)")

cc.require(not problems, "This lesson cannot start:\\n  - " + "\\n  - ".join(problems),
           fix="Fix the items above, restart the kernel, and re-run this cell.")
print(f"prerequisites ok — cosmos_course from {cc.__file__}")
''')

# ===========================================================================
# 5. Guided lab
# ===========================================================================
nb.md("""
## Guided lab: build the probe, one layer at a time

`cosmos_course.config.probe_environment()` already does everything in this
section. We are going to ignore it until the end and write each piece by hand.

The reason is not purity. It is that in Lesson 06 the probe will tell you
something that contradicts what you see, and at that point "call the helper" is
not a debugging strategy. Knowing which system call produced each number is.

### Layer 1 — the host

Four facts, all from the Python standard library, none of which need a GPU.

- **Operating system.** The Cosmos Framework supports Linux only. There is no
  Windows or macOS build; WSL2 counts as Linux here.
- **CPU architecture.** `x86_64` or `aarch64`. This is the most common cause of a
  wheel refusing to install, and the error never says "architecture" — it says
  "no matching distribution found".
- **glibc version.** CUDA wheels are built against glibc 2.35 or newer (Ubuntu
  22.04). On an older base image a wheel installs happily and then fails at
  import with a `GLIBC_2.3x not found` message that reads like a corrupt file.
  Watch for an *empty* answer too: `platform.libc_ver()` returns `('', '')` on a
  musl system such as Alpine, and musl cannot run these wheels at all — so blank
  is a hard stop, not a shrug. Confirm with `ldd --version`.
- **Python version.** `>= 3.10`, from the framework's `pyproject.toml`.

The cell below separates *facts* from *verdicts* on purpose. The facts are true
regardless of what you are installing; the thresholds belong to the Cosmos
Framework (`COSMOS3_FACTS.md` §3) and will move.
""")

nb.code('''
import re

host = {
    "os": platform.system(),
    "os_release": platform.release(),
    "machine": platform.machine(),
    "libc": " ".join(platform.libc_ver()),
    "python": platform.python_version(),
    "cpu_count": os.cpu_count(),
}
for key, value in host.items():
    print(f"  {key:<12} {value}")


def version_tuple(text):
    """Turn '2.35' or '12.8.1' into a comparable tuple. Empty input -> (0,)."""
    parts = [int(c) for c in re.split(r"[^0-9]+", str(text or "")) if c]
    return tuple(parts) or (0,)


libc_version = host["libc"].split(" ")[-1] if host["libc"] else ""
host_verdicts = [
    ("Linux", host["os"] == "Linux", host["os"]),
    ("x86_64 or aarch64", host["machine"] in ("x86_64", "aarch64"), host["machine"]),
    ("glibc >= 2.35", version_tuple(libc_version) >= (2, 35), host["libc"] or "unknown"),
    ("Python >= 3.10", version_tuple(host["python"]) >= (3, 10), host["python"]),
]
print()
for label, ok, observed in host_verdicts:
    print(f"  [{'ok ' if ok else 'NO '}] {label:<20} observed: {observed}")
host_ok = all(ok for _, ok, _ in host_verdicts)
''')

# --- Layer 2 ---------------------------------------------------------------
nb.md("""
### Layer 2 — the two CUDA versions

This confuses everyone, once, permanently. There are two CUDA version numbers on
your machine and they mean different things.

**The driver CUDA version** is what `nvidia-smi` prints in the top-right corner.
It is not the version of CUDA you have installed. It is *the highest CUDA runtime
version this driver is capable of supporting*. A driver reporting "CUDA Version:
13.0" will happily run a program compiled against 12.8, 12.4 or 11.8.

**The runtime CUDA version** is what `torch.version.cuda` prints. It is the
version of the CUDA toolkit your PyTorch build was *compiled against*, baked into
the wheel you installed. `nvcc --version` is a third number and is almost never
the one you want: it reports whichever compiler is on your PATH, and PyTorch
ships compiled kernels and never invokes it at runtime.

The rule that matters:

```
driver CUDA version  >=  runtime CUDA version   ->  fine, even if they differ
driver CUDA version  <   runtime CUDA version   ->  broken
```

Broken looks like `CUDA error: no kernel image is available for execution on the
device`, or an import that segfaults, or `forward compatibility was attempted on
non-supported HW`. It does not look like a version error. The fix is to update
the driver or install a PyTorch built against an older CUDA — never to install
another CUDA toolkit alongside, which is what everyone tries first.

Start with the raw thing: read the header block `nvidia-smi` prints and find both
numbers with your own eyes, then let code parse the machine-readable form.
(Parsing the pretty table with a regular expression is fragile; the layout
changes between driver releases.)

Two cells follow. The first reads the header and enumerates the GPUs. The second
reads the driver's *CUDA* version — which is a separate query, not one of the
`--query-gpu` fields — alongside what PyTorch was built with, and compares them.
""")

nb.code('''
smi_text, smi_err = run_cmd(["nvidia-smi"])
if smi_text is None:
    print(f"nvidia-smi unavailable: {smi_err}")
    print("  Either no NVIDIA driver is installed, or you are in a container "
          "started without --gpus. Both are findings; keep going.")
else:
    print("\\n".join(smi_text.splitlines()[:11]))   # header only; skip the process table

gpu_rows = []
query, query_err = run_cmd([
    "nvidia-smi",
    "--query-gpu=index,name,driver_version,memory.total,memory.free,compute_cap",
    "--format=csv,noheader,nounits",
])
for line in (query or "").splitlines():
    cells = [c.strip() for c in line.split(",")]
    if len(cells) >= 6:
        gpu_rows.append(dict(zip(
            ("index", "name", "driver", "vram_total_mib", "vram_free_mib", "compute_cap"),
            cells)))

print()
for row in gpu_rows:
    print(f"  [{row['index']}] {row['name']}   driver {row['driver']}   "
          f"cc {row['compute_cap']}")
    print(f"       VRAM {row['vram_total_mib']} MiB total, {row['vram_free_mib']} MiB free")
if not gpu_rows:
    print(f"  (no GPUs enumerated: {query_err})")
''')

nb.code('''
driver_cuda = None
compute_text, compute_err = run_cmd(["nvidia-smi", "--query", "--display=COMPUTE"])
if compute_text:
    match = re.search(r"CUDA Version\\s*:\\s*([\\d.]+)", compute_text)
    if match:
        driver_cuda = match.group(1)

torch_version = None
runtime_cuda = None
cuda_available = False
try:
    import torch

    torch_version = torch.__version__
    runtime_cuda = torch.version.cuda
    cuda_available = bool(torch.cuda.is_available())
except ImportError:
    print("torch is not installed in this kernel — run scripts/setup.sh")

print(f"  driver CUDA  (nvidia-smi)        : {driver_cuda or 'unknown'}")
print(f"  runtime CUDA (torch.version.cuda): {runtime_cuda or 'unknown'}")
print(f"  torch                            : {torch_version or 'not installed'}")
print(f"  torch.cuda.is_available()        : {cuda_available}\\n")

if driver_cuda and runtime_cuda:
    if version_tuple(driver_cuda) >= version_tuple(runtime_cuda):
        print(f"  ok  driver {driver_cuda} >= runtime {runtime_cuda}")
        if version_tuple(driver_cuda) != version_tuple(runtime_cuda):
            print("      They differ, and that is normal: the driver supports up to "
                  "its own version and your build asks for less.")
    else:
        print(f"  PROBLEM  driver {driver_cuda} < runtime {runtime_cuda}. Kernels "
              f"compiled for the newer CUDA will not load. Update the driver, or "
              f"install a torch built against an older CUDA.")
elif cuda_available:
    print("  One of the two versions could not be read, but torch reports CUDA is "
          "available — which is the test that actually matters.")
else:
    print("  Neither version could be read and torch cannot see a GPU. Layers 3 "
          "and 4 will be empty; that is the finding.")
''')

# --- Layer 3 ---------------------------------------------------------------
nb.md("""
### Layer 3 — GPU identity and compute capability

**Compute capability** is a version number for the GPU's instruction set, written
`major.minor`. It is not a performance rating and not a memory size. It tells you
which instructions exist.

| Capability | Architecture | Example | What it adds |
|---|---|---|---|
| 8.0 | Ampere | A100 | bf16 tensor cores |
| 8.6 / 8.9 | Ampere / Ada | RTX 30xx, L40S | 8.9 adds FP8 tensor cores |
| **9.0** | **Hopper** | **H100** | FP8 tensor cores, thread-block clusters, TMA |
| 10.0 | Blackwell | B200 | FP4, further FP8 throughput |

Two consequences for this course, both from `COSMOS3_FACTS.md` §3 and §4:

1. The Cosmos Framework picks its attention backend by architecture. Hopper gets
   `flash-attn-3-nv`, Ada and Ampere get `flash-attn`, Blackwell gets `natten`.
   FlashAttention-3 was written around Hopper's asynchronous copy and warp-group
   instructions, so it is not "the newer one you could run anywhere".
2. The Reasoner NIM needs capability 8.0 for BF16 and 8.9 for FP8. On an H100
   both exist, which is why one card can serve the 32B Super *reasoner* at FP8 —
   a fact Lesson 15 returns to.

Detect it. Do not assume it, even if you are certain what you rented. And compare
the two sources: `nvidia-smi` talks to the driver and ignores
`CUDA_VISIBLE_DEVICES`, while PyTorch honours it, so a disagreement between them
is diagnostic rather than mysterious.
""")

nb.code('''
gpu = {"count": 0, "names": [], "capability": None, "vram_total_gb": []}
if cuda_available:
    gpu["count"] = torch.cuda.device_count()
    for i in range(gpu["count"]):
        props = torch.cuda.get_device_properties(i)
        gpu["names"].append(props.name)
        gpu["vram_total_gb"].append(props.total_memory / (1024 ** 3))
        if i == 0:
            gpu["capability"] = torch.cuda.get_device_capability(i)
        print(f"  [{i}] {props.name}  —  {props.total_memory / (1024 ** 3):.1f} GiB, "
              f"{props.multi_processor_count} SMs")
else:
    print("  torch cannot see a GPU.")

print(f"\\n  nvidia-smi sees {len(gpu_rows)} GPU(s); torch sees {gpu['count']}")
if len(gpu_rows) != gpu["count"]:
    print("  MISMATCH — the usual cause is CUDA_VISIBLE_DEVICES.")
    print(f"    CUDA_VISIBLE_DEVICES = {os.environ.get('CUDA_VISIBLE_DEVICES', '(not set)')!r}")
else:
    print("  The two sources agree.")

if gpu["capability"]:
    cap = gpu["capability"]
    print(f"\\n  compute capability {cap[0]}.{cap[1]}")
    print(f"    bf16 tensor cores (needs >= 8.0): {cap >= (8, 0)}")
    print(f"    FP8 tensor cores  (needs >= 8.9): {cap >= (8, 9)}")
    print(f"    Hopper features   (needs == 9.0): {cap == (9, 0)}")
''')

nb.callout(
    "h100",
    "If that printed capability 9.0 you are on Hopper and the H100-specific notes "
    "throughout this course apply directly. On 8.6 or 8.9 everything still runs — "
    "the framework falls back to `flash-attn` and BF16 — but wall-clock numbers "
    "will not match anything this course measures. That is fine, because this "
    "course measures on *your* machine rather than quoting.",
)

# --- Layer 4 ---------------------------------------------------------------
nb.md("""
### Layer 4 — VRAM on a discrete GPU

This is the conceptual core of the lesson. Four numbers describe GPU memory and
they are routinely mistaken for each other.

An H100 is a **discrete** GPU: it has its own HBM framebuffer, physically
separate from host RAM. Nothing your process does to host memory affects VRAM,
and nothing it does to VRAM affects host memory.

| Number | Where it comes from | What it means |
|---|---|---|
| **total** | `torch.cuda.mem_get_info()[1]` | The size of the framebuffer |
| **free** | `torch.cuda.mem_get_info()[0]` | What the driver could still hand out, *device-wide* |
| **reserved** | `torch.cuda.memory_reserved()` | What PyTorch has taken from the driver and is holding |
| **allocated** | `torch.cuda.memory_allocated()` | What your live tensors are using |

The relationship is always:

```
allocated  <=  reserved  <=  what nvidia-smi shows for your process  <=  total
```

The two gaps are where the confusion lives.

**reserved minus allocated** is PyTorch's caching allocator. When a tensor is
freed, PyTorch does not give the memory back to the driver, because `cudaMalloc`
and `cudaFree` are slow and synchronising. It keeps the block for reuse. So
`reserved` ratchets upward and does not come down on its own. That gap is cache.
**It is not a leak.**

**nvidia-smi minus reserved** is mostly the CUDA context — roughly 0.3 to 0.6 GB
of driver bookkeeping, kernel images and cuBLAS/cuDNN workspaces that appear the
moment a process touches the GPU. It is real memory, you cannot avoid it, and you
did not allocate it.

Start with a baseline reading before anything is allocated.
""")

nb.code('''
baseline = cc.memory_snapshot(include_smi=True)
print(baseline)
''')

nb.predict_run_explain(
    predict=(
        "The next cell allocates a single float32 tensor of exactly 1 GiB "
        "(2^28 elements x 4 bytes). Write down three numbers before you run it: "
        "what `memory_allocated()` will report, what `memory_reserved()` will "
        "report, and what `nvidia-smi` will report for the whole device. All in "
        "decimal GB, so 1 GiB is 1.074."
    ),
    change=(
        "Edit the three values in the `PREDICTION` dictionary at the top of the "
        "cell. Guessing is fine — committing to a guess is the point."
    ),
    explain=(
        "Which of your three numbers was furthest off, and in which direction? "
        "State in one sentence what occupies the difference between "
        "`memory_reserved()` and what `nvidia-smi` reports."
    ),
    hint=(
        "The tensor is uninitialised, so nothing is copied — this is a pure "
        "allocation. And has anything else on this machine already touched the "
        "GPU? The `nvidia-smi` figure is device-wide, not per-process."
    ),
)

nb.code('''
# Edit these three predictions BEFORE running this cell. Decimal GB.
PREDICTION = {
    "memory_allocated_gb": 1.0,
    "memory_reserved_gb": 1.0,
    "nvidia_smi_used_gb": 1.0,
}

GIB = 1024 ** 3
big = None
after_alloc = baseline

if cuda_available:
    cc.reset_peak_memory()
    big = torch.empty(2 ** 28, dtype=torch.float32, device="cuda")   # 1 GiB exactly
    torch.cuda.synchronize()
    after_alloc = cc.memory_snapshot(include_smi=True)
    measured = {
        "memory_allocated_gb": after_alloc.torch_allocated_gb,
        "memory_reserved_gb": after_alloc.torch_reserved_gb,
        "nvidia_smi_used_gb": after_alloc.smi_used_gb,
    }
    print(f"  tensor requested: {big.numel() * big.element_size() / 1e9:.3f} GB "
          f"(= {big.numel() * big.element_size() / GIB:.3f} GiB)\\n")
    for key, predicted in PREDICTION.items():
        actual = measured.get(key)
        shown = "n/a" if actual is None else f"{actual:.3f}"
        error = "" if actual is None else f"   (off by {actual - predicted:+.3f})"
        print(f"  {key:<22} predicted {predicted:>6.2f}   measured {shown:>7}{error}")
else:
    print("no CUDA device — skipping the allocation experiment")
''')

nb.md("""
Now free it. Predict this one silently first: after `del big`, what will
`allocated` be, and what will `reserved` be?

`allocated` will go to roughly zero. `reserved` will not move — and that is the
single most misread pair of numbers in PyTorch. The 1 GiB block is still owned by
your process, sitting in a pool, waiting to serve the next allocation of a
similar size without a round trip to the driver. Nothing has leaked.

`torch.cuda.empty_cache()` hands the unused pool back to the driver. It is useful
for making a measurement readable, which is exactly what we are doing here, and
close to useless as a fix for an out-of-memory error: you paid for that cache and
the next allocation rebuilds it.
""")

nb.code('''
if cuda_available and big is not None:
    del big
    big = None
    torch.cuda.synchronize()
    after_free = cc.describe_memory("after del")

    torch.cuda.empty_cache()
    after_empty = cc.memory_snapshot(include_smi=True)
    print()
    print(f"  reserved before empty_cache(): {after_free.torch_reserved_gb:.3f} GB")
    print(f"  reserved after  empty_cache(): {after_empty.torch_reserved_gb:.3f} GB")
    print(f"  nvidia-smi still shows       : {after_empty.smi_used_gb} GB — the CUDA "
          f"context does not go away until the process does")
else:
    print("no CUDA device — nothing to free")
''')

nb.callout(
    "vram",
    "The habit worth building: when a run dies with `CUDA out of memory`, read "
    "**allocated** to learn how big your tensors got, **reserved** to learn how "
    "much your process is holding, and **nvidia-smi** to find out whether "
    "something else on the card is the real problem. Reading only one of the "
    "three is how people spend an afternoon optimising a model that was never "
    "the thing filling the card.",
)

nb.callout(
    "note",
    "**Not this machine.** On NVIDIA's Grace-based unified-memory parts this "
    "story changes. On a GB10 (DGX Spark) the GPU shares one physical LPDDR pool "
    "with the CPU: there is no separate framebuffer, `nvidia-smi`'s memory "
    "columns can read `Not Supported`, and `mem_get_info()` under-reports free "
    "memory because reclaimable page cache is not counted. On GH200 and GB200 "
    "there is still dedicated HBM per GPU, but CPU and GPU share a coherent "
    "address space, so a managed buffer can migrate to host memory over "
    "NVLink-C2C instead of failing — \"it fits\" and \"it fits in HBM\" stop "
    "being the same question. Neither applies to an H100. This is written down "
    "so you recognise the difference if you move machines, not because you need "
    "it today.",
)

# --- Layer 5 ---------------------------------------------------------------
nb.md("""
### Layer 5 — the single-GPU budget problem

Here is the constraint that shapes this entire course. You have one card. Two
workloads want it.

- **The generator.** Cosmos3-Nano inference is documented at **32 GB**
  (`COSMOS3_FACTS.md` §3, from the framework's `docs/faq.md`). Cosmos3-Edge is not
  documented; ~12 GB is a working estimate that Lesson 06 measures properly.
- **The Reasoner NIM.** A serving stack pre-allocates its KV cache at startup
  against whatever VRAM is free at that moment. Left alone it will take most of
  the card. The 8B FP8 weights are about 8 GB; the rest is cache it reserved
  because nothing stopped it.

Both fit individually. Together, by default, they do not.
""")

nb.code('''
import json

budget = cc.vram_budget()
print(json.dumps(budget, indent=2))

card_gb = budget["total_gb"]
print()
for tier_name in ("Cosmos3-Edge", "Cosmos3-Nano", "Cosmos3-Super"):
    need = cc.MODEL_TIERS[tier_name]["inference_vram_gb"]
    fits_alone = need + budget["reserve_gb"] <= card_gb
    key = "coexist_with_edge" if tier_name == "Cosmos3-Edge" else "coexist_with_nano"
    coexist = False if tier_name == "Cosmos3-Super" else budget[key]["feasible"]
    print(f"  {tier_name:<14} needs ~{need:>4} GB   "
          f"alone: {'yes' if fits_alone else 'NO':<3}   "
          f"alongside a NIM: {'yes' if coexist else 'no'}")
''')

nb.md("""
Read that as two plans, not one answer.

**Take turns.** Stop the NIM, generate, restart the NIM. Neither side gives up
anything. You pay in wall-clock time: the NIM re-reads its weights on every
start, and a container restart is tens of seconds at best.

**Cap the NIM.** Start it with an explicit memory fraction so both fit at once.
You pay in KV cache, which is the same as paying in maximum context length — a
long video in a single reasoning request may no longer fit.

Lesson 02 has you measure the NIM's real resting footprint and choose. For now
the arithmetic is enough.

Note the asymmetry that falls out of those numbers, because it is easy to state
backwards. Super **generation** needs ~128 GB and will never fit one H100. Super
**reasoning** fits at FP8 on one H100 (`COSMOS3_FACTS.md` §4). The generator is
the expensive tower, not the reasoner.
""")

# --- Layer 6 ---------------------------------------------------------------
nb.md("""
### Layer 6 — disk

Disk is the constraint people forget until a download dies at 94%, leaving a
partial checkpoint that then fails as "checkpoint not found" — a completely
different-looking error with the same cause.

The numbers below come from `COSMOS3_FACTS.md` §1 and §3; the two marked
"estimate" are marked in the source too.

When you run short, `scripts/cleanup.sh` reclaims the Hugging Face cache, the uv
cache, NIM weights and generated media. It reports by default and deletes only
when given both a target flag and `--yes`. Run it with no arguments once now, so
you know what it looks like before you need it in a hurry.

```bash
./scripts/cleanup.sh                    # report only, deletes nothing
./scripts/cleanup.sh --outputs --yes    # delete generated media
```
""")

nb.code('''
COURSE_DISK_GB = {
    "Cosmos3-Edge checkpoint": 9.1,
    "Cosmos3-Nano checkpoint": 34.9,
    "guardrail + VAE + Qwen3Guard (first run)": 3.63 + 2.82 + 1.52,
    "Reasoner NIM image + FP8 nano profile": 8.28 + 20.0,
    "uv cache and framework venv (estimate)": 20.0,
    "generated outputs (estimate)": 30.0,
}
total_needed = sum(COURSE_DISK_GB.values())
for label, size in COURSE_DISK_GB.items():
    print(f"  {label:<44} {size:>7.2f} GB")
print(f"  {'-' * 44} {'-' * 7}")
print(f"  {'total for a full pass':<44} {total_needed:>7.2f} GB\\n")

free_gb = shutil.disk_usage(cc.COURSE_ROOT).free / (1024 ** 3)
module0_gb = 9.1 + 3.63 + 2.82 + 1.52
print(f"  free on the course volume : {free_gb:.1f} GiB")
print(f"  needed for Module 0 only  : {module0_gb:.1f} GB (Edge plus first-run auxiliaries)")
if free_gb < 25:
    print("\\n  PROBLEM: below 25 GiB you cannot finish Lesson 01.")
elif free_gb < total_needed:
    print("\\n  Enough to start, not enough for everything. Plan to prune between "
          "modules with scripts/cleanup.sh.")
else:
    print("\\n  Room for the whole course without pruning.")
''')

nb.checkpoint(
    "Before continuing, you should be able to say from memory how much free disk "
    "this machine has and whether Cosmos3-Nano (34.9 GB) is affordable on it.",
    '''
disk_ok = free_gb >= 25
print("host layer:", "ok" if host_ok else "PROBLEM")
print("disk layer:", "ok" if disk_ok else "PROBLEM — below 25 GiB")
print(f"Nano affordable now: {free_gb >= 34.9 + 10}")
''',
)

# --- Layer 7 ---------------------------------------------------------------
nb.md("""
### Layer 7 — Docker, GPU passthrough, and the NGC registry

Lessons 02 to 05 run the Cosmos 3 Reasoner NIM, which is a container. Four
distinct things can be wrong and they produce similar-looking failures:

1. **No Docker at all.** `docker` is not on PATH.
2. **Docker but no daemon.** The binary exists; `docker info` refuses. Usually the
   daemon is stopped, or your user is not in the `docker` group.
3. **Daemon but no GPU.** Containers start but cannot see the card. The NVIDIA
   Container Toolkit is missing, or the daemon was not restarted after installing
   it.
4. **GPU but no registry login.** Everything works until `docker pull
   nvcr.io/nim/...` returns 401.

Check them in that order, because each makes the next meaningless.

Check 4 needs care. An NGC API key is a secret; we want to know *whether* one has
been used, never what it is. Docker stores registry credentials in
`~/.docker/config.json`, and reading the **keys** of its `auths` object tells you
which registries you have logged into. The first cell below never touches the
values.

Check 3 is the one that costs something. It has to start a container, which means
pulling `nvidia/cuda:12.8.0-base-ubuntu22.04` if it is not already local — about
**200 MB**. That is the only download in this lesson, so it lives in a second
cell behind a flag you set yourself. If you skip it, `docker_status["gpu"]` stays
`None`, meaning "not tested", which is honestly different from `False`, meaning
"tested and broken".
""")

nb.code('''
docker_status = {"binary": False, "daemon": None, "gpu": None, "nvcr_login": None}
docker_status["binary"] = shutil.which("docker") is not None
print(f"  1. docker on PATH      : {docker_status['binary']}")

if docker_status["binary"]:
    server, server_err = run_cmd(["docker", "info", "--format", "{{.ServerVersion}}"], timeout=30)
    docker_status["daemon"] = server
    print(f"  2. daemon responding   : {'yes (server ' + server + ')' if server else 'NO — ' + str(server_err)}")
    if not server:
        print("       sudo systemctl start docker")
        print("       sudo usermod -aG docker $USER    # then log out and back in")
else:
    print("  2. daemon responding   : skipped (no docker binary)")

docker_config = Path.home() / ".docker" / "config.json"
if docker_config.exists():
    try:
        registries = sorted(json.loads(docker_config.read_text()).get("auths", {}))
        docker_status["nvcr_login"] = any("nvcr.io" in name for name in registries)
        print(f"  4. logged in to nvcr.io: {docker_status['nvcr_login']}   "
              f"(registries configured: {registries or 'none'})")
    except (json.JSONDecodeError, OSError) as exc:
        print(f"  4. logged in to nvcr.io: could not read config ({exc})")
else:
    print("  4. logged in to nvcr.io: no ~/.docker/config.json yet")

if docker_status["nvcr_login"] is not True:
    print("\\n  Before Lesson 02, log in without putting the key in a file or a cell:")
    print("      echo \\"$NGC_API_KEY\\" | docker login nvcr.io -u '$oauthtoken' --password-stdin")
''')

nb.code('''
PULL_TEST_IMAGE = False   # set True to allow a ~200 MB image pull

if docker_status["daemon"] and PULL_TEST_IMAGE:
    print("  pulling nvidia/cuda:12.8.0-base-ubuntu22.04 (~200 MB) if not cached...")
    gpu_out, gpu_err = run_cmd(
        ["docker", "run", "--rm", "--gpus", "all",
         "nvidia/cuda:12.8.0-base-ubuntu22.04", "nvidia-smi", "-L"],
        timeout=300,
    )
    docker_status["gpu"] = bool(gpu_out and "GPU 0" in gpu_out)
    print(f"  3. container sees GPU  : {docker_status['gpu']}")
    print("       " + (gpu_out or str(gpu_err)).replace("\\n", "\\n       "))
    if not docker_status["gpu"]:
        print("       Install the NVIDIA Container Toolkit and restart the daemon.")
elif docker_status["daemon"]:
    print("  3. container sees GPU  : not tested (PULL_TEST_IMAGE is False)")
else:
    print("  3. container sees GPU  : skipped (no daemon)")
''', tags=["expensive"])

nb.callout(
    "warning",
    "Never print an API key, never assign one to a variable in a notebook, and "
    "never pass one as a command-line argument — arguments are visible in `ps` "
    "output to every user on the machine. Export it in your shell and pipe it on "
    "stdin, as above. `scripts/validate_notebooks.py` scans every cell in this "
    "repository for strings shaped like `nvapi-`, `hf_` and `sk-` keys and fails "
    "the build if it finds one. It reports the shape and length, never the value.",
)

# --- The wrapper -----------------------------------------------------------
nb.md("""
### And now the helper

Everything above is what `cosmos_course.config.probe_environment()` does. Now
that you have written each layer by hand, calling it is not a black box — it is a
shortcut you could rebuild.

Note the argument: `check_docker=False` skips the container test, the only slow
part. Those fields come back `None`, meaning "not tested".

The second cell compares the report against what you measured yourself. The two
should agree field for field; where they do not, you have found either a bug in
the helper or a change in the machine between the two runs, and you now know
enough to tell which.

The report splits **problems** (things that will stop you) from **warnings**
(things that will slow you down). That split lives in `config._assess()`, about
seventy lines of thresholds you are invited to disagree with; the assessment
section asks you to. The same cell saves it: Lessons 02, 06 and 14 read this
file, and it is the first thing anyone will ask for if you open an issue about
this course.
""")

nb.code('''
report = cc.probe_environment(check_docker=False)
print(report.summary())
''')

nb.code('''
comparison = [
    ("machine", host["machine"], report.machine),
    ("python", host["python"], report.python_version),
    ("gpu count", gpu["count"], report.gpu_count),
    ("compute capability",
     f"{gpu['capability'][0]}.{gpu['capability'][1]}" if gpu["capability"] else None,
     report.compute_capability),
    ("torch cuda", runtime_cuda, report.torch_cuda_version),
]
for label, mine, theirs in comparison:
    agree = str(mine) == str(theirs)
    print(f"  [{'ok ' if agree else 'DIFF'}] {label:<20} mine={mine!r}  report={theirs!r}")

report_path = report.save(OUTPUT_DIR / "env_report.json")
print(f"\\nsaved: {report_path}")
print(f"problems: {len(report.problems)}")
for item in report.problems:
    print(f"  x {item}")
print(f"warnings: {len(report.warnings)}")
for item in report.warnings:
    print(f"  ! {item}")
''')

# ===========================================================================
# 6. Predict–run–explain #2
# ===========================================================================
nb.md("""
## The second prediction, and the bug it belongs to

`CUDA_VISIBLE_DEVICES` is an environment variable telling the CUDA driver which
physical GPUs a process may see. Setting it to `"0"` on a one-GPU box is a no-op.
Setting it to `"1"` is not.

The source DLI course this material is adapted from was written for a two-GPU
machine and pins `CUDA_VISIBLE_DEVICES` to `"1"` in its setup cells to keep its
work off device 0. Those lines still ship. On your single-GPU machine that is a
bug, and it is the most likely thing to break your day if you copy code from the
original.

The experiment below runs in a **child process**, and that detail is the lesson
inside the lesson. CUDA reads this variable once, when the driver initialises,
which happens the first time anything touches the GPU. This kernel has already
done that, so changing `os.environ` here would have no effect and you would
wrongly conclude the variable does not matter.
""")

nb.predict_run_explain(
    predict=(
        "A child Python process is started with `CUDA_VISIBLE_DEVICES=1` on this "
        "single-GPU machine. Predict three things: what "
        "`torch.cuda.device_count()` returns, what `torch.cuda.is_available()` "
        "returns, and what happens when that process then tries to allocate a "
        "tensor on `cuda:0`."
    ),
    change=(
        "Write your three answers into `PREDICTION_2` at the top of the next "
        "cell, then run it. The same cell also runs a control with the variable "
        "removed."
    ),
    explain=(
        "The variable names a device that does not exist. Explain why that "
        "produces the result you saw rather than an error at the moment the "
        "variable was set — and why the experiment had to run in a child process."
    ),
    hint=(
        "CUDA reads the variable once per process, at driver initialisation. "
        "After that the visible-device list is fixed. What does that imply about "
        "changing `os.environ` in a notebook that has already used the GPU?"
    ),
)

nb.code('''
PREDICTION_2 = {
    "device_count": 1,        # how many devices will the child see?
    "is_available": True,     # will torch.cuda.is_available() be True?
    "allocation": "works",    # "works", or the error you expect
}
for key, value in PREDICTION_2.items():
    print(f"  predicted {key:<14} {value!r}")

CHILD_PROBE = """
import os, torch
print("CUDA_VISIBLE_DEVICES =", repr(os.environ.get("CUDA_VISIBLE_DEVICES")))
print("device_count        =", torch.cuda.device_count())
print("is_available        =", torch.cuda.is_available())
try:
    t = torch.zeros(8, device="cuda:0")
    print("allocation          = ok, shape", tuple(t.shape))
except Exception as exc:
    print("allocation          =", type(exc).__name__ + ":", str(exc).splitlines()[0])
"""

child_env = dict(os.environ)
child_env["CUDA_VISIBLE_DEVICES"] = "1"      # the bug, on purpose
done = subprocess.run([sys.executable, "-c", CHILD_PROBE], env=child_env,
                      capture_output=True, text=True, timeout=300)
print("\\n--- child with CUDA_VISIBLE_DEVICES=1 ---")
print(done.stdout or done.stderr[-1200:])

control_env = dict(os.environ)
control_env.pop("CUDA_VISIBLE_DEVICES", None)
done = subprocess.run([sys.executable, "-c", CHILD_PROBE], env=control_env,
                      capture_output=True, text=True, timeout=300)
print("--- control, variable removed ---")
print(done.stdout or done.stderr[-1200:])
''', tags=["teaching-antipattern"])

nb.answer("""
`device_count()` returns **0** and `is_available()` returns **False**. There is no
error when the variable is set, and none when CUDA initialises: from the driver's
point of view you asked for the set of devices whose index is 1, that set is
empty, and an empty set is a legal answer.

The allocation then fails. Exactly how depends on your driver and PyTorch build —
`RuntimeError: No CUDA GPUs are available` or `RuntimeError: CUDA error: invalid
device ordinal`. Both mean the same thing.

The failure surfaces far from its cause, which is what makes it expensive. The
variable is usually set in a shell profile, a Dockerfile, a Slurm script or the
first cell of a notebook someone copied, and the error appears in whatever
model-loading code ran an hour later.
""")

# ===========================================================================
# 7. Debugging lab
# ===========================================================================
nb.md("""
## Debugging lab — the only GPU has disappeared

Worked as **symptom → hypothesis → diagnostic step → repair → verification**.
Every debugging lab in this course takes that shape, because it is the shape that
generalises. Reading corrected code teaches nothing.

### Symptom

You have inherited a notebook from the source DLI course. Its first cell sets
some environment variables. Later, model loading fails with:

```
RuntimeError: CUDA error: invalid device ordinal
```

or — worse, because it is silent — no error at all. The code runs on CPU, takes
forty minutes per image, and you conclude the model is slow.

`nvidia-smi` in a terminal shows a healthy, idle H100. The card is fine.
""")

nb.code('''
BROKEN_FIRST_CELL = """
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"   # inherited from a two-GPU machine
import torch
print("torch sees", torch.cuda.device_count(), "GPU(s)")
model_device = "cuda" if torch.cuda.is_available() else "cpu"
print("model will load on:", model_device)
"""

done = subprocess.run([sys.executable, "-c", BROKEN_FIRST_CELL],
                      capture_output=True, text=True, timeout=300)
print(done.stdout or done.stderr[-1200:])
''', tags=["teaching-antipattern"])

nb.md("""
### Hypothesis

The card is healthy but this *process* cannot see it. That points at something
process-scoped: an environment variable, a container started without `--gpus`, or
a driver/runtime mismatch. Three candidates, each with distinguishing evidence:

| Hypothesis | Distinguishing evidence |
|---|---|
| `CUDA_VISIBLE_DEVICES` hides it | `nvidia-smi` sees N GPUs, `torch.cuda.device_count()` sees fewer |
| Container without GPU passthrough | `nvidia-smi` itself fails *inside* that environment |
| Driver older than runtime | `device_count()` is right, but kernels fail to load |

### Diagnostic step

Compare the two sources. `nvidia-smi` talks to the driver directly and ignores
`CUDA_VISIBLE_DEVICES`; PyTorch honours it. Disagreement is close to conclusive.
""")

nb.code('''
def diagnose_missing_gpu(env=None):
    """Compare what the driver reports against what a CUDA process can see.

    Returns findings, most specific last. This is deliberately callable with an
    arbitrary environment so you can test a fix without changing your own.
    """
    env = dict(env or os.environ)
    findings = []

    listing, list_err = run_cmd(["nvidia-smi", "-L"])
    driver_count = len([ln for ln in (listing or "").splitlines() if ln.strip()])

    child = subprocess.run(
        [sys.executable, "-c", "import torch; print(torch.cuda.device_count())"],
        env=env, capture_output=True, text=True, timeout=300)
    try:
        torch_count = int(child.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        torch_count = -1

    findings.append(f"driver reports {driver_count} GPU(s); torch in that "
                    f"environment sees {torch_count}")
    visible = env.get("CUDA_VISIBLE_DEVICES")
    if driver_count > 0 and torch_count == 0:
        if visible not in (None, ""):
            findings.append(
                f"CUDA_VISIBLE_DEVICES={visible!r} selects device indices that do not "
                f"exist here (valid: 0..{driver_count - 1}). This is the cause.")
        else:
            findings.append("the variable is not set, so look elsewhere: container "
                            "GPU passthrough, or a CPU-only torch build.")
    return findings


for line in diagnose_missing_gpu(child_env):
    print("  " + line)
''')

nb.md("""
### Repair, and verification

Two options, and the difference matters.

**Unset it** — the process sees every GPU the driver offers. Correct when you own
the whole card.

**Set it to `"0"`** — explicit, and identical in effect on a one-GPU box. Prefer
this when a script might run on a shared multi-GPU node later, because it states
an intent rather than relying on a default.

What does *not* work is setting it after CUDA has initialised. In a notebook that
has already touched the GPU, you must restart the kernel.

A repair you have not verified is a guess, so the cell below runs the fixed
version and then re-runs the diagnostic against the repaired environment.
""")

nb.code('''
FIXED_FIRST_CELL = """
import os
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "0")   # this machine has exactly one
import torch
print("torch sees", torch.cuda.device_count(), "GPU(s)")
print("is_available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print("device 0:", torch.cuda.get_device_name(0))
"""

repaired_env = dict(os.environ)
repaired_env.pop("CUDA_VISIBLE_DEVICES", None)
done = subprocess.run([sys.executable, "-c", FIXED_FIRST_CELL], env=repaired_env,
                      capture_output=True, text=True, timeout=300)
print(done.stdout or done.stderr[-1200:])

findings = diagnose_missing_gpu(repaired_env)
print("--- diagnostic re-run against the repaired environment ---")
for line in findings:
    print("  " + line)
print("\\nresolved:", not any("does not exist" in line for line in findings))
''')

nb.callout(
    "upstream",
    "The source DLI course `S-OV-57-V1` sets `CUDA_VISIBLE_DEVICES` to `1` in its "
    "setup cells because it was authored on a two-GPU instance. Nothing in the "
    "source material says so, and the notebooks still ship that way. If you lift "
    "code from any NVIDIA course notebook into this one, check its device pinning "
    "first. `cc.probe_environment()` raises a warning whenever the variable is "
    "set, and `scripts/validate_notebooks.py` rejects the value `1` outright in "
    "any cell not tagged `teaching-antipattern`.",
)

# ===========================================================================
# 8. Exercises
# ===========================================================================
nb.md("""
## Exercises

Three exercises, increasing in scope. Each requires a decision that cannot be
copied from a cell above.
""")

nb.exercise(
    "foundation",
    "Report the interconnect topology",
    goal=(
        "Extend your hand-built probe with an eighth layer: the GPU interconnect "
        "topology, and an interpretation of it in one sentence."
    ),
    instructions=(
        "1. Run `nvidia-smi topo -m` through `run_cmd` and print the raw matrix.\n"
        "2. Write `parse_topology(text)` returning a dict with at least: the "
        "number of GPUs in the matrix, the set of link codes appearing between "
        "GPU pairs (`NV#`, `PIX`, `PXB`, `NODE`, `SYS`), and the CPU-affinity "
        "column if present.\n"
        "3. Write `interpret_topology(parsed)` returning one plain sentence about "
        "what this machine's topology means *for this course*.\n"
        "4. Handle the single-GPU case, where the matrix is one row reading `X` "
        "and there are no inter-GPU links at all — and handle `nvidia-smi` being "
        "absent, like every other probe here."
    ),
    success=(
        "`parse_topology` returns a dict on this machine without raising, "
        "`interpret_topology` produces a sentence you would defend, and both "
        "return something sensible when `topo_text` is `None`."
    ),
    starter='''
topo_text, topo_err = run_cmd(["nvidia-smi", "topo", "-m"])
print(topo_text or f"(no topology available: {topo_err})")


def parse_topology(text):
    """Parse `nvidia-smi topo -m` into a dict. Return the empty shape if text is None."""
    parsed = {"gpu_count": 0, "link_types": set(), "affinity": []}
    # TODO: split the matrix into rows, read the GPU labels from the header row,
    # and collect the link codes from the off-diagonal cells.
    return parsed


def interpret_topology(parsed):
    """One sentence about what this topology means for this course."""
    # TODO: on one GPU there is no inter-GPU link to interpret. Say what that
    # implies for the FSDP and context-parallel rungs of the OOM ladder.
    return "TODO"


print(parse_topology(topo_text))
print(interpret_topology(parse_topology(topo_text)))
''',
    hints=[
        "The legend at the bottom of `nvidia-smi topo -m` defines the codes: `NV#` "
        "is NVLink with # links, `SYS` means traffic crosses the CPU sockets, and "
        "`NV# < PIX < PXB < NODE < SYS` runs fastest to slowest. The interesting "
        "interpretation on a single-GPU machine is a negative one: with no second "
        "GPU there is no link, which is exactly why the FSDP-shard and "
        "context-parallel rungs of NVIDIA's OOM ladder (`COSMOS3_FACTS.md` §5) are "
        "unavailable to you. Say that.",
    ],
    solution_ref="solutions/00_solutions.ipynb",
)

nb.exercise(
    "applied",
    "A will-it-fit predicate",
    goal=(
        "Write `will_it_fit(model, resolution, frames)` that answers, before you "
        "launch anything, whether a generation job is possible on this card — and "
        "says why when the answer is no."
    ),
    instructions=(
        "1. Read the card's total VRAM from `torch`, falling back to 80.0 GB when "
        "there is no GPU so the function stays testable anywhere.\n"
        "2. Reject configurations the tier does not support, using "
        "`cc.MODEL_TIERS[model]`: `max_resolution_tier`, `frames_range`, "
        "`supports_audio`, `supports_transfer`.\n"
        "3. Reject configurations whose `inference_vram_gb` plus a reserve exceeds "
        "the card.\n"
        "4. Use `cc.estimate_generation_cost(...)` to attach a relative cost, so a "
        "caller can compare two configurations that both fit.\n"
        "5. Return a dict with `fits` (bool), `reasons` (list of strings) and "
        "`cost_units` (int).\n"
        "6. Run `check_will_it_fit()`. All three cases must pass."
    ),
    success=(
        "`check_will_it_fit()` prints three PASS lines and returns True, and every "
        "rejection message names the specific field that caused it."
    ),
    starter='''
CARD_GB = torch.cuda.get_device_properties(0).total_memory / (1024 ** 3) if cuda_available else 80.0


def will_it_fit(model, resolution, frames, reserve_gb=4.0):
    """Can this machine run this generation job? Explain either answer."""
    result = {"fits": False, "reasons": [], "cost_units": 0}
    tier = cc.MODEL_TIERS.get(model)
    if tier is None:
        result["reasons"].append(f"unknown model {model!r}")
        return result
    # TODO: capability checks from `tier`, then the VRAM check against CARD_GB,
    # then cc.estimate_generation_cost() for the cost.
    return result


CASES = [
    ("Cosmos3-Nano", "480", 121, True,
     "the course's normal working configuration"),
    ("Cosmos3-Edge", "768", 121, False,
     "Edge is documented to 480p; the tier, not the card, is the limit"),
    ("Cosmos3-Super", "480", 121, False,
     "128 GB of inference VRAM does not fit an 80 GB card at any resolution"),
]


def check_will_it_fit():
    """Check the three known cases and report what passed."""
    failures = []
    for model, resolution, frames, expected, why in CASES:
        try:
            got = bool(will_it_fit(model, resolution, frames)["fits"])
        except Exception as exc:
            failures.append(f"FAIL {model} {resolution}p {frames}f raised {exc!r}")
            continue
        if got == expected:
            print(f"PASS {model:<14} {resolution}p {frames:>3}f -> fits={got}   ({why})")
        else:
            failures.append(f"FAIL {model:<14} {resolution}p {frames:>3}f -> fits={got}, "
                            f"expected {expected}   ({why})")
    for line in failures:
        print(line)
    return not failures


check_will_it_fit()
''',
    hints=[
        "Compare resolution tiers as integers — `int(resolution) > "
        "int(tier['max_resolution_tier'])` — because they are tier *names* that "
        "happen to look like pixel heights. The Super case needs the most care: "
        "its `inference_vram_gb` is 128, which exceeds the card on its own, so no "
        "resolution or frame count changes the answer and your reason string "
        "should say so rather than blaming the resolution. Note also that "
        "`estimate_generation_cost` returns its own `warnings` list; deciding "
        "whether a warning should force `fits` to False is the real judgement "
        "call, and you should be able to defend it either way.",
    ],
    solution_ref="solutions/00_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "A preflight that a later lesson could call",
    goal=(
        "Write `preflight(report)` that a later lesson can call as its first cell, "
        "failing with a message specific enough to act on for each of five "
        "distinct broken environments."
    ),
    instructions=(
        "1. Accept an `EnvReport` (from `cc.probe_environment()`) so it can be "
        "tested without breaking the machine.\n"
        "2. Detect and distinguish these five, each with its own message and its "
        "own suggested fix: (a) no NVIDIA GPU visible at all; (b) a GPU is present "
        "but `torch` cannot use it — a CPU-only build, or a driver older than the "
        "runtime; (c) a GPU with too little VRAM for the requested tier; "
        "(d) `CUDA_VISIBLE_DEVICES` selecting an index that does not exist; "
        "(e) insufficient free disk for the requested tier's download.\n"
        "3. Take the model tier as an argument so the VRAM and disk thresholds "
        "come from `cc.MODEL_TIERS` rather than being hard-coded.\n"
        "4. Raise `RuntimeError` listing *all* failures, not the first. A learner "
        "who fixes one problem and re-runs to discover a second has been made to "
        "wait twice for no reason.\n"
        "5. Test it by monkeypatching: build five synthetic `EnvReport` objects, "
        "one per case, and assert each triggers its own message and no others."
    ),
    success=(
        "`test_preflight()` prints six PASS lines — one healthy, five broken — and "
        "`preflight(cc.probe_environment(check_docker=False))` on this machine "
        "either passes silently or names a real problem you agree with."
    ),
    starter='''
def preflight(report, model="Cosmos3-Edge", *, disk_headroom_gb=10.0):
    """Refuse to start a lesson on a machine that cannot finish it.

    Raises RuntimeError listing EVERY problem found, so one restart is enough.
    """
    tier = cc.MODEL_TIERS[model]
    found = []
    # TODO: the five cases. Each message should name what is wrong AND what to do
    # about it — "no GPU" is not actionable; "no GPU: check you rented a GPU
    # instance and that `nvidia-smi` works" is.
    if found:
        raise RuntimeError("preflight failed:\\n  - " + "\\n  - ".join(found))
    return True


def make_report(**overrides):
    """A synthetic EnvReport for testing. Healthy H100 by default."""
    base = dict(
        machine="x86_64", python_version="3.12.3", gpu_count=1,
        gpu_names=["NVIDIA H100 80GB HBM3"], gpu_vram_total_gb=[79.6],
        compute_capability="9.0", torch_version="2.8.0", torch_cuda_version="12.8",
        torch_cuda_available=True, disk_free_gb=400.0, visible_devices=None,
    )
    base.update(overrides)
    return cc.EnvReport(**base)


BROKEN = {
    "no gpu": make_report(gpu_count=0, gpu_names=[], gpu_vram_total_gb=[],
                          torch_cuda_available=False),
    "torch cannot use it": make_report(torch_cuda_available=False, torch_cuda_version=None),
    "too little vram": make_report(gpu_vram_total_gb=[7.8],
                                   gpu_names=["NVIDIA GeForce RTX 2080"]),
    "hidden device": make_report(visible_devices="1", gpu_count=0,
                                 torch_cuda_available=False),
    "disk full": make_report(disk_free_gb=3.0),
}


def test_preflight():
    """A healthy report must pass; each broken one must fail for its own reason."""
    failures = []
    try:
        preflight(make_report())
        print("PASS healthy report is accepted")
    except RuntimeError as exc:
        failures.append(f"FAIL healthy report was rejected: {exc}")
    for label, broken in BROKEN.items():
        try:
            preflight(broken)
            failures.append(f"FAIL {label!r} was accepted and should not have been")
        except RuntimeError as exc:
            print(f"PASS {label!r} rejected: {str(exc).splitlines()[-1][:90]}")
    for line in failures:
        print(line)
    return not failures


test_preflight()
''',
    hints=[
        "Cases (b) and (d) both show `torch_cuda_available=False`. What separates "
        "them is `gpu_count` and `visible_devices`: a hidden device leaves "
        "`visible_devices` set to an index the machine does not have, while a "
        "CPU-only build leaves `torch_cuda_version` as None with the GPU still "
        "enumerated. Order your checks so the more specific one wins. "
        "`cc.EnvReport` is a dataclass, so `make_report` constructs one directly — "
        "that is the monkeypatch. Patching the function itself works too "
        "(`cosmos_course.config.probe_environment = lambda **kw: make_report()`), "
        "but then remember to restore it. And do not stop at the first problem: "
        "collect them all and raise once, the way `config._assess()` fills two "
        "lists and lets the caller decide what is fatal.",
    ],
    solution_ref="solutions/00_solutions.ipynb",
)

# ===========================================================================
# 9. Assessment and reflection
# ===========================================================================
nb.md("""
## Assessment and reflection

### Knowledge check

Answer from memory, then check yourself.

1. `nvidia-smi` says CUDA 13.0 and `torch.version.cuda` says 12.8. Is anything
   wrong? What if the two were swapped?
2. `nvidia-smi` shows 41 GB in use on the card. `torch.cuda.memory_allocated()` in
   your process says 22 GB. Name the things that account for the difference, and
   say which one you can act on.
3. A run fails with `CUDA out of memory` while `memory_reserved()` reports 30 GB
   more than `memory_allocated()`. Is that gap the problem? What would tell you?
4. Why is compute capability 9.0 relevant to which attention implementation the
   framework selects?
5. A colleague reports that Cosmos3-Super "does not work on H100". Under what
   reading is that true, and under what reading is it false?
6. A container starts, `nvidia-smi` inside it fails, but `nvidia-smi` on the host
   works. Which of the four Docker checks failed, and what do you install?
""")

nb.answer("""
1. Nothing is wrong. The driver supports up to CUDA 13.0; your build asks for
   12.8, which is less. Swapped — driver 12.8, runtime 13.0 — is broken: kernels
   compiled for 13.0 will not load, and the message will be about kernel images
   rather than about versions.
2. PyTorch's reserved-but-unallocated pool (the caching allocator), plus roughly
   0.3–0.6 GB of CUDA context, plus any *other* process on the card. You can
   return the pool with `empty_cache()`; you cannot avoid the context; the other
   process is a scheduling problem rather than a memory one.
3. Not necessarily. A large gap is healthy cache. It becomes fragmentation only
   when the free blocks are individually too small for the next request, and the
   evidence is in the error text — "tried to allocate 2.00 GiB … 8.53 GiB free"
   is fragmentation. Rung one is `PYTORCH_ALLOC_CONF=expandable_segments:True`.
4. The framework picks its backend per architecture: Hopper `flash-attn-3-nv`,
   Ada and Ampere `flash-attn`, Blackwell `natten`. FlashAttention-3 depends on
   Hopper-specific asynchronous copy and warp-group instructions, so it does not
   port downwards.
5. True for **generation**: ~128 GB of inference VRAM does not fit an 80 GB card.
   False for **reasoning**: the Reasoner NIM serves the 32B Super reasoner at FP8
   on one H100 (`COSMOS3_FACTS.md` §4). The generator is the expensive tower.
6. Check 3 — daemon running, no GPU passthrough. Install the NVIDIA Container
   Toolkit and **restart the Docker daemon**; forgetting the restart is the usual
   reason it still fails afterwards.
""")

nb.md("""
### Practical completion test, and the record you keep

The cell below is the criterion for calling Lesson 00 finished. It also writes
`outputs/00/machine_notes.md`, which holds the three numbers you are supposed to
know from memory — you will want them in Lesson 02 when deciding how to share the
card, and in Lesson 17 when deciding whether a fine-tune can fit.
""")

nb.code('''
def lesson_00_complete():
    """Everything Lesson 00 was supposed to establish, checked."""
    checks = [
        ("env report saved", report_path.exists()),
        ("host layer ok", host_ok),
        ("disk >= 25 GiB", disk_ok),
        ("torch sees a GPU", cuda_available and gpu["count"] >= 1),
        ("driver >= runtime CUDA",
         not (driver_cuda and runtime_cuda)
         or version_tuple(driver_cuda) >= version_tuple(runtime_cuda)),
        ("nvidia-smi and torch agree", len(gpu_rows) == gpu["count"]),
        ("no CUDA_VISIBLE_DEVICES surprise",
         os.environ.get("CUDA_VISIBLE_DEVICES") in (None, "", "0")),
        ("probe reports no problems", not report.problems),
    ]
    for label, ok in checks:
        print(f"  [{'ok ' if ok else 'NO '}] {label}")
    passed = all(ok for _, ok in checks)
    print("\\nLesson 00:", "complete" if passed else "not yet — see the NO lines")
    return passed


lesson_00_complete()

notes = [
    "# My machine",
    "",
    f"- GPU: {gpu['names'][0] if gpu['names'] else 'none detected'}",
    f"- VRAM total: {gpu['vram_total_gb'][0]:.1f} GiB" if gpu["vram_total_gb"] else "- VRAM total: n/a",
    f"- Compute capability: {gpu['capability']}",
    f"- Driver CUDA: {driver_cuda}   runtime CUDA: {runtime_cuda}",
    f"- Free disk: {free_gb:.0f} GiB",
    f"- Architecture: {host['machine']}, glibc {host['libc']}, Python {host['python']}",
    "",
    "## My argument with one of config._assess()'s thresholds",
    "",
    "TODO: pick a threshold, say what you would change it to, and why.",
]
notes_path = OUTPUT_DIR / "machine_notes.md"
notes_path.write_text("\\n".join(notes) + "\\n")
print(f"\\nwrote {notes_path}")
''')

nb.md("""
### Argue with a threshold

`cosmos_course/config.py`'s `_assess()` turns raw facts into problems and
warnings. Open it and read the thresholds. Candidates worth disagreeing with:

- VRAM below 20 GB is a **problem**, below 40 GB a **warning**. Is 20 the right
  line, given that Edge is *estimated* at ~12 GB and nothing in this course has
  measured it yet?
- Free disk below 25 GB is a problem, below 60 GB a warning. Those numbers assume
  you will pull Nano. Should the threshold depend on which tier you intend to use?
- Host RAM below 100 GB produces a warning about dataloader workers. Where did 100
  come from, and what would you measure to justify a different number?
- `CUDA_VISIBLE_DEVICES` being set produces a *warning*. After the debugging lab,
  should it be a problem when it names an index the machine does not have?

Pick one. Write your alternative and your reasoning into the `TODO` section of
`outputs/00/machine_notes.md`. There is no correct answer; there is a defensible
one, and producing it is the objective.

### Common misconceptions

- **"`reserved` minus `allocated` is a memory leak."** It is the caching allocator
  holding freed blocks for reuse. It becomes a problem only when those blocks are
  too fragmented to serve the next request.
- **"`nvidia-smi`'s CUDA version is the CUDA I have installed."** It is the highest
  runtime version this driver supports. Your build's version is
  `torch.version.cuda`.
- **"`nvcc --version` tells me what PyTorch uses."** It does not. PyTorch ships
  compiled kernels and never invokes `nvcc` at runtime.
- **"`empty_cache()` fixes out-of-memory errors."** It returns the unused pool and
  destroys the cache you paid for. Occasionally it buys one more allocation;
  usually the memory was being used by something else on the card.
- **"Setting `CUDA_VISIBLE_DEVICES` in a notebook cell works."** Only before
  anything has touched the GPU. After that the visible-device list is fixed and
  you need a kernel restart.
- **"Docker working means the NIM will run."** Four separate things can be broken;
  check them in order.

### Summary

You built a seven-layer environment probe by hand, reconciled it against
`cosmos_course.config.probe_environment()`, measured the same gigabyte through
four different lenses, computed a VRAM and disk budget for the whole course, and
debugged a single-GPU machine whose only GPU had been hidden by an inherited
environment variable.

`outputs/00/env_report.json` is the artefact. Every later lesson can read it, and
when something goes wrong in Lesson 06 it is the file that tells you whether the
machine changed underneath you.

### Suggested extensions

- Add a persistence-mode check (`nvidia-smi -pm`) and explain what persistence
  mode costs and saves on a workstation versus a server.
- Log a VRAM sample every second to a JSONL file for a minute, then plot it.
  Lesson 02 needs exactly this to watch the NIM's startup reservation happen.
- Extend `will_it_fit` to take a *time* budget as well, using a units-per-second
  constant you will calibrate in Lesson 06.

### Mastery checklist

- [ ] I can state this machine's VRAM, compute capability and free disk from
      memory.
- [ ] I can explain the difference between the driver CUDA version and the runtime
      CUDA version, and say which comparison matters.
- [ ] I can predict which of `allocated`, `reserved` and `nvidia-smi` moves when I
      free a tensor, and why.
- [ ] I can name the two strategies for sharing one GPU between the NIM and the
      generator, and what each one costs.
- [ ] I can diagnose a hidden GPU from the disagreement between two sources.
- [ ] I have written down one threshold in `config._assess()` I would change, and
      why.

### Next

**Lesson 01 — What Cosmos 3 is, and your first generated image.** It downloads
about 9 GB of Cosmos3-Edge plus 8 GB of first-run auxiliaries, so start it when
you have the bandwidth.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "00_environment_check.ipynb")
