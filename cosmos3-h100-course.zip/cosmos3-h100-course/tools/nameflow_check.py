"""Cross-cell undefined-name check.

Simulates top-to-bottom execution, tracking which names each cell binds and
flagging names read before anything defines them. Catches the class of bug where
a notebook only works because you ran cells out of order.
"""
import ast, builtins, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILTINS = set(dir(builtins)) | {"__name__", "__file__", "_", "get_ipython", "display"}

class Binder(ast.NodeVisitor):
    """Collect names bound at module level in one cell."""
    def __init__(self): self.bound = set()
    def visit_Assign(self, n):
        for t in n.targets: self._bind(t)
        self.generic_visit(n)
    def visit_AnnAssign(self, n):
        if n.target: self._bind(n.target)
        self.generic_visit(n)
    def visit_AugAssign(self, n): self._bind(n.target); self.generic_visit(n)
    def visit_For(self, n): self._bind(n.target); self.generic_visit(n)
    def visit_AsyncFor(self, n): self._bind(n.target); self.generic_visit(n)
    def visit_With(self, n):
        for i in n.items:
            if i.optional_vars: self._bind(i.optional_vars)
        self.generic_visit(n)
    def visit_FunctionDef(self, n): self.bound.add(n.name); self.generic_visit(n)
    def visit_AsyncFunctionDef(self, n): self.bound.add(n.name); self.generic_visit(n)
    def visit_ClassDef(self, n): self.bound.add(n.name); self.generic_visit(n)
    def visit_Import(self, n):
        for a in n.names: self.bound.add((a.asname or a.name).split(".")[0])
    def visit_ImportFrom(self, n):
        for a in n.names: self.bound.add(a.asname or a.name)
    def visit_ExceptHandler(self, n):
        if n.name: self.bound.add(n.name)
        self.generic_visit(n)
    def visit_comprehension(self, n): self._bind(n.target); self.generic_visit(n)
    def visit_Lambda(self, n): pass  # its params are local
    def _bind(self, t):
        if isinstance(t, ast.Name): self.bound.add(t.id)
        elif isinstance(t, (ast.Tuple, ast.List)):
            for e in t.elts: self._bind(e)
        elif isinstance(t, ast.Starred): self._bind(t.value)

def local_names(tree):
    """Every name bound anywhere in the tree, including inside functions.
    Coarse on purpose — we want false negatives, not false positives."""
    b = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            b.add(node.name)
            for a in node.args.args + node.args.kwonlyargs + node.args.posonlyargs: b.add(a.arg)
            if node.args.vararg: b.add(node.args.vararg.arg)
            if node.args.kwarg: b.add(node.args.kwarg.arg)
        elif isinstance(node, ast.Lambda):
            for a in node.args.args: b.add(a.arg)
        elif isinstance(node, ast.ClassDef): b.add(node.name)
        elif isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)): b.add(node.id)
        elif isinstance(node, ast.arg): b.add(node.arg)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for a in node.names: b.add((a.asname or a.name).split(".")[0])
        elif isinstance(node, ast.ExceptHandler) and node.name: b.add(node.name)
        elif isinstance(node, ast.Global): b.update(node.names)
    return b

bad = 0
paths = sorted(ROOT.glob("*.ipynb")) + sorted(ROOT.glob("solutions/*.ipynb"))
for p in paths:
    nb = json.loads(p.read_text())
    known = set(BUILTINS)
    problems = []
    for i, cell in enumerate(nb["cells"]):
        if cell["cell_type"] != "code": continue
        src = "".join(cell["source"])
        if any(l.lstrip().startswith(("%", "!")) for l in src.splitlines()): continue
        try: tree = ast.parse(src)
        except SyntaxError: continue
        defined_here = local_names(tree)
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                if node.id not in known and node.id not in defined_here:
                    problems.append(f"    cell {i}: '{node.id}' used before assignment")
        b = Binder(); b.visit(tree)
        known |= b.bound | defined_here
    status = "ok  " if not problems else "FAIL"
    print(f"[{status}] {p.name}")
    for pr in sorted(set(problems))[:6]: print(pr)
    bad += len(set(problems))
print(f"\n{bad} potential undefined-name issue(s)")
sys.exit(1 if bad else 0)
