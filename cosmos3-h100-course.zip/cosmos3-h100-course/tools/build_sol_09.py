"""Build solutions/09_solutions.ipynb — reference answers for Lesson 09."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("09", "Audio conditioning and the guardrail",
                      lesson_file="09_generation_audio_guardrail.ipynb")

nb.header(
    "Two subjects, one theme: **the run that exits zero and produced nothing useful.** "
    "The foundation exercise isolates what audio conditioning contributes by generating "
    "the same scene with and without it. The applied one builds a wrapper that separates "
    "*blocked* from *failed* from *succeeded*, which matters because only one of the "
    "three is worth retrying. The challenge one measures what the guardrail costs and "
    "then argues, properly, about when you would turn it off."
)

nb.callout(
    "warning",
    "**Audio needs Cosmos3-Nano** — `COSMOS3_FACTS.md` §1 gives Edge `supports_audio: "
    "false`, so there is no cheap tier here. The guardrail also pulls "
    "`nvidia/Cosmos-Guardrail1`, the one gated repo in the whole Cosmos 3 stack. "
    "Generation is therefore off by default. The classifier, the retry policy, the "
    "experiment design and the cost decomposition all run and are verified against "
    "synthetic inputs.",
)

nb.prelude("The lesson's configuration, harness, `has_audio` probe and `classify_run`.")
nb.code(setup_cell("09"))

nb.code('''
import json
import shutil
import subprocess
import threading
import time

import numpy as np

from cosmos_course.measure import MeasurementLog, benchmark
from cosmos_course.models import Generator, RunResult, diagnose

MODEL = "Cosmos3-Nano"          # overrides the setup cell: Edge has no sound tokenizer
ALLOW_DOWNLOAD = False          # Nano (~35 GB) + the gated guardrail (~3.6 GB)

generator = cc.Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=False)

if MODE == "full":
    RES, N_FRAMES, N_STEPS = "480", 121, 35
else:
    RES, N_FRAMES, N_STEPS = "480", 61, 12
RUN_TIMEOUT = 5400 if MODE == "full" else 2400
RUN = ALLOW_DOWNLOAD and (not framework_problems) and DEVICE.startswith("cuda")

CALIB_PATH = cc.OUTPUT_ROOT / "06" / "calibration.json"
CALIB = json.loads(CALIB_PATH.read_text()) if CALIB_PATH.exists() else {}
log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
RUNS = {}


def predict_seconds(resolution, num_frames, num_steps, aspect_ratio="16,9"):
    ups = CALIB.get("units_per_second")
    if not ups:
        return None
    units = cc.estimate_generation_cost(resolution=resolution, num_frames=num_frames,
                                        num_steps=num_steps,
                                        aspect_ratio=aspect_ratio)["cost_units"]
    return (CALIB.get("fixed_overhead_s") or 0.0) + units / ups


def compact(obj):
    if isinstance(obj, (str, Path)):
        obj = json.loads(Path(obj).read_text())
    return json.dumps(obj, ensure_ascii=True, separators=(",", ":"))


print(f"model: {MODEL} (Edge supports_audio="
      f"{cc.MODEL_TIERS['Cosmos3-Edge']['supports_audio']})")
print(f"RUN  : {RUN}")
print(f"ffmpeg / ffprobe: {bool(shutil.which('ffmpeg'))} / {bool(shutil.which('ffprobe'))}")
''')

nb.code('''
class GpuSampler:
    """Poll device-wide VRAM on a thread; report the peak, in GB."""

    def __init__(self, interval=1.0, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            v = self._read_gb()
            if v is not None:
                self.samples.append(v)

    def __enter__(self):
        self.samples = [self._read_gb() or 0.0]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None


def run_and_verify(spec, subdir, *, label=None, extra_args=None, verify=True):
    """Run, sample VRAM, verify by content, record. Returns the RunResult."""
    label = label or spec.name
    if not RUN:
        print(f"skipped {label!r}: generation is disabled")
        return None
    for problem in cc.validate_spec(spec, strict=False):
        print("  spec warning:", problem)
    predicted = predict_seconds(spec.resolution, spec.num_frames or 1,
                                spec.num_steps or 1, spec.aspect_ratio or "16,9")
    with GpuSampler() as sampler:
        with cc.timer(label, track_memory=False) as timing:
            result = generator.run(spec, OUTPUT_DIR / subdir, seed=spec.seed or 0,
                                   extra_args=extra_args, timeout=RUN_TIMEOUT)
    RUNS[label] = {"seconds": timing.seconds, "peak_gb": sampler.peak_gb,
                   "predicted_s": predicted, "extra_args": list(extra_args or []),
                   "result": result}
    log.record(label=label, model=MODEL, mode=MODE,
               **{k: v for k, v in RUNS[label].items() if k != "result"})
    if verify:
        cc.verify_result(result)
    return result


def has_audio(path):
    """Does this file carry an audio stream? Returns the codec name, or None."""
    ffprobe = shutil.which("ffprobe")
    if ffprobe is None:
        return None
    try:
        out = subprocess.run(
            [ffprobe, "-v", "error", "-select_streams", "a:0",
             "-show_entries", "stream=codec_name", "-of", "csv=p=0", str(path)],
            capture_output=True, text=True, timeout=60, check=True).stdout.strip()
        return out.splitlines()[0] if out else None
    except Exception:
        return None


print("harness ready")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "With and without audio conditioning",
    goal="Establish what the audio track actually contributes, by generating the same "
         "scene with and without it.",
    success="Two verified clips differing only in audio conditioning, an audio-stream "
            "check on each, one temporal comparison, and a written verdict.",
    approach="Synthesise a **rhythmic** tone with known event times, so the test is "
             "\"does motion spike at frames 12, 36 and 60\" rather than a correlation "
             "you have to squint at.",
)

nb.code('''
def make_rhythmic_tone(path, *, seconds=3.0, bpm=60, freq=440):
    """A tone with clear onsets at known times. Hint 1: beats ambient sound.

    Ambient noise makes you eyeball a correlation. A pulse train tells you
    exactly which frames should show motion, which turns the comparison from a
    judgement into a lookup.
    """
    ffmpeg = shutil.which("ffmpeg")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if ffmpeg is None:
        return None
    period = 60.0 / bpm
    # A sine gated to short bursts: silence between beats, so the envelope has
    # unambiguous onsets rather than a continuous drone. `aevalsrc` builds it in
    # one expression rather than by combining two sources, which is both shorter
    # and far less likely to break on a different ffmpeg build.
    # A sine multiplied by a narrow raised-cosine gate. Written WITHOUT any
    # comma on purpose: lavfi splits filter arguments on commas and colons
    # before the expression evaluator sees them, and every escaping form for
    # a comma inside `aevalsrc` failed on the ffmpeg builds this was tested
    # against. Repeated multiplication raises the gate to the eighth power,
    # which is a narrow pulse, and needs no pow(x,8).
    gate = f"(0.5+0.5*cos(2*PI*t/{period}))"
    expr = f"sin(2*PI*{freq}*t)*" + "*".join([gate] * 8)
    try:
        subprocess.run(
            [ffmpeg, "-y", "-loglevel", "error",
             "-f", "lavfi", "-i", f"aevalsrc={expr}:d={seconds}:s=16000",
             "-ac", "1", str(path)],
            check=True, capture_output=True, text=True, timeout=120)
    except subprocess.CalledProcessError as exc:
        print(f"ffmpeg could not synthesise the tone: "
              f"{(exc.stderr or '').strip()[:160]}")
        return None
    return path


def beat_frames(*, seconds, bpm, fps):
    """Frame indices at which a beat onset falls. The prediction to test."""
    period = 60.0 / bpm
    return [round(t * fps) for t in np.arange(0, seconds, period)]


AUDIO_SECONDS, AUDIO_BPM, VIDEO_FPS = 3.0, 60, 24
expected_beats = beat_frames(seconds=AUDIO_SECONDS, bpm=AUDIO_BPM, fps=VIDEO_FPS)
print(f"beats expected at frames: {expected_beats}")

SOUND = cc.asset_or_none("audio_pouring") or make_rhythmic_tone(
    OUTPUT_DIR / "audio" / "tone.wav", seconds=AUDIO_SECONDS, bpm=AUDIO_BPM)
print(f"sound: {SOUND}")
if SOUND is not None and Path(SOUND).exists():
    print(f"  audio stream: {has_audio(SOUND)}")
''')

nb.code('''
def motion_over_time(path, count=64):
    """Per-frame mean absolute change. The video's own envelope."""
    frames = []
    try:
        import imageio.v3 as iio
        for i, f in enumerate(iio.imiter(path)):
            arr = np.asarray(f)
            frames.append(arr.mean(axis=2) if arr.ndim == 3 else arr)
            if len(frames) >= count:
                break
    except Exception:
        return []
    return [float(abs(frames[i + 1] - frames[i]).mean())
            for i in range(len(frames) - 1)]


def peaks_near(envelope, indices, *, window=2):
    """Fraction of expected beat frames that sit at a LOCAL MAXIMUM of motion.

    Deliberately not a correlation against the audio envelope. Correlation is
    dominated by the overall trend — a clip that moves a lot everywhere
    correlates with any energetic sound — whereas the question is whether the
    motion is *timed* to the beats. Local maxima answer that.
    """
    if len(envelope) < 5:
        return float("nan"), []
    hits = []
    for i in indices:
        lo, hi = max(0, i - window), min(len(envelope), i + window + 1)
        if lo >= hi:
            continue
        local = envelope[lo:hi]
        hits.append(envelope[min(i, len(envelope) - 1)] >= max(local) - 1e-9)
    return (float(np.mean(hits)) if hits else float("nan")), hits


# Verify the detector on envelopes whose answer is known by construction.
_n = 72
_flat = [1.0] * _n
_spiky = [1.0] * _n
for _i in expected_beats:
    if _i < _n:
        _spiky[_i] = 5.0
rate_spiky, _ = peaks_near(_spiky, expected_beats)
rate_flat, _ = peaks_near(_flat, expected_beats)
print(f"synthetic spiky envelope -> {rate_spiky:.0%} of beats at a local max")
print(f"synthetic flat  envelope -> {rate_flat:.0%}")
assert rate_spiky == 1.0, rate_spiky
print("PASS the beat detector finds every planted spike, and a flat envelope "
      "trivially satisfies 'local maximum' — which is why the FLAT case must be "
      "read alongside the envelope's own variance, not on its own")
print(f"     flat envelope variance: {np.var(_flat):.4f} (zero — no timing "
      f"information exists to detect)")
''')

nb.code('''
IMAGE = cc.asset_or_none("image_coastal_road_audio") or cc.asset_or_none("image_car_driving")
PROMPT = {
    "description": "The scene continues, with movement that follows the sound.",
    "camera": {"motion": "static, locked off"},
    "style": "documentary realism, natural colour",
}
SEED = 7           # hint 1: FIXED across both runs, or the difference is seed variance

pair = {}
if IMAGE is not None:
    common = dict(prompt=compact(PROMPT), vision_path=str(IMAGE), resolution=RES,
                  aspect_ratio="16,9", num_frames=N_FRAMES, num_steps=N_STEPS,
                  seed=SEED)
    # The ONLY differences: model_mode, sound_path, enable_sound.
    with_audio = cc.InferenceSpec(model_mode="audio_image2video", name="with_audio",
                                  sound_path=str(SOUND) if SOUND else None,
                                  enable_sound=True, **common)
    without_audio = cc.InferenceSpec(model_mode="image2video", name="without_audio",
                                     **common)

    # Prove the two specs differ in exactly the intended fields, before spending
    # anything. This is the control the whole comparison rests on.
    a, b = with_audio.to_dict(), without_audio.to_dict()
    differing = {k for k in set(a) | set(b) if a.get(k) != b.get(k)}
    print(f"fields differing between the two specs: {sorted(differing)}")
    assert differing <= {"model_mode", "sound_path", "enable_sound", "name"}, differing
    print("PASS the two specs differ only in the audio conditioning (and the name)")

    for spec in (with_audio, without_audio):
        result = run_and_verify(spec, "audio_pair", label=spec.name)
        if result is not None and result.video_path:
            pair[spec.name] = result.video_path
else:
    print("No conditioning image on disk — run scripts/fetch_assets.py")
''')

nb.code('''
# PLACEHOLDER ENVELOPES — invented. The audio-conditioned one has motion peaks
# at the beat frames; the unconditioned one does not. They exist so the
# comparison runs; they are NOT measurements of Cosmos 3.
if pair:
    envelopes = {name: motion_over_time(path) for name, path in pair.items()}
    audio_streams = {name: has_audio(path) for name, path in pair.items()}
    placeholder_env = False
else:
    placeholder_env = True
    rng = np.random.default_rng(0)
    base = 2.0 + rng.normal(0, 0.25, N_FRAMES - 1)
    withe = base.copy()
    for i in expected_beats:
        if i < len(withe):
            withe[i] += 3.0
    envelopes = {"with_audio": [float(v) for v in withe],
                 "without_audio": [float(v) for v in base]}
    audio_streams = {"with_audio": "aac", "without_audio": None}
    print("PLACEHOLDER ENVELOPES — invented, not measurements.\\n")

print(f"{'clip':<16}{'audio stream':>14}{'frames':>8}{'mean motion':>13}"
      f"{'beats at a peak':>17}")
print("-" * 70)
for name, env in envelopes.items():
    rate, _ = peaks_near(env, expected_beats)
    print(f"{name:<16}{str(audio_streams.get(name)):>14}{len(env) + 1:>8}"
          f"{np.mean(env):>13.3f}{rate:>17.0%}")

# Step 3's check, asserted: the audio-conditioned output must actually carry an
# audio stream. `enable_sound=True` is a request, and a video that generated
# fine but silently dropped its audio track looks identical in every other way.
if not placeholder_env and "with_audio" in audio_streams:
    if audio_streams["with_audio"] is None:
        print("\\nThe audio-conditioned output has NO audio stream. That is a finding: "
              "the mode ran, the picture generated, and the sound did not survive "
              "muxing. Check the framework's output directory for a separate .wav "
              "before concluding the model produced none.")
    else:
        print(f"\\naudio stream present: {audio_streams['with_audio']}")
''')

nb.code('''
try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

if plt is not None and envelopes:
    fig, ax = plt.subplots(figsize=(9, 3.6))
    for name, env in envelopes.items():
        ax.plot(env, label=name)
    for i in expected_beats:
        ax.axvline(i, color="#c92a2a", ls="--", lw=1, alpha=.6)
    ax.set_xlabel("frame index (dashed red = expected beat onsets)")
    ax.set_ylabel("mean absolute frame-to-frame change")
    ax.set_title("PLACEHOLDER DATA — not a measurement" if placeholder_env
                 else "measured on this machine", fontsize=10)
    ax.legend(fontsize=8)
    plt.tight_layout()
    plt.show()
''')

nb.model_answer(
    "**What did the audio buy, and was it worth the extra mode?**\n\n"
    "Two sentences as asked, then the reasoning behind them.\n\n"
    "*The audio bought timing: the conditioned clip's motion peaks land on the beat "
    "onsets and the unconditioned clip's do not, which is a synchronisation the prompt "
    "cannot express at any length. Whether that is worth the extra mode depends entirely "
    "on whether anything downstream consumes the timing — for a clip a human watches, "
    "yes; for frames a detector trains on, almost never.*\n\n"
    "**Why the test is beat-timing rather than correlation.** `peaks_near` asks whether "
    "the expected beat frames sit at local maxima of the motion envelope. The obvious "
    "alternative — correlate the video's motion envelope against the audio's amplitude "
    "envelope — is worse for a specific reason: correlation is dominated by the shared "
    "trend. A clip that simply moves more overall correlates with any energetic sound, "
    "and you would conclude \"audio increases motion\" when what happened is \"audio "
    "conditioning shifted the model towards a more dynamic sample\". Local maxima at "
    "*known* times cannot be satisfied that way.\n\n"
    "**What the rhythmic tone is really for.** Hint 1 offers it as a convenience and it "
    "is more than that: it makes the null hypothesis testable. With ambient sound you "
    "have no prediction, so any correlation you find is a post-hoc observation. With a "
    "60 bpm pulse and a 24 fps output you have written down frames 0, 24, 48 *before* "
    "generating, and a hit rate against that list is a real test with a computable "
    "chance baseline — with a window of +/-2 frames, the chance of a random frame being "
    "the local max of its 5-frame window is 1/5, so 3 of 3 hits is p ≈ 0.008. That is a "
    "number you can defend; \"the curves look related\" is not.\n\n"
    "**The honest caveat about the flat case**, which the verification cell makes "
    "explicit: a perfectly flat envelope trivially satisfies \"is a local maximum\", so "
    "a high hit rate on a low-variance envelope means nothing. Report the envelope's "
    "variance next to the hit rate, always.\n\n"
    "**Was it worth the extra mode?** The costs are concrete: `audio_image2video` "
    "forces Cosmos3-Nano (Edge has no sound tokenizer), which is a 35 GB download and "
    "roughly 32 GB of inference VRAM against Edge's ~12, and it adds a conditioning "
    "input that must be prepared and time-aligned. For **synthetic training data for a "
    "vision model**, none of that buys anything — the trainer sees frames and the audio "
    "track is discarded, so you have paid Nano's cost for a property nothing consumes. "
    "For anything a person watches, or for a model that is itself multimodal, the timing "
    "is the entire point and there is no other way to get it. The decision is not about "
    "the audio; it is about the consumer."
)

nb.extend(
    "One tone at one tempo tests one thing. The experiment that would actually "
    "characterise the coupling is a **tempo sweep**: the same scene at 40, 60, 90 and "
    "140 bpm, measuring hit rate at each. The interesting prediction is that it falls "
    "off at high tempo, because the model has a limited temporal resolution — at 140 bpm "
    "and 24 fps the beats are ten frames apart, and if the model's effective temporal "
    "receptive field is coarser than that the timing cannot be expressed. Finding where "
    "the hit rate collapses tells you the temporal resolution of the audio conditioning, "
    "which is a genuinely useful number and is documented nowhere."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "A guardrail-aware wrapper",
    goal="Write a wrapper that runs a generation and reports, unambiguously, whether it "
         "was blocked, failed or succeeded — and does something different in each case.",
    success="Five or more prompts classified, each with a reason, no retries on blocked "
            "runs, and a stated disagreement rate between the classifier and your own "
            "judgement.",
    approach="Resolve `blocked?` to **`failed`**, not to `blocked` — with the argument "
             "below — and drive the retry decision from `RunResult.diagnose()` rather "
             "than from the verdict.",
)

nb.code('''
GUARDRAIL_MARKERS = ("guardrail", "blocked", "safety", "did not pass",
                     "content policy", "nsfw", "rejected")
BLANK_MARKERS = ("flat", "single colour", "essentially empty", "only ",
                 "barely change", "decoded only")


def classify_run(result):
    """Return (verdict, reason). Verdicts: succeeded | blocked | failed | not_run.

    CHANGED FROM THE LESSON: the ambiguous `blocked?` case — a blank output with
    nothing in the log naming the guardrail — resolves to **failed**, not to
    blocked. The argument is in the commentary below; the short version is that
    the two verdicts have different consequences and the safe error is the one
    that keeps looking.
    """
    if result is None:
        return "not_run", "generation was disabled or the cell was skipped"

    log_text = (result.stdout_tail or "").lower()
    guardrail_hit = [m for m in GUARDRAIL_MARKERS if m in log_text]

    if result.returncode != 0:
        return "failed", (f"non-zero exit ({result.returncode})"
                          + (f"; log also mentions {guardrail_hit}" if guardrail_hit
                             else ""))
    if not result.outputs:
        return ("blocked" if guardrail_hit else "failed",
                "exit 0 but no output files"
                + (f"; log mentions {guardrail_hit}" if guardrail_hit
                   else "; nothing in the log points at the guardrail"))

    failures = [c for c in cc.verify_result(result, verbose=False) if not c.passed]
    if not failures:
        return "succeeded", "exit 0, output present, every content check passed"

    blank = [c for c in failures
             if any(m in c.reason.lower() for m in BLANK_MARKERS)]
    if blank:
        if guardrail_hit:
            return "blocked", (f"blank output and the log names the guardrail "
                               f"({guardrail_hit}): {blank[0].reason}")
        return "failed", (f"blank output with NO guardrail evidence in the log "
                          f"({blank[0].reason}). Classified as failed rather than "
                          f"blocked so it stays in the queue for investigation; "
                          f"read the full stdout before deciding.")
    return "failed", "; ".join(f"{c.name}: {c.reason}" for c in failures[:2])
''')

nb.code('''
# Which diagnoses are worth a retry. Driven by RunResult.diagnose(), which
# already pattern-matches the failures this course has hit (hint 1).
RETRYABLE = ("port", "address already in use", "connection", "timeout", "timed out",
             "transient", "temporarily")
NOT_RETRYABLE = ("out of memory", "oom", "gated", "401", "403", "no such file",
                 "not found", "disk", "no space", "invalid", "unsupported")


def retry_is_sensible(result):
    """Would running this again, unchanged, plausibly succeed? (bool, why)."""
    if result is None:
        return False, "nothing ran"
    text = " ".join(result.diagnose()).lower() + " " + (result.stdout_tail or "").lower()
    for marker in NOT_RETRYABLE:
        if marker in text:
            return False, f"diagnosis mentions {marker!r}, which will not fix itself"
    for marker in RETRYABLE:
        if marker in text:
            return True, f"diagnosis mentions {marker!r}, which can be transient"
    return False, ("no diagnosis matched a known-transient cause; not retried, "
                   "because retrying an unclassified failure turns one wait into two")


def generate(spec, subdir="wrapped", *, retries=1):
    """Run one generation and report blocked / failed / succeeded.

    BLOCKED RUNS ARE NOT RETRIED. What would have to be true for a retry to
    change the outcome? The guardrail screens the PROMPT (a text classifier, run
    before sampling) and the FRAMES (a content classifier, run after). Neither
    reads the seed. Prompt screening is deterministic in the prompt, so an
    identical prompt is blocked identically every time — retrying is a
    guaranteed wait for the same answer. Frame screening is the only branch
    where a new seed could plausibly change the verdict, and if it does, you
    have produced a video that a content filter rejects on one sample and
    accepts on another, which you should not be shipping either way.
    """
    record = {"name": spec.name, "verdict": None, "reason": None, "attempts": 0,
              "seconds": 0.0, "output": None, "retry_note": None}
    for attempt in range(retries + 1):
        record["attempts"] = attempt + 1
        started = time.perf_counter()
        result = run_and_verify(spec, subdir, label=f"{spec.name}_a{attempt}",
                                verify=False)
        record["seconds"] += time.perf_counter() - started
        verdict, reason = classify_run(result)
        record["verdict"], record["reason"] = verdict, reason

        if verdict == "succeeded":
            record["output"] = str(result.video_path or result.image_path or "")
            return record
        if verdict == "blocked":
            record["retry_note"] = "not retried: a blocked prompt blocks again"
            return record
        if verdict == "not_run":
            return record
        # failed
        ok, why = retry_is_sensible(result)
        record["retry_note"] = why
        if not ok or attempt == retries:
            return record
    return record
''')

nb.code('''
# A fake RunResult, so every branch of the classifier and the retry policy can
# be exercised without a GPU. Each case is one of the four outcomes the wrapper
# must distinguish.
class FakeResult:
    def __init__(self, returncode=0, outputs=(), stdout_tail="", diag=()):
        self.returncode = returncode
        self.outputs = list(outputs)
        self.stdout_tail = stdout_tail
        self._diag = list(diag)

    def diagnose(self):
        return self._diag

    def ok(self):
        return self.returncode == 0 and bool(self.outputs)

    def video_path(self):
        return self.outputs[0] if self.outputs else None

    def image_path(self):
        return None


CASES = [
    ("clean success", FakeResult(0, [Path("a.mp4")]), "succeeded"),
    ("crash", FakeResult(1, [], "CUDA out of memory"), "failed"),
    ("blocked, log says so", FakeResult(0, [], "guardrail blocked the prompt"),
     "blocked"),
    ("exit 0, no files, no evidence", FakeResult(0, [], "done."), "failed"),
]

# The classifier calls cc.verify_result on real files, so the two content-based
# cases are checked separately against real artefacts below.
import unittest.mock as _mock

for label, fake, expected in CASES:
    with _mock.patch.object(cc, "verify_result", return_value=[]):
        verdict, reason = classify_run(fake)
    mark = "PASS" if verdict == expected else "FAIL"
    print(f"{mark} {label:<32} -> {verdict:<10} {reason[:52]}")
    assert verdict == expected, (label, verdict, reason)

# The ambiguous case, which is the exercise's step 1: blank content, no
# guardrail evidence.
blank_check = cc.CheckResult(name="check_video", passed=False,
                             reason="frames barely change; the clip is flat")
with _mock.patch.object(cc, "verify_result", return_value=[blank_check]):
    verdict, reason = classify_run(FakeResult(0, [Path("a.mp4")], "done."))
assert verdict == "failed", (verdict, reason)
print(f"PASS {'blank, no guardrail evidence':<32} -> {verdict:<10} (resolved to "
      f"failed, not blocked?)")
with _mock.patch.object(cc, "verify_result", return_value=[blank_check]):
    verdict, reason = classify_run(
        FakeResult(0, [Path("a.mp4")], "guardrail rejected the content"))
assert verdict == "blocked", (verdict, reason)
print(f"PASS {'blank, guardrail named in log':<32} -> {verdict:<10}")
''')

nb.code('''
# The retry policy, checked against the diagnoses it is supposed to separate.
RETRY_CASES = [
    ("OOM", FakeResult(1, [], "torch.cuda.OutOfMemoryError", ["CUDA out of memory"]),
     False),
    ("port collision", FakeResult(1, [], "", ["address already in use on port 29500"]),
     True),
    ("gated repo", FakeResult(1, [], "", ["401 Client Error: repo is gated"]), False),
    ("unknown", FakeResult(1, [], "", ["something nobody has seen before"]), False),
]
for label, fake, expected in RETRY_CASES:
    ok, why = retry_is_sensible(fake)
    mark = "PASS" if ok == expected else "FAIL"
    print(f"{mark} {label:<18} retry={str(ok):<6} {why}")
    assert ok == expected, (label, ok, why)
print("\\nPASS an OOM is not retried, a port collision is, and an unrecognised "
      "failure is not")
''')

nb.code('''
BATCH = [
    ("benign_kitchen",
     {"description": "A robot arm folds a towel on a stainless counter.",
      "lighting": "even overhead light", "style": "documentary realism"}, "ok"),
    ("benign_road",
     {"description": "A car drives along an empty coastal road at dusk.",
      "lighting": "warm low sun", "style": "documentary realism"}, "ok"),
    ("benign_workshop",
     {"description": "A person places a mug on a workshop bench.",
      "lighting": "soft daylight", "style": "documentary realism"}, "ok"),
    ("expected_block",
     {"description": ("Graphic footage of a severe injury with visible blood, "
                      "photorealistic and detailed."),
      "style": "documentary realism"}, "blocked"),
    ("impossible_geometry",
     {"description": "A plain grey calibration target.", "style": "flat"}, "failed"),
]


def make_spec(name, prompt_obj, expectation):
    """Build the spec for one batch entry. The 'failed' entry is broken on purpose."""
    kwargs = dict(model_mode="text2video", name=name, prompt=compact(prompt_obj),
                  resolution=RES, aspect_ratio="16,9", num_frames=N_FRAMES,
                  num_steps=N_STEPS, seed=SEED)
    if expectation == "failed":
        # An impossible geometry: an aspect ratio written with a colon rather
        # than a comma. This is one of the course's named gotchas and it fails
        # for a reason that has nothing to do with content, which is exactly
        # what a "failed, not blocked" case needs to be.
        kwargs["aspect_ratio"] = "16:9"
    return cc.InferenceSpec(**kwargs)


records = []
for name, prompt_obj, expectation in BATCH:
    spec = make_spec(name, prompt_obj, expectation)
    problems = cc.validate_spec(spec, strict=False)
    rec = generate(spec, "wrapped", retries=1) if RUN else {
        "name": name, "verdict": "not_run",
        "reason": ("generation disabled; local spec validation says: "
                   + ("; ".join(problems) if problems else "no problems")),
        "attempts": 0, "seconds": 0.0, "output": None, "retry_note": None}
    rec["expected"] = expectation
    rec["spec_problems"] = problems
    records.append(rec)

print(f"{'prompt':<22}{'expected':<10}{'verdict':<12}{'attempts':>9}{'time':>9}  reason")
print("-" * 112)
for r in records:
    print(f"{r['name']:<22}{r['expected']:<10}{r['verdict']:<12}"
          f"{r['attempts']:>9}{r['seconds']:>9.1f}  {str(r['reason'])[:44]}")

# Whatever the machine, one thing must hold: a blocked run is never retried.
for r in records:
    if r["verdict"] == "blocked":
        assert r["attempts"] == 1, r
print("\\nPASS no blocked run was retried")

# And the broken-geometry entry must be caught by local validation even with no
# GPU — which is the cheapest possible version of "fails for a different reason".
bad = [r for r in records if r["expected"] == "failed"]
assert bad and bad[0]["spec_problems"], bad
print(f"PASS the impossible-geometry spec is rejected locally before any run: "
      f"{bad[0]['spec_problems'][0][:80]}")
''')

nb.model_answer(
    "**Resolving `blocked?`, and the wrapper's own error rate.**\n\n"
    "**The decision: `blocked?` resolves to `failed`.** A blank output with no guardrail "
    "evidence in the log is classified as a failure, not a block.\n\n"
    "The argument is about what each verdict *causes*. `blocked` is terminal: the wrapper "
    "does not retry, does not escalate, and the record says \"the content policy refused "
    "this\". `failed` keeps the run in the queue for investigation and may be retried if "
    "the diagnosis supports it. So the question is: which mistake is cheaper?\n\n"
    "- Calling a genuine block a failure costs one wasted retry (and only if the "
    "diagnosis matches a transient cause, which a guardrail block will not) plus a "
    "human glance at a run that turns out to be fine to discard.\n"
    "- Calling a genuine failure a block **closes the investigation**. A blank output "
    "caused by a decode error, a corrupt conditioning image, a VAE producing NaNs, or a "
    "one-frame video is filed under \"the guardrail rejected it\" and nobody looks again. "
    "That is a systematic bug hiding behind a policy explanation, and it will keep "
    "happening.\n\n"
    "The asymmetry is decisive, and it is the same shape as Lesson 03's \"unclassified "
    "exceptions are not retried\" and Lesson 00's \"the more specific check runs first\": "
    "**when two classifications are both defensible, choose the one whose error stays "
    "visible.**\n\n"
    "There is a second reason, specific to this case. A guardrail that blocks content "
    "*without saying so in the log* is a serious operational problem in its own right — "
    "you cannot audit what you cannot see. Classifying the silent case as `failed` "
    "surfaces it as an anomaly rather than normalising it.\n\n"
    "**The wrapper's own error rate.** This is step 5 and it must be measured, not "
    "assumed. The procedure: for every record, open the output and decide for yourself "
    "what happened, without looking at the verdict first; then count disagreements. On a "
    "five-item batch the interval on that rate is enormous — one disagreement out of five "
    "gives a 95% Wilson interval of roughly [4%, 62%] — so the number is worth recording "
    "and not worth quoting.\n\n"
    "What you are most likely to disagree with, in order: (1) a clip that is dark but not "
    "blank, which `check_video` calls flat and you call correct; (2) a clip that passes "
    "every check and does not resemble the prompt at all, which the classifier calls "
    "`succeeded` and you would call a failure — the classifier has no notion of prompt "
    "adherence; (3) the ambiguous case above, where you have the log and can read it "
    "properly.\n\n"
    "**And the case hint 1 singles out: a prompt you expected to be blocked and which "
    "was not.** Record it as-is. The temptation is to escalate the prompt until it "
    "blocks, which turns the batch into a search for the filter's boundary and destroys "
    "it as a measurement of your expectations. The finding \"my model of what the "
    "guardrail blocks is wrong\" is worth more than a batch where every expectation was "
    "met."
)

nb.extend(
    "The wrapper classifies one run. What you actually want is the **rate over time**: "
    "log every verdict with its prompt and date, and alert when the blocked fraction "
    "moves. A guardrail update that starts blocking a category you rely on is invisible "
    "in any single run and obvious in a weekly rate — and since the guardrail is a "
    "separate gated checkpoint that can be updated independently of the generator, this "
    "is a real change that will happen to you rather than a hypothetical."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "What does the guardrail actually cost?",
    goal="Measure the guardrail's throughput and VRAM cost across a batch, and make a "
         "defensible recommendation about when to offload it — and about when disabling "
         "it could be justified.",
    success="A design stated in advance, a noise floor measured before any comparison, at "
            "least nine measured cells, a threshold recommendation with its supporting "
            "number and its failure cost, and a written position on disabling that "
            "engages with the hard case.",
    approach="State the design and the repeat count first, measure the noise floor "
             "before any comparison, and decompose the guardrail's cost into a fixed "
             "part and a per-frame part using Lesson 06's method.",
)

nb.code('''
# ---- STEP 1: the design, written down BEFORE anything runs ---------------
CONDITIONS = {
    "resident": None,
    "offloaded": ["--offload-guardrail-models"],
    "disabled": ["--no-guardrails"],
}
JOB_SIZES = [
    # (label, resolution, num_frames, num_steps)
    ("small",       RES, 25, N_STEPS),
    ("medium",      RES, 61, N_STEPS),
    ("long",        RES, 121, N_STEPS),
    ("more_steps",  RES, 61, N_STEPS * 2),   # control: guardrail cost should be
]                                            # FLAT in steps (hint 1)
REPEATS = 3

print(f"design: {len(CONDITIONS)} conditions x {len(JOB_SIZES)} job sizes = "
      f"{len(CONDITIONS) * len(JOB_SIZES)} cells, {REPEATS} repeats each "
      f"= {len(CONDITIONS) * len(JOB_SIZES) * REPEATS} runs")
print()
print("WHY 3 REPEATS. One measurement cannot separate an effect from run-to-run")
print("noise, and at these run lengths the noise is not small: clock and power")
print("excursions, page-cache state on the weight files, and thermal throttling")
print("on a warm H100 all move a single number by several percent. Three gives a")
print("median (robust to one outlier) and a spread (which is the noise floor).")
print("Five would be better and costs 60 runs; three is the smallest number that")
print("yields a median at all, and the report states the spread so a reader can")
print("judge whether any difference clears it.")
print()
print("WHY 'more_steps' IS IN THE DESIGN. It is a control, not a data point.")
print("Frame screening scales with frames; prompt screening does not; NEITHER")
print("scales with denoising steps. So the guardrail's absolute cost at")
print("(61 frames, 2x steps) must match its cost at (61 frames, 1x steps). If it")
print("does not, the measurement is picking up something other than the")
print("guardrail and every other cell is suspect.")
''')

nb.code('''
def build_spec(label, resolution, frames, steps, *, seed=SEED):
    return cc.InferenceSpec(
        model_mode="text2video", name=f"cost_{label}",
        prompt=compact({"description": "A plain grey calibration target rotating "
                                       "slowly on a white background.",
                        "style": "flat, neutral"}),
        resolution=resolution, aspect_ratio="16,9", num_frames=frames,
        num_steps=steps, seed=seed)


def noise_floor(spec, repeats=REPEATS, extra_args=None):
    """Run one configuration several times. Everything else is compared to this."""
    if not RUN:
        return None
    times, peaks = [], []
    for i in range(repeats):
        with GpuSampler() as sampler:
            with cc.timer(f"{spec.name}_floor{i}", track_memory=False, quiet=True) as t:
                generator.run(spec, OUTPUT_DIR / "cost_floor", seed=spec.seed or 0,
                              extra_args=extra_args, timeout=RUN_TIMEOUT)
        times.append(t.seconds)
        peaks.append(sampler.peak_gb or float("nan"))
    med = float(np.median(times))
    return {"times": times, "median_s": med, "spread_s": max(times) - min(times),
            "spread_frac": (max(times) - min(times)) / med if med else None,
            "peak_gb": float(np.median(peaks))}


def measure_cell(condition, job):
    """One (condition, job size) cell. Return time, peak VRAM and the verdict."""
    label, resolution, frames, steps = job
    spec = build_spec(f"{label}_{condition}", resolution, frames, steps)
    extra = CONDITIONS[condition]
    times, peaks, verdicts = [], [], []
    for i in range(REPEATS):
        result = run_and_verify(spec, "cost", label=f"{spec.name}_r{i}",
                                extra_args=extra, verify=False)
        if result is None:
            return None
        times.append(RUNS[f"{spec.name}_r{i}"]["seconds"])
        peaks.append(RUNS[f"{spec.name}_r{i}"]["peak_gb"])
        verdicts.append(classify_run(result)[0])
    return {"condition": condition, "job": label, "frames": frames, "steps": steps,
            "median_s": float(np.median(times)), "spread_s": max(times) - min(times),
            "peak_gb": float(np.median([p for p in peaks if p is not None] or [float("nan")])),
            "verdicts": verdicts}
''')

nb.code('''
# ---- STEP 2: the noise floor, measured BEFORE any comparison -------------
floor = noise_floor(build_spec("floor", RES, 61, N_STEPS))
cells = []
if RUN:
    for condition in CONDITIONS:
        for job in JOB_SIZES:
            cell = measure_cell(condition, job)
            if cell:
                cells.append(cell)
else:
    # PLACEHOLDER CELLS — invented, so the decomposition and the recommendation
    # can be computed and checked. NOT measurements of Cosmos 3. The shape
    # encodes the hypothesis under test (a fixed part plus a per-frame part,
    # flat in steps) so that the analysis code is exercised on data of the
    # right form. Replace by running with ALLOW_DOWNLOAD = True.
    floor = {"times": [300.1, 305.4, 302.0], "median_s": 302.0, "spread_s": 5.3,
             "spread_frac": 5.3 / 302.0, "peak_gb": 34.0}
    base = {"small": 140.0, "medium": 300.0, "long": 580.0, "more_steps": 590.0}
    frames = {"small": 25, "medium": 61, "long": 121, "more_steps": 61}
    steps = {"small": N_STEPS, "medium": N_STEPS, "long": N_STEPS,
             "more_steps": N_STEPS * 2}
    for condition in CONDITIONS:
        for label in base:
            if condition == "disabled":
                extra_s, extra_gb = 0.0, 0.0
            else:
                extra_s = 6.0 + 0.22 * frames[label]      # fixed + per-frame
                extra_gb = 3.2 if condition == "resident" else 0.4
                if condition == "offloaded":
                    extra_s += 4.5                        # transfer cost
            cells.append({"condition": condition, "job": label,
                          "frames": frames[label], "steps": steps[label],
                          "median_s": base[label] + extra_s, "spread_s": 5.0,
                          "peak_gb": 34.0 + extra_gb,
                          "verdicts": ["succeeded"] * REPEATS, "placeholder": True})
    print("PLACEHOLDER CELLS — invented, not measurements.\\n")

print(f"noise floor: median {floor['median_s']:.1f} s, spread "
      f"{floor['spread_s']:.1f} s ({floor['spread_frac']:.1%} of the median)")
if floor["spread_frac"] and floor["spread_frac"] > 0.25:
    print("  Spread above 25% of the median. Treat every difference below that "
          "as unmeasured, and find out what is moving before believing anything.")
print()
print(f"{'condition':<12}{'job':<12}{'frames':>7}{'steps':>7}{'median s':>11}"
      f"{'spread':>9}{'peak GB':>9}")
print("-" * 68)
for c in sorted(cells, key=lambda c: (c["job"], c["condition"])):
    print(f"{c['condition']:<12}{c['job']:<12}{c['frames']:>7}{c['steps']:>7}"
          f"{c['median_s']:>11.1f}{c['spread_s']:>9.1f}{c['peak_gb']:>9.1f}")
assert len(cells) >= 9, f"the design needs at least nine cells, got {len(cells)}"
print(f"\\n{len(cells)} cells measured")
''')

nb.code('''
# ---- STEP 3: attribute the cost -----------------------------------------
by = {(c["condition"], c["job"]): c for c in cells}
overhead = []
for job in JOB_SIZES:
    label, _, frames, steps = job
    on, off = by.get(("resident", label)), by.get(("disabled", label))
    if not on or not off:
        continue
    overhead.append({"job": label, "frames": frames, "steps": steps,
                     "seconds": on["median_s"] - off["median_s"],
                     "gb": on["peak_gb"] - off["peak_gb"]})

print(f"{'job':<12}{'frames':>7}{'steps':>7}{'guardrail s':>13}{'guardrail GB':>14}"
      f"{'above floor?':>14}")
print("-" * 68)
for row in overhead:
    clears = "yes" if abs(row["seconds"]) > floor["spread_s"] else "NO — unmeasured"
    print(f"{row['job']:<12}{row['frames']:>7}{row['steps']:>7}"
          f"{row['seconds']:>13.1f}{row['gb']:>14.2f}{clears:>14}")

# Fixed vs per-frame, by the same two-point decomposition Lesson 06 used for
# steps. Fit overhead = a + b * frames across the job sizes that differ only in
# frame count.
frame_rows = [r for r in overhead if r["steps"] == N_STEPS]
if len(frame_rows) >= 2:
    xs = np.array([r["frames"] for r in frame_rows], float)
    ys = np.array([r["seconds"] for r in frame_rows], float)
    per_frame, fixed = np.polyfit(xs, ys, 1)
    print(f"\\nguardrail cost = {fixed:.1f} s fixed + {per_frame:.3f} s per frame")
    print(f"  at {N_FRAMES} frames that is {fixed + per_frame * N_FRAMES:.1f} s")
else:
    per_frame = fixed = float("nan")
    print("\\nNot enough frame-varying cells to decompose the cost.")

# The control (hint 1): the guardrail's cost must be FLAT in steps.
same_frames = [r for r in overhead if r["frames"] == 61]
if len(same_frames) == 2:
    a, b = same_frames
    delta = abs(a["seconds"] - b["seconds"])
    print(f"\\ncontrol — same frames ({a['frames']}), {a['steps']} vs {b['steps']} steps:")
    print(f"  guardrail cost {a['seconds']:.1f} s vs {b['seconds']:.1f} s "
          f"(difference {delta:.1f} s)")
    if delta > floor["spread_s"]:
        print("  The guardrail's cost CHANGED with step count, which it should not. "
              "Question the measurement before questioning the guardrail: the most "
              "likely cause is that the two runs did not screen the same number of "
              "frames, or that thermal state differed between them.")
    else:
        print("  Flat in steps, within the noise floor — the measurement behaves as "
              "the mechanism predicts, which is weak evidence that it is measuring "
              "the guardrail and not something correlated with run length.")
''')

nb.code('''
# ---- STEP 4: the offload recommendation, with its number and its cost ----
resident_gb = np.median([c["peak_gb"] for c in cells if c["condition"] == "resident"])
offload_gb = np.median([c["peak_gb"] for c in cells if c["condition"] == "offloaded"])
resident_s = np.median([c["median_s"] for c in cells if c["condition"] == "resident"])
offload_s = np.median([c["median_s"] for c in cells if c["condition"] == "offloaded"])
vram_saved = resident_gb - offload_gb
time_cost = offload_s - resident_s

print(f"resident : {resident_gb:.1f} GB peak, {resident_s:.1f} s median")
print(f"offloaded: {offload_gb:.1f} GB peak, {offload_s:.1f} s median")
print(f"offloading saves {vram_saved:.1f} GB and costs {time_cost:+.1f} s per run")
print()
card_gb = 80.0
try:
    import torch
    if torch.cuda.is_available():
        card_gb = torch.cuda.get_device_properties(0).total_memory / 1e9
except Exception:
    pass
headroom = card_gb - resident_gb
print(f"THRESHOLD: offload when the resident configuration leaves less than "
      f"{vram_saved:.1f} GB of headroom —")
print(f"  i.e. when peak VRAM with the guardrail resident exceeds "
      f"{card_gb - vram_saved:.1f} GB on this {card_gb:.0f} GB card.")
print(f"  Right now: peak {resident_gb:.1f} GB, headroom {headroom:.1f} GB -> "
      f"{'OFFLOAD' if headroom < vram_saved else 'keep it resident'}")
print()
print(f"COST WHEN THE RECOMMENDATION IS WRONG:")
print(f"  Offloading when you did not need to: {time_cost:+.1f} s per run, every run. "
      f"Over a 100-clip batch that is {100 * time_cost / 60:.0f} minutes for nothing.")
print(f"  NOT offloading when you should have: an OOM, which costs the whole run and "
      f"— worse — usually arrives partway through a batch, so you lose the queue "
      f"position as well as the run. The asymmetry says: when the headroom is "
      f"within about 2 GB of {vram_saved:.1f}, offload.")
''')

nb.model_answer(
    "**On disabling the guardrail.**\n\n"
    "Position: **`--no-guardrails` is defensible in exactly one configuration, and that "
    "configuration is defined by who can see the output, not by what you are generating.**\n\n"
    "*What the guardrail screens.* Two separate classifiers, and conflating them is the "
    "commonest confusion here. A **text** classifier screens the prompt before sampling "
    "starts. A **content** classifier screens generated frames afterwards. `--no-guardrails` "
    "turns off both; `--offload-guardrail-models` keeps both and moves their weights off "
    "the card between uses. So \"disabled\" is a policy decision and \"offloaded\" is a "
    "memory decision, and they should never be argued about together.\n\n"
    "*The hard case, engaged with rather than avoided.* You are generating collision "
    "footage to train an automotive perception system. This is a real and legitimate "
    "requirement — a detector that has never seen a crash cannot be evaluated on one, and "
    "real crash footage is scarce, ethically fraught to collect, and legally encumbered. "
    "The guardrail will block a fraction of these prompts, because \"vehicle collision, "
    "visible impact damage\" is indistinguishable at the text level from content the "
    "filter exists to refuse. Telling this user \"never disable it\" is telling them to "
    "abandon the work, and they will not; they will disable it without a policy, which is "
    "the worst outcome available.\n\n"
    "*What would have to be true before I signed off.* Five things, and all five:\n\n"
    "1. **The outputs never leave a controlled environment.** Not a shared drive, not a "
    "notebook someone else opens, not an artefact store with broad read access. If a "
    "human who did not opt in can see the output, the guardrail stays on.\n"
    "2. **Something replaces it.** Turning off the filter and putting nothing in its "
    "place is not a decision, it is an omission. The replacement can be narrower — a "
    "prompt allow-list rather than a general classifier, plus human review of a sample of "
    "outputs — but it must exist, be written down, and produce a record.\n"
    "3. **The prompts are enumerated in advance**, from a reviewed list, not composed "
    "interactively. A fixed list can be reviewed once by a person; an interactive session "
    "cannot be reviewed at all.\n"
    "4. **Every output is logged with its prompt, its seed and the fact that screening "
    "was off.** If a downstream dataset contains unscreened material, that must be "
    "discoverable from the dataset, not from someone's memory.\n"
    "5. **A named person owns the decision** and it is time-boxed. \"We turned it off "
    "for the crash-corpus generation in March\" is auditable; \"we turn it off\" is not.\n\n"
    "*Why not simply always offload instead.* Because offloading does not address the "
    "problem — the guardrail still runs and still blocks. Offloading is the answer to \"I "
    "need the VRAM\", not to \"the filter refuses my legitimate prompt\". Conflating them "
    "leads people to reach for `--no-guardrails` when they meant "
    "`--offload-guardrail-models`, which is a policy change made for a memory reason.\n\n"
    "*If your answer is \"never\", argue it properly.* The strongest version: the "
    "guardrail's false-refusal rate is a cost you can measure and route around — request "
    "a policy exception, use a differently-worded prompt, source real footage under "
    "licence — while the cost of a wrong disable is unbounded and lands on people who "
    "did not choose it. That is a coherent position and I do not think it survives "
    "contact with the crash-corpus case, where the alternatives are genuinely unavailable "
    "and the environment genuinely is controlled. But it is the right position for a "
    "default.\n\n"
    "**Hint 2's point, which belongs in the report.** The `disabled` condition was "
    "measured on **benign prompts only** — a rotating grey calibration target. That is "
    "stated because a measurement obtained by generating unscreened content has a cost "
    "attached, and reporting the cost is part of the answer. It also happens to be better "
    "methodology: the timing comparison wants identical content across conditions, and a "
    "prompt that the resident condition would block cannot be timed in all three."
)

nb.code('''
lines = [
    "# What the guardrail costs — Lesson 09, Exercise 3",
    "",
    ("**PLACEHOLDER NUMBERS.** No Nano run happened on this machine; the values below "
     "are invented to exercise the analysis. The design, the noise-floor discipline, "
     "the decomposition and the recommendations are real."
     if any(c.get("placeholder") for c in cells) else "Measured on this machine."),
    "",
    "## Design, stated in advance",
    "",
    f"- {len(CONDITIONS)} conditions (resident / offloaded / disabled) x "
    f"{len(JOB_SIZES)} job sizes = {len(cells)} cells",
    f"- {REPEATS} repeats per cell; median reported, spread reported alongside",
    "- `more_steps` is a CONTROL, not a data point: guardrail cost must be flat in "
    "denoising steps",
    "- the `disabled` condition ran on benign prompts only, and that is a deliberate "
    "limitation of the measurement",
    "",
    "## Noise floor (measured first)",
    "",
    f"median {floor['median_s']:.1f} s, spread {floor['spread_s']:.1f} s "
    f"({floor['spread_frac']:.1%}). Any difference smaller than the spread is "
    f"unmeasured.",
    "",
    "## Cost decomposition",
    "",
    f"guardrail cost = **{fixed:.1f} s fixed + {per_frame:.3f} s per frame**"
    if fixed == fixed else "not enough cells to decompose",
    "",
    "## Recommendation: when to offload",
    "",
    f"Offload when peak VRAM with the guardrail resident exceeds "
    f"{card_gb - vram_saved:.1f} GB on an {card_gb:.0f} GB card — i.e. when headroom "
    f"falls below the {vram_saved:.1f} GB the offload frees.",
    "",
    f"Cost when wrong: offloading unnecessarily costs {time_cost:+.1f} s per run; not "
    f"offloading when you should have costs an OOM mid-batch. The asymmetry argues for "
    f"offloading inside a ~2 GB margin of the threshold.",
    "",
    "## Recommendation: on disabling",
    "",
    "See the model answer in the notebook. Summary: defensible only when the outputs "
    "stay in a controlled environment, something narrower replaces the filter, the "
    "prompts are enumerated and reviewed in advance, every output is logged as "
    "unscreened, and a named person owns a time-boxed decision. Offloading is a memory "
    "decision; disabling is a policy decision; they must not be argued about together.",
    "",
    "## What surprised me",
    "",
    "The fixed component. Intuition says the guardrail is a per-frame classifier and "
    "should therefore cost roughly nothing on a short clip, but a substantial share of "
    "its cost is paid before a single frame is screened — it is model loading and a "
    "prompt-classification pass, neither of which scales with the job. The practical "
    "consequence inverts the naive rule: the guardrail is proportionally MOST expensive "
    "on short jobs, which are exactly the ones you run most often while iterating.",
]
report_path = OUTPUT_DIR / "guardrail_cost.md"
report_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {report_path}")
print("\\n".join(lines[-8:]))
''')

nb.why(
    "**Why the noise floor is measured before any comparison, again.** This is the third "
    "exercise in the course to insist on it and the reason is worth restating in this "
    "context: the guardrail's per-run cost is plausibly single-digit seconds on a run "
    "that takes several minutes. If the machine's own run-to-run spread is comparable, "
    "the entire experiment is unmeasurable, and you want to know that *before* spending "
    "36 runs. `cosmos_course.measure.benchmark` exists for exactly this and warns when "
    "the spread exceeds 25% of the median.\n\n"
    "**Why `more_steps` is in the design.** It is the cheapest possible falsification "
    "test. The mechanism says the guardrail screens prompts (once) and frames (per "
    "frame), and touches nothing that scales with denoising steps. So doubling the steps "
    "must leave the guardrail's *absolute* cost unchanged. If it does not, the "
    "measurement is capturing something correlated with run length — thermal throttling "
    "is the usual culprit, since a longer run is a hotter run — and every other cell is "
    "contaminated. Hint 1 offers this as a control and it is the single most valuable "
    "cell in the design, because it can invalidate the whole thing for the cost of three "
    "runs.\n\n"
    "**Why the threshold is expressed in headroom rather than in job size.** \"Offload "
    "for jobs over 100 frames\" is the tempting form and it is wrong, because it hides "
    "the actual variable. What decides the answer is whether peak VRAM plus the "
    "guardrail's resident footprint fits the card, and that depends on resolution, frame "
    "count, model tier *and* on whether a NIM is holding memory (Lesson 02). Expressing "
    "the rule in headroom makes it transfer to configurations that were never measured; "
    "expressing it in frames does not.\n\n"
    "**Why the failure cost is asymmetric and the threshold is shaded.** Offloading "
    "unnecessarily costs seconds per run, and it costs them predictably. Failing to "
    "offload costs a whole run and lands mid-batch. When the two errors differ by two "
    "orders of magnitude in cost, the threshold should not sit where the expected values "
    "cross — it should sit inside a margin on the cheap-error side, and the report says "
    "so explicitly rather than quietly picking a conservative number."
)

nb.extend(
    "Everything here measures the guardrail's cost. Nobody has measured its **benefit**, "
    "and that is the harder and more useful experiment: what is its false-refusal rate on "
    "prompts you actually want, and its miss rate on prompts you actually do not? Both "
    "are estimable with a labelled prompt set of a hundred items and no generation at all "
    "for the prompt classifier — you only need the block/no-block verdict, which arrives "
    "in seconds. Without those two numbers, \"is the guardrail worth its cost\" is not a "
    "question anyone can answer, and the offload/disable debate is being conducted "
    "entirely on one side of the ledger."
)

nb.finish()
