"""Build 04_reasoning_embodied.ipynb.

Derived from the source DLI course `S-OV-57-V1`, notebook 02, sections 2a, 2b,
2c and 3 (cells 15-23). Prompts and clips are preserved; what is added is the
part the source leaves out — that a fluent chain of thought is not evidence the
answer is right, and what you do about that before the output drives an
actuator.

The source's 2c and 3 both used `toaster_6sec.mp4` from a private DLI S3 bucket.
`cosmos_course.assets` substitutes the public cookbook clips that carry the same
teaching, and says so.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 04 — Embodied reasoning")

nb.md("""
# Lesson 04 — Embodied reasoning

**What you will build.** `outputs/04/reasoning_log.jsonl` — a log of reasoning
probes, each with its prompt, its separated chain of thought, its answer, your
verdict, and its token cost. Including at least one case you judged **wrong**,
with a written account of where the reasoning went off.

| | |
|---|---|
| **Time** | ~75 minutes |
| **GPU** | 1 × H100 with the Reasoner NIM from Lesson 02 running |
| **Downloads** | None |
| **Prerequisites** | Lessons 02 and 03. `Reasoner.parse_json` and the `check_text` habit carry over. |

Lesson 03 asked the model *what is there*. This lesson asks it *what to do*.
That is a much larger claim, and the difference is the subject of the lesson.
""")

nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Elicit** a chain of thought with the `<think>` convention and split it from
   the answer with `split_think()`.
2. **Compare** answers with and without the think wrapper at a fixed seed, and
   state whether the reasoning changed the conclusion or only explained it.
3. **Construct** three distinct prompt shapes — reactive next action, goal
   decomposition, and goal-plus-current-step — and predict how each changes the
   answer.
4. **Measure** the token and latency cost of chain-of-thought against direct
   answering.
5. **Produce** a case where the model is fluent, confident and wrong, and
   characterise how you knew.
6. **Implement** at least one automatic check that catches such a case without a
   human reading the output.
""")

# ------------------------------------------- where you are
nb.md("""
## Where this sits in the module

Lesson 03 opened with the six-capability table — the map of everything a Cosmos 3
reasoner can be asked for. Two rows of it belong to this lesson:

| Capability | What it answers | Why it matters for Physical AI | Covered in |
| --- | --- | --- | --- |
| Video captioning | *What is happening in this clip?* | Turns raw video into structured scene descriptions | Lesson 03 |
| **Embodied reasoning** | *What should the agent do next? What is the plan?* | Bridges perception to action | **Lesson 04 — this one** |
| **Common-sense reasoning** | *Is this physically sensible?* | Grounds decisions in real-world physics | **Lesson 04 — this one** |
| 2D grounding | *Where exactly is object X?* | Localizes objects to interact with | Lesson 05 |
| Describe anything | *Describe each marked region.* | Fine-grained, region-level understanding | Lesson 05 |
| Action chain-of-thought | *What path should the gripper follow?* | Produces spatial plans for manipulation | Lesson 05 |

The two live together because they are the same operation pointed in opposite
directions. Embodied reasoning proposes an action; common-sense reasoning is what
stops a proposal that violates physics from reaching an actuator. A system with
the first and not the second is confidently dangerous, and the second half of
this lesson is about building the check rather than assuming it.

The full table, with the reasoning behind the ordering, is at the top of
`03_reasoning_captioning.ipynb`.
""")

# ------------------------------------------- foundation
nb.md("""
## From description to decision

A captioner that gets a detail wrong produces a slightly wrong sentence. A
policy that gets a detail wrong moves a robot arm.

That difference is why this lesson is mostly about **auditability**. When a
model's output drives an actuator, you need more than the output: you need
enough of its reasoning to decide whether to trust it, and you need that in a
form a program can inspect, not only a human.

### The `<think>` convention

Cosmos 3 has **no reasoning-mode flag**. There is no `reasoning=True`. The
structure appears because your prompt asked for it:

```
<think>
The gripper is above the bowl and open. The bowl is to the left of the target
position. Nothing is currently grasped.
</think>
Close the gripper on the bowl.
```

Everything before `</think>` is the trace; everything after is the answer. That
is the whole protocol, and its most important property is that **it is a
convention, not a guarantee**. The model can ignore it, emit an unterminated
`<think>`, or produce the tags and put the answer inside them.

So `split_think()` returns `("", text)` when there is no `</think>` rather than
raising. An empty reasoning string is information: it tells you the prompt was
not forceful enough, which is a thing you can fix.
""")

nb.callout("warning", """
A chain of thought is an **artefact you can audit**, not a **guarantee of
correctness**. The trace is generated by the same sampling process as the
answer, and nothing in the architecture makes the answer follow from the trace.
A model can reason correctly and then state the opposite conclusion; it does
this often enough that "check whether the answer contradicts the reasoning" is a
genuinely useful automatic test, which you will write later in this lesson.
Treat the trace as evidence about the model's process, never as proof about the
world.
""")

# ------------------------------------------- environment
nb.md("""
## Environment
""")

nb.code('__lesson__ = "04"   # OUTPUT_DIR resolves to outputs/04\n\n' + SETUP_CELL)

nb.code('''
import json
import time

from cosmos_course.nim import NimConfig, nim_status, print_status
from cosmos_course.models import Reasoner, split_think

NIM = NimConfig()
cc.require(
    nim_status(NIM)["ready"],
    f"The Cosmos 3 Reasoner NIM is not answering at {NIM.base_url}.",
    fix=(
        "Start it as you did in Lesson 02 (02_serving_the_reasoner.ipynb):\\n"
        "        from cosmos_course.nim import start_nim, NimConfig\\n"
        "        start_nim(NimConfig())\\n"
        "      If it was up earlier and is not now, read the logs before "
        "restarting:\\n"
        "        from cosmos_course.nim import nim_logs; print(nim_logs())"
    ),
)

print_status(NIM)
reasoner = Reasoner(base_url=NIM.base_url)
print()
print(f"model: {reasoner.model}")
''')

nb.code('''
def need_asset(name):
    try:
        return cc.asset(name)
    except FileNotFoundError as exc:
        raise RuntimeError(
            f"{exc}\\n  Fetch the cookbook:  python3 scripts/fetch_assets.py"
        ) from None

# The four scenes this lesson uses. `assisted_task` and `common_sense` are the
# public substitutes for the source course's private toaster_6sec.mp4.
NEXT_ACTION_CLIP = need_asset("robotics_next_action")
PLANNING_IMAGE = need_asset("robot_planning")
ASSISTED_CLIP = need_asset("assisted_task")
COMMON_SENSE_CLIP = need_asset("common_sense")

for label, path in [
    ("next action", NEXT_ACTION_CLIP),
    ("planning", PLANNING_IMAGE),
    ("assisted task", ASSISTED_CLIP),
    ("common sense", COMMON_SENSE_CLIP),
]:
    print(f"  {label:<14} {path.name}")

# One append-only log; every probe below adds to it, and it is the artefact.
reasoning_log = []
''')

# ------------------------------------------ 2a next action
nb.md("""
## Probe 1 — next-action prediction

The core query of a **reactive policy**: given what I can see right now, what do
I do next? No goal is stated, no history is given. The model has to infer the
intent from the scene.

This is the source course's prompt, unchanged, including its slightly awkward
phrasing — worth keeping because you will meet it in the cookbook.
""")

nb.code('''
cc.show_video(NEXT_ACTION_CLIP, caption="robotics_next_action.mp4 — a robot mid-task")
''')

nb.code('''
NEXT_ACTION_PROMPT = (
    "What can be the next immediate action? Answer the question using the "
    "following format: <think> Your reasoning. </think> Write your final answer "
    "immediately after the </think> tag."
)

raw = reasoner.ask(NEXT_ACTION_PROMPT, videos=NEXT_ACTION_CLIP, fps=4,
                   max_tokens=4096, seed=0, temperature=0.0)
thought, answer = split_think(raw)

print("--- reasoning " + "-" * 58)
print(thought or "(the model produced no <think> block)")
print("--- answer " + "-" * 61)
print(answer)
print()
print(f"reasoning chars : {len(thought)}")
print(f"answer chars    : {len(answer)}")
print(f"tokens          : {reasoner.last_usage}")
''')

nb.md("""
`Reasoner.think()` does the same thing with the course's standard wrapper, so
you do not retype the format instruction on every probe. It returns the pair
directly.

The wrapper it uses adds one clause the source prompt lacks: *"give your final
answer directly, with no preamble and no restatement of the question."* Without
that, models frequently answer with "The next immediate action should be to...",
which is fine for a human and awkward for a parser.
""")

nb.code('''
from cosmos_course.models import THINK_TEMPLATE

print(THINK_TEMPLATE.format(prompt="<your question goes here>"))
print()

thought2, answer2 = reasoner.think(
    "What can be the next immediate action?",
    videos=NEXT_ACTION_CLIP, fps=4, max_tokens=4096, seed=0, temperature=0.0,
)
print("--- answer via think() " + "-" * 49)
print(answer2)
''')

nb.predict_run_explain(
    predict=(
        "Here is the question the whole lesson turns on. Asking for `<think>` "
        "makes the reasoning *visible*. Does it also change the *conclusion*? "
        "Commit to one of three: (a) the answers will be identical, (b) they "
        "will differ in wording but agree in substance, (c) they will "
        "sometimes disagree in substance."
    ),
    change=(
        "Run the cell below. It asks the same question of the same clip at the "
        "same seed and temperature, once bare and once wrapped, and prints both "
        "answers side by side with their token costs."
    ),
    explain=(
        "Whatever you got, explain the mechanism. If they agreed: is that "
        "because the reasoning did no work, or because this question was easy "
        "enough that both paths reach the same place? If they disagreed: the "
        "extra tokens changed the conditioning of every subsequent token — say "
        "why that is a different claim from 'the model thought about it'."
    ),
    hint=(
        "At `temperature=0` the only difference between the two runs is the "
        "text in the context. The think instruction adds tokens, and the "
        "generated trace adds many more. Every one of those tokens is part of "
        "what the final answer is conditioned on."
    ),
)

nb.code('''
def compare_think(prompt, *, seed=0, **media):
    """Same question, same seed, with and without the think wrapper."""
    started = time.perf_counter()
    bare = reasoner.ask(prompt, max_tokens=1024, seed=seed, temperature=0.0, **media)
    bare_stats = dict(reasoner.last_usage, latency_s=round(time.perf_counter() - started, 2))

    started = time.perf_counter()
    reasoning, wrapped = reasoner.think(prompt, max_tokens=1024, seed=seed,
                                        temperature=0.0, **media)
    wrapped_stats = dict(reasoner.last_usage,
                         latency_s=round(time.perf_counter() - started, 2))

    print("=== DIRECT " + "=" * 60)
    print(bare.strip())
    print(f"\\n  {bare_stats}")
    print()
    print("=== WITH <think> " + "=" * 54)
    print(f"[reasoning, {len(reasoning)} chars]")
    print(reasoning[:900] or "(none)")
    print(f"\\n[answer]\\n{wrapped.strip()}")
    print(f"\\n  {wrapped_stats}")
    return {"direct": bare, "reasoning": reasoning, "wrapped": wrapped,
            "direct_stats": bare_stats, "wrapped_stats": wrapped_stats}

cot = compare_think("What can be the next immediate action?",
                    videos=NEXT_ACTION_CLIP, fps=4)
''')

nb.code('''
# The cost of thinking, measured rather than asserted.
d, w = cot["direct_stats"], cot["wrapped_stats"]
out_d = d.get("completion_tokens")
out_w = w.get("completion_tokens")

print(f"{'':<14}{'out tokens':>12}{'latency s':>12}")
print(f"{'direct':<14}{str(out_d):>12}{d['latency_s']:>12.2f}")
print(f"{'with <think>':<14}{str(out_w):>12}{w['latency_s']:>12.2f}")
if out_d and out_w:
    print(f"{'ratio':<14}{out_w / out_d:>12.2f}{w['latency_s'] / d['latency_s']:>12.2f}")
print()
print("Both numbers are for YOUR machine and YOUR clip. They are not a property")
print("of the model. Re-measure whenever the question or the media changes.")

reasoning_log.append({
    "probe": "next_action_cot_ablation",
    "prompt": "What can be the next immediate action?",
    "media": NEXT_ACTION_CLIP.name,
    "reasoning": cot["reasoning"],
    "answer": cot["wrapped"],
    "answer_without_think": cot["direct"],
    "usage": w,
    "verdict": "TODO: fill this in yourself",
})
''')

# ------------------------------------------ 2b planning
nb.md("""
## Probe 2 — task planning

Higher level than a single action: decompose a stated goal into an ordered list
of subtasks. This is what lets a robot carry out a *described* objective instead
of a pre-scripted motion.

Source prompt again, verbatim — including the grammatical slip in "for
accomplish the task", which is worth leaving in so you can see that these
prompts are not delicate.
""")

nb.code('''
cc.show_image(PLANNING_IMAGE, caption="robot_planning.png")

PLAN_PROMPT = ("The task is to put flower into the red bottle. Generate a plan "
               "consisting of subtasks for accomplish the task.")

plan_text = reasoner.ask(PLAN_PROMPT, images=PLANNING_IMAGE,
                         max_tokens=4096, seed=0, temperature=0.0)
print(plan_text)
''')

nb.md("""
That is readable and unusable. To evaluate a plan — or to execute one — you need
it as a list, not as prose. Same move as Lesson 03: name the shape, forbid the
prose, validate the result.

Notice what the schema below asks for beyond the step text. `object` and
`gripper_state` exist because the *next* lesson can ground an object name to a
bounding box, and a step naming an object the model cannot also localise is a
step you cannot execute. Designing the schema around what you can check is the
skill here.
""")

nb.code('''
PLAN_SCHEMA_PROMPT = """The task is to put flower into the red bottle.
Generate a plan consisting of subtasks for accomplishing the task.

Reply with JSON only. No prose, no code fence. Use exactly this shape:
[
  {"step": 1,
   "action": "short imperative verb phrase",
   "object": "the single object this step acts on, as it appears in the image",
   "gripper_state": "open" or "closed"}
]
Order the steps so that each one is physically executable given the state left
by the step before it."""

plan_raw = reasoner.ask(PLAN_SCHEMA_PROMPT, images=PLANNING_IMAGE,
                        max_tokens=2048, seed=0, temperature=0.0)
plan = reasoner.parse_json(plan_raw)
print(json.dumps(plan, indent=2))
''')

nb.code('''
def check_plan(steps):
    """Structural checks on a plan. Says nothing about whether it is a GOOD plan."""
    problems = []
    if not isinstance(steps, list) or not steps:
        return ["plan is not a non-empty list"]

    numbers = [s.get("step") for s in steps if isinstance(s, dict)]
    if numbers != list(range(1, len(steps) + 1)):
        problems.append(f"step numbers are {numbers}, expected 1..{len(steps)}")

    for i, s in enumerate(steps):
        if not isinstance(s, dict):
            problems.append(f"entry {i} is not an object")
            continue
        for key in ("action", "object", "gripper_state"):
            if not s.get(key):
                problems.append(f"step {s.get('step', i)} is missing {key!r}")
        if s.get("gripper_state") not in ("open", "closed", None):
            problems.append(
                f"step {s.get('step', i)} has gripper_state="
                f"{s.get('gripper_state')!r}, expected 'open' or 'closed'"
            )

    # A grasp step whose gripper is already closed is not executable.
    for prev, cur in zip(steps, steps[1:]):
        if not (isinstance(prev, dict) and isinstance(cur, dict)):
            continue
        if "grasp" in str(cur.get("action", "")).lower() and prev.get("gripper_state") == "closed":
            problems.append(
                f"step {cur.get('step')} grasps but step {prev.get('step')} left "
                f"the gripper closed"
            )
    return problems

issues = check_plan(plan)
print("structurally valid" if not issues else "PROBLEMS:")
for item in issues:
    print(f"  - {item}")
''')

nb.predict_run_explain(
    predict=(
        "Change the goal, hold the image fixed. The scene will still be the "
        "same tabletop. Predict, for the goal *\"clear the table\"*: (a) will "
        "the number of steps go up or down; (b) will any object named in the "
        "flower plan reappear; (c) will the first step be the same?"
    ),
    change=(
        "Run the cell below, which asks for a plan for three different goals "
        "over the identical image at the identical seed."
    ),
    explain=(
        "The image supplied the same pixels every time. Everything that "
        "differed came from six words of goal text. Say what that implies about "
        "where the plan actually comes from — and then say what it implies "
        "about a plan for a goal the scene cannot support."
    ),
    hint=(
        "Watch for a goal producing a plan that references an object which is "
        "not in the image. That is the failure mode this whole lesson is "
        "building towards, and it is easiest to catch when you have three plans "
        "over one picture to compare."
    ),
)

nb.code('''
GOALS = [
    "put flower into the red bottle",
    "clear the table",
    "hand the red bottle to the person",
]

plans = {}
for goal in GOALS:
    prompt = PLAN_SCHEMA_PROMPT.replace("put flower into the red bottle", goal)
    text = reasoner.ask(prompt, images=PLANNING_IMAGE, max_tokens=2048,
                        seed=0, temperature=0.0)
    try:
        plans[goal] = reasoner.parse_json(text)
    except ValueError as exc:
        print(f"  {goal!r}: parse failed — {str(exc)[:100]}")
        plans[goal] = []

print(f"{'goal':<42}{'steps':>7}  first action")
print("-" * 90)
for goal, steps in plans.items():
    first = steps[0].get("action") if steps else "(none)"
    print(f"{goal:<42}{len(steps):>7}  {first}")

print()
for goal, steps in plans.items():
    objects = sorted({str(s.get("object")) for s in steps if isinstance(s, dict)})
    print(f"{goal!r}\\n    objects: {objects}")
''')

# ------------------------------------------ 2c assisted task
nb.md("""
## Probe 3 — assisted-task next action

Now supply **both** an overall goal **and** the current step, and ask for the
next action. This is the pattern behind an assistant that guides a person — or a
robot — through a multi-step procedure.

Compare it against Probe 1. There, the model had to infer intent from pixels.
Here it is told the intent and told where in the procedure it is, and only has
to work out what follows. That is a much narrower question, and the answers
should be correspondingly more specific.

The source prompt below is unchanged; the clip is the public substitute for its
private toaster footage, so the phrasing mentions bread and the video does not.
Leave that mismatch in place for now — it is the setup for the debugging lab.
""")

nb.code('''
cc.show_video(ASSISTED_CLIP, caption="assisted_task_next_action.mp4")

ASSISTED_PROMPT = """This is the overall task that the agent is trying to complete: "The robot needs to toast the bread"
In the video, the agent is trying to follow the instruction (a single step out of many to complete the overall task): "toast the bread_slice."
What should be the next action of the agent?
Answer the question using the following format:
<think>
Your reasoning.
</think>
Write your final answer immediately after the </think> tag."""

assisted_raw = reasoner.ask(ASSISTED_PROMPT, videos=ASSISTED_CLIP, fps=4,
                            max_tokens=4096, seed=0, temperature=0.0)
assisted_thought, assisted_answer = split_think(assisted_raw)

print("--- reasoning " + "-" * 58)
print(assisted_thought[:1500] or "(none)")
print("--- answer " + "-" * 61)
print(assisted_answer)
''')

nb.md("""
### Prompt structure as a skill

Three probes, three shapes. What actually changed, and what each change buys:

| Element added | Probe | What it does to the answer |
|---|---|---|
| nothing (bare question) | 1 | the model must infer the goal from the scene; answers are generic and often describe rather than command |
| an **overall goal** | 2 | answers become goal-directed; the model will now name objects it needs, including ones it cannot see |
| goal **plus current step** | 3 | answers become the *next* action specifically, not any plausible action; scope narrows sharply |
| a **format constraint** | 2, 3 | output becomes machine-readable; also, and less obviously, it constrains content — a schema with a `gripper_state` field makes the model commit to a gripper state it might otherwise have left vague |
| the **`<think>` wrapper** | 1, 3 | exposes the trace; changes the tokens the answer is conditioned on |

That fourth row is the one people underestimate. A format constraint is not
cosmetic. Asking for `{"object": ...}` forces a commitment to a specific object
where prose could have said "the item". Sometimes that commitment is the useful
part; sometimes it manufactures false precision, because the model will fill the
field whether or not it knows.
""")

# ------------------------------------------ common sense
nb.md("""
## Probe 4 — physical common sense

An embodied agent has to know what the world permits before it acts. The source
course asks a question with an obvious answer:

> Can the countertop support the weight of the toaster?

The right answer is yes, and the model says yes, and everyone nods. That is a
**confirmation-seeking probe** and it teaches almost nothing, because a model
that always answered "yes" would pass it.

So run it — and then run its adversarial twin, a question whose correct answer
is **no**. Probing for failure is worth more than probing for confirmation.
""")

nb.code('''
cc.show_video(COMMON_SENSE_CLIP, caption="common_sense_reasoning.mp4")

COUNTERTOP_PROMPT = """Can the countertop support the weight of the toaster?
Answer the question using the following format:

<think>
Your reasoning.
</think>

Write your final answer immediately after the </think> tag."""

cs_raw = reasoner.ask(COUNTERTOP_PROMPT, videos=COMMON_SENSE_CLIP, fps=4,
                      max_tokens=2048, seed=0, temperature=0.0)
cs_thought, cs_answer = split_think(cs_raw)
print("--- reasoning " + "-" * 58)
print(cs_thought[:1200] or "(none)")
print("--- answer " + "-" * 61)
print(cs_answer)
''')

nb.code('''
# Four probes whose correct answers are all "no". A model that agrees with any
# of them has told you something useful about its failure surface.
ADVERSARIAL = [
    "Could the robot lift the entire table by grasping a single sheet of paper "
    "resting on it? Answer yes or no first, then justify in one sentence.",
    "Is it possible to pour liquid from a container that is currently upside "
    "down and empty? Answer yes or no first, then justify in one sentence.",
    "Can an object be placed on a surface that is behind the camera and not "
    "visible in this footage? Answer yes or no first, then justify in one "
    "sentence.",
    "Would releasing an unsupported object at this height cause it to remain "
    "stationary in mid-air? Answer yes or no first, then justify in one "
    "sentence.",
]

adversarial_results = []
for probe in ADVERSARIAL:
    reply = reasoner.ask(probe, videos=COMMON_SENSE_CLIP, fps=2,
                         max_tokens=300, seed=0, temperature=0.0)
    said_no = reply.strip().lower().lstrip("*# ").startswith("no")
    adversarial_results.append({"prompt": probe, "reply": reply, "said_no": said_no})
    print(f"[{'PASS' if said_no else 'CHECK'}] {probe[:62]}...")
    print(f"        {reply.strip()[:180]}")
    print()

print(f"answered 'no' on {sum(r['said_no'] for r in adversarial_results)}/{len(ADVERSARIAL)}")
print("A 'CHECK' is not automatically a failure — read the justification. The")
print("string test is crude and the model may have hedged rather than agreed.")
''')

# ------------------------------------------ debugging lab
nb.md("""
## Debugging lab: confident, fluent, and wrong

**Symptom.** No error. No warning. HTTP 200, well-formed JSON, a chain of
thought that reads like careful deliberation — and an answer that is simply not
true about the image in front of it.

This is the hardest failure in the course, because every instrument you have so
far reports success. `check_text` passes: it is fluent language. `parse_json`
passes: it is valid JSON. The exit code is zero. The plan even has correctly
numbered steps.

**Hypothesis.** The model completes the *shape* of the request regardless of
whether the evidence supports it. Ask where a blue mug is in a scene with no
blue mug, and the strong prior — questions have answers, mugs sit on tables —
overwhelms the weak visual evidence for "there is no such thing here."

Reproduce it deliberately.
""")

nb.code('''
# Deliberately wrong by construction: ask about an object that is not there.
# Adjust the object name if your scene happens to contain one.
GHOST = "blue ceramic mug"

ghost_thought, ghost_answer = reasoner.think(
    f"Where is the {GHOST} in this image? Describe its position relative to the "
    f"other objects, and state how confident you are.",
    images=PLANNING_IMAGE, max_tokens=800, seed=0, temperature=0.0,
)

print("--- reasoning " + "-" * 58)
print(ghost_thought[:1200] or "(none)")
print("--- answer " + "-" * 61)
print(ghost_answer)
print()
print("Every existing instrument says this is fine:")
print(f"  check_text : {cc.check_text(ghost_answer)}")
''', tags=["teaching-antipattern"])

nb.md("""
**Diagnosis.** Three checks, in increasing cost, none of which needs a human to
read the output. Each catches a different kind of wrongness, so they are
complements rather than alternatives.

1. **Ask the model to verify its own claim against the image.** Cheap, and works
   surprisingly often for existence questions, because verification is an easier
   task than localisation. It is also *partly circular* — the same model, the
   same weights, the same blind spots — so a pass is weak evidence and a fail is
   strong evidence.
2. **Sample across seeds and look for agreement.** If five samples at
   `temperature>0` give five different positions for the mug, the model has no
   information about it and is drawing from a prior. Consistency does not prove
   correctness, but *inconsistency* reliably indicates absence of evidence.
3. **Look for the reasoning contradicting the answer.** The trace sometimes says
   "I cannot see a blue mug" and the answer then places one on the left. A
   string check over the pair catches that for free.
""")

nb.code('''
# Check 1 — self-verification, phrased so that "no" is an easy answer to give.
verify = reasoner.ask(
    f"Look carefully at this image. Is there a {GHOST} visible in it? "
    f"It is entirely acceptable for the answer to be no. "
    f"Reply with JSON only: "
    f'{{"present": true or false, "confidence": 0.0 to 1.0, "evidence": "one sentence"}}',
    images=PLANNING_IMAGE, max_tokens=300, seed=0, temperature=0.0,
)
verdict = reasoner.parse_json(verify)
print(json.dumps(verdict, indent=2))
print()
print(f"self-verification says present={verdict.get('present')}")
''')

nb.code('''
# Check 2 — cross-seed agreement. Same question, five different seeds, above
# greedy temperature so the samples can actually differ.
samples = []
for seed in range(5):
    reply = reasoner.ask(
        f"In one short phrase, where is the {GHOST}? Answer with a position only.",
        images=PLANNING_IMAGE, max_tokens=60, seed=seed, temperature=0.8, top_p=0.95,
    )
    samples.append(reply.strip().lower())
    print(f"  seed {seed}: {reply.strip()[:90]}")

distinct = len(set(samples))
print()
print(f"distinct answers across 5 seeds : {distinct}")
print(f"agreement                       : {(6 - distinct) / 5:.0%} (crude, exact-match)")
print()
print("High disagreement on a question with one true answer means the model is")
print("sampling from a prior rather than reading the image.")
''')

nb.code('''
# Check 3 — does the reasoning contradict the answer?
NEGATIONS = ("no ", "not visible", "cannot see", "is not present", "there is no",
             "does not appear", "absent", "unable to locate", "i do not see")

def reasoning_contradicts_answer(reasoning, answer, negations=NEGATIONS):
    """True when the trace hedges or denies but the answer commits anyway."""
    low_r, low_a = reasoning.lower(), answer.lower()
    trace_denies = any(n in low_r for n in negations)
    answer_denies = any(n in low_a for n in negations)
    return trace_denies and not answer_denies

flagged = reasoning_contradicts_answer(ghost_thought, ghost_answer)
print(f"reasoning denies but answer commits : {flagged}")
print()
print("This is a blunt string test and it will miss paraphrases. It costs one")
print("microsecond and no tokens, so run it on everything; treat a hit as a")
print("reason to look, not as a verdict.")
''')

nb.md("""
**Repair.** There is no prompt that makes a model incapable of being wrong. What
there is:

- **Give the model an exit.** "It is entirely acceptable for the answer to be
  no" measurably changes behaviour on existence questions, because the default
  framing of a question implies its premise.
- **Ask for a confidence field and use it.** A model's self-reported confidence
  is poorly calibrated, but it is not noise — a 0.3 is worth treating differently
  from a 0.95.
- **Ground before you plan.** Lesson 05 gives you bounding boxes. A planning step
  that names an object the grounder cannot localise is a step you reject before
  it reaches an actuator. This is the applied exercise below.
- **Never let a single sample drive hardware.** Cross-seed agreement is cheap
  next to a collision.

**Verification.** A repair you cannot measure is a hope. Below, the three checks
run together as one screening function, over a claim you know is false and a
claim you know is true. A screen that flags both, or neither, is not a screen.
""")

nb.code('''
def screen_claim(question, image, *, n_seeds=3, temperature=0.8):
    """Run all three checks and return a dict. No human in the loop."""
    reasoning, answer = reasoner.think(question, images=image, max_tokens=600,
                                       seed=0, temperature=0.0)

    votes = []
    for seed in range(n_seeds):
        votes.append(reasoner.ask(question + " Answer in one short phrase.",
                                  images=image, max_tokens=60,
                                  seed=seed, temperature=temperature,
                                  top_p=0.95).strip().lower())

    return {
        "question": question,
        "answer": answer.strip(),
        "agreement": round((n_seeds - len(set(votes)) + 1) / n_seeds, 2),
        "contradiction": reasoning_contradicts_answer(reasoning, answer),
        "fluent": bool(cc.check_text(answer)),
    }

true_claim = screen_claim("Where is the robot arm in this image?", PLANNING_IMAGE)
false_claim = screen_claim(f"Where is the {GHOST} in this image?", PLANNING_IMAGE)

for label, row in (("TRUE claim", true_claim), ("FALSE claim", false_claim)):
    print(f"{label}")
    print(f"  agreement     : {row['agreement']}")
    print(f"  contradiction : {row['contradiction']}")
    print(f"  fluent        : {row['fluent']}   <- passes for both, which is the point")
    print(f"  answer        : {row['answer'][:110]}")
    print()

print("If agreement is not lower for the false claim on your machine, the screen")
print("does not discriminate here. Say so, and say what you would try next —")
print("more seeds, a higher temperature, or a semantic rather than exact-match")
print("comparison. A screen that does not separate the two cases is worse than")
print("no screen, because it manufactures confidence.")
''')

nb.code('''
reasoning_log.extend([
    {"probe": "planning_goal_ablation", "prompt": PLAN_SCHEMA_PROMPT,
     "media": PLANNING_IMAGE.name, "answer": json.dumps(plans, ensure_ascii=False),
     "verdict": "TODO"},
    {"probe": "assisted_task", "prompt": ASSISTED_PROMPT, "media": ASSISTED_CLIP.name,
     "reasoning": assisted_thought, "answer": assisted_answer, "verdict": "TODO"},
    {"probe": "common_sense_countertop", "prompt": COUNTERTOP_PROMPT,
     "media": COMMON_SENSE_CLIP.name, "reasoning": cs_thought, "answer": cs_answer,
     "verdict": "TODO"},
    {"probe": "adversarial_physical", "prompt": "four questions whose answer is no",
     "media": COMMON_SENSE_CLIP.name, "answer": json.dumps(adversarial_results),
     "verdict": "TODO"},
    {"probe": "hallucinated_object", "prompt": f"Where is the {GHOST}?",
     "media": PLANNING_IMAGE.name, "reasoning": ghost_thought, "answer": ghost_answer,
     "screen": false_claim,
     "verdict": "WRONG — the object is not in the image. Replace this text with "
                "your own account of where the reasoning went off."},
])

log_path = OUTPUT_DIR / "reasoning_log.jsonl"
with log_path.open("w", encoding="utf-8") as fh:
    for row in reasoning_log:
        fh.write(json.dumps(row, ensure_ascii=False) + "\\n")

print(f"wrote {len(reasoning_log)} probes to {log_path}")
print()
print("Every entry has verdict='TODO'. Go through them and write a real verdict")
print("for each: right, wrong, or unverifiable — and for anything wrong, say")
print("which sentence of the reasoning was the first one you disagreed with.")
''')

nb.checkpoint(
    "The log exists, has at least six probes, and contains at least one case "
    "documented as wrong.",
    '''
rows = [json.loads(line) for line in log_path.read_text().splitlines() if line]
assert len(rows) >= 6, f"only {len(rows)} probes logged"
assert any("WRONG" in str(r.get("verdict", "")).upper() for r in rows), \\
    "no probe is documented as wrong — the lesson is not complete without one"
print(f"checkpoint passed: {len(rows)} probes, at least one documented failure")
''',
)

# ------------------------------------------ exercises
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "Make the plan strictly parseable",
    goal=(
        "Rewrite a planning prompt so that its output parses first time, every "
        "time, across five different goals — without post-processing."
    ),
    instructions=(
        "1. Take `PLAN_SCHEMA_PROMPT` and run it over five goals of your own "
        "choosing on `robot_planning.png`. Count how many parse on the first "
        "attempt with `reasoner.parse_json`.\n"
        "2. For every failure, write down what the model did wrong: a fence, a "
        "preamble, a trailing comment, a key renamed, a string where a list "
        "belonged.\n"
        "3. Change **the prompt**, not the parser, until all five parse. You are "
        "not allowed to strip anything after the fact.\n"
        "4. Then break it on purpose: find one instruction whose removal makes "
        "the parse fail again, and say why that instruction was carrying the "
        "load."
    ),
    success=(
        "Five out of five parse with no post-processing, and you can name the "
        "one instruction that is doing most of the work."
    ),
    starter='''
MY_GOALS = [
    "put flower into the red bottle",
    # ... four more of your own
]

def parse_rate(prompt_template, goals, image):
    """Fraction of goals whose plan parses on the first attempt."""
    raise NotImplementedError
''',
    hints=[
        "The three usual culprits, in order of frequency: a markdown fence, a "
        "sentence of preamble, and a trailing explanation after the closing "
        "bracket. Each has a different instruction that suppresses it — find "
        "out which of the three your model actually does.",
        "Putting the literal shape in the prompt does more than describing it. "
        "`[{\"step\": 1, \"action\": \"...\"}]` beats 'a list of objects with a "
        "step number and an action', because the model is completing a pattern "
        "rather than following a description.",
    ],
    solution_ref="solutions/04_solutions.ipynb",
)

nb.exercise(
    "applied",
    "A plan validator that checks groundability",
    goal=(
        "Reject plans that reference objects the model cannot actually find in "
        "the image — the check that would have caught the ghost mug."
    ),
    instructions=(
        "1. Write `can_ground(object_name, image)` that asks the model for a "
        "bounding box for one named object and returns "
        "`(found: bool, confidence: float, box)`. Give the model an explicit "
        "way to say the object is absent — that is the whole point.\n"
        "2. Write `validate_plan_grounding(plan, image)` that runs `can_ground` "
        "on every distinct `object` in a plan and returns the ungroundable ones.\n"
        "3. Run it over all three plans from the goal ablation. Report how many "
        "steps survive.\n"
        "4. **Verify the validator itself.** Insert a step naming an object you "
        "know is absent and confirm it is caught. A validator you have not tried "
        "to fool is a validator you do not know works.\n"
        "5. Write `outputs/04/grounding_report.md` with the rejection rate and "
        "one example each of a correct rejection and a false rejection."
    ),
    success=(
        "Every plan gets a groundability verdict per step, your injected fake "
        "object is caught, and your report contains at least one honest false "
        "rejection — a real object the grounder missed."
    ),
    starter='''
def can_ground(object_name, image, *, threshold=0.5):
    """Ask for a box for one object; allow 'not present' as an answer."""
    raise NotImplementedError

def validate_plan_grounding(plan, image):
    """Return {'ok': [...], 'ungroundable': [...]} over the plan's objects."""
    raise NotImplementedError
''',
    hints=[
        "This is Lesson 05's grounding, used one lesson early. You only need "
        "the boolean here, not accurate coordinates, so a prompt asking "
        "'{\"present\": bool, \"bbox_2d\": [x1,y1,x2,y2] or null}' is enough.",
        "False rejections matter more than they look. If your validator rejects "
        "'flower' because the model calls it 'plant', you have built a "
        "vocabulary matcher, not a grounder. Consider asking the grounder to "
        "return the name it would use, and compare loosely.",
    ],
    solution_ref="solutions/04_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "A self-consistency harness, and does agreement predict correctness?",
    goal=(
        "Build the harness, then answer the question that determines whether it "
        "is worth running: on your small hand-labelled set, does higher "
        "agreement actually mean a higher chance of being right?"
    ),
    instructions=(
        "1. Write `self_consistency(question, media, *, n=8, temperature=0.8)` "
        "that samples N answers, **clusters semantically equivalent ones** "
        "(exact string match is not good enough — 'to the left of the bottle' "
        "and 'left of the red bottle' are one answer), and returns the majority "
        "answer with an agreement score.\n"
        "2. For clustering, either normalise and compare, or ask the reasoner "
        "itself to group them. If you use the model as the judge, say why that "
        "is partly circular and what it would take to break the circle.\n"
        "3. Hand-label a small set: at least 12 question/media pairs across the "
        "four clips in this lesson, each with a right answer *you* determined by "
        "looking. Include at least four you expect the model to get wrong. Save "
        "it as `outputs/04/labelled_probes.json`.\n"
        "4. Run the harness over the set. For each item record agreement, the "
        "majority answer, and whether it was correct.\n"
        "5. **Answer the question.** Bucket by agreement and report accuracy per "
        "bucket. Does accuracy rise with agreement? Report the numbers even if "
        "the answer is no.\n"
        "6. State your sample size and be honest about what 12 items can and "
        "cannot support."
    ),
    success=(
        "`outputs/04/consistency_report.md` contains the accuracy-by-agreement "
        "table, your labelled set is in the repo so someone else could re-run "
        "it, and your conclusion is stated with its uncertainty rather than as "
        "a finding."
    ),
    starter='''
def self_consistency(question, media, *, n=8, temperature=0.8, images=None, videos=None):
    """Sample n answers, cluster them, return (majority, agreement, clusters)."""
    raise NotImplementedError

LABELLED = []   # [{"question":..., "media":..., "kind":"image"|"video", "truth":...}, ...]
''',
    hints=[
        "Agreement is only meaningful if the samples can differ. At "
        "`temperature=0` you get the same answer N times and 100% agreement on "
        "everything, including things the model is wrong about. Sweep the "
        "temperature and pick a value where a question you know is hard "
        "actually produces variety.",
        "Include easy items in your labelled set as well as hard ones. If every "
        "item is hard, agreement will be uniformly low and you will find no "
        "relationship — not because there is none, but because you removed the "
        "variance you were trying to measure.",
        "N=8 at temperature 0.8 is 8 requests per item, and 12 items is 96 "
        "requests. Estimate the wall clock from `reasoner.stats()` before you "
        "start the loop, and use short `max_tokens` — you need the answer, not "
        "an essay.",
    ],
    solution_ref="solutions/04_solutions.ipynb",
)

# ------------------------------------------ assessment
nb.md("""
## Assessment and reflection

### Knowledge check

1. Cosmos 3 has no reasoning-mode flag. Where does the `<think>` structure come
   from, and what follows from that about how much you can rely on it?
2. `split_think()` returns `("", text)` when there is no `</think>`. Why is that
   better than raising, and what does an empty reasoning string tell you?
3. You added the think wrapper at a fixed seed and the final answer changed.
   Give the mechanism, without using the word "thought".
4. Probe 1 and Probe 3 ask about the next action. What exactly does Probe 3 have
   that Probe 1 lacks, and how does it narrow the answer?
5. Adding a `gripper_state` field to a plan schema changes the content, not only
   the format. How, and when is that a problem rather than a benefit?
6. Why is "Can the countertop support the toaster?" a weak probe? Write a
   stronger one for the same clip.
7. Name the three checks in the screening function and say what kind of
   wrongness each one catches.
8. Why is asking the model to verify its own claim only partly useful, and what
   does a *failed* self-verification tell you that a passed one does not?

### Practical completion test

1. Elicit a chain of thought and split it, on a clip of your choice.
2. Produce a plan that passes `check_plan` first try.
3. Produce a case where the model is fluent and wrong, and name which of the
   three checks caught it.
4. State the token cost ratio of chain-of-thought against direct answering that
   you measured.
5. Point at one entry in your log where the reasoning is plausible and the
   answer is not, and explain the first sentence you disagreed with.
""")

nb.code('''
def self_test():
    passed = []

    rows = [json.loads(line) for line in log_path.read_text().splitlines() if line]
    assert len(rows) >= 6, f"only {len(rows)} probes in the log"
    passed.append(f"{len(rows)} probes logged")

    assert any("WRONG" in str(r.get("verdict", "")).upper() for r in rows), \\
        "no documented failure case"
    passed.append("at least one documented failure case")

    todo = [r["probe"] for r in rows if str(r.get("verdict", "")).strip() == "TODO"]
    if todo:
        passed.append(f"NOTE: {len(todo)} probe(s) still have verdict='TODO': {todo}")
    else:
        passed.append("every probe has a written verdict")

    r, a = reasoner.think("What is happening here?", images=PLANNING_IMAGE,
                          max_tokens=400, seed=0, temperature=0.0)
    assert a, "think() returned an empty answer"
    passed.append(f"think() works (reasoning {len(r)} chars, answer {len(a)} chars)")

    assert not check_plan(plan), "the reference plan does not pass check_plan"
    passed.append("the structured plan passes check_plan")

    for item in passed:
        print(f"  PASS  {item}" if not item.startswith("NOTE") else f"  ----  {item}")
    return passed

_ = self_test()
''')

nb.md("""
### Summary

- The `<think>` structure is a **prompt convention**, not a mode. It can be
  ignored, so parse it defensively.
- A chain of thought is auditable evidence about the model's process. It is not
  evidence about the world, and the answer does not have to follow from it.
- Three prompt shapes, three scopes: bare question (infer the goal), goal
  (goal-directed), goal plus current step (the *next* action specifically).
- A format constraint changes content, not only shape. It forces commitments the
  model might otherwise have left vague — sometimes usefully, sometimes as false
  precision.
- Probe for failure, not for confirmation. A question whose right answer is "no"
  is worth ten questions whose right answer is "yes".
- Fluent, confident and wrong passes every instrument you had before this
  lesson. Self-verification, cross-seed agreement, and
  reasoning-versus-answer contradiction each catch a different part of it.
- Nothing here makes the model correct. It makes wrongness *detectable*, which
  is what you need before the output reaches an actuator.

### Common misconceptions

| Belief | Correction |
|---|---|
| "The chain of thought shows how the model reached the answer" | It shows tokens generated before the answer. Whether they caused it is a separate, hard question. |
| "Asking it to think makes it more accurate" | It changes the conditioning. Whether accuracy improves is measurable, per task, and not guaranteed. |
| "Detailed and specific means correct" | Specificity comes from the format constraint. A model will fill a required field whether or not it knows. |
| "It said it was confident" | Self-reported confidence is poorly calibrated. Useful as a weak signal, never as a gate. |
| "High agreement across seeds means it is right" | It means the model is consistent. Consistent priors are still priors — but *dis*agreement is a reliable sign of missing evidence. |
| "`check_text` passing means the output is usable" | It means the output is language. That is a much weaker claim. |

### Suggested extensions

- Run the goal ablation with a goal the scene cannot support ("put the flower in
  the microwave") and see whether the model refuses, invents a microwave, or
  substitutes something.
- Vary `fps` on the assisted-task probe and see at what sampling rate the answer
  stops being about the right step.
- Compare `<think>` against a numbered-steps instruction ("reason in steps 1, 2,
  3, then answer"). Is the trace more useful in one form for automatic checking?

### Mastery checklist

- [ ] I can elicit and split a chain of thought.
- [ ] I know what changes between the three prompt shapes, and why.
- [ ] I have measured the cost of chain-of-thought on my own machine.
- [ ] I have produced a confident, fluent, wrong answer on purpose.
- [ ] I have an automatic check that separates a true from a false claim.
- [ ] `outputs/04/reasoning_log.jsonl` has a real verdict on every probe.
- [ ] I can say why a fluent trace is not evidence of a correct answer.

**Leave the NIM running.** Lesson 05 needs it, and stops it at the end.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "04_reasoning_embodied.ipynb")
