"""Build 19_capstone_synthetic_data_flywheel.ipynb.

Not a lesson. A project brief plus scaffolding.

The learner has finished eighteen lessons and can, individually, caption a clip,
write a spec, run a generation, verify an output and measure a run. What they
have never done is make those five things cooperate on one GPU, unattended, with
a budget, while something goes wrong.

So this notebook supplies:

* the problem and the deliverables, stated as measurable criteria;
* an interface contract for each of six stages, with a runnable skeleton and an
  automated ``check_stage_N()``;
* four design decisions with no correct answer, which the learner must make and
  defend in writing;
* mandatory profiling and a prediction they have to commit to before running;
* four failures they must survive without losing completed work.

It supplies **no implementations**. Every stage body is `TODO` plus
`NotImplementedError`. The reference implementation lives in
``solutions/19_capstone_reference.ipynb`` and is one defensible answer, not the
answer.

Design notes worth recording:

**Why reduced mode is Edge and not Nano.** Edge cannot do transfer
(COSMOS3_FACTS.md §1: no audio, no transfer, 256p/480p). That looks like a
limitation and is actually useful: it forces the modality decision to be made
*as a decision*, argued and spec-validated, before any GPU time exists to spend
on it. The learner writes and validates a `video2video` spec they cannot run,
which is exactly the discipline Lesson 08 was teaching.

**Why batching is a first-class knob.** ``Generator.run`` accepts a list of
specs and writes them as one JSONL batch job — one model load for N samples. At
256p/61f/10steps the compute per variant is small enough that process startup
dominates, so batch size is the single biggest lever on reduced-mode wall clock.
It is also a genuine tradeoff (a crash loses the whole batch), which makes it
worth a decision rather than a default.

**Why the capstone re-reasons rather than reading outputs/03.** Lesson 03's
scene records are the right shape but were produced with a different prompt at a
different fps, and the capstone needs the plausibility baseline on the *source*
clip to calibrate the judge. Reading them is offered as a shortcut and is not the
default.

**The one piece of new infrastructure.** ``cosmos_course/pipeline.py`` — Ledger,
StageClock, DeviceSampler, run_stage. Resume and stage attribution are not
lesson content and are not Cosmos-specific, so they belong in the package. The
notebook is then orchestration over ``cosmos_course`` and nothing else.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402
from capstone_checks import (  # noqa: E402
    N_STAGES,
    CHECK_DECISIONS,
    CHECK_STAGE_0,
    CHECK_STAGE_1,
    CHECK_STAGE_2,
    CHECK_STAGE_3,
    CHECK_STAGE_4,
    CHECK_STAGE_5,
    CHECK_STAGE_6,
    FOUNDATION_CHECK_NAMES,
    DECISION_CONTRACT,
    MANIFEST_CONTRACT,
    N_FOUNDATION_CHECKS,
    N_REPORT_SECTIONS,
    N_STAGE_CHECKS,
    REPORT_SECTION_HEADINGS,
    REPORT_SECTIONS,
    STAGE_CHECK_NAMES,
)

ROOT = Path(__file__).resolve().parent.parent

# Spelled-out counts, so the prose in this file and the prose in
# assets/reference/CAPSTONE_RUBRIC.md cannot drift apart again. See
# tools/capstone_checks.py for the argument.
_WORD = {5: "five", 6: "six", 7: "seven", 8: "eight"}
N_CHECKS_WORD = _WORD[N_STAGE_CHECKS]                 # "seven"
N_FOUNDATION_WORD = _WORD[N_FOUNDATION_CHECKS]        # "five"
N_SECTIONS_WORD = _WORD[N_REPORT_SECTIONS]            # "eight"
ALL_CHECKS = f"`{STAGE_CHECK_NAMES[0]}()` … `{STAGE_CHECK_NAMES[-1]}()`"
FOUNDATION_CHECKS = (f"`{FOUNDATION_CHECK_NAMES[0]}()` … "
                     f"`{FOUNDATION_CHECK_NAMES[-1]}()`")

nb = Notebook("Lesson 19 — Capstone: the synthetic data flywheel")

# =====================================================================
# 1. TITLE BLOCK
# =====================================================================
nb.md("""
# Lesson 19 — Capstone: the synthetic data flywheel

**What you will build.** A pipeline that takes a handful of real recordings and
returns a larger, screened, physically plausible set of synthetic clips — with
the cost of every accepted clip measured, the accept/reject policy defended, and
an honest account of what the result does not show.

| | |
|---|---|
| **Time** | ~5 hours. The reduced pipeline itself is a 45–60 minute unattended run; the rest is design, measurement and writing. |
| **GPU** | 1 × H100 80 GB, scheduled between the reasoner and the generator. They cannot both hold the card. |
| **Downloads** | **None in reduced mode** if you have finished Lessons 02 and 06 (Reasoner NIM image and profile, Cosmos3-Edge). Full mode needs Cosmos3-Nano, **34.9 GB**, and is opt-in. |
| **Prerequisites** | Lessons 03, 05, 07, 08, 12, 14, 18. Effectively the whole course. |
| **Graded against** | `assets/reference/CAPSTONE_RUBRIC.md`. Read it *before* you start. |
| **You will write** | `outputs/capstone/manifest.jsonl`, `outputs/capstone/metrics.json`, `outputs/capstone/REPORT.md` |
""")

# =====================================================================
# 2. LEARNING OBJECTIVES
# =====================================================================
nb.md("""
## Learning objectives

By the end of this capstone you can:

1. **Design** a six-stage pipeline from real clips to screened synthetic data,
   under a stated budget in GPU-minutes and gigabytes, and **defend** every
   stage boundary.
2. **Implement** each stage against a published interface contract and
   **verify** the contract with an automated check before spending GPU time.
3. **Schedule** two models that cannot coexist on one 80 GB card, and
   **measure** the switching cost as a fraction of wall clock.
4. **Predict** the cost per accepted clip from your Lesson 06 calibration,
   **measure** it, and **reconcile** the two by naming the dominant error term.
5. **Define** a diversity criterion that a machine can compute, **apply** it, and
   **state** how a degenerate generator could satisfy it.
6. **Choose** an accept/reject threshold, **argue** it as a precision/recall
   tradeoff, and **quantify** your agreement with it by spot-checking.
7. **Survive** four specific failures — a rejected clip, an OOM, a dead NIM and a
   malformed model response — without losing completed work, and **classify**
   each one correctly.
8. **Profile** the pipeline: throughput, peak device VRAM, per-stage wall clock,
   and **identify** the bottleneck with a number attached.
9. **Report** the result against a supplied template, including a section that
   states what the evidence does not support.
""")

# =====================================================================
# 3. ENVIRONMENT
#
# This comes before the brief on purpose. The brief, the budget and the six
# stage contracts all refer to what these two cells print, and reading two
# thousand words about a pipeline you have not yet configured is the wrong way
# round.
# =====================================================================
nb.md("""
## Environment

The two code cells below come first, before the brief. Everything after them —
the problem, the budget, the six stage contracts — refers to what they print.
""")

nb.code('__lesson__ = "capstone"   # OUTPUT_DIR resolves to outputs/capstone\n\n' + SETUP_CELL)

nb.md("""
### Configuration

Two modes, both first-class. `reduced` exists so you can validate the whole
pipeline end to end before spending hours on it; it is not a toy. `full` is what
you would actually ship, and it is opt-in with the download and the runtime
stated before anything starts.

Everything downstream reads this cell. If you want to change the shape of the
run, change it here and nowhere else — the rubric checks that the reduced/full
switch is one edit.
""")

nb.code('''
import json
import shutil
import subprocess
import time
from datetime import datetime, timezone

from cosmos_course.measure import MeasurementLog
from cosmos_course.models import Generator, Reasoner
from cosmos_course.nim import NimConfig, nim_status, start_nim, stop_nim
from cosmos_course.pipeline import DeviceSampler, Ledger, StageClock, run_stage

# ---------------------------------------------------------------------------
# The two profiles. MODE comes from the setup cell above (COSMOS_COURSE_MODE).
#
# reduced: Cosmos3-Edge at the 256 tier. Edge is 4B, ~12 GB of VRAM, and does
#          NOT support transfer or audio (COSMOS3_FACTS.md section 1). That
#          constraint is deliberate here -- see the modality decision below.
# full:    Cosmos3-Nano at 480. 16B total / 8B active, 34.9 GB download,
#          32 GB inference VRAM, every model mode. Hours, not minutes.
# ---------------------------------------------------------------------------
PROFILES = {
    "reduced": {
        "model": "Cosmos3-Edge",
        "resolution": "256",       # tier NAME, not a pixel height
        "num_frames": 61,          # Edge is documented for 50-150 frames
        "num_steps": 10,
        "fps": 24,
        "n_sources": 3,
        "variants_per_source": 3,
        "gen_batch_size": 3,       # specs per Generator.run -- see decision 4
        "judge_fps": 2.0,
        "budget_minutes": 90,
    },
    "full": {
        "model": "Cosmos3-Nano",
        "resolution": "480",
        "num_frames": 121,
        "num_steps": 35,
        "fps": 24,
        "n_sources": 6,
        "variants_per_source": 4,
        "gen_batch_size": 4,
        "judge_fps": 4.0,
        "budget_minutes": None,    # no budget; this one takes hours
    },
}
PROFILE = PROFILES[MODE]

# An explicit COSMOS_COURSE_MODEL wins over the profile, so you can run reduced
# mode on Nano to exercise transfer. Everything else follows the profile.
MODEL = os.environ.get("COSMOS_COURSE_MODEL") or PROFILE["model"]

RES        = PROFILE["resolution"]
N_FRAMES   = PROFILE["num_frames"]
N_STEPS    = PROFILE["num_steps"]
FPS        = PROFILE["fps"]
ASPECT     = "16,9"                      # comma. Not a colon, not a float.
N_SOURCES  = PROFILE["n_sources"]
PER_SOURCE = PROFILE["variants_per_source"]
GEN_BATCH_SIZE = PROFILE["gen_batch_size"]
JUDGE_FPS  = PROFILE["judge_fps"]
BUDGET_MIN = PROFILE["budget_minutes"]
BASE_SEED  = 2026

N_PLANNED = N_SOURCES * PER_SOURCE

GENERATED_DIR = OUTPUT_DIR / "generated"
GENERATED_DIR.mkdir(parents=True, exist_ok=True)

MANIFEST_PATH = OUTPUT_DIR / "manifest.jsonl"
SCENES_PATH   = OUTPUT_DIR / "scenes.jsonl"
METRICS_PATH  = OUTPUT_DIR / "metrics.json"
REPORT_PATH   = OUTPUT_DIR / "REPORT.md"
TEMPLATE_PATH = COURSE_ROOT / "assets/reference/CAPSTONE_REPORT_TEMPLATE.md"
RUBRIC_PATH   = COURSE_ROOT / "assets/reference/CAPSTONE_RUBRIC.md"

print(f"mode        : {MODE}")
print(f"model       : {MODEL}")
print(f"geometry    : {RES}p tier, {N_FRAMES} frames, {N_STEPS} steps, {ASPECT}")
print(f"scope       : {N_SOURCES} source clips x {PER_SOURCE} variants "
      f"= {N_PLANNED} attempted")
print(f"batching    : {GEN_BATCH_SIZE} spec(s) per Generator.run")
print(f"budget      : {BUDGET_MIN} min" if BUDGET_MIN else "budget      : none (full mode)")
print(f"deliverables: {OUTPUT_DIR}")
''')

# =====================================================================
# 3. THE BRIEF
# =====================================================================
nb.md("""
## The brief

### The problem

A robotics team has a handful of real recordings — call it a dozen clips of a
manipulator doing one task in one kitchen. They want to train on ten times that,
across more lighting conditions, more camera placements and more object
arrangements than they can physically stage. Collecting the extra footage means
weeks of robot time. They would like a model to do it instead.

That is a reasonable thing to want and an easy thing to do badly. The failure
mode is not "the videos look wrong". The failure mode is **a training set full of
physically impossible clips that nobody looked at**, because a generation script
exited zero four hundred times and everybody assumed.

Cosmos 3 can close the loop, because one checkpoint holds both a reasoner that
can describe and judge a clip and a generator that can produce one:

```
   real clip ──► REASON  ──► structured caption + plausibility baseline
                    │              (Lesson 03, Lesson 04)
                    ▼
                 VARY  ──► the variants you decide are worth making
                    │              (your design decisions)
                    ▼
                 GENERATE ──► new clips: image2video, and/or video2video
                    │          plus a control hint (Lessons 07, 08)
                    ▼
                 VALIDATE ──► check_video for aliveness, then the reasoner
                    │          for plausibility (Lessons 04, 09, 18)
                    ▼
                 MEASURE  ──► throughput, peak VRAM, wall clock per stage,
                    │          switching overhead, cost per accepted clip
                    ▼          (Lessons 06, 14, 15)
                 REPORT   ──► manifest + metrics + an evidence-backed write-up
```

Every arrow is something you have already done once. The capstone is the arrows
holding while you are not watching.

### What you deliver

| Artefact | Path | What makes it acceptable |
|---|---|---|
| Manifest | `outputs/capstone/manifest.jsonl` | one record per **attempted** variant, with provenance, the exact prompt, accept/reject and a reason |
| Metrics | `outputs/capstone/metrics.json` | every key in `METRIC_KEYS`, all measured on your machine |
| Report | `outputs/capstone/REPORT.md` | all eight sections (`## 0.` – `## 7.`) of `assets/reference/CAPSTONE_REPORT_TEMPLATE.md`, no placeholders left |
| Measurement log | `outputs/capstone/measurements.jsonl` | `cc.MeasurementLog`, one row per timed operation |
| Clips | `outputs/capstone/generated/` | the videos themselves, named by `variant_id` |

The paths in that table are not decoration. They come from the configuration
cell above, and the next cell reports which of them exist on your disk right
now.
""")

nb.code('''
# The five deliverables as paths, checked against the disk. On a fresh start
# every one of them is missing; nothing in this notebook writes them for you.
# Run this cell again at the end -- it is the first half of your completion test.
DELIVERABLES = {
    "manifest":     MANIFEST_PATH,
    "metrics":      METRICS_PATH,
    "report":       REPORT_PATH,
    "measurements": OUTPUT_DIR / "measurements.jsonl",
    "clips":        GENERATED_DIR,
}

for name, path in DELIVERABLES.items():
    if path.is_dir():
        state = f"directory, {len(list(path.glob('*')))} file(s)"
    elif path.exists():
        state = f"{path.stat().st_size:,} bytes"
    else:
        state = "not written yet"
    print(f"  {name:<13} {state:<24} {path}")

written = sum(1 for p in DELIVERABLES.values() if p.exists() and not p.is_dir())
print()
print(f"{written} of {len(DELIVERABLES)} deliverables exist. That number is what "
      f"the capstone")
print("is asking you to change.")
''')

nb.md("""
### Success criteria

**Running it successfully is not enough to pass.** Profiling, evaluation and
interpretation are required. A pipeline that produced twenty clips with no
measurement scores below one that produced four with a measured cost, a defended
threshold and a limitations section that names something inconvenient.

So these are the criteria. They are deliberately numeric, because "produces good
variations" is not a criterion and cannot be checked by anybody, including you.

**Reduced mode — the pass bar:**

| # | Criterion | How it is checked |
|---|---|---|
| S1 | ≥ 3 source clips reasoned into valid scene records | `check_stage_1()` |
| S2 | ≥ 8 variants attempted, each with a unique `variant_id` | `check_stage_2()` |
| S3 | Every spec passes `cc.validate_spec(strict=True)` **before** any GPU time | `check_stage_3()` |
| S4 | ≥ 6 attempted variants produce a file that `cc.check_video` accepts, and ≥ 1 is accepted by the policy | `check_stage_6()` |
| S5 | Manifest has exactly one record per attempted variant, all fields populated | `check_stage_6()` |
| S6 | Peak device VRAM stays below **75 GB**, and the reasoner and generator are never resident together | `metrics["peak_vram_gb"]`, sampled device-wide |
| S7 | Whole run completes in **≤ 90 minutes** of wall clock | `metrics["wall_clock_seconds"]` |
| S8 | Cost per accepted clip is **predicted before the run** and **measured after**, and you have named the dominant term in the gap | `metrics["prediction_ratio"]` + report §3.2 |
| S9 | Killing the kernel mid-run and re-running loses **at most one** completed variant | the ledger, before and after |
| S10 | All four injected failures are survived and correctly classified | the debugging lab |

Two of those are decided by the profile you have already loaded rather than by
anything you are about to write. Check them now, while changing them is one edit.
""")

nb.code('''
# S1 and S2 are numeric and they are set by PROFILE, not by your implementation.
# A profile that cannot clear them will still run happily to the end and fail.
pass_bar = {
    "S1  source clips":       (N_SOURCES, 3),
    "S2  attempted variants": (N_PLANNED, 8),
}

for label, (configured, required) in pass_bar.items():
    verdict = "clears" if configured >= required else "TOO SMALL"
    print(f"  {label:<24} configured {configured:>3}   bar >= {required:<3} "
          f"{verdict}")

if BUDGET_MIN is None:
    print("  S7  wall-clock budget    none -- full mode has no time budget")
else:
    print(f"  S7  wall-clock budget    {BUDGET_MIN} minutes")

assert N_SOURCES >= 3 and N_PLANNED >= 8, (
    "this configuration cannot clear S1/S2 however well you implement it. "
    "Raise n_sources or variants_per_source in PROFILES and re-run.")
print()
print("The configuration can clear the numeric bar. Whether your implementation")
print("does is a different question, and the one the rest of the notebook is about.")
''')

nb.md("""
### Reading the pass bar

Two of these deserve a note.

**S6 is 75 GB, not 80.** You need headroom for the CUDA context, allocator
fragmentation and whatever else is on the card. A run that peaks at 79 GB has not
succeeded; it has not failed *yet*.

**S4 counts the generator, not your policy.** It is deliberately about how many
attempts produced a *live* file — one that decodes, holds together spatially and
moves — rather than how many the judge accepted. A strict threshold should cost
you acceptances, not a criterion; otherwise the bar would be quietly pressuring
you to loosen decision 3, which is the opposite of what the rubric wants. The
one acceptance S4 does require exists because without it there is no
cost-per-accepted-clip and half the report has no denominator.

**S7 is a budget, not a prediction.** This notebook will not tell you how long
anything takes on your machine — nothing in this course does. The reduced
configuration is *sized for* roughly 45–60 minutes; 90 is the point at which it
has stopped being reduced. If you blow through it, the configuration is too big
and the cost model below tells you which knob to turn.

**Full mode** raises S1 to 6 clips and S2 to 24 variants, moves to Cosmos3-Nano
at 480p, and drops S7 entirely. It takes hours. Do it after reduced mode works.

**Seven checks, six stages, five for Foundation.** Three counts that are easy to
run together, so here they are once. The pipeline has **six stages**. There are
**seven checks**, `check_stage_0()` through `check_stage_6()` — stage 0 is the
source material and the ledgers, which nobody implements and which is wrong more
often than any stage that does get implemented. The **Foundation** tier stops at
`check_stage_4()`, so **five** of the seven; **Applied** needs all seven green in
a fresh kernel, and that is the pass condition.
""")

nb.callout("warning", """
Read `assets/reference/CAPSTONE_RUBRIC.md` now, before you write any code. Three
of its six criteria — measurement rigour, failure handling and honesty of the
evaluation — cannot be retrofitted after the run. In particular, criterion 3
requires your cost prediction to be **committed to the ledger before you run**,
and there is no way to do that afterwards that anybody should believe.
""")

nb.code(
    "# The counts from the paragraph above, printed from the same list the\n"
    "# checks themselves are built from, so the two cannot drift apart. Re-run\n"
    "# this cell whenever you want to know how much of the pipeline is defined\n"
    "# in this kernel: on a first pass through the notebook, none of it is.\n"
    "STAGE_CHECKS = (\n"
    + "".join(f'    "{name}",\n' for name in STAGE_CHECK_NAMES)
    + ")\n"
    f"FOUNDATION_CHECKS = STAGE_CHECKS[:{N_FOUNDATION_CHECKS}]\n"
    f"N_PIPELINE_STAGES = {N_STAGES}\n"
    + '''
for name in STAGE_CHECKS:
    needed_by = "Foundation and Applied" if name in FOUNDATION_CHECKS else "Applied"
    print(f"  {name:<15} {needed_by:<24} "
          f"{'defined' if name in globals() else 'not defined yet'}")

print()
print(f"{len(STAGE_CHECKS)} checks over {N_PIPELINE_STAGES} stages, "
      f"{len(FOUNDATION_CHECKS)} of them needed for the Foundation tier.")
print("Every one of them arrives in the section for the stage it checks.")
''')

# =====================================================================
# 4. CONCEPTUAL FRAMING
# =====================================================================
nb.md("""
## Why this is hard on one GPU

Three constraints shape every decision below. None of them is about model
quality.

**1. The two models cannot both hold the card.** The Reasoner NIM pre-allocates
KV cache against whatever VRAM is free when it starts, which on an idle 80 GB
H100 is most of it. Cosmos3-Nano generation wants 32 GB (`COSMOS3_FACTS.md` §3)
and Edge wants roughly 12 GB (a working estimate you measured in Lesson 06). You
measured the NIM's resting footprint yourself in Lesson 02. Either you stop the
NIM before generating, or you cap it at startup and pay for the cap in KV cache.
Either way the pipeline has a **stage order** dictated by memory rather than by
logic, and the transitions cost real seconds that belong in your budget.

**2. Process startup is not free and does not scale with job size.** Every
`Generator.run` is a fresh subprocess that imports the framework and loads the
checkpoint. At full resolution that overhead is a rounding error next to the
sampling. At the reduced tier — 256p, 61 frames, 10 steps — the sampling is small
enough that the *load* is most of the cost. `Generator.run` accepts a **list** of
specs and runs them as one batch job, which is why batch size is a knob you have
to think about rather than a default you can accept.

**3. A screening stage that is more expensive than the thing it screens is a bad
screening stage.** Asking the reasoner about a clip costs a NIM restart plus
inference. Running `cc.check_video` on it costs a few frame decodes. Order them
accordingly, and know what each one can and cannot see.
""")

nb.callout("vram", """
The stage order in this capstone — reason everything, then generate everything,
then validate everything — is not the order the data flows suggests. Clip-by-clip
would be more natural and would let you abandon a bad clip early. It is rejected
because it would mean starting and stopping the NIM once per clip, and on one
GPU that is the single most expensive thing you can do. You are trading a natural
control flow for a memory schedule. Say so in your report; it is one of the four
budget decisions.
""")

nb.code('''
# The two claims above, as arithmetic on this machine and this checkpoint.
# Nothing here is a timing; it is a memory budget and a count of model loads.
VRAM_CEILING_GB = 75          # criterion S6, on an 80 GB card
gen_vram_gb = cc.MODEL_TIERS[MODEL]["inference_vram_gb"]

print(f"{MODEL} inference wants about {gen_vram_gb} GB "
      f"(cosmos_course.MODEL_TIERS)")
print(f"S6 ceiling is {VRAM_CEILING_GB} GB, so {VRAM_CEILING_GB - gen_vram_gb} GB "
      f"is left for everything else")
print("while generation is resident -- and the Reasoner NIM's KV cache alone will")
print("take more than that unless you cap it or stop it. That is the constraint.")
print()

# Which model has to be resident, stage by stage, in the order this capstone
# uses. "none" means neither: planning and reporting need no GPU at all.
RESIDENT = ["reasoner", "none", "generator", "reasoner", "none", "none"]
previous = ["none"] + RESIDENT[:-1]
model_loads = sum(1 for was, now in zip(previous, RESIDENT) if now != was and now != "none")

print("stage order  : " + " -> ".join(RESIDENT))
print(f"model loads  : {model_loads} per pass over the whole batch")
print(f"clip by clip : the same schedule once per clip, so "
      f"{model_loads * N_SOURCES} loads for {N_SOURCES} clips")
print()
print("That ratio is the entire argument for reasoning every clip before")
print("generating any of them. Stage 5 makes you measure what a load actually")
print("costs on your machine, and the answer belongs in your report.")
''')

nb.md("""
## What makes a variation *useful*

This is the part with no right answer, and it is the part the rubric weights
most heavily after measurement.

Generating something *different* is trivial. Change the seed and you get a
different clip. Change the prompt to "a spaceship" and you get something very
different indeed. Neither helps a robotics team, for two different reasons: the
first varies nothing the model will be asked to generalise over, and the second
varies so much that the clip is no longer about their task.

A useful variation is one that:

- **moves along an axis the deployed system will actually encounter** — lighting
  at 6 a.m. versus noon, a cluttered bench versus a clear one, a different camera
  height. Not "a spaceship".
- **holds the task fixed** — the manipulator is still doing the thing. If the
  variation changes what is happening, it is a different dataset, not an
  augmentation of this one.
- **is physically possible** — which is what the screening stage is for.
- **is not a near-duplicate of a variation you already have.** Ten clips at
  "slightly warmer light" are one clip with nine copies, and they will make your
  yield numbers look good while teaching a model nothing.

Your job is to turn that paragraph into something a machine can compute, defend
the choice, and say how a lazy generator could satisfy your criterion without
doing anything useful. That last part is the difference between "good" and
"excellent" on the rubric.
""")

nb.callout("deeper", """
There is a real literature on this under names like *diversity–fidelity
tradeoff*, *coverage* and *mode collapse*. You do not need it here, and reaching
for a published metric before you have written down what you want in plain
language is usually a mistake. Define the property you care about first, then go
looking for whether somebody has already formalised it. If you do reach for one,
say in the report what it assumes — most coverage metrics assume an embedding
space in which distance means something, and for physical plausibility that is a
large assumption.
""")

nb.code('''
# The cheapest possible version of a diversity criterion: how much of the
# wording actually changed? Four candidate variations of one scene, three of
# which are the same clip described three times.
CANDIDATE_VARIATIONS = [
    "robot arm places the red mug on the wooden bench, warm afternoon light",
    "robot arm places the red mug on the wooden bench, slightly warmer light",
    "robot arm places the red mug on the wooden bench, warm light again",
    "robot arm places the red mug on a cluttered bench, hard overhead light",
]


def wording_overlap(a, b):
    """Fraction of the distinct words the two descriptions share."""
    words_a, words_b = set(a.lower().split()), set(b.lower().split())
    return len(words_a & words_b) / len(words_a | words_b)


for i, first in enumerate(CANDIDATE_VARIATIONS):
    for j, second in enumerate(CANDIDATE_VARIATIONS[i + 1:], start=i + 1):
        print(f"  variation {i} vs {j}:  {wording_overlap(first, second):.2f} "
              f"of the wording is shared")

print()
print("Variations 0, 1 and 2 are one clip described three times; 3 moves along an")
print("axis a deployed robot would actually meet. The numbers do separate them,")
print("though not by much, and this particular number is trivially gamed by")
print("padding a prompt with rare words -- which is exactly the kind of admission")
print("the rubric is asking you to make about whatever criterion you design.")
''')

nb.md("""
## The six stages and their contracts

This is not a walkthrough. Every stage below gives you an interface, a skeleton
and an automated check. None of them gives you the implementation. Four of the
decisions have no correct answer and you have to defend the one you make.

Each stage is one function with a documented signature. The contract is the
interface, not the implementation — you can do whatever you like inside as long
as the outside behaves as described and `check_stage_N()` passes.

| Stage | Function | In | Out | Runs while |
|---|---|---|---|---|
| 1 Reason | `reason_stage(clip_id, path)` | one real clip | scene record + plausibility baseline | NIM up |
| 2 Vary | `plan_variants(scene, n)` | one scene record | n variant plans | no model resident |
| 3 Generate | `build_spec(v, scene)` → `generate_batch(...)` | variant plans | files on disk | generator up |
| 4 Validate | `screen(variant, path)` | one generated file | accept/reject + reason | NIM up |
| 5 Measure | `collect_metrics(...)` | ledger + clock + samples | `metrics.json` | nothing resident |
| 6 Report | `write_report(...)` | metrics + decisions | `REPORT.md` | nothing resident |

Two rules that apply to all six:

**A stage function must not catch its own exceptions.** `cc.run_stage` catches,
times, classifies and records them. A stage that swallows its own errors makes
the failure classification useless, and the failure classification is graded.

**A stage function must be deterministic given its inputs and the configured
seeds.** Two runs with the same inputs produce the same `variant_id`s. Without
that, resume cannot work, because the ledger keys would not match.
""")

nb.md("""
## Is this configuration actually small enough?

Do not take the word "reduced" on trust. `cc.estimate_generation_cost` returns a
**unit count**, not a time: latent tokens times denoising steps. The absolute
number means nothing, but the ratio against a configuration you have already
timed means everything, and you timed several in Lesson 06.

The cell below prints the whole reduced run as a multiple of one reference
generation. If that multiple is larger than you can afford, the fix is in this
cell's inputs, not in hoping.
""")

nb.code('''
per_variant = cc.estimate_generation_cost(
    resolution=RES, aspect_ratio=ASPECT,
    num_frames=N_FRAMES, num_steps=N_STEPS, model=MODEL)

reference = cc.estimate_generation_cost(
    resolution="480", aspect_ratio="16,9", num_frames=121, num_steps=35,
    model=MODEL)

print(f"one variant : {per_variant['width']}x{per_variant['height']}, "
      f"{per_variant['latent_tokens']:,} latent tokens, "
      f"{per_variant['cost_units']:,} units")
print(f"              = {per_variant['relative_to_480p_121f_35s']:.3f} x the "
      f"480p/121f/35-step reference")
print(f"whole run   : {per_variant['cost_units'] * N_PLANNED:,} units "
      f"= {per_variant['relative_to_480p_121f_35s'] * N_PLANNED:.2f} x that "
      f"reference")
for warning in per_variant["warnings"]:
    print(f"  WARNING: {warning}")

print()
print("Read that last line as: 'the sampling in this entire run costs about as")
print("much as N of the generations I timed in Lesson 06.' If N is large, this")
print("configuration is not reduced and you should say so now rather than in")
print("ninety minutes.")
print()
print(f"reference config for comparison: {reference['cost_units']:,} units")
''')

nb.callout("gotcha", """
The unit model says nothing about process startup, and at this tier startup is
probably the larger term. A run of nine variants at 0.01x the reference is not
1/100th of a Lesson 06 run — it is nine subprocess launches, or three if you
batch, plus a bit of sampling. That is precisely why `GEN_BATCH_SIZE` is one of
the four decisions, and why your prediction below has to have a fixed-overhead
term in it.
""")

nb.md("""
## Verification

This fails now, loudly, on anything that would fail in forty minutes' time
quietly. Two categories: things that stop the pipeline (`cc.require`) and things
that only degrade it (printed warnings).
""")

nb.code('''
blocking = []
degraded = []

if not DEVICE.startswith("cuda"):
    blocking.append("No CUDA device is visible. Check `nvidia-smi` and "
                    "`torch.cuda.is_available()`.")

generator = Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=False)
if framework_problems:
    blocking.extend(framework_problems)

if shutil.which("docker") is None:
    blocking.append("docker is not on PATH, so the Reasoner NIM cannot be "
                    "started. Stages 1 and 4 both need it.")

if shutil.which("ffmpeg") is None:
    degraded.append("ffmpeg is missing. Video previews and any control-video "
                    "trimming will be skipped; `Reasoner.ensure_h264` will pass "
                    "files through unchanged and a non-H.264 clip will come back "
                    "as HTTP 422.")

if not TEMPLATE_PATH.exists():
    blocking.append(f"the report template is missing: {TEMPLATE_PATH}")
if not RUBRIC_PATH.exists():
    degraded.append(f"the rubric is missing: {RUBRIC_PATH}")

# Lesson 06's calibration turns the unit count into a time prediction for THIS
# machine. Without it you can still run, but your cost prediction has no basis
# and criterion S8 cannot be satisfied.
CALIB_PATH = cc.OUTPUT_ROOT / "06" / "calibration.json"
CALIBRATION = json.loads(CALIB_PATH.read_text()) if CALIB_PATH.exists() else {}
if not CALIBRATION.get("units_per_second"):
    degraded.append(f"no calibration at {CALIB_PATH}. Re-run Lesson 06's "
                    f"calibration cell, or your prediction in the next section "
                    f"is a guess and you must label it one.")

for item in degraded:
    print(f"  degraded: {item}")
print()
cc.require(not blocking,
           "The capstone cannot start:\\n  - " + "\\n  - ".join(blocking)
           if blocking else "ok",
           fix="Fix each item above. `python3 scripts/smoke_test.py` walks the "
               "same ground with more detail.")
print("environment ok")
''')

nb.callout("warning", """
**Full mode downloads.** `MODE="full"` uses Cosmos3-Nano: **34.9 GB** of
checkpoint, on top of whatever is already in your Hugging Face cache, and a run
measured in hours rather than minutes. Nothing here pulls it silently — the cell
below refuses to proceed in full mode unless you set
`COSMOS_CAPSTONE_ALLOW_DOWNLOAD=1` in your shell, so that the decision to spend
35 GB of disk is one you made on purpose.
""")

nb.code('''
tier = cc.MODEL_TIERS[MODEL]
allow_download = os.environ.get("COSMOS_CAPSTONE_ALLOW_DOWNLOAD") == "1"

print(f"{MODEL}: {tier['params_total_b']}B total / {tier['params_active_b']}B "
      f"active, {tier['download_gb']} GB download, "
      f"~{tier['inference_vram_gb']} GB inference VRAM")
print(f"  transfer (video2video + control hint): "
      f"{'supported' if tier['supports_transfer'] else 'NOT supported'}")
print(f"  audio:    {'supported' if tier['supports_audio'] else 'NOT supported'}")
print(f"  max tier: {tier['max_resolution_tier']}p")
print()

if MODE == "full" and not allow_download:
    print("MODE='full' selected. This wants Cosmos3-Nano "
          f"({cc.MODEL_TIERS['Cosmos3-Nano']['download_gb']} GB) and takes "
          "hours.")
    print("Set COSMOS_CAPSTONE_ALLOW_DOWNLOAD=1 and restart the kernel to "
          "proceed, or")
    print("switch back to MODE='reduced' and get the pipeline working first.")
else:
    print("proceeding")
''')

# =====================================================================
# 6. THE BUDGET (predict before you run) -- PRE #1
# =====================================================================
nb.md("""
## The budget: predict, then measure

Criterion **S8** says you predict the cost per accepted clip before the run and
reconcile it afterwards. This is not bookkeeping. A prediction you committed to
is the only way to find out that your mental model of where the time goes is
wrong, and on a single-GPU pipeline it is usually wrong in the same place: the
fixed costs nobody puts in the model.

Your prediction needs three terms, and you have measured two of them:

```
                     fixed_overhead_s              (Lesson 06 calibration)
  seconds/variant  = ─────────────────  +  ──────────────────────────────────
                       batch_size            units_per_variant / units_per_s
                                                  (Lesson 06 calibration)

  seconds/accepted = (seconds/variant + judge_seconds) / acceptance_rate
                                                          (you have to guess)
```

The acceptance rate is the interesting one, because you cannot measure it before
you run and it is in the denominator. Guess it, write the guess down, and find
out how wrong you were. Being wrong here is the single most informative thing
that will happen to you today.
""")

nb.predict_run_explain(
    predict=(
        "Write down three numbers before you run the next cell: (a) the seconds "
        "per variant your calibration implies, (b) the fraction of variants you "
        "expect the screening stage to accept, and (c) the resulting GPU-seconds "
        "per accepted clip. Also predict which single stage will dominate the "
        "wall clock — reason, generate, validate, or switching the NIM up and "
        "down."
    ),
    change=(
        "Set `ACCEPTANCE_GUESS` in the cell below to your (b). Leave everything "
        "else alone. The cell writes your prediction to the ledger with a "
        "timestamp, which is what makes it a prediction rather than a "
        "recollection."
    ),
    explain=(
        "After the pipeline has run, come back to this number. If your predicted "
        "seconds-per-variant is close and your cost-per-accepted-clip is far out, "
        "the acceptance rate was your error. If both are far out, look at the "
        "fixed overhead — the unit model does not include process startup, NIM "
        "restarts, or the judge. Name the dominant term in your report; 'it was "
        "3x off' is not a reconciliation."
    ),
    hint=(
        "Most people over-predict the acceptance rate on their first run, and "
        "most people forget that the NIM has to come up twice. If your predicted "
        "switching time is zero, that is the thing to reconsider first."
    ),
)

nb.code('''
# ---------------------------------------------------------------------------
# TODO: your honest guess at the fraction of attempted variants that will pass
# BOTH the automatic checks and the plausibility judge. Anything in (0, 1].
# ---------------------------------------------------------------------------
ACCEPTANCE_GUESS = 0.60          # <- change this to YOUR number

# Judge cost: one reasoner call per surviving clip. If you have Lesson 03's
# measured latency to hand, use it; otherwise this is a placeholder you must
# label as such in the report.
JUDGE_SECONDS_GUESS = 25.0       # <- and this one

UNITS_PER_SECOND = CALIBRATION.get("units_per_second")
FIXED_OVERHEAD_S = CALIBRATION.get("fixed_overhead_s") or 0.0

units_per_variant = per_variant["cost_units"]

if UNITS_PER_SECOND:
    compute_s = units_per_variant / UNITS_PER_SECOND
    launch_s = FIXED_OVERHEAD_S / max(1, GEN_BATCH_SIZE)
    predicted_variant_s = launch_s + compute_s
    predicted_accepted_s = (predicted_variant_s + JUDGE_SECONDS_GUESS) / ACCEPTANCE_GUESS
    basis = "Lesson 06 calibration"
else:
    compute_s = launch_s = predicted_variant_s = predicted_accepted_s = None
    basis = "NONE -- no calibration on this machine"

PREDICTION = {
    "key": "prediction",
    "made_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "basis": basis,
    "mode": MODE, "model": MODEL,
    "units_per_variant": units_per_variant,
    "units_per_second": UNITS_PER_SECOND,
    "fixed_overhead_s": FIXED_OVERHEAD_S,
    "gen_batch_size": GEN_BATCH_SIZE,
    "acceptance_guess": ACCEPTANCE_GUESS,
    "judge_seconds_guess": JUDGE_SECONDS_GUESS,
    "predicted_seconds_per_variant": predicted_variant_s,
    "predicted_seconds_per_accepted": predicted_accepted_s,
    "predicted_dominant_stage": "TODO: reason | generate | validate | switch",
}

for name, value in PREDICTION.items():
    print(f"  {name:<32} {value}")
''')

nb.callout("note", """
`predicted_dominant_stage` is a string with `TODO` in it on purpose.
`check_stage_5()` refuses to pass while it is still there. A prediction you did
not write down is not a prediction, and this is the cheapest possible enforcement
of that.
""")

# =====================================================================
# 7. LEDGER AND RESUME
# =====================================================================
nb.md("""
## The ledger: how the run survives being interrupted

Criterion **S9** says an interruption costs you at most the item in flight.
That property has to be designed in; there is no way to add it afterwards.

`cc.Ledger` is an append-only JSONL keyed by a field you choose. Each append is
flushed and `fsync`ed before the call returns, so a `kill -9` cannot lose a
completed item. Resume is then trivial and needs no special code path: the
pipeline loops over the work it *wants*, asks the ledger what it already has, and
does the difference.

Two ledgers, because the two stages have different keys and different lifetimes:

- `scenes` — keyed by `clip_id`. One record per source clip. Small, cheap to
  rebuild, but rebuilding it costs a NIM restart.
- `manifest` — keyed by `variant_id`. **This is a deliverable.** One record per
  attempted variant, with everything needed to explain where the clip came from
  and why it was kept or dropped.

A record is written to the manifest the moment a variant's fate is known —
including when its fate is "the generator OOMed". A manifest that only records
successes cannot tell you your yield.
""")

nb.code('''
scenes = Ledger(SCENES_PATH, key_field="clip_id")
manifest = Ledger(MANIFEST_PATH, key_field="variant_id")
prediction_log = Ledger(OUTPUT_DIR / "predictions.jsonl", key_field="key")
measurements = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
clock = StageClock()

# The prediction is committed here, once, before anything runs. record_once
# means re-running this cell does not overwrite what you predicted the first
# time -- which is the whole point of committing it.
if prediction_log.record_once(PREDICTION):
    print("prediction committed to the ledger")
else:
    print("a prediction is already on record; keeping the original")
    print(f"  {prediction_log.get('prediction')['made_at']}")

print()
print(scenes.summary("clip_id"))
print(manifest.summary("status"))
print()
if len(manifest):
    print(f"Resuming: {len(manifest)} variant(s) already have a verdict. "
          f"They will be skipped.")
    print("Delete outputs/capstone/manifest.jsonl to start over.")
''')

nb.md("""
### The manifest record

One record per attempted variant. These fields are the contract; `check_stage_6`
enforces them and the rubric's traceability criterion is exactly the claim that
you can navigate this record in both directions.
""")

nb.code(MANIFEST_CONTRACT + '''
for name, meaning in MANIFEST_FIELDS.items():
    print(f"  {name:<14} {meaning}")
''')

nb.callout("gotcha", """
Merging `rejected` and `failed` into one bucket is the single most common way
people lose marks on this capstone. "Nine of twenty didn't work" is unactionable:
it could mean your threshold is strict (good, intentional) or your generator is
crashing (bad, urgent). They are different numbers and they go in different rows
of the report.
""")

# =====================================================================
# 8. SOURCE CLIPS
# =====================================================================
nb.md("""
## Stage 0 — the source material

Point this at your own footage if you have it. If you do not, it falls back to
cookbook clips, and you should read the warning below and put it in your report.
""")

nb.code('''
# Set COSMOS_CAPSTONE_SOURCES=/path/to/your/clips to use your own footage.
# Anything ffmpeg can read; H.264 avoids a transcode.
SOURCE_DIR = os.environ.get("COSMOS_CAPSTONE_SOURCES")

FALLBACK_CLIPS = [
    "robotics_next_action",     # robot mid-task
    "video_caption",            # general clip
    "situation_understanding",  # scene requiring inference
    "physical_plausibility",    # the model judging what is possible
    "common_sense",
    "assisted_task",
]


def resolve_sources(limit):
    """Return [(clip_id, Path)] -- your clips if configured, cookbook otherwise."""
    if SOURCE_DIR:
        root = Path(SOURCE_DIR).expanduser()
        found = sorted(p for p in root.glob("*")
                       if p.suffix.lower() in {".mp4", ".mov", ".mkv", ".webm"})
        if not found:
            raise FileNotFoundError(
                f"COSMOS_CAPSTONE_SOURCES={root} contains no video files.")
        return [(p.stem, p) for p in found[:limit]]

    pairs = []
    for name in FALLBACK_CLIPS:
        path = cc.asset_or_none(name)
        if path is not None:
            pairs.append((name, path))
        if len(pairs) >= limit:
            break
    if len(pairs) < limit:
        raise FileNotFoundError(
            f"only {len(pairs)} of {limit} fallback clips are on disk. Run "
            f"`python scripts/fetch_assets.py`, or set "
            f"COSMOS_CAPSTONE_SOURCES to a directory of your own clips.")
    return pairs


SOURCES = resolve_sources(N_SOURCES)
for clip_id, path in SOURCES:
    print(f"  {clip_id:<26} {path}")
print()
print("own footage" if SOURCE_DIR else "cookbook fallback -- see the warning below")
''')

nb.callout("warning", """
If you are using the cookbook fallback, these clips may well be inside the
distribution Cosmos 3 was trained on. Variants of them will be easier to produce
and easier to accept than variants of footage the model has never seen, so your
acceptance rate is **optimistic** and your cost per accepted clip is
**flattering**. That is a threat to validity, it belongs in report §4, and it is
the first thing a reviewer will ask about.
""")

nb.checkpoint(
    "Stage 0 is done when every source clip resolves to a file that exists and "
    "the ledgers are open. This is the cheapest check in the notebook and it "
    "catches a surprising fraction of wasted afternoons.",
    CHECK_STAGE_0 + "\n\ncheck_stage_0()",
)

# =====================================================================
# 9. THE FOUR DECISIONS
# =====================================================================
nb.md("""
## The four decisions

These are the intellectual content of the capstone. None has a correct answer.
All four are graded on the *reasoning*, and specifically on whether you named the
alternative you rejected and what would change your mind.

Fill the dict below in as you go — you will not be able to answer decision 3
sensibly until you have seen a few outputs — but fill it in **in the notebook**,
not only in the report. `check_decisions()` refuses placeholder text and short
answers, and it runs before the report is written.

1. **Conditioning modality.** Which of `image2video`, `video2video` + control
   hint, and `text2video` for which kind of variation? What does each preserve?
   `edge` keeps shape and layout, `blur` keeps colour and lighting, `depth` keeps
   3D structure, `seg` keeps object identity (`COSMOS3_FACTS.md` §2).
   `image2video` keeps only the first frame and invents the rest.
2. **Diversity criterion.** What makes a variation *useful* rather than merely
   different? It must be computable — your code has to produce a number — and you
   must say how a lazy generator could satisfy it without helping anyone.
3. **Accept/reject policy.** What do you ask the reasoner, and what threshold do
   you set? This is a precision/recall tradeoff and you own it: a loose
   threshold puts impossible clips into a training set, a tight one throws away
   usable clips and raises your cost per accepted clip.
4. **Budget.** Where does the VRAM go, and where does the wall clock go? Which
   stage do you deliberately let dominate, and what did you give up?
""")

nb.callout("h100", """
Decision 1 has a hard constraint in reduced mode. **Cosmos3-Edge does not support
transfer at all** (`COSMOS3_FACTS.md` §1) — no `video2video` with a control hint,
no audio. So in reduced mode you can *design* and *validate* a transfer spec but
you cannot run it, and `check_stage_3()` will tell you so rather than letting you
discover it after a model load. That is not a gap in the exercise: writing a spec
you cannot execute, and having the validator confirm it is well-formed, is
exactly the discipline Lesson 08 was building. Running it needs Nano — set
`COSMOS_COURSE_MODEL=Cosmos3-Nano`, or do it in the Challenge tier.
""")

nb.code('''
DECISIONS = {
    "modality": {
        "choice": "TODO",
        "why": "TODO: argue from what each mode preserves.",
        "rejected": "TODO: which alternative, and the specific reason.",
        "would_change_my_mind": "TODO: an observation, not a feeling.",
    },
    "diversity": {
        "choice": "TODO: your criterion, in one sentence.",
        "why": "TODO: what it rewards, and why that is the right thing to reward.",
        "rejected": "TODO",
        "would_change_my_mind": "TODO",
        "how_it_could_be_gamed": "TODO: how a degenerate generator scores well.",
    },
    "accept_reject": {
        "choice": "TODO: what you ask, and the threshold.",
        "why": "TODO: which error you chose to make, and why that one.",
        "rejected": "TODO",
        "would_change_my_mind": "TODO",
    },
    "budget": {
        "choice": "TODO: where the VRAM goes and which stage dominates.",
        "why": "TODO",
        "rejected": "TODO",
        "would_change_my_mind": "TODO",
    },
}

''' + DECISION_CONTRACT + '''

''' + CHECK_DECISIONS + '''

check_decisions()
''')

# =====================================================================
# 10. STAGE 1 — REASON
# =====================================================================
nb.md("""
## Stage 1 — Reason

Turn each real clip into two things: a structured scene record (the five axes
Module 2 knows how to condition on, from Lesson 03) and a **plausibility
baseline** — the judge's verdict on the *real* footage.

The baseline is the part that is new, and it matters more than it looks. Your
screening stage in Stage 4 will ask the reasoner whether a generated clip is
physically plausible. If that same question, asked about genuine footage of a
real robot, comes back "no", then your threshold is wrong and every number
downstream is measuring your prompt rather than your generator. Calibrating a
judge against known-good input before trusting it on unknown input is the same
argument Lesson 18 made about evaluators, applied to a screen.

**Runs while the NIM is up.** Nothing else may hold the card.
""")

nb.code('''
# Lesson 03's schema. Five fields because they are the five axes the generator
# can be conditioned on -- subjects, setting, actions, lighting, camera.
CAPTION_SCHEMA = {
    "subjects": ["list of strings: the main entities, most salient first"],
    "setting": "string: where this is, one sentence",
    "actions": ["list of strings: what happens, in temporal order"],
    "lighting": "string: quality, direction and colour of the light",
    "camera": "string: viewpoint, framing and any camera motion",
}

# The shape your plausibility judgement must have, in stage 1 and again in
# stage 4. The SHAPE is fixed so the pipeline can rely on it; the QUESTION you
# ask to get it is decision 3 and is yours.
BASELINE_KEYS = ("plausible", "confidence", "why")

NIM = NimConfig()
reasoner = Reasoner(base_url=NIM.base_url)


def nim_up():
    """Start the Reasoner NIM if it is not already answering. Timed as `switch`."""
    with clock.stage("switch"):
        return start_nim(NIM, wait=True, timeout=2400)


def nim_down():
    """Stop the NIM and get the VRAM back. Timed as `switch`."""
    with clock.stage("switch"):
        return stop_nim(NIM)


print("NIM endpoint:", NIM.base_url)
print("status      :", "ready" if nim_status(NIM)["ready"] else "not running")
''')

nb.md("""
### The contract

```python
reason_stage(clip_id: str, clip_path: Path) -> dict
```

Returns a dict with **exactly** these five keys:

| Key | Type | Meaning |
|---|---|---|
| `clip_id` | `str` | as passed in |
| `source_path` | `str` | absolute path to the real file |
| `record` | `dict` | the five `CAPTION_SCHEMA` keys, correct types |
| `baseline` | `dict` | `BASELINE_KEYS`: `plausible` bool, `confidence` float in [0,1], `why` str |
| `provenance` | `dict` | `model`, `fps`, `seed`, `prompt_tokens`, `completion_tokens`, `latency_s` |

Raises `ValueError` if the model's reply cannot be parsed into that shape.
**Does not catch its own exceptions** — `cc.run_stage` does that, and it needs
the exception to classify it.
""")

nb.code('''
def reason_stage(clip_id, clip_path):
    """Turn one real clip into a scene record plus a plausibility baseline.

    Contract
    --------
    Returns {"clip_id", "source_path", "record", "baseline", "provenance"} as
    described above. Raises ValueError on unparseable output. Deterministic at
    temperature=0 with a fixed seed. Must not catch its own exceptions.

    Reuse, do not rewrite
    ---------------------
    cc.Reasoner.ask(prompt, videos=..., fps=..., temperature=0.0, seed=...)
    cc.Reasoner.parse_json(text)          handles fences, prose and <think>
    cc.Reasoner.ensure_h264(path)         a non-H.264 clip returns HTTP 422
    reasoner.last_usage                   {"prompt_tokens", "completion_tokens"}
    cc.check_text(blob)                   degenerate-output detection
    """
    # TODO 1. Transcode defensively. The NIM decodes with OpenCV and a clip it
    #         cannot read comes back as HTTP 422 with zero frames, which is not
    #         an obvious error message. Lesson 02 and Lesson 03 both hit this.
    #
    # TODO 2. Ask for the structured record. Lesson 03 established what makes
    #         this parse first time: "reply with JSON only", an example object
    #         pinning key names AND types, and an instruction to write the
    #         string "unknown" rather than dropping a key it cannot fill.
    #         Use temperature=0.0 and a fixed seed, or nothing downstream is
    #         reproducible and resume will produce different variant_ids.
    #
    # TODO 3. Validate the parsed record against CAPTION_SCHEMA -- keys present,
    #         lists where the schema says list. Raise ValueError if not.
    #         Do NOT silently repair it; a repaired record hides a prompt bug.
    #
    # TODO 4. Ask the plausibility question on the SAME clip and parse it into
    #         BASELINE_KEYS. What you ask is decision 3. Whatever you ask, ask
    #         the identical question in stage 4 -- a baseline taken with a
    #         different question calibrates nothing.
    #
    # TODO 5. Assemble and return. Provenance is not bureaucracy: in stage 4
    #         you will want to know which caption, at which fps, produced a
    #         clip you are looking at.
    raise NotImplementedError("stage 1: implement reason_stage")
''')

nb.md("""
### The check

Run this on one clip before you run it on all of them. It costs one NIM call and
it will save you from discovering a schema bug on clip six.
""")

nb.code(CHECK_STAGE_1 + '''

# check_stage_1()   # <- uncomment once reason_stage is implemented
print("check_stage_1 is defined. Implement reason_stage, then call it.")
''')

# =====================================================================
# 11. STAGE 2 — VARY
# =====================================================================
nb.md("""
## Stage 2 — Vary

The design stage. No GPU, no model, no excuse: this is where you decide what the
dataset is *for*, and everything downstream is bookkeeping on that decision.

Two functions. `plan_variants` turns one scene record into N variant plans;
`diversity_score` puts a number on how much variation a set of plans actually
contains. The second exists because "I varied three things" is a claim, and the
capstone does not accept claims.

**`diversity_score` must be computable from the plans alone**, before any pixels
exist. A criterion you can only evaluate after generating is useless for
deciding what to generate.
""")

nb.code('''
# Which conditioning modes you are willing to plan. Constrained by the tier:
# Edge cannot do video2video transfer at all (COSMOS3_FACTS.md section 1).
MODALITIES = ("image2video", "video2video", "text2video")
CONTROL_HINTS = tuple(sorted(cc.TRANSFER_HINTS))   # edge, blur, depth, seg

# ---------------------------------------------------------------------------
# The axes you will vary along. ONE worked example is given, to fix the shape.
# The axes themselves are decision 2 and they are yours.
#
# An axis is useful when the deployed system will actually meet it, and when
# moving along it does not change what is happening in the clip. "Time of day"
# qualifies. "Species of animal present" does not, for a kitchen manipulator.
# ---------------------------------------------------------------------------
AXES = {
    "lighting": [
        "low warm evening light from a single window, long soft shadows",
        "flat overcast daylight, no directional shadows",
    ],
    # TODO: add at least two more axes, with at least two values each.
    #       check_stage_2 requires three axes and will say so.
}

print(f"{len(AXES)} axis/axes defined, "
      f"{sum(len(v) for v in AXES.values())} values total")
print(f"modalities available on {MODEL}: "
      f"{[m for m in MODALITIES if m != 'video2video' or cc.MODEL_TIERS[MODEL]['supports_transfer']]}")
''')

nb.md("""
### The contract

```python
plan_variants(scene: dict, n: int) -> list[dict]
diversity_score(variants: list[dict]) -> dict
```

`plan_variants` returns exactly `n` dicts, each with:

| Key | Type | Notes |
|---|---|---|
| `variant_id` | `str` | unique and **stable** — same scene and n produce the same ids |
| `clip_id` | `str` | from the scene |
| `axis` | `str` | a key of `AXES` |
| `axis_value` | `str` | one of that axis's values |
| `modality` | `str` | a member of `MODALITIES` |
| `control_hint` | `str` or `None` | a member of `cc.TRANSFER_HINTS`, only for `video2video` |
| `prompt` | `str` | derived from `scene["record"]`, with the axis value applied |
| `seed` | `int` | derived from `BASE_SEED` and the variant, not random |

`diversity_score` returns `{"criterion": str, "value": float, "detail": dict}`,
where higher means more diverse, and `criterion` names what you measured.
""")

nb.callout("gotcha", """
`variant_id` stability is what makes resume work. If you build it from
`uuid4()` or from `time.time()`, a resumed run generates a fresh set of ids, the
ledger matches nothing, and you redo everything you already paid for. Build it
from the inputs: clip id, axis, axis value, modality, seed. `check_stage_2` calls
`plan_variants` twice and compares.
""")

nb.code('''
def plan_variants(scene, n):
    """Turn one scene record into n variant plans. Deterministic.

    Contract
    --------
    Exactly n dicts with the keys in the table above. variant_id unique within
    the whole run and stable across calls. prompt derived from
    scene["record"] -- not typed by hand, and not identical between variants.

    Reuse, do not rewrite
    ---------------------
    scene["record"]              the five conditioning axes from stage 1
    cc.TRANSFER_HINTS            the four members of TransferHintKey
    cc.MODEL_TIERS[MODEL]        supports_transfer, max_resolution_tier
    """
    # TODO 1. Choose which axes to move along, and how to spread n variants
    #         across them. One axis x n values? n axes x one value? A mix?
    #         This is a real choice: spreading thin covers more of the space,
    #         spreading thick lets you see whether ONE axis actually works.
    #
    # TODO 2. Build the prompt. Start from scene["record"] so the variant is
    #         about the same task in the same place, then apply the axis value
    #         to exactly the field it belongs to -- an axis value about light
    #         should modify `lighting`, not be bolted onto the end of the
    #         sentence. Lesson 07 showed why structured prompts beat a single
    #         sentence for this: they let you change one attribute.
    #
    # TODO 3. Choose modality per variant. Decision 1. Remember that
    #         image2video needs a first frame and video2video needs a control
    #         video whose frame count you inherit (Lesson 08).
    #
    # TODO 4. Derive variant_id and seed from the inputs. Stable, unique.
    raise NotImplementedError("stage 2: implement plan_variants")


def diversity_score(variants):
    """Put a number on how much useful variation a set of plans contains.

    Contract
    --------
    Returns {"criterion": str, "value": float, "detail": dict}. Higher is more
    diverse. Computable from the plans alone -- no generated pixels.

    This is decision 2 made executable. Whatever you choose, you must be able to
    say in the report how a generator could score well on it while producing
    nothing anybody wants.
    """
    # TODO. Candidates, roughly in order of how much they are worth:
    #   - distinct (axis, axis_value) pairs, normalised by n. Cheap, honest,
    #     and blind to whether the prompt actually differs.
    #   - pairwise token-set distance between prompts. Catches "I varied the
    #     axis and the prompt came out identical anyway".
    #   - coverage of a grid you declared in advance: which cells of
    #     axes x values did you actually fill?
    #   - minimum pairwise distance rather than mean -- a mean is easy to raise
    #     with one far-out variant while the other nine are near-duplicates.
    # Pick one, or combine, but be able to defend it.
    raise NotImplementedError("stage 2: implement diversity_score")
''')

nb.code(CHECK_STAGE_2 + '''

print("check_stage_2 is defined. Implement plan_variants and diversity_score.")
''')

# =====================================================================
# 12. STAGE 3 — GENERATE
# =====================================================================
nb.md("""
## Stage 3 — Generate

Turn plans into specs, and specs into files. Two functions, and a design
constraint that is the whole reason the second one exists.

**`generate_batch` must run one `Generator.run` for the whole list**, not one per
variant. `Generator.run` accepts a list of `InferenceSpec` and writes them as a
JSONL batch job — one framework import, one checkpoint load, N samples. At the
reduced tier the sampling per variant is small enough that the load dominates,
so this is the single largest lever on wall clock you have.

It is also a genuine tradeoff, which is why `GEN_BATCH_SIZE` is a knob and part
of decision 4: **a crash loses the whole batch.** Batch of one is maximally
robust and maximally slow. Batch of nine is the reverse. Choose, and say why.

**Runs while the NIM is down.** Stop it first, and check that the VRAM came back.
""")

nb.code('''
def build_spec(variant, scene):
    """One variant plan -> one InferenceSpec that validate_spec accepts.

    Contract
    --------
    spec.name == variant["variant_id"]        (this is how outputs are matched)
    spec.model_mode == variant["modality"]
    resolution / num_frames / num_steps / aspect_ratio from the config cell
    spec.seed == variant["seed"]
    cc.validate_spec(spec, strict=True) raises nothing.

    Reuse, do not rewrite
    ---------------------
    cc.InferenceSpec(...)         every field, all optional except mode and name
    cc.validate_spec(spec)        catches a bad mode, a missing required field,
                                  frames over the tier limit, a control hint on
                                  the wrong mode, and "16:9" instead of "16,9"
    cc.asset_or_none("neg_prompt_i2v")     negative prompt for image2video
    cc.asset_or_none("control_edge")       a cookbook control video
    """
    # TODO 1. Mode-specific required fields (cosmos_course.specs.REQUIRED_FIELDS):
    #           image2video      prompt + vision_path   (a first FRAME)
    #           video2video      prompt + vision_path   (a control VIDEO)
    #                            plus a controls={hint: {...}} block
    #           text2video       prompt
    #
    # TODO 2. For image2video you need a first frame. You have a source video,
    #         not an image. Extract one with ffmpeg, or use a cookbook still --
    #         but if you use a cookbook still, the variant is no longer about
    #         your source clip and the manifest's provenance becomes a lie.
    #
    # TODO 3. Negative prompts exist per mode and text2image has none
    #         (Lesson 07). Decide whether to use one and say why.
    #
    # TODO 4. Validate before returning. A spec that fails validation here costs
    #         you nothing; one that fails after a checkpoint load costs minutes.
    raise NotImplementedError("stage 3: implement build_spec")


def generate_batch(variants, scenes_by_id):
    """Generate a batch of variants in ONE Generator.run. Returns paths.

    Contract
    --------
    Returns {variant_id: Path or None} with one entry per input variant.
    None means "this variant produced no file" -- not an exception. A single bad
    sample must not lose the rest of the batch.

    Reuse, do not rewrite
    ---------------------
    generator.run(specs, out_dir, seed=..., timeout=...)   list -> batch JSONL
    result.videos                  every video the run wrote, newest last
    result.diagnose()              pattern-matches known framework failures
    result.ok                      exit code zero AND at least one output
    """
    # TODO 1. Build one spec per variant and run them as a list.
    #
    # TODO 2. Match outputs back to variants. The framework names outputs after
    #         each sample's `name`, which is why the contract pins
    #         spec.name == variant_id. Match on the stem; do not assume the
    #         order of result.videos matches the order of your specs.
    #
    # TODO 3. Return None for any variant with no matching file, and let the
    #         caller record it as `failed`. Do not raise -- the other eight
    #         samples in the batch are fine and you have already paid for them.
    raise NotImplementedError("stage 3: implement generate_batch")
''')

nb.md("""
### The transfer spec you will not run

Decision 1 asks which control modality suits which variation. In reduced mode
Edge cannot execute `video2video` at all, so write the spec anyway and let the
validator confirm it is well formed. This is a real deliverable: the rubric asks
for a defended modality choice, and a spec that validates is evidence you
understood the mechanism rather than the vocabulary.
""")

nb.code('''
DESIGNED_TRANSFER_SPEC = None      # TODO: replace with a real InferenceSpec

# TODO. Build a video2video spec for ONE of your variants:
#   - model_mode="video2video"     -- transfer is NOT its own mode
#   - vision_path=<the control video>
#   - controls={hint: {"control_path": ..., "weight": 1.0}} for exactly one of
#     edge / blur / depth / seg
#   - num_frames must match the control video's frame count: the output geometry
#     comes from the control input, not from your spec (Lesson 08)
#
# Then say, in DECISIONS["modality"], which hint you chose and what it preserves.


def check_transfer_design():
    """The transfer spec is well formed, whether or not this tier can run it."""
    assert DESIGNED_TRANSFER_SPEC is not None, \\
        "DESIGNED_TRANSFER_SPEC is still None. Decision 1 needs a spec, not a " \\
        "sentence."
    problems = cc.validate_spec(DESIGNED_TRANSFER_SPEC, strict=False)
    assert not problems, "transfer spec is invalid:\\n  - " + "\\n  - ".join(problems)

    body = DESIGNED_TRANSFER_SPEC.to_dict()
    assert body["model_mode"] == "video2video", \\
        "transfer is video2video plus a hint block, not a mode of its own"
    hints = cc.TRANSFER_HINTS & set(body)
    assert len(hints) == 1, \\
        f"expected exactly one control hint block, found {sorted(hints)}"
    print(f"  ok  well-formed video2video spec with the {list(hints)[0]!r} hint")

    if not cc.MODEL_TIERS[MODEL]["supports_transfer"]:
        print(f"  note: {MODEL} cannot RUN this (COSMOS3_FACTS.md section 1). "
              f"The spec is still correct.")
        print("  To run it: COSMOS_COURSE_MODEL=Cosmos3-Nano, or the Challenge "
              "tier.")
    return True


print("check_transfer_design is defined.")
''')

nb.code(CHECK_STAGE_3 + '''

print("check_stage_3 is defined. Implement build_spec, then call it.")
''')

nb.callout("h100", """
`check_stage_3` deliberately spends zero GPU time. Everything it tests — mode
validity, required fields per mode, frame counts against the tier ceiling, the
aspect-ratio comma, name/id agreement, total cost against budget — is checkable
locally. The habit is the point: a nine-sample batch that dies on sample seven
because of a typo has cost you the six that worked plus the model load, and every
one of the mistakes that causes it is visible before launch.
""")

# =====================================================================
# 13. STAGE 4 — VALIDATE
# =====================================================================
nb.md("""
## Stage 4 — Validate

Two screens, in this order, and the order is not arbitrary.

**First the cheap automatic one.** `cc.check_video` decodes a few frames and
asks: does this file open, does it have frames, do consecutive frames differ
enough to be a video rather than a freeze, and not so much that it is noise. It
costs milliseconds and it catches the failures that are not worth a model's
opinion — a zero-byte file, a black clip, a guardrail rejection that produced a
blank frame and exited zero.

**Then the expensive judged one.** The reasoner looks at the surviving clips and
answers your plausibility question. This costs a NIM restart plus inference per
clip, which is why it goes second: screening with the expensive test first is
paying full price for information the cheap test already had.

The threshold is decision 3, and it is a precision/recall tradeoff you own. Set
it loose and implausible clips enter a training set that somebody will trust. Set
it tight and you throw away usable clips, which shows up directly as a higher
cost per accepted clip. Neither is safe; pick the error you would rather make and
say why it is the right error for a robotics training set.
""")

nb.code('''
# ---------------------------------------------------------------------------
# TODO: decision 3, made numeric. Both of these are yours.
# ---------------------------------------------------------------------------
ACCEPT_CONFIDENCE = None     # float in (0, 1]; None means "not decided yet"
REQUIRE_ALL_CHECKS = True    # must every cc.check_* pass, or is one failure ok?


def screen(variant, path):
    """Decide the fate of one generated clip. Cheap checks first.

    Contract
    --------
    Returns a dict with:
      "status"  one of "accepted" / "rejected" / "failed"
      "reason"  a sentence a person can act on -- not a stack trace
      "checks"  {check_name: bool} from the automatic checks
      "judge"   {"plausible", "confidence", "why"} or None if never asked

    `rejected` means the policy said no. `failed` means the pipeline broke --
    no file, a file that will not decode at all, an unreachable NIM. Keeping
    them apart is graded.

    Reuse, do not rewrite
    ---------------------
    cc.check_video(path)             CheckResult with .passed, .reason, .metrics
    cc.verify_result(result)         every applicable check on a RunResult
    cc.Reasoner.ask(..., videos=..., fps=JUDGE_FPS, temperature=0.0, seed=...)
    cc.Reasoner.parse_json(text)
    """
    # TODO 1. No file at all -> "failed". Not "rejected": nothing was judged.
    #
    # TODO 2. Automatic checks. cc.check_video returns metrics as well as a
    #         verdict; put them in "checks" so a rejected clip can be argued
    #         with later. A clip that fails here does NOT go to the judge.
    #
    # TODO 3. The judge. Ask the SAME question you asked in stage 1, so the
    #         baseline calibrates it. Parse into the BASELINE_KEYS shape.
    #         A malformed reply is a "malformed" failure, not a rejection --
    #         raise, and let run_stage classify and retry it.
    #
    # TODO 4. Apply the threshold. Accept only if the automatic checks passed
    #         AND the judge said plausible AND confidence >= ACCEPT_CONFIDENCE.
    #         Write the reason so that reading it six months from now tells you
    #         what happened without opening the video.
    raise NotImplementedError("stage 4: implement screen")
''')

nb.md("""
### The check: does it reject something broken?

A screen that accepts everything passes every test you can write about its
happy path. So test the unhappy path first, with a file that is definitely not a
video. No GPU, no NIM, no model.
""")

nb.code(CHECK_STAGE_4 + '''

print("check_stage_4 is defined. Set ACCEPT_CONFIDENCE and implement screen.")
''')

nb.md("""
### Calibrating the judge

`check_stage_4` proves the screen rejects rubbish. It says nothing about whether
it accepts *good* input, and a screen that rejects everything also passes it.

So run the judge on the real source clips — the ones you already have a baseline
for from stage 1. If your judge calls genuine footage of a real robot
implausible, the threshold or the question is wrong, and every acceptance rate
you report afterwards is measuring your prompt.

This costs one reasoner call per source clip and it is the cheapest insurance in
the notebook.
""")

nb.code('''
def calibrate_judge(verbose=True):
    """Ask the judge about the REAL clips. It should accept them.

    Returns {"agreed": int, "total": int, "disagreements": [...]}, and the
    number belongs in report section 2.3.
    """
    assert len(scenes), "run stage 1 first"
    if not nim_status(NIM)["ready"]:
        nim_up()

    agreed, disagreements = 0, []
    for scene in scenes.records():
        fake = {"variant_id": f"calib-{scene['clip_id']}",
                "clip_id": scene["clip_id"], "axis": "none",
                "axis_value": "none", "modality": "image2video",
                "control_hint": None, "prompt": "calibration", "seed": 0}
        outcome = screen(fake, Path(scene["source_path"]))
        if outcome["status"] == "accepted":
            agreed += 1
        else:
            disagreements.append({
                "clip_id": scene["clip_id"],
                "status": outcome["status"],
                "reason": outcome["reason"],
                "stage1_baseline": scene["baseline"],
            })

    if verbose:
        print(f"  judge accepted {agreed}/{len(scenes)} REAL clips")
        for item in disagreements:
            print(f"    {item['clip_id']}: {item['status']} -- {item['reason'][:90]}")
        if disagreements:
            print()
            print("  Your judge rejects real footage. Before you screen anything")
            print("  with it, decide which is true:")
            print("    (a) the threshold is too tight -> lower ACCEPT_CONFIDENCE")
            print("    (b) the question is wrong -> rewrite it and redo stage 1")
            print("    (c) check_video's thresholds do not suit your footage ->")
            print("        look at .metrics and argue with the default")
    return {"agreed": agreed, "total": len(scenes),
            "disagreements": disagreements}


print("calibrate_judge is defined.")
''')

nb.callout("deeper", """
There is a circularity here that you have to name in the report and cannot fully
remove. The reasoner and the generator are two towers of **one checkpoint**
(`COSMOS3_FACTS.md` §1). A judge drawn from the same model as the generator
shares its priors, so it is systematically likely to find plausible exactly the
things that model likes to produce. Lesson 18 made this argument about evaluating
a fine-tune; it applies with equal force to screening synthetic data.

Partial mitigations, none free: restrict the judge to nearly mechanical questions
("is the gripper in contact with the mug in the last frame?") rather than
evaluative ones; use a different model family as a second judge; or spot-check a
sample by eye and report your disagreement rate, which is what the rubric asks
for as a minimum.
""")

# =====================================================================
# 14. STAGE 5 — MEASURE
# =====================================================================
nb.md("""
## Stage 5 — Measure

Profiling is not optional here and it is not a nice-to-have section at the end.
Criterion S8 and rubric criterion 3 both require it, and rubric gate **G1** fails
the whole capstone for any performance number in the report that is not in a
file under `outputs/capstone/`.

Four things have to be measured, and three of them are easy to get wrong on this
particular pipeline:

**Wall clock per stage.** `cc.StageClock` accumulates it. It refuses to nest,
because a nested stage double-counts seconds and then the totals exceed the wall
clock and a reader spends their time on your arithmetic instead of your result.

**Peak VRAM, device-wide.** `torch.cuda.max_memory_allocated()` in this kernel
sees only this kernel. Generation is a `torchrun` subprocess and the reasoner is
a container, so from here both of them appear to use no memory at all. Use
`cc.DeviceSampler`, which asks the driver. Getting this wrong produces a
suspiciously excellent result, which is how you can spot it.

**Switching overhead.** The seconds spent starting and stopping the NIM, as an
absolute number and as a fraction. This is the tax you pay for having one GPU,
and reporting it is the difference between "generation is slow" and "generation
is fine and I spent a quarter of the run restarting a container".

**Cost per accepted clip.** GPU-seconds divided by accepted clips. Note the
denominator: a pipeline with a 20% acceptance rate costs five times per useful
clip what its per-variant time suggests, and that is the number that decides
whether this approach is affordable.
""")

nb.code('''
METRIC_KEYS = (
    # what was run
    "mode", "model", "resolution", "num_frames", "num_steps", "gen_batch_size",
    "n_sources", "n_attempted",
    # yield -- rejected and failed are SEPARATE
    "n_accepted", "n_rejected", "n_failed", "acceptance_rate",
    # time
    "stage_seconds", "switch_seconds", "switch_fraction",
    "wall_clock_seconds", "unaccounted_seconds", "dominant_stage",
    # memory
    "peak_vram_gb",
    # cost, predicted and measured
    "gpu_seconds_per_accepted", "accepted_per_gpu_hour",
    "predicted_seconds_per_accepted", "prediction_ratio",
    "predicted_dominant_stage",
    # quality of the design
    "diversity", "judge_calibration", "resume_events",
)


def collect_metrics(clock, manifest, prediction, extras=None):
    """Assemble metrics.json from the ledger, the clock and the samplers.

    Contract
    --------
    Returns a dict containing every key in METRIC_KEYS. Numbers only where a
    number was measured; None where it was not, and never a plausible-looking
    placeholder. `stage_seconds` maps stage name -> seconds and its values plus
    `unaccounted_seconds` must not exceed `wall_clock_seconds`.

    Reuse, do not rewrite
    ---------------------
    clock.to_dict()          stage_seconds, accounted, wall, unaccounted
    clock.fraction("switch") switching as a share of accounted time
    manifest.counts("status") accepted / rejected / failed, already tallied
    cc.MeasurementLog        append each timed operation as you go
    """
    # TODO 1. Yield from manifest.counts("status"). Do not recount by hand; the
    #         ledger is the source of truth and a second count that disagrees
    #         with it is a bug you will find at the worst moment.
    #
    # TODO 2. Time from clock.to_dict(). Report unaccounted seconds rather than
    #         hiding them -- if it is large, that IS a finding.
    #
    # TODO 3. Peak VRAM from the DeviceSampler readings you collected per stage.
    #         Report per stage and overall. Criterion S6 is 75 GB.
    #
    # TODO 4. Cost per accepted clip, and the ratio against `prediction`.
    #         prediction_ratio = measured / predicted. Say which way it went.
    #
    # TODO 5. Fill predicted_dominant_stage from your committed prediction and
    #         dominant_stage from the clock, so the report can compare them.
    raise NotImplementedError("stage 5: implement collect_metrics")
''')

nb.code(CHECK_STAGE_5 + '''

print("check_stage_5 is defined.")
''')

# =====================================================================
# 15. STAGE 6 — REPORT
# =====================================================================
nb.md("""
## Stage 6 — Report

The template is `assets/reference/CAPSTONE_REPORT_TEMPLATE.md`. **Eight sections**,
numbered `## 0.` through `## 7.`, and none of them may be deleted — if you did not
do something, write "not done, because …". A missing section reads as an
oversight; an empty one with a reason reads as a decision, and the rubric scores
those differently.

`write_report` is the only stage where you are allowed to be generous with
yourself about automation. Generating the numeric tables from `metrics.json` is
good practice — it makes gate G1 automatic. Generating the *prose* is not: the
justifications, the threats to validity and the "what this does not show" section
are the part being graded, and a template-filled paragraph reads exactly as
template-filled as it is.
""")

nb.code(REPORT_SECTIONS + '''

def write_report(metrics, decisions, path=None):
    """Fill the template into outputs/capstone/REPORT.md.

    Contract
    --------
    Writes a file containing every heading in REPORT_SECTIONS, with no "[FILL]"
    and no "<...>" placeholders remaining. Every number in it must also be in
    metrics.json -- that is rubric gate G1 and it is checked by a human, so make
    it easy on yourself by generating the tables rather than typing them.
    """
    # TODO 1. Read TEMPLATE_PATH.
    # TODO 2. Substitute the numeric placeholders from `metrics`.
    # TODO 3. Substitute your four decisions from `decisions` into section 2.
    # TODO 4. Write the prose yourself: sections 0, 4, 5 and 6. These are the
    #         graded ones. Section 5 needs four or more items and at least one
    #         of them should be inconvenient for you.
    raise NotImplementedError("stage 6: implement write_report")
''')

nb.code(CHECK_STAGE_6 + '''

print("check_stage_6 is defined.")
''')

# =====================================================================
# 16. THE ORCHESTRATOR
# =====================================================================
nb.md("""
## Putting it together

The orchestrator is deliberately thin. If yours needs much more than this, the
extra logic belongs inside a stage — that is what the contracts are for.

Read the shape of it before you fill it in, because the shape encodes three of
the constraints from the top of this notebook:

- **stages are batched by model residency**, not by clip, so the NIM comes up
  twice and not twice per clip;
- **every unit of work goes through `cc.run_stage`**, which times it, classifies
  any failure and never raises, so one bad clip cannot end the run;
- **the ledger is consulted before every unit**, which is the entire resume
  mechanism and needs no special code path.
""")

nb.code('''
def run_pipeline(resume=True, limit=None):
    """The whole flywheel. Thin on purpose. Returns the metrics dict.

    Order is dictated by VRAM, not by data flow:
        NIM up   -> reason every clip
        NIM down -> generate every batch
        NIM up   -> validate every clip
        NIM down -> measure and report
    """
    outcomes = []
    peaks = {}

    # -- 1. reason ---------------------------------------------------------
    nim_up()
    for clip_id, path in (SOURCES[:limit] if limit else SOURCES):
        if resume and scenes.has(clip_id):
            print(f"[skip] reason {clip_id} (already in the ledger)")
            continue
        # TODO: run_stage("reason", ...) with key=clip_id, clock=clock,
        #       retries=1, on_retry=<something that restarts the NIM>.
        #       On success, scenes.append(outcome.value).
        #       On failure, record it -- a clip you could not caption is a
        #       result, and it is not the same as one you could not generate.
        raise NotImplementedError("orchestrator: the reason loop")

    # -- 2. vary -----------------------------------------------------------
    with clock.stage("vary"):
        # TODO: plans = [plan for each scene], and record diversity_score(plans).
        #       No GPU, no model. Cheap enough to redo on every resume.
        raise NotImplementedError("orchestrator: the vary step")

    # -- 3. generate -------------------------------------------------------
    nim_down()
    # TODO: skip anything already in the manifest; batch the rest in groups of
    #       GEN_BATCH_SIZE; run_stage("generate", ..., sample_vram=True); record
    #       a `failed` manifest entry for every variant that produced no file.

    # -- 4. validate -------------------------------------------------------
    nim_up()
    # TODO: for each generated file, run_stage("validate", ...) and append the
    #       full manifest record. A malformed judge reply is retryable; an
    #       undecodable file is not.

    # -- 5. measure and report --------------------------------------------
    nim_down()
    with clock.stage("measure"):
        # TODO: metrics = collect_metrics(clock, manifest, PREDICTION, ...)
        #       METRICS_PATH.write_text(json.dumps(metrics, indent=2))
        raise NotImplementedError("orchestrator: measure")

    return outcomes, peaks


print("run_pipeline is a skeleton. Fill it in after the six stage checks pass.")
''')

nb.callout("warning", """
Do not call `nim_up()` or `nim_down()` inside a `with clock.stage(...)` block.
Both already open a `switch` stage of their own, and `StageClock` refuses to
nest — you will get a `RuntimeError` telling you exactly this. The restriction is
deliberate: nested timing produces stage totals that exceed the wall clock, and
then nobody can trust any of your numbers.
""")

# =====================================================================
# 17. PREDICT-RUN-EXPLAIN #2
# =====================================================================
nb.md("""
## The batching question

`GEN_BATCH_SIZE` is the one knob in this notebook whose effect you can predict
from first principles and then check, which makes it the best possible use of
five minutes.

One `Generator.run` costs a fixed amount — spawn a subprocess, import the
framework, load the checkpoint, build the pipeline — plus per-sample sampling
time. Batching amortises the fixed part across the batch. It also means a crash
takes the whole batch with it, and the ledger cannot save work that was never
written.
""")

nb.predict_run_explain(
    predict=(
        "With your calibration's `fixed_overhead_s` and `units_per_second`, "
        "predict the total generate-stage seconds for the whole run at "
        "`GEN_BATCH_SIZE = 1` and at `GEN_BATCH_SIZE = N_PLANNED`. Then predict "
        "the expected seconds of work *lost* per crash at each setting, "
        "assuming one crash somewhere uniformly at random. Which setting has "
        "the better expected total time including the loss?"
    ),
    change=(
        "Run the cell below, which does the arithmetic for a range of batch "
        "sizes. Then change `GEN_BATCH_SIZE` in the config cell to whatever you "
        "decided and justify it in `DECISIONS['budget']`."
    ),
    explain=(
        "The curve is not linear and it flattens fast: most of the benefit is in "
        "the first doubling. Explain why, in terms of which term of the cost "
        "model each additional sample adds to. Then explain what the curve does "
        "NOT model — the thing that actually decides this at full resolution, "
        "where the fixed cost is a rounding error."
    ),
    hint=(
        "Amortised launch cost per variant is `fixed_overhead_s / batch_size`, "
        "so the saving from 1 to 2 is half the overhead and the saving from 8 "
        "to 9 is about one seventy-second of it. Expected loss per crash grows "
        "linearly in batch size. The two curves cross somewhere, and where they "
        "cross depends on how likely a crash is on your machine — which you can "
        "estimate from how many you have had so far in this course."
    ),
)

nb.code('''
if UNITS_PER_SECOND:
    print(f"{'batch':>6}{'launches':>10}{'launch s':>11}{'sample s':>11}"
          f"{'total s':>10}{'lost/crash':>12}")
    for batch in (1, 2, 3, 4, 6, N_PLANNED):
        if batch > N_PLANNED:
            continue
        launches = -(-N_PLANNED // batch)          # ceiling division
        launch_s = launches * FIXED_OVERHEAD_S
        sample_s = N_PLANNED * units_per_variant / UNITS_PER_SECOND
        # A crash lands uniformly inside a batch, so on average half the batch's
        # sampling is lost, plus the whole launch that produced it.
        lost = FIXED_OVERHEAD_S + 0.5 * batch * units_per_variant / UNITS_PER_SECOND
        print(f"{batch:>6}{launches:>10}{launch_s:>11.0f}{sample_s:>11.0f}"
              f"{launch_s + sample_s:>10.0f}{lost:>12.0f}")
    print()
    print("These are predictions from YOUR Lesson 06 calibration, not")
    print("measurements. The generate stage will tell you how good they were.")
else:
    print("No calibration on this machine, so there is nothing to predict from.")
    print("Re-run Lesson 06's calibration cell, or run this pipeline once and")
    print("calibrate from the numbers it produces -- and label them as such.")
''')

nb.callout("h100", """
What the table does not model, and what actually decides this at 480p or 720p:
sampling time grows with latent tokens times steps, while the launch cost does
not grow at all. At the reduced tier the launch is most of the cost and batching
is transformative. At full resolution the launch is a few percent and batching
buys you almost nothing while still costing you the whole batch on a crash. The
right answer to "should I batch?" is therefore different in your two modes, which
is exactly the kind of thing a decision has to say out loud.
""")

# =====================================================================
# 18. DEBUGGING LAB
# =====================================================================
nb.md("""
## Debugging lab — the four failures you must survive

Criterion **S10** and rubric criterion 4. Four failures, each with a different
correct response, and the pipeline has to tell them apart. Work each one through
symptom → hypothesis → diagnostic → repair → verification.

The important idea underneath: **an error class is a routing decision.** Retrying
an OOM unchanged gets you a second OOM and a wasted model load. Retrying a
malformed JSON reply usually works, because sampling is stochastic. Restarting a
dead container and retrying works. Retrying a bug in your own code gets you the
same bug at a slower rate. `cc.classify_error` puts a failure in one of five
buckets and `cc.StageOutcome.retryable()` turns that into a yes or no.
""")

nb.code('''
# The strings below are real signatures, shortened. Predict the classification
# for each BEFORE you run the cell -- write your five answers down.
SIGNATURES = {
    "generator OOM": (
        "RuntimeError: CUDA out of memory. Tried to allocate 3.91 GiB "
        "(GPU 0; 79.15 GiB total capacity; 71.02 GiB already allocated)"),
    "NIM container gone": (
        "APIConnectionError: Connection error. "
        "[Errno 111] Connection refused: http://localhost:8000/v1/chat/completions"),
    "malformed judge reply": (
        "json.decoder.JSONDecodeError: Expecting value: line 1 column 1 (char 0)"),
    "run exceeded its timeout": (
        "subprocess.TimeoutExpired: Command '[torchrun ...]' timed out after 1800 s"),
    "a bug in my own stage": (
        "KeyError: 'lighting'"),
}

print(f"{'signature':<26}{'class':<12}{'retry?':<8}what to do")
print("-" * 96)
ROUTING = {
    "oom": "shrink the job (frames, resolution, steps) and re-run it. Do NOT retry unchanged.",
    "service": "restart the NIM, then retry the same item.",
    "malformed": "retry once with a stricter prompt. Twice means the prompt is wrong.",
    "timeout": "the job is too big for the budget. Shrink it; retrying is a second timeout.",
    "other": "your code. Stop the run and fix it -- do not grind through 40 identical failures.",
}
for label, text in SIGNATURES.items():
    cls = cc.classify_error(text)
    outcome = cc.StageOutcome(name="drill", ok=False, seconds=0.0,
                              error=text, error_class=cls)
    print(f"{label:<26}{cls:<12}{str(outcome.retryable()):<8}{ROUTING[cls]}")
''')

nb.md("""
### Failure 1 — a rejected clip that is actually fine

**Symptom.** `check_video` rejects a clip. You watch it and it looks like a
video.

**Hypothesis.** `check_video` is not asking "is this good", it is asking two
narrower questions: do consecutive frames differ *enough* (a freeze looks like a
still image), and *not too much* (noise looks like maximum change). A slow,
smooth, correctly generated clip with a static camera can trip the lower bound.

**Diagnostic.** The `CheckResult` carries its metrics. Look at them before you
argue with the verdict, and compare against a clip you know is fine.

**Repair.** Either raise the threshold with an argument, or accept that this is a
true rejection. Both are defensible. Silently loosening it until nothing is
rejected is not.

**Verification.** Re-run the check on a clip you know is a freeze and confirm it
is still caught.
""")

nb.code('''
# Runnable now: the metrics are what you argue with, not the boolean.
sample = SOURCES[0][1]
result = cc.check_video(sample)
print(f"{sample.name}: passed={result.passed}  {result.reason}")
for key, value in result.metrics.items():
    print(f"    {key:<24} {value}")
print()
print("cc.check_video's defaults: min_frames=2, min_temporal_change=0.15,")
print("max_temporal_change=60.0. A static-camera clip of a slow manipulator")
print("sits near the lower bound. If you move it, move it for a stated reason")
print("and record the reason in the manifest -- otherwise your acceptance rate")
print("is a function of an undocumented constant.")
''')

nb.md("""
### Failure 2 — an OOM in the generator

**Symptom.** `Generator.run` returns a non-zero exit code, no output file, and a
tail full of allocator numbers. Or worse: the notebook kernel survives and the
*next* run also fails, because something is still holding the card.

**Hypothesis.** Either the job is too big for the tier, or the NIM was still
resident when generation started, or a previous run's process did not exit.

**Diagnostic.** `result.diagnose()` pattern-matches the framework's output
against failures this course has hit. Then look at the card directly — the
generator is a subprocess, so this kernel's allocator counters are irrelevant.

**Repair.** `cc.oom_advice()` prints the escalation ladder for one GPU, in
order. Note which rungs do not exist for you: raising the FSDP shard degree and
raising the context-parallel degree both need more GPUs (`COSMOS3_FACTS.md` §5).
On one card you have `expandable_segments`, activation checkpointing, a smaller
job, and — for training only — LoRA.

**Verification.** Re-run at the reduced geometry and confirm the peak sampled by
`cc.DeviceSampler` is where you predicted.
""")

nb.code('''
# What the card actually has on it right now. Run this before every generate
# stage; it is the cheapest possible insurance against failure 2.
probe = DeviceSampler()
used = probe.read_gb()
status = nim_status(NIM)
print(f"device VRAM in use : {used:.1f} GB" if used is not None
      else "device VRAM in use : unknown (nvidia-smi unavailable)")
print(f"NIM container      : {'running' if status['running'] else 'not running'}"
      f"  ready={status['ready']}")
if status["vram_gb"]:
    print(f"NIM is holding     : {status['vram_gb']:.1f} GB")
print()
if used is not None and used > 8.0 and not status["running"]:
    print("Something is holding the card and it is not the NIM. Usually a")
    print("python process from an earlier notebook that did not exit. Find it")
    print("with `nvidia-smi` and kill it -- your next generation will OOM for")
    print("no visible reason otherwise.")

print()
cc.oom_advice(model=MODEL, resolution=RES, num_frames=N_FRAMES,
              num_steps=N_STEPS)
''')

nb.md("""
### Failure 3 — the NIM died mid-run

**Symptom.** Stage 4 was going fine and now every clip raises a connection
error. The container is gone.

**Hypothesis.** Docker killed it (OOM inside the container), or something else
grabbed the port, or it was never healthy and the first few calls happened to be
served before it fell over.

**Diagnostic.** `nim_status()` reports from four independent sources: docker's
view, the health endpoint, the model list, and `nvidia-smi`. "Container running
but not ready" is loading. "Container gone but VRAM still high" is something
else entirely, and that distinction is why the function reports all four rather
than a boolean.

**Repair.** This is a `service` failure, so it *is* retryable — but only after
you fix the service. That is exactly what `run_stage(..., on_retry=...)` is for:
the hook runs between attempts, and restarting the NIM there is the difference
between a retry that works and a retry that fails identically.

**Verification.** `nim_logs()` for the last 50 lines, then one successful call.
""")

nb.code('''
def restart_nim_then_retry(outcome):
    """on_retry hook: bring the service back before the next attempt.

    Retrying a `service` failure without doing this just fails again, more
    quickly. The hook is where the state of the world changes -- that is the
    whole reason run_stage takes one rather than looping internally.
    """
    print(f"    {outcome.error_class} failure -- restarting the NIM before retry")
    stop_nim(NIM, quiet=True)
    start_nim(NIM, wait=True, timeout=2400, quiet=True)


print("restart_nim_then_retry is defined. Pass it as on_retry= in the reason")
print("and validate loops.")
''')

nb.md("""
The drill below points a `Reasoner` at a port with nothing on it, so you can
watch classification and the retry hook work without killing a container you
want. It is tagged `skip-execution` because it takes a deliberate connection
timeout, which is a poor use of an automated run's time — but run it by hand once.
""")

nb.code('''
dead = Reasoner(base_url="http://localhost:9", max_retries=1)
drill = run_stage(
    "reason", lambda: dead.ask("hello"), key="drill", retries=1,
    on_retry=lambda o: print("    (the real hook would restart the NIM here)"))
print()
print(f"classified as : {drill.error_class}")
print(f"retryable     : {drill.retryable()}")
print("pipeline state: still running -- run_stage does not raise")
''', tags=["skip-execution"])

nb.md("""
### Failure 4 — a malformed model response

**Symptom.** `parse_json` raises. The model wrote a paragraph, or fenced the
JSON, or emitted a `<think>` block, or produced JSON with a trailing comma.

**Hypothesis.** Three of those four are handled by `Reasoner.parse_json`, which
scans for the first *balanced* brace pair rather than using a greedy regex.
If it still raises, the reply genuinely is not JSON.

**Diagnostic.** Print the raw text. Always. The reply almost always tells you
what the prompt did wrong, and no amount of reasoning about the parser
substitutes for looking at fifty characters of output.

**Repair.** Retry once with a stricter instruction. If it happens twice on the
same input, the prompt is wrong, not the model — and Lesson 03's three levers
are where to look: "reply with JSON only", an example object pinning key names
and types, and "use the string `unknown` rather than omitting a key".

**Verification.** The retry parses, and a rerun at `temperature=0.0` with the
same seed reproduces it.
""")

nb.code('''
# Runnable: the four wrappings, through the real parser.
WRAPPINGS = {
    "bare":        '{"plausible": true, "confidence": 0.8, "why": "consistent motion"}',
    "code fence":  '```json\\n{"plausible": true, "confidence": 0.8, "why": "ok"}\\n```',
    "with prose":  'Here is my assessment:\\n{"plausible": false, "confidence": 0.9, "why": "the mug passes through the table"}\\nLet me know if you need more.',
    "after think": '<think>The gripper closes before contact.</think>\\n{"plausible": false, "confidence": 0.7, "why": "grasp precedes contact"}',
    "not json":    'The video seems physically plausible to me.',
}

for label, text in WRAPPINGS.items():
    try:
        parsed = Reasoner.parse_json(text)
        print(f"  {label:<12} parsed -> {parsed}")
    except Exception as exc:
        cls = cc.classify_error(exc)
        print(f"  {label:<12} RAISED {type(exc).__name__} -> classified {cls!r}")
        print(f"               raw reply: {text[:60]!r}")
''')

nb.callout("gotcha", """
Notice which of the five failed. The parser handles fences, leading prose,
trailing prose and `<think>` blocks — everything except a reply that contains no
JSON at all. That last case is a *prompt* failure wearing a parser's clothing,
and the fix is in the prompt. If you find yourself writing a regex to extract a
boolean from an English sentence, stop: you are building a parser for output you
should have constrained.
""")

nb.md("""
### Failure 5 — the one that is not on the list

You will hit something these four do not cover. When you do, work it the same
way and write it down: symptom, hypothesis, the diagnostic that discriminated
between your hypotheses, the repair, the verification. Then classify it — is it
`oom`, `service`, `malformed`, `timeout`, or a bug in your code? — and decide
whether your retry policy handles it.

The rubric's "excellent" level for failure handling asks for exactly this: a
failure you found yourself, from your own run, handled. It is worth more than the
four supplied ones because you had to notice it.
""")

# =====================================================================
# 19. THE THREE GRADED TIERS
# =====================================================================
nb.md("""
## Exercises — the three graded tiers

These replace the usual three exercises, and they are the deliverable. Stop at
whichever tier you reach; the rubric ceiling rises with the tier, and
`assets/reference/CAPSTONE_RUBRIC.md` says exactly how.

| Tier | Scope | Rubric ceiling |
|---|---|---|
| Foundation | reduced pipeline, **one** source clip, `check_stage_0()` … `check_stage_4()` green (five of the seven) | not a pass on its own |
| Applied | the full reduced run, defended policy, measurement, report | **the pass condition** |
| Challenge | an extension with a hypothesis and a measured answer | required for a top score |
""")

nb.exercise(
    "foundation",
    "One clip, end to end, `check_stage_0` … `check_stage_4` green",
    goal=(
        "Get the pipeline to carry a single real clip all the way to a screened, "
        "recorded verdict. This is a plumbing exercise: the point is that the "
        "six contracts hold, not that the output is any good."
    ),
    instructions=(
        "1. Implement `reason_stage`, and get `check_stage_1()` green on one "
        "   clip. Look at the plausibility baseline it returns for the REAL "
        "   footage — if it says implausible, fix that before anything else.\n"
        "2. Add two more axes to `AXES`, implement `plan_variants` and "
        "   `diversity_score`, and get `check_stage_2()` green. The "
        "   determinism assertion is the one that catches most people.\n"
        "3. Implement `build_spec` and get `check_stage_3()` green. It spends no "
        "   GPU time, so iterate here until it is clean.\n"
        "4. Set `ACCEPT_CONFIDENCE`, implement `screen`, and get "
        "   `check_stage_4()` green. It only tests the *unhappy* path, which is "
        "   deliberate.\n"
        "5. Implement `generate_batch` and run the three variants of your one "
        "   clip. Verify every output with `cc.verify_result` — not with the "
        "   exit code.\n"
        "6. Append one manifest record per attempted variant, including any that "
        "   produced nothing.\n"
        "7. Run `check_stage_0()` … `check_stage_4()` in a **fresh kernel**, top "
        "   to bottom, and confirm they still pass."
    ),
    success=(
        "All of `check_stage_0` through `check_stage_4` pass from a clean "
        "kernel. `outputs/capstone/manifest.jsonl` has one record per attempted "
        "variant with a status and a readable reason. At least one generated "
        "file exists and passes `cc.check_video`. You can name, from your own "
        "manifest, which source clip and which prompt produced it."
    ),
    starter='''
# Foundation: the smallest end-to-end path. Fill in the stages, then run this.
FOUNDATION_CLIP = SOURCES[0]

nim_up()
scene = check_stage_1(clip=FOUNDATION_CLIP)
scenes.record_once(scene)

plans = check_stage_2(scene=scene)
check_stage_3(plans=plans)
check_stage_4()

nim_down()
# TODO: generate_batch(plans, {scene["clip_id"]: scene}), then screen each
#       output and append a manifest record for every plan -- including the
#       ones that produced no file.
''',
    hints=[
        "Do stage 1 and stage 4 with the same question. The whole value of the "
        "stage-1 baseline is that it calibrates the stage-4 judge, and a "
        "baseline taken with a different prompt calibrates nothing.",
        "`check_stage_2`'s determinism assertion fails for one reason in "
        "practice: a `variant_id` built from `uuid4()`, `id()` or the clock. "
        "Build it from the inputs — clip id, axis, axis value, modality, seed — "
        "and it is stable for free. A short hash of that tuple keeps it "
        "readable.",
        "For `image2video` you need a first frame and you have a video. "
        "`ffmpeg -i clip.mp4 -frames:v 1 first.png` costs nothing and keeps the "
        "provenance honest, which matters because the manifest claims the "
        "variant came from that clip.",
    ],
    solution_ref="solutions/19_capstone_reference.ipynb",
)

nb.exercise(
    "applied",
    "The full reduced run, with a defended policy and a report",
    goal=(
        "Run the whole flywheel unattended on 3 source clips and ~9 variants, "
        "measure it properly, defend the accept/reject policy with evidence "
        "including your own eyes, and write the report."
    ),
    instructions=(
        "**1. Finish the orchestrator.** `run_pipeline()` end to end, unattended, "
        "from one cell. Every unit of work through `cc.run_stage`; every verdict "
        "in the ledger the moment it is known.\n\n"
        "**2. Calibrate the judge** with `calibrate_judge()` before you trust it, "
        "and record the number.\n\n"
        "**3. Prove resume works.** Start the run, interrupt the kernel part way "
        "through the generate stage, restart it and run again. Count what you "
        "lost from the ledger. Criterion S9 allows at most one completed "
        "variant.\n\n"
        "**4. Spot-check the judge by eye.** Watch at least five accepted clips "
        "and three rejected ones with `cc.show_video`. Fill in the 2x2 "
        "agreement table in report §2.3. This is the only independent evidence "
        "you will have about the one component nothing else validates.\n\n"
        "**5. Measure.** `collect_metrics` and `check_stage_5()`. Per-stage wall "
        "clock, device-wide peak VRAM, switching overhead as a fraction, cost "
        "per accepted clip, and the reconciliation against the prediction you "
        "committed before the run.\n\n"
        "**6. Answer all four decisions** in `DECISIONS` and get "
        "`check_decisions()` green.\n\n"
        "**7. Write the report** against the template and get `check_stage_6()` "
        "green. Then run the self-assessment checklist at the end of the rubric."
    ),
    success=(
        "Criteria S1–S10 all satisfied. `check_stage_0` … `check_stage_6` and "
        "`check_decisions` all pass — that is all seven stage checks, not the "
        "five the Foundation tier stopped at. `metrics.json` has every key in "
        "`METRIC_KEYS`. `REPORT.md` has all eight sections, no placeholders, at "
        "least four items in 'what this does not show', and a reconciliation "
        "that names the dominant term in the prediction error rather than just "
        "reporting the ratio."
    ),
    starter='''
# Applied: the whole thing. Expect to run this more than once.
outcomes, peaks = run_pipeline(resume=True)

metrics = collect_metrics(clock, manifest, PREDICTION, extras={"peaks": peaks})
METRICS_PATH.write_text(json.dumps(metrics, indent=2) + "\\n")
check_stage_5(metrics)

check_decisions()
write_report(metrics, DECISIONS, REPORT_PATH)
check_stage_6()

print(clock.table())
print()
print(cc.stage_table(outcomes))
''',
    hints=[
        "If the switching fraction surprises you, it is probably because the NIM "
        "comes up twice and each start pays for a health-check poll loop. "
        "`start_nim` returns `startup_seconds`; log it rather than inferring it "
        "from the clock, and then you can separate 'the container started' from "
        "'the model finished loading'.",
        "For the resume demonstration, interrupt during the *generate* stage "
        "rather than during reason or validate. It is the stage where a batch is "
        "in flight, so it is the one where the batch-size tradeoff from decision "
        "4 actually costs you something — which makes the number worth reporting.",
        "A reconciliation that names the dominant term usually looks like: "
        "'predicted 140 s/accepted, measured 380 s. Of the 240 s gap, roughly "
        "180 s is the two NIM restarts, which the unit model does not include at "
        "all, and about 40 s is the acceptance rate coming in at 0.44 rather "
        "than the 0.6 I guessed.' Two terms, both with numbers. That is the shape.",
        "If your acceptance rate is 100%, your threshold is almost certainly too "
        "loose — and if it is 0%, look at the judge calibration before you look "
        "at the generator. Either extreme is worth a paragraph in the report, "
        "and neither is worth quietly moving the threshold until the number "
        "looks respectable.",
    ],
    solution_ref="solutions/19_capstone_reference.ipynb",
)

nb.exercise(
    "challenge",
    "Extend it, and measure whether the extension helped",
    goal=(
        "Change one thing about the pipeline, form a hypothesis about what it "
        "will do to a number you already measure, and find out. The point is the "
        "measured answer, not the extension."
    ),
    instructions=(
        "Pick **one** of these. Each is a genuine experiment with a real chance "
        "of a null result, and a well-measured null result scores higher here "
        "than a vague positive one.\n\n"
        "**A. The Lesson 17 checkpoint in the generate stage.** Point "
        "`Generator` at the fine-tuned Edge checkpoint from Lesson 17 and ask "
        "whether it changes the acceptance rate. Hold prompts, seeds, geometry "
        "and threshold fixed; the only thing that moves is the checkpoint. "
        "Lesson 18's arithmetic applies directly and it is unforgiving: with a "
        "handful of paired clips you can only detect a large effect, so compute "
        "what size of effect you could have detected before you interpret the "
        "one you got.\n\n"
        "**B. A second control modality.** Run the transfer spec you designed "
        "and validated in stage 3, with `COSMOS_COURSE_MODEL=Cosmos3-Nano`. "
        "Generate the same variation two ways — `image2video`, and "
        "`video2video` with a control hint — and measure the *diversity gain* "
        "with the criterion you defined in decision 2, plus the change in "
        "acceptance rate and in cost per accepted clip. Then say which mode you "
        "would use for which axis, with the number.\n\n"
        "**C. A cheaper screen.** Your judge costs a NIM restart plus inference "
        "per clip. Replace it with something cheaper — a stricter "
        "`check_video`, an optical-flow statistic, a first-frame/last-frame "
        "consistency test — and measure the *agreement* with the judge as well "
        "as the time saved. A screen that is 90% as accurate for 2% of the cost "
        "changes the shape of the whole pipeline; one that is 60% as accurate "
        "does not.\n\n"
        "Whichever you pick: state the hypothesis before you run, hold "
        "everything else fixed, pair on the seed, report an interval, and add a "
        "section to the report."
    ),
    success=(
        "A stated hypothesis, a controlled comparison with everything but one "
        "variable held fixed, a measured effect with an interval or an explicit "
        "statement that n is too small for one, and a verdict you are willing "
        "to defend — including 'no detectable difference, and here is the size "
        "of effect I could have detected'. The report gains a section and the "
        "manifest gains a column that identifies which arm each clip came from."
    ),
    starter='''
# Challenge A: the Lesson 17 checkpoint as a second arm.
L17_RUN_DIR = cc.OUTPUT_ROOT / "17" / "train" / "cosmos3" / "sft" / "vision_sft_edge"
LATEST = L17_RUN_DIR / "checkpoints" / "latest_checkpoint.txt"

if LATEST.exists():
    TUNED = L17_RUN_DIR / "checkpoints" / LATEST.read_text().strip()
    print(f"fine-tuned checkpoint: {TUNED}")
    # Generator.run forwards extra_args to the framework, and the framework
    # takes --checkpoint-path. Same prompts, same seeds, same geometry.
    # TODO: arm = generator.run(specs, out_dir, extra_args=["--checkpoint-path", str(TUNED)])
else:
    print("No Lesson 17 checkpoint. Options, in order of usefulness:")
    print("  - option B or C instead;")
    print("  - base against base at different seeds, which measures your")
    print("    harness's null behaviour and is genuinely worth having.")

# TODO: hypothesis, in writing, BEFORE the run.
# TODO: paired comparison -- same prompt and seed in both arms.
# TODO: what effect size could this n have detected? (Lesson 18)
''',
    hints=[
        "For A: Lesson 17's fine-tune ran for tens of iterations at a fraction "
        "of the shipped global batch, inside a warmup schedule that had not "
        "finished. 'I cannot distinguish this from the base model' is very "
        "likely the correct answer, and it belongs in the report as the "
        "headline rather than as an apology.",
        "For B: the output geometry of a transfer run comes from the control "
        "video, not from your spec (Lesson 08). If you want a like-for-like "
        "comparison against image2video you have to make the frame counts agree, "
        "which means trimming the control — and a trimmed control is a different "
        "control, so say so.",
        "For C: measure agreement with a 2x2 table, not with an accuracy "
        "percentage. If your judge accepts 70% of clips, a screen that accepts "
        "everything is '70% accurate' and useless. The interesting number is "
        "what it does on the 30% the judge rejected.",
        "For all three: the number that decides whether your result means "
        "anything is the seed variance you measured in Lesson 18, not the size "
        "of the difference you observed. Compute it first and you will know "
        "before you start whether the experiment can answer the question.",
    ],
    solution_ref="solutions/19_capstone_reference.ipynb",
)

# =====================================================================
# 20. ASSESSMENT AND REFLECTION
# =====================================================================
nb.md("""
## Assessment

Most of this section is checkable, and a surprising amount of it is checkable by
machine. The order is deliberate: find out where you actually are, then answer
the questions, then read the summary. Doing it the other way round is more
comfortable and tells you less.

### Practical completion test

You are finished when, from a clean kernel:

- `check_stage_0()` … `check_stage_6()` and `check_decisions()` all pass;
- `outputs/capstone/manifest.jsonl` has one record per attempted variant, with
  `accepted`, `rejected` and `failed` as distinct statuses;
- `outputs/capstone/metrics.json` contains every key in `METRIC_KEYS`, all of
  them measured on your machine;
- `outputs/capstone/REPORT.md` has all eight sections (`## 0.` – `## 7.`) and no
  placeholders;
- you can point at the ledger and say what an interruption cost you;
- every performance number in the report appears in a file under
  `outputs/capstone/`.

Then score yourself against `assets/reference/CAPSTONE_RUBRIC.md` and run its
self-assessment checklist. It takes ten minutes and it moves most people up a
level on at least two criteria.

The next two cells do the parts of that list a machine can do.
""")

nb.code('''
# Where you are, computed rather than remembered. Same DELIVERABLES and
# STAGE_CHECKS you defined at the top of the notebook.
print("deliverables")
for name, path in DELIVERABLES.items():
    if path.is_dir():
        state = f"{len(list(path.glob('*')))} file(s)"
    else:
        state = "present" if path.exists() else "missing"
    print(f"  {name:<13} {state}")

defined_checks = [name for name in STAGE_CHECKS if name in globals()]
print(f"\\nstage checks defined in this kernel: {len(defined_checks)} of "
      f"{len(STAGE_CHECKS)}")
for name in STAGE_CHECKS:
    print(f"  {'yes' if name in defined_checks else 'no ':<4} {name}")

print("\\nreport sections")
if REPORT_PATH.exists():
    report_text = REPORT_PATH.read_text(encoding="utf-8")
    for heading in REPORT_SECTIONS:
        print(f"  {'found  ' if heading in report_text else 'MISSING'} {heading}")
    print(f"  {report_text.count('[FILL]')} '[FILL]' placeholder(s) remaining")
else:
    print(f"  no report at {REPORT_PATH} yet")
''')

nb.code('''
# "Every performance number in the report appears in a file under
# outputs/capstone/." That is checkable, so check it rather than believing it.
import re


def unsourced_numbers(report_path=REPORT_PATH,
                      evidence=(METRICS_PATH, MANIFEST_PATH)):
    """Numbers in the report that none of the evidence files contain.

    Deliberately crude: substring matching over the raw text, single digits
    ignored because they are section numbers and list markers. It cannot tell
    you a number is wrong. It can tell you a number came from nowhere.
    """
    if not report_path.exists():
        return None
    text = report_path.read_text(encoding="utf-8")
    have = "\\n".join(p.read_text(encoding="utf-8")
                     for p in evidence if p.exists())
    loose = [token for token in re.findall(r"\\d+(?:\\.\\d+)?", text)
             if not ("." not in token and float(token) < 10)
             and token not in have]
    return sorted(set(loose), key=float)


unsourced = unsourced_numbers()
if unsourced is None:
    print(f"no report at {REPORT_PATH} yet -- run this again when there is one")
else:
    print(f"{len(unsourced)} number(s) in REPORT.md that metrics.json and "
          f"manifest.jsonl do not contain:")
    for token in unsourced[:20]:
        print(f"  {token}")
    print()
    print("Some will be innocent: a year, a frame count, a resolution. The ones")
    print("that are not innocent are what rubric gate G1 is about -- a number in a")
    print("report with no file behind it.")
''')

nb.md("""
### Knowledge check

1. Your pipeline reports 9 attempted, 4 accepted, 5 "didn't work". What is the
   single most important thing missing from that sentence?
2. You measured peak VRAM at 11 GB during generation with Cosmos3-Nano, which
   documents 32 GB. What is the most likely explanation, and how would you check?
3. Why does the pipeline reason about every clip before generating any, rather
   than processing clip by clip? What does that ordering cost you?
4. Your predicted cost per accepted clip was 140 s and you measured 380 s. Name
   the two terms most likely to account for the gap, in order.
5. Your judge accepts 100% of generated clips. Give two very different
   explanations and say what would distinguish them.
6. Why is `variant_id` required to be stable across calls to `plan_variants`?
7. An OOM is classified `oom` and `retryable()` returns False. Why is that the
   right default, given that a retry sometimes does succeed?
8. You have 20 more minutes of GPU time. Do you generate more variants or more
   seeds of the variants you have? On what does it depend?

Question 6 has a demonstration attached. Run it before you open the answers.
""")

nb.code('''
# Question 6, as six lines you can run. Both of these produce a plausible id.
# Only one of them lets a resumed run recognise work you have already paid for.
import hashlib
import uuid


def stable_variant_id(clip_id, axis, axis_value, seed):
    """An id derived from the plan, so the same plan always yields the same id."""
    payload = f"{clip_id}|{axis}|{axis_value}|{seed}"
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()[:10]


example_plan = ("kitchen_01", "lighting", "overcast morning", BASE_SEED)

print("derived from the plan :", stable_variant_id(*example_plan),
      stable_variant_id(*example_plan))
print("uuid4                 :", uuid.uuid4().hex[:10], uuid.uuid4().hex[:10])
print()
print("The second line differs every call, and differs again after a kernel")
print("restart. A ledger keyed on it matches nothing on resume, so the pipeline")
print("regenerates everything you already paid for -- silently, and looking")
print("exactly like a normal run.")
''')

nb.answer("""
1. **Which of the five were rejections and which were failures.** A rejection is
   the policy working — it is evidence your threshold is doing something. A
   failure is the pipeline broken. They have different fixes and they belong in
   different rows of the report. Merging them is the most common way to lose
   marks on this capstone.

2. Almost certainly that you measured **this kernel's allocator** rather than the
   device. Generation runs in a `torchrun` subprocess, so
   `torch.cuda.max_memory_allocated()` here sees essentially nothing that matters.
   Check with `cc.DeviceSampler` — or just have `nvidia-smi` open in another
   terminal while a generation runs, which is the version that convinces people.

3. Because the reasoner and the generator **cannot both hold the card**, so
   clip-by-clip would mean a NIM stop and start per clip, and on one GPU that is
   the most expensive thing in the pipeline. What it costs you: you cannot
   abandon a bad clip early, you hold all the scene records in memory (cheap),
   and a crash in the generate stage happens after you have paid for all the
   reasoning. The trade is worth it, and saying which way you traded is decision 4.

4. **Fixed overhead** first — process launches and, above all, NIM restarts,
   neither of which the unit cost model contains at all. Then the **acceptance
   rate**, which is in the denominator, so guessing 0.6 when the truth is 0.4
   inflates the real cost by half again. If both are accounted for and a gap
   remains, look at the judge's latency, which people routinely forget is GPU
   time too.
""", summary="Answers 1–4")

nb.code('''
# Question 5 has arithmetic in it as well. If your judge has accepted n clips in
# a row and rejected none, the standard 95% upper bound on the true rejection
# rate is about 3/n -- the "rule of three". No measurement here, only the bound.
for n in (6, 9, 12, 24, 100):
    print(f"  {n:>3} accepted, 0 rejected -> the true rejection rate could still "
          f"be as high as {3 / n:.0%}")

print()
print("At the sample sizes this capstone produces, 'it accepted everything' is")
print("not evidence that the judge works. It is a sample too small to say either")
print("way, which is why you calibrate on footage whose answer you already know")
print("and why you spot-check by watching clips yourself.")
''')

nb.answer("""
5. Either **the threshold is too loose** — you are accepting anything with a
   confidence above a floor no output ever falls below — or **the generator is
   genuinely producing plausible clips** at this tier, which is not absurd for
   short, low-resolution, in-distribution variations. Distinguish them by
   screening something you know is bad: feed the judge a deliberately corrupted
   clip, or a variant with a physically impossible prompt. A judge that accepts
   that is not screening.

6. Because **the ledger is keyed on it**, and the ledger is the resume mechanism.
   An id derived from `uuid4()` changes on every call, so a resumed run matches
   nothing in the manifest and regenerates everything you already paid for —
   silently, and looking exactly like a normal run.

7. Because the **common case is that a retry fails identically**, having first
   cost you a full checkpoint load. The times a retry succeeds are the times
   something *else* freed memory in the interim, which is luck rather than a
   strategy. The right response to an OOM is to change the job and then run it,
   and `retryable()` returning False is what forces that to be a decision you
   make rather than a loop you watch.

8. It depends on what you are going to claim. **More variants** if the claim is
   about coverage — you want your dataset to span the axes, and a second seed of
   an existing prompt adds nothing to coverage. **More seeds** if the claim is
   about the acceptance rate or about a comparison between two arms, because
   there the seed is the noise you are trying to average out. Lesson 18's
   version: buy prompts when the claim is about generalisation, buy seeds when
   the claim is about a difference.
""", summary="Answers 5–8")

nb.code('''
# "Cost per accepted clip has the acceptance rate in the denominator." That
# sentence is worth one line of arithmetic. The multipliers below are ratios,
# not timings -- the only timings in this notebook are the ones you measured.
for acceptance in (0.9, 0.7, 0.5, 0.3, 0.1):
    print(f"  {acceptance:>4.0%} accepted -> each accepted clip costs "
          f"{1 / acceptance:.1f} attempts")

print()
if METRICS_PATH.exists():
    measured_metrics = json.loads(METRICS_PATH.read_text())
    print(f"your measured acceptance rate      : "
          f"{measured_metrics.get('acceptance_rate')}")
    print(f"your GPU-seconds per accepted clip : "
          f"{measured_metrics.get('gpu_seconds_per_accepted')}")
else:
    print(f"no {METRICS_PATH.name} yet, so the ratios above are all there is.")
print()
print("Halving the acceptance rate doubles the cost of everything downstream,")
print("which is why a screening threshold is an economic decision as much as a")
print("quality one -- and why tightening it is not free.")
''')

nb.md("""
### Summary

- **The pipeline's stage order is a memory schedule**, not a data-flow diagram.
  Two models that cannot share one card force reason-all, then generate-all, then
  validate-all, and the switching between them is a cost you must measure rather
  than absorb.
- **Batching is the dominant lever at low resolution and almost irrelevant at
  high.** `Generator.run` takes a list; one load, N samples. The tradeoff is that
  a crash takes the batch, which is why it is a decision.
- **Screen cheap first, expensive second.** `cc.check_video` costs milliseconds
  and catches the failures not worth a model's opinion. The judge costs a NIM
  restart per batch and inference per clip.
- **Calibrate the judge on real footage before trusting it on generated
  footage.** A screen that rejects genuine video is measuring your prompt.
- **The judge is not independent of the generator.** Two towers, one checkpoint.
  Name it, mitigate what you can, and report your own disagreement rate.
- **Rejections and failures are different numbers.** One is your policy working;
  the other is your pipeline broken.
- **Cost per accepted clip has the acceptance rate in the denominator**, which
  is why a screening policy is an economic decision and not only a quality one.
- **A prediction is only a prediction if you wrote it down first.** Commit it to
  the ledger, then reconcile by naming the dominant error term.
- **Resume has to be designed in.** An append-only ledger keyed on a stable id,
  consulted before every unit of work, and there is no special resume code path
  at all.
- **An error class is a routing decision.** Retry a `service` failure after
  fixing the service, retry a `malformed` reply once, never retry an `oom`
  unchanged, and stop the run on a bug in your own code.
- **Producing screened clips is not evidence of downstream benefit.** Unless you
  trained on them and evaluated the result, say so plainly.
""")

nb.code('''
# The last bullet, made concrete. What did the run actually leave you?
print(f"manifest holds {len(manifest)} attempted variant(s)")
for status, count in manifest.counts("status").items():
    print(f"  {status:<10} {count}")

accepted_records = manifest.select(status="accepted")
if accepted_records:
    axes = sorted({str(record.get("axis")) for record in accepted_records})
    print(f"\\n{len(accepted_records)} accepted clip(s), varying: "
          f"{', '.join(axes)}")
    print("That set, converted to Lesson 16's JSONL format, is the input to a")
    print("fine-tune -- and until you run one, it is a dataset and not a result.")
else:
    print("\\nNothing accepted yet, so there is no dataset to hand to Lesson 16.")
    print("An empty accepted set is a finding too. It belongs in the report with")
    print("the reason, not on a list of things to fix later.")
''')

nb.md("""
### Common misconceptions

| Belief | Correction |
|---|---|
| "It exited zero, so it generated something" | The guardrail can reject a prompt, produce a blank frame and exit cleanly. `cc.verify_result` on every run, every time. |
| "More variants is a better dataset" | Ten near-duplicates are one clip with nine copies. Your diversity criterion exists precisely to make that measurable. |
| "The reasoner is an objective judge" | It shares a checkpoint with the generator. It is a useful screen and a biased one, and you have to say which failure modes it is likely to be blind to. |
| "Peak VRAM was fine — no OOM" | Absence of an OOM is not a measurement. On an 80 GB card a 79 GB peak has not succeeded, it has not failed yet. |
| "I'll add the profiling at the end" | Three of the six rubric criteria cannot be retrofitted, and the prediction cannot be committed retrospectively by anyone who wants to be believed. |
| "The pipeline crashed, so the run is lost" | Only if you did not design a ledger. With one, a crash costs the item in flight. |
| "A null result means the capstone failed" | A measured null with a stated detectable-effect size scores above a vague positive. That is written into the rubric. |
| "Reduced mode is a toy" | Reduced mode is the mode in which you find every bug. Full mode is where you find out how expensive those bugs would have been. |
""")

nb.code('''
# The last row of that table, in numbers. This is the unit model from Lesson 06
# and the tier table -- the size of the step you would be taking, not a timing.
totals = {}
for name, profile in PROFILES.items():
    tier_info = cc.MODEL_TIERS[profile["model"]]
    cost = cc.estimate_generation_cost(
        resolution=profile["resolution"], aspect_ratio=ASPECT,
        num_frames=profile["num_frames"], num_steps=profile["num_steps"],
        model=profile["model"])
    planned = profile["n_sources"] * profile["variants_per_source"]
    totals[name] = cost["cost_units"] * planned
    print(f"{name:<8} {profile['model']:<14} {profile['resolution']}p tier, "
          f"{profile['num_frames']} frames, {profile['num_steps']} steps")
    print(f"{'':<8} {planned} variants, {totals[name]:,} units of sampling, "
          f"{tier_info['download_gb']} GB checkpoint")

print()
print(f"Full mode is about {totals['full'] / totals['reduced']:.0f}x the sampling "
      f"of reduced mode.")
print("How long that takes is a question only your machine can answer, and stage 5")
print("is where you make it answer.")
''')

nb.md("""
### Suggested extensions

- **Close the loop for real.** Take your accepted clips into Lesson 16's JSONL
  format, fine-tune Edge on them in Lesson 17, and evaluate with Lesson 18's
  harness against the base model. That is the only way to turn "I produced
  screened synthetic data" into "the synthetic data did something", and it is
  the claim everybody wants to make and almost nobody measures.
- **Make the judge independent.** Serve a different model family as a second
  judge and measure the two judges' agreement. Where they disagree is where your
  screening is actually uncertain, and it is a much better place to spend your
  own attention than a random sample.
- **Cost the whole flywheel per useful training clip**, including the human
  minutes. If your accepted clips cost 4 GPU-minutes each and 30 seconds of
  someone watching them, which term would you attack first? The answer is
  usually not the one people optimise.
- **Try to break your own diversity criterion.** Write a deliberately degenerate
  variant planner that scores well on it and produces obvious rubbish. If you
  cannot, the criterion is better than you thought; if you can, you have found
  the paragraph that belongs in report §4.

### Mastery checklist

- [ ] I can state why the two models cannot both hold the card, with a number.
- [ ] All six stage contracts hold in a fresh kernel.
- [ ] My `variant_id`s are stable, and I proved it by killing and resuming.
- [ ] I calibrated the judge on real footage before screening anything with it.
- [ ] I can say which error my accept/reject threshold prefers to make, and why.
- [ ] My diversity criterion is computable, and I can describe how to game it.
- [ ] I measured peak VRAM device-wide, not from this kernel's allocator.
- [ ] I committed a cost prediction before the run and reconciled it afterwards.
- [ ] I named the bottleneck stage with a measured number attached.
- [ ] I know what fraction of my run was spent restarting a container.
- [ ] All four failure classes are handled, and none of them is retried wrongly.
- [ ] Rejections and failures are separate numbers in my manifest.
- [ ] I watched some clips myself and reported my disagreement with the judge.
- [ ] Every number in my report is in a file under `outputs/capstone/`.
- [ ] My report says at least four things the evidence does not support.

The cell below ticks the ones that read a file.
""")

nb.code('''
# The checkable half of the checklist above. Nothing here can tell whether you
# understood something; it can only tell whether the evidence exists.
metrics_now = json.loads(METRICS_PATH.read_text()) if METRICS_PATH.exists() else {}
status_counts = manifest.counts("status")

checkable = {
    "every stage check is defined in this kernel":
        all(name in globals() for name in STAGE_CHECKS),
    "a cost prediction is on record":
        prediction_log.has("prediction"),
    "the prediction has been reconciled against a measurement":
        metrics_now.get("prediction_ratio") is not None,
    "peak VRAM was recorded":
        metrics_now.get("peak_vram_gb") is not None,
    "a dominant stage is named":
        bool(metrics_now.get("dominant_stage")),
    "switching time is recorded as a share of the run":
        metrics_now.get("switch_fraction") is not None,
    "rejections and failures are separate numbers":
        len([s for s in ("accepted", "rejected", "failed") if s in status_counts]) > 1,
    "a diversity number exists":
        metrics_now.get("diversity") is not None,
    "the judge was calibrated":
        metrics_now.get("judge_calibration") is not None,
    "the report exists":
        REPORT_PATH.exists(),
}

for claim, done in checkable.items():
    print(f"  [{'x' if done else ' '}] {claim}")

print()
print(f"{sum(checkable.values())} of {len(checkable)} machine-checkable items.")
print("Whether you watched the clips, whether you can defend the threshold, and")
print("whether your report says something inconvenient are not on this list. They")
print("are the part a person reads, and the part the rubric weights hardest.")
''')

nb.md("""
---

**That is the course.** You can serve a reasoner and a generator on one H100
without them fighting, condition generation on images, control videos and
actions, measure any of it honestly, attempt a fine-tune on hardware nobody
documented it for, evaluate the result without a harness, and now assemble all of
it into a pipeline that survives contact with a long unattended run.

The last skill is the one that transfers furthest, and it is not about Cosmos:
**an artefact you produced is not evidence until you have measured it, screened
it, and written down what it does not show.**
""")

nb.md(FOOTER_MD)

# ---------------------------------------------------------------------------
# Build-time consistency gate.
#
# The counts in this notebook, in the reference, in CAPSTONE_RUBRIC.md and in
# CAPSTONE_REPORT_TEMPLATE.md drifted apart once already: the rubric named six
# checks where this file defines seven, and both said the report had seven
# sections where the template has eight. The two markdown files cannot import
# anything, so they are checked here, from the same constants the notebooks are
# built from.
# ---------------------------------------------------------------------------
_TEXT = "\n".join("".join(c["source"]) for c in nb.cells)
assert _TEXT.count("def check_stage_") == N_STAGE_CHECKS, (
    f"{_TEXT.count('def check_stage_')} check definitions, expected "
    f"{N_STAGE_CHECKS}")
assert f"all {N_SECTIONS_WORD} sections" in _TEXT, (
    f"the notebook does not say the report has {N_SECTIONS_WORD} sections")
assert "all seven sections" not in _TEXT, "stale seven-section claim"

_RUBRIC = (ROOT / "assets" / "reference" / "CAPSTONE_RUBRIC.md").read_text(
    encoding="utf-8")
_TEMPLATE = (ROOT / "assets" / "reference" /
             "CAPSTONE_REPORT_TEMPLATE.md").read_text(encoding="utf-8")
_problems = []
if f"`{STAGE_CHECK_NAMES[0]}()`" not in _RUBRIC:
    _problems.append(f"rubric never names {STAGE_CHECK_NAMES[0]}")
if f"all {N_SECTIONS_WORD} sections" not in _RUBRIC:
    _problems.append(f"rubric does not say {N_SECTIONS_WORD} report sections")
if "all seven sections" in _RUBRIC:
    _problems.append("rubric still claims seven report sections")
for _heading in REPORT_SECTION_HEADINGS:
    if _heading not in _TEMPLATE:
        _problems.append(f"template is missing {_heading!r}")
if _TEMPLATE.count("\n## ") != N_REPORT_SECTIONS:
    _problems.append(f"template has {_TEMPLATE.count(chr(10) + '## ')} top-level "
                     f"sections, expected {N_REPORT_SECTIONS}")
assert not _problems, "capstone artefacts disagree:\n  - " + "\n  - ".join(_problems)
print(f"  consistency: {N_STAGE_CHECKS} checks "
      f"({STAGE_CHECK_NAMES[0]}..{STAGE_CHECK_NAMES[-1]}), "
      f"{N_FOUNDATION_CHECKS} for Foundation, "
      f"{N_REPORT_SECTIONS} report sections — lesson, rubric and template agree")

nb.write(ROOT / "19_capstone_synthetic_data_flywheel.ipynb")

