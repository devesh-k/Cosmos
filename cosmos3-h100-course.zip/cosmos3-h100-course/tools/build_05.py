"""Build 05_reasoning_spatial.ipynb.

Derived from the source DLI course `S-OV-57-V1`, notebook 02, sections 4, 5 and
6 (cells 24-29): 2D grounding, "describe anything" via Set-of-Mark, and action
chain-of-thought trajectories. Prompts and assets are preserved. What is fixed:
the source's Set-of-Mark marks are pixel coordinates tuned to one 1280x720
asset, which silently mislocates every mark on any other image.

This lesson ends Module 1, so it also stops the NIM and gives the card back.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 05 — Spatial grounding")

nb.md("""
# Lesson 05 — Spatial grounding

**What you will build.** `outputs/05/` containing an annotated bounding-box
image, a Set-of-Mark image with region captions keyed to the marks you drew, an
overlaid gripper trajectory, and a written note on a grounding failure you
found.

| | |
|---|---|
| **Time** | ~90 minutes |
| **GPU** | 1 × H100 with the Reasoner NIM running. **This lesson stops it at the end.** |
| **Downloads** | None |
| **Prerequisites** | Lessons 02, 03 and 04. |

Lesson 03 asked *what*. Lesson 04 asked *what to do*. This one asks **where** —
and everything in Module 3 needs an answer to that, because an action without
coordinates is not an action.
""")

nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Request** a 2D bounding box, parse the JSON, and convert its coordinates to
   pixels at the correct scale.
2. **Explain** why the model emits coordinates on a 0–1000 grid, and predict what
   does and does not change when the image is resized.
3. **Diagnose** an overlay drawn in the wrong place, from the shape of the error
   back to the missing conversion.
4. **Build** a Set-of-Mark image programmatically and verify that each returned
   `subject_id` corresponds to the mark you drew.
5. **Elicit** a 2D end-effector trajectory as ordered waypoints and overlay it.
   (*End effector* is the robotics term for the business end of a robot arm —
   the gripper, hand or tool bolted to the last joint. It is the part that
   touches the world, so it is the part a plan is usually written about.)
6. **Parse** semi-structured model output robustly — fences, prose, and a
   preceding `<think>` block.
7. **Free** the GPU at the end of Module 1 and say why that is necessary.
""")

# --------------------------------------------- where you are
nb.md("""
## Where this sits in the module

The last three rows of Lesson 03's six-capability table are this lesson, and
finishing them finishes Module 1:

| Capability | What it answers | Why it matters for Physical AI | Covered in |
| --- | --- | --- | --- |
| Video captioning | *What is happening in this clip?* | Turns raw video into structured scene descriptions | Lesson 03 |
| Embodied reasoning | *What should the agent do next? What is the plan?* | Bridges perception to action | Lesson 04 |
| Common-sense reasoning | *Is this physically sensible?* | Grounds decisions in real-world physics | Lesson 04 |
| **2D grounding** | *Where exactly is object X?* | Localizes objects to interact with | **Lesson 05 — this one** |
| **Describe anything** | *Describe each marked region.* | Fine-grained, region-level understanding | **Lesson 05 — this one** |
| **Action chain-of-thought** | *What path should the gripper follow?* | Produces spatial plans for manipulation | **Lesson 05 — this one** |

These three are the ones with checkable answers. A caption can be graded only by
reading it; a bounding box can be graded by a program, and a trajectory can be
graded by whether it is monotone, smooth and inside the frame. That is why they
are last: everything you build here produces numbers, and numbers are what
Module 3 needs when it starts moving an arm.

They also build on each other in order. Grounding gives you boxes; the boxes give
you the marks that "describe anything" needs; and a trajectory is grounding
extended over time. Do them in the order they appear.

The full table, with the reasoning behind the ordering, is at the top of
`03_reasoning_captioning.ipynb`.
""")

# --------------------------------------------- foundation
nb.md("""
## Coordinates on a 0–1000 grid

Ask Cosmos 3 where something is and you get JSON like this:

```json
[{"bbox_2d": [412, 233, 588, 476], "label": "red bottle"}]
```

Four numbers, in the order `[x1, y1, x2, y2]` — left, top, right, bottom. Origin
at the **top left**, x increasing rightwards, y increasing downwards, which is
the image convention and the opposite of the maths convention on the y axis.

The numbers are **not pixels**. They are normalised to a fixed 0–1000 range,
**per axis and independently**: x is divided by the image width, y by the
height, and each is then scaled to 0–1000.

```
   pixel space (1280 x 720)              normalised space (1000 x 1000)
   +--------------------------+          +--------------------------+
   |                          |          |                          |
   |     +------+             |   ==>    |    +--------+            |
   |     | 176  |             |          |    |  137   |            |
   |     | x243 |             |          |    | x 337  |            |
   |     +------+             |          |    +--------+            |
   +--------------------------+          +--------------------------+
        x: /1280 *1000                        a square box in pixels is
        y: /720  *1000                        NOT square here
```

### Why normalise at all

Because the model does not know your image's dimensions and should not have to.
A vision encoder resizes and tiles its input before the transformer ever sees
it; whatever pixel grid you started with is gone by then. Emitting numbers in a
fixed, dimensionless range means the same output is meaningful for a 640×480
frame and a 4K still, and the client — which *does* know the dimensions —
multiplies back.

### The bug this creates

Someone will treat 0–1000 as pixels. On a 1280×720 image that draws every box
crammed into the top-left corner, at roughly 78% of the correct width and 139%
of the correct height. It looks *almost* plausible, which is why it survives
review. You will produce this deliberately in the debugging lab, because
recognising its distinctive shape is faster than re-deriving the arithmetic.
""")

nb.callout("gotcha", """
The per-axis normalisation is the part that catches people who already know
about normalised coordinates. Because x and y are divided by *different*
numbers, a box that is square in normalised space is not square in pixels
unless the image happens to be square. `cosmos_course.viz._denorm(value, extent)`
takes the extent as an argument for exactly this reason — there is no single
scale factor.
""")

# --------------------------------------------- environment
nb.md("""
## Environment
""")

nb.code('__lesson__ = "05"   # OUTPUT_DIR resolves to outputs/05\n\n' + SETUP_CELL)

nb.code('''
import json

from cosmos_course.nim import NimConfig, nim_status, print_status, stop_nim
from cosmos_course.models import Reasoner

NIM = NimConfig()
cc.require(
    nim_status(NIM)["ready"],
    f"The Cosmos 3 Reasoner NIM is not answering at {NIM.base_url}.",
    fix=(
        "Start it as you did in Lesson 02 (02_serving_the_reasoner.ipynb):\\n"
        "        from cosmos_course.nim import start_nim, NimConfig\\n"
        "        start_nim(NimConfig())\\n"
        "      If it was up earlier and is not now, read the logs first:\\n"
        "        from cosmos_course.nim import nim_logs; print(nim_logs())"
    ),
)

print_status(NIM)
reasoner = Reasoner(base_url=NIM.base_url)
print()
print(f"model: {reasoner.model}")
''')

nb.code('''
from PIL import Image as PILImage

def need_asset(name):
    try:
        return cc.asset(name)
    except FileNotFoundError as exc:
        raise RuntimeError(
            f"{exc}\\n  Fetch the cookbook:  python3 scripts/fetch_assets.py"
        ) from None

SCENE = need_asset("robot_planning")        # grounding target
WORKSPACE = need_asset("robot_workspace")   # robot_153.jpg, Set-of-Mark
TRAJECTORY_SCENE = need_asset("action_cot")  # action_cot_trajectory.png

for label, path in [("grounding", SCENE), ("workspace", WORKSPACE),
                    ("trajectory", TRAJECTORY_SCENE)]:
    with PILImage.open(path) as img:
        print(f"  {label:<12} {path.name:<28} {img.size[0]} x {img.size[1]}")
''')

# --------------------------------------------- 2D grounding
nb.md("""
## 2D grounding

The source course's prompt, unchanged. Note how little it specifies: it names
the object, asks for a box, and says "Return a json". The model supplies the key
names, which is why the overlay helper accepts `bbox_2d`, `bbox` **or** `box` —
it is not consistent about which it uses.
""")

nb.code('''
cc.show_image(SCENE, caption="robot_planning.png")

GROUNDING_PROMPT = "Locate the accurate bounding box of the cameras. Return a json."

grounding_raw = reasoner.ask(GROUNDING_PROMPT, images=SCENE,
                             max_tokens=2048, seed=0, temperature=0.0)
print(grounding_raw)
''')

nb.code('''
boxes = cc.parse_model_json(grounding_raw)
print(json.dumps(boxes, indent=2))
print()
print(f"objects returned : {len(boxes)}")
print(f"keys in the first: {sorted(boxes[0]) if boxes else '(none)'}")
''')

nb.md("""
### The conversion, written out once

`viz.draw_boxes` does this for you, but do it by hand once so the arithmetic is
yours rather than the library's.
""")

nb.code('''
def denorm_box(box, width, height):
    """[x1,y1,x2,y2] on the 0-1000 grid -> pixel coordinates.

    Note the two different divisors. x uses width, y uses height. There is no
    single scale factor, and assuming there is one is the most common bug here
    after treating the numbers as pixels outright.
    """
    x1, y1, x2, y2 = box
    return [
        x1 / 1000.0 * width,
        y1 / 1000.0 * height,
        x2 / 1000.0 * width,
        y2 / 1000.0 * height,
    ]

with PILImage.open(SCENE) as img:
    W, H = img.size

print(f"image: {W} x {H}\\n")
for obj in boxes:
    raw = obj.get("bbox_2d") or obj.get("bbox") or obj.get("box")
    if not raw or len(raw) != 4:
        continue
    px = denorm_box(raw, W, H)
    label = obj.get("label") or obj.get("name") or "(unlabelled)"
    print(f"  {label}")
    print(f"    normalised : {[round(v) for v in raw]}")
    print(f"    pixels     : {[round(v) for v in px]}")
    print(f"    size px    : {round(px[2] - px[0])} x {round(px[3] - px[1])}")
''')

nb.code('''
annotated = OUTPUT_DIR / "grounding_boxes.png"
cc.draw_boxes(SCENE, boxes, save_to=annotated)
print(f"saved {annotated}")
''')

nb.predict_run_explain(
    predict=(
        "Resize the image to half its width and half its height, and send the "
        "smaller copy with the identical prompt and seed. Predict the returned "
        "`bbox_2d` numbers. Will they (a) halve, (b) stay roughly the same, or "
        "(c) change unpredictably? Say why."
    ),
    change=(
        "Run the cell below. It resizes to 50%, re-grounds, and prints both "
        "sets of normalised coordinates side by side along with the pixel boxes "
        "each one maps to in its own image."
    ),
    explain=(
        "The normalised numbers should be close, because that is the entire "
        "point of normalising. Then explain the part that is more interesting: "
        "they will not be *identical*. The smaller image genuinely contains "
        "less information, the vision encoder tiles it differently, and the "
        "model's estimate shifts. Quantify the shift and decide whether it "
        "would matter for a grasp."
    ),
    hint=(
        "If the numbers halved, you have found a real and reportable finding: "
        "this server is returning pixels, not normalised coordinates, and every "
        "overlay in this lesson needs rethinking. Check the aspect ratio too — "
        "if x scales and y does not, something is normalising on one axis only."
    ),
)

nb.code('''
small = OUTPUT_DIR / "scene_half.png"
with PILImage.open(SCENE) as img:
    img.resize((img.width // 2, img.height // 2), PILImage.LANCZOS).save(small)

with PILImage.open(small) as img:
    sw, sh = img.size
print(f"original {W} x {H}   ->   resized {sw} x {sh}\\n")

small_raw = reasoner.ask(GROUNDING_PROMPT, images=small,
                         max_tokens=2048, seed=0, temperature=0.0)
small_boxes = cc.parse_model_json(small_raw)

print(f"{'label':<22}{'normalised (full)':>26}{'normalised (half)':>26}")
print("-" * 74)
for a, b in zip(boxes, small_boxes):
    ra = a.get("bbox_2d") or a.get("bbox") or a.get("box") or []
    rb = b.get("bbox_2d") or b.get("bbox") or b.get("box") or []
    label = str(a.get("label") or a.get("name") or "?")[:20]
    print(f"{label:<22}{str([round(v) for v in ra]):>26}{str([round(v) for v in rb]):>26}")
    if len(ra) == 4 and len(rb) == 4:
        drift = max(abs(x - y) for x, y in zip(ra, rb))
        print(f"{'':<22}{'max drift: ' + str(round(drift)) + ' /1000':>52}")
''')

nb.code('''
# Both overlays, side by side. If normalisation is working, the boxes land on
# the same objects in both images despite the images being different sizes.
half_annotated = OUTPUT_DIR / "grounding_boxes_half.png"
cc.draw_boxes(small, small_boxes, save_to=half_annotated, show=False)
cc.contact_sheet(
    [annotated, half_annotated],
    labels=[f"full {W}x{H}", f"half {sw}x{sh}"],
    width=380,
)
''')

# --------------------------------------------- debugging lab
nb.md("""
## Debugging lab: the overlay is in the wrong place

**Symptom.** The model's JSON looks entirely reasonable. The boxes draw without
error. And every one of them sits crushed into the upper-left corner of the
image, roughly the right shape but plainly not on the objects.

**Hypothesis.** Someone treated the 0–1000 numbers as pixels. It is worth being
precise about what that looks like, because the *shape* of the error identifies
the cause faster than reading the code:

- on a **1280×720** image, boxes appear at 1000/1280 ≈ **78%** of their correct
  x extent and 1000/720 ≈ **139%** of their correct y extent — so they are
  squashed horizontally and stretched vertically, and clipped at the bottom;
- on a **512×512** image, most boxes land partly or wholly off the right and
  bottom edges, so you see fragments or nothing;
- on a **1000×1000** image it is *correct*, which is how this bug reaches
  production.

Produce it.
""")

nb.code('''
from PIL import ImageDraw

def draw_boxes_wrong(image_path, objects, save_to=None):
    """DELIBERATELY WRONG. Treats 0-1000 coordinates as pixel coordinates.

    Kept in the lesson because recognising the output is worth more than
    re-deriving the arithmetic. Do not copy this.
    """
    img = PILImage.open(image_path).convert("RGB")
    draw = ImageDraw.Draw(img)
    for obj in objects:
        box = obj.get("bbox_2d") or obj.get("bbox") or obj.get("box")
        if not box or len(box) != 4:
            continue
        draw.rectangle(list(box), outline=(230, 25, 75), width=4)   # <- the bug
    if save_to:
        Path(save_to).parent.mkdir(parents=True, exist_ok=True)
        img.save(save_to)
    return img

wrong = OUTPUT_DIR / "grounding_WRONG.png"
draw_boxes_wrong(SCENE, boxes, save_to=wrong)
cc.contact_sheet([wrong, annotated], labels=["WRONG: 0-1000 read as pixels",
                                             "correct: scaled to pixels"], width=380)
''', tags=["teaching-antipattern"])

nb.md("""
**Diagnostic step.** Do not squint at the picture — do the arithmetic. Two
questions settle it:

1. Is every returned coordinate ≤ 1000, on an image wider than 1000 pixels? Then
   they are normalised and something downstream is not converting.
2. Does the ratio of drawn-box width to image width equal the ratio of the raw
   number to 1000? Then the drawing code used the raw number directly.

The cell below answers both mechanically. This is the check to put in a test.
""")

nb.code('''
def diagnose_overlay(objects, width, height):
    """Are these coordinates normalised, pixel, or something else?"""
    values = []
    for obj in objects:
        box = obj.get("bbox_2d") or obj.get("bbox") or obj.get("box")
        if box and len(box) == 4:
            values.extend(box)
    if not values:
        return {"verdict": "no boxes found"}

    largest = max(values)
    report = {
        "n_boxes": len(values) // 4,
        "max_coordinate": largest,
        "image_w": width,
        "image_h": height,
    }
    if largest <= 1000 and max(width, height) > 1000:
        report["verdict"] = (
            "NORMALISED (0-1000). Multiply x by width/1000 and y by height/1000 "
            "before drawing."
        )
    elif largest > 1000:
        report["verdict"] = (
            "PIXELS, or a different normalisation range. Do NOT divide by 1000."
        )
    else:
        report["verdict"] = (
            "AMBIGUOUS — the image is small enough that both readings fit. Test "
            "on a larger image, or check whether the boxes land on the objects."
        )
    return report

print(json.dumps(diagnose_overlay(boxes, W, H), indent=2))
''')

nb.md("""
**Repair.** Divide by 1000 and multiply by the extent **of the matching axis**.
That is what `viz._denorm(value, extent)` does, and why it takes the extent as
an argument instead of assuming one.

**Verification.** Not "it looks better". Two checks that a program can run:

1. every drawn box lies inside the image bounds;
2. the box centres land on distinguishably different image content — a set of
   boxes all in the corner would pass check 1 happily.

The second is the one that catches the bug, and it needs no ground truth.
""")

nb.code('''
def verify_overlay(objects, width, height):
    """Structural verification that boxes are plausibly placed."""
    problems = []
    centres = []
    for i, obj in enumerate(objects):
        box = obj.get("bbox_2d") or obj.get("bbox") or obj.get("box")
        if not box or len(box) != 4:
            problems.append(f"object {i} has no usable box")
            continue
        x1, y1, x2, y2 = denorm_box(box, width, height)
        if x2 <= x1 or y2 <= y1:
            problems.append(f"object {i} has a degenerate box (x2<=x1 or y2<=y1)")
        if not (0 <= x1 < x2 <= width and 0 <= y1 < y2 <= height):
            problems.append(f"object {i} falls outside the {width}x{height} image")
        centres.append(((x1 + x2) / 2, (y1 + y2) / 2))

    # Are they all bunched in one corner? Spread relative to image size.
    if len(centres) > 1:
        spread_x = (max(c[0] for c in centres) - min(c[0] for c in centres)) / width
        spread_y = (max(c[1] for c in centres) - min(c[1] for c in centres)) / height
        if max(spread_x, spread_y) < 0.05:
            problems.append(
                f"all {len(centres)} centres sit within 5% of each other "
                f"(spread {spread_x:.2%} x {spread_y:.2%}) — the signature of a "
                f"scaling bug, or of the model returning the same box repeatedly"
            )
    return problems

print("A. correctly scaled boxes:")
for p in verify_overlay(boxes, W, H) or ["(no problems)"]:
    print(f"     {p}")

# B. Express what the buggy code actually painted, so the same verifier can
#    judge it. The bug drew the raw 0-1000 numbers straight into pixel space,
#    so the rectangle it produced corresponds to the normalised box
#    (raw_x * 1000 / W, raw_y * 1000 / H).
def as_drawn_by_the_bug(objects, width, height):
    out = []
    for obj in objects:
        raw = obj.get("bbox_2d") or obj.get("bbox") or obj.get("box")
        if not raw or len(raw) != 4:
            continue
        x1, y1, x2, y2 = raw
        out.append({"bbox_2d": [x1 * 1000 / width, y1 * 1000 / height,
                                x2 * 1000 / width, y2 * 1000 / height]})
    return out

print()
print("B. what the buggy overlay actually painted:")
for p in verify_overlay(as_drawn_by_the_bug(boxes, W, H), W, H) or [
        "(no problems — this image is close enough to 1000x1000 that the bug "
        "hides; try it on a wider one)"]:
    print(f"     {p}")
''')

# --------------------------------------------- Set of Mark
nb.md("""
## Set-of-Mark prompting

Grounding asks the model *where is X*. **Set-of-Mark** inverts it: you draw
numbered regions on the image yourself, then ask the model to describe *each
marked subject*. The `subject_id` in its reply refers back to your number.

Why bother, when you could just ask about "the robot arm on the left"? Because
a referring expression is ambiguous and a number is not. With two arms in frame,
"the left arm" depends on whose left; "region 1" does not. Marking makes the
output **addressable**: every caption is bound to a region whose coordinates you
already have, so you can join the model's description to your own data.

In a full pipeline the regions come from a segmentation model such as SAM. Here
you place them by hand, which keeps the numbering stable and the experiment
reproducible.
""")

nb.callout("upstream", """
The source course hard-coded these marks as **pixel** boxes tuned to
`robot_153.jpg` at 1280×720. That works for exactly one file. Point the same
code at any other image and every mark lands somewhere wrong — silently, because
a rectangle drawn in the wrong place still draws.

`viz.mark_subjects` therefore takes a `normalized` flag, and when
`normalized=False` it *asserts* that the boxes fall inside the image rather than
drawing nonsense. Below, the source's pixel boxes are converted once to the
0–1000 grid so they follow the image at any size — the same conversion you just
did for the model's output, in the opposite direction.
""")

nb.code('''
# The source course's marks, as pixel boxes on a 1280x720 asset.
SOURCE_W, SOURCE_H = 1280, 720
SOURCE_MARKS = [
    {"id": 1, "bbox": [300, 430, 480, 700], "note": "left robotic arm / gripper"},
    {"id": 2, "bbox": [820, 420, 990, 700], "note": "right robotic arm"},
    {"id": 3, "bbox": [895, 35, 1010, 120], "note": "red object on the desk"},
    {"id": 4, "bbox": [270, 0, 465, 215], "note": "person standing"},
]

def to_normalized(box, width, height):
    """Pixel box on a known canvas -> the 0-1000 grid. The inverse of denorm_box."""
    x1, y1, x2, y2 = box
    return [x1 / width * 1000, y1 / height * 1000,
            x2 / width * 1000, y2 / height * 1000]

MARKS = [
    {"id": m["id"], "bbox": to_normalized(m["bbox"], SOURCE_W, SOURCE_H), "note": m["note"]}
    for m in SOURCE_MARKS
]

with PILImage.open(WORKSPACE) as img:
    ww, wh = img.size

matches = (ww, wh) == (SOURCE_W, SOURCE_H)
print(f"asset is {ww} x {wh}; the source assumed {SOURCE_W} x {SOURCE_H}")
print("they match" if matches else "they DO NOT match — the raw pixel boxes "
                                   "would have landed in the wrong places")
print()
for m in MARKS:
    print(f"  {m['id']}  {[round(v) for v in m['bbox']]}   {m['note']}")
''')

nb.code('''
marked = cc.mark_subjects(WORKSPACE, MARKS, OUTPUT_DIR / "workspace_marked.png",
                          normalized=True)
cc.show_image(marked, caption="Set-of-Mark: four numbered regions drawn by us")
''')

nb.code('''
# The source course's describe-anything prompt, unchanged.
SOM_PROMPT = ('Please caption the notable attributes in the provided image. List and '
              'describe all marked subjects in the image with their categories and '
              'detailed captions using a json with keyword "subject_id", "category" '
              'and "caption".')

som_raw = reasoner.ask(SOM_PROMPT, images=marked, max_tokens=4096,
                       seed=0, temperature=0.0)
regions = reasoner.parse_json(som_raw)
print(json.dumps(regions, indent=2)[:2500])
''')

nb.md("""
### Verify the keying, do not assume it

The whole value of Set-of-Mark is that `subject_id` refers to *your* number. If
the model returns four captions numbered 1–4 in a different order from your
marks, or invents a fifth region, the binding is broken and every downstream
join is silently wrong.

Check it. This is the cell that makes Set-of-Mark trustworthy rather than
decorative.
""")

nb.code('''
def check_som_keying(regions, marks):
    """Do the returned subject_ids correspond exactly to the marks we drew?"""
    drawn = {m["id"] for m in marks}
    returned = []
    for r in regions:
        if isinstance(r, dict) and r.get("subject_id") is not None:
            try:
                returned.append(int(r["subject_id"]))
            except (TypeError, ValueError):
                returned.append(r["subject_id"])
    problems = []
    missing = drawn - set(returned)
    invented = [r for r in returned if r not in drawn]
    duplicated = [r for r in set(returned) if returned.count(r) > 1]
    if missing:
        problems.append(f"marks with no caption: {sorted(missing)}")
    if invented:
        problems.append(f"subject_ids that were never drawn: {invented}")
    if duplicated:
        problems.append(f"subject_ids captioned more than once: {duplicated}")
    return problems, returned

problems, returned_ids = check_som_keying(regions, MARKS)
print(f"drawn    : {sorted(m['id'] for m in MARKS)}")
print(f"returned : {returned_ids}")
print()
if problems:
    for p in problems:
        print(f"  PROBLEM: {p}")
else:
    print("  keying is exact — every mark got exactly one caption")
''')

nb.code('''
# Join the captions back to the regions we drew, which is the point of the exercise.
by_id = {}
for r in regions:
    if isinstance(r, dict) and r.get("subject_id") is not None:
        try:
            by_id[int(r["subject_id"])] = r
        except (TypeError, ValueError):
            continue

for m in MARKS:
    r = by_id.get(m["id"])
    print(f"[{m['id']}] we marked: {m['note']}")
    if r:
        print(f"     category : {r.get('category')}")
        print(f"     caption  : {str(r.get('caption'))[:200]}")
    else:
        print("     (no caption returned for this mark)")
    print()

som_json = OUTPUT_DIR / "region_captions.json"
som_json.write_text(json.dumps(
    {"marks": MARKS, "regions": regions, "keying_problems": problems}, indent=2))
print(f"wrote {som_json}")
''')

# --------------------------------------------- action CoT
nb.md("""
## Action chain-of-thought: a trajectory

Beyond *what* to do and *where* things are: **how to move**. Given a
manipulation task, the model plans the 2D path the **end effector** — the
gripper, hand or tool at the tip of the robot arm, the part that actually
touches the world — should follow in pixel space, and returns ordered waypoints.

Same 0–1000 grid, different key: `{"point_2d": [x, y], "label": "..."}`.

`viz.draw_trajectory` numbers each waypoint and ramps the colour from green at
the start to red at the end, so the direction is legible without reading the
numbers. That matters more than it sounds: a path that looks wrong is often a
right path traversed backwards, and you cannot tell from an undirected line.

This is the source course's prompt and its sampling settings, unchanged —
including `temperature=0.6`, which is a deliberate departure from the
`temperature=0` used everywhere else in this module.

The call below also passes `top_k`, `repetition_penalty` and `presence_penalty`.
All six sampling parameters are defined in the reference table in **Lesson 03,
"Determinism: why the same request gives different answers"** — go back and read
it now if those three are unfamiliar, because the sweep later in this lesson
holds them fixed while it varies only `temperature`, and that argument only
works if you know what is being held fixed.
""")

nb.code('''
cc.show_image(TRAJECTORY_SCENE, caption="action_cot_trajectory.png")

TRAJECTORY_PROMPT = """You are given the task "Move the pink bowl to the right". Specify the 2D trajectory your end effector should follow in pixel space. Return the trajectory coordinates in JSON format like this: {"point_2d": [x, y], "label": "gripper trajectory"}.
Answer the question using the following format:

<think>
Your reasoning.
</think>

Write your final answer immediately after the </think> tag."""

traj_raw = reasoner.ask(TRAJECTORY_PROMPT, images=TRAJECTORY_SCENE, max_tokens=4096,
                        temperature=0.6, top_p=0.95, top_k=20,
                        repetition_penalty=1.0, presence_penalty=0.0)
print(traj_raw[:2000])
''')

nb.md("""
### Robust parsing

That response contains a `<think>` block, and the reasoning inside it very often
contains a **draft** of the JSON. Parsing the first JSON blob in the raw text
would give you the draft — plausible, wrong, and no error raised.

`Reasoner.parse_json(text, after_think=True)` splits on `</think>` first.
`viz.parse_model_json` does the same by default. Three other things they handle:

| The model wrote | What defeats a naive parse |
|---|---|
| ```` ```json ... ``` ```` | `json.loads` chokes on the fence |
| `Here is the trajectory: [...]` | prose before the value |
| `[...] Let me know if you need more.` | prose after the value |

And one subtlety worth knowing: the extractor scans for the first *balanced*
bracket pair rather than using a greedy `\\[.*\\]` regex. Given
`[1,2] and then [3,4]`, the greedy version returns the whole span including the
prose between them.
""")

nb.code('''
from cosmos_course.models import split_think

reasoning, answer_part = split_think(traj_raw)
print(f"reasoning : {len(reasoning)} chars")
print(f"answer    : {len(answer_part)} chars")
print()

def try_parse(text, *, after_think):
    """Parse, and report a failure as a value instead of an exception."""
    try:
        return cc.parse_model_json(text, after_think=after_think), None
    except ValueError as exc:
        return None, str(exc).splitlines()[0]

naive, naive_error = try_parse(traj_raw, after_think=False)
correct, correct_error = try_parse(traj_raw, after_think=True)

print(f"parsing the WHOLE response : "
      f"{len(naive) if naive is not None else 'FAILED — ' + str(naive_error)}")
print(f"splitting on </think> first : "
      f"{len(correct) if correct is not None else 'FAILED — ' + str(correct_error)}")
print()
if naive is None:
    print("The naive parse failed outright. That is the good case: a loud")
    print("failure beats a quiet wrong answer.")
elif correct is not None and len(naive) != len(correct):
    print("Different, and both parsed. The reasoning block contained a draft,")
    print("and taking it would have given you a plausible wrong trajectory")
    print("with no error anywhere.")
else:
    print("Same this time. That is luck, not safety — the draft is not always")
    print("present, and a parser that only works when it is absent is a bug")
    print("waiting for a different seed.")

if correct is None:
    raise RuntimeError(
        "the trajectory response did not contain parseable JSON after "
        "</think>. Print traj_raw and look at what the model actually wrote; "
        "the usual fix is to name the exact keys in the prompt."
    )
waypoints = correct
''')

nb.code('''
traj_png = OUTPUT_DIR / "trajectory.png"
cc.draw_trajectory(TRAJECTORY_SCENE, waypoints, save_to=traj_png)

pts = [w["point_2d"] for w in waypoints if isinstance(w, dict) and w.get("point_2d")]
print(f"{len(pts)} waypoints")
for i, (x, y) in enumerate(pts):
    print(f"  {i:>2}  normalised ({x:>4}, {y:>4})")
''')

nb.predict_run_explain(
    predict=(
        "The source course used `temperature=0.6` for this task and said it "
        "encourages 'a smooth, exploratory path'. Predict what actually happens "
        "as temperature rises from 0.0 to 1.2: (a) does the number of waypoints "
        "go up, down, or stay flat; (b) do the paths get smoother or less "
        "smooth; (c) at what point, if any, does the JSON stop parsing?"
    ),
    change=(
        "Run the sweep below. It requests the same trajectory at five "
        "temperatures, records parse failures, waypoint counts and a simple "
        "smoothness measure, and overlays every path that parsed."
    ),
    explain=(
        "Define smoothness before you interpret the numbers — the cell uses "
        "mean turning angle between consecutive segments, where lower is "
        "straighter. Then say whether the source's claim held on your machine. "
        "If it did not, that is the more interesting result, and it is exactly "
        "the kind of assertion this course refuses to inherit unmeasured."
    ),
    hint=(
        "There are two separate things temperature can do here and they are "
        "easy to conflate: it changes the *path* the model proposes, and it "
        "changes the *reliability of the output format*. A rise in parse "
        "failures is not a statement about trajectory quality."
    ),
)

nb.code('''
import math

def turning(points):
    """Mean absolute turning angle in degrees between consecutive segments.

    Lower is straighter. Undefined for fewer than three points, which is
    itself worth reporting rather than papering over.
    """
    if len(points) < 3:
        return None
    angles = []
    for a, b, c in zip(points, points[1:], points[2:]):
        v1 = (b[0] - a[0], b[1] - a[1])
        v2 = (c[0] - b[0], c[1] - b[1])
        n1 = math.hypot(*v1)
        n2 = math.hypot(*v2)
        if n1 == 0 or n2 == 0:
            continue
        cosine = max(-1.0, min(1.0, (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2)))
        angles.append(math.degrees(math.acos(cosine)))
    return round(sum(angles) / len(angles), 1) if angles else None

# Sanity-check the metric on paths whose answer you already know, before using
# it to judge anything the model produced.
print(f"straight line   -> {turning([[0, 0], [10, 0], [20, 0]])} deg")
print(f"right-angle turn-> {turning([[0, 0], [10, 0], [10, 10]])} deg")
print(f"two points only -> {turning([[0, 0], [10, 0]])}  (undefined, and that is reportable)")
''')

nb.code('''
TEMPERATURES = (0.0, 0.3, 0.6, 0.9, 1.2)
sweep = {}

for temp in TEMPERATURES:
    # Everything except temperature is held at the source course's settings,
    # including the seed, so the only thing varying is the one thing named.
    text = reasoner.ask(
        TRAJECTORY_PROMPT, images=TRAJECTORY_SCENE, max_tokens=4096,
        temperature=temp, top_p=0.95, top_k=20, repetition_penalty=1.0, seed=0,
    )
    try:
        parsed = cc.parse_model_json(text, after_think=True)
        points = [w["point_2d"] for w in parsed
                  if isinstance(w, dict) and isinstance(w.get("point_2d"), (list, tuple))]
        sweep[temp] = {"ok": True, "n": len(points), "points": points,
                       "turning_deg": turning(points), "raw": text}
    except ValueError as exc:
        sweep[temp] = {"ok": False, "n": 0, "points": [], "turning_deg": None,
                       "error": str(exc)[:120], "raw": text}
    print(f"  temperature={temp}: {'parsed' if sweep[temp]['ok'] else 'PARSE FAILED'}")

print()
print(f"{'temp':>6}{'parsed':>9}{'waypoints':>11}{'mean turn deg':>15}")
print("-" * 41)
for temp, row in sweep.items():
    print(f"{temp:>6}{str(row['ok']):>9}{row['n']:>11}{str(row['turning_deg']):>15}")
''')

nb.code('''
overlays, labels = [], []
for temp, row in sweep.items():
    if not row["ok"] or not row["points"]:
        continue
    out = OUTPUT_DIR / f"trajectory_t{str(temp).replace('.', '')}.png"
    cc.draw_trajectory(TRAJECTORY_SCENE,
                       [{"point_2d": p} for p in row["points"]],
                       save_to=out, show=False)
    overlays.append(out)
    labels.append(f"T={temp}  n={row['n']}  turn={row['turning_deg']}")

if overlays:
    cc.contact_sheet(overlays, labels=labels, width=300, cols=3)
else:
    print("nothing parsed at any temperature — report that, and look at sweep[t]['raw']")
''')

nb.md("""
### Read the paths, not only the table

A trajectory can have a low turning angle and still be useless: a straight line
from one corner to the other is perfectly smooth and does not touch the bowl.
Smoothness is a *property*, not a *score*.

Ask the harder question of each overlay: does the path start at or near the
gripper, pass through the object, and end where the task said to put it? That is
three checks, and none of them is smoothness. The challenge exercise makes them
explicit.
""")

nb.callout("note", """
This is a **pixel-space** plan, not a metric action. It says where the gripper
should appear to be in this camera's image, in normalised image coordinates. It
says nothing about depth, nothing about gripper orientation, nothing in metres.

Lesson 12's `wam` mode predicts a very different object: a 10-dimensional action
in the robot's own frame — three translation deltas in metres, a **6-D
rotation**, one gripper channel.

*Forward reference; take it on trust.* A 6-D rotation (`rot6d`) writes an
orientation as six numbers rather than three: the first two columns of a 3×3
rotation matrix, from which the third follows. **Lesson 10 explains why** —
three-number representations are discontinuous, which makes them bad things for a
network to predict — and **Lesson 12 lays out all ten channels**.

Both objects are called trajectories and they are not the same thing. Converting
between them needs camera intrinsics, extrinsics and a depth estimate, none of
which is in this JSON.
""")

# --------------------------------------------- exercises
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "Ground three objects and score them with IoU",
    goal=(
        "Put a number on grounding quality instead of an impression, by "
        "comparing the model's boxes against boxes you drew yourself."
    ),
    instructions=(
        "1. Choose three named objects in `robot_planning.png` that you can "
        "point at unambiguously.\n"
        "2. Draw your own box for each, by eye, in **pixel** coordinates, then "
        "convert them to the 0–1000 grid with `to_normalized`. Record how you "
        "decided the edges — tight to the visible extent, or including "
        "occluded parts? Say which, because it changes every number that "
        "follows.\n"
        "3. Ground each object with the model, one request per object.\n"
        "4. Implement `iou(box_a, box_b)` — intersection over union — and score "
        "each pair.\n"
        "5. Report the three scores and say which object was hardest. Then "
        "answer: is a low score a model failure, or a disagreement about where "
        "the object ends?"
    ),
    success=(
        "Three IoU scores, a stated convention for your own boxes, and a "
        "written judgement on whether the worst score is a grounding failure or "
        "an annotation disagreement."
    ),
    starter='''
MY_BOXES = {
    # "object name": [x1, y1, x2, y2] in PIXELS on robot_planning.png
}

def iou(a, b):
    """Intersection over union of two [x1, y1, x2, y2] boxes in the same space."""
    raise NotImplementedError
''',
    hints=[
        "IoU: intersection width is `max(0, min(ax2,bx2) - max(ax1,bx1))`, "
        "same for height; union is `area_a + area_b - intersection`. The "
        "`max(0, ...)` is what makes non-overlapping boxes score 0 instead of "
        "a negative number.",
        "Compare in one consistent space. Normalised is easier because IoU is "
        "scale-invariant anyway — but only if you converted *both* boxes, and "
        "mixing one normalised box with one pixel box gives you a number that "
        "looks like a score and is not.",
    ],
    solution_ref="solutions/05_solutions.ipynb",
)

nb.exercise(
    "applied",
    "Grounding into Set-of-Mark, automatically",
    goal=(
        "Close the loop: take boxes the model produced, feed them back as marks, "
        "and get region-keyed descriptions — with no hand-placed coordinates "
        "anywhere."
    ),
    instructions=(
        "1. Write `ground_all(objects, image)` that grounds a list of object "
        "names and returns marks in `mark_subjects` format, assigning stable ids.\n"
        "2. Feed those marks to `cc.mark_subjects(..., normalized=True)`.\n"
        "3. Ask for region captions with the Set-of-Mark prompt, and run "
        "`check_som_keying` on the result.\n"
        "4. **Then do the check that matters.** Compare each returned caption "
        "against the object name you originally grounded. If you grounded "
        "'red bottle' as region 2 and region 2 comes back captioned as a "
        "microwave, the pipeline is broken somewhere and the keying check will "
        "not have noticed.\n"
        "5. Report the round-trip agreement rate, and investigate one "
        "disagreement far enough to say whether the grounding or the captioning "
        "was at fault."
    ),
    success=(
        "The pipeline runs end to end with no hand-placed coordinates, keying "
        "is verified, and you have a round-trip agreement rate with at least "
        "one disagreement traced to a specific stage."
    ),
    starter='''
TARGETS = ["the robot arm", "the red bottle", "the flower", "the camera"]

def ground_all(objects, image):
    """Ground each name; return marks [{'id': n, 'bbox': [...0-1000...]}]."""
    raise NotImplementedError
''',
    hints=[
        "Grounding one object per request is more reliable than asking for all "
        "four at once, and it makes attribution easy — you know which request "
        "produced which box. It costs four requests instead of one; measure "
        "whether that matters before optimising it away.",
        "Handle the object that is not there. If the model returns no box, or "
        "a box covering the whole image, that mark should not be drawn — an "
        "id that exists in your list and not on the image breaks the keying "
        "check in a way that looks like a model failure.",
    ],
    solution_ref="solutions/05_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "An end-to-end pick-target selector",
    goal=(
        "Build the thing Module 1 has been assembling: given a scene and a "
        "stated task, choose which object to pick, plan the approach, and "
        "evaluate the whole pipeline across several scenes with a written "
        "failure analysis."
    ),
    instructions=(
        "1. **Ground** candidate objects in a scene (Lesson 05) and reject any "
        "that fail `verify_overlay`.\n"
        "2. **Choose.** Given a task string, ask the model to select exactly one "
        "candidate *by its mark id* and justify the choice in one sentence. "
        "Asking for an id rather than a name is what makes the answer "
        "checkable.\n"
        "3. **Plan.** Request a gripper trajectory to the chosen object and "
        "overlay it.\n"
        "4. **Score it automatically.** At minimum: does the final waypoint fall "
        "inside the chosen object's box; is the path monotonic towards it; are "
        "all waypoints inside the image. Define each check before you look at "
        "any output.\n"
        "5. **Evaluate** on at least four scenes — `robot_planning`, "
        "`grounding_2d`, `robot_workspace`, `action_cot` — with at least two "
        "tasks each.\n"
        "6. **Write `outputs/05/pick_selector_report.md`.** Per-stage success "
        "rates, and a failure analysis that attributes every failure to a "
        "stage: grounding, selection, or planning. State which stage is your "
        "bottleneck and what you would fix first.\n"
        "7. Include at least one case where an earlier stage succeeded and a "
        "later one failed *because of* the earlier output — a plausible box in "
        "the wrong place is the usual culprit."
    ),
    success=(
        "The report has per-stage rates over at least eight scene/task pairs, "
        "every failure is attributed to a stage, and there is at least one "
        "documented cascading failure with its cause identified."
    ),
    starter='''
SCENES = {
    "robot_planning": ["pick up the flower", "hand the bottle to the person"],
    # ... at least three more scenes, two tasks each
}

def pick_target(image, task, candidates):
    """Ground -> select by id -> plan a trajectory. Return every intermediate."""
    raise NotImplementedError

def score_pick(result, image):
    """Automatic checks. Define them before looking at any output."""
    raise NotImplementedError
''',
    hints=[
        "Selecting by mark id rather than by name is the design decision that "
        "makes this evaluable. A name has to be matched fuzzily against your "
        "candidate list; an integer either is in the list or is not.",
        "The final-waypoint-inside-the-box check is the single most informative "
        "one, and it fails in two very different ways: the trajectory is wrong, "
        "or the box was wrong and the trajectory was right. Log both boxes and "
        "waypoints so you can tell them apart afterwards.",
        "Attributing cascading failures is the actual content of step 7. If "
        "grounding put 'red bottle' on the flower, then selection picked the "
        "right id for the wrong object and planning drew a perfect path to the "
        "wrong place. Every stage reports success. Only the joined record shows "
        "the failure.",
    ],
    solution_ref="solutions/05_solutions.ipynb",
)

# --------------------------------------------- assessment
nb.md("""
## Assessment and reflection

### Knowledge check

1. A box comes back as `[100, 200, 300, 400]` on a 1920×1080 image. What are the
   pixel coordinates, and which two divisors did you use?
2. Why normalise at all, given the client always knows the image size?
3. You resized an image and the returned coordinates barely moved. Why did they
   move at all?
4. Draw, in words, what a 0–1000-as-pixels bug looks like on a 1280×720 image.
   On what image size would it look correct?
5. Every box is inside the image and none is degenerate, and the overlay is
   still wrong. Give a check that would catch it.
6. What does Set-of-Mark buy you over a referring expression? Give a case where
   the referring expression is genuinely ambiguous and the mark is not.
7. Why does `parse_json(after_think=True)` matter for the trajectory task
   specifically?
8. You want to hand the pixel-space trajectory you produced today to a real robot
   arm. Name three pieces of information it does not contain, and for each say
   what you would have to obtain to supply it. *(Answerable from this lesson
   alone; `wam` actions are Lesson 12 and are not being assessed.)*

### Practical completion test

1. Ground an object and draw it at the correct scale.
2. Show the same box drawn wrongly and say what the shape of the error tells you.
3. Build a Set-of-Mark image and verify the keying automatically.
4. Elicit a trajectory and overlay it with the waypoints numbered.
5. Parse a response containing both a `<think>` draft and a final answer, and
   show you got the final one.
""")

nb.code('''
def self_test():
    passed = []

    for name in ("grounding_boxes.png", "workspace_marked.png",
                 "region_captions.json", "trajectory.png"):
        assert (OUTPUT_DIR / name).exists(), f"{name} was not produced"
    passed.append("all four artefacts exist in outputs/05")

    assert not verify_overlay(boxes, W, H), "the grounding overlay failed verification"
    passed.append("grounding boxes pass verify_overlay")

    som = json.loads((OUTPUT_DIR / "region_captions.json").read_text())
    if som["keying_problems"]:
        passed.append(f"NOTE: Set-of-Mark keying problems: {som['keying_problems']}")
    else:
        passed.append("Set-of-Mark keying is exact")

    assert len(pts) >= 2, f"trajectory has only {len(pts)} waypoint(s)"
    inside = all(0 <= x <= 1000 and 0 <= y <= 1000 for x, y in pts)
    assert inside, "some waypoints fall outside the 0-1000 grid"
    passed.append(f"trajectory has {len(pts)} waypoints, all inside the grid")

    parsed_ok = sum(1 for row in sweep.values() if row["ok"])
    passed.append(f"{parsed_ok}/{len(sweep)} temperatures produced parseable JSON")

    for item in passed:
        print(f"  PASS  {item}" if not item.startswith("NOTE") else f"  ----  {item}")
    return passed

_ = self_test()
''')

# --------------------------------------------- shut down
nb.md("""
## Stopping the NIM, and why

Module 1 is finished. Module 2 generates video with the Cosmos Framework, and
that needs the card.

From Lesson 02: the NIM reserves a large block of free VRAM as KV cache at
startup and holds it for the life of the process. It does not release memory
under pressure, and the CUDA allocator does not negotiate — a generation launch
either gets the memory it asks for or raises. Leaving the NIM running is
therefore not "using a bit of the GPU"; it is holding most of it, and Lesson
06's first cell will OOM with an error that says nothing about containers.

So stop it, and **verify from `nvidia-smi` that the driver actually gave the
memory back**. Those are different claims: `docker rm` returning does not mean
the CUDA context has finished tearing down. `stop_nim` polls for the release,
which is why it can take a few seconds and why it reports a before and after.
""")

nb.code('''
before = nim_status(NIM)
print(f"before: {before['gpu_used_gb']} / {before['gpu_total_gb']} GB used, "
      f"NIM holding {before['vram_gb']} GB")
print()

result = stop_nim(NIM)
print()
print(json.dumps(result, indent=2))
''')

nb.code('''
after = nim_status(NIM)
free_gb = (after["gpu_total_gb"] or 0) - (after["gpu_used_gb"] or 0)
nano_needs = cc.MODEL_TIERS["Cosmos3-Nano"]["inference_vram_gb"]
edge_needs = cc.MODEL_TIERS["Cosmos3-Edge"]["inference_vram_gb"]

print(f"free now                      : {free_gb:.1f} GB")
print(f"Cosmos3-Nano generation needs : {nano_needs} GB   -> "
      f"{'ok' if free_gb >= nano_needs else 'NOT ENOUGH'}")
print(f"Cosmos3-Edge generation needs : {edge_needs} GB   -> "
      f"{'ok' if free_gb >= edge_needs else 'NOT ENOUGH'}")
print()
if after["gpu_used_gb"] and after["gpu_used_gb"] > 4.0:
    print(f"{after['gpu_used_gb']:.1f} GB is still held by something else. Run "
          f"`nvidia-smi`.")
    print("A leftover python process from an earlier lesson is the usual answer,")
    print("and it will make Lesson 06 OOM for no visible reason.")
else:
    print("The card is clear. Module 2 can have it.")
''')

nb.md("""
### Summary

- Cosmos 3 emits spatial answers on a **0–1000 grid**, normalised per axis:
  divide x by width, y by height, each scaled to 0–1000. There is no single
  scale factor.
- Normalisation makes the output independent of your image's dimensions. It also
  makes coordinates approximately, not exactly, invariant to resizing — the
  model's estimate genuinely changes when it has fewer pixels.
- Treating 0–1000 as pixels is the classic bug. It has a recognisable shape, it
  looks correct on a 1000×1000 image, and it survives review.
- Verify overlays structurally: inside the image, non-degenerate, and *spread
  out*. The spread check is the one that catches scaling errors.
- **Set-of-Mark** makes output addressable. Its value depends entirely on the
  `subject_id` keying being correct, so check the keying every time.
- The source's marks were pixel boxes tuned to one 1280×720 asset. Convert to
  the normalised grid and they follow any image.
- Split on `</think>` before parsing JSON. The reasoning block often contains a
  draft, and parsing the draft is a wrong answer with no error.
- A pixel-space trajectory is not a robot action. No depth, no orientation, no
  metres.

### Common misconceptions

| Belief | Correction |
|---|---|
| "The coordinates are pixels" | They are 0–1000 per axis. Multiply by width/1000 and height/1000. |
| "One scale factor is enough" | x and y have different divisors unless the image is square. |
| "Resizing must halve the coordinates" | Normalised output is resolution-independent. If it halved, your server is returning pixels — investigate. |
| "The boxes are inside the image, so the overlay is right" | So is a pile of boxes in the corner. Check spread too. |
| "The model returned four captions, so Set-of-Mark worked" | Check the `subject_id`s match the marks you drew. Same count, wrong keys, silently wrong join. |
| "Higher temperature gives a smoother path" | Measure it. Smoothness and format reliability move independently, and the source's claim is not something to inherit unmeasured. |
| "A smooth trajectory is a good trajectory" | A straight line across the image is perfectly smooth and touches nothing. |

### Suggested extensions

- Ground the same object in ten frames of a video and plot the box centre over
  time. Jitter tells you about the model's stability; drift tells you about the
  scene.
- Mark the *same* four regions with different id numbers and check whether the
  captions follow the ids or the positions.
- Feed the trajectory's final waypoint back as a grounding query — "what is at
  this location?" — and see whether the model agrees with itself.

### Mastery checklist

- [ ] I can convert 0–1000 coordinates to pixels in both directions.
- [ ] I can recognise a scaling bug from the shape of the overlay.
- [ ] I have a structural overlay verification that catches it.
- [ ] I built a Set-of-Mark image and verified its keying.
- [ ] I elicited and overlaid a trajectory, and read it as directed.
- [ ] I know why `after_think=True` matters for the trajectory task.
- [ ] I stopped the NIM and confirmed from `nvidia-smi` that VRAM came back.

**Module 1 is complete.** You can now turn footage into captions, decisions and
coordinates. Module 2 turns descriptions back into footage — and it needs the
whole card, which you have just given it.

### Module 1 resources

The three links the source course closed its reasoning notebook with, plus the
one this course adds:

- **[Cosmos 3 cookbook — reasoner](https://github.com/NVIDIA/cosmos/tree/main/cookbooks/cosmos3/reasoner)** —
  every image and clip Lessons 03–05 used, plus NVIDIA's own prompt examples for
  each of the six capabilities. `scripts/fetch_assets.py` reads from here, so
  this is also where to look when an asset name stops resolving.
- **[Try the reasoner in your browser](https://build.nvidia.com/nvidia/cosmos3-nano-reasoner)** —
  hosted Nano reasoner with no install. Useful for showing someone what the
  model does without asking them to find a GPU first.
- **[Reasoner NIM on the NGC catalog](https://catalog.ngc.nvidia.com/orgs/nim/teams/nvidia/containers/cosmos3-reasoner)** —
  container tags and release notes for the image Lesson 02 pulls.
- **[`nvidia/Cosmos3-Nano` on Hugging Face](https://huggingface.co/nvidia/Cosmos3-Nano)** —
  the model card behind the numbers Lesson 01 printed, including the
  `openmdw1.1-license` tag. Read the source rather than this course's tables.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "05_reasoning_spatial.ipynb")
