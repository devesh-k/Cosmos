"""Build 01_cosmos3_mental_model.ipynb.

Lesson 01 — "What Cosmos 3 is, and your first generated image."

Gives the learner a mechanical model of the architecture before they use it, so
the rest of the course reads as a set of consequences rather than a set of
recipes. Ends with one real text2image on Cosmos3-Edge, timed and verified.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
nb = Notebook("Lesson 01 — What Cosmos 3 is, and your first generated image")

# ===========================================================================
# 1. Title block
# ===========================================================================
nb.md("""
# Lesson 01 — What Cosmos 3 is, and your first generated image

**What you will build.** A verified list of the model modes taken from your own
checkout (`outputs/01/mode_enum.json`), and one real generated image from
Cosmos3-Edge that you timed and checked rather than assumed
(`outputs/01/first_image/`).

**Time.** About 60 minutes, of which 30–50 is unattended download the first time.

**GPU needed.** Yes, for the last third.

**Downloads.** ~9.1 GB (Cosmos3-Edge) plus ~8.0 GB of first-run auxiliaries —
the guardrail, a VAE, and a text-safety model. All behind a flag you set
yourself, with the sizes printed first.

**Prerequisites.** Lesson 00, and its `outputs/00/env_report.json`. One Hugging
Face account with a token, and one licence click.
""")

# ===========================================================================
# 2. Learning objectives
# ===========================================================================
nb.md("""
## Learning objectives

By the end of this lesson you will be able to:

- **Explain** what a world foundation model is, and why perceive–reason–act needs
  one model rather than three.
- **Explain** how a Mixture-of-Transformers checkpoint can be "16B on disk, 8B
  active", and **decide** which of the two numbers to budget against for
  inference and which for training.
- **Compare** the three tiers against a stated task and **justify** a choice from
  `MODEL_TIERS` rather than from tier names.
- **Extract** the `ModelMode` enum from your own checkout and **compare** it
  against both this course's table and NVIDIA's prose, demonstrating that
  `policy` is gone and `wam` is live.
- **Predict** the effect of halving `num_steps` on wall-clock time and on the
  image, then **measure** both.
- **Debug** two failures that a validator catches and a clean exit code does not.
""")

# ===========================================================================
# 3. Conceptual foundation
# ===========================================================================
nb.md("""
## What a world foundation model is

Start from zero, because the phrase is doing a lot of work.

A **language model** predicts what text comes next. A **world model** predicts
what the *world* does next: given some frames of video, some sense of what is
happening, and possibly an action, it produces the frames that plausibly follow.
A **world foundation model** is one trained broadly enough that you can point it
at a new scene — a kitchen, a warehouse, a road — without training it again.

"Physical AI" is the term for systems that act in the physical world: robot arms,
humanoids, autonomous vehicles. Those systems need three capabilities, and until
recently you built them from three separate models:

```
  PERCEIVE   what is in front of me?      <- a vision-language model
  REASON     what should happen next?     <- a planner or an LLM
  ACT        what do I do about it?       <- a policy network
```

Three models means three sets of weights, three training runs, three sets of
failure modes, and — the expensive part — three different internal
representations of the same scene that have to be glued together at their
boundaries.

Cosmos 3 is one checkpoint that does all three. That is the claim worth making
mechanical, because everything else in this course is a consequence of it.

### Why generation is the interesting half

The obvious use of a world model is generating video, and that is real. The less
obvious use, and the reason this course exists, is **data**. Robot learning is
starved of training data: collecting a thousand demonstrations of a robot pouring
water takes a thousand pourings, in a real kitchen, with a real robot. A world
model that has seen enough pouring can produce on-distribution variants of one
real clip — different lighting, different mug, different counter — and the
downstream policy trains on those. Lesson 19 builds exactly that loop.

## Omni-model and Mixture-of-Transformers

Here is the architectural idea, from the bottom.

A **transformer** is a stack of layers. Each layer mixes information between
positions (attention) and then transforms each position independently (a
feed-forward block). Text tokens, image patches and audio frames can all be
turned into "positions", which is why one architecture can serve several
modalities.

A **Mixture-of-Transformers** (MoT) keeps that stack but gives it *more than one
set of weights*, and routes each token to the set that matches its job. Cosmos 3
has two such sets — call them **towers**:

```
                       one checkpoint on disk
   ┌───────────────────────────────────────────────────────────┐
   │                                                           │
   │   REASONER tower                    GENERATOR tower       │
   │   vision-language                   diffusion transformer │
   │   pixels + text in                  noise + condition in  │
   │   text out                          pixels out            │
   │                                                           │
   │   shared: tokenizer, VAE, positional scheme, embeddings   │
   └───────────────────────────────────────────────────────────┘
             │                                    │
     "what is happening               "make me a video of
      in this clip?"                   what happens next"
```

**Only one tower is active in any single forward pass.** Ask a question, the
reasoner runs. Ask for a video, the generator runs. The other tower's parameters
sit in memory doing nothing.

That single sentence explains the number that confuses everyone:

| | Cosmos3-Nano | Cosmos3-Super |
|---|---:|---:|
| Parameters on disk (Hugging Face safetensors index) | **15,750,057,456** (16B) | **64,615,003,632** (64B) |
| Parameters active in one forward pass | **8B** | **32B** |
| What NVIDIA's docs and the NIM call it | "Nano (8B)" | "Super (32B)" |

Both numbers are correct. They answer different questions.

### The rule to remember

> **For inference, budget against the *active* count. For training, budget
> against the *total*.**

Inference runs one tower, so activations and the compute bill follow the active
count. Training gives *every* parameter an optimizer state — a fp32 master copy,
two AdamW moments, a gradient — whether or not that parameter was active in the
step. Sixteen billion parameters cost sixteen billion parameters' worth of
optimizer state.

We will make that concrete with `cosmos_course.finetune.estimate_sft_memory`
below, and Lesson 17 spends a whole session on it.
""")

nb.callout(
    "upstream",
    "This naming split is a genuine trap rather than a typo. Hugging Face model "
    "cards report the safetensors index total, NVIDIA's documentation and the NIM "
    "report the per-forward-pass count, and neither says which convention it is "
    "using. When you read a VRAM figure anywhere for a Cosmos 3 tier, work out "
    "which number it was derived from before you trust it. "
    "`assets/reference/COSMOS3_FACTS.md` §1 records both.",
)

# ===========================================================================
# 4. Environment and prerequisites
# ===========================================================================
nb.md("""
## Environment and prerequisites

Same configuration cell as Lesson 00, with `__lesson__` pointing at this lesson's
output directory.
""")

nb.code('# This lesson writes to outputs/01/. The setup cell below reads this name.\n'
        '__lesson__ = "01"\n\n' + SETUP_CELL)

nb.md("""
The verification cell fails on the two things that make this lesson impossible —
no PyTorch, and not enough disk for the downloads — and *warns* about the two
things that only block the last third: no GPU, and no framework checkout. That
split is deliberate. The conceptual half of this lesson is worth doing on a
laptop while a download runs somewhere else.
""")

nb.code('''
import json
import shutil

# Note: AUXILIARY_DOWNLOADS_GB is not re-exported on the package, so it comes
# from the module. `cc.missing_modules()` and dir(cc) tell you what is.
from cosmos_course.config import AUXILIARY_DOWNLOADS_GB

env_report_path = cc.OUTPUT_ROOT / "00" / "env_report.json"
free_gb = shutil.disk_usage(cc.COURSE_ROOT).free / (1024 ** 3)
needed_gb = cc.MODEL_TIERS[MODEL]["download_gb"] + sum(AUXILIARY_DOWNLOADS_GB.values())

blocking = []
try:
    import torch
except ImportError:
    torch = None
    blocking.append("torch is not installed in this kernel. Run scripts/setup.sh and "
                    "select the 'Cosmos 3 (H100)' kernel.")
if free_gb < needed_gb + 5:
    blocking.append(f"only {free_gb:.0f} GiB free; this lesson downloads about "
                    f"{needed_gb:.1f} GB. Run scripts/cleanup.sh, or point HF_HOME "
                    f"at a bigger volume.")

cc.require(not blocking, "Lesson 01 cannot start:\\n  - " + "\\n  - ".join(blocking),
           fix="Fix the items above and re-run this cell.")

if not env_report_path.exists():
    print(f"note: {env_report_path} is missing — go back and finish Lesson 00.")
if DEVICE != "cuda":
    print("WARNING: no CUDA device. Everything up to the generation section still "
          "runs; the generation itself will be skipped.")
if not cc.COSMOS3_REPO.exists():
    print(f"WARNING: no Cosmos Framework checkout at {cc.COSMOS3_REPO}. "
          f"Set COSMOS3_REPO, or run scripts/setup.sh.")
print(f"\\nok — {free_gb:.0f} GiB free, need about {needed_gb:.1f} GB")
''')

# ===========================================================================
# 5. Guided lab — the three tiers
# ===========================================================================
nb.md("""
## Guided lab

### The three tiers

Cosmos 3 ships as three generation checkpoints plus two action-policy variants.
The numbers below come from `cosmos_course.config.MODEL_TIERS`, which mirrors
`COSMOS3_FACTS.md` §1. Print them rather than reading them from prose — including
this prose.

After the table, the callout names two errors the source course makes, and then a
cell checks the more consequential of the two for you. The gating claim is
verifiable in about two seconds per repository, over plain HTTPS, with no
download: `cc.check_hf_access` reads your `HF_TOKEN` from the environment to send
as a bearer header, and never prints, logs or returns it.
""")

nb.code('''
rows = []
for name, tier in cc.MODEL_TIERS.items():
    rows.append((
        name,
        f"{tier['params_total_b']}B",
        f"{tier['params_active_b']}B",
        f"{tier['download_gb']:.1f} GB",
        f"{tier['inference_vram_gb']} GB",
        tier["max_resolution_tier"] + "p",
        "yes" if tier["supports_audio"] else "no",
        "yes" if tier["supports_transfer"] else "no",
        "YES" if tier["gated"] else "no",
    ))

header = ("model", "total", "active", "download", "inf VRAM", "max res", "audio",
          "transfer", "gated")
widths = [max(len(str(r[i])) for r in rows + [header]) for i in range(len(header))]
print("  " + "  ".join(h.ljust(w) for h, w in zip(header, widths)))
print("  " + "  ".join("-" * w for w in widths))
for row in rows:
    print("  " + "  ".join(str(c).ljust(w) for c, w in zip(row, widths)))

print("\\nnotes:")
for name, tier in cc.MODEL_TIERS.items():
    print(f"  {name}: {tier['note']}")
''')

nb.callout(
    "upstream",
    "Three things the source DLI course (`S-OV-57-V1`) gets wrong about the "
    "tiers, and the first two cost real time. **First, gating.** Its notebook 01 "
    "spends an entire session accepting gated licences for the Cosmos3 "
    "checkpoints. All nine Cosmos3 repositories now return `gated: false`; the "
    "only repository still requiring a licence click anywhere in this stack is "
    "`nvidia/Cosmos-Guardrail1`. One click, not five. **Second, Edge's size.** "
    "You will see Edge described as \"2B\" in the audiovisual cookbook. The "
    "safetensors index total is 3,858,999,728 — 4B. Where 2B appears it is the "
    "roughly-half of the model that the shipped vision SFT recipe actually "
    "*trains* (`optimizer.keys_to_select`), not the size of the checkpoint. "
    "**Third, the licence name.** The source calls it the NVIDIA Open Model "
    "License. Every Cosmos3 weight repository is tagged `openmdw1.1-license` — "
    "**OpenMDW 1.1**, the Linux Foundation's Open Model, Data and Weights "
    "licence, which is a different document with different terms "
    "(`COSMOS3_FACTS.md` §1). It matters if you are shipping anything derived "
    "from these weights, and the next cell shows you where to read the tag "
    "rather than the prose. Check the gating claim yourself there too, rather "
    "than taking this callout's word for it.",
)

nb.code('''
# Check the gating claim against Hugging Face rather than against the table above.
gating = {}
for repo in ("nvidia/Cosmos3-Edge", "nvidia/Cosmos3-Nano", "nvidia/Cosmos3-Super",
             "nvidia/Cosmos-Guardrail1"):
    gating[repo] = cc.check_hf_access(repo, quiet=True)

print()
for repo, info in gating.items():
    state = "gated" if info.get("gated") else "not gated"
    reach = "accessible" if info["accessible"] else f"HTTP {info['status']}"
    print(f"  {repo:<30} {state:<10} {reach}")

if not any(info["accessible"] for info in gating.values()):
    print("\\n  Nothing was reachable — you are probably offline. The claim to check "
          "later is: exactly one of these four is gated.")
else:
    print(f"\\n  gated among these four: "
          f"{[r for r, i in gating.items() if i.get('gated')] or 'none'}")
    print("  Expected: only nvidia/Cosmos-Guardrail1.")
''')

nb.md("""
### Which licence, actually?

The same API response carries the licence tag, and reading it takes one more
field. Do that rather than trusting any prose — including the callout above and
including NVIDIA's own course material, which names a licence these repositories
are not under.

`cardData.license` is the machine-readable tag Hugging Face renders as the
licence badge on the model page. It is the closest thing to an authoritative
answer you can get without a lawyer, and it disagrees with the source course.
""")

nb.code('''
import json as _json
import urllib.request as _urlreq

def hf_license(repo_id):
    """The licence tag Hugging Face has on record for a repo, or None."""
    headers = {"Accept": "application/json"}
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"   # sent, never printed
    try:
        req = _urlreq.Request(
            f"https://huggingface.co/api/models/{repo_id}", headers=headers)
        with _urlreq.urlopen(req, timeout=20) as resp:
            body = _json.loads(resp.read().decode("utf-8", "replace"))
    except Exception as exc:
        return None, type(exc).__name__
    card = body.get("cardData") or {}
    return card.get("license"), None


print(f"  {'repository':<30} {'cardData.license'}")
print(f"  {'-' * 30} {'-' * 22}")
seen = []
for repo in ("nvidia/Cosmos3-Edge", "nvidia/Cosmos3-Nano", "nvidia/Cosmos3-Super"):
    value, err = hf_license(repo)
    seen.append(value)
    print(f"  {repo:<30} {value or ('unreachable: ' + str(err))}")

print()
if any(v for v in seen):
    print("  Expected on every row: openmdw1.1-license.")
    print("  That is OpenMDW 1.1 — the Linux Foundation's Open Model, Data and")
    print("  Weights licence. It is NOT the NVIDIA Open Model License, which is")
    print("  what the source DLI course's notebook 01 tells you you are accepting.")
    print("  Two different documents. If you plan to redistribute anything built")
    print("  from these weights, read the one the repository actually names.")
else:
    print("  Offline. The claim to check when you have a network: every Cosmos3")
    print("  repo is tagged openmdw1.1-license, not the NVIDIA Open Model License.")
''')

# --- active vs total, made concrete ---------------------------------------
nb.md("""
### Active versus total, in gigabytes

The rule above — active for inference, total for training — is easy to nod along
to and easy to get backwards under pressure. `estimate_sft_memory` turns it into
numbers you can argue with. It is the tool Lesson 17 is built on; we are calling
it now only to make the architectural point concrete.

Read the estimate below against Nano's **32 GB** documented inference figure
(`COSMOS3_FACTS.md` §3). Inference budgets against 8B active. Training budgets
against all 16B, because a frozen parameter still needs its bf16 forward copy and
a trainable one needs a fp32 master, two AdamW moments and a gradient on top.
""")

nb.code('''
estimate_sft_memory = getattr(cc, "estimate_sft_memory", None)
if estimate_sft_memory is None:
    print("cosmos_course.finetune is not available in this checkout:",
          cc.missing_modules().get("finetune", "unknown reason"))
else:
    full = estimate_sft_memory("Cosmos3-Nano", trainable_fraction=1.0, ema=True,
                               world_size=1)
    print(full)
    print()
    print(f"  Nano inference (documented) : "
          f"{cc.MODEL_TIERS['Cosmos3-Nano']['inference_vram_gb']} GB   <- 8B active")
    print(f"  Nano full SFT state         : {full.state_gb:.0f} GB   <- 16B total")
    print(f"  ratio                       : "
          f"{full.state_gb / cc.MODEL_TIERS['Cosmos3-Nano']['inference_vram_gb']:.1f}x")
''')

nb.callout(
    "vram",
    "That ratio is the whole reason Module 5 exists. The model you can *run* "
    "comfortably on one H100 is nowhere near the model you can *train* on one "
    "H100, and the gap is optimizer state rather than activations — which is why "
    "activation checkpointing, the first thing everyone reaches for, does not "
    "close it. Lesson 17 does the arithmetic properly and then tries anyway.",
)

# ===========================================================================
# 6. The mode enum
# ===========================================================================
nb.md("""
### The mode enum — verify it against your own checkout

A Cosmos Framework run is driven by a JSON *spec* whose most important field is
`model_mode`. It selects which tower runs and what shape the inputs and outputs
take. Getting it wrong is not a soft failure: the framework validates specs with
`extra="forbid"` and an unknown mode is rejected outright.

There are ten modes. This course lists them in
`cosmos_course.config.MODEL_MODES`, NVIDIA lists a different set in
`docs/inference.md`, and the two disagree. Rather than asking you to believe
either, the next two cells read the enum out of the framework **you have
installed** and diff it against this course's table.

Three strategies, tried in order, because the framework may or may not be
importable from this kernel depending on how you set the course up:

1. `import cosmos_framework.inference.args` in this kernel;
2. run the framework venv's own interpreter as a subprocess and ask it;
3. parse `cosmos_framework/inference/args.py` as text.

Strategy 3 is the fallback that works even offline with no venv, and it is the
one worth remembering — reading the source is always available.

The second cell does the diff. Three things to look for in it: does the checkout
contain `wam`, does it still contain the old name, and does it match this
course's table exactly?
""")

nb.code('''
import re
import subprocess

ENUM_SNIPPET = (
    "import json; from cosmos_framework.inference.args import ModelMode; "
    "print(json.dumps(sorted(m.value for m in ModelMode)))"
)


def read_model_modes():
    """Return (modes, source). Tries three strategies; never raises."""
    try:
        from cosmos_framework.inference.args import ModelMode

        return sorted(m.value for m in ModelMode), "imported in this kernel"
    except Exception:
        pass

    venv_python = cc.COSMOS3_REPO / ".venv" / "bin" / "python"
    if venv_python.exists():
        try:
            done = subprocess.run([str(venv_python), "-c", ENUM_SNIPPET],
                                  cwd=str(cc.COSMOS3_REPO), capture_output=True,
                                  text=True, timeout=180, check=True)
            return json.loads(done.stdout.strip().splitlines()[-1]), "framework venv subprocess"
        except Exception:
            pass

    source = cc.COSMOS3_REPO / "cosmos_framework" / "inference" / "args.py"
    if source.exists():
        text = source.read_text(errors="replace")
        block = re.search(r"class\\s+ModelMode\\s*\\([^)]*\\)\\s*:(.*?)(?=\\nclass\\s|\\Z)",
                          text, re.S)
        if block:
            found = re.findall(r"^\\s+[A-Z][A-Z0-9_]*\\s*=\\s*[\\"']([a-z0-9_]+)[\\"']",
                               block.group(1), re.M)
            if found:
                return sorted(set(found)), f"parsed {source.name}"
    return [], "could not read the enum from this machine"


checkout_modes, mode_source = read_model_modes()
print(f"source: {mode_source}")
for mode in checkout_modes:
    print(f"  {mode}")
if not checkout_modes:
    print("  (nothing found — the diff below will fall back to this course's table)")
''')

nb.code('''
course_modes = sorted(cc.MODEL_MODES)
observed = checkout_modes or course_modes

only_here = sorted(set(course_modes) - set(observed))
only_there = sorted(set(observed) - set(course_modes))

print(f"  this course lists : {len(course_modes)} modes")
print(f"  your checkout has : {len(observed)} modes  ({mode_source})")
print(f"  in the course table but not your checkout : {only_here or 'none'}")
print(f"  in your checkout but not the course table : {only_there or 'none'}\\n")

print(f"  'wam'    present in your checkout : {'wam' in observed}")
print(f"  'policy' present in your checkout : {'policy' in observed}   <- must be False\\n")

for mode in course_modes:
    mark = "ok " if mode in observed else "?? "
    print(f"  [{mark}] {mode:<18} {cc.MODEL_MODES[mode]}")

artefact = OUTPUT_DIR / "mode_enum.json"
artefact.write_text(json.dumps({
    "source": mode_source,
    "modes_from_checkout": observed,
    "modes_in_course_table": course_modes,
    "only_in_course_table": only_here,
    "only_in_checkout": only_there,
    "wam_present": "wam" in observed,
    "policy_present": "policy" in observed,
}, indent=2) + "\\n")
print(f"\\nwrote {artefact}")

# And one thing that is NOT a mode: transfer. See the callout below.
print("\\ntransfer control hints (attach to model_mode 'video2video'):")
for hint, description in cc.TRANSFER_HINTS.items():
    print(f"  {hint:<6} {description}")
print("  wsm    ships as a cookbook asset family and uses the same mechanism, "
      "but is NOT a member of the enum.")
print("\\nEdge cannot do transfer at all: supports_transfer="
      f"{cc.MODEL_TIERS['Cosmos3-Edge']['supports_transfer']}")
''')

nb.callout(
    "upstream",
    "**The rename you must know about.** What used to be called `policy` is now "
    "`wam` — World Action Model. The old name is not in the enum and a run using "
    "it fails with a validation error that does not mention the rename. Three "
    "independent confirmations, all in `COSMOS3_FACTS.md` §2: "
    "`ACTION_MODEL_MODES` contains `ModelMode.WAM`; the defaults directory "
    "contains `defaults/wam/` and no policy directory; and the shipped inputs "
    "`inputs/omni/action_policy_av.json` and `action_policy_robot.json` both "
    "contain the *new* value inside — only the filenames still say policy. "
    "Meanwhile `docs/inference.md`, `docs/faq.md` and the action cookbook README "
    "all still document the old name. **Trust the enum, not the prose.** One more "
    "trap if you go checking: fetch "
    "`raw.githubusercontent.com/.../refs/heads/main/...` rather than "
    "`.../main/...`, because the latter serves a stale cached copy that still "
    "shows the old member. `cosmos_course.specs.normalize_policy_mode()` maps the "
    "old name to the new one if you need to accept both.\n\n"
    "**And one thing that is not a mode at all.** You will see \"transfer\" "
    "written as though it were one — the cookbook README encourages this. It is "
    "not. Video-to-video transfer runs as `video2video` **plus a control-hint "
    "block** in the spec, and the framework detects transfer from the presence of "
    "that block. `TransferHintKey` defines exactly the four hints printed above. "
    "Lesson 08 uses all of them; they appear here so the shape of a transfer spec "
    "is not a surprise later.",
)

# ===========================================================================
# 7. Diffusion in one page
# ===========================================================================
nb.md("""
### Diffusion in one page

You are about to run a diffusion model, so here is the least you need. Lesson 06
does it properly.

**The idea.** Start from pure random noise. Ask the model: "given this noisy
thing, and given the prompt, what would a slightly less noisy version look like?"
Apply the answer. Repeat. After enough repetitions the noise has become an image
the model considers plausible for that prompt.

That is the whole loop. Nothing is retrieved, nothing is pasted; every pixel is
constructed by repeatedly nudging noise toward something the model has learned is
plausible.

**Two knobs matter today.**

- **`num_steps`** — how many nudges. More steps means smaller, more careful
  moves. Cost is close to linear in steps, because the steps are sequential and
  each one is a full forward pass through the generator tower. This is the
  cheapest knob to turn and the first one to cut when you are impatient.
- **`guidance`** — how hard each nudge is pushed toward the prompt rather than
  toward "any plausible image". Low guidance drifts off-prompt; high guidance
  obeys the prompt and starts producing over-saturated, over-contrasty artefacts.
  There is a sweet spot and it depends on the model.

**Two more you will meet.** `seed` fixes the starting noise, which is what makes
a run reproducible. `shift` re-spaces the steps along the schedule so more of
them land where the image structure is decided.

The illustration below is *not* the algorithm. It interpolates between fixed
noise and a fixed target so you can see the trajectory; a real sampler has no
target and predicts the direction to move at each step. The shape of the journey
is the point.
""")

nb.code('''
import numpy as np

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None
    print("matplotlib is not installed; skipping the illustration")

if plt is not None:
    rng = np.random.default_rng(0)
    size = 96
    yy, xx = np.mgrid[0:size, 0:size]
    target = np.exp(-(((xx - 60) ** 2 + (yy - 36) ** 2) / 340.0)) + 0.55 * (yy / size)
    target = (target - target.min()) / (target.max() - target.min())
    noise = rng.normal(size=(size, size))

    n_steps = 8
    fig, axes = plt.subplots(1, n_steps + 1, figsize=(1.5 * (n_steps + 1), 2.0))
    for k, ax in enumerate(axes):
        alpha = k / n_steps
        frame = (1 - alpha) * noise + alpha * (target - 0.5) * 4.0
        ax.imshow(frame, cmap="magma")
        ax.set_title(f"step {k}", fontsize=8)
        ax.axis("off")
    fig.suptitle("Illustration only: noise on the left, structure on the right", fontsize=9)
    plt.tight_layout()
    plt.show()
''')

# ===========================================================================
# 8. The guardrail
# ===========================================================================
nb.md("""
### The guardrail, and the one licence click

Between the generator and every file it writes sits a **guardrail**: a set of
models that screen the prompt going in and the frames coming out. It is enabled
by default. `nvidia/Cosmos-Guardrail1` is the one repository in this entire stack
that still requires you to accept a licence, and the generator will pull it on
your first run.

Two consequences worth internalising now.

**It costs a click.** Open
`https://huggingface.co/nvidia/Cosmos-Guardrail1`, accept, and make sure
`HF_TOKEN` is exported in the shell that started Jupyter. Access is granted
immediately. Without it your first generation fails with a 401 or 403 that names
Hugging Face and not the guardrail, which reads like an account problem.

**It can silently blank your output.** A rejected prompt or a rejected frame does
not raise. The run completes, the exit code is zero, and the file it wrote is
blank, blurred or a flat colour. That is a policy decision working as designed,
and it is the single best reason to check output content rather than exit codes.
The debugging lab at the end of this lesson makes that concrete.

There is a `--no-guardrails` flag. Understand what you are switching off before
you use it; Lesson 09 argues both sides properly.

One naming wrinkle to expect: the cookbook points at
`nvidia/Cosmos-1.0-Guardrail` while the framework uses
`nvidia/Cosmos-Guardrail1`. Both repositories exist, both are gated. Accept
whichever your run asks for; Lesson 09 has you record which one it actually
pulled.
""")

nb.code('''
guard = cc.check_hf_access("nvidia/Cosmos-Guardrail1")
print()
print(f"  token present in this kernel's environment: {guard['token_present']}")
print("  (presence only — the value is never read into the notebook)")
if not guard["accessible"]:
    print("\\n  Fix this before turning the download flag on, or the first run "
          "wastes its checkpoint download and then fails.")
''')

nb.md("""
## Your first generated image

Everything from here costs bandwidth, disk and GPU time. Sizes first, then a flag
you set yourself.

The first run downloads, in this order: the checkpoint, the guardrail, a VAE and
a text-safety model. The auxiliaries are pulled lazily on first inference, which
is why a run can appear to hang after the checkpoint finishes — it is fetching
another 8 GB.
""")

# ===========================================================================
# 9. First generation
# ===========================================================================
nb.code('''
hf_home = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface"))
repo_dir = hf_home / "hub" / f"models--nvidia--{MODEL}"
already_cached = repo_dir.exists()


def dir_size_gb(path):
    """Total size on disk, following the symlinks the HF cache uses. 0.0 if absent."""
    if not Path(path).exists():
        return 0.0
    total = 0
    for item in Path(path).rglob("*"):
        try:
            if item.is_file():
                total += item.stat().st_size
        except OSError:
            continue
    return total / 1e9


print(f"  checkpoint      {MODEL:<16} {cc.MODEL_TIERS[MODEL]['download_gb']:>6.2f} GB")
for name, size in AUXILIARY_DOWNLOADS_GB.items():
    print(f"  first-run aux   {name[:40]:<40} {size:>6.2f} GB")
total_download = cc.MODEL_TIERS[MODEL]["download_gb"] + sum(AUXILIARY_DOWNLOADS_GB.values())
print(f"  {'-' * 58}")
print(f"  total first-run download{'':<34} {total_download:>6.2f} GB\\n")
print(f"  HF cache: {hf_home}")
print(f"  {MODEL} already cached: {already_cached}"
      + (f" ({dir_size_gb(repo_dir):.1f} GB on disk)" if already_cached else ""))
''')

nb.md("""
Now the flag. Set `ALLOW_DOWNLOAD = True` when you are ready to spend the
bandwidth and the GPU time. Nothing below this cell does anything expensive while
it is `False`, and every later cell prints what it skipped rather than failing.

`MODE` comes from the configuration cell at the top. In `reduced` — the default —
this is a 256-tier image with few steps and should finish in a couple of minutes
once the weights are local. In `full` it is a 480-tier image at the framework's
usual step count.
""")

nb.code('''
ALLOW_DOWNLOAD = False    # <- set True to download and generate

RESOLUTION = "256" if MODE == "reduced" else "480"
NUM_STEPS = 12 if MODE == "reduced" else 35
PROMPT = (
    "A wide, evenly lit industrial kitchen. A single-arm robot stands at a "
    "stainless steel counter holding a folded blue towel. Shallow depth of field, "
    "photographic, no text."
)

generator = cc.Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=False)
for problem in framework_problems:
    print(f"  ! {problem}")

READY = ALLOW_DOWNLOAD and DEVICE == "cuda" and not framework_problems
# Downloading 17 GB over a slow link can take well over an hour; a warm run is
# minutes. The timeout has to cover whichever this is.
RUN_TIMEOUT = 900 if already_cached else 7200

print(f"\\n  mode={MODE}  resolution={RESOLUTION}  steps={NUM_STEPS}")
print(f"  ALLOW_DOWNLOAD={ALLOW_DOWNLOAD}  device={DEVICE}  ready={READY}")
if not READY:
    print("  Generation cells below will report what they skipped and why.")
''')

nb.md("""
### The spec

The framework takes a JSON file of *sample arguments*, one per sample.
`cosmos_course.specs.InferenceSpec` is a typed wrapper that emits that JSON and
validates it locally first, which turns a twenty-minute round trip through model
loading into an instant error.

Note `aspect_ratio="16,9"`. The separator is a **comma**. Writing `16:9` is the
first mistake nearly everyone makes and the debugging lab returns to it.
""")

nb.code('''
spec = cc.InferenceSpec(
    model_mode="text2image",
    name="first_image",
    prompt=PROMPT,
    resolution=RESOLUTION,
    aspect_ratio="16,9",
    num_frames=1,          # 1 frame is an image; >= 24 is a video
    num_steps=NUM_STEPS,
    guidance=7.0,
    seed=0,
)
print(spec.describe())
print()
problems = cc.validate_spec(spec, strict=False)
print("validation problems:", problems or "none")
print()
print("cost estimate:", json.dumps(spec.cost(), indent=2))
''')

nb.callout(
    "note",
    "Read the `warnings` list in that cost estimate carefully. It says Edge is "
    "documented for 50–150 frames and you asked for 1. That warning is aimed at "
    "video and misfires on a single-frame image — the course's own helper "
    "over-warns here. It is left in rather than special-cased, because a helper "
    "that is occasionally wrong and says so out loud is more useful than one that "
    "is quietly confident. Read warnings; do not obey them.",
)

nb.md("""
### Measuring what a subprocess does to the card

The generator runs as a **separate process** against the framework's own
virtualenv. That is deliberate — the two environments have incompatible pins, and
a subprocess returns every byte of VRAM to the operating system when it exits,
where a failed in-process import can leave your kernel holding 40 GB.

The cost is that `torch.cuda.max_memory_allocated()` in *this* kernel cannot see
what that process did. So we sample the driver instead: poll `nvidia-smi` on a
background thread and keep the maximum. This is the standard technique for
measuring something you do not control, and Lesson 14 reuses it.
""")

nb.code('''
import threading
import time


class GpuSampler:
    """Poll device-wide VRAM use on a thread; report the peak.

    Device-wide, not per-process: it includes anything else on the card, which is
    the honest reading when a subprocess is the thing you are measuring. Stop
    everything else before trusting the number.
    """

    def __init__(self, interval=1.0):
        self.interval = interval
        self.samples = []
        self._stop = threading.Event()
        self._thread = None

    def _read_used_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", "--id=0", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout.strip()
            return float(out.splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_used_gb()
            if value is not None:
                self.samples.append(value)

    def __enter__(self):
        self.samples = [self._read_used_gb() or 0.0]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None

    @property
    def baseline_gb(self):
        return self.samples[0] if self.samples else None
''')

nb.md("""
### Run it

`cc.timer` synchronises the GPU and reports wall clock. `MeasurementLog` appends
the result to a JSONL file that Lesson 14 reads back.

Expect the first run to spend most of its time downloading and loading weights,
not denoising. That is normal, and separating the two is what Lesson 06 does.

Then verify it before looking at it. `verify_result` runs every applicable check
and reports the exit code as **one signal among several**. A non-zero exit is
conclusive evidence of failure; a zero exit is not evidence of success. That
asymmetry is the habit this course is trying to build, and the reason
`cosmos_course.checks` exists at all.

For an image the substantive check is spatial autocorrelation: in a real picture
a pixel predicts its neighbour with correlation above about 0.95, while in noise
that number sits near zero. Unlike standard deviation it does not care about
contrast, which matters because the nastiest failures produce mid-grey noise
whose mean and histogram look perfectly healthy.
""")

nb.code('''
from cosmos_course.measure import MeasurementLog

log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
result = None
first_run_seconds = None
first_run_peak_gb = None

if READY:
    print(f"starting — up to {total_download:.1f} GB may download first")
    with GpuSampler() as sampler:
        with cc.timer("first text2image", track_memory=False) as timing:
            result = generator.run(spec, OUTPUT_DIR / "first_image",
                                   seed=0, timeout=RUN_TIMEOUT)
    first_run_seconds = timing.seconds
    first_run_peak_gb = sampler.peak_gb
    log.record(label="first_text2image", seconds=timing.seconds, mode=MODE,
               resolution=RESOLUTION, num_steps=NUM_STEPS, model=MODEL,
               device_peak_gb=sampler.peak_gb, device_baseline_gb=sampler.baseline_gb)
    print(f"\\n  wall clock       : {timing.seconds:.1f} s")
    print(f"  device VRAM before: {sampler.baseline_gb:.1f} GB")
    print(f"  device VRAM peak  : {sampler.peak_gb:.1f} GB")
else:
    print("skipped: ALLOW_DOWNLOAD is False, or there is no GPU, or the framework "
          "checkout is missing. Nothing was downloaded.")
''', tags=["expensive"])

nb.code('''
if result is not None:
    checks = cc.verify_result(result)
    print()
    print(result.summary())
    if result.image_path:
        cc.show_image(result.image_path, caption=f"{MODEL} · {RESOLUTION}p · "
                                                 f"{NUM_STEPS} steps · seed 0")
else:
    print("nothing to verify — the generation cell was skipped")
''')

# ===========================================================================
# 10. Predict–run–explain
# ===========================================================================
nb.predict_run_explain(
    predict=(
        "The next run is identical except that `num_steps` is halved. Predict two "
        "things and write them down: the ratio of the new wall-clock time to the "
        "first run's, and whether `check_image` will pass. Then say what you "
        "expect to *see* different in the picture."
    ),
    change=(
        "Nothing to edit — run the cell. It reuses the same seed and prompt so "
        "steps are the only variable."
    ),
    explain=(
        "Compare the measured time ratio against your prediction. Steps are "
        "sequential full forward passes, so what should the ratio have been in "
        "principle, and what accounts for the difference between that and what "
        "you measured? Then look at both images: did `check_image` distinguish "
        "them, and should it have?"
    ),
    hint=(
        "The first run paid for weight loading and possibly a download; the "
        "second did not. Which parts of the wall clock scale with `num_steps` and "
        "which are fixed? `first_run_seconds` includes both."
    ),
)

nb.code('''
half_steps = max(1, NUM_STEPS // 2)
spec_half = cc.InferenceSpec(
    model_mode="text2image", name="half_steps", prompt=PROMPT,
    resolution=RESOLUTION, aspect_ratio="16,9", num_frames=1,
    num_steps=half_steps, guidance=7.0, seed=0,
)
result_half = None

if READY:
    with GpuSampler() as sampler_half:
        with cc.timer(f"text2image at {half_steps} steps", track_memory=False) as t_half:
            result_half = generator.run(spec_half, OUTPUT_DIR / "half_steps",
                                        seed=0, timeout=RUN_TIMEOUT)
    log.record(label="half_steps", seconds=t_half.seconds, mode=MODE,
               resolution=RESOLUTION, num_steps=half_steps, model=MODEL,
               device_peak_gb=sampler_half.peak_gb)
    if first_run_seconds:
        print(f"\\n  {NUM_STEPS} steps : {first_run_seconds:>7.1f} s")
        print(f"  {half_steps} steps : {t_half.seconds:>7.1f} s")
        print(f"  measured ratio (half/full) : {t_half.seconds / first_run_seconds:.2f}")
        print(f"  ratio if time were purely proportional to steps : "
              f"{half_steps / NUM_STEPS:.2f}")
else:
    print("skipped — see the ALLOW_DOWNLOAD flag above")
''', tags=["expensive"])

nb.md("""
Now quantify the images rather than eyeballing them. `check_image` returns its
metrics, so the two runs can be compared numerically — though be careful about
what that comparison means. These are *aliveness* statistics, not quality
metrics. A lower step count can produce a softer, less detailed picture that
still scores well on every one of them. The numbers tell you the pipeline worked;
your eyes tell you whether the result is any good.
""")

nb.code('''
paths = [p for p in (getattr(result, "image_path", None),
                     getattr(result_half, "image_path", None)) if p]
if paths:
    labels = [f"{NUM_STEPS} steps", f"{half_steps} steps"][:len(paths)]
    for label, path in zip(labels, paths):
        outcome = cc.check_image(path)
        keys = ("std", "autocorrelation", "edge_density", "uniform_fraction", "size_kb")
        summary = "  ".join(f"{k}={outcome.metrics[k]:.4g}"
                            for k in keys if k in outcome.metrics)
        print(f"  {label:<12} {'PASS' if outcome.passed else 'FAIL'}   {summary}")
    cc.contact_sheet(paths, cols=2, width=320)
else:
    print("no images to compare — the generation cells were skipped")
''')

nb.predict_run_explain(
    predict=(
        "Which is bigger for Cosmos3-Edge: the download, or the peak VRAM the "
        "generation actually used? Commit to an answer and a reason before you "
        "look. Both numbers are already in front of you — the download size was "
        "printed above, and `first_run_peak_gb` was sampled during the run."
    ),
    change=(
        "Nothing to edit. Run the cell; it reads the on-disk size of the cached "
        "repository rather than trusting the advertised figure."
    ),
    explain=(
        "Name three things that occupy VRAM during a run but do not appear in the "
        "download, and one thing that appears in the download but need not be "
        "resident during a text2image run."
    ),
    hint=(
        "Weights are stored in bf16 — two bytes per parameter — so 4B parameters "
        "is about 8 GB on disk. What else has to be on the card while denoising "
        "is happening? And is the *whole* checkpoint needed for a text2image run "
        "on a two-tower model?"
    ),
)

nb.code('''
cached_gb = dir_size_gb(repo_dir)
advertised_gb = cc.MODEL_TIERS[MODEL]["download_gb"]
params_b = cc.MODEL_TIERS[MODEL]["params_total_b"]

print(f"  advertised download          : {advertised_gb:.2f} GB")
print(f"  actually on disk now         : {cached_gb:.2f} GB")
print(f"  bf16 weights implied by {params_b}B params : {params_b * 2:.1f} GB")
if first_run_peak_gb is not None:
    print(f"  device VRAM peak during run  : {first_run_peak_gb:.2f} GB (device-wide)")
    print(f"  peak / on-disk               : "
          f"{first_run_peak_gb / max(cached_gb, 0.01):.2f}x")
else:
    print("  device VRAM peak during run  : not measured (generation was skipped)")
print(f"\\n  For reference, this course's working estimate for Edge inference is "
      f"{cc.MODEL_TIERS[MODEL]['inference_vram_gb']} GB. It is an estimate, not an "
      f"NVIDIA figure, and Lesson 06 measures it properly with the model isolated "
      f"on the card.")
''')

nb.md("""
<details>
<summary><b>Answer</b> (try it yourself first)</summary>

VRAM is normally the larger number, and by a clear margin.

The download is bf16 weights and not much else: 4B parameters at two bytes each
is roughly 8 GB, which is most of Edge's 9.1 GB.

Resident during a run you additionally have the CUDA context (0.3–0.6 GB), the
activations for the denoising loop, attention workspaces, the VAE that decodes
latents to pixels, the guardrail models screening prompt and frames, and the
allocator's reserved-but-unused pool. None of those are in the checkpoint.

Pulling the other way: on a Mixture-of-Transformers checkpoint a `text2image` run
uses the generator tower, so a well-implemented loader need not keep every
reasoner parameter hot. That is why the active-parameter count is the right
inference budget — and why measuring beats arithmetic. Note also that the number
you sampled is device-wide, so anything else on the card is included in it.

</details>
""")

nb.md("""
## Debugging lab — two failures, one loud and one silent

### Failure 1: symptom

You wrote `"aspect_ratio": "16:9"`, as you would anywhere else in computing. The
run rejects it — or, depending on where you put it, accepts it and quietly gives
you the default geometry.

### Hypothesis

The framework takes aspect ratio as a comma-separated string, not a
colon-separated one and not a float. There is a fixed set of accepted values.

### Diagnostic step

Do not launch anything. `validate_spec` checks locally, in milliseconds, against
`cosmos_course.config.ASPECT_RATIOS`. Run it with `strict=False` to see the
problem list instead of an exception.
""")

nb.code('''
bad_spec = cc.InferenceSpec(
    model_mode="text2image", name="colon_aspect", prompt=PROMPT,
    resolution=RESOLUTION, aspect_ratio="16:9",     # wrong separator, on purpose
    num_frames=1, num_steps=NUM_STEPS, seed=0,
)
for problem in cc.validate_spec(bad_spec, strict=False):
    print(f"  - {problem}")
''', tags=["teaching-antipattern"])

nb.md("""
### Repair and verification

The accepted values live in one place. Read them, fix the spec, and confirm the
problem list is empty — that is the verification step, and skipping it is how you
end up fixing the same field twice.
""")

nb.code('''
from cosmos_course.config import ASPECT_RATIOS

print("accepted aspect ratios:", ASPECT_RATIOS)
bad_spec.aspect_ratio = "16,9"
print("problems after repair:", cc.validate_spec(bad_spec, strict=False) or "none")

width, height = cc.resolution_wh(RESOLUTION, "16,9")
print(f"\\n  resolution tier {RESOLUTION!r} at 16,9 -> {width}x{height} px")
print("  Note the tier is a NAME, not a pixel height. '256' is 256x144, not "
      "'256 pixels tall'.")
''')

nb.md("""
### Failure 2: symptom

This one is worse, because nothing complains.

A prompt arrives empty — lost to a JSON escaping mistake, or read from a field
that was never set, or a template that rendered to nothing. The spec validates.
The run exits 0. A file appears. The pipeline reports success and you move on.

`validate_spec` cannot catch this: an empty string is a present field, and
"meaningful" is not a property a schema can check. The only thing that catches it
is looking at what came out.
""")

nb.code('''
blank_spec = cc.InferenceSpec(
    model_mode="text2image", name="blank_prompt",
    prompt="",                                   # empty, on purpose
    resolution=RESOLUTION, aspect_ratio="16,9", num_frames=1,
    num_steps=max(1, NUM_STEPS // 2), guidance=7.0, seed=0,
)
print("validate_spec says:", cc.validate_spec(blank_spec, strict=False) or "no problems")
print("  ^ a schema cannot tell an empty prompt from a deliberate one.\\n")

blank_result = None
if READY:
    blank_result = generator.run(blank_spec, OUTPUT_DIR / "blank_prompt",
                                 seed=0, timeout=RUN_TIMEOUT, stream_logs=False)
    print(f"  exit code : {blank_result.returncode}")
    print(f"  outputs   : {len(blank_result.outputs)} file(s)")
else:
    print("  skipped — see the ALLOW_DOWNLOAD flag above")
''', tags=["expensive"])

nb.md("""
### Diagnosis, repair, verification

Compare the two images through `check_image` and read the metrics rather than the
exit codes. Three outcomes are possible and all three are informative:

- **The check fails** on flatness or uniformity. The guardrail blanked the frame,
  or the model had nothing to condition on. The exit code was still zero.
- **The check passes** but the picture is generic. This is the honest case: an
  unconditional sample is a perfectly healthy image of nothing in particular, and
  no automatic statistic can call that wrong. `check_image` is an *aliveness*
  test, not a quality test, and that limit is the point.
- **Nothing was produced at all.** `RunResult.ok` requires a zero exit code *and*
  at least one output file, precisely because the two come apart.

The repair is upstream of the model: assert your prompt is non-empty before you
spend a GPU-minute on it.
""")

nb.code('''
def assert_prompt(text, min_words=4):
    """Refuse to spend GPU time on a prompt that says nothing."""
    words = (text or "").split()
    if len(words) < min_words:
        raise ValueError(
            f"prompt has {len(words)} word(s), expected at least {min_words}. "
            f"An empty or near-empty prompt produces a valid file and a "
            f"meaningless picture, and the exit code will be 0."
        )
    return text


for candidate in ("", "   ", PROMPT):
    try:
        assert_prompt(candidate)
        print(f"  ok      {candidate[:48]!r}...")
    except ValueError as exc:
        print(f"  BLOCKED {candidate!r} — {exc}")

if blank_result is not None and blank_result.image_path:
    print()
    print("  blank prompt:", cc.check_image(blank_result.image_path))
if result is not None and result.image_path:
    print("  real prompt :", cc.check_image(result.image_path))
''')

nb.callout(
    "warning",
    "Generalise the lesson rather than the fix. Every stage of this course can "
    "exit 0 and be wrong: a transfer run that silently ignored your control video, "
    "an action spec with the wrong `domain_name` producing well-formed numbers for "
    "the wrong robot, a dataset loader that dropped every record. The habit is to "
    "verify the artefact. `cosmos_course.checks` has a function for each kind, and "
    "`verify_result` runs whichever apply.",
)

nb.md("""
## Exercises

All three run without further downloads if you completed the generation section.
The foundation exercise needs the GPU; the other two do not.
""")

nb.exercise(
    "foundation",
    "Three seeds, measured rather than eyeballed",
    goal=(
        "Generate the same prompt at three seeds and quantify how much they "
        "differ, instead of saying \"they look different\"."
    ),
    instructions=(
        "1. Generate the same spec at seeds 0, 1 and 2. Keep everything else "
        "fixed, including `num_steps`.\n"
        "2. Write `image_difference(a, b)` returning a number that grows with how "
        "different two images are. Load both with Pillow, convert to grayscale, "
        "resize to a common size, and take the mean absolute difference — then say "
        "in a comment what that metric is blind to.\n"
        "3. Compare all three pairs. Also compare one image against *itself* to "
        "establish the floor.\n"
        "4. Re-run seed 0 a second time and compare it against the first seed-0 "
        "image. Report whether the pipeline is deterministic on this machine."
    ),
    success=(
        "You have a 3x3 matrix of pairwise differences with a zero diagonal, and a "
        "written answer to the determinism question with the number that supports "
        "it."
    ),
    starter='''
import numpy as np
from PIL import Image

SEEDS = [0, 1, 2]
seed_images = {}


def image_difference(path_a, path_b):
    """Mean absolute grayscale difference, 0 = identical.

    TODO: say in a comment what this metric cannot see. (Hint: shift one image
    by two pixels and think about what happens to the number.)
    """
    a = Image.open(path_a).convert("L")
    b = Image.open(path_b).convert("L").resize(a.size)
    return float(np.abs(np.asarray(a, float) - np.asarray(b, float)).mean())


if READY:
    for seed in SEEDS:
        seed_spec = cc.InferenceSpec(
            model_mode="text2image", name=f"seed_{seed}", prompt=PROMPT,
            resolution=RESOLUTION, aspect_ratio="16,9", num_frames=1,
            num_steps=NUM_STEPS, guidance=7.0, seed=seed,
        )
        # TODO: run it, keep seed_images[seed] = <path to the image>
    # TODO: build and print the pairwise matrix, then the determinism re-run
else:
    print("needs the generation section; set ALLOW_DOWNLOAD = True above")
''',
    hints=[
        "`generator.run(spec, OUTPUT_DIR / f\"seed_{seed}\", seed=seed)` — pass the "
        "seed in both places, because the spec field and the command-line flag are "
        "separate knobs and a mismatch is exactly the kind of thing this exercise "
        "should surface. For the determinism question: a pixel-wise metric of zero "
        "proves determinism, but a small non-zero value does not prove "
        "non-determinism until you can say how small is small — which is what the "
        "self-comparison floor is for.",
    ],
    solution_ref="solutions/01_solutions.ipynb",
)

nb.exercise(
    "applied",
    "The largest job that fits a time budget",
    goal=(
        "Write `largest_that_fits(seconds)` choosing the resolution, frame count "
        "and step count that make the most of a stated time budget on *this* "
        "machine — calibrated by one measured run rather than assumed."
    ),
    instructions=(
        "1. Calibrate. Take one measured run from `outputs/01/measurements.jsonl` "
        "and its `cost_units` from `cc.estimate_generation_cost`, and derive a "
        "units-per-second constant for this machine.\n"
        "2. Enumerate candidate configurations across `RESOLUTION_TIERS`, a range "
        "of frame counts, and a range of step counts.\n"
        "3. Drop candidates the tier does not support (`max_resolution_tier`, "
        "`frames_range`) and candidates whose predicted time exceeds the budget.\n"
        "4. Rank the survivors. Deciding what \"largest\" means is the exercise: "
        "pixels? pixel-seconds of video? cost units? Choose, and defend it in a "
        "comment.\n"
        "5. Report the predicted time for your winner and state your confidence "
        "in it."
    ),
    success=(
        "`largest_that_fits(600)` returns a configuration whose predicted time is "
        "under ten minutes, your ranking rule is written down, and you can name "
        "the biggest source of error in the prediction."
    ),
    starter='''
from cosmos_course.config import RESOLUTION_TIERS

measurements = cc.MeasurementLog(OUTPUT_DIR / "measurements.jsonl").load()
print(f"{len(measurements)} measurement(s) available")


def calibrate_units_per_second(records):
    """Derive units-per-second for this machine from measured runs.

    TODO: for each record, rebuild its cost with cc.estimate_generation_cost and
    divide by the measured seconds. Decide what to do about weight-loading time,
    which is in `seconds` and is not proportional to cost units — and say what
    your choice does to the estimate.
    """
    return None


def largest_that_fits(seconds, model=None, units_per_second=None):
    """Best configuration that should finish within `seconds`."""
    model = model or MODEL
    candidates = []
    # TODO: enumerate, filter against the tier, predict, rank.
    return candidates[0] if candidates else None


rate = calibrate_units_per_second(measurements)
print("units per second:", rate)
print(largest_that_fits(600, units_per_second=rate))
''',
    hints=[
        "`estimate_generation_cost` deliberately returns a unit count rather than "
        "a time, because the *ratio* between two configurations is stable across "
        "hardware while the absolute seconds are not. Calibration is what turns it "
        "into a time estimate for one machine. Your biggest error source is that a "
        "measured `seconds` includes weight loading, which is a fixed cost: fit "
        "`seconds = fixed + units / rate` if you have two measurements, and if you "
        "only have one, say out loud that your rate is an upper bound on cost per "
        "unit.",
    ],
    solution_ref="solutions/01_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "A model card reader with no hard-coded facts",
    goal=(
        "Build `read_model_card(repo_or_path)` that reports a checkpoint's tier, "
        "active and total parameter counts, supported modes, and whether this "
        "machine can run it — reading all of it from the local checkpoint and the "
        "installed framework, with **no** facts hard-coded from this course."
    ),
    instructions=(
        "1. Locate the checkpoint in the Hugging Face cache from a repo id. Do not "
        "assume a path layout you have not checked.\n"
        "2. Read `config.json` and, if present, `model.safetensors.index.json`. "
        "Sum `metadata.total_size`, or the shard sizes, to get the real on-disk "
        "size. Derive the *total* parameter count from the tensor shapes or from "
        "total bytes divided by bytes-per-parameter, and say which you used.\n"
        "3. Derive the *active* count. This is the hard part and there is no field "
        "for it: you must reason from the config's expert or tower structure. If "
        "you cannot determine it, return `None` with a stated reason — an honest "
        "`None` beats a confident guess.\n"
        "4. Read supported modes from the installed framework, reusing "
        "`read_model_modes()` from earlier in this lesson.\n"
        "5. Compare the requirement against the card's real VRAM, read from "
        "`torch`.\n"
        "6. Validate against `cc.MODEL_TIERS` at the end — but only as a *check*, "
        "printing where your reader and the course's table disagree. If they "
        "disagree, work out which one is wrong before assuming it is yours."
    ),
    success=(
        "`read_model_card(\"nvidia/Cosmos3-Edge\")` returns a dict with the six "
        "fields, every value traceable to a file on disk or a `torch` call, and "
        "the comparison against `cc.MODEL_TIERS` printed with any disagreement "
        "explained."
    ),
    starter='''
def find_local_checkpoint(repo_id):
    """Return the snapshot directory for a cached HF repo, or None.

    TODO: the cache layout is models--<org>--<name>/snapshots/<sha>/. Verify that
    on your machine before relying on it.
    """
    return None


def read_model_card(repo_id):
    """Report what a local checkpoint actually is. No hard-coded course facts."""
    card = {
        "repo_id": repo_id,
        "local_path": None,
        "disk_gb": None,
        "params_total_b": None,
        "params_active_b": None,      # None with a reason is a valid answer
        "supported_modes": [],
        "runnable_here": None,
        "notes": [],
    }
    # TODO
    return card


card = read_model_card(f"nvidia/{MODEL}")
print(json.dumps(card, indent=2, default=str))

expected = cc.MODEL_TIERS.get(MODEL, {})
for field in ("params_total_b", "params_active_b", "download_gb"):
    print(f"  course table {field:<18} = {expected.get(field)}")
''',
    hints=[
        "`model.safetensors.index.json` has a `metadata.total_size` in bytes and a "
        "`weight_map` naming every tensor. The tensor *names* are the most "
        "informative thing in the file: a Mixture-of-Transformers checkpoint has "
        "parameter names carrying a tower marker — the SFT recipes select on "
        "substrings such as `moe_gen` — so summing the parameters whose names "
        "belong to one tower is a defensible route to an active count. Say which "
        "convention you relied on, because that is the assumption most likely to "
        "break on the next release. And bytes-per-parameter is not always 2: read "
        "the dtype from `config.json` (`torch_dtype`) rather than assuming bf16, "
        "and if the checkpoint mixes dtypes, say so in `notes` rather than "
        "averaging it away.",
    ],
    solution_ref="solutions/01_solutions.ipynb",
)

# ===========================================================================
# 13. Assessment and reflection
# ===========================================================================
nb.md("""
## Assessment and reflection

### Knowledge check

1. Hugging Face says Cosmos3-Nano has 15,750,057,456 parameters. NVIDIA calls it
   "Nano (8B)". Explain both numbers in one sentence each, and say which you would
   use to answer "will inference fit on my card?"
2. Why does training memory scale with the total parameter count even though only
   one tower is active per forward pass?
3. Your colleague's script sets `model_mode` to the string `"policy"` and fails.
   What is the current name, and how would you have found that out without asking
   anyone?
4. Name the four transfer control hints and the mode they attach to.
5. A generation run exits 0 and writes a 340 KB PNG. Name three distinct ways
   that file could still be worthless, and the check that catches each.
6. Which repositories in the Cosmos 3 stack are gated, and what did the source
   course get wrong about that?
7. You halve `num_steps`. What happens to wall-clock time, and what happens to
   peak VRAM? Why are the answers different?
""")

nb.md("""
<details>
<summary><b>Answer</b> (try it yourself first)</summary>

1. 15,750,057,456 is the safetensors index total — everything on disk, both
   towers. "8B" is what flows through one forward pass, because a
   Mixture-of-Transformers activates one tower at a time. For "will inference
   fit", use the **active** count; 8B active is why NVIDIA documents Nano
   inference at 32 GB.
2. Because every parameter carries optimizer state whether or not it was active
   this step: a fp32 master copy, two AdamW moments, and a gradient. That is 16–22
   bytes per trainable parameter *before* activations, and it does not care about
   routing.
3. It is `wam`. You would find out by reading the `ModelMode` enum in your own
   checkout, exactly as this lesson did — `docs/inference.md`, `docs/faq.md` and
   the cookbook README all still say the old name.
4. `edge` (shape and layout), `blur` (colour and lighting), `depth` (3D structure),
   `seg` (object identity). They attach to `model_mode: "video2video"`; transfer is
   not a mode of its own.
5. A guardrail rejection blanked the frame — caught by the flatness and
   uniform-fraction checks. A NaN in the latent decoded to noise — caught by
   spatial autocorrelation, and by nothing amplitude-based. An empty or wrong
   prompt produced a healthy but meaningless image — caught by neither, which is
   why the repair belongs upstream, in an assertion on the prompt.
6. Exactly one: `nvidia/Cosmos-Guardrail1` (and its cookbook-named twin
   `nvidia/Cosmos-1.0-Guardrail`). All nine Cosmos3 checkpoints are ungated. The
   source DLI course spends a whole notebook accepting licences that no longer
   need accepting.
7. Wall clock falls close to linearly, because steps are sequential forward
   passes. Peak VRAM barely moves, because per-step activations are transient and
   the resident weights, VAE and guardrail dominate the footprint. Steps are a
   throughput knob, not a memory knob.

</details>

### Practical completion test

The completion criterion for this lesson: the image passes `check_image`, and the
mode list you extracted contains `wam` and does not contain the old name.
""")

nb.code('''
def lesson_01_complete():
    checks = [
        ("mode_enum.json written", artefact.exists()),
        ("checkout has 'wam'", "wam" in observed),
        ("checkout does not have the old name", "policy" not in observed),
        ("course table and checkout agree", not only_here and not only_there),
        ("generation ran", result is not None),
        ("image exists", bool(getattr(result, "image_path", None))),
        ("image passes check_image",
         bool(result is not None and result.image_path
              and cc.check_image(result.image_path).passed)),
    ]
    for label, ok in checks:
        print(f"  [{'ok ' if ok else 'NO '}] {label}")
    required = [ok for label, ok in checks[:4]]
    optional = [ok for label, ok in checks[4:]]
    print("\\nconceptual half:", "complete" if all(required) else "not yet")
    print("generation half :", "complete" if all(optional)
          else "not yet (expected if ALLOW_DOWNLOAD is still False)")
    return all(required) and all(optional)


lesson_01_complete()
''')

nb.md("""
### Common misconceptions

- **"Nano is 8B, so the download is 16 GB."** The download is 34.9 GB. Active
  parameters describe a forward pass; the disk holds both towers.
- **"An omni-model runs everything at once."** One tower per forward pass. The
  other one is resident and idle.
- **"Transfer is a model mode."** It is `video2video` plus a control-hint block.
- **"`policy` still works, it is in the docs."** The docs are stale in three
  places. The enum is the truth.
- **"The Cosmos3 checkpoints are gated."** They were when the source course was
  written. They are not now. Only the guardrail is.
- **"Exit code 0 means it worked."** It means the process finished. The guardrail
  can blank a frame, an empty prompt can produce a meaningless picture, and both
  exit 0.
- **"More steps is always better."** More steps costs close to linear time for
  diminishing returns, and Lesson 06 finds where the curve flattens on your
  machine.

### Summary

You now have a mechanical account of what Cosmos 3 is: one checkpoint, two
towers, one active per forward pass, which is why the parameter count has two
correct values and why inference and training budget against different ones. You
extracted the mode enum from your own checkout rather than trusting prose, and
established that `wam` is live and the old name is gone. You generated, timed and
verified one real image, and you saw two ways a run can look successful and not
be.

Artefacts: `outputs/01/mode_enum.json`, `outputs/01/first_image/`,
`outputs/01/measurements.jsonl`.

### Suggested extensions

- Re-run the first generation with `--no-guardrails` (via `extra_args`) and
  compare the peak VRAM sample. How much of your footprint was the safety stack?
- Sweep `guidance` over four values at a fixed seed and describe the trend before
  Lesson 07 does it formally.
- Generate at the 480 tier and compare the measured time ratio against the ratio
  `estimate_generation_cost` predicts. Where the two disagree is where Lesson 06
  starts.

### Mastery checklist

- [ ] I can explain Mixture-of-Transformers to someone who has never met it, in
      under a minute, and say why the parameter count has two right answers.
- [ ] I can state the rule for which count to budget against, and why.
- [ ] I can list the ten model modes and say where to check them.
- [ ] I can explain why `policy` fails and where upstream still recommends it.
- [ ] I can describe the denoising loop and predict the direction of `num_steps`
      and `guidance`.
- [ ] I never conclude a run worked from its exit code.

### Next

**Lesson 02 — Serving the reasoner.** It pulls the Reasoner NIM (8.28 GB
compressed, ~20 GB of weights on disk) and confronts the constraint you costed in
Lesson 00: the NIM and the generator both want the whole card.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "01_cosmos3_mental_model.ipynb")
