#!/usr/bin/env python3
"""Cross-check every lesson's `solution_ref` against what is on disk.

A lesson that points at `solutions/NN_solutions.ipynb` and a solutions file that
does not exist is a broken promise the other validators cannot see: the
reference lives in a markdown cell, so `syntax_check` ignores it and
`validate_notebooks`'s asset check does not match `.ipynb`.

Checks, per referenced solutions notebook:
  * it exists
  * it has exactly one solution section per exercise in the lesson (three)
  * every section restates a goal and a success criterion
  * every section is followed by at least one code cell
  * the notebook opens with the standard header and the setup cell
  * it carries no committed outputs (validate_notebooks covers this too; here
    it is cheap and this script is the one people run after editing a builder)

Exit code 0 when clean, 1 otherwise.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REF = re.compile(r"Reference solution: `(solutions/[^`]+\.ipynb)`")
SECTION = re.compile(r"^## Solution \d+ — ", re.M)
EXERCISE = re.compile(r'^### <span style="background:')


def source(cell: dict) -> str:
    src = cell.get("source", "")
    return "".join(src) if isinstance(src, list) else str(src)


def main() -> int:
    problems: list[str] = []
    checked = 0

    lessons = sorted(p for p in ROOT.glob("[0-9][0-9]_*.ipynb"))
    if not lessons:
        print("no lesson notebooks found", file=sys.stderr)
        return 2

    for lesson in lessons:
        nb = json.loads(lesson.read_text(encoding="utf-8"))
        cells = nb["cells"]
        exercises = sum(1 for c in cells
                        if c["cell_type"] == "markdown" and EXERCISE.match(source(c)))
        refs = sorted({m for c in cells if c["cell_type"] == "markdown"
                       for m in REF.findall(source(c))})

        if not refs:
            problems.append(f"{lesson.name}: no solution_ref anywhere")
            continue
        if len(refs) != 1:
            problems.append(f"{lesson.name}: {len(refs)} distinct refs {refs}")

        for ref in refs:
            path = ROOT / ref
            checked += 1
            if not path.exists():
                problems.append(f"{lesson.name}: {ref} does not exist")
                continue

            sol = json.loads(path.read_text(encoding="utf-8"))
            scells = sol["cells"]

            # The capstone reference has its own shape and is authored
            # separately; only its existence and hygiene are checked here.
            per_exercise = bool(re.fullmatch(r"\d\d_solutions\.ipynb", path.name))
            if not per_exercise:
                n_code = sum(1 for c in scells if c["cell_type"] == "code")
                bad = [j for j, c in enumerate(scells) if c["cell_type"] == "code"
                       and (c.get("outputs") or c.get("execution_count") is not None)]
                for j in bad:
                    problems.append(f"{ref}: cell {j} carries outputs or an "
                                    f"execution_count")
                print(f"  ok    {ref:<34} {len(scells):>3} cells "
                      f"({n_code} code)  [capstone reference — structure not "
                      f"checked here]")
                continue
            headings = [i for i, c in enumerate(scells)
                        if c["cell_type"] == "markdown" and SECTION.search(source(c))]

            if len(headings) != exercises:
                problems.append(
                    f"{ref}: {len(headings)} solution section(s) for "
                    f"{exercises} exercise(s) in {lesson.name}")

            for i in headings:
                body = source(scells[i])
                if "**The goal.**" not in body:
                    problems.append(f"{ref}: section at cell {i} restates no goal")
                if "**Done when.**" not in body:
                    problems.append(
                        f"{ref}: section at cell {i} restates no success criterion")
                nxt = [c for c in scells[i + 1:i + 8] if c["cell_type"] == "code"]
                if not nxt:
                    problems.append(
                        f"{ref}: section at cell {i} has no code cell after it")

            head = source(scells[0]) if scells else ""
            if not head.startswith("# Lesson "):
                problems.append(f"{ref}: does not open with a lesson title")
            if not any("attempt" in source(c).lower() or "own answer" in source(c).lower()
                       for c in scells[:6] if c["cell_type"] == "markdown"):
                problems.append(f"{ref}: header does not tell the reader to try first")
            if not any("one defensible solution" in source(c).lower()
                       for c in scells[:8] if c["cell_type"] == "markdown"):
                problems.append(f"{ref}: header does not say this is one solution "
                                f"among several")
            if not any("Configuration. Run this first" in source(c)
                       for c in scells if c["cell_type"] == "code"):
                problems.append(f"{ref}: does not repeat the lesson's setup cell")
            if not (20 <= len(scells) <= 40):
                problems.append(f"{ref}: {len(scells)} cells, outside 20-40")

            for j, c in enumerate(scells):
                if c["cell_type"] == "code":
                    if c.get("outputs"):
                        problems.append(f"{ref}: cell {j} has committed outputs")
                    if c.get("execution_count") is not None:
                        problems.append(f"{ref}: cell {j} has an execution_count")

            n_code = sum(1 for c in scells if c["cell_type"] == "code")
            print(f"  ok    {ref:<34} {len(scells):>3} cells "
                  f"({n_code} code)  {len(headings)} solutions")

    print()
    print(f"{len(lessons)} lesson(s), {checked} referenced solutions notebook(s)")
    for item in problems:
        print(f"  PROBLEM  {item}")
    print(f"\n{len(problems)} problem(s)")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
