"""Build 06_generation_fundamentals.ipynb.

Derived from the source DLI course `S-OV-57-V1`, notebook 03, sections 1 and 2
(cells 3-11): environment, the structured-prompt helpers, text2video and the
`create_payload` pattern. The examples and the cookbook assets are preserved.

What this lesson adds, because the source has none of it:

* diffusion taught from zero with a toy denoiser the learner trains and samples
  in the notebook, so `num_steps`, `guidance`, `shift` and `seed` are things
  they have *seen* rather than parameters they have been handed;
* the latent-space arithmetic behind `estimate_generation_cost`;
* measurement with warm-up, synchronisation and separation of load from compute;
* calibration of units-per-second on the learner's own machine, which every
  later lesson in Module 2 spends against.

What it corrects: the source pins `CUDA_VISIBLE_DEVICES` to the second GPU
(there is only one here, and that hides it), hard-codes `/dli/task`, buries
resolution and frame count inside a `FIXED_SAMPLING` constant, and states that
Cosmos3-Nano is gated. It is not; only the guardrail is.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 06 — Generation fundamentals")

# =====================================================================
# Title and objectives
# =====================================================================
nb.md("""
# Lesson 06 — Generation fundamentals

**What you will build.** A working mental model of diffusion that you built by
training one yourself, your first text-to-image and text-to-video outputs from
Cosmos 3, and `outputs/06/calibration.json` — a measured constant that turns
`estimate_generation_cost()` from a relative number into a real time prediction
for *your* H100. Lessons 07, 08 and 09 all spend against that calibration.

| | |
|---|---|
| **Time** | ~2 hours, of which roughly half is unattended generation |
| **GPU** | 1 × H100 80 GB. **Nothing else may hold the card** — stop the Reasoner NIM first. |
| **Downloads** | None if you completed Lesson 01. Otherwise Cosmos3-Edge, ~9.1 GB, plus first-run auxiliaries (guardrail 3.63 GB, Wan2.2 VAE 2.82 GB, Qwen3Guard 1.52 GB). The notebook inspects your cache and tells you the size before it pulls anything. |
| **Prerequisites** | Lesson 01. Module 1 is *not* required. |

Lesson 01 gave you one image and one paragraph about diffusion. This lesson
gives you the mechanism, and then the cost of the mechanism in seconds and
gigabytes — which is the only currency that matters when you have one GPU.
""")

nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Implement** a working diffusion model from scratch in a few dozen lines,
   train it, and sample from it — in one dimension, with no Cosmos involved.
2. **Predict** the direction and rough size of the effect of `num_steps`,
   `guidance`, `shift` and `seed` before running anything, and check yourself
   against a measurement.
3. **Explain** classifier-free guidance, including what the "free" refers to and
   why it costs you a second forward pass per step anyway.
4. **Compute** the latent token count for a generation job by hand — from the
   VAE's 8× spatial and 4× temporal compression plus 2×2 patchification — and
   reconcile it with `estimate_generation_cost()`.
5. **Author** a structured JSON prompt field by field, and apply the right
   negative prompt for the mode being run.
6. **Measure** a generation run correctly, separating model load from compute
   and sampling device VRAM rather than guessing it, then **calibrate**
   units-per-second for this machine.
7. **Diagnose** a CUDA out-of-memory failure from its traceback and walk the
   single-GPU escalation ladder, naming the rungs that do not exist on one GPU.
""")

# =====================================================================
# Conceptual foundation — diffusion from zero
# =====================================================================
nb.md("""
## What a diffusion model actually is

Forget images for a moment. Everything in this section happens in one dimension,
and one dimension is something you can plot.

Suppose you have a pile of numbers drawn from some distribution you care about —
the *data distribution* — and you want a machine that produces fresh numbers from
that same distribution. Diffusion gets there in a way that looks absurd until
you watch it work.

**Step one: destroy the data on purpose.** Take a data point $x_0$ and mix it
with random noise, a little at first and then more and more:

$$x_t = \\sqrt{\\bar\\alpha_t}\\,x_0 + \\sqrt{1-\\bar\\alpha_t}\\,\\varepsilon,
\\qquad \\varepsilon \\sim \\mathcal{N}(0, 1)$$

$\\bar\\alpha_t$ starts near 1 (barely any noise) and decays toward 0 (almost
pure noise) as $t$ runs from 0 to $T$. This is the **forward process**. It has
no parameters and nothing is learned; it is a fixed recipe for ruining data.

By $t = T$ every trace of the original is gone and $x_T$ is indistinguishable
from a sample of pure Gaussian noise. That is the point. Pure Gaussian noise is
something you can generate for free, anywhere, at any time.

**Step two: learn to undo one step of it.** Train a network $\\varepsilon_\\theta$
that, given a noisy $x_t$ and the noise level $t$, predicts *which noise was
added*. That is plain supervised regression: you made the noise yourself, so you
have the label.

**Step three: sample.** Start from pure noise. Ask the network what noise it
thinks is in there. Remove some of it. Ask again at a slightly lower noise
level. Repeat. After $N$ iterations you are holding a number that looks as
though it came from the data distribution — but it did not. You built it out of
noise.

That loop, run on a 16-times-compressed video latent instead of a single number,
is Cosmos 3.

The data below is deliberately obvious: two tight bumps, one at $-2$ and one at
$+2$. If diffusion works, a trained model will produce numbers near $-2$ and
$+2$ and almost nothing in between. Watch the forward process destroy them.
""")

nb.code('''
import json
import subprocess
import time

import numpy as np

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None
    print("matplotlib is not installed — the plots below will be skipped.")

rng = np.random.default_rng(0)

# The data: two classes, class 0 near -2 and class 1 near +2.
N_DATA = 4096
labels_np = rng.integers(0, 2, size=N_DATA)
x0_np = np.where(labels_np == 0,
                 rng.normal(-2.0, 0.30, N_DATA),
                 rng.normal(+2.0, 0.30, N_DATA))

# The forward process: T noise levels, from "barely noisy" to "pure noise".
#
# The 0.06 upper end matters and is not arbitrary. Sampling starts from pure
# N(0,1) noise, so the schedule must actually GET there: if abar at the last
# step is still, say, 0.13, then x_T retains a third of the signal amplitude and
# starting from pure noise is starting from the wrong distribution. The samples
# then come out systematically shrunk toward zero. This is a real and published
# flaw in common diffusion schedules, not a quirk of this toy — check
# `abar[-1]` below and see how close to zero it is.
T = 200
betas = np.linspace(1e-4, 0.06, T)
abar = np.cumprod(1.0 - betas)          # alpha-bar in the equation above

print(f"data      : {N_DATA} samples, modes at -2 and +2")
print(f"schedule  : T={T} levels, abar[0]={abar[0]:.4f} -> abar[{T-1}]={abar[-1]:.5f}")
print(f"at t=0     the signal keeps {abar[0] ** 0.5:.3f} of its amplitude")
print(f"at t={T-1}   the signal keeps {abar[-1] ** 0.5:.3f} of its amplitude")

if plt is not None:
    shown = [0, 30, 60, 100, T - 1]
    fig, axes = plt.subplots(1, len(shown), figsize=(2.8 * len(shown), 2.4), sharey=True)
    for ax, t in zip(axes, shown):
        xt = abar[t] ** 0.5 * x0_np + (1 - abar[t]) ** 0.5 * rng.normal(size=N_DATA)
        ax.hist(xt, bins=70, range=(-5, 5), color="#1971c2")
        ax.set_title(f"t = {t}\\nabar = {abar[t]:.3f}", fontsize=9)
        ax.set_xlabel("x")
    axes[0].set_ylabel("count")
    fig.suptitle("Forward process: two modes dissolving into one Gaussian", fontsize=10)
    plt.tight_layout()
    plt.show()
''')

nb.md("""
Read the panels left to right. At $t=0$ the two modes are crisp. By $t=60$ they
have merged into one lump. By $t=199$ you are looking at a standard normal and
there is no way to tell which mode any particular sample came from.

That last panel is where sampling *starts*. The model's whole job is to walk it
back to the left.

### Training the denoiser

The network is small on purpose: two hidden layers, 128 units. Its inputs are
the noisy value $x_t$, the noise level $t$ scaled to $[0,1]$, and a **class
label** — 0, 1, or a third value meaning "no label given". Its output is one
number: its guess at the noise that was added.

The class label is what makes guidance possible later, and the way it is trained
is the whole trick. During training the label is **randomly replaced by the
"no label" token 15% of the time**. So one set of weights learns two jobs at
once: denoising when it knows the class, and denoising when it does not. That is
the "free" in *classifier-free guidance* — you get an unconditional model for
free, without training a separate classifier, because you dropped the label
sometimes.

This trains on CPU in well under a minute. Nothing is downloaded and no GPU is
involved; it is deliberately a toy you can read end to end.
""")

nb.code('''
import torch
import torch.nn as nn

torch.manual_seed(0)

NULL_LABEL = 2          # index 2 means "no class was given"


class TinyDenoiser(nn.Module):
    """Predicts the noise in x_t, given the noise level and (maybe) a class."""

    def __init__(self, hidden: int = 128):
        super().__init__()
        self.label_emb = nn.Embedding(3, hidden)     # classes 0, 1, and NULL_LABEL
        self.net = nn.Sequential(
            nn.Linear(hidden + 2, hidden), nn.SiLU(),
            nn.Linear(hidden, hidden), nn.SiLU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, x, t_frac, y):
        return self.net(torch.cat([x, t_frac, self.label_emb(y)], dim=1))


model = TinyDenoiser()
opt = torch.optim.Adam(model.parameters(), lr=2e-3)

x0_t = torch.tensor(x0_np, dtype=torch.float32).unsqueeze(1)
y_t = torch.tensor(labels_np, dtype=torch.long)
abar_t = torch.tensor(abar, dtype=torch.float32)

losses = []
train_start = time.perf_counter()
for step in range(3000):
    idx = torch.randint(0, N_DATA, (256,))
    xb, yb = x0_t[idx], y_t[idx]
    # Drop the label 15% of the time. This is what buys the unconditional model.
    yb = torch.where(torch.rand(256) < 0.15, torch.full_like(yb, NULL_LABEL), yb)

    t = torch.randint(0, T, (256,))
    a = abar_t[t].unsqueeze(1)
    eps = torch.randn_like(xb)
    xt = a.sqrt() * xb + (1 - a).sqrt() * eps           # the forward process

    loss = ((model(xt, (t.float() / T).unsqueeze(1), yb) - eps) ** 2).mean()
    opt.zero_grad()
    loss.backward()
    opt.step()
    losses.append(loss.item())

print(f"trained in {time.perf_counter() - train_start:.1f} s on CPU")
print(f"loss: first 100 mean {np.mean(losses[:100]):.4f} -> "
      f"last 100 mean {np.mean(losses[-100:]):.4f}")
''')

nb.md("""
### Sampling: the loop that makes everything

The sampler is short enough to read line by line, and every line has a
counterpart in the Cosmos 3 pipeline.

```
x = random noise                          <- `seed` decides exactly which noise
for t in a decreasing schedule:           <- `num_steps` decides how many entries
    eps_cond   = model(x, t, class)       <- the prompt-conditioned prediction
    eps_uncond = model(x, t, NO_LABEL)    <- the same weights, prompt withheld
    eps = eps_uncond + w * (eps_cond - eps_uncond)   <- `guidance` = w
    x0_hat = (x - sqrt(1-abar_t) * eps) / sqrt(abar_t)   <- implied clean sample
    x = step toward the next, lower noise level
return x
```

Two things to notice now, because they explain most of what you will measure
later.

**The steps are sequential.** Step $k+1$ needs the output of step $k$. They
cannot be parallelised; more steps is more wall clock, close to linearly.

**Guidance costs a second forward pass.** `eps_cond` and `eps_uncond` are two
separate evaluations of the network. Every diffusion sampler you run with
guidance enabled is doing roughly twice the compute per step that the arithmetic
suggests. "Free" refers to not needing a separate classifier at *training* time.
It is not free at inference.
""")

nb.code('''
@torch.no_grad()
def sample(n=2000, cls=1, n_steps=50, guidance=1.0, seed=0, shift=1.0):
    """Sample from the toy model. Deterministic given `seed` (DDIM, eta=0).

    guidance == 0 -> unconditional; == 1 -> plain conditional;
    > 1 -> extrapolate away from the unconditional prediction.
    """
    gen = torch.Generator().manual_seed(seed)
    x = torch.randn(n, 1, generator=gen)

    # Where the steps land on the noise schedule. `shift` bends the spacing.
    u = np.linspace(1.0, 0.0, n_steps)
    u = shift * u / (1.0 + (shift - 1.0) * u)
    ts = np.clip((u * (T - 1)).round().astype(int), 0, T - 1)

    y_c = torch.full((n,), cls, dtype=torch.long)
    y_n = torch.full((n,), NULL_LABEL, dtype=torch.long)

    for i, t in enumerate(ts):
        tf = torch.full((n, 1), float(t) / T)
        eps = model(x, tf, y_c)
        if guidance != 1.0:
            eps_u = model(x, tf, y_n)
            eps = eps_u + guidance * (eps - eps_u)
        a_t = float(abar[t])
        x0_hat = (x - (1 - a_t) ** 0.5 * eps) / a_t ** 0.5
        a_prev = float(abar[ts[i + 1]]) if i + 1 < len(ts) else 1.0
        x = a_prev ** 0.5 * x0_hat + (1 - a_prev) ** 0.5 * eps
    return x.squeeze(1).numpy()


def on_mode(samples, target=2.0, tol=0.9):
    """Fraction of samples within `tol` of the requested mode."""
    return float(np.mean(np.abs(samples - target) < tol))


REAL_CLASS1 = x0_np[labels_np == 1]


def w1(samples, real=None):
    """Wasserstein-1 distance to the real data. 0 = the distributions match.

    In one dimension this is just the mean absolute gap between the two sorted
    samples, which is why it is worth using here: it is three lines, it has no
    free parameters, and unlike "is the mean right" it notices when a sampler
    lands on the mode with far too little spread.
    """
    real = REAL_CLASS1 if real is None else real
    n = min(len(samples), len(real))
    idx_a = np.linspace(0, len(samples) - 1, n).astype(int)
    idx_b = np.linspace(0, len(real) - 1, n).astype(int)
    return float(np.mean(np.abs(np.sort(samples)[idx_a] - np.sort(real)[idx_b])))


baseline = sample(n_steps=50, cls=1, guidance=1.0, seed=0)
print("class 1 requested (true mode +2.000, true sd 0.300)")
print(f"  mean {baseline.mean():+.3f}   sd {baseline.std():.3f}   "
      f"on-mode {on_mode(baseline):.1%}   W1 {w1(baseline):.4f}")

if plt is not None:
    fig, ax = plt.subplots(figsize=(6, 2.6))
    ax.hist(x0_np[labels_np == 1], bins=60, range=(-4, 4), alpha=.55,
            label="real data (class 1)", color="#868e96")
    ax.hist(baseline, bins=60, range=(-4, 4), alpha=.65,
            label="generated", color="#1971c2")
    ax.set_xlabel("x")
    ax.legend(fontsize=8)
    ax.set_title("50 steps, guidance 1.0 — generated against real", fontsize=10)
    plt.tight_layout()
    plt.show()
''')

nb.md("""
The generated histogram should sit on top of the real one, near $+2$, with
almost nothing near $-2$. If it does: you have trained and sampled a diffusion
model. The rest of this lesson is that same loop with a much larger network and
much larger tensors.

Now turn the knobs.

### `num_steps` — how many nudges

Fewer steps means each one has to move further, and a big move made from a rough
estimate is a worse move. But the *way* it goes wrong is not what most people
guess, so commit to a prediction before you look: at two steps, do you expect
samples scattered all over the place, or samples piled up somewhere?

Watch the `sd` column, and watch `W1` — the Wasserstein-1 distance between the
generated samples and the real data, which is zero when the two distributions
match and grows when they do not.
""")

nb.code('''
step_rows = []
for n_steps in (2, 4, 8, 16, 32, 64, 128):
    s = sample(n_steps=n_steps, cls=1, guidance=1.0, seed=0)
    step_rows.append({"num_steps": n_steps, "mean": float(s.mean()),
                      "sd": float(s.std()), "w1": w1(s)})

print(f"{'steps':>6} {'mean':>8} {'sd':>7} {'W1':>9}     (true mean +2.000, sd 0.300)")
for r in step_rows:
    print(f"{r['num_steps']:>6} {r['mean']:>+8.3f} {r['sd']:>7.3f} {r['w1']:>9.4f}")

if plt is not None:
    fig, axes = plt.subplots(1, 2, figsize=(10, 2.7))
    axes[0].plot([r["num_steps"] for r in step_rows],
                 [r["w1"] for r in step_rows], "o-", color="#1971c2")
    axes[0].set_ylabel("W1 distance to real data\\n(lower is better)")
    axes[1].plot([r["num_steps"] for r in step_rows],
                 [r["sd"] for r in step_rows], "o-", color="#5f3dc4")
    axes[1].axhline(REAL_CLASS1.std(), ls="--", lw=1, color="#495057",
                    label="true spread")
    axes[1].set_ylabel("sample spread")
    axes[1].legend(fontsize=8)
    for ax in axes:
        ax.set_xscale("log", base=2)
        ax.set_xlabel("num_steps")
        ax.grid(alpha=.3)
    fig.suptitle("Quality against steps: diminishing returns", fontsize=10)
    plt.tight_layout()
    plt.show()
''')

nb.md("""
Two things to read out of that.

**Few steps do not miss the mode — they collapse onto it.** At two steps the
mean is close to correct and the spread is a fraction of the truth. A
deterministic sampler taking enormous strides is strongly mode-seeking; it finds
the high-probability region and produces almost nothing else. Translated to
images, that is why very-low-step output looks smooth, generic and
interchangeable rather than wrong. It is a **diversity** failure before it is an
accuracy failure, and if you evaluate with a metric that only asks "is this a
plausible sample" you will not see it at all.

**The W1 curve falls steeply and then flattens.** That shape is the most useful
single thing to know about `num_steps`: past the knee you are paying linearly in
time for an improvement you cannot see. Where the knee sits depends on the model
and the sampler, and finding it for Cosmos 3 on your machine is this lesson's
first exercise.

If your numbers come out differently — the network you just trained is not a
perfect denoiser, and yours had thirty seconds of training — that is a result,
not a fault. Write down what you got.

### `guidance` — how hard to push toward the prompt

The blend again:

$$\\varepsilon = \\varepsilon_{\\text{uncond}}
   + w\\,(\\varepsilon_{\\text{cond}} - \\varepsilon_{\\text{uncond}})$$

* $w = 0$ — ignore the class entirely. You get the whole data distribution: both
  modes.
* $w = 1$ — the plain conditional prediction. Correct, but the two predictions
  are similar early in sampling, so the pull toward the class is gentle.
* $w > 1$ — **extrapolate**. Take the direction that distinguishes "class 1"
  from "anything at all", and travel further along it than the model actually
  predicted.

That last one is worth staring at. Nothing guarantees the extrapolated point is
still on the data distribution, and at large $w$ it is not. In images this shows
up as over-saturated colour, crushed contrast and a plasticky look. In a
one-dimensional toy it shows up as the mean overshooting past $+2$ and the
spread collapsing — the same failure, stripped of the photography.

Watch the `wrong mode` column especially. At $w = 0$ roughly half the samples
should land near $-2$, because with the label switched off the model is sampling
the *whole* data distribution and half of it is class 0. That column is the
clearest evidence in this notebook that the conditioning is real and that an
unconditional model genuinely lives inside the same weights.
""")

nb.code('''
guide_rows = []
for w in (0.0, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    s = sample(n_steps=50, cls=1, guidance=w, seed=0)
    guide_rows.append({"guidance": w, "mean": float(s.mean()), "sd": float(s.std()),
                       "wrong_mode": float(np.mean(s < 0)), "on_mode": on_mode(s),
                       "w1": w1(s)})

print(f"{'w':>5} {'mean':>8} {'sd':>7} {'wrong mode':>11} {'on-mode':>9} {'W1':>9}")
for r in guide_rows:
    print(f"{r['guidance']:>5.1f} {r['mean']:>+8.3f} {r['sd']:>7.3f} "
          f"{r['wrong_mode']:>10.1%} {r['on_mode']:>8.1%} {r['w1']:>9.4f}")
print()
print("true mode +2.000, true sd 0.300")
print()
print("Read the W1 column as a U. It is worst at w=0 (the model ignored the")
print("class), best somewhere near w=1, and worsens again as w grows — the")
print("samples become MORE recognisably class 1 and LESS like the real data at")
print("the same time. That U is the guidance tradeoff, in one column.")

if plt is not None:
    fig, axes = plt.subplots(1, 2, figsize=(10, 2.8))
    axes[0].plot([r["guidance"] for r in guide_rows],
                 [r["mean"] for r in guide_rows], "o-", color="#c92a2a")
    axes[0].axhline(2.0, ls="--", color="#495057", lw=1, label="true mode")
    axes[0].set_ylabel("sample mean")
    axes[1].plot([r["guidance"] for r in guide_rows],
                 [r["sd"] for r in guide_rows], "o-", color="#5f3dc4")
    axes[1].axhline(0.30, ls="--", color="#495057", lw=1, label="true sd")
    axes[1].set_ylabel("sample spread")
    for ax in axes:
        ax.set_xlabel("guidance w")
        ax.grid(alpha=.3)
        ax.legend(fontsize=8)
    fig.suptitle("Guidance: adherence bought with fidelity and diversity", fontsize=10)
    plt.tight_layout()
    plt.show()
''')

nb.md("""
### `shift` — where the steps land

You have a fixed budget of steps. Should they be spaced evenly along the noise
schedule?

Almost certainly not. Early in sampling — at high noise — the model is deciding
coarse structure: kitchen or road, horizon high or low. Late in sampling it is
deciding texture. Coarse decisions are worth more steps than fine ones,
especially for video and at high resolution where there is more coarse structure
to get wrong.

`shift` re-spaces the timesteps to spend more of them at high noise. Cosmos 3 is
a **flow-matching** model: sampling follows an approximately straight path from
noise to data over a normalised time $u \\in [0,1]$, and the shift is applied to
that time as

$$u' = \\frac{s\\,u}{1 + (s-1)\\,u}$$

With $s = 1$ nothing changes. As $s$ grows the steps bunch toward the noisy end.
The cookbook's shipped generation prompts use `shift: 10.0`, a strong bunching,
and that is a hint about where this model class needs its compute.

The cell below plots where the steps land, and then checks whether the spacing
changes the *result* and not only the schedule — at a small step budget, where
spacing matters most.

Predict first, and notice that you now have two competing arguments. The
heuristic says a strong shift should help. But the justification for the
heuristic was *coarse spatial structure*, and this toy has one dimension and no
spatial structure at all. So which prediction do you back?
""")

nb.code('''
def shifted_times(n_steps, shift):
    u = np.linspace(1.0, 0.0, n_steps)
    return shift * u / (1.0 + (shift - 1.0) * u)


for s in (1.0, 3.0, 10.0):
    u = shifted_times(12, s)
    print(f"shift {s:>4.1f}: {np.mean(u > 0.5):.0%} of steps in the noisy half "
          f"(u > 0.5); first three at u = "
          + ", ".join(f"{v:.3f}" for v in u[:3]))

if plt is not None:
    fig, ax = plt.subplots(figsize=(6.5, 2.6))
    for s, colour in ((1.0, "#495057"), (3.0, "#1971c2"), (10.0, "#c92a2a")):
        ax.plot(range(12), shifted_times(12, s), "o-", color=colour, label=f"shift = {s}")
    ax.set_xlabel("step index")
    ax.set_ylabel("noise level u  (1 = pure noise)")
    ax.grid(alpha=.3)
    ax.legend(fontsize=8)
    ax.set_title("shift bunches the steps toward high noise", fontsize=10)
    plt.tight_layout()
    plt.show()

print()
print(f"{'shift':>6} {'mean':>8} {'sd':>7} {'W1':>9}   (6 steps only)")
for s in (1.0, 2.0, 5.0, 10.0):
    out = sample(n_steps=6, cls=1, guidance=2.0, seed=0, shift=s)
    print(f"{s:>6.1f} {out.mean():>+8.3f} {out.std():>7.3f} {w1(out):>9.4f}")
print()
print("Same model, same seed, same number of forward passes. Only the spacing of")
print("the timesteps changed, and the result changed with it.")
''')

nb.md("""
Read that table honestly, because it probably does not say what the heuristic
predicted.

In this toy, a strong shift at a small budget tends to make things **worse**,
not better — and that is the correct outcome. The argument for spending steps at
high noise was that coarse structure is decided there and coarse structure is
expensive to get wrong. A one-dimensional two-mode distribution has no coarse
structure to allocate steps to: the only thing to decide is roughly where on the
line to land, and that is settled almost immediately. Bunching the remaining
steps into the noisy region starves the low-noise end, where this particular
distribution's remaining work actually is.

So the toy has just shown you the limit of the toy, which is worth more than
another confirmation. `shift` is a **spatial-structure** heuristic, and the
right place to test whether it earns its keep is on Cosmos 3 at a real
resolution — where you can afford it, because it costs nothing.

That is also the general shape of the skill: a small model tells you what the
knobs *do* mechanically. It does not tell you what values to use. Only
measurement on the real model does that, which is what the second half of this
lesson is for.

One claim in there is testable in four seconds: *at a small budget*. If the
argument is right, the penalty for a strong shift should shrink as the budget
grows, because a generous budget can afford to starve the low-noise end a little.
""")

nb.code('''
# Does the shift penalty depend on the step budget, as the argument claims?
print(f"{'steps':>6}" + "".join(f"{'shift ' + str(s):>12}" for s in (1.0, 3.0, 10.0))
      + "   best")
for n in (4, 6, 12, 24, 48):
    scores = {s: w1(sample(n_steps=n, cls=1, guidance=2.0, seed=0, shift=s))
              for s in (1.0, 3.0, 10.0)}
    best = min(scores, key=scores.get)
    print(f"{n:>6}" + "".join(f"{scores[s]:>12.4f}" for s in (1.0, 3.0, 10.0))
          + f"   {best}")
print()
print("W1 is a distance, so lower is better. Read down the columns, not across:")
print("what matters is whether the gap between shift 1 and shift 10 narrows as")
print("the budget grows. If it does, the penalty really is a small-budget effect")
print("and not a blanket verdict on shift.")
''')

nb.md("""
### The toy, mapped onto Cosmos 3

| Toy | Cosmos 3 spec field | What it does | Cost |
|---|---|---|---|
| `seed` argument to `torch.randn` | `seed` | Chooses the starting noise, and therefore the whole sample | None |
| length of `ts` | `num_steps` | Number of sequential denoising iterations | Roughly linear in wall clock |
| `w` in the blend | `guidance` | How far to extrapolate toward the prompt | Already paid; the second forward pass happens regardless |
| `shift` in `shifted_times` | `shift` | Where the steps land on the schedule | None |
| the class label | `prompt` / `negative_prompt` | What the model is being asked for | None directly |
| `x` is one number | `x` is a video latent | See below | Everything |

Five of those six are free or nearly free. The one that costs is the size of the
thing being denoised.
""")

nb.md("""
## Cosmos 3 does not denoise pixels

A 121-frame 832×480 clip is 121 × 832 × 480 × 3 ≈ 145 million numbers. Running
35 sequential denoising steps over 145 million numbers, each step a full
transformer forward pass with attention across all of them, is not something an
H100 will do this afternoon.

So it does not. Cosmos 3 is a **latent** diffusion model. Three compressions sit
between your pixels and the thing the transformer sees:

```
  pixels   121 x 832 x 480 x 3
     |
     |  Wan2.2 VAE encoder:  8x spatial, 4x temporal
     v
  latent    31 x 104 x  60 x C          (121/4 rounded, 832/8, 480/8)
     |
     |  2 x 2 patchify: each 2x2 block of latent pixels -> one token
     v
  tokens    31 x  52 x  30  =  48,360 tokens
```

Net effect: **divide each spatial dimension by 16, divide time by 4**. The
transformer denoises around 48,000 tokens instead of 145 million numbers — a
3,000-fold reduction — and a separate VAE decoder turns the finished latent back
into pixels once, at the end.

Do that arithmetic yourself rather than taking the diagram's word for it. It is
four multiplications and it is the single most useful piece of mental arithmetic
in Module 2.
""")

nb.code('''
# The compression chain, by hand. Plain arithmetic — nothing imported, because
# this is the calculation you want to be able to do in your head later.
FRAMES, WIDTH, HEIGHT = 121, 832, 480
VAE_SPATIAL, VAE_TEMPORAL, PATCH = 8, 4, 2

pixels = FRAMES * WIDTH * HEIGHT * 3

lat_t = -(-FRAMES // VAE_TEMPORAL)          # ceiling division: 121 -> 31
lat_h = HEIGHT // VAE_SPATIAL
lat_w = WIDTH // VAE_SPATIAL

tok_t, tok_h, tok_w = lat_t, lat_h // PATCH, lat_w // PATCH
tokens = tok_t * tok_h * tok_w

print(f"pixels  {FRAMES} x {WIDTH} x {HEIGHT} x 3 = {pixels:>12,}")
print(f"latent  {lat_t} x {lat_w} x {lat_h}       = {lat_t * lat_h * lat_w:>12,}  (before channels)")
print(f"tokens  {tok_t} x {tok_w} x {tok_h}       = {tokens:>12,}")
print()
print(f"reduction from pixels to tokens: {pixels / tokens:,.0f}x")

assert tokens == 48_360, f"expected 48,360 tokens, got {tokens:,}"
print()
print("The assert passed, so the diagram above is arithmetic and not decoration.")
print("Net effect worth memorising: divide each spatial dimension by 16 (8 from")
print("the VAE, 2 more from patchifying), and divide the frame count by 4.")
''')

nb.md("""
Two consequences you will feel all through Module 2:

* **Cost scales with pixel *area*, not with width.** 480p to 720p is 1.5× in
  each dimension and therefore about 2.25× in tokens. This is why dropping a
  resolution tier is the biggest single lever on the OOM ladder.
* **Frames are comparatively cheap.** The 4× temporal compression means four
  extra frames cost one extra latent slice.

Both of those are claims about ratios, so check them as ratios.
""")

nb.code('''
def token_count(frames, width, height):
    """Tokens the transformer actually denoises, from the chain above."""
    return (-(-frames // VAE_TEMPORAL)
            * (height // VAE_SPATIAL // PATCH)
            * (width // VAE_SPATIAL // PATCH))


base = token_count(121, 832, 480)

print("consequence 1 — cost follows pixel AREA, not width")
print(f"{'clip':<22} {'tokens':>9} {'vs 480p':>9}")
for label, (w, h) in {
    "480p  832 x 480": (832, 480),
    "720p 1280 x 720": (1280, 720),
    "256p  448 x 256": (448, 256),
}.items():
    n = token_count(121, w, h)
    print(f"{label:<22} {n:>9,} {n / base:>8.2f}x")
print("  720p is roughly 1.5x in each dimension, so roughly 1.5 x 1.5 = 2.25x the")
print("  tokens. The measured number is a little above that because 832 x 480 is")
print("  not exactly two-thirds of 1280 x 720 — the shape of the rule is right and")
print("  the exact constant is not worth memorising.")
print("  Dropping a resolution tier is the biggest single lever you have.")
print()

print("consequence 2 — frames are comparatively cheap")
print(f"{'frames':>7} {'tokens':>9} {'vs 121f':>9}")
for f in (25, 61, 121, 241):
    n = token_count(f, 832, 480)
    print(f"{f:>7} {n:>9,} {n / base:>8.2f}x")
print("  Doubling the frame count roughly doubles the tokens, but four extra")
print("  frames buy only one extra latent slice, so short clips round up badly.")
''')

nb.md("""
`cosmos_course.config.estimate_generation_cost()` implements exactly this
arithmetic, and you will check it by hand rather than trusting it — right after
the environment is set up, because it needs the package imported.

<div style="border-left:4px solid #a61e4d;padding:.6em 1em;margin:1em 0;background:rgba(128,128,128,.08);border-radius:0 4px 4px 0">

**VRAM budget** — The unit count that function returns is deliberately **not** a
time. Absolute seconds depend on your card, your attention backend, your clocks
and whatever else is running; ratios between two configurations are far more
stable. Later in this lesson you measure one constant — units per second on this
machine — and from then on the estimator predicts real time for you. That
constant is not portable, and the course never quotes one.

</div>
""")

# =====================================================================
# Environment
# =====================================================================
nb.md("""
## Environment and prerequisites

The configuration cell is the same in every lesson: model tier, run mode,
device, output directory. Everything below reads from it.

`MODE="reduced"` keeps every generation in this notebook to a small number of
minutes by cutting frames and steps. `MODE="full"` uses settings you would
actually ship. Start reduced; you can re-run any cell in full mode later by
exporting `COSMOS_COURSE_MODE=full` and restarting the kernel.

The verification cell that follows fails loudly on the things that make the
lesson impossible and warns about the things that only block the generation
half. Failing there costs five seconds; failing forty minutes into a download
costs the afternoon.
""")

nb.code('# This lesson writes to outputs/06/. The setup cell below reads this name.\n'
        '__lesson__ = "06"\n\n' + SETUP_CELL)

nb.code('''
from cosmos_course.measure import MeasurementLog
from cosmos_course.models import Generator, diagnose

cc.require(DEVICE.startswith("cuda"),
           "No CUDA device is visible, so nothing in the second half of this lesson runs.",
           fix="Check `nvidia-smi`, then `torch.cuda.is_available()`, then "
               "`echo $CUDA_VISIBLE_DEVICES` — an inherited value that hides device 0 "
               "is the usual cause on a single-GPU machine.")

generator = Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=True)

# Reduced mode is the default and must stay cheap; full mode is what you ship.
# Every generation below reads these names.
if MODE == "full":
    RES_IMAGE, RES_VIDEO, N_FRAMES, N_STEPS = "480", "480", 121, 35
else:
    RES_IMAGE, RES_VIDEO, N_FRAMES, N_STEPS = "256", "480", 61, 20

RUN_TIMEOUT = 3600 if MODE == "full" else 1800

log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
RUNS = {}

print()
print(f"mode {MODE!r}: image tier {RES_IMAGE}, video tier {RES_VIDEO}, "
      f"{N_FRAMES} frames, {N_STEPS} steps")
print(f"per-run timeout: {RUN_TIMEOUT} s")
''')

nb.md("""
### What is about to be downloaded, before anything is downloaded

The next cell inspects your Hugging Face cache and reports what a run *would*
pull. It downloads nothing itself. If everything is already cached — which it
will be if you finished Lesson 01 — generation enables automatically. If it is
not, you set `ALLOW_DOWNLOAD = True` yourself, having read the size.

After that, check the token arithmetic. `by hand` in the second table is
`(w // 16) * (h // 16) * (frames // 4)` written out explicitly. If it agrees
with `tokens`, you know where the number comes from rather than trusting a
function.
""")

nb.code('''
def hf_cache_dir(repo_id):
    root = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface")) / "hub"
    return root / ("models--" + repo_id.replace("/", "--"))


def dir_size_gb(path):
    path = Path(path)
    if not path.exists():
        return 0.0
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file()) / 1e9


# Set this True only after reading the sizes printed below.
ALLOW_DOWNLOAD = False

repo = cc.MODEL_TIERS[MODEL]["hf_repo"]
cached_gb = dir_size_gb(hf_cache_dir(repo))
needs_checkpoint = cached_gb < 1.0

pending = []
if needs_checkpoint:
    pending.append((repo, cc.MODEL_TIERS[MODEL]["download_gb"]))
for name, size in cc.AUXILIARY_DOWNLOADS_GB.items():
    probe = hf_cache_dir(name) if ("/" in name and " " not in name) else None
    if probe is None or dir_size_gb(probe) < 0.1:
        pending.append((name, size))

print(f"checkpoint {repo}: {cached_gb:.1f} GB already cached")
if pending:
    print(f"\\nA run may download up to {sum(s for _, s in pending):.1f} GB:")
    for name, size in pending:
        print(f"    {size:>6.2f} GB  {name}")
    print("\\nAuxiliary sizes are the published figures; a partial cache means less")
    print("than this in practice. The guardrail is the ONE gated repo in the whole")
    print("Cosmos 3 stack — if you have not accepted its licence, see Lesson 01.")
else:
    print("\\nNothing to download.")

RUN = (not framework_problems) and DEVICE.startswith("cuda") \\
    and (not needs_checkpoint or ALLOW_DOWNLOAD)
print(f"\\ngeneration enabled: {RUN}")
if not RUN:
    print("  Everything above this point still runs. Set ALLOW_DOWNLOAD = True")
    print("  (or fix the framework checkout) to enable the generation cells.")
''')

nb.code('''
CONFIGS = [
    ("256p image, 1 frame",   "256",   1, 20),
    ("256p clip, 61 frames",  "256",  61, 20),
    ("480p clip, 61 frames",  "480",  61, 20),
    ("480p clip, 121 frames", "480", 121, 35),
    ("720p clip, 121 frames", "720", 121, 35),
    ("768p clip, 121 frames", "768", 121, 35),
]

print(f"{'configuration':<24} {'w x h':>11} {'tokens':>9} {'by hand':>9} "
      f"{'units':>13} {'rel':>6}")
for label, res, frames, steps in CONFIGS:
    est = cc.estimate_generation_cost(resolution=res, num_frames=frames,
                                      num_steps=steps, aspect_ratio="16,9")
    w, h = est["width"], est["height"]
    by_hand = (w // 16) * (h // 16) * max(1, frames // 4)
    print(f"{label:<24} {w:>5}x{h:<5} {est['latent_tokens']:>9,} {by_hand:>9,} "
          f"{est['cost_units']:>13,} {est['relative_to_480p_121f_35s']:>6.2f}")

print()
print("'units' is tokens x steps. 'rel' compares against a 480p / 121-frame /")
print("35-step job. Note 480p -> 720p: 1.5x in each dimension, ~2.25x in tokens.")
''')

# =====================================================================
# Structured prompts
# =====================================================================
nb.md("""
## Structured prompts: Cosmos 3 does not want a sentence

Most text-to-image systems take a sentence. Cosmos 3 takes an
**attribute-by-attribute scene description**, serialised as JSON and passed as
the `prompt` string. The cookbook ships several; open one and read what it
actually contains.

Why this shape? Because a world foundation model is being asked for physical
plausibility, not a picture. "A robot in a kitchen" underdetermines the camera,
the lighting, the surfaces, the motion and the physics. The structured form
makes each of those an explicit field you can hold fixed while varying one
other — which is exactly what generating training data requires, and the reason
the ablation exercise at the end of this lesson is possible at all.

Two mechanical details that will bite you if you skip them. The JSON goes into
the spec as a **string**, not as a nested object — the framework's `prompt`
field is typed as text. And compact separators matter a little: whitespace in
the serialised prompt is tokens the text encoder processes for no information.
""")

nb.code('''
prompt_path = cc.asset("prompt_robot_kitchen")
robot_kitchen = json.loads(prompt_path.read_text())

print(f"{prompt_path.name}: {len(json.dumps(robot_kitchen)):,} characters of JSON\\n")


def outline(obj, indent=0, max_depth=2):
    """Print the shape of a nested structure: keys, types, and a value preview."""
    pad = "  " * indent
    if isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(value, (dict, list)) and indent < max_depth:
                kind = "dict" if isinstance(value, dict) else f"list[{len(value)}]"
                print(f"{pad}{key}  ({kind})")
                outline(value, indent + 1, max_depth)
            else:
                text = json.dumps(value)
                print(f"{pad}{key}: {text[:88]}{'...' if len(text) > 88 else ''}")
    elif isinstance(obj, list):
        for i, value in enumerate(obj[:2]):
            print(f"{pad}[{i}]")
            outline(value, indent + 1, max_depth)
        if len(obj) > 2:
            print(f"{pad}... and {len(obj) - 2} more")


outline(robot_kitchen)


def compact(obj):
    """Serialise a structured prompt the way the framework wants it: one string."""
    if isinstance(obj, (str, Path)):
        obj = json.loads(Path(obj).read_text())
    return json.dumps(obj, ensure_ascii=True, separators=(",", ":"))


pretty_len = len(json.dumps(robot_kitchen, indent=2))
compact_len = len(compact(robot_kitchen))
print()
print(f"pretty-printed : {pretty_len:,} characters")
print(f"compact        : {compact_len:,} characters "
      f"({100 * (1 - compact_len / pretty_len):.0f}% smaller)")

# ---------------------------------------------------------------------
# Now write your own. Change the values, keep the field names: you are
# learning what the model is sensitive to, and that needs a fixed schema.
# A good first edit is somewhere concrete and physical — the surface
# material, the time of day, the camera height.
# ---------------------------------------------------------------------
my_prompt = {
    "description": (
        "A wheeled service robot picks a ceramic mug from a wooden bench and "
        "sets it down on a metal tray, in a small workshop."
    ),
    "subjects": [
        {"name": "service robot",
         "appearance": "matte white shell, single articulated arm, black rubber wheels",
         "action": "reaches, closes its gripper on the mug handle, lifts, places"},
        {"name": "ceramic mug",
         "appearance": "plain off-white, slight gloss, no printing",
         "action": "is lifted and set down, remains upright throughout"},
    ],
    "scene": {
        "location": "workshop bench beside a window",
        "surfaces": "scratched wooden bench, brushed steel tray",
        "background": "pegboard with hand tools, slightly out of focus",
    },
    "lighting": "overcast daylight from the window on the left, soft shadows",
    "camera": {"framing": "medium shot, slightly above bench height",
               "motion": "static tripod, no movement"},
    "style": "documentary realism, natural colour, no stylisation",
}

MY_PROMPT_PATH = OUTPUT_DIR / "my_prompt.json"
MY_PROMPT_PATH.write_text(json.dumps(my_prompt, indent=2) + "\\n")
print()
print(f"wrote {MY_PROMPT_PATH}  ({len(compact(my_prompt)):,} characters compact)")
''')

nb.md("""
## Negative prompts

A negative prompt is the conditioning fed to the **unconditional** branch of
classifier-free guidance. Look back at the blend:

$$\\varepsilon = \\varepsilon_{\\text{neg}}
  + w\\,(\\varepsilon_{\\text{cond}} - \\varepsilon_{\\text{neg}})$$

With no negative prompt, $\\varepsilon_{\\text{neg}}$ is the model's prediction
given nothing. With one, it is its prediction given *a description of what you do
not want*, and guidance now extrapolates away from that specific thing rather
than away from the average of everything. So a negative prompt is not a filter
and not a rule; it is a direction, and it has force only in proportion to
`guidance`. At `guidance = 1` it does nothing at all.

The cookbook ships defaults under `negative_prompts/text2video/` and
`negative_prompts/image2video/`. There is **none for `text2image`**, and the
reason is structural rather than an oversight: the shipped negative prompts are
about temporal artefacts — flicker, jitter, warping between frames, morphing
limbs. A single frame has no temporal artefacts to suppress.
""")

nb.code('''
neg_t2v_path = cc.asset_or_none("neg_prompt_t2v")
neg_i2v_path = cc.asset_or_none("neg_prompt_i2v")

for label, path in (("text2video", neg_t2v_path), ("image2video", neg_i2v_path)):
    if path is None:
        print(f"{label:<12}: not on disk. Run scripts/fetch_assets.py to clone "
              f"the cookbook, then re-run this cell.")
        continue
    body = json.loads(path.read_text())
    text = body if isinstance(body, str) else json.dumps(body)
    print(f"{label:<12}: {path.name}")
    print(f"              {text[:220]}{'...' if len(text) > 220 else ''}")
    print()

NEG_T2V = compact(neg_t2v_path) if neg_t2v_path else None
print("text2image  : no negative prompt ships for this mode, by design.")
print("              A still frame cannot flicker.")
''')

# =====================================================================
# Measurement harness and first runs
# =====================================================================
nb.md("""
## Measuring a subprocess, properly

Generation runs as a **separate process** against the framework's own
virtualenv. That is deliberate (Lesson 01 explains why) and it has one
consequence for measurement: `torch.cuda.max_memory_allocated()` in *this*
kernel cannot see a single byte of what that process allocated. Different
process, different allocator.

So we sample the driver instead. A background thread polls `nvidia-smi` and
keeps the maximum. Three caveats, all of which you should state out loud
whenever you report a number obtained this way:

1. It is **device-wide**, not per-process. Anything else on the card is
   included. Stop the NIM first.
2. It is a **sample**, so a peak shorter than the polling interval is invisible.
   The real peak is at least what you measured, never less.
3. It reports the CUDA **reserved pool plus context**, not live tensors — always
   larger than `memory_allocated()` would have said.

The second cell wraps run, measure, verify and log into one call so the pattern
is identical every time. Note the order: **verify before you look**.
`verify_result` reports the exit code as one signal among several, and it exists
because a zero exit code is not evidence of success on this stack. A run can
complete tidily, return 0, write a well-formed MP4 and hand you a blank frame —
because the guardrail rejected the prompt, or the latent went NaN, or the prompt
arrived empty. Lesson 09 makes that happen on purpose.
""")

nb.code('''
import threading


class GpuSampler:
    """Poll device-wide VRAM on a thread; report baseline and peak, in GB."""

    def __init__(self, interval=1.0, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_gb()
            if value is not None:
                self.samples.append(value)

    def __enter__(self):
        self.samples = [self._read_gb() or 0.0]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None

    @property
    def baseline_gb(self):
        return self.samples[0] if self.samples else None
''')

nb.code('''
def run_and_verify(spec, subdir, *, label=None, extra_args=None, timeout=None):
    """Run one job, sample device VRAM, verify the output, record the numbers."""
    label = label or spec.name
    if not RUN:
        print(f"skipped {label!r}: generation is disabled (RUN is False)")
        return None

    problems = cc.validate_spec(spec, strict=False)
    if problems:
        print("spec problems:", problems)

    estimate = spec.cost()
    print(f"{label}: {estimate.get('cost_units', 0):,} cost units "
          f"({estimate.get('width')}x{estimate.get('height')}, "
          f"{spec.num_frames} frames, {spec.num_steps} steps)")

    with GpuSampler() as sampler:
        with cc.timer(label, track_memory=False) as timing:
            result = generator.run(spec, OUTPUT_DIR / subdir,
                                   seed=spec.seed or 0,
                                   extra_args=extra_args,
                                   timeout=timeout or RUN_TIMEOUT)

    RUNS[label] = {
        "seconds": timing.seconds,
        "peak_gb": sampler.peak_gb,
        "baseline_gb": sampler.baseline_gb,
        "cost_units": estimate.get("cost_units"),
        "num_steps": spec.num_steps,
        "resolution": spec.resolution,
        "num_frames": spec.num_frames,
        "result": result,
    }
    log.record(label=label, model=MODEL, mode=MODE,
               **{k: v for k, v in RUNS[label].items() if k != "result"})

    print(f"\\n  wall clock        : {timing.seconds:.1f} s")
    print(f"  device VRAM before: {sampler.baseline_gb:.1f} GB")
    print(f"  device VRAM peak  : {sampler.peak_gb:.1f} GB")
    print()
    cc.verify_result(result)
    return result
''')

nb.md("""
### text2image — the cheapest thing this model does

One frame, small tier, few steps. This is what you use to iterate on a prompt
before spending minutes on video. `num_frames=1` is what makes it an image
rather than a very short video.
""")

nb.code('''
t2i_spec = cc.InferenceSpec(
    model_mode="text2image",
    name="t2i_robot_kitchen",
    prompt=compact(robot_kitchen),
    # No negative_prompt: none ships for text2image, and that is deliberate.
    resolution=RES_IMAGE,
    aspect_ratio="16,9",
    num_frames=1,
    num_steps=N_STEPS,
    guidance=7.0,
    shift=10.0,
    seed=0,
)
print(t2i_spec.describe())
print()

t2i_result = run_and_verify(t2i_spec, "t2i")
if t2i_result is not None and t2i_result.image_path:
    cc.show_image(t2i_result.image_path, width=560,
                  caption=f"text2image, {RES_IMAGE}p, {N_STEPS} steps, seed 0")
''')

nb.md("""
### text2video

Same prompt, same model, many more tokens. This run will dominate the wall clock
in this notebook, so read the cost estimate it prints and compare it against the
image above before it starts.

In reduced mode this is a 480p clip at 61 frames. Expect **minutes, not
seconds** — you are about to measure exactly how many, and quoting a figure here
would be making it up.
""")

nb.code('''
t2v_spec = cc.InferenceSpec(
    model_mode="text2video",
    name="t2v_robot_kitchen",
    prompt=compact(robot_kitchen),
    negative_prompt=NEG_T2V,
    resolution=RES_VIDEO,
    aspect_ratio="16,9",
    num_frames=N_FRAMES,
    fps=24,
    num_steps=N_STEPS,
    guidance=7.0,
    shift=10.0,
    seed=0,
)

t2v_result = run_and_verify(t2v_spec, "t2v")
if t2v_result is not None and t2v_result.video_path:
    cc.show_video(t2v_result.video_path, width=560,
                  caption=f"text2video, {RES_VIDEO}p, {N_FRAMES} frames, {N_STEPS} steps")
''')

nb.checkpoint(
    "Both runs should have printed `all checks passed`. If the image check failed "
    "on autocorrelation you have noise rather than a picture; if it failed on "
    "flatness, look for a guardrail rejection in the run log. Do not continue "
    "until you know which of those it was.",
    '''
for name in ("t2i_robot_kitchen", "t2v_robot_kitchen"):
    entry = RUNS.get(name)
    if entry is None:
        print(f"{name}: did not run")
        continue
    failed = [c.name for c in cc.verify_result(entry["result"], verbose=False)
              if not c.passed]
    print(f"{name}: {entry['seconds']:.1f} s, peak {entry['peak_gb']:.1f} GB, "
          f"{'OK' if not failed else 'FAILED ' + ','.join(failed)}")
''')

# =====================================================================
# Predict-run-explain 1 — steps
# =====================================================================
nb.predict_run_explain(
    predict=(
        "You are about to run the same text2image spec twice, once at 20 "
        "denoising steps and once at 40. Write down the ratio of wall clock "
        "times you expect, then write down whether you expect it to be above or "
        "below 2.0, and why."
    ),
    change=(
        "Nothing — the cell below runs both. Commit your number first, in a "
        "comment at the top of the cell if that helps."
    ),
    explain=(
        "The measured ratio will not be 2.0. Decompose the total into a fixed "
        "part and a per-step part, then name at least three things in the fixed "
        "part."
    ),
    hint=(
        "Every run is a fresh subprocess. Before the first denoising step it "
        "must import torch and the framework, create a CUDA context, read the "
        "checkpoint from disk or page cache, load the guardrail, encode the text "
        "prompt and allocate the latent. Afterwards it must decode the latent "
        "through the VAE, screen the output, and write a file. None of that "
        "scales with num_steps."
    ),
)

nb.code('''
step_measurements = {}
for steps in (20, 40):
    spec = cc.InferenceSpec(
        model_mode="text2image", name=f"steps_{steps}",
        prompt=compact(robot_kitchen),
        resolution=RES_IMAGE, aspect_ratio="16,9",
        num_frames=1, num_steps=steps, guidance=7.0, shift=10.0, seed=0,
    )
    if run_and_verify(spec, "steps", label=f"steps_{steps}") is not None:
        step_measurements[steps] = RUNS[f"steps_{steps}"]["seconds"]
    print("-" * 72)

print(step_measurements or "no measurements: generation is disabled")
''')

nb.md("""
Now solve for the two parts. Two measurements at two step counts give two
equations in two unknowns:

$$t = a + b\\,n \\qquad\\Rightarrow\\qquad
  b = \\frac{t_{40} - t_{20}}{20},\\qquad a = t_{20} - 20b$$

$a$ is the fixed cost of a run on this machine: process start, model load,
guardrail, text encoding, VAE decode, file write. $b$ is the marginal cost of
one denoising step at this geometry.

This decomposition is not a curiosity. It is what makes the calibration below
honest, and it is why a steps sweep that ignores fixed overhead produces a curve
that flatters low step counts.
""")

nb.code('''
FIXED_OVERHEAD_S = None
PER_STEP_S = None

if len(step_measurements) == 2:
    t20, t40 = step_measurements[20], step_measurements[40]
    PER_STEP_S = (t40 - t20) / 20.0
    FIXED_OVERHEAD_S = t20 - 20 * PER_STEP_S
    print(f"t(20 steps) = {t20:8.1f} s")
    print(f"t(40 steps) = {t40:8.1f} s")
    print(f"measured ratio          : {t40 / t20:.2f}x   (not 2.00)")
    print()
    print(f"fixed overhead a        : {FIXED_OVERHEAD_S:8.1f} s")
    print(f"per-step cost b         : {PER_STEP_S:8.3f} s/step at {RES_IMAGE}p, 1 frame")
    print(f"fixed share of the 20-step run: {100 * FIXED_OVERHEAD_S / t20:.0f}%")
    if FIXED_OVERHEAD_S < 0:
        print()
        print("A negative fixed overhead is not physical. It means the 40-step run")
        print("was disproportionately fast — usually because the 20-step run paid a")
        print("first-touch cost (cold page cache, weights read from disk) that the")
        print("second did not. Re-run the previous cell now that both are warm.")
else:
    print("Not enough measurements. This section needs generation enabled.")
''')

# =====================================================================
# Calibration
# =====================================================================
nb.md("""
## Calibrate your machine

`estimate_generation_cost()` returns *units* — latent tokens × steps — and
deliberately refuses to return seconds. One measured constant converts it.

The honest version of that constant divides units by **compute** time rather
than total time, because the fixed overhead you just measured does not scale
with units:

$$\\text{units per second} = \\frac{\\text{cost units}}{t_{\\text{total}} - a}
\\qquad\\Longrightarrow\\qquad
\\hat t = a + \\frac{\\text{units}}{\\text{units per second}}$$

The result goes to `outputs/06/calibration.json`, which Lessons 07, 08 and 09
read. It is specific to this machine, this checkpoint and this software stack.
Copying someone else's is worse than having none, because it looks
authoritative.

The cell also predicts a configuration it has already measured and reports the
error. A model that cannot reproduce its own training data is not a model.
""")

nb.code('''
CALIBRATION_PATH = OUTPUT_DIR / "calibration.json"

rates = []
for label, entry in RUNS.items():
    if not entry.get("cost_units") or not entry.get("seconds"):
        continue
    overhead = FIXED_OVERHEAD_S if (FIXED_OVERHEAD_S or 0) > 0 else 0.0
    compute_s = entry["seconds"] - overhead
    if compute_s <= 0.5:
        continue
    rates.append({"label": label, "cost_units": entry["cost_units"],
                  "total_s": round(entry["seconds"], 2),
                  "compute_s": round(compute_s, 2),
                  "units_per_second": entry["cost_units"] / compute_s})

UNITS_PER_SECOND = None
if rates:
    values = sorted(r["units_per_second"] for r in rates)
    UNITS_PER_SECOND = values[len(values) // 2]        # median, not mean
    print(f"{'run':<22} {'units':>13} {'total s':>9} {'compute s':>10} {'units/s':>12}")
    for r in rates:
        print(f"{r['label']:<22} {r['cost_units']:>13,} {r['total_s']:>9.1f} "
              f"{r['compute_s']:>10.1f} {r['units_per_second']:>12,.0f}")
    print()
    print(f"median units/second on this machine: {UNITS_PER_SECOND:,.0f}")
    spread = (max(values) - min(values)) / UNITS_PER_SECOND
    if spread > 0.4:
        print(f"  Spread across runs is {spread:.0%} of the median. The unit model is")
        print("  first-order only; image and video runs stress different parts of the")
        print("  pipeline. Treat predictions as a factor-of-two guide, and say so.")
else:
    print("No usable measurements yet — calibration needs at least one run.")

CALIBRATION_PATH.write_text(json.dumps({
    "model": MODEL, "mode": MODE,
    "fixed_overhead_s": FIXED_OVERHEAD_S,
    "per_step_s_at_image_tier": PER_STEP_S,
    "units_per_second": UNITS_PER_SECOND,
    "samples": rates,
    "note": ("Measured on this machine only. Units are latent_tokens * num_steps "
             "from cosmos_course.config.estimate_generation_cost."),
}, indent=2) + "\\n")
print(f"\\nwrote {CALIBRATION_PATH}")


def predict_seconds(resolution, num_frames, num_steps, aspect_ratio="16,9"):
    """Predicted wall clock for a job, from this machine's calibration."""
    if not UNITS_PER_SECOND:
        return None
    units = cc.estimate_generation_cost(
        resolution=resolution, num_frames=num_frames,
        num_steps=num_steps, aspect_ratio=aspect_ratio)["cost_units"]
    return (FIXED_OVERHEAD_S or 0.0) + units / UNITS_PER_SECOND


if UNITS_PER_SECOND:
    print()
    for label, res, frames, steps in CONFIGS:
        print(f"  {label:<26} predicted {predict_seconds(res, frames, steps) / 60:>6.1f} min")
    print()
    for label, entry in RUNS.items():
        got = predict_seconds(entry["resolution"], entry["num_frames"], entry["num_steps"])
        if got:
            print(f"  self-check {label:<22} predicted {got:6.1f} s, "
                  f"measured {entry['seconds']:6.1f} s  "
                  f"({100 * (got - entry['seconds']) / entry['seconds']:+.0f}%)")
    print()
    print("Errors above about 30% mean the unit count is missing something for your")
    print("stack. Report that rather than trusting the prediction.")
''')

# =====================================================================
# Predict-run-explain 2 — seed vs guidance
# =====================================================================
nb.predict_run_explain(
    predict=(
        "Three images are about to be generated from one prompt. A is the "
        "reference. B changes only the `seed`. C changes only the `guidance`, "
        "from 7.0 to 2.0. Predict, for each of B and C: will the composition — "
        "where things are, how many of them there are — stay recognisably the "
        "same as A, or change completely?"
    ),
    change=(
        "Nothing to edit; the cell runs all three. Write both predictions down "
        "first."
    ),
    explain=(
        "One of the two changed the picture entirely and the other changed its "
        "character. Explain both using the toy sampler from the top of this "
        "notebook: what does `seed` determine, and at what point in the loop does "
        "`guidance` act?"
    ),
    hint=(
        "In the toy sampler `seed` decides `x` before the loop begins. `guidance` "
        "only rescales a difference between two predictions inside each "
        "iteration. A different starting point is a different journey; a "
        "differently-weighted blend is the same journey walked with a different "
        "stride."
    ),
)

nb.code('''
variants = [
    ("A_reference",     {"seed": 0,     "guidance": 7.0}),
    ("B_seed_only",     {"seed": 12345, "guidance": 7.0}),
    ("C_guidance_only", {"seed": 0,     "guidance": 2.0}),
]

variant_paths, variant_labels = [], []
for name, knobs in variants:
    spec = cc.InferenceSpec(
        model_mode="text2image", name=name, prompt=compact(robot_kitchen),
        resolution=RES_IMAGE, aspect_ratio="16,9",
        num_frames=1, num_steps=max(12, N_STEPS // 2), shift=10.0, **knobs,
    )
    res = run_and_verify(spec, "variants", label=name)
    if res is not None and res.image_path:
        variant_paths.append(res.image_path)
        variant_labels.append(f"{name}  seed={knobs['seed']} g={knobs['guidance']}")
    print("-" * 72)

if variant_paths:
    cc.contact_sheet(variant_paths, cols=3, width=300, labels=variant_labels)
    print(f"{'variant':<18} {'std':>7} {'edge density':>13} {'autocorr':>10}")
    for path, label in zip(variant_paths, variant_labels):
        m = cc.check_image(path).metrics
        print(f"{label.split()[0]:<18} {m.get('std', 0):>7.1f} "
              f"{m.get('edge_density', 0):>13.3f} {m.get('autocorrelation', 0):>10.3f}")
    print()
    print("These are aliveness statistics, not quality scores. Their job is to give")
    print("you something numerical to argue with when your eyes and your prediction")
    print("disagree. Look at the contact sheet as well.")
''')

# =====================================================================
# Debugging lab
# =====================================================================
nb.md("""
## Debugging lab — CUDA out of memory

This is the failure you will hit most often, and it is loud, which makes it a
good one to learn on. Later lessons cover the quiet ones.

### Symptom

You asked for something ambitious — 768p, 189 frames, 50 steps — and forty
seconds in, the process died with a wall of red. The important part is almost
never at the bottom.
""")

nb.code('''
# A Cosmos Framework OOM as it appears in practice, with paths shortened. Read
# it before running anything else: the numbers in the message are the diagnosis.
OOM_TRACEBACK = """
[rank0]: Traceback (most recent call last):
[rank0]:   File "cosmos_framework/scripts/inference.py", line 214, in main
[rank0]:     outputs = pipeline.generate(sample_args)
[rank0]:   File "cosmos_framework/inference/pipeline.py", line 388, in generate
[rank0]:     latent = self.denoise(latent, t, context)
[rank0]:   File "cosmos_framework/models/dit/attention.py", line 141, in forward
[rank0]:     attn = flash_attn_func(q, k, v, causal=False)
[rank0]: torch.OutOfMemoryError: CUDA out of memory. Tried to allocate 9.62 GiB.
[rank0]: GPU 0 has a total capacity of 79.14 GiB of which 6.71 GiB is free.
[rank0]: Process 21877 has 72.42 GiB memory in use. Of the allocated memory
[rank0]: 61.08 GiB is allocated by PyTorch, and 8.94 GiB is reserved by PyTorch
[rank0]: but unallocated. If reserved but unallocated memory is large try setting
[rank0]: PYTORCH_ALLOC_CONF=expandable_segments:True to avoid fragmentation.
E0829 torchrun elastic/agent/server/api.py:733] Worker group failed
"""

print(OOM_TRACEBACK)
''')

nb.md("""
### Hypothesis

Read the numbers, in this order:

* **Tried to allocate 9.62 GiB** — one single allocation, not a slow leak. That
  points at an activation tensor whose size is set by your geometry.
* **6.71 GiB free of 79.14 GiB** — the card is genuinely nearly full. This is
  not a fragmentation-only case.
* **8.94 GiB reserved but unallocated** — but there *is* a fragmentation
  component. Nine gigabytes are held by PyTorch's caching allocator and serving
  no tensor. Had the request been 8 GiB rather than 9.62, rung one alone might
  have saved it.
* **`attention.py` in the frame stack** — attention cost is quadratic in
  sequence length, and sequence length here is the latent token count. This is
  the geometry, not the model weights.

Hypothesis: *the job's token count is too large for this card, and there is
enough fragmentation that the allocator cannot use all of what is free.*

### Diagnostic step

`cosmos_course.models.diagnose()` pattern-matches known failures — check whether
it agrees with you. Then `oom_advice()` prints the escalation ladder in the order
to try it and, given a measured peak, how much headroom you had. Feed it your own
measurement, not a guess.

Pay attention to the section headed **NOT available on one GPU**. NVIDIA's own
ladder in the framework FAQ has six rungs, and two of them — raising the FSDP
shard degree and raising the context-parallel degree — work by splitting state
across *additional ranks*. With one device there is nothing to split onto. Advice
that begins "just increase the shard degree" was written for a node, and
following it here wastes an afternoon.
""")

nb.code('''
for hint in diagnose(OOM_TRACEBACK, returncode=1):
    print(hint)
    print()

measured_peak = max((e["peak_gb"] for e in RUNS.values() if e.get("peak_gb")),
                    default=None)
ladder = cc.oom_advice(measured_peak, model=MODEL,
                       resolution="768", num_frames=189, num_steps=50)

unavailable = [line.strip() for line in ladder
               if "shard degree" in line or "context-parallel" in line]
print()
print(f"rungs the ladder explicitly rules out on this machine: {len(unavailable)}")
for line in unavailable:
    print("   " + line)
''')

nb.md("""
### Repair and verification

Work down the ladder, cheapest first, and use the estimator so you know what
each rung buys *before* spending minutes finding out. The ratio column is the
one to read: resolution is the biggest lever because tokens go as area.

Then re-run, and verify by content. The repair is not finished when the process
exits zero; it is finished when the checks pass.
""")

nb.code('''
LADDER = [
    ("as requested",             "768", 189, 50),
    ("rung 2: 768 -> 480",       "480", 189, 50),
    ("rung 3: 189 -> 61 frames", "480",  61, 50),
    ("rung 4: 50 -> 25 steps",   "480",  61, 25),
]

base = cc.estimate_generation_cost(resolution="768", num_frames=189, num_steps=50)
print(f"{'step down the ladder':<26} {'units':>15} {'vs original':>12} {'predicted':>11}")
for label, res, frames, steps in LADDER:
    est = cc.estimate_generation_cost(resolution=res, num_frames=frames, num_steps=steps)
    seconds = predict_seconds(res, frames, steps)
    print(f"{label:<26} {est['cost_units']:>15,} "
          f"{est['cost_units'] / base['cost_units']:>11.2f}x "
          f"{(f'{seconds / 60:.1f} min' if seconds else 'n/a'):>11}")
print()
print("Note what rung 4 does and does not do. Cutting steps roughly halves wall")
print("clock and barely touches peak memory: per-step activations are transient,")
print("and the peak is set by the largest single tensor, which is a function of")
print("geometry. Steps are a throughput lever, not a memory lever.")

repaired = cc.InferenceSpec(
    model_mode="text2video", name="repaired",
    prompt=compact(robot_kitchen), negative_prompt=NEG_T2V,
    resolution="480", aspect_ratio="16,9", num_frames=61, fps=24,
    num_steps=max(12, N_STEPS), guidance=7.0, shift=10.0, seed=0,
)
print()
print("problems:", cc.validate_spec(repaired, strict=False) or "none")
repaired_result = run_and_verify(repaired, "repaired", label="repaired")
''')

# =====================================================================
# Exercises
# =====================================================================
nb.md("""
## Exercises

Three exercises. The first is a guided modification, the second is a small
engineering task with a test attached, and the third is open enough that two
sensible people would answer it differently.
""")

nb.exercise(
    "foundation",
    "Find the knee in the steps curve — on Cosmos, not on the toy",
    goal=(
        "Produce a quality-proxy-against-time curve for `num_steps` on your own "
        "machine, and identify the point past which extra steps stop paying."
    ),
    instructions=(
        "1. Choose at least five step counts spanning a wide range; 6 through 50 "
        "is reasonable.\n"
        "2. Generate a `text2image` at each, holding prompt, seed, resolution and "
        "guidance fixed. Only `num_steps` may change.\n"
        "3. Record wall clock and a quality proxy for each. "
        "`cc.check_image(path).metrics` gives you `std`, `edge_density` and "
        "`autocorrelation` for free.\n"
        "4. Plot the proxy against **measured compute time** — subtract your "
        "`FIXED_OVERHEAD_S` first — and mark where the curve flattens.\n"
        "5. Write two sentences on whether your proxy tracks what you actually "
        "see. Look at the images. A proxy that disagrees with your eyes is a "
        "finding, not a bug to hide."
    ),
    success=(
        "A plot with at least five points, a stated knee with a step count "
        "attached, and an honest paragraph about the proxy's limits."
    ),
    starter='''
STEP_GRID = [6, 12, 20, 30, 50]
sweep_rows = []

for steps in STEP_GRID:
    # Build one spec per step count. Change ONLY num_steps.
    # spec = cc.InferenceSpec(model_mode="text2image", name=f"knee_{steps}", ...)
    # res = run_and_verify(spec, "knee", label=f"knee_{steps}")
    # metrics = cc.check_image(res.image_path).metrics
    # sweep_rows.append({"steps": steps, "seconds": RUNS[f"knee_{steps}"]["seconds"],
    #                    **metrics})
    pass

print(f"{len(sweep_rows)} point(s) collected")
''',
    hints=[
        "Edge density is the most responsive of the three proxies to step count, "
        "because under-stepped samples are smooth and blobby. Autocorrelation is "
        "nearly saturated on any real image and will look flat — which is itself "
        "worth reporting rather than hiding.\n\n"
        "Subtract `FIXED_OVERHEAD_S` from each wall clock before plotting, or the "
        "curve will look far flatter than the compute actually is and you will "
        "place the knee too low.",
    ],
    solution_ref="solutions/06_solutions.ipynb",
)

nb.exercise(
    "applied",
    "plan_generation(time_budget_s)",
    goal=(
        "Write a function that, given a time budget in seconds, returns the "
        "largest job this machine can finish inside it — and prove it with an "
        "automated check."
    ),
    instructions=(
        "1. Implement `plan_generation(time_budget_s, model=MODEL)` returning a "
        "dict with `resolution`, `num_frames`, `num_steps` and "
        "`predicted_seconds`.\n"
        "2. Use your own calibration. Do not hard-code seconds anywhere.\n"
        "3. Respect the real constraints: `cc.MAX_FRAMES_BY_TIER` for the tier "
        "ceiling and `cc.MODEL_TIERS[MODEL]['max_resolution_tier']` for the "
        "model's. A plan that violates either is a bug, not an aggressive "
        "choice.\n"
        "4. Decide and *write down* your preference order when several plans fit. "
        "Frames before steps? Resolution before frames? There is no right answer; "
        "there is an answer you can defend.\n"
        "5. Run `check_plan_generation()`. Then generate the plan it returns for "
        "a four-minute budget and compare predicted against measured."
    ),
    success=(
        "`check_plan_generation()` prints all-pass, and one real generation run "
        "lands inside its budget. If it does not, you report the miss and its "
        "size rather than adjusting the budget."
    ),
    starter='''
def plan_generation(time_budget_s, model=None):
    """Largest job predicted to finish within time_budget_s on THIS machine."""
    raise NotImplementedError


def check_plan_generation():
    """Automated check. Run it before believing your own function."""
    passed = []
    assert UNITS_PER_SECOND, "no calibration — run the calibration cell first"

    small, large = plan_generation(120), plan_generation(1800)
    assert small["predicted_seconds"] <= 120, "the 120 s plan does not fit 120 s"
    assert large["predicted_seconds"] <= 1800, "the 1800 s plan does not fit 1800 s"
    passed.append("both plans respect their budget")

    small_units = cc.estimate_generation_cost(
        resolution=small["resolution"], num_frames=small["num_frames"],
        num_steps=small["num_steps"])["cost_units"]
    large_units = cc.estimate_generation_cost(
        resolution=large["resolution"], num_frames=large["num_frames"],
        num_steps=large["num_steps"])["cost_units"]
    assert large_units > small_units, "a larger budget must buy a larger job"
    passed.append(f"more budget buys more job ({small_units:,} -> {large_units:,})")

    ceiling = cc.MAX_FRAMES_BY_TIER[large["resolution"]]
    assert large["num_frames"] <= ceiling, f"exceeds the {large['resolution']} ceiling"
    passed.append("frame count respects the tier ceiling")

    tier_max = int(cc.MODEL_TIERS[MODEL]["max_resolution_tier"])
    assert int(large["resolution"]) <= tier_max, f"{MODEL} tops out at {tier_max}p"
    passed.append(f"resolution respects {MODEL}'s {tier_max}p ceiling")

    assert plan_generation(1)["predicted_seconds"] is not None, \\
        "an impossible budget must still return a plan, or raise on purpose"
    passed.append("an impossible budget is handled deliberately")

    for item in passed:
        print(f"  PASS  {item}")
    return passed
''',
    hints=[
        "The search space is small — four resolution tiers, a handful of frame "
        "counts, a handful of step counts. Enumerate it, score every candidate "
        "with `predict_seconds`, drop the ones that do not fit and pick the "
        "maximum by your stated preference. Do not try to invert the cost formula "
        "analytically.",
        "The one-second budget is the interesting test. Returning the smallest "
        "possible job with an honest `predicted_seconds` above the budget is "
        "defensible; so is raising. Silently returning something that does not "
        "fit is not.",
    ],
    solution_ref="solutions/06_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "A prompt-ablation study",
    goal=(
        "Determine which fields of a structured Cosmos 3 prompt the model is "
        "actually sensitive to, with a metric you chose and can defend."
    ),
    instructions=(
        "1. Start from one structured prompt — the cookbook's or your own.\n"
        "2. Pick at least four fields to ablate. For each, produce two or three "
        "variants changing *only* that field: `lighting` from overcast to harsh "
        "midday, `camera.motion` from static to a slow dolly, `scene.surfaces` "
        "from wood to polished steel — plus a control that changes nothing but "
        "the whitespace in the JSON.\n"
        "3. Generate every variant at a fixed seed, resolution and step count. "
        "Anything varying other than the field under test invalidates the "
        "comparison.\n"
        "4. Define your effect metric *before* looking at any output, and write "
        "down why it should detect the change you made. A perceptual distance, a "
        "colour-histogram distance, an edge-map overlap, or the reasoner from "
        "Module 1 scoring adherence are all defensible; guessing is not.\n"
        "5. Establish a **noise floor** by regenerating one variant at several "
        "seeds and measuring the same metric. An effect smaller than the "
        "seed-to-seed variation is not an effect.\n"
        "6. Report a ranked table of fields by effect size with the noise floor "
        "marked on it, plus a paragraph on what the model appears to ignore and "
        "what that implies for using it to make training data."
    ),
    success=(
        "A ranked table over at least four fields, a stated metric with a stated "
        "justification, a measured seed noise floor, and at least one field "
        "honestly reported as having no detectable effect. A study where "
        "everything mattered is a study with no control."
    ),
    starter='''
import copy

BASE_PROMPT = json.loads(cc.asset("prompt_robot_kitchen").read_text())


def set_field(prompt, dotted_path, value):
    """Return a copy of `prompt` with one nested field replaced.

    Supports "lighting" and "camera.motion" style paths. Raise on a path that
    does not exist — a silent no-op here would make a field look insensitive
    when in fact you never changed it.
    """
    out = copy.deepcopy(prompt)
    raise NotImplementedError


ABLATIONS = {
    # "lighting": ["harsh midday sun, hard shadows", "blue hour, low ambient light"],
    # "camera.motion": ["slow dolly forward", "handheld, slight shake"],
}


def effect_metric(path_a, path_b):
    """Distance between two generated images. Justify this choice in writing."""
    raise NotImplementedError
''',
    hints=[
        "The whitespace-only control is the most important variant in the study. "
        "At a fixed seed it must produce an identical image. If it does not, "
        "something in your pipeline is not deterministic and every effect size "
        "you measure afterwards is contaminated — find that first.",
        "Run the noise floor at three or four seeds before running a single "
        "ablation. Knowing the floor changes how many variants per field are "
        "worth generating, and it is the difference between a study and a "
        "collection of anecdotes.",
    ],
    solution_ref="solutions/06_solutions.ipynb",
)

# =====================================================================
# Assessment
# =====================================================================
nb.md("""
## Assessment and reflection

### Knowledge check

1. The forward process has no learned parameters. What, precisely, is learned?
2. Why does sampling start from Gaussian noise rather than from, say, a blank
   grey image? What has to be true of the noise schedule for that to be valid,
   and what did you check to confirm it?
3. What is "free" about classifier-free guidance, and what does it cost you at
   inference time anyway?
4. Your samples at `guidance = 16` look over-saturated and all alike. Explain
   both symptoms with one mechanism.
5. A 121-frame 832×480 clip: how many latent tokens, and which three
   compressions get you there? Do it without running the cell.
6. You halve the width and the height. What happens to the token count, and why
   is it not a factor of two?
7. You doubled `num_steps` and the run took 1.6× as long, not 2×. Where did the
   other 0.4 go?
8. Why does this course refuse to publish a units-per-second figure?
9. An OOM message says 8.9 GiB is "reserved but unallocated" while a 9.6 GiB
   allocation failed. Which rung of the ladder does that point at, and why?
10. Name the two OOM-ladder rungs that do not exist on a single GPU, and say
    what they would have done.

### Practical completion test

1. Train the toy denoiser and produce samples that land on the requested mode.
2. Generate and verify one `text2image` and one `text2video`.
3. Measure a fixed overhead and a per-step cost, and write both down.
4. Produce `outputs/06/calibration.json` with a non-null `units_per_second`.
5. Predict the runtime of a configuration you have not run, then run it and
   report the error as a percentage.
""")

nb.code('''
def lesson_06_complete():
    """Check the artefacts, and the numbers that show the ideas landed."""
    passed, notes = [], []

    assert on_mode(baseline) > 0.5, \\
        "the toy sampler is not landing on the requested mode; re-train it"
    passed.append(f"toy diffusion works: {on_mode(baseline):.0%} of samples on mode, "
                  f"W1 to real data {w1(baseline):.3f}")

    few, many = step_rows[0], step_rows[-1]
    assert few["sd"] < many["sd"], \\
        "few-step sampling should be UNDER-dispersed relative to many-step"
    passed.append(f"low-step under-dispersion reproduced: sd {few['sd']:.3f} at "
                  f"{few['num_steps']} steps vs {many['sd']:.3f} at {many['num_steps']}")

    assert guide_rows[0]["wrong_mode"] > 0.2, \\
        "guidance 0 should sample both modes; the conditioning may not have trained"
    passed.append("the unconditional branch exists (guidance 0 samples both modes)")

    assert MY_PROMPT_PATH.exists(), "you did not write your own structured prompt"
    mine = json.loads(MY_PROMPT_PATH.read_text())
    assert set(mine) >= {"description", "subjects", "scene"}, \\
        "your prompt is missing the core fields"
    passed.append(f"your own structured prompt: {len(compact(mine)):,} characters")

    assert CALIBRATION_PATH.exists(), "outputs/06/calibration.json was not written"
    calib = json.loads(CALIBRATION_PATH.read_text())
    if calib.get("units_per_second"):
        passed.append(f"calibrated at {calib['units_per_second']:,.0f} units/s")
    else:
        notes.append("calibration file exists but is empty — generation was disabled")

    if calib.get("fixed_overhead_s") is not None:
        passed.append(f"fixed overhead measured: {calib['fixed_overhead_s']:.1f} s")
    else:
        notes.append("fixed overhead not measured — run the 20/40-step cell")

    verified = [name for name, e in RUNS.items()
                if e["result"] is not None
                and all(c.passed for c in cc.verify_result(e["result"], verbose=False))]
    if verified:
        passed.append(f"{len(verified)}/{len(RUNS)} runs passed every content check")
    else:
        notes.append("no verified generation runs — generation was disabled")

    for item in passed:
        print(f"  PASS  {item}")
    for item in notes:
        print(f"  ----  {item}")
    return passed, notes


_ = lesson_06_complete()
''')

nb.md("""
### Summary

- **Diffusion**: a fixed forward process destroys data with noise; a learned
  network predicts that noise; sampling starts from noise and iterates the
  prediction backwards. You built one.
- **`num_steps`** is the number of sequential iterations. Cost is close to
  linear; quality has a knee, past which you pay for nothing. Too few steps is a
  **diversity** failure first — samples collapse onto the mode rather than
  missing it.
- **`guidance`** blends a prompt-conditioned prediction with an unconditional
  one from the same weights. "Free" means no separate classifier was trained,
  not that inference is free — two forward passes per step. High values buy
  adherence with fidelity and diversity.
- **`shift`** re-spaces the timesteps toward high noise, where coarse structure
  is decided. It costs nothing and matters most at small step budgets.
- **`seed`** chooses the starting noise and therefore the entire sample.
- Cosmos 3 denoises **latents**: 8× spatial and 4× temporal from the Wan2.2 VAE,
  then 2×2 patchification. Net /16 spatially, /4 temporally. Cost is
  tokens × steps, and tokens go as pixel *area*.
- **Structured JSON prompts** describe a scene attribute by attribute and are
  passed as a compact string. Negative prompts condition the unconditional
  branch; there is none for `text2image`, because a still frame cannot flicker.
- Measure with warm-up and synchronisation, sample device VRAM for a subprocess,
  and separate fixed overhead from per-step compute. Only then does
  units-per-second mean anything.
- Verify every output by content. A zero exit code is not evidence of success.

### Common misconceptions

| Belief | Correction |
|---|---|
| "The model removes noise from an image" | There is no image. It predicts the noise in a latent, and the sampler uses that prediction to take one step. |
| "More steps is always better" | Quality plateaus; time does not. Find the knee and stop. |
| "Too few steps makes bad samples" | It makes *too similar* samples. Each one looks fine; the set has no variety. Measure spread, not plausibility. |
| "`shift=10` is the right value because the cookbook uses it" | It is a spatial-structure heuristic. The one-dimensional toy shows it can hurt. Test it where you will use it. |
| "Classifier-free guidance is free" | Free of a classifier at training time. It costs a second forward pass per step at inference. |
| "Negative prompts block things" | They steer the unconditional branch. At `guidance = 1` they have no effect at all. |
| "720p is 1.5× the cost of 480p" | Tokens go as area: about 2.25×. Check with the estimator before committing. |
| "Doubling steps doubles the time" | Only the compute doubles. Load, guardrail and VAE decode do not. |
| "The estimator predicts seconds" | It predicts units. Seconds need your own calibration, and it is not portable. |
| "Cutting steps fixes an OOM" | It cuts wall clock. Peak memory is set by geometry — drop a resolution tier. |
| "It exited zero, so it worked" | Lesson 09 makes a clean-exit failure happen on purpose. Verify content. |

### Suggested extensions

- Re-train the toy denoiser with the label-drop rate at 0% and at 50% and watch
  what happens to the guidance sweep. The 0% case is the most instructive.
- Add a second data mode very close to the first, and find the guidance value at
  which the model stops being able to tell them apart.
- Run the same Cosmos spec twice with an identical seed and diff the output files
  byte for byte. If they differ, find out which non-determinism is responsible
  before Lesson 07 asks you to rely on reproducibility.

### Mastery checklist

- [ ] I trained a diffusion model and sampled from it.
- [ ] I can state what `num_steps`, `guidance`, `shift` and `seed` each do, and
      which of them are free.
- [ ] I can compute a latent token count by hand and get the estimator's answer.
- [ ] I wrote a structured prompt of my own and know why it is passed as a string.
- [ ] I measured fixed overhead separately from per-step compute.
- [ ] `outputs/06/calibration.json` exists and I know what is in it.
- [ ] I can read an OOM traceback and name the rung it points at.
- [ ] I verified every output by content rather than by exit code.

### Next

Lesson 07 stops asking the model to invent a scene and starts giving it one.
Image-conditioned generation is where this becomes useful for data work, and
where your calibration starts earning its keep — you will plan runs against a
budget rather than starting them and hoping.

## Free what you allocated, and say why

Two reasons this is not housekeeping.

**Matplotlib figures and the toy tensors accumulate in the kernel.** A notebook
that has drawn a dozen figures and kept every array is holding host memory the
next lesson's dataloader would like.

**Lesson 07 runs generation immediately.** Anything this kernel holds on the GPU
is memory the generator subprocess cannot have, and the allocator does not
negotiate: the launch either gets what it asks for or raises. This kernel should
be holding approximately nothing on the card, and the cell below verifies that
rather than assuming it.
""")

nb.code('''
import gc

for name in ("x0_t", "y_t", "abar_t", "opt"):
    globals().pop(name, None)

if plt is not None:
    plt.close("all")
gc.collect()

try:
    import torch as _torch
    if _torch.cuda.is_available():
        _torch.cuda.empty_cache()
        free_b, total_b = _torch.cuda.mem_get_info()
        print(f"device: {free_b / 1e9:.1f} GB free of {total_b / 1e9:.1f} GB")
        print(f"this kernel holds {_torch.cuda.memory_allocated() / 1e9:.2f} GB "
              f"allocated, {_torch.cuda.memory_reserved() / 1e9:.2f} GB reserved")
        if free_b / total_b < 0.6:
            print()
            print("Less than 60% of the card is free while this kernel is barely using")
            print("it. Something else owns the GPU — the Reasoner NIM, or an orphaned")
            print("run. Check `nvidia-smi`; Lesson 07 will OOM otherwise.")
except Exception as exc:
    print(f"could not read device memory: {type(exc).__name__}: {exc}")

print(f"\\noutputs/06 on disk: {dir_size_gb(OUTPUT_DIR):.2f} GB")
print("Video is the bulk of it. scripts/cleanup.sh removes generated media without")
print("touching the Hugging Face cache, which is the expensive part to re-fetch.")
''')

nb.md(FOOTER_MD)

nb.write(ROOT / "06_generation_fundamentals.ipynb")
