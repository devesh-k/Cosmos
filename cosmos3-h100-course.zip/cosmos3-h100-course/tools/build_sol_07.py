"""Build solutions/07_solutions.ipynb — reference answers for Lesson 07."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("07", "Image-conditioned generation",
                      lesson_file="07_generation_conditioned.ipynb")

nb.header(
    "Lesson 07 hands the model a first frame. All three exercises are about what that "
    "frame decides and what it does not. The foundation exercise holds the prompt fixed "
    "and varies only the frame, then asks which property of an image predicts how much "
    "motion you get. The applied one chains reasoner and generator into `animate()`, "
    "which forces a decision about VRAM that Lesson 02 measured. The challenge one builds "
    "an augmentation set and — the part that separates data from decoration — measures "
    "its diversity against a seed-noise baseline."
)

nb.callout(
    "warning",
    "**Generation is off by default.** `ALLOW_GENERATION = False`, exactly as in the "
    "lesson. Every metric, design-cost calculation and diversity comparison below still "
    "runs, against synthetic frames whose answers are known by construction, so the "
    "method is verifiable without a GPU. Nothing produced on that path is a measurement "
    "of Cosmos 3, and every such value is labelled where it appears.",
)

nb.prelude(
    "The lesson's configuration and its measurement helpers: `image_wh`, `nearest_aspect`, "
    "`preservation_profile`, `check_geometry` and the `run_and_verify` harness, all "
    "unchanged so the exercises read against the same names."
)
nb.code(setup_cell("07"))

nb.code('''
import copy
import itertools
import json
import shutil
import subprocess
import threading
import time

import numpy as np

from cosmos_course.config import ASPECT_RATIOS
from cosmos_course.measure import MeasurementLog
from cosmos_course.models import Generator

generator = cc.Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=False)

ALLOW_GENERATION = False           # <- set True on an H100 with the checkpoint
if MODE == "full":
    RES, N_FRAMES, N_STEPS = "480", 121, 35
else:
    RES, N_FRAMES, N_STEPS = "480", 61, 12
RUN_TIMEOUT = 3600 if MODE == "full" else 1800
RUN = ALLOW_GENERATION and (not framework_problems) and DEVICE.startswith("cuda")

CALIB_PATH = cc.OUTPUT_ROOT / "06" / "calibration.json"
CALIB = json.loads(CALIB_PATH.read_text()) if CALIB_PATH.exists() else {}


def predict_seconds(resolution, num_frames, num_steps, aspect_ratio="16,9"):
    """Predicted wall clock from Lesson 06's calibration, or None."""
    ups = CALIB.get("units_per_second")
    if not ups:
        return None
    units = cc.estimate_generation_cost(
        resolution=resolution, num_frames=num_frames, num_steps=num_steps,
        aspect_ratio=aspect_ratio)["cost_units"]
    return (CALIB.get("fixed_overhead_s") or 0.0) + units / ups


log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
RUNS = {}

print(f"mode {MODE!r}: {RES}p, {N_FRAMES} frames, {N_STEPS} steps")
print(f"RUN = {RUN}   calibration from Lesson 06: "
      f"{'present' if CALIB.get('units_per_second') else 'absent'}")
for p in framework_problems:
    print(f"  ! {p}")
''')

nb.code('''
class GpuSampler:
    """Poll device-wide VRAM on a thread; report baseline and peak, in GB."""

    def __init__(self, interval=1.0, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_gb()
            if value is not None:
                self.samples.append(value)

    def __enter__(self):
        self.samples = [self._read_gb() or 0.0]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None


def run_and_verify(spec, subdir, *, label=None, timeout=None):
    """Predict, run, sample VRAM, verify by content, and record."""
    label = label or spec.name
    if not RUN:
        print(f"skipped {label!r}: generation is disabled")
        return None
    problems = cc.validate_spec(spec, strict=False)
    if problems:
        print("spec problems:", problems)
    predicted = predict_seconds(spec.resolution, spec.num_frames or 1,
                                spec.num_steps or 1, spec.aspect_ratio or "16,9")
    with GpuSampler() as sampler:
        with cc.timer(label, track_memory=False) as timing:
            result = generator.run(spec, OUTPUT_DIR / subdir, seed=spec.seed or 0,
                                   timeout=timeout or RUN_TIMEOUT)
    error = (100 * (predicted - timing.seconds) / timing.seconds) if predicted else None
    RUNS[label] = {"seconds": timing.seconds, "peak_gb": sampler.peak_gb,
                   "predicted_s": predicted, "prediction_error_pct": error,
                   "result": result}
    log.record(label=label, model=MODEL, mode=MODE,
               **{k: v for k, v in RUNS[label].items() if k != "result"})
    cc.verify_result(result)
    return result


def compact(obj):
    """Serialise a structured prompt as the single string the framework wants."""
    if isinstance(obj, (str, Path)):
        obj = json.loads(Path(obj).read_text())
    return json.dumps(obj, ensure_ascii=True, separators=(",", ":"))


def image_wh(path):
    from PIL import Image
    with Image.open(path) as im:
        return im.size


def aspect_value(spec_string):
    aw, ah = (float(x) for x in spec_string.split(","))
    return aw / ah


def nearest_aspect(width, height):
    """The accepted aspect string closest to an actual image's shape."""
    target = width / height
    return min(ASPECT_RATIOS, key=lambda a: abs(aspect_value(a) - target))


def read_frame(path, index=0):
    """Return one RGB frame as a numpy array, or None if it cannot be decoded."""
    try:
        import imageio.v3 as iio
        for i, frame in enumerate(iio.imiter(path)):
            if i == index:
                return np.asarray(frame)
    except Exception:
        pass
    try:
        import cv2
        cap = cv2.VideoCapture(str(path))
        cap.set(cv2.CAP_PROP_POS_FRAMES, index)
        ok, frame = cap.read()
        cap.release()
        if ok:
            return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    except Exception:
        pass
    return None


def gray(array_or_path, size=(160, 90)):
    """Grayscale, resized to a common grid so two sources are comparable."""
    from PIL import Image
    img = (Image.open(array_or_path) if isinstance(array_or_path, (str, Path))
           else Image.fromarray(np.asarray(array_or_path).astype(np.uint8)))
    return np.asarray(img.convert("L").resize(size), dtype=np.float64)


def correlate(a, b):
    """Pearson correlation of two equally-shaped arrays. 1.0 = identical."""
    x, y = a.ravel(), b.ravel()
    if x.std() < 1e-6 or y.std() < 1e-6:
        return float("nan")
    return float(((x - x.mean()) * (y - y.mean())).mean() / (x.std() * y.std()))


def preservation_profile(video_path, image_path, indices=(0, 10, 30, 60)):
    """Correlate the conditioning image against frames through the clip."""
    reference = gray(image_path)
    rows = []
    for i in indices:
        frame = read_frame(video_path, i)
        if frame is None:
            continue
        rows.append({"frame": i, "correlation": correlate(reference, gray(frame))})
    return rows


def video_wh(path):
    """Pixel geometry of a video: ffprobe first, a decoded frame second."""
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        try:
            out = subprocess.run(
                [ffprobe, "-v", "error", "-select_streams", "v:0",
                 "-show_entries", "stream=width,height", "-of", "csv=p=0:s=x",
                 str(path)],
                capture_output=True, text=True, timeout=60, check=True).stdout.strip()
            width, height = out.splitlines()[0].split("x")
            return int(width), int(height)
        except Exception:
            pass
    frame = read_frame(path, 0)
    if frame is not None:
        return frame.shape[1], frame.shape[0]
    return None, None


def check_geometry(video_path, image_path, tolerance=0.05):
    """Does the output's aspect match the conditioning image's?"""
    iw, ih = image_wh(image_path)
    vw, vh = video_wh(video_path)
    if not vw or not vh:
        return {"ok": None, "reason": "could not read the output's geometry"}
    source, output = iw / ih, vw / vh
    error = abs(output / source - 1)
    return {"ok": error <= tolerance, "source_wh": (iw, ih), "output_wh": (vw, vh),
            "source_aspect": round(source, 4), "output_aspect": round(output, 4),
            "relative_error": round(error, 4)}


print("helpers ready:", nearest_aspect(1920, 1080), nearest_aspect(1080, 1920))
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Three first frames, one prompt",
    goal="Establish how much of the output is decided by the conditioning frame by "
         "holding everything else constant and changing only the frame.",
    success="Three verified videos, three preservation profiles on one plot, and a "
            "written answer naming a property of the images rather than restating the "
            "result.",
    approach="Derive each aspect ratio from its own image — the one thing that must vary "
             "with the frame — and reduce each profile to a single **decay rate** so "
             "three curves become three comparable numbers.",
)

nb.code('''
FRAMES = ["image_car_driving", "image_humanoid_robot", "image_coastal_road_audio"]
SHARED_PROMPT = {
    "description": "The scene continues naturally for a few seconds.",
    "camera": {"motion": "static, locked off"},
    "style": "documentary realism, natural colour",
}
NEG_I2V = cc.asset_or_none("neg_prompt_i2v")
NEG_I2V = compact(NEG_I2V) if NEG_I2V else None

frame_profiles = {}
for name in FRAMES:
    path = cc.asset_or_none(name)
    if path is None:
        print(f"{name}: missing — run scripts/fetch_assets.py")
        continue
    w, h = image_wh(path)
    aspect = nearest_aspect(w, h)          # hint 1: per-image, not a shared 16,9
    spec = cc.InferenceSpec(
        model_mode="image2video", name=f"frame_{name}",
        prompt=compact(SHARED_PROMPT), negative_prompt=NEG_I2V,
        vision_path=str(path), resolution=RES, aspect_ratio=aspect,
        num_frames=N_FRAMES, num_steps=N_STEPS, seed=0,
    )
    print(f"{name:<28} {w}x{h}  aspect {aspect}")
    result = run_and_verify(spec, "frames", label=f"frame_{name}") if RUN else None
    if result is not None and result.video_path:
        frame_profiles[name] = preservation_profile(result.video_path, path)

print(f"\\n{len(frame_profiles)} profile(s)")
''')

nb.code('''
# PLACEHOLDER PROFILES — invented curves, used only so the analysis below runs.
# They are shaped the way an image2video preservation profile is shaped (starts
# near 1.0 at frame 0, decays), with different decay rates per clip. NOT
# measurements of Cosmos 3.
PLACEHOLDER_PROFILES = {
    "image_car_driving": [{"frame": 0, "correlation": 0.985},
                          {"frame": 10, "correlation": 0.741},
                          {"frame": 30, "correlation": 0.502},
                          {"frame": 60, "correlation": 0.388}],
    "image_humanoid_robot": [{"frame": 0, "correlation": 0.991},
                             {"frame": 10, "correlation": 0.953},
                             {"frame": 30, "correlation": 0.921},
                             {"frame": 60, "correlation": 0.904}],
    "image_coastal_road_audio": [{"frame": 0, "correlation": 0.988},
                                 {"frame": 10, "correlation": 0.867},
                                 {"frame": 30, "correlation": 0.702},
                                 {"frame": 60, "correlation": 0.641}],
}

using_placeholder_profiles = not frame_profiles
profiles = frame_profiles or PLACEHOLDER_PROFILES
if using_placeholder_profiles:
    print("USING PLACEHOLDER PROFILES — invented, not measured.\\n")


def decay_summary(rows):
    """Reduce a profile to comparable numbers: start, end, and drop per frame.

    Three curves on a plot invite an eyeball comparison. Three numbers can be
    ranked, and the ranking is what the written answer has to be about.
    """
    rows = [r for r in rows if r["correlation"] == r["correlation"]]   # drop NaN
    if len(rows) < 2:
        return None
    first, last = rows[0], rows[-1]
    span = max(last["frame"] - first["frame"], 1)
    return {"start": first["correlation"], "end": last["correlation"],
            "total_drop": first["correlation"] - last["correlation"],
            "drop_per_frame": (first["correlation"] - last["correlation"]) / span}


print(f"{'clip':<30}{'r@0':>8}{'r@last':>9}{'drop':>8}{'drop/frame':>13}")
print("-" * 68)
summaries = {}
for name, rows in profiles.items():
    s = decay_summary(rows)
    summaries[name] = s
    if s:
        print(f"{name:<30}{s['start']:>8.3f}{s['end']:>9.3f}"
              f"{s['total_drop']:>8.3f}{s['drop_per_frame']:>13.5f}")

if summaries:
    most = max(summaries, key=lambda k: summaries[k]["total_drop"])
    least = min(summaries, key=lambda k: summaries[k]["total_drop"])
    print(f"\\nmost motion (largest drop) : {most}")
    print(f"least motion (smallest drop): {least}")
''')

nb.code('''
try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

if plt is not None and profiles:
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    for name, rows in profiles.items():
        ax.plot([r["frame"] for r in rows], [r["correlation"] for r in rows],
                "o-", label=name)
    ax.set_xlabel("frame index")
    ax.set_ylabel("correlation with the conditioning image")
    ax.set_ylim(0, 1.02)
    ax.set_title("PLACEHOLDER DATA — not a measurement"
                 if using_placeholder_profiles else "measured on this machine",
                 fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(alpha=.3)
    plt.tight_layout()
    plt.show()
else:
    print("matplotlib not installed; the table above is the plot.")
''')

nb.code('''
# The property that is claimed to predict motion, made checkable in advance.
# The claim: a frame whose subject is MID-ACTION decays fastest. Operationalise
# "mid-action" as motion blur — a moving subject photographed with a real
# shutter is blurred along its direction of travel, and blur shows up as
# reduced high-frequency energy relative to the frame's overall contrast.
def blur_index(path):
    """Low value = blurred (likely mid-action). High = crisp (likely static).

    Variance of the Laplacian, normalised by the image's own contrast so a
    dark frame is not scored as blurry just for being dark.
    """
    g = gray(path, size=(320, 180))
    lap = (-4 * g[1:-1, 1:-1] + g[:-2, 1:-1] + g[2:, 1:-1]
           + g[1:-1, :-2] + g[1:-1, 2:])
    return float(lap.var() / max(g.var(), 1e-6))


predictions = {}
for name in FRAMES:
    path = cc.asset_or_none(name)
    if path is None:
        continue
    predictions[name] = blur_index(path)

if predictions:
    print(f"{'clip':<30}{'blur index':>12}   (lower = more motion blur)")
    for name, value in sorted(predictions.items(), key=lambda kv: kv[1]):
        print(f"{name:<30}{value:>12.4f}")
    ranked_pred = [n for n, _ in sorted(predictions.items(), key=lambda kv: kv[1])]
    ranked_obs = [n for n in sorted(summaries, key=lambda k: -summaries[k]["total_drop"])
                  if n in predictions]
    print(f"\\npredicted most-motion order : {ranked_pred}")
    print(f"observed  most-motion order : {ranked_obs}")
    print("Agreement between these two orders is the test of the claim. "
          "Disagreement is more interesting than agreement — it means the "
          "property is wrong and there is a better one.")
else:
    print("No conditioning images on disk, so the predictor cannot be run. The "
          "claim it encodes is stated in the model answer below and remains a "
          "prediction until you test it.")
''')

nb.model_answer(
    "**Which frame produced the most motion, which the least, and what property of the "
    "image predicts it?**\n\n"
    "The property is **whether the frame contains a subject that is unambiguously "
    "mid-action**, and the reason is mechanical rather than aesthetic.\n\n"
    "`image2video` conditions on one frame and samples a continuation. The model is, in "
    "effect, estimating a distribution over what happens next. A frame of a car on a "
    "highway with a motion-blurred road surface is a frame from the *middle* of an "
    "event: every plausible continuation involves the car moving, because a car that "
    "stops dead is not in the training distribution for that image. A frame of a humanoid "
    "robot standing still in a room is a frame that is *consistent with nothing "
    "happening*, so \"nothing happens\" is a high-probability continuation and the clip "
    "stays close to the conditioning frame. The prompt says \"the scene continues "
    "naturally\" in both cases, and \"naturally\" resolves differently.\n\n"
    "So the ranking should be: `image_car_driving` most motion, `image_coastal_road_audio` "
    "intermediate (a road implies travel, but the frame may be a static vista), "
    "`image_humanoid_robot` least.\n\n"
    "**Could you have predicted it in advance?** Yes, and the cell above tries to, which "
    "is the difference between a prediction and a post-hoc story. The operationalisation "
    "is motion blur: a subject genuinely in motion, photographed with a real shutter, is "
    "blurred along its direction of travel, so the frame's high-frequency energy is "
    "depressed relative to its contrast. That is measurable from the image alone, before "
    "any generation.\n\n"
    "**The honest limits of that predictor**, which matter as much as the claim:\n\n"
    "- It confuses motion blur with *any* blur. A shallow depth of field — which the "
    "shared prompt does not control — scores as motion. A synthetic or rendered frame has "
    "no motion blur at all regardless of what it depicts.\n"
    "- It is global, and motion is usually local. A crisp background with one blurred car "
    "scores mostly on the background.\n"
    "- The stronger predictor is probably semantic rather than photometric: ask the "
    "reasoner from Module 1 \"is the main subject of this image in the middle of an "
    "action? answer yes or no\". That reads the content instead of a proxy for it, costs "
    "one request, and is exactly the tool Module 1 built. It was not used here only "
    "because it needs a NIM, and a predictor that runs without one is more useful in this "
    "notebook.\n\n"
    "**One methodological point worth keeping.** Correlation against the conditioning "
    "frame measures *departure*, not motion. A clip that stays perfectly still but drifts "
    "in colour scores as high motion; a clip in which a subject moves within a fixed "
    "frame scores lower than it should, because most pixels are unchanged. It is the "
    "right first metric because it is free and monotone in roughly the right direction. "
    "If a ranking from it ever surprises you, look at the clip before believing the "
    "number.\n\n"
    "*If the table above came from the placeholder profiles, the ordering is invented. "
    "The claim and its predictor are the deliverable.*"
)

nb.extend(
    "Correlation against frame 0 conflates two things: how far the clip has travelled, "
    "and how *fast*. Adding the frame-to-frame correlation — each frame against its "
    "predecessor rather than against the conditioning image — separates them. A clip with "
    "steady motion shows a low, flat frame-to-frame curve and a steadily falling "
    "profile; a clip that jumps once and then freezes shows one dip and a flat profile "
    "afterwards. Those are very different failures and the current metric scores them "
    "identically. `cc.check_video` already computes a temporal-change statistic for its "
    "own purposes, so the frames are being decoded anyway."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "A caption-to-video pipeline",
    goal="Build `animate(image_path)` — caption an image with the reasoner, convert the "
         "caption into a structured prompt, and return a verified video.",
    success="`animate()` runs end to end on three images without manual intervention, "
            "reports a yield, and its docstring states the VRAM strategy and why.",
    approach="**Take turns, in two phases**: caption every image first with the NIM up, "
             "stop it once, then generate every video. That pays the NIM's start-up cost "
             "once for the whole batch instead of once per image.",
)

nb.code('''
from cosmos_course.models import Reasoner
from cosmos_course.nim import NimConfig, nim_status, start_nim, stop_nim

NIM = NimConfig()
HAVE_DOCKER = shutil.which("docker") is not None
NIM_READY = bool(nim_status(NIM).get("ready")) if HAVE_DOCKER else False

CAPTION_SCHEMA = {
    "subjects": ["list of strings: the main entities, most salient first"],
    "setting": "string: where this is, one sentence",
    "actions": ["list of strings: what happens, in temporal order"],
    "lighting": "string: quality, direction and colour of the light",
    "camera": "string: viewpoint, framing and any camera motion",
}
CAPTION_PROMPT = (
    "Describe this image as a structured scene record.\\n"
    "Reply with JSON only — no prose before it, no prose after it, no code fence.\\n"
    "Use exactly these keys and these types:\\n"
    + json.dumps(CAPTION_SCHEMA, indent=2)
    + "\\nIf a field cannot be determined, use the string \\"unknown\\".")

# A shorter schema for the retry, per hint 1: an unparseable caption is the
# commonest failure and the cheapest to recover from.
SHORT_PROMPT = ('Reply with JSON only: {"subjects": ["..."], "setting": "...", '
                '"actions": ["..."], "lighting": "...", "camera": "..."}')


class CaptionError(RuntimeError):
    """The reasoner answered, and the answer could not be used."""


def caption_image(path, *, fps=4, reasoner=None):
    """Caption one image into a Lesson 03 scene record. Raises on a bad parse.

    Retries ONCE at temperature 0 with a shorter schema before giving up. A
    second failure raises CaptionError rather than returning None, so the
    caller can distinguish "the model could not do this image" from "the NIM
    is down" — which have different fixes.
    """
    if reasoner is None:
        raise CaptionError("no reasoner available")
    for prompt, temperature in ((CAPTION_PROMPT, 0.0), (SHORT_PROMPT, 0.0)):
        text = reasoner.ask(prompt, images=path, max_tokens=1024, seed=0,
                            temperature=temperature)
        try:
            record = reasoner.parse_json(text)
        except ValueError:
            continue
        if isinstance(record, dict) and set(record) & set(CAPTION_SCHEMA):
            return record
    raise CaptionError(f"could not parse a scene record for {Path(path).name} "
                       f"after two attempts")
''')

nb.code('''
UNKNOWNS = {"unknown", "n/a", "none", ""}


def _is_unknown(value):
    if value is None:
        return True
    if isinstance(value, list):
        return not value or all(str(v).strip().lower() in UNKNOWNS for v in value)
    return str(value).strip().lower() in UNKNOWNS


def record_to_prompt(record, *, style="documentary realism, natural colour"):
    """Scene record -> structured generation prompt. Improved from Lesson 03.

    Two changes over the mechanical Lesson 03 mapping, both specific to
    image2video rather than to text2video:

      * `camera.motion` is forced to "static, locked off" unless the caption
        explicitly names movement. The caption describes ONE FRAME, so any
        camera motion in it is inferred rather than observed, and passing an
        invented dolly through as a condition is how you get a clip that drifts
        away from a frame you wanted preserved.
      * `description` is written in the CONTINUOUS aspect ("continues to ...")
        rather than as a list of completed actions, because the model is being
        asked what happens next, not what happened.
    """
    prompt, dropped = {}, []
    for field in CAPTION_SCHEMA:
        if _is_unknown(record.get(field)):
            dropped.append(field)

    subjects = [str(s).strip() for s in (record.get("subjects") or [])
                if str(s).strip() and str(s).strip().lower() not in UNKNOWNS]
    if subjects:
        prompt["subjects"] = [{"name": s} for s in subjects[:4]]
    if not _is_unknown(record.get("setting")):
        prompt["scene"] = {"location": str(record["setting"]).strip()}
    if not _is_unknown(record.get("lighting")):
        prompt["lighting"] = str(record["lighting"]).strip()

    camera_text = "" if _is_unknown(record.get("camera")) else str(record["camera"])
    moving = any(word in camera_text.lower()
                 for word in ("pan", "dolly", "track", "handheld", "zoom", "moving",
                              "orbit", "crane", "tilt"))
    prompt["camera"] = {"framing": camera_text.strip() or "medium shot",
                        "motion": camera_text.strip() if moving else "static, locked off"}

    actions = [str(a).strip().rstrip(".") for a in (record.get("actions") or [])
               if str(a).strip() and str(a).strip().lower() not in UNKNOWNS]
    lead = subjects[0] if subjects else "the scene"
    if actions:
        prompt["description"] = (f"{lead} continues to {actions[0]}"
                                 + (f", then {actions[1]}" if len(actions) > 1 else "")
                                 + ". The motion continues smoothly for a few seconds.")
    else:
        prompt["description"] = (f"{lead} continues naturally for a few seconds, with "
                                 f"no cut and no change of framing.")
    prompt["style"] = style
    return prompt, dropped


# Check the two improvements on records whose correct handling is known.
_still = {"subjects": ["a humanoid robot"], "setting": "a workshop",
          "actions": ["stands still"], "lighting": "soft daylight",
          "camera": "static tripod, medium shot"}
_moving = {"subjects": ["a car"], "setting": "a highway", "actions": ["drives forward"],
           "lighting": "bright daylight", "camera": "handheld, following the car"}
p1, _ = record_to_prompt(_still)
p2, _ = record_to_prompt(_moving)
assert p1["camera"]["motion"] == "static, locked off", p1
assert "handheld" in p2["camera"]["motion"], p2
assert "continues to" in p1["description"]
print("PASS an inferred static camera stays static; an explicitly moving one is kept")
print(json.dumps(p2, indent=2))
''')

nb.code('''
def animate(image_path, *, seed=0, reasoner=None, record=None):
    """Image -> caption -> structured prompt -> verified video.

    VRAM STRATEGY: **take turns, batched.** The Reasoner NIM sizes its KV cache
    against free VRAM at start-up and will hold most of the card (Lesson 02
    measured this), so the generator cannot start while it is up. The two
    options are to cap the NIM's memory or to stop it. This uses stop — but
    NOT inside animate(). Stopping and starting per image would pay a full
    model load per call, which is the trade hint 1 flags. Instead `animate`
    accepts a caption that was produced earlier: `animate_batch` below captions
    every image with the NIM up, stops it once, then generates.

    Why not the cap: capping works (Lesson 02, Exercise 3) but its safe value
    depends on the generation shape, and for a batch that runs unattended the
    consequence of getting it wrong is an OOM part-way through. Taking turns
    has one cost, paid once, and cannot fail that way.

    FAILURE HANDLING, each case distinct:
      * NIM down / no reasoner  -> CaptionError, and no generation is attempted
      * unparseable caption     -> retried once, then CaptionError
      * generation failed       -> a result dict with ok=False and the run's
                                   diagnose() output, NOT an exception, because
                                   one bad image must not stop a batch
    """
    image_path = Path(image_path)
    out = {"image": str(image_path), "caption": None, "prompt": None,
           "video": None, "checks": [], "ok": False, "error": None}
    try:
        out["caption"] = record if record is not None else caption_image(
            image_path, reasoner=reasoner)
    except CaptionError as exc:
        out["error"] = f"caption: {exc}"
        return out

    prompt, dropped = record_to_prompt(out["caption"])
    out["prompt"] = prompt
    out["dropped_fields"] = dropped

    w, h = image_wh(image_path)
    spec = cc.InferenceSpec(
        model_mode="image2video", name=f"animate_{image_path.stem}",
        prompt=compact(prompt), negative_prompt=NEG_I2V,
        vision_path=str(image_path), resolution=RES,
        aspect_ratio=nearest_aspect(w, h), num_frames=N_FRAMES,
        num_steps=N_STEPS, seed=seed,
    )
    if not RUN:
        out["error"] = "generation disabled (RUN is False)"
        return out
    result = run_and_verify(spec, "animate", label=spec.name)
    if result is None or not result.ok:
        out["error"] = "generation: " + "; ".join(
            result.diagnose() if result is not None else ["no result"])
        return out
    out["video"] = str(result.video_path) if result.video_path else None
    out["checks"] = cc.verify_result(result, verbose=False)
    out["ok"] = bool(out["video"]) and all(c.passed for c in out["checks"])
    return out


def animate_batch(image_paths, *, seed=0):
    """Caption everything with the NIM up, stop it once, then generate."""
    image_paths = [Path(p) for p in image_paths]
    records, errors = {}, {}

    if HAVE_DOCKER and (NIM_READY or os.environ.get("NGC_API_KEY")):
        was_up = bool(nim_status(NIM).get("ready"))
        if not was_up:
            start_nim(NIM, wait=True, timeout=2400)
        reasoner = Reasoner(base_url=NIM.base_url)
        for path in image_paths:
            try:
                records[path] = caption_image(path, reasoner=reasoner)
            except CaptionError as exc:
                errors[path] = str(exc)
        # Stopped ONCE, after the whole captioning phase.
        stop_nim(NIM)
        print(f"captioned {len(records)}/{len(image_paths)}; NIM stopped")
    else:
        print("No NIM available; captioning is skipped and animate() will report "
              "a caption error per image rather than pretending.")

    results = []
    for path in image_paths:
        if path in errors:
            results.append({"image": str(path), "caption": None, "prompt": None,
                            "video": None, "checks": [], "ok": False,
                            "error": f"caption: {errors[path]}"})
            continue
        results.append(animate(path, seed=seed, record=records.get(path)))
    return results
''')

nb.code('''
def report_yield(results):
    ok = [r for r in results if r and r.get("ok")]
    print(f"yield: {len(ok)}/{len(results)} passed every check")
    for r in results:
        if not r:
            continue
        if r.get("error"):
            status = r["error"][:56]
        else:
            bad = [c.name for c in r["checks"] if not c.passed]
            status = "OK" if not bad else ",".join(bad)
        print(f"  {Path(r['image']).name:<28} {status}")
    return ok


images = [p for p in (cc.asset_or_none(n) for n in FRAMES) if p is not None]
if images:
    results = animate_batch(images)
    ok = report_yield(results)
    # Every result must carry a distinguishable outcome. This is the assertion
    # that instruction 5 is really asking for: three different failures must
    # not all look like None.
    for r in results:
        assert r["ok"] or r["error"], r
        assert r["error"] is None or ":" in r["error"], r["error"]
    kinds = sorted({(r["error"] or "ok").split(":")[0] for r in results})
    print(f"\\ndistinct outcome kinds observed: {kinds}")
    print("PASS each result reports its own outcome; nothing returns a bare None")
else:
    print("No conditioning images on disk. The pipeline cannot run; "
          "run scripts/fetch_assets.py.")
    results = []
''')

nb.why(
    "**Why batch the phases instead of starting and stopping the NIM inside "
    "`animate()`.** Hint 1 offers per-call start/stop as \"the simplest correct answer\" "
    "and then names its cost: a full model load per image. For three images that is "
    "annoying; for three hundred it is the entire job. Splitting into a caption phase and "
    "a generate phase pays the load once. The cost is that `animate()` is no longer "
    "self-contained — it takes an optional pre-computed `record` — and that is a real "
    "loss of composability, paid deliberately.\n\n"
    "**Why take turns rather than cap.** Both work. Capping (Lesson 02, Exercise 3) keeps "
    "the NIM up and hands the generator a fixed remainder, which is better when you are "
    "alternating frequently. It was rejected here for one reason: the safe cap depends on "
    "the generation shape, and this pipeline runs unattended over a list of images with "
    "different aspect ratios. Getting the cap wrong produces an OOM in the middle of a "
    "batch — the worst possible time. Taking turns cannot fail that way. If your batch "
    "were interleaved rather than phased, capping would be the better answer.\n\n"
    "**Why `record_to_prompt` forces a static camera.** This is the improvement over "
    "Lesson 03's mapping that matters most here, and the reason is specific to "
    "`image2video`. The caption describes a *single frame*. Any camera motion in that "
    "caption is inferred by the captioner, not observed — there is no motion in a still "
    "to observe. Passing an invented \"slow pan left\" through into the generation prompt "
    "adds a condition that fights the conditioning frame, and the result is a clip that "
    "drifts away from the image you were trying to preserve. Forcing static unless the "
    "caption names a specific movement keeps invented conditions out of the prompt. This "
    "generalises: **when converting a description of an observation into an instruction, "
    "drop the fields the observation could not have supported.**\n\n"
    "**Why the three failures return differently.** Instruction 5 says returning `None` "
    "for all three is not handling them, and the underlying reason is that the three have "
    "different *operators*. A NIM that is down is fixed by starting it and re-running "
    "everything. An unparseable caption is fixed by retrying that one image, and it is "
    "retried automatically once before giving up. A failed generation is fixed by looking "
    "at `diagnose()` — OOM, guardrail rejection, and a decode failure need three different "
    "responses. Collapsing them loses the only information that decides what to do next. "
    "Note also that a generation failure does *not* raise: one bad image must not stop a "
    "batch, whereas a missing reasoner should stop it, because every subsequent image "
    "will fail identically.\n\n"
    "**On yield.** `report_yield` counts results where every check in "
    "`cc.verify_result` passed. It deliberately does not count a zero exit code. Under "
    "this pipeline the most likely silent failure is a guardrail rejection producing a "
    "clean exit and a blank clip, and `check_video` catches it by looking at temporal "
    "change."
)

nb.extend(
    "The pipeline currently throws the caption away after building the prompt. Keeping "
    "it — writing `{image, caption, prompt, video, checks}` as one JSONL record per "
    "output — turns the run into a dataset with provenance, and makes the obvious next "
    "experiment cheap: caption the *generated video* with the same schema and compare it "
    "against the caption of the source image. Fields that survive the round trip are "
    "fields the generator actually honoured. That is Lesson 06's ablation study done "
    "with a semantic metric instead of a pixel one, and it needs no extra generations."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "An augmentation set, and an argument for it",
    goal="Turn one source image into N controlled variations that would be defensible as "
         "training data, and write the argument for why the set is diverse enough to be "
         "worth having.",
    success="A generated and screened set with a stated rejection rate, a diversity "
            "measurement compared against a seed-noise baseline, and a written argument "
            "including a limitation you did not have to admit.",
    approach="Cost the design before running it, choose one-factor-at-a-time over the "
             "full factorial for a stated reason, and report every distance as a multiple "
             "of the seed-noise floor.",
)

nb.code('''
# Step 1: the downstream task. Without it "diverse" has no referent.
TASK = ("a forward-collision detector for a dashcam, which must keep working at "
        "dusk, in rain, and when the mount vibrates")
SOURCE_IMAGE = cc.asset_or_none("image_car_driving")

AXES = {
    "lighting": ["overcast, flat daylight",
                 "harsh midday sun, hard shadows",
                 "dusk, low sun behind the camera, long shadows"],
    "camera.motion": ["static, locked off",
                      "slow dolly forward",
                      "handheld, persistent small vibration"],
    "scene.weather": ["dry road, clear air",
                      "light rain, wet reflective road",
                      "fog, visibility under fifty metres"],
}
BASE = {
    "description": "The vehicle ahead continues along the road for a few seconds.",
    "subjects": [{"name": "the vehicle ahead"}, {"name": "the road surface"}],
    "scene": {"location": "a multi-lane road seen from a dashcam",
              "weather": "dry road, clear air"},
    "lighting": "overcast, flat daylight",
    "camera": {"framing": "forward-facing dashcam", "motion": "static, locked off"},
    "style": "documentary realism, natural colour",
}

print(f"task  : {TASK}")
print(f"axes  : {len(AXES)} axes x {[len(v) for v in AXES.values()]} levels")
print(f"source: {SOURCE_IMAGE.name if SOURCE_IMAGE else 'MISSING'}")
''')

nb.code('''
def design_cost(axes, design="full_factorial", *, seeds=1):
    """How many runs, and how long, from Lesson 06's calibration?

    Hint 1: run this BEFORE generating anything. Discovering the cost after
    eleven runs is a worse lesson than discovering it now.
    """
    levels = [len(v) for v in axes.values()]
    if design == "full_factorial":
        runs = 1
        for n in levels:
            runs *= n
    elif design == "ofat":            # one factor at a time, from a baseline
        runs = 1 + sum(n - 1 for n in levels)
    elif design == "latin_square":
        runs = max(levels)
    else:
        raise ValueError(f"unknown design {design!r}")
    runs *= seeds
    per_run = predict_seconds(RES, N_FRAMES, N_STEPS)
    return {"design": design, "runs": runs,
            "seconds": (runs * per_run) if per_run else None,
            "minutes": round(runs * per_run / 60, 1) if per_run else None,
            "per_run_seconds": round(per_run, 1) if per_run else None}


for design in ("full_factorial", "ofat", "latin_square"):
    cost = design_cost(AXES, design)
    per = f"{cost['per_run_seconds']} s" if cost["per_run_seconds"] else "unknown"
    total = f"{cost['minutes']} min" if cost["minutes"] else "unknown (no calibration)"
    print(f"{design:<16} {cost['runs']:>3} runs  x {per:>10}  = {total}")
print()
print("Plus the seed-noise baseline, which is extra runs of the SAME spec:")
print(f"  3 seeds at the baseline: {design_cost({}, 'ofat', seeds=3)['runs']} runs")
''')

nb.model_answer(
    "**Which design, and what it can and cannot identify.**\n\n"
    "**One factor at a time (OFAT), 7 runs**, plus 3 baseline seeds for the noise floor, "
    "for 9 generations in total after de-duplicating the shared baseline.\n\n"
    "*What the full factorial would buy and why it is not worth it here.* 27 runs "
    "identifies **interactions**: whether fog and dusk together are worse than the sum of "
    "fog and dusk separately, which for a collision detector is exactly the case you "
    "worry about. That is genuinely the more informative experiment. It is roughly four "
    "times the GPU time, and — the decisive point — at three levels per axis and one seed "
    "per cell, a 27-run factorial has **one sample per cell**, so any interaction it "
    "finds is confounded with seed noise. You would be measuring interactions at a "
    "signal-to-noise ratio you cannot state. A 27-run factorial with 3 seeds each is 81 "
    "runs, which is the honest version and is out of budget.\n\n"
    "*What OFAT cannot identify:* interactions, at all. Every conclusion is of the form "
    "\"holding everything else at baseline, moving this axis moves the output by X\". If "
    "the axes interact, OFAT will mislead — and for weather and lighting they almost "
    "certainly do, because fog at dusk is not fog plus dusk.\n\n"
    "*The Latin square (3 runs) is rejected outright.* It is the cheapest design and it "
    "confounds main effects with each other by construction. With three axes and three "
    "levels you get three runs in which every axis differs simultaneously, and no "
    "attribution is possible. It is the right design when you have many factors and are "
    "screening for which few matter, and this study has three factors already chosen.\n\n"
    "**So: OFAT, with the interaction limitation stated as a known gap, and a follow-up "
    "2x2 factorial on the two axes most likely to interact (weather and lighting) as the "
    "named next experiment.** That is 4 more runs and answers the question OFAT cannot."
)

nb.code('''
def build_variants(base, axes, design="ofat"):
    """Return [(label, prompt_dict)] for the chosen design."""
    def set_field(prompt, dotted, value):
        out = copy.deepcopy(prompt)
        node, parts = out, dotted.split(".")
        for part in parts[:-1]:
            if part not in node:
                raise KeyError(f"{dotted!r}: no such path")
            node = node[part]
        if parts[-1] not in node:
            raise KeyError(f"{dotted!r}: no such leaf")
        node[parts[-1]] = value
        return out

    variants = [("baseline", copy.deepcopy(base))]
    if design == "ofat":
        for field, levels in axes.items():
            for level in levels[1:]:        # levels[0] IS the baseline
                variants.append((f"{field}={level[:26]}",
                                 set_field(base, field, level)))
    elif design == "full_factorial":
        keys = list(axes)
        for combo in itertools.product(*(axes[k] for k in keys)):
            prompt = copy.deepcopy(base)
            for k, v in zip(keys, combo):
                prompt = set_field(prompt, k, v)
            variants.append(("|".join(v[:12] for v in combo), prompt))
    return variants


variants = build_variants(BASE, AXES, "ofat")
print(f"{len(variants)} variants under OFAT")
for label, _ in variants:
    print(f"  {label}")
assert len(variants) == design_cost(AXES, "ofat")["runs"], "cost model disagrees"
print("\\nPASS the variant list matches the design cost computed before generating")

# Every variant must differ from the baseline in EXACTLY one field.
def _flat(d, prefix=""):
    out = {}
    for k, v in d.items():
        if isinstance(v, dict):
            out.update(_flat(v, f"{prefix}{k}."))
        else:
            out[f"{prefix}{k}"] = json.dumps(v)
    return out


base_flat = _flat(BASE)
for label, prompt in variants[1:]:
    diff = [k for k, v in _flat(prompt).items() if base_flat.get(k) != v]
    assert len(diff) == 1, (label, diff)
print("PASS every OFAT variant differs from the baseline in exactly one field")
''')

nb.code('''
def clip_distance(path_a, path_b, indices=(0, 15, 30, 45)):
    """Mean 1 - correlation between matched frames of two clips.

    The SAME metric is used for the seed baseline and for the axes (hint 2).
    Using a different metric for the floor than for the effect makes the ratio
    meaningless, and it is an easy mistake to make when the floor is measured
    first and the metric is refined afterwards.
    """
    values = []
    for i in indices:
        fa, fb = read_frame(path_a, i), read_frame(path_b, i)
        if fa is None or fb is None:
            continue
        r = correlate(gray(fa), gray(fb))
        if r == r:
            values.append(1.0 - r)
    return float(np.mean(values)) if values else None


def seed_noise_baseline(spec_kwargs, seeds=(0, 1, 2), subdir="augment"):
    """Distance between clips that differ ONLY by seed. The floor for diversity."""
    paths = []
    for seed in seeds:
        spec = cc.InferenceSpec(name=f"noise_seed{seed}", seed=seed, **spec_kwargs)
        result = run_and_verify(spec, subdir, label=f"noise_seed{seed}")
        if result is not None and result.video_path:
            paths.append(result.video_path)
    if len(paths) < 2:
        return None, []
    dists = [clip_distance(a, b) for a, b in itertools.combinations(paths, 2)]
    dists = [d for d in dists if d is not None]
    return (float(np.mean(dists)) if dists else None), dists
''')

nb.code('''
# The measurement, when the GPU is available; a clearly-labelled placeholder
# otherwise so the comparison logic and the write-up still run.
spec_kwargs = dict(model_mode="image2video", prompt=compact(BASE),
                   negative_prompt=NEG_I2V,
                   vision_path=str(SOURCE_IMAGE) if SOURCE_IMAGE else None,
                   resolution=RES, num_frames=N_FRAMES, num_steps=N_STEPS)
if SOURCE_IMAGE is not None:
    sw, sh = image_wh(SOURCE_IMAGE)
    spec_kwargs["aspect_ratio"] = nearest_aspect(sw, sh)

noise_floor, floor_samples = (None, [])
axis_distances, rejected = {}, []

if RUN and SOURCE_IMAGE is not None:
    noise_floor, floor_samples = seed_noise_baseline(spec_kwargs)
    base_result = RUNS.get("noise_seed0", {}).get("result")
    base_path = base_result.video_path if base_result else None
    for label, prompt in variants[1:]:
        spec = cc.InferenceSpec(name=f"aug_{abs(hash(label)) % 10 ** 8}", seed=0,
                                **{**spec_kwargs, "prompt": compact(prompt)})
        result = run_and_verify(spec, "augment", label=spec.name)
        checks = cc.verify_result(result, verbose=False) if result else []
        geometry_ok = True
        if result is not None and result.video_path and SOURCE_IMAGE is not None:
            geometry_ok = bool(check_geometry(result.video_path, SOURCE_IMAGE)["ok"])
        if (result is None or not result.ok or not all(c.passed for c in checks)
                or not geometry_ok):
            rejected.append(label)
            continue
        field = label.split("=")[0]
        axis_distances.setdefault(field, []).append(
            clip_distance(base_path, result.video_path))
else:
    # PLACEHOLDER — invented distances so the comparison and the argument run.
    noise_floor, floor_samples = 0.081, [0.075, 0.084, 0.084]
    axis_distances = {"lighting": [0.311, 0.402], "scene.weather": [0.288, 0.351],
                      "camera.motion": [0.088, 0.099]}
    rejected = ["scene.weather=fog, visibility un"]
    print("PLACEHOLDER DIVERSITY NUMBERS — invented, not measured.\\n")

attempted = len(variants) - 1
print(f"rejection rate: {len(rejected)}/{attempted} "
      f"({len(rejected) / attempted:.0%})" if attempted else "")
for r in rejected:
    print(f"  rejected: {r}")
print()
print(f"seed-noise floor: {noise_floor:.4f} "
      f"(from {len(floor_samples)} pair(s): {[round(v, 3) for v in floor_samples]})")
print()
print(f"{'axis':<18}{'mean distance':>15}{'x floor':>10}  verdict")
print("-" * 62)
for field, dists in sorted(axis_distances.items(),
                           key=lambda kv: -float(np.mean(kv[1]))):
    mean = float(np.mean([d for d in dists if d is not None]))
    ratio = mean / noise_floor
    verdict = ("real diversity" if ratio >= 2 else
               "marginal" if ratio >= 1.3 else
               "NOT diversity — this axis moves clips less than the seed does")
    print(f"{field:<18}{mean:>15.4f}{ratio:>10.2f}  {verdict}")
''')

nb.code('''
weak = [f for f, d in axis_distances.items()
        if float(np.mean([x for x in d if x is not None])) / noise_floor < 1.3]
report_path = OUTPUT_DIR / "augmentation_argument.md"
lines = [
    "# Augmentation set — the argument",
    "",
    ("**Numbers below are PLACEHOLDERS.** No generation ran on this machine. The "
     "design, the cost model, the screening and the comparison against the seed floor "
     "are real; the distances are invented. Set ALLOW_GENERATION = True to replace them."
     if not RUN else "Measured on this machine."),
    "",
    f"**Downstream task.** {TASK}",
    "",
    "## Design",
    "",
    f"One factor at a time over {len(AXES)} axes x 3 levels: "
    f"{design_cost(AXES, 'ofat')['runs']} runs, plus 3 seeds at the baseline for the "
    f"noise floor. The full factorial ({design_cost(AXES, 'full_factorial')['runs']} "
    f"runs) was rejected because at one seed per cell its interaction estimates would "
    f"be confounded with seed noise, and the honest 3-seed version is out of budget.",
    "",
    "## Screening",
    "",
    f"- variants attempted: {attempted}",
    f"- rejected by `verify_result` or `check_geometry`: {len(rejected)}"
    + (f" ({len(rejected) / attempted:.0%})" if attempted else ""),
    "",
    "## Diversity against the seed-noise floor",
    "",
    f"Seed-noise floor: **{noise_floor:.4f}** (mean pairwise distance between clips "
    f"differing only by seed).",
    "",
    "| axis | mean distance | multiple of floor |",
    "|---|---:|---:|",
]
for field, dists in sorted(axis_distances.items(),
                           key=lambda kv: -float(np.mean(kv[1]))):
    mean = float(np.mean([d for d in dists if d is not None]))
    lines.append(f"| {field} | {mean:.4f} | {mean / noise_floor:.2f}x |")

lines += [
    "",
    "## What the set covers",
    "",
    "Lighting and weather move the clips several times further than a seed change "
    "does, so those axes are producing genuine variation rather than noise wearing a "
    "label. For a detector that must work at dusk and in rain, those are the two axes "
    "the task named, and they are the two that work.",
    "",
    "## What it does not cover",
    "",
    f"- **{', '.join(weak) if weak else 'no axis'}** did not clear the floor. A label "
    f"attached to clips that differ less than two random seeds do is a label with no "
    f"signal behind it, and training on it teaches a model that the label is noise.",
    "- **Interactions.** OFAT cannot see them. Fog at dusk is the case a collision "
    "detector fails on, and this set does not contain it.",
    "- **Geometry.** Every clip comes from one conditioning frame, so camera height, "
    "lens, mount position and road layout are constant across the entire set.",
    "",
    "## What I would generate next",
    "",
    "A 2x2 factorial on lighting x weather (4 runs) to test the interaction OFAT "
    "cannot reach, and a second source frame — a different road, a different camera "
    "height — because that is the axis with the largest gap between this set and real "
    "data, and it costs nothing but another image.",
    "",
    "## The limitation I did not have to admit",
    "",
    "Every clip in this set shares one conditioning frame, which means they share its "
    "content, its lens distortion, its exposure, its sensor noise, its compression "
    "artefacts and its exact road geometry. Real dashcam data varies in all of those "
    "*jointly and independently*, and this set varies in none of them. A detector "
    "trained on it can learn 'this road at dusk' rather than 'roads at dusk', and it "
    "will report excellent validation accuracy on a held-out split of this same set "
    "because the split shares the same latent frame. The correlation is invisible to "
    "any per-clip metric and is not fixed by generating more clips — only by "
    "generating from more source frames. Anyone using synthetic augmentation from a "
    "single seed image should hold out by SOURCE, not by clip.",
]
report_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {report_path}\\n")
print("\\n".join(lines[-12:]))
''')

nb.why(
    "**Why the noise floor is measured before anything else.** Hint 2 says it turns the "
    "exercise from a demo into a result, and the mechanism is worth being precise about. "
    "Every distance in the axis table is a distance between two clips generated from the "
    "same image by the same model. Some of that distance is the axis; some is that "
    "diffusion sampling is stochastic. Without the floor you cannot separate them, and — "
    "worse — you will systematically over-report, because every axis will show a "
    "non-zero distance and non-zero looks like an effect. Reporting each axis as a "
    "*multiple of the floor* makes the comparison unavoidable rather than optional.\n\n"
    "**Why the same metric must be used for both.** `clip_distance` is used for the floor "
    "and for the axes, and the docstring says why. It is an easy and invisible mistake to "
    "measure the floor with one metric, refine the metric while looking at the axis "
    "results, and then compare the two. The ratio silently becomes meaningless. Fixing "
    "the metric before the floor run and never touching it again is the discipline.\n\n"
    "**Why `check_geometry` is part of the screening.** `cc.verify_result` asks whether "
    "the file is a live video. It does not ask whether the output has the same shape as "
    "the conditioning image, and an aspect mismatch is the specific failure Lesson 07's "
    "debugging lab is built around. In an augmentation set that mismatch is worse than "
    "elsewhere: a subset of clips at a different aspect ratio introduces a systematic "
    "confound between one axis level and the geometry, which is precisely the kind of "
    "artefact a downstream model will happily learn.\n\n"
    "**On the rejection rate.** It is reported rather than driven to zero. A set with a "
    "0% rejection rate usually means the screening is too weak, not that the generation "
    "is perfect — and a rejection rate that varies by axis level is itself a finding: if "
    "every fog variant fails, that is not a sampling accident, it is the guardrail or the "
    "checker disagreeing with low-contrast output, and it biases the set in a direction "
    "you would not have chosen."
)

nb.extend(
    "The diversity metric here is pixel correlation, which answers \"are these clips "
    "different\". The question that actually matters for the stated task is \"are these "
    "clips different **in the way the detector cares about**\" — and those come apart. "
    "Fog reduces contrast globally, which scores as a large pixel distance while possibly "
    "removing the very feature the detector uses. The stronger measurement is to run the "
    "downstream model, or a proxy for it, over the set and look at the spread of its "
    "*features* rather than of the pixels. That is more work and it is the only version "
    "of \"diverse\" that is defined relative to the task, which step 1 insisted the whole "
    "study be about."
)

nb.finish()
