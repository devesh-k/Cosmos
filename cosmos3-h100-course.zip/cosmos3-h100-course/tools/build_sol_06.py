"""Build solutions/06_solutions.ipynb — reference answers for Lesson 06."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("06", "Generation fundamentals",
                      lesson_file="06_generation_fundamentals.ipynb")

nb.header(
    "Lesson 06 is where the course starts spending real GPU time, and all three "
    "exercises are about spending it deliberately. The foundation exercise finds the "
    "point where extra denoising steps stop paying, **on your machine**. The applied one "
    "turns that calibration into a planner that answers \"what is the biggest job that "
    "fits in four minutes\". The challenge one asks which parts of a structured prompt "
    "the model is actually sensitive to — and insists on a noise floor, because an "
    "effect smaller than seed-to-seed variation is not an effect."
)

nb.callout(
    "warning",
    "**Generation is off by default here, as in the lesson.** `ALLOW_GENERATION = False` "
    "means nothing downloads and nothing runs on the GPU. Every analysis cell below "
    "still executes: the curve-fitting, the planner, the ablation bookkeeping and the "
    "noise-floor logic all run against clearly-labelled placeholder data so the *method* "
    "is checkable. Set `ALLOW_GENERATION = True` on a machine with an H100 and the "
    "checkpoint to replace the placeholders with measurements. No number produced under "
    "the placeholder path is a measurement of Cosmos 3.",
)

nb.prelude(
    "The lesson's configuration, its `GpuSampler`, its `run_and_verify` harness and its "
    "calibration constants, so the exercises below are written against exactly the names "
    "the lesson used."
)
nb.code(setup_cell("06"))

nb.code('''
import copy
import json
import subprocess
import threading
import time

import numpy as np

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

from cosmos_course.measure import MeasurementLog
from cosmos_course.models import Generator

generator = cc.Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=False)

# Same knobs, same names as the lesson.
ALLOW_GENERATION = False          # <- set True on an H100 with the checkpoint
if MODE == "full":
    RES_IMAGE, RES_VIDEO, N_FRAMES, N_STEPS = "480", "480", 121, 35
else:
    RES_IMAGE, RES_VIDEO, N_FRAMES, N_STEPS = "256", "480", 61, 20
RUN_TIMEOUT = 3600 if MODE == "full" else 1800
RUN = ALLOW_GENERATION and DEVICE.startswith("cuda") and not framework_problems

log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
RUNS = {}

print(f"mode {MODE!r}: image tier {RES_IMAGE}, video tier {RES_VIDEO}, "
      f"{N_FRAMES} frames, {N_STEPS} steps")
print(f"RUN = {RUN}")
for p in framework_problems:
    print(f"  ! {p}")
''')

nb.code('''
class GpuSampler:
    """Poll device-wide VRAM on a thread; report baseline and peak, in GB."""

    def __init__(self, interval=1.0, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_gb()
            if value is not None:
                self.samples.append(value)

    def __enter__(self):
        self.samples = [self._read_gb() or 0.0]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None

    @property
    def baseline_gb(self):
        return self.samples[0] if self.samples else None


def run_and_verify(spec, subdir, *, label=None, extra_args=None, timeout=None):
    """Run one job, sample device VRAM, verify the output, record the numbers."""
    label = label or spec.name
    if not RUN:
        print(f"skipped {label!r}: generation is disabled (RUN is False)")
        return None
    problems = cc.validate_spec(spec, strict=False)
    if problems:
        print("spec problems:", problems)
    estimate = spec.cost()
    with GpuSampler() as sampler:
        with cc.timer(label, track_memory=False) as timing:
            result = generator.run(spec, OUTPUT_DIR / subdir, seed=spec.seed or 0,
                                   extra_args=extra_args,
                                   timeout=timeout or RUN_TIMEOUT)
    RUNS[label] = {"seconds": timing.seconds, "peak_gb": sampler.peak_gb,
                   "baseline_gb": sampler.baseline_gb,
                   "cost_units": estimate.get("cost_units"),
                   "num_steps": spec.num_steps, "resolution": spec.resolution,
                   "num_frames": spec.num_frames, "result": result}
    log.record(label=label, model=MODEL, mode=MODE,
               **{k: v for k, v in RUNS[label].items() if k != "result"})
    cc.verify_result(result)
    return result


print("harness ready")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Find the knee in the steps curve — on Cosmos, not on the toy",
    goal="Produce a quality-proxy-against-time curve for `num_steps` on your own "
         "machine, and identify the point past which extra steps stop paying.",
    success="A plot with at least five points, a stated knee with a step count attached, "
            "and an honest paragraph about the proxy's limits.",
    approach="Define the knee as a *rule* applied to the curve rather than a point read "
             "off it by eye, so the answer is reproducible and so a different reader can "
             "disagree with the rule rather than with the eyeballing.",
)

nb.code('''
STEP_GRID = [6, 12, 20, 30, 50]
PROMPT = ("A wide, evenly lit industrial kitchen. A single-arm robot stands at a "
          "stainless steel counter holding a folded blue towel. Shallow depth of "
          "field, photographic, no text.")

sweep_rows = []
for steps in STEP_GRID:
    spec = cc.InferenceSpec(
        model_mode="text2image", name=f"knee_{steps}", prompt=PROMPT,
        resolution=RES_IMAGE, aspect_ratio="16,9", num_frames=1,
        num_steps=steps, guidance=7.0, seed=0,
    )
    res = run_and_verify(spec, "knee", label=f"knee_{steps}")
    if res is None or res.image_path is None:
        continue
    metrics = cc.check_image(res.image_path).metrics
    sweep_rows.append({"steps": steps,
                       "seconds": RUNS[f"knee_{steps}"]["seconds"],
                       "path": str(res.image_path), **metrics})

print(f"{len(sweep_rows)} point(s) collected")
''')

nb.code('''
# PLACEHOLDER DATA — used only when generation is off, so the analysis below has
# something to chew on. These are NOT measurements of Cosmos 3 and must not be
# quoted. They are shaped like a plausible curve (saturating quality, linear
# time) purely so the knee rule can be exercised.
PLACEHOLDER_SWEEP = [
    {"steps": 6, "seconds": 24.0, "std": 38.0, "edge_density": 0.031,
     "autocorrelation": 0.972, "placeholder": True},
    {"steps": 12, "seconds": 33.0, "std": 46.0, "edge_density": 0.049,
     "autocorrelation": 0.978, "placeholder": True},
    {"steps": 20, "seconds": 45.0, "std": 51.0, "edge_density": 0.060,
     "autocorrelation": 0.981, "placeholder": True},
    {"steps": 30, "seconds": 60.0, "std": 53.0, "edge_density": 0.064,
     "autocorrelation": 0.982, "placeholder": True},
    {"steps": 50, "seconds": 90.0, "std": 54.0, "edge_density": 0.066,
     "autocorrelation": 0.982, "placeholder": True},
]

using_placeholder = not sweep_rows
rows = sweep_rows or PLACEHOLDER_SWEEP
if using_placeholder:
    print("USING PLACEHOLDER DATA. Every number in this section is invented to "
          "exercise the method. Set ALLOW_GENERATION = True to replace it.\\n")

# FIXED_OVERHEAD_S: with two or more points, fit seconds = a + b*steps and read
# the intercept. Hint 1 is emphatic that subtracting it matters — leaving weight
# loading in flattens the time axis and puts the knee too low.
steps_arr = np.array([r["steps"] for r in rows], dtype=float)
secs_arr = np.array([r["seconds"] for r in rows], dtype=float)
if len(rows) >= 2:
    PER_STEP_S, FIXED_OVERHEAD_S = np.polyfit(steps_arr, secs_arr, 1)
    FIXED_OVERHEAD_S = float(max(FIXED_OVERHEAD_S, 0.0))
    PER_STEP_S = float(PER_STEP_S)
else:
    PER_STEP_S = FIXED_OVERHEAD_S = None

print(f"fitted fixed overhead : {FIXED_OVERHEAD_S:.1f} s")
print(f"fitted per-step cost  : {PER_STEP_S:.3f} s/step at {RES_IMAGE}p, 1 frame")
compute_s = secs_arr - (FIXED_OVERHEAD_S or 0.0)

print()
print(f"{'steps':>6}{'total s':>10}{'compute s':>11}{'edge_density':>14}"
      f"{'std':>8}{'autocorr':>10}")
for r, c in zip(rows, compute_s):
    print(f"{r['steps']:>6}{r['seconds']:>10.1f}{c:>11.1f}"
          f"{r['edge_density']:>14.4f}{r['std']:>8.1f}{r['autocorrelation']:>10.4f}")
''')

nb.code('''
def find_knee(x, y, *, fraction=0.9):
    """The smallest x at which y has reached `fraction` of its total gain.

    A RULE, not an eyeball. The knee is defined as the first point where the
    proxy has captured 90% of the improvement it will ever show across the
    sweep. Stating it this way has three benefits: it is reproducible, it is
    arguable (you can reject 0.9 and pick 0.95), and it degrades sensibly on a
    curve that never saturates — it simply returns the last point, which is the
    honest answer to "the knee is off the right edge of your grid".
    """
    x, y = np.asarray(x, float), np.asarray(y, float)
    lo, hi = float(y.min()), float(y.max())
    if hi - lo <= 0:
        return None, None
    target = lo + fraction * (hi - lo)
    for xi, yi in zip(x, y):
        if yi >= target:
            return float(xi), float(target)
    return float(x[-1]), float(target)


# Check the rule against a curve whose knee is known by construction.
_x = np.array([1, 2, 4, 8, 16], float)
_y = np.array([0.0, 0.5, 0.9, 0.99, 1.0])
knee_x, _ = find_knee(_x, _y, fraction=0.9)
assert knee_x == 4.0, knee_x
assert find_knee([1, 2, 3], [5, 5, 5])[0] is None       # flat curve: no knee
assert find_knee([1, 2, 3], [0, 1, 2], fraction=0.9)[0] == 3.0   # never saturates
print("PASS find_knee is correct on a saturating curve, a flat curve and a "
      "linear one")

PROXY = "edge_density"     # hint 1: the most responsive of the three
knee_steps, knee_value = find_knee([r["steps"] for r in rows],
                                   [r[PROXY] for r in rows])
print(f"\\nknee on {PROXY}: {knee_steps} steps "
      f"(90% of the total gain, proxy = {knee_value:.4f})")

# What the extra steps beyond the knee actually cost, in compute seconds.
by_steps = {r["steps"]: c for r, c in zip(rows, compute_s)}
if knee_steps in by_steps:
    beyond = by_steps[max(by_steps)] - by_steps[knee_steps]
    print(f"going from {int(knee_steps)} to {int(max(by_steps))} steps costs "
          f"{beyond:.1f} more compute seconds")
    print(f"and buys {rows[-1][PROXY] - dict((r['steps'], r[PROXY]) for r in rows)[knee_steps]:+.4f} "
          f"of {PROXY}")
''')

nb.code('''
if plt is not None:
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(compute_s, [r[PROXY] for r in rows], "o-", color="#1971c2")
    for r, c in zip(rows, compute_s):
        axes[0].annotate(str(r["steps"]), (c, r[PROXY]),
                         textcoords="offset points", xytext=(5, -9), fontsize=8)
    if knee_value is not None:
        axes[0].axhline(knee_value, ls="--", lw=1, color="#c92a2a")
        axes[0].axvline(by_steps.get(knee_steps, 0), ls="--", lw=1, color="#c92a2a")
    axes[0].set_xlabel("measured COMPUTE seconds (fixed overhead removed)")
    axes[0].set_ylabel(PROXY)
    axes[0].set_title(("PLACEHOLDER DATA — not a measurement"
                       if using_placeholder else "measured on this machine"),
                      fontsize=10)
    for name, colour in (("std", "#2b8a3e"), ("autocorrelation", "#e8590c")):
        series = np.array([r[name] for r in rows], float)
        span = series.max() - series.min()
        axes[1].plot([r["steps"] for r in rows],
                     (series - series.min()) / span if span else series * 0,
                     "o-", label=f"{name} (range {span:.4f})", color=colour)
    series = np.array([r[PROXY] for r in rows], float)
    axes[1].plot([r["steps"] for r in rows],
                 (series - series.min()) / (series.max() - series.min()),
                 "o-", label=f"{PROXY} (range {series.max() - series.min():.4f})",
                 color="#1971c2")
    axes[1].set_xlabel("num_steps")
    axes[1].set_ylabel("proxy, rescaled to 0-1")
    axes[1].set_title("all three proxies, normalised — note the RANGES", fontsize=10)
    axes[1].legend(fontsize=8)
    plt.tight_layout()
    plt.show()
else:
    print("matplotlib not installed; the table above is the plot.")

if sweep_rows and len(sweep_rows) >= 2:
    cc.contact_sheet([r["path"] for r in sweep_rows],
                     labels=[f"{r['steps']} steps" for r in sweep_rows],
                     width=260, cols=3)
else:
    print("\\nNo images to show. Step 5 asks you to LOOK at them — that is the part "
          "of this exercise a proxy cannot do for you.")
''')

nb.model_answer(
    "**Does the proxy track what you actually see?**\n\n"
    "Partly, and the places it does not are the interesting ones. Three specific limits, "
    "each of which you can confirm by looking at the contact sheet:\n\n"
    "**1. Edge density measures sharpness, and sharpness is not quality.** An "
    "under-stepped sample is smooth and blobby, so edge density climbs steeply over the "
    "first few steps and this is real. But edge density also climbs when the sampler "
    "produces high-frequency *noise*, and at very low step counts with high guidance you "
    "can get both at once. The proxy cannot distinguish \"more detail\" from \"more "
    "texture artefacts\", and above the knee that is exactly the distinction that "
    "matters.\n\n"
    "**2. Autocorrelation is saturated and says almost nothing.** Hint 1 warns of this "
    "and the second panel above shows it: its range across the whole sweep is tiny "
    "compared with edge density's. That is not a bug — `cc.check_image` uses "
    "autocorrelation to detect *noise*, i.e. to answer \"is this an image at all\", and "
    "by step 6 the answer is already yes. A metric doing its job well at one question is "
    "not thereby useful for a different one. Reporting it as flat is the correct outcome, "
    "and hiding it would be the mistake.\n\n"
    "**3. None of the three can see semantics.** The thing that most often improves "
    "between 12 and 30 steps is not sharpness — it is whether the robot has the right "
    "number of arms, whether the towel is folded, whether text-like scribble has resolved "
    "into a plain surface. Every one of those is invisible to a pixel statistic and "
    "obvious to you in two seconds. If your eyes say 20 steps is unusable and the proxy "
    "says it is 95% of the way there, believe your eyes and report the disagreement.\n\n"
    "**What I would use instead, and why not here.** The reasoner from Module 1, scoring "
    "prompt adherence on a 1–5 scale, sees exactly the semantic failures the pixel "
    "statistics miss. It costs a NIM, one request per image, and it introduces its own "
    "noise — so the honest version needs several samples per image and a self-consistency "
    "check, which is Lesson 04's machinery. That is the right tool and it is a bigger "
    "experiment. Edge density is defensible here because it is free, monotone in the "
    "thing being varied, and — crucially — **its limitations are nameable**, which is "
    "what makes it usable as a proxy rather than a pretend measurement.\n\n"
    "*If the numbers above came from the placeholder set, none of this is a finding about "
    "Cosmos 3. The structure of the argument is the deliverable; the knee is yours to "
    "measure.*"
)

nb.extend(
    "The knee is currently a property of one prompt at one resolution. It is very likely "
    "not the same for video: temporal coherence is one of the last things to converge, "
    "so a step count that is ample for a still can leave a 61-frame clip flickering. "
    "Repeating this sweep for `text2video` with a temporal proxy — the mean absolute "
    "difference between consecutive frames, which `cc.check_video` already computes as "
    "`temporal_change` — would tell you whether your image-derived knee is safe to apply "
    "to video, and the prediction is that it is not."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "plan_generation(time_budget_s)",
    goal="Given a time budget in seconds, return the largest job this machine can "
         "finish inside it — and prove it with an automated check.",
    success="`check_plan_generation()` prints all-pass, and one real generation run lands "
            "inside its budget. If it does not, report the miss and its size rather than "
            "adjusting the budget.",
    approach="Enumerate the (small) search space, score with the calibrated predictor, "
             "and rank by a written-down preference order: **resolution, then frames, "
             "then steps** — with the argument for that ordering below.",
)

nb.code('''
# Calibration, exactly as the lesson computes it: median units per COMPUTE
# second across every run recorded so far.
CALIBRATION_PATH = OUTPUT_DIR / "calibration.json"
rates = []
for label, entry in RUNS.items():
    if not entry.get("cost_units") or not entry.get("seconds"):
        continue
    compute = entry["seconds"] - (FIXED_OVERHEAD_S or 0.0)
    if compute > 0.5:
        rates.append(entry["cost_units"] / compute)

UNITS_PER_SECOND = None
if rates:
    rates.sort()
    UNITS_PER_SECOND = rates[len(rates) // 2]
    print(f"median units/second from {len(rates)} run(s): {UNITS_PER_SECOND:,.0f}")
elif using_placeholder:
    # Derived from the PLACEHOLDER sweep, so it is a placeholder too. Kept only
    # so the planner and its check can run.
    units = [cc.estimate_generation_cost(num_frames=1, resolution=RES_IMAGE,
                                         num_steps=r["steps"], model=MODEL)["cost_units"]
             for r in rows]
    per_second = [u / max(s, 0.5) for u, s in zip(units, compute_s)]
    per_second.sort()
    UNITS_PER_SECOND = per_second[len(per_second) // 2]
    print(f"PLACEHOLDER units/second: {UNITS_PER_SECOND:,.0f} — derived from invented "
          f"timings, not measured")

assert UNITS_PER_SECOND, "no calibration available"


def predict_seconds(resolution, num_frames, num_steps, model=None):
    """Predicted wall clock = fixed overhead + cost units / calibrated rate."""
    units = cc.estimate_generation_cost(
        num_frames=num_frames, resolution=resolution, num_steps=num_steps,
        model=model or MODEL)["cost_units"]
    return (FIXED_OVERHEAD_S or 0.0) + units / UNITS_PER_SECOND
''')

nb.code('''
FRAME_CHOICES = (1, 25, 61, 89, 121, 189)
STEP_CHOICES = (8, 12, 20, 30, 35, 50)


def plan_generation(time_budget_s, model=None):
    """Largest job predicted to finish within time_budget_s on THIS machine.

    PREFERENCE ORDER, written down as instruction 4 requires:

        1. resolution   (highest that fits)
        2. num_frames   (most that fit at that resolution)
        3. num_steps    (most that fit at that resolution and frame count)

    The argument. Resolution and frame count determine what the output IS — you
    cannot upscale your way to detail that was never generated, and you cannot
    extend a 25-frame clip into a 121-frame one. Steps determine how well the
    thing you asked for was rendered, and a 20-step 480p clip is more useful
    than a 50-step 256p one for almost every purpose this course has. Steps are
    also the cheapest axis to increase later: re-running at more steps costs
    one more run, whereas discovering you needed 480p costs a redesign.

    THE CASE AGAINST, which is real: past the knee found in Exercise 1, extra
    steps are nearly free of benefit — so ranking steps last is only correct
    once you are AT or ABOVE the knee. A planner that hands you 8 steps at 768p
    has technically maximised resolution and produced something unusable. Hence
    the MIN_USABLE_STEPS floor below: preference orders need a floor, or the
    lowest-priority axis gets starved to zero.
    """
    model = model or MODEL
    tier = cc.MODEL_TIERS[model]
    tier_max_res = int(tier["max_resolution_tier"])
    lo_frames, hi_frames = tier["frames_range"]
    MIN_USABLE_STEPS = 12

    candidates = []
    for resolution in cc.RESOLUTION_TIERS:
        if int(resolution) > tier_max_res:
            continue
        ceiling = cc.MAX_FRAMES_BY_TIER.get(resolution, hi_frames)
        for frames in FRAME_CHOICES:
            # A single frame is a still image, and text2image sits outside the
            # tier's VIDEO frame range by construction — Edge's frames_range is
            # (50, 150), which would otherwise make a still illegal. Treating
            # frames==1 as always allowed is a real decision, not a loophole:
            # the constraint being enforced is about video length.
            if frames != 1 and not (lo_frames <= frames <= hi_frames):
                continue
            if frames > ceiling:
                continue
            for steps in STEP_CHOICES:
                if steps < MIN_USABLE_STEPS:
                    continue
                predicted = predict_seconds(resolution, frames, steps, model)
                if predicted > time_budget_s:
                    continue
                candidates.append({
                    "model": model, "resolution": resolution, "num_frames": frames,
                    "num_steps": steps,
                    "predicted_seconds": round(float(predicted), 1),
                    "fits": True,
                })
    if candidates:
        candidates.sort(key=lambda c: (-int(c["resolution"]), -c["num_frames"],
                                       -c["num_steps"]))
        return candidates[0]

    # Hint 2: an impossible budget must be handled deliberately. This returns
    # the smallest legal job with an HONEST predicted_seconds above the budget
    # and fits=False, rather than raising. A caller in a loop can then decide;
    # a caller who ignores `fits` gets a number that visibly exceeds what they
    # asked for, which is louder than a silently shrunk plan.
    smallest_res = min((r for r in cc.RESOLUTION_TIERS
                        if int(r) <= tier_max_res), key=lambda r: int(r))
    frames = 1                    # a still is the smallest legal job
    plan = {"model": model, "resolution": smallest_res, "num_frames": frames,
            "num_steps": MIN_USABLE_STEPS, "fits": False}
    plan["predicted_seconds"] = round(
        float(predict_seconds(smallest_res, frames, MIN_USABLE_STEPS, model)), 1)
    plan["note"] = (f"nothing fits {time_budget_s} s; this is the smallest legal job "
                    f"and it is predicted to take {plan['predicted_seconds']} s")
    return plan
''')

nb.code('''
def check_plan_generation():
    """Automated check. Run it before believing your own function."""
    passed = []
    assert UNITS_PER_SECOND, "no calibration — run the calibration cell first"

    small, large = plan_generation(120), plan_generation(1800)
    assert small["predicted_seconds"] <= 120, "the 120 s plan does not fit 120 s"
    assert large["predicted_seconds"] <= 1800, "the 1800 s plan does not fit 1800 s"
    passed.append("both plans respect their budget")

    small_units = cc.estimate_generation_cost(
        resolution=small["resolution"], num_frames=small["num_frames"],
        num_steps=small["num_steps"])["cost_units"]
    large_units = cc.estimate_generation_cost(
        resolution=large["resolution"], num_frames=large["num_frames"],
        num_steps=large["num_steps"])["cost_units"]
    assert large_units > small_units, "a larger budget must buy a larger job"
    passed.append(f"more budget buys more job ({small_units:,} -> {large_units:,})")

    ceiling = cc.MAX_FRAMES_BY_TIER[large["resolution"]]
    assert large["num_frames"] <= ceiling, f"exceeds the {large['resolution']} ceiling"
    passed.append("frame count respects the tier ceiling")

    tier_max = int(cc.MODEL_TIERS[MODEL]["max_resolution_tier"])
    assert int(large["resolution"]) <= tier_max, f"{MODEL} tops out at {tier_max}p"
    passed.append(f"resolution respects {MODEL}'s {tier_max}p ceiling")

    assert plan_generation(1)["predicted_seconds"] is not None, \\
        "an impossible budget must still return a plan, or raise on purpose"
    passed.append("an impossible budget is handled deliberately")

    for item in passed:
        print(f"  PASS  {item}")
    return passed


check_plan_generation()
print()
for budget in (60, 120, 240, 600, 1800):
    plan = plan_generation(budget)
    flag = "" if plan.get("fits", True) else "   <- DOES NOT FIT"
    print(f"budget {budget:>5} s -> {plan['resolution']:>3}p  "
          f"{plan['num_frames']:>3} frames  {plan['num_steps']:>2} steps  "
          f"predicted {plan['predicted_seconds']:>7.1f} s{flag}")
print()
impossible = plan_generation(1)
print("plan_generation(1):", json.dumps(impossible, indent=2))
''')

nb.code('''
# Step 5 — generate the four-minute plan and compare predicted against measured.
# The success criterion is explicit that a miss is reported, not hidden.
BUDGET_S = 240
plan = plan_generation(BUDGET_S)
print(f"plan for a {BUDGET_S} s budget: {plan}")

spec = cc.InferenceSpec(
    model_mode="text2video" if plan["num_frames"] > 1 else "text2image",
    name="budget_plan", prompt=PROMPT, resolution=plan["resolution"],
    aspect_ratio="16,9", num_frames=plan["num_frames"],
    num_steps=plan["num_steps"], guidance=7.0, seed=0,
)
result = run_and_verify(spec, "budget_plan", label="budget_plan",
                        timeout=max(RUN_TIMEOUT, int(BUDGET_S * 4)))

if result is not None and "budget_plan" in RUNS:
    measured = RUNS["budget_plan"]["seconds"]
    predicted = plan["predicted_seconds"]
    error = (measured - predicted) / predicted
    print(f"\\npredicted : {predicted:8.1f} s")
    print(f"measured  : {measured:8.1f} s")
    print(f"error     : {error:+8.1%}")
    print(f"inside the {BUDGET_S} s budget: {measured <= BUDGET_S}")
    if measured > BUDGET_S:
        print(f"MISS of {measured - BUDGET_S:.1f} s. Reported, not corrected. The "
              f"likely cause is that the calibration runs were images and this is "
              f"video: attention is quadratic in sequence length and the cost model "
              f"is linear, so a rate fitted on 1-frame runs under-predicts "
              f"multi-frame ones. Recalibrate on a run of the same SHAPE.")
else:
    print("\\nNo run performed (RUN is False), so predicted-vs-measured is not "
          "available. That comparison is the point of step 5 and it needs a GPU. "
          "The prediction stands as a prediction:")
    print(f"  {plan['resolution']}p, {plan['num_frames']} frames, "
          f"{plan['num_steps']} steps, predicted {plan['predicted_seconds']:.1f} s")
''')

nb.why(
    "**Why enumerate rather than invert.** Hint 1 says it and the reason is worth "
    "spelling out: the search space is four resolution tiers times six frame counts "
    "times six step counts — 144 candidates, each costing one arithmetic evaluation. "
    "Inverting `cost_units = latent_tokens x steps` analytically for three unknowns "
    "under two ceiling constraints is a small optimisation problem with integer "
    "constraints, and every minute spent on it is a minute not spent measuring. When the "
    "search space is small enough to enumerate, enumerate.\n\n"
    "**Why the preference order needs a floor.** This is the part of the exercise most "
    "likely to produce a subtly broken answer. Any strict lexicographic ranking starves "
    "its lowest-priority axis: rank resolution first and the planner will happily hand "
    "you 768p at 8 steps, because 8 steps is legal and buys another resolution tier. The "
    "output is unusable. `MIN_USABLE_STEPS` fixes it, and the value should come from "
    "Exercise 1's knee rather than from taste — which is a nice illustration of why the "
    "exercises are in this order.\n\n"
    "**Why the impossible budget returns rather than raises.** Both are defensible and "
    "hint 2 says so. The deciding argument is the caller: `plan_generation` is the kind "
    "of function you call in a loop over a queue of jobs, and an exception forces every "
    "caller to write a try/except to discover something that is not exceptional — a job "
    "that does not fit is an ordinary outcome. Returning a plan with `fits: False` and an "
    "honest `predicted_seconds` well above the budget lets the caller decide, and makes "
    "the failure visible even to a caller who ignores the flag. What is *not* defensible "
    "is silently returning a plan that does not fit while claiming it does, which is what "
    "you get if you clamp `predicted_seconds` to the budget.\n\n"
    "**Why the miss is reported rather than absorbed.** The success criterion is unusually "
    "specific about this, and it is the most transferable thing in the exercise. When a "
    "prediction misses, there are two moves: fix the predictor, or widen the budget until "
    "it fits. The second feels like progress and destroys the instrument — after two "
    "rounds of it you have a planner that always succeeds and predicts nothing. The "
    "error message above names the most probable cause (calibrating on images and "
    "predicting video) precisely so the response is to recalibrate rather than to "
    "retune."
)

nb.extend(
    "The planner assumes one job at a time. The version worth having takes a *queue* and "
    "a total budget, and chooses the mix: given twenty minutes, is it better to produce "
    "one 121-frame clip or four 25-frame ones? That question has no general answer, which "
    "is the point — it forces you to state what the output is for, and the answer changes "
    "the objective function rather than the constraints. It is also where the cost model "
    "starts paying for itself, because comparing two *portfolios* of jobs is exactly what "
    "relative cost units are good at and absolute seconds are not."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "A prompt-ablation study",
    goal="Determine which fields of a structured Cosmos 3 prompt the model is actually "
         "sensitive to, with a metric you chose and can defend.",
    success="A ranked table over at least four fields, a stated metric with a stated "
            "justification, a measured seed noise floor, and at least one field honestly "
            "reported as having no detectable effect.",
    approach="Run the whitespace control and the noise floor **first**; only then run the "
             "ablations, and report every effect size as a multiple of the floor rather "
             "than as a raw distance.",
)

nb.code('''
BASE_PROMPT = None
_kitchen = cc.asset_or_none("prompt_robot_kitchen")
if _kitchen is not None:
    BASE_PROMPT = json.loads(_kitchen.read_text())
else:
    # The shape Lesson 06 works with, written out so this runs without the
    # cookbook checkout. Same fields, different content.
    BASE_PROMPT = {
        "description": ("A wheeled service robot picks a ceramic mug from a wooden "
                        "bench and sets it on a metal tray, in a small workshop."),
        "subjects": [
            {"name": "service robot",
             "appearance": "matte white shell, single articulated arm",
             "action": "reaches, grips the mug handle, lifts, places"},
            {"name": "ceramic mug", "appearance": "plain off-white, slight gloss",
             "action": "is lifted and set down, remains upright"},
        ],
        "scene": {"location": "workshop bench beside a window",
                  "surfaces": "scratched wooden bench, brushed steel tray",
                  "background": "pegboard with hand tools, slightly out of focus"},
        "lighting": "overcast daylight from the window on the left, soft shadows",
        "camera": {"framing": "medium shot, slightly above bench height",
                   "motion": "static tripod, no movement"},
        "style": "documentary realism, natural colour, no stylisation",
    }
print(json.dumps(BASE_PROMPT, indent=2)[:520])
''')

nb.code('''
def set_field(prompt, dotted_path, value):
    """Return a copy of `prompt` with one nested field replaced.

    Raises on a path that does not exist. A silent no-op here is the worst
    possible bug in this study: the field would appear insensitive, and the
    reason would be that you never changed it. That failure is indistinguishable
    from a real null result unless the function refuses.
    """
    out = copy.deepcopy(prompt)
    parts = dotted_path.split(".")
    node = out
    for part in parts[:-1]:
        if not isinstance(node, dict) or part not in node:
            raise KeyError(f"{dotted_path!r}: no such path (failed at {part!r})")
        node = node[part]
    if not isinstance(node, dict) or parts[-1] not in node:
        raise KeyError(f"{dotted_path!r}: no such leaf {parts[-1]!r}")
    node[parts[-1]] = value
    return out


# Prove the guard works, both ways.
_probe = set_field(BASE_PROMPT, "lighting", "harsh midday sun")
assert _probe["lighting"] == "harsh midday sun"
assert BASE_PROMPT["lighting"] != "harsh midday sun", "set_field mutated the original"
assert set_field(BASE_PROMPT, "camera.motion", "slow dolly")["camera"]["motion"] \\
    == "slow dolly"
for bad in ("lightning", "camera.zoom", "scene.nonexistent"):
    try:
        set_field(BASE_PROMPT, bad, "x")
    except KeyError as exc:
        print(f"PASS refused {bad!r}: {exc}")
    else:
        raise AssertionError(f"{bad!r} should have raised")

ABLATIONS = {
    "lighting": ["harsh midday sun, hard shadows, high contrast",
                 "blue hour, low ambient light, cool cast"],
    "camera.motion": ["slow dolly forward", "handheld, slight shake"],
    "scene.surfaces": ["polished stainless steel throughout",
                       "rough concrete and matte black rubber"],
    "style": ["high-contrast film noir, deep shadows",
              "flat technical illustration, no shading"],
}
print(f"\\n{len(ABLATIONS)} fields, "
      f"{sum(len(v) for v in ABLATIONS.values())} variants, plus a whitespace control")
''')

nb.code('''
def compact(obj):
    """Serialise a structured prompt the way the framework wants it: one string."""
    return json.dumps(obj, ensure_ascii=True, separators=(",", ":"))


def effect_metric(path_a, path_b):
    """Distance between two generated images, in [0, 1]. 0 = identical.

    CHOICE AND JUSTIFICATION, fixed before any output was looked at:

      A 32-bin-per-channel joint colour histogram distance (1 - histogram
      intersection), averaged with a normalised edge-map disagreement.

    Why this should detect the changes being made:

      * `lighting` changes colour temperature and shadow contrast, which moves
        mass between histogram bins directly.
      * `scene.surfaces` changes material — wood to steel — which changes both
        colour distribution and specular edge structure.
      * `style` changes global tone mapping, again a histogram effect.
      * `camera.motion` is the one this metric is WEAKEST on, and that is
        stated up front: a dolly changes composition, which a spatially-blind
        histogram cannot see, and the edge term only partly compensates. If
        camera.motion ranks low, that is a fact about this metric as much as
        about the model. Saying so in advance is the difference between a
        limitation and an excuse.

    Rejected: perceptual distance (LPIPS) would be better on composition and
    needs a pretrained network and a GPU that is busy generating; raw pixel MAE
    would be dominated by the seed's texture noise rather than by the change.
    """
    from PIL import Image

    a = np.asarray(Image.open(path_a).convert("RGB"), dtype=np.float32)
    b = np.asarray(Image.open(path_b).convert("RGB").resize(
        Image.open(path_a).size), dtype=np.float32)

    hist_terms = []
    for channel in range(3):
        ha, _ = np.histogram(a[..., channel], bins=32, range=(0, 255), density=True)
        hb, _ = np.histogram(b[..., channel], bins=32, range=(0, 255), density=True)
        ha, hb = ha / max(ha.sum(), 1e-9), hb / max(hb.sum(), 1e-9)
        hist_terms.append(1.0 - float(np.minimum(ha, hb).sum()))
    hist_distance = float(np.mean(hist_terms))

    def edges(arr):
        g = arr.mean(axis=2)
        gx = np.abs(np.diff(g, axis=1))[:-1, :]
        gy = np.abs(np.diff(g, axis=0))[:, :-1]
        mag = np.hypot(gx, gy)
        return mag > (mag.mean() + mag.std())

    ea, eb = edges(a), edges(b)
    union = float((ea | eb).sum())
    edge_distance = 1.0 - (float((ea & eb).sum()) / union if union else 1.0)
    return 0.5 * hist_distance + 0.5 * edge_distance


# Check the metric on images whose distance is known by construction.
from PIL import Image as _PILImage

_tmp = OUTPUT_DIR / "_metric_check"
_tmp.mkdir(parents=True, exist_ok=True)
_rng = np.random.default_rng(0)
_base = _rng.integers(0, 255, (64, 96, 3), dtype=np.uint8)
_PILImage.fromarray(_base).save(_tmp / "a.png")
_PILImage.fromarray(_base).save(_tmp / "a_copy.png")
_PILImage.fromarray(np.clip(_base.astype(int) + 60, 0, 255).astype(np.uint8)).save(
    _tmp / "brighter.png")
_identical = effect_metric(_tmp / "a.png", _tmp / "a_copy.png")
_shifted = effect_metric(_tmp / "a.png", _tmp / "brighter.png")
# 1e-9 rather than == 0.0: the histogram terms are floating-point sums that come
# back as 1 - 0.9999999999, and an exact-equality assertion on a float pipeline
# is a test that fails for a reason unrelated to the thing being tested.
assert _identical < 1e-9, _identical
assert _shifted > 0.1, _shifted
print(f"PASS effect_metric is {_identical:.2e} for identical images and "
      f"{_shifted:.3f} for a brightness shift")
''')

nb.code('''
# Hint 1 and 2, in the order they must actually be run: the whitespace control
# FIRST (is the pipeline deterministic at all?), then the noise floor.
NOISE_SEEDS = [0, 1, 2, 3]
control_distance = None
noise_floor = None
floor_samples = []

if RUN:
    base_spec = dict(model_mode="text2image", resolution=RES_IMAGE,
                     aspect_ratio="16,9", num_frames=1, num_steps=N_STEPS,
                     guidance=7.0)
    ref = run_and_verify(cc.InferenceSpec(
        name="abl_base", prompt=compact(BASE_PROMPT), seed=0, **base_spec),
        "ablation", label="abl_base")

    # The control: same content, different whitespace. At a fixed seed this
    # must be identical. If it is not, stop — every effect below is polluted.
    pretty = json.dumps(BASE_PROMPT, indent=2)
    ctrl = run_and_verify(cc.InferenceSpec(
        name="abl_control", prompt=pretty, seed=0, **base_spec),
        "ablation", label="abl_control")
    if ref is not None and ctrl is not None:
        control_distance = effect_metric(ref.image_path, ctrl.image_path)
        print(f"\\nwhitespace control distance: {control_distance:.4f}")
        if control_distance > 1e-6:
            print("NOT ZERO. Something in the pipeline is non-deterministic, OR the "
                  "whitespace really did change the tokenisation enough to matter. "
                  "Find out which before reading a single effect size below.")

    for seed in NOISE_SEEDS[1:]:
        got = run_and_verify(cc.InferenceSpec(
            name=f"abl_seed{seed}", prompt=compact(BASE_PROMPT), seed=seed,
            **base_spec), "ablation", label=f"abl_seed{seed}")
        if got is not None and ref is not None:
            floor_samples.append(effect_metric(ref.image_path, got.image_path))
    if floor_samples:
        noise_floor = float(np.mean(floor_samples))
else:
    # PLACEHOLDER FLOOR — invented, so the ranking machinery below can run.
    control_distance = 0.0
    floor_samples = [0.181, 0.204, 0.192]
    noise_floor = float(np.mean(floor_samples))
    print("PLACEHOLDER noise floor — invented numbers, not measurements.")

print(f"\\nseed-to-seed distances : {[round(v, 4) for v in floor_samples]}")
print(f"noise floor (mean)     : {noise_floor:.4f}")
print(f"floor spread           : {(max(floor_samples) - min(floor_samples)):.4f}"
      if floor_samples else "")
print("\\nAn ablation whose effect is below this number has not been shown to have "
      "an effect. That is the whole reason this cell runs before the next one.")
''')

nb.code('''
results = []
if RUN:
    base_spec = dict(model_mode="text2image", resolution=RES_IMAGE,
                     aspect_ratio="16,9", num_frames=1, num_steps=N_STEPS,
                     guidance=7.0)
    ref_path = RUNS["abl_base"]["result"].image_path
    for field, values in ABLATIONS.items():
        for i, value in enumerate(values):
            variant = set_field(BASE_PROMPT, field, value)
            label = f"abl_{field.replace('.', '_')}_{i}"
            got = run_and_verify(cc.InferenceSpec(
                name=label, prompt=compact(variant), seed=0, **base_spec),
                "ablation", label=label)
            if got is not None:
                results.append({"field": field, "variant": i,
                                "distance": effect_metric(ref_path, got.image_path)})
else:
    # PLACEHOLDER RESULTS — invented distances, chosen so that one field falls
    # below the floor (which is what the exercise insists a real study must
    # find at least once). NOT measurements.
    for field, dists in [("lighting", [0.44, 0.51]), ("scene.surfaces", [0.39, 0.42]),
                         ("style", [0.35, 0.47]), ("camera.motion", [0.19, 0.21])]:
        for i, d in enumerate(dists):
            results.append({"field": field, "variant": i, "distance": d,
                            "placeholder": True})
    print("PLACEHOLDER ablation distances — invented, not measured.\\n")

by_field = {}
for r in results:
    by_field.setdefault(r["field"], []).append(r["distance"])

ranked = sorted(((f, float(np.mean(v)), float(np.std(v)), len(v))
                 for f, v in by_field.items()), key=lambda t: -t[1])

print(f"{'field':<18}{'mean effect':>13}{'sd':>8}{'n':>4}{'x floor':>10}  verdict")
print("-" * 74)
for field, mean, sd, n in ranked:
    ratio = mean / noise_floor if noise_floor else float("nan")
    verdict = ("clearly above the floor" if ratio >= 2.0 else
               "marginal — not distinguishable from seed noise" if ratio >= 1.2 else
               "NO DETECTABLE EFFECT at this sample size")
    print(f"{field:<18}{mean:>13.4f}{sd:>8.4f}{n:>4}{ratio:>10.2f}  {verdict}")
print(f"\\nnoise floor = {noise_floor:.4f} (mean over {len(floor_samples)} seed pairs)")

below = [f for f, mean, _, _ in ranked if noise_floor and mean / noise_floor < 1.2]
assert below, ("every field cleared the floor — a study where everything mattered has "
               "no control. Widen the floor measurement or add a field you expect to "
               "be ignored.")
print(f"honestly reported as having no detectable effect: {below}")
''')

nb.model_answer(
    "**What the model appears to ignore, and what that implies for making training "
    "data.**\n\n"
    "The ranking above puts `camera.motion` at the bottom, below or barely at the noise "
    "floor, while `lighting`, `scene.surfaces` and `style` all clear it. Two "
    "explanations are consistent with that, and they have opposite consequences, so the "
    "honest answer names both.\n\n"
    "**Explanation A: the metric is blind to it.** This was stated in `effect_metric`'s "
    "docstring *before* the run, which is the only reason it can be offered now without "
    "it sounding like an excuse. A colour histogram is spatially blind; a dolly changes "
    "composition while leaving the colour distribution nearly untouched. The edge term "
    "helps a little and not enough. **This explanation is also structurally favoured by "
    "the experiment design**: the ablation ran `text2image` with `num_frames=1`, and "
    "camera *motion* is a temporal property. A single frame cannot dolly. Asking a "
    "one-frame generation to express camera motion is close to asking it to express "
    "duration.\n\n"
    "**Explanation B: the model genuinely under-weights it.** Also plausible. The field "
    "sits inside a nested object (`camera.motion`) rather than at the top level, it is "
    "one short string among several hundred tokens, and diffusion conditioning is known "
    "to be dominated by the strongest global signals — lighting and style are global, "
    "camera motion is not.\n\n"
    "**How to tell them apart, which is the experiment this study should trigger:** "
    "re-run the `camera.motion` ablation as `text2video` and score with a temporal "
    "metric — optical-flow magnitude, or `cc.check_video`'s `temporal_change`. If the "
    "effect appears, it was A. If it does not, it was B. Until that is run, the correct "
    "statement is *\"not detected by this metric in this modality\"*, not *\"the model "
    "ignores camera motion\"*.\n\n"
    "**What this implies for using the model to make training data — the part that "
    "actually matters.** If you generate a synthetic dataset by varying prompt fields and "
    "expect the outputs to vary correspondingly, then any field below the noise floor is "
    "**a label with no signal behind it**. You will produce a dataset in which "
    "`camera.motion: \"slow dolly forward\"` and `camera.motion: \"static\"` are attached "
    "to indistinguishable videos, and a downstream model trained on it will learn that "
    "the label is noise — or worse, will latch onto whatever incidental correlation "
    "exists between the label and the seed. That is a silent data-quality failure and it "
    "does not show up in any loss curve.\n\n"
    "The practical rule: **ablate before you generate a corpus.** The fields that clear "
    "the noise floor are the axes you can vary meaningfully; the ones that do not should "
    "either be dropped from the prompt schema or held constant, and in either case must "
    "not be emitted as labels. This costs a few dozen generations up front and it is "
    "cheaper than discovering it after generating fifty thousand.\n\n"
    "*If the table above came from the placeholder block, the ranking is invented and "
    "chosen to have exactly one field below the floor. The method is the deliverable.*"
)

nb.extend(
    "Everything here is single-field. The interesting question the study cannot answer is "
    "**interaction**: does `lighting` still matter when `style` has already been set to "
    "something dominating? A full factorial over four fields at two levels is sixteen "
    "generations per seed — affordable at 256p — and it would tell you whether the fields "
    "compose or compete. The prediction from how classifier-free guidance works is that "
    "they compete: `style` and `lighting` both act on global tone, so setting a strong "
    "style should measurably shrink the lighting effect. That is a checkable claim, and "
    "checking it is worth more than adding a fifth field to the one-at-a-time table."
)

nb.finish()
