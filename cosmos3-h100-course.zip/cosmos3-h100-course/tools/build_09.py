"""Build 09_generation_audio_guardrail.ipynb.

Almost entirely new. The source DLI course `S-OV-57-V1` never mentions the audio
modes and never mentions the guardrail, despite the guardrail being enabled by
default in every generation run its notebook 03 performs — and despite it being
the only component in the whole stack that still requires a licence click.

Two things this lesson exists to teach:

* `audio_image2video`, and why Cosmos3-Edge cannot do it;
* that a guardrail rejection is a **clean-exit failure** — return code 0, a
  valid file on disk, and nothing useful in it. That is the strongest possible
  motivation for `cosmos_course.checks.verify_result`, and it is demonstrated
  here twice: once deterministically with a synthesised blank clip, and once for
  real with a prompt written to trip the filter.

It also corrects the source's premise that five repositories need licence
acceptance. One does.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 09 — Audio-visual generation and the guardrail")

# =====================================================================
# Title and objectives
# =====================================================================
nb.md("""
# Lesson 09 — Audio-visual generation and the guardrail

**What you will build.** `outputs/09/` containing a video that carries an audio
stream, and `failure_signatures.md` — your own written record of what a
guardrail rejection, an out-of-memory failure and a codec failure each look like
*on your machine*, so you can tell them apart at a glance next time.

| | |
|---|---|
| **Time** | ~90 minutes |
| **GPU** | 1 × H100 80 GB, exclusively. |
| **Downloads** | Cosmos3-Nano (34.9 GB) if you skipped Lesson 08, plus **`nvidia/Cosmos-Guardrail1`, ~3.6 GB — the one gated repository in the entire Cosmos 3 stack.** |
| **Prerequisites** | Lesson 08. Lesson 04's plausibility screening is useful context but not required. |

Two things the source course never taught, and one of them has been running
inside every generation you have done since Lesson 01 without being mentioned.
""")

nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Run** `audio_image2video` on Cosmos3-Nano and **verify** the output carries
   an audio stream, using `ffprobe` rather than by listening.
2. **Explain** why Cosmos3-Edge cannot do this, and cite where that constraint
   lives.
3. **Describe** where the guardrail sits in the pipeline, what it screens, and
   that it is on by default.
4. **Accept** the one gated licence and **diagnose** the 401/403 that follows
   from not having accepted it — the only gating error in this course.
5. **Demonstrate** that a guardrail rejection produces a valid file and a return
   code of 0, and **classify** a run as blocked, failed or succeeded from its
   evidence.
6. **Measure** the VRAM and wall-clock cost of the guardrail, with and without
   `--offload-guardrail-models`, and make a recommendation you can defend.
7. **Argue** a position on disabling the guardrail in a research pipeline, and
   state what you would be taking responsibility for.
""")

# =====================================================================
# Audio conditioning
# =====================================================================
nb.md("""
## Sound, and which models have it

Two of the ten model modes involve audio, and they do different things.

**`audio_image2video`** takes an image *and an audio track* and generates video
conditioned on both. The image pins the first frame exactly as in Lesson 07; the
audio is encoded by a sound tokenizer and conditions the whole clip temporally.
The result is video whose motion is synchronised to the sound — footsteps that
land on the beats, water that splashes when you hear it splash, a mouth that
moves when there is speech.

**`text2video` with `enable_sound: true`** goes the other way: no audio input,
and the model generates a soundtrack alongside the picture. The cookbook ships
`robot_pouring_water_audio.json` for exactly this.

Neither works on Cosmos3-Edge, and the reason is architectural rather than a
licensing or packaging decision: **Edge has no sound tokenizer**. There is no
component in that checkpoint that turns a waveform into tokens the transformer
can attend to, and none that turns tokens back into a waveform. It is not a flag
you can turn on.

Check that against the installed package rather than believing this page. The
next cell needs no GPU, no model and no download.
""")

nb.code('''
# Runs before the standard configuration cell: a capability question should not
# need a GPU. Imports only the course package.
import json
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

COURSE_ROOT_PROBE = Path.cwd()
while not (COURSE_ROOT_PROBE / "cosmos_course").is_dir() \\
        and COURSE_ROOT_PROBE != COURSE_ROOT_PROBE.parent:
    COURSE_ROOT_PROBE = COURSE_ROOT_PROBE.parent
sys.path.insert(0, str(COURSE_ROOT_PROBE))
import cosmos_course as cc0

print(f"{'tier':<15} {'audio':>6} {'transfer':>9} {'max res':>8} {'inference VRAM':>15}")
for tier, facts in cc0.MODEL_TIERS.items():
    if "Policy" in tier:
        continue
    print(f"{tier:<15} {str(facts['supports_audio']):>6} "
          f"{str(facts['supports_transfer']):>9} {facts['max_resolution_tier']:>8} "
          f"{str(facts['inference_vram_gb']) + ' GB':>15}")

print()
print("audio_image2video requires the fields:",
      ", ".join(sorted(cc0.specs.REQUIRED_FIELDS["audio_image2video"])))
print()
print("So: Nano and Super carry sound. Super needs ~128 GB for framework")
print("inference and will not fit an 80 GB card. Nano is the only option here,")
print("and that is a hardware fact rather than a preference.")
''')

# =====================================================================
# Environment
# =====================================================================
nb.md("""
## Environment

Standard configuration cell, then the Nano gate again — same shape as Lesson 08,
so if you did that lesson the checkpoint is already cached and this is free.

New in this lesson: the guardrail check. `nvidia/Cosmos-Guardrail1` is roughly
3.6 GB and it is **gated**, which means a licence click on the Hugging Face
model page and a token this process can see. If you did Lesson 01 you have
already done that; the cell confirms it rather than assuming.
""")

nb.code('# This lesson writes to outputs/09/. The setup cell below reads this name.\n'
        '__lesson__ = "09"\n\n' + SETUP_CELL)

nb.code('''
from cosmos_course.measure import MeasurementLog
from cosmos_course.models import Generator, RunResult, diagnose

MODEL = "Cosmos3-Nano"          # overrides the setup cell: Edge has no sound tokenizer


def hf_cache_dir(repo_id):
    root = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface")) / "hub"
    return root / ("models--" + repo_id.replace("/", "--"))


def dir_size_gb(path):
    path = Path(path)
    if not path.exists():
        return 0.0
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file()) / 1e9


# Set True only after reading the sizes printed below.
ALLOW_DOWNLOAD = False

nano_cached = dir_size_gb(hf_cache_dir(cc.MODEL_TIERS[MODEL]["hf_repo"]))
guard_cached = dir_size_gb(hf_cache_dir("nvidia/Cosmos-Guardrail1"))
needs = []
if nano_cached < 5.0:
    needs.append((cc.MODEL_TIERS[MODEL]["hf_repo"], cc.MODEL_TIERS[MODEL]["download_gb"]))
if guard_cached < 0.5:
    needs.append(("nvidia/Cosmos-Guardrail1  (GATED)",
                  cc.AUXILIARY_DOWNLOADS_GB["nvidia/Cosmos-Guardrail1"]))

print(f"{MODEL:<28} {nano_cached:>6.1f} GB cached")
print(f"{'nvidia/Cosmos-Guardrail1':<28} {guard_cached:>6.1f} GB cached")
if needs:
    print(f"\\nA run will download up to {sum(s for _, s in needs):.1f} GB:")
    for name, size in needs:
        print(f"    {size:>6.2f} GB  {name}")
else:
    print("\\nNothing to download.")

generator = Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=True)

if MODE == "full":
    RES, N_FRAMES, N_STEPS = "480", 121, 35
else:
    RES, N_FRAMES, N_STEPS = "480", 61, 12
RUN_TIMEOUT = 5400 if MODE == "full" else 2400

RUN = ((not framework_problems) and DEVICE.startswith("cuda")
       and (not needs or ALLOW_DOWNLOAD))
print()
print(f"mode {MODE!r}: {RES}p, {N_FRAMES} frames, {N_STEPS} steps")
print(f"generation enabled: {RUN}")
''')

nb.md("""
The measurement harness is the one from Lessons 06 to 08, with one addition:
`run_and_verify` now takes `extra_args`, because the guardrail experiments in
this lesson are about a command-line flag.
""")

nb.code('''
CALIB_PATH = cc.OUTPUT_ROOT / "06" / "calibration.json"
CALIB = json.loads(CALIB_PATH.read_text()) if CALIB_PATH.exists() else {}
log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
RUNS = {}


class GpuSampler:
    """Poll device-wide VRAM on a thread; report the peak, in GB."""

    def __init__(self, interval=1.0, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_gb()
            if value is not None:
                self.samples.append(value)

    def __enter__(self):
        self.samples = [self._read_gb() or 0.0]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None


def predict_seconds(resolution, num_frames, num_steps, aspect_ratio="16,9"):
    """Predicted wall clock from Lesson 06's calibration, or None."""
    ups = CALIB.get("units_per_second")
    if not ups:
        return None
    units = cc.estimate_generation_cost(
        resolution=resolution, num_frames=num_frames, num_steps=num_steps,
        aspect_ratio=aspect_ratio)["cost_units"]
    return (CALIB.get("fixed_overhead_s") or 0.0) + units / ups


print(f"calibration: "
      + (f"{CALIB['units_per_second']:,.0f} units/s from {CALIB_PATH}"
         if CALIB.get("units_per_second") else "MISSING — run Lesson 06 for time predictions"))
''')

nb.code('''
def run_and_verify(spec, subdir, *, label=None, extra_args=None, verify=True):
    """Run, sample VRAM, verify by content, record. Returns the RunResult."""
    label = label or spec.name
    if not RUN:
        print(f"skipped {label!r}: generation is disabled")
        return None
    for problem in cc.validate_spec(spec, strict=False):
        print("  spec warning:", problem)

    predicted = predict_seconds(spec.resolution, spec.num_frames or 1,
                                spec.num_steps or 1, spec.aspect_ratio or "16,9")
    print(f"{label}: predicted "
          + (f"{predicted / 60:.1f} min" if predicted else "n/a (no calibration)"))

    with GpuSampler() as sampler:
        with cc.timer(label, track_memory=False) as timing:
            result = generator.run(spec, OUTPUT_DIR / subdir, seed=spec.seed or 0,
                                   extra_args=extra_args, timeout=RUN_TIMEOUT)

    RUNS[label] = {"seconds": timing.seconds, "peak_gb": sampler.peak_gb,
                   "predicted_s": predicted,
                   "extra_args": list(extra_args or []), "result": result}
    log.record(label=label, model=MODEL, mode=MODE,
               **{k: v for k, v in RUNS[label].items() if k != "result"})
    print(f"\\n  {timing.seconds:.1f} s, peak device VRAM {sampler.peak_gb:.1f} GB"
          + (f"  (predicted {predicted:.0f} s, "
             f"{100 * (predicted - timing.seconds) / timing.seconds:+.0f}%)"
             if predicted else ""))
    if verify:
        print()
        cc.verify_result(result)
    return result


def compact(obj):
    if isinstance(obj, (str, Path)):
        obj = json.loads(Path(obj).read_text())
    return json.dumps(obj, ensure_ascii=True, separators=(",", ":"))


def has_audio(path):
    """Does this file carry an audio stream? Returns the codec name, or None."""
    ffprobe = shutil.which("ffprobe")
    if ffprobe is None:
        return "unknown (ffprobe not installed)"
    try:
        out = subprocess.run(
            [ffprobe, "-v", "error", "-select_streams", "a:0",
             "-show_entries", "stream=codec_name,channels,sample_rate",
             "-of", "default=nw=1", str(path)],
            capture_output=True, text=True, timeout=60, check=True).stdout.strip()
    except Exception:
        return None
    return out or None


print("harness ready")
''')

# =====================================================================
# The assets
# =====================================================================
nb.md("""
## The audio assets, and an honest gap

`COSMOS3_FACTS.md` §6 lists the audiovisual cookbook's contents, and there is
something missing from the list: it names
`prompts/image2video/coastal_road_audio.json` and
`images/image2video/coastal_road_audio.jpg`, but **no audio file**. Yet
`audio_image2video` requires `sound_path`.

Rather than invent a filename and present it as documented, the cell below goes
and looks. It searches the audiovisual asset tree for anything with an audio
extension and reports what it finds. Two outcomes, both fine:

* **A sound file exists.** Good — you can run the real `audio_image2video`
  example below.
* **Nothing is found.** Then the cookbook checkout does not ship one, and the
  lesson takes the `text2video` + `enable_sound` route instead, which needs no
  external audio at all. You lose the conditioning demonstration and keep the
  audio-generation demonstration.

Reporting a gap and routing around it is a better habit than guessing at a path
and getting a `FileNotFoundError` two cells later.
""")

nb.code('''
AUDIO_SUFFIXES = (".wav", ".mp3", ".m4a", ".flac", ".aac", ".ogg", ".opus")
audiovisual_root = cc.COOKBOOK / "generator" / "audiovisual"

sound_candidates = []
if audiovisual_root.exists():
    for path in sorted(audiovisual_root.rglob("*")):
        if path.is_file() and path.suffix.lower() in AUDIO_SUFFIXES:
            sound_candidates.append(path)
else:
    print(f"cookbook not found at {audiovisual_root}")
    print("Run `python scripts/fetch_assets.py` to clone it.")

print(f"audio files found in the audiovisual cookbook: {len(sound_candidates)}")
for path in sound_candidates[:10]:
    print(f"  {path.relative_to(cc.COOKBOOK)}  ({path.stat().st_size / 1e6:.2f} MB)")

# Prefer one whose name matches the coastal-road example, else take any.
SOUND_PATH = None
for path in sound_candidates:
    if "coastal" in path.stem.lower():
        SOUND_PATH = path
        break
if SOUND_PATH is None and sound_candidates:
    SOUND_PATH = sound_candidates[0]

COASTAL_IMAGE = cc.asset_or_none("image_coastal_road_audio")
COASTAL_PROMPT = cc.asset_or_none("prompt_coastal_road_audio")
POURING_PROMPT = cc.asset_or_none("prompt_robot_pouring_audio")

print()
print(f"conditioning image : {COASTAL_IMAGE or 'missing'}")
print(f"conditioning prompt: {COASTAL_PROMPT or 'missing'}")
print(f"sound file         : {SOUND_PATH or 'NONE FOUND — the a2v path will be skipped'}")
print(f"text2video prompt  : {POURING_PROMPT or 'missing'}")
if COASTAL_IMAGE:
    cc.show_image(COASTAL_IMAGE, width=460, caption="the coastal road first frame")
''')

nb.md("""
### Route one: generate a soundtrack

`text2video` with `enable_sound=True` asks the model to produce audio alongside
the picture. No audio input, nothing to source, and it works whenever Nano
works. `validate_spec` will tell you that `enable_sound` is only meaningful for
`text2video` and `audio_image2video` — try it on `text2image` and see.

Verify with `ffprobe`, not with your ears. "I think I heard something" is not a
test you can put in a pipeline, and a silent-but-present audio stream is a
different failure from no stream at all.
""")

nb.code('''
pouring_prompt_obj = (json.loads(POURING_PROMPT.read_text()) if POURING_PROMPT else {
    "description": "A robot arm pours water from a glass jug into a metal sink. "
                   "The water splashes audibly as it lands.",
    "camera": {"motion": "static", "framing": "medium close-up"},
})
neg_t2v = cc.asset_or_none("neg_prompt_t2v")

sound_spec = cc.InferenceSpec(
    model_mode="text2video", name="t2v_with_sound",
    prompt=compact(pouring_prompt_obj),
    negative_prompt=compact(neg_t2v) if neg_t2v else None,
    resolution=RES, aspect_ratio="16,9",
    num_frames=N_FRAMES, fps=24, num_steps=N_STEPS,
    guidance=7.0, shift=10.0, seed=0,
    enable_sound=True,
)
print(sound_spec.describe())
print()
print("enable_sound on the wrong mode is caught locally:")
for problem in cc.validate_spec(
        {"model_mode": "text2image", "name": "x", "prompt": "y", "enable_sound": True},
        strict=False):
    print("  " + problem)
print()

sound_result = run_and_verify(sound_spec, "audio", label="t2v_with_sound")
if sound_result is not None and sound_result.video_path:
    stream = has_audio(sound_result.video_path)
    print()
    print(f"audio stream in {sound_result.video_path.name}:")
    print("  " + (stream.replace("\\n", "  ") if stream else "NONE — the file is silent"))
    print()
    print("A missing stream here is informative rather than fatal: it tells you")
    print("`enable_sound` was accepted by the validator and not honoured by the")
    print("pipeline on this build. Record that as a fact about your installation.")
    cc.show_video(sound_result.video_path, width=520, caption="text2video with enable_sound")
''')

nb.md("""
### Route two: condition on audio

`audio_image2video` needs three things: `prompt`, `vision_path` and
`sound_path`. The image is pinned as the first latent slice exactly as in Lesson
07; the audio is tokenised and conditions the sequence across time.

The interesting question is what the audio actually buys you, and the honest
answer is *synchronisation*. The prompt says what the scene is; the image says
what it looks like; the audio says **when things happen**. That is a temporal
signal no amount of prompt engineering supplies, which is why this mode exists
rather than being folded into `image2video`.
""")

nb.code('''
a2v_result = None
if SOUND_PATH is None:
    print("No audio file in the cookbook checkout, so audio_image2video is skipped.")
    print("This is a missing-asset condition, not a failure of the mode:")
    print("  - run `python scripts/fetch_assets.py` and check the audiovisual tree")
    print("  - or supply your own short wav and set SOUND_PATH by hand")
    print()
    print("What it would look like, for reference:")
    print(json.dumps({
        "model_mode": "audio_image2video", "name": "a2v_coastal_road",
        "prompt": "<structured JSON as a string>",
        "vision_path": "<absolute path to coastal_road_audio.jpg>",
        "sound_path": "<absolute path to the audio file>",
        "resolution": RES, "aspect_ratio": "16,9",
        "num_frames": N_FRAMES, "fps": 24, "num_steps": N_STEPS,
    }, indent=2))
elif COASTAL_IMAGE is None:
    print("The coastal road image is missing — run scripts/fetch_assets.py")
else:
    coastal_prompt_obj = (json.loads(COASTAL_PROMPT.read_text()) if COASTAL_PROMPT
                          else {"description": "A coastal road seen from a moving vehicle, "
                                               "waves breaking below."})
    neg_i2v = cc.asset_or_none("neg_prompt_i2v")
    a2v_spec = cc.InferenceSpec(
        model_mode="audio_image2video", name="a2v_coastal_road",
        prompt=compact(coastal_prompt_obj),
        negative_prompt=compact(neg_i2v) if neg_i2v else None,
        vision_path=str(COASTAL_IMAGE),
        sound_path=str(SOUND_PATH),
        resolution=RES, aspect_ratio="16,9",
        num_frames=N_FRAMES, fps=24, num_steps=N_STEPS,
        guidance=7.0, shift=10.0, seed=0,
    )
    print(a2v_spec.describe())
    print()
    a2v_result = run_and_verify(a2v_spec, "audio", label="a2v_coastal_road")
    if a2v_result is not None and a2v_result.video_path:
        print()
        print("audio stream:", has_audio(a2v_result.video_path) or "NONE")
        cc.show_video(a2v_result.video_path, width=520,
                      caption="audio_image2video: image + audio in, video out")
''')

# =====================================================================
# The guardrail
# =====================================================================
nb.md("""
## The guardrail

Every generation you have run since Lesson 01 has passed through a safety
component you were never told about, because it is on by default. It is worth
knowing where it sits.

```
  your prompt ──► [ prompt screen ]──► text encoder ──► denoising loop
                        │                                     │
                     rejected                                 ▼
                        │                              VAE decode
                        │                                     │
                        │                                     ▼
                        │                          [ frame screen ]
                        │                                     │
                        ▼                                  rejected
                 blanked / empty output ◄──────────────────────┘
                        │
                        ▼
                  file written, exit 0
```

Two screens, at two ends. The **prompt screen** is a text classifier — in this
stack, `Qwen/Qwen3Guard-Gen-0.6B`, one of the auxiliary downloads you saw in
Lesson 06. The **frame screen** inspects the generated pixels, and includes
face blurring as well as content classification.

Follow the arrows to the bottom. A rejection does not raise, does not set a
non-zero exit code, and does not necessarily leave an obvious message in the
log. It produces a blanked or empty output and the pipeline continues.

**This is the entire reason `cosmos_course.checks` exists.** Everything the
course has said about exit codes being insufficient evidence has been building
toward this, and you are about to make it happen twice.

### The one gated repository

`nvidia/Cosmos-Guardrail1` is the only repository in the Cosmos 3 stack that
still requires a licence acceptance. All nine Cosmos3 checkpoints return
`gated: false`. The source DLI course spends an entire notebook on accepting
five licences; that notebook is obsolete, and the one click that remains is this
one.

There is also a **naming split** worth knowing: the cookbook points at
`nvidia/Cosmos-1.0-Guardrail` while the framework uses
`nvidia/Cosmos-Guardrail1`. Both exist, both are gated, and which one your run
pulls depends on which code path you took. Check your cache rather than assuming.
""")

nb.callout("upstream", """
The naming split is not a typo in this course: `COSMOS3_FACTS.md` §7 records
both repositories as real and both as gated. Accepting one licence does not
grant the other, which produces a genuinely confusing failure — the run works
through the framework and 403s through a cookbook script, or the reverse. The
cell below checks both and reports which one is actually in your cache, because
that is the only reliable way to know which path your installation took.
""")

nb.code('''
for repo in ("nvidia/Cosmos-Guardrail1", "nvidia/Cosmos-1.0-Guardrail"):
    info = cc.check_hf_access(repo)
    cached = dir_size_gb(hf_cache_dir(repo))
    print(f"    cached locally: {cached:.2f} GB")
    print()

print("For contrast, a Cosmos 3 checkpoint:")
cc.check_hf_access("nvidia/Cosmos3-Nano")
print()
print(f"HF_TOKEN visible to this kernel: "
      f"{bool(os.environ.get('HF_TOKEN') or os.environ.get('HUGGING_FACE_HUB_TOKEN'))}")
print("(Presence only. The value is never printed, logged or written to a file.)")
''')

nb.md("""
### Accepting the licence, once

If the check above reported 401 or 403 for `Cosmos-Guardrail1`, do this now.
It takes under a minute and access is granted immediately — there is no review
queue.

1. Open `https://huggingface.co/nvidia/Cosmos-Guardrail1` while signed in.
2. Read the licence and click accept. The page changes to show the file list.
3. Make sure a token is visible **to this process**:
   `export HF_TOKEN=hf_...` in the shell you launched Jupyter from, or run
   `huggingface-cli login`. A token set in a different terminal after Jupyter
   started is not inherited — that is the single most common reason step 3 looks
   done and is not.
4. **Restart the kernel** so it picks up the new environment, then re-run the
   check above.

You can pass `--no-guardrails` to skip the component entirely. Understand what
that is before you do it: it is the safety filter, and turning it off is a
decision you are taking responsibility for, not a workaround for a download you
did not want. The last section of this lesson asks you to argue a position on
it.
""")

# =====================================================================
# Clean-exit failure
# =====================================================================
nb.md("""
## A clean exit that produced nothing

Before spending GPU minutes trying to trip a filter, here is the failure
signature, constructed deterministically so it works on every machine every
time.

The cell below synthesises a flat grey video with `ffmpeg` — exactly what a
blanked output looks like — wraps it in a real `RunResult` with return code 0
and one output file, and runs the course's standard verification over it.

Watch what happens. `RunResult.ok` is **True**: the exit code is zero and a file
exists, which is all `ok` claims to check. `verify_result` disagrees, because it
opened the file.

Watch the *reason* it gives, too. A flat grey video compresses to almost
nothing, so `check_video` is likely to reject it for being a few kilobytes
before it ever gets far enough to notice that the frames are uniform. Both
verdicts mean the same thing — there is no picture in this file — and a
classifier that only looks for the word "flat" will miss half of them. That is a
bug worth avoiding rather than discovering in production.
""")

nb.code('''
BLANK = OUTPUT_DIR / "synthetic_blank.mp4"
ffmpeg = shutil.which("ffmpeg")
if ffmpeg and not BLANK.exists():
    subprocess.run([ffmpeg, "-y", "-loglevel", "error",
                    "-f", "lavfi", "-i", "color=c=gray:s=320x180:d=2:r=24",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", str(BLANK)],
                   check=True, capture_output=True, text=True, timeout=120)

if BLANK.exists():
    fake = RunResult(returncode=0, seconds=42.0, outputs=[BLANK],
                     stdout_tail="Guardrail: input prompt did not pass the safety check.\\n"
                                 "Writing output.\\nDone.")
    print(f"returncode      : {fake.returncode}")
    print(f"output files    : {len(fake.outputs)}  ({BLANK.name}, "
          f"{BLANK.stat().st_size / 1024:.1f} KB)")
    print(f"RunResult.ok    : {fake.ok}      <- exit code 0 AND a file exists")
    print()
    print("Now open the file:")
    print()
    checks = cc.verify_result(fake)
    print()
    print("The process check passed. The video check did not. That gap, between")
    print("'the program finished' and 'the program was right', is the whole point")
    print("of cosmos_course.checks — and it is not hypothetical: it is what a")
    print("guardrail rejection looks like from the outside.")
else:
    print("ffmpeg is not installed, so the blank clip could not be synthesised.")
    print("Install ffmpeg (`apt install ffmpeg`) to run this demonstration.")
''')

nb.md("""
### A classifier for run outcomes

Three outcomes, and a pipeline needs to tell them apart because the right
response differs: a **blocked** run should be logged and skipped, a **failed**
run should be retried or escalated, and a **succeeded** run should be kept.
Treating all three as "not ok" throws away the information that decides what to
do next.

The function below is deliberately conservative. It looks at the return code
first (a non-zero code is conclusive evidence of failure), then at whether any
output exists, then at whether the content passes, and only then reaches for the
log text. Log-string matching is the least reliable signal — messages change
between releases — so it is used to *explain* a verdict rather than to reach one.
""")

nb.code('''
GUARDRAIL_MARKERS = ("guardrail", "blocked", "safety", "did not pass",
                     "content policy", "nsfw", "rejected")

# Reasons `cc.checks` gives that all mean "there is no picture in this file".
# Note the size ones. A flat frame compresses to almost nothing, so a blanked
# output frequently arrives as a suspiciously tiny file and the checker reports
# the size before it ever gets far enough to notice the flatness.
BLANK_MARKERS = ("flat", "single colour", "essentially empty", "only ",
                 "barely change", "decoded only")


def classify_run(result):
    """Return (verdict, reason). Verdicts: succeeded | blocked | failed | not_run."""
    if result is None:
        return "not_run", "generation was disabled or the cell was skipped"

    log_text = (result.stdout_tail or "").lower()
    guardrail_hit = [m for m in GUARDRAIL_MARKERS if m in log_text]

    if result.returncode != 0:
        return "failed", (f"non-zero exit ({result.returncode})"
                          + (f"; log also mentions {guardrail_hit}" if guardrail_hit else ""))

    if not result.outputs:
        return ("blocked" if guardrail_hit else "failed",
                "exit 0 but no output files"
                + (f"; log mentions {guardrail_hit}" if guardrail_hit
                   else "; nothing in the log points at the guardrail, so treat this "
                        "as an unexplained failure and read the full stdout"))

    failures = [c for c in cc.verify_result(result, verbose=False) if not c.passed]
    if not failures:
        return "succeeded", "exit 0, output present, every content check passed"

    blank = [c for c in failures
             if any(marker in c.reason.lower() for marker in BLANK_MARKERS)]
    if blank:
        return ("blocked" if guardrail_hit else "blocked?",
                f"exit 0 and a file, but there is no picture in it ({blank[0].reason[:70]}) "
                f"— the signature of a screened output"
                + (f"; log mentions {guardrail_hit}" if guardrail_hit
                   else "; the log does not confirm it, so verify before reporting"))

    return "failed", "output exists but failed: " + "; ".join(c.name for c in failures)


if BLANK.exists():
    print("on the synthetic blank clip:", classify_run(fake))
print("on a run that did not happen  :", classify_run(None))
for label, entry in RUNS.items():
    print(f"on {label:<22}:", classify_run(entry["result"]))
''')

# =====================================================================
# Predict-run-explain 1 — the blocked prompt
# =====================================================================
nb.predict_run_explain(
    predict=(
        "The next cell submits a prompt written to trip the safety filter. "
        "Predict three things and write them down: the return code, whether an "
        "output file is created, and what `check_video` will say about that file "
        "if it exists."
    ),
    change=(
        "Nothing to edit — and do not escalate the prompt. It is deliberately at "
        "the mild end of what a filter targets, and making it worse teaches you "
        "nothing you will not learn from this one."
    ),
    explain=(
        "Compare what you got against your prediction, and against the "
        "synthetic blank above. Then answer the question this whole lesson is "
        "for: what would a pipeline that trusts return codes have done with this "
        "run?"
    ),
    hint=(
        "There are three plausible outcomes and the lesson works for all of "
        "them: the prompt is blocked and you get a blank file, the prompt is "
        "blocked and you get no file, or the prompt passes and you get a normal "
        "video. Which one you see depends on your guardrail build. Record which "
        "it was — that is the signature you are here to learn."
    ),
)

nb.code('''
# A prompt written to trip the text screen. It is clinical and brief on purpose:
# the goal is to exercise the filter, not to put unpleasant content in a lesson.
# Do not make it worse — there is nothing further to learn by doing so.
BLOCKABLE_PROMPT = {
    "description": ("Graphic close-up of a severe traffic collision with visible "
                    "injuries to the driver, blood on the windscreen."),
    "camera": {"framing": "close-up", "motion": "static"},
}

blocked_spec = cc.InferenceSpec(
    model_mode="text2video", name="deliberately_blockable",
    prompt=compact(BLOCKABLE_PROMPT),
    resolution=RES, aspect_ratio="16,9",
    num_frames=N_FRAMES, fps=24, num_steps=max(8, N_STEPS // 2),
    guidance=7.0, shift=10.0, seed=0,
)

blocked_result = run_and_verify(blocked_spec, "guardrail",
                                label="deliberately_blockable", verify=False)

verdict, reason = classify_run(blocked_result)
print()
print(f"verdict : {verdict}")
print(f"reason  : {reason}")
if blocked_result is not None:
    print(f"returncode : {blocked_result.returncode}")
    print(f"outputs    : {[p.name for p in blocked_result.outputs]}")
    print(f"RunResult.ok (exit code + a file): {blocked_result.ok}")
    print()
    cc.verify_result(blocked_result)
    hits = [line for line in (blocked_result.stdout_tail or "").splitlines()
            if any(m in line.lower() for m in GUARDRAIL_MARKERS)]
    print()
    print(f"log lines mentioning the guardrail: {len(hits)}")
    for line in hits[:6]:
        print("  " + line.strip()[:110])
''', tags=["teaching-antipattern"])

nb.md("""
Whatever you got, write it into `failure_signatures.md` now, while the detail is
fresh. The point of that file is that in three weeks, when a batch job produces
forty files and eleven of them are wrong, you will want to recognise the shape
of the failure without re-deriving it.

The three signatures to record, and how they differ:

| Failure | Exit code | Output file | Log |
|---|---|---|---|
| Guardrail rejection | 0 | present but blank, or absent | may mention "guardrail" or "blocked"; sometimes silent |
| CUDA out of memory | non-zero | absent | `torch.OutOfMemoryError`, an allocation size, a free/total pair |
| Codec / decode failure | varies | absent, or a file with zero frames | decoder errors, or HTTP 422 from the NIM |

Only the first has a zero exit code. That is what makes it dangerous.
""")

nb.code('''
SIGNATURES = OUTPUT_DIR / "failure_signatures.md"
guardrail_verdict, guardrail_reason = classify_run(blocked_result)

lines = [
    "# Failure signatures on this machine",
    "",
    f"Recorded {time.strftime('%Y-%m-%d')}, model {MODEL}, mode {MODE}.",
    "",
    "## Guardrail rejection",
    "",
    f"- verdict from `classify_run`: **{guardrail_verdict}**",
    f"- reason: {guardrail_reason}",
]
if blocked_result is not None:
    lines += [
        f"- return code: `{blocked_result.returncode}`",
        f"- output files: {[p.name for p in blocked_result.outputs] or 'none'}",
        f"- `RunResult.ok`: `{blocked_result.ok}`",
    ]
else:
    lines.append("- not reproduced (generation was disabled)")

lines += [
    "",
    "## CUDA out of memory",
    "",
    "- return code: non-zero (torchrun reports the worker group failed)",
    "- output files: none",
    "- log: `torch.OutOfMemoryError`, an allocation size, and a free/total pair.",
    "- See Lesson 06's debugging lab for the full traceback and the ladder.",
    "",
    "## Codec or decode failure",
    "",
    "- reaching the Reasoner NIM: HTTP 422 with zero frames decoded (AV1 input).",
    "- fix: `Reasoner.ensure_h264(path)`; see Lesson 02.",
    "",
    "## The rule",
    "",
    "Only the guardrail rejection exits zero. An exit code separates the other",
    "two from success; nothing but reading the output separates the first one.",
    "",
]
SIGNATURES.write_text("\\n".join(lines) + "\\n")
print(f"wrote {SIGNATURES}")
print()
print("\\n".join(lines[:14]))
''')

# =====================================================================
# Predict-run-explain 2 — offloading
# =====================================================================
nb.predict_run_explain(
    predict=(
        "`--offload-guardrail-models` keeps the guardrail's weights on the host "
        "and moves them to the GPU only when a screen is needed. Predict two "
        "numbers: the change in **peak device VRAM** and the change in **wall "
        "clock**, each as a direction and a rough magnitude. Then predict which "
        "of the two changes more, proportionally."
    ),
    change=(
        "Nothing to edit; the cell runs the same spec twice, once with the flag "
        "and once without. Commit to both numbers first."
    ),
    explain=(
        "One of the two barely moved. Explain why, in terms of *when* the "
        "guardrail is resident relative to when the peak occurs, and say whether "
        "this flag would have saved the Lesson 06 out-of-memory failure."
    ),
    hint=(
        "The peak VRAM of a diffusion run happens inside the denoising loop, and "
        "the guardrail is not screening anything at that moment — it screened the "
        "prompt before the loop and it will screen the frames after. So ask "
        "yourself whether its weights being resident during the loop contributes "
        "to the peak, or merely to the baseline."
    ),
)

nb.code('''
short_prompt = {
    "description": "A wide static shot of an empty workshop bench in daylight.",
    "camera": {"motion": "static"},
}

offload_rows = []
for label, extra in (("guardrail resident", None),
                     ("guardrail offloaded", ["--offload-guardrail-models"])):
    spec = cc.InferenceSpec(
        model_mode="text2video", name=label.replace(" ", "_"),
        prompt=compact(short_prompt),
        resolution=RES, aspect_ratio="16,9",
        num_frames=N_FRAMES, fps=24, num_steps=max(8, N_STEPS // 2),
        guidance=7.0, shift=10.0, seed=0,
    )
    res = run_and_verify(spec, "guardrail", label=label, extra_args=extra)
    if res is not None:
        offload_rows.append({"label": label, **{k: RUNS[label][k]
                                                for k in ("seconds", "peak_gb")}})
    print("-" * 72)

if len(offload_rows) == 2:
    a, b = offload_rows
    print(f"{'configuration':<22} {'wall clock':>12} {'peak VRAM':>12}")
    for row in offload_rows:
        print(f"{row['label']:<22} {row['seconds']:>10.1f} s {row['peak_gb']:>10.1f} GB")
    def pct(new, old):
        return f"{100 * (new - old) / old:+.1f}%" if old else "n/a"

    print()
    print(f"VRAM change : {b['peak_gb'] - a['peak_gb']:+.2f} GB "
          f"({pct(b['peak_gb'], a['peak_gb'])})")
    print(f"time change : {b['seconds'] - a['seconds']:+.1f} s "
          f"({pct(b['seconds'], a['seconds'])})")
    print()
    print("Both numbers are single measurements on one machine, so treat small")
    print("differences as noise. If you want to claim one, run it three times and")
    print("report a median with a spread — cosmos_course.measure.benchmark does")
    print("exactly that, and Lesson 14 makes it a habit.")
else:
    print("Need both runs to compare. Generation is disabled or one run failed.")
''')

# =====================================================================
# Debugging lab
# =====================================================================
nb.md("""
## Debugging lab — the only gating error in this course

### Symptom

A generation run dies in the first minute, before any progress bar appears, with
a wall of Hugging Face traceback ending in a 401 or a 403. The confusing part is
that you did not ask for the guardrail, you asked for a video — and every Cosmos
3 checkpoint is ungated, so the error appears to be about a model you never
mentioned.
""")

nb.code('''
GATED_TRACEBACK = """
Traceback (most recent call last):
  File "huggingface_hub/utils/_errors.py", line 304, in hf_raise_for_status
    response.raise_for_status()
requests.exceptions.HTTPError: 401 Client Error: Unauthorized for url:
  https://huggingface.co/api/models/nvidia/Cosmos-Guardrail1/revision/main

The above exception was the direct cause of the following exception:

huggingface_hub.utils._errors.GatedRepoError: 401 Client Error.
Cannot access gated repo for url
  https://huggingface.co/api/models/nvidia/Cosmos-Guardrail1/revision/main
Access to model nvidia/Cosmos-Guardrail1 is restricted.
You must have access to it and be authenticated to access it. Please log in.
E0829 torchrun elastic/agent/server/api.py:733] Worker group failed
"""

print(GATED_TRACEBACK)
print("=" * 72)
for hint in diagnose(GATED_TRACEBACK, returncode=1):
    print(hint)
''')

nb.md("""
### Hypothesis and diagnosis

Hypothesis: the guardrail is enabled by default, it is gated, and this process
cannot authenticate for it. Note the two independent ways that happens, because
they need different fixes and look identical from here:

* **The licence was never accepted.** Then even a valid token gets a 403,
  because the token is fine and the account has no grant.
* **The licence was accepted but no token reached the subprocess.** The
  generator runs as a child process with a cleaned environment; a token set in a
  terminal after Jupyter started is not in Jupyter's environment and therefore
  not in the child's.

`check_hf_access` separates them: it reports `token_present` and the HTTP status
independently, so "no token" and "no grant" are distinguishable rather than both
appearing as "401".
""")

nb.code('''
def diagnose_gating(repo_id="nvidia/Cosmos-Guardrail1"):
    """Separate 'no token' from 'no licence grant' from 'fine'."""
    info = cc.check_hf_access(repo_id, quiet=True)
    token = info["token_present"]
    status = info["status"]

    if info["accessible"]:
        return ("ok", f"{repo_id} is reachable"
                      + (" and gated, with access granted" if info["gated"] else ""))
    if status in (401, 403) and not token:
        return ("no_token",
                "No HF token in this process. Accepting the licence in a browser is "
                "necessary and not sufficient — the subprocess needs credentials.\\n"
                "  export HF_TOKEN=hf_...   in the shell that starts Jupyter, then "
                "RESTART THE KERNEL.")
    if status in (401, 403) and token:
        return ("no_grant",
                f"A token is present but access is refused. Open "
                f"https://huggingface.co/{repo_id} and accept the licence. "
                f"Access is granted immediately; there is no review queue.")
    if status == 404:
        return ("wrong_name",
                f"404 for {repo_id}. Check the spelling — the cookbook says "
                f"nvidia/Cosmos-1.0-Guardrail and the framework says "
                f"nvidia/Cosmos-Guardrail1. Both exist.")
    return ("unknown", f"status {status}; are you offline?")


for repo in ("nvidia/Cosmos-Guardrail1", "nvidia/Cosmos-1.0-Guardrail"):
    kind, message = diagnose_gating(repo)
    print(f"{repo}")
    print(f"  -> {kind}: {message}")
    print()

print("Which repo did YOUR runs actually pull? Check the cache, not the docs:")
for repo in ("nvidia/Cosmos-Guardrail1", "nvidia/Cosmos-1.0-Guardrail"):
    size = dir_size_gb(hf_cache_dir(repo))
    print(f"  {repo:<32} {size:>6.2f} GB on disk"
          + ("   <- this one" if size > 0.5 else ""))
''')

nb.md("""
### Repair and verification

The repair is the four steps in the licence section above. The verification is
not "the error went away" — it is a positive check that the repository is
reachable *from this process*, run before you spend a minute of GPU time.

That is the general shape worth taking away: gating failures are cheap to check
and expensive to hit, so check them at the top of a pipeline rather than
discovering them at the bottom of a model load.
""")

nb.code('''
def preflight(repo_ids=("nvidia/Cosmos-Guardrail1",)):
    """Run before any generation. Raises with the fix, not just the symptom."""
    problems = []
    for repo in repo_ids:
        kind, message = diagnose_gating(repo)
        if kind != "ok":
            problems.append(f"{repo}: {message}")
    if problems:
        raise RuntimeError("pre-flight failed:\\n  - " + "\\n  - ".join(problems)
                           + "\\n\\n  You can also run without the guardrail entirely by "
                             "passing --no-guardrails, but read the section below first.")
    print("pre-flight ok: every required repository is reachable from this process")
    return True


try:
    preflight()
except RuntimeError as exc:
    print(exc)
''')

nb.md("""
### `--no-guardrails`, and the argument you should be able to make

The flag exists and it works. Before reaching for it, be clear about what it is
and is not.

**What it is not:** a workaround for a download you did not want, or a
performance optimisation. If your objection is VRAM, `--offload-guardrail-models`
addresses that and you have just measured how much. If your objection is the
licence click, the click takes ten seconds.

**What it might legitimately be:** a considered decision in a closed research
pipeline where you are generating content the screen would reject for reasons
that do not apply to you — collision footage for an autonomous-vehicle safety
dataset is the obvious real example — and where you have a different control in
place. "A different control in place" is the load-bearing part of that sentence.

**What you take on when you disable it:** every output is unscreened, including
outputs you did not look at, in a batch you will later hand to someone else. The
guardrail is also doing face blurring; without it, footage that contained
identifiable people may produce outputs that do too.

The challenge exercise asks you to write this argument properly, with your
measurements attached.
""")

nb.callout("warning", """
`--no-guardrails` also disables **face blurring**. If any of your conditioning
images or control videos contain identifiable people, outputs generated without
the guardrail may contain them too — including outputs in a batch you did not
look at and later handed to someone else. That consequence is separate from the
content-classification one and it is the one people forget.
""")

nb.checkpoint(
    "You should have at least one video with a verified audio stream (or a "
    "recorded reason why not), a `failure_signatures.md` in `outputs/09/`, and a "
    "recorded verdict for the deliberately blockable prompt.",
    '''
print(f"{'run':<24} {'verdict':<12} {'audio':<28} {'time':>9}")
for label, entry in RUNS.items():
    verdict = classify_run(entry["result"])[0]
    audio = "-"
    res = entry["result"]
    if res is not None and res.video_path:
        audio = (has_audio(res.video_path) or "none").replace("\\n", " ")[:26]
    print(f"{label:<24} {verdict:<12} {audio:<28} {entry['seconds']:>7.1f} s")

print()
print(f"failure_signatures.md written: {SIGNATURES.exists()}")
print(f"guardrail reachable          : {diagnose_gating()[0] == 'ok'}")
''')

# =====================================================================
# Exercises
# =====================================================================
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "With and without audio conditioning",
    goal=(
        "Establish what the audio track actually contributes, by generating the "
        "same scene with and without it."
    ),
    instructions=(
        "1. Take the `audio_image2video` spec and produce a matched "
        "`image2video` spec: same image, same prompt, same seed, same geometry, "
        "same step count. The only difference is `sound_path` and the mode.\n"
        "2. If your checkout has no audio asset, record a few seconds yourself or "
        "synthesise one — `ffmpeg -f lavfi -i 'sine=frequency=440:duration=3'` "
        "gives you a tone, and a tone with a clear rhythm is actually a better "
        "test than ambient noise because synchronisation is visible.\n"
        "3. Verify both outputs, and check the audio stream on each with "
        "`has_audio`.\n"
        "4. Compare the two clips on a temporal measure — per-frame change over "
        "time is the obvious one — and say whether the audio-conditioned clip's "
        "motion tracks the audio's envelope.\n"
        "5. Write two sentences on what the audio bought you and whether it was "
        "worth the extra mode."
    ),
    success=(
        "Two verified clips differing only in audio conditioning, an audio-stream "
        "check on each, one temporal comparison, and a written verdict."
    ),
    starter='''
def motion_over_time(path, count=24):
    """Per-frame mean absolute change. The video's own envelope."""
    import numpy as np
    frames = []
    try:
        import imageio.v3 as iio
        for i, f in enumerate(iio.imiter(path)):
            frames.append(np.asarray(f).mean(axis=2) if f.ndim == 3 else np.asarray(f))
            if len(frames) >= count:
                break
    except Exception:
        return []
    return [float(abs(frames[i + 1] - frames[i]).mean()) for i in range(len(frames) - 1)]


# Build the matched image2video spec here, run both, then compare the envelopes.
''',
    hints=[
        "A rhythmic tone beats ambient sound for this test: you know exactly when "
        "the events are, so you can look for motion at those frame indices rather "
        "than eyeballing a correlation.\n\n"
        "Hold the seed fixed across both runs. Without that, any difference you "
        "measure could be seed variance, and you will have proved nothing — this "
        "is the same control the Lesson 06 ablation exercise insisted on.",
    ],
    solution_ref="solutions/09_solutions.ipynb",
)

nb.exercise(
    "applied",
    "A guardrail-aware wrapper",
    goal=(
        "Write a wrapper that runs a generation and reports, unambiguously, "
        "whether it was blocked, failed or succeeded — and does something "
        "different in each case."
    ),
    instructions=(
        "1. Build on `classify_run`, but do better than it does. It currently "
        "returns `blocked?` when the content is blank and the log does not "
        "confirm the guardrail. Decide how to resolve that case and justify your "
        "choice.\n"
        "2. Write `generate(spec, *, retries=1)` that runs, classifies, and:\n"
        "   - on **succeeded**, returns the output path;\n"
        "   - on **failed**, retries up to `retries` times if the diagnosis "
        "suggests a retry could help (`RunResult.diagnose()` names the cause), "
        "and raises with the diagnosis otherwise;\n"
        "   - on **blocked**, does *not* retry — a blocked prompt will be blocked "
        "again — and returns a record explaining why.\n"
        "3. Run it over a batch of at least five prompts, including at least one "
        "you expect to be blocked and at least one that should fail for a "
        "different reason (an impossible geometry is an easy one to arrange).\n"
        "4. Produce a summary table: prompt, verdict, reason, time.\n"
        "5. Report the wrapper's own error rate — cases where you disagree with "
        "its verdict after looking at the output yourself."
    ),
    success=(
        "Five or more prompts classified, each with a reason, no retries on "
        "blocked runs, and a stated disagreement rate between the classifier and "
        "your own judgement."
    ),
    starter='''
def generate(spec, subdir="wrapped", *, retries=1):
    """Run one generation and report blocked / failed / succeeded.

    Blocked runs are NOT retried. Justify that in a comment: what would have to
    be true for a retry to change the outcome?
    """
    raise NotImplementedError


BATCH = [
    # ("descriptive_name", prompt_dict, "what you expect: ok | blocked | failed"),
]


def summarise(records):
    print(f"{'prompt':<26} {'expected':<10} {'verdict':<12} {'time':>8}")
    raise NotImplementedError
''',
    hints=[
        "`RunResult.diagnose()` already pattern-matches OOM, gating, missing "
        "checkpoints, port collisions and disk-full. Use its output to decide "
        "whether a retry is sensible: an OOM will not fix itself, but a port "
        "collision will.\n\n"
        "The most informative case in your batch is a prompt you expect to be "
        "blocked and which is not. When that happens, your expectation was wrong "
        "and you have learned something about the filter — record it rather than "
        "adjusting the prompt until it agrees with you.",
    ],
    solution_ref="solutions/09_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "What does the guardrail actually cost?",
    goal=(
        "Measure the guardrail's throughput and VRAM cost across a batch, and "
        "make a defensible recommendation about when to offload it — and, "
        "separately, about when disabling it could be justified."
    ),
    instructions=(
        "1. Design the measurement before running it. Three conditions — "
        "resident, offloaded, disabled — across at least three job sizes. State "
        "how many repeats you will do and why, given that a single measurement "
        "cannot distinguish a real effect from run-to-run noise.\n"
        "2. Establish the noise floor first: run one identical configuration "
        "three times and report the spread. `cosmos_course.measure.benchmark` "
        "gives you a median and a spread and warns when the spread exceeds 25% "
        "of the median.\n"
        "3. Measure wall clock and peak device VRAM for every cell of the "
        "design. Attribute the difference: how much of the guardrail's cost is "
        "fixed per run, and how much scales with the number of frames it has to "
        "screen? Your Lesson 06 decomposition of fixed against per-unit cost is "
        "the right tool.\n"
        "4. Write the recommendation. It must include a threshold — 'offload "
        "when X' — with the measurement that supports it, and it must say what "
        "the recommendation costs when it is wrong.\n"
        "5. Write the second recommendation, on disabling. Cover: what the "
        "guardrail screens, what replaces it if you turn it off, who sees the "
        "outputs, and what you would need to be true before you would sign off "
        "on it. If your answer is 'never', argue that properly too — but engage "
        "with the collision-footage case rather than avoiding it.\n"
        "6. Include one thing you measured that surprised you, or state "
        "explicitly that nothing did."
    ),
    success=(
        "A design stated in advance, a noise floor measured before any "
        "comparison, at least nine measured cells, a threshold recommendation "
        "with its supporting number and its failure cost, and a written position "
        "on disabling that engages with the hard case."
    ),
    starter='''
from cosmos_course.measure import benchmark

CONDITIONS = {
    "resident": None,
    "offloaded": ["--offload-guardrail-models"],
    "disabled": ["--no-guardrails"],
}
JOB_SIZES = [
    # (label, resolution, num_frames, num_steps)
]


def noise_floor(spec, repeats=3):
    """Run one configuration several times. Everything else is compared to this."""
    raise NotImplementedError


def measure_cell(condition, job):
    """One (condition, job size) cell. Return time, peak VRAM and the verdict."""
    raise NotImplementedError
''',
    hints=[
        "Frame screening scales with frames; prompt screening does not. So the "
        "guardrail's cost should have a fixed part and a per-frame part, and a "
        "design that varies frame count is what separates them. Vary steps as "
        "well and you get a useful control: the guardrail's cost should be "
        "roughly flat in steps, and if it is not, question your measurement "
        "before you question the guardrail.",
        "The disabled condition is the one to be careful with. Run it on benign "
        "prompts only, and note in your report that you did — a measurement that "
        "required generating unscreened content to obtain is a measurement with a "
        "cost attached, and reporting the cost is part of the answer.",
    ],
    solution_ref="solutions/09_solutions.ipynb",
)

# =====================================================================
# Assessment
# =====================================================================
nb.md("""
## Assessment and reflection

### Knowledge check

1. Why can Cosmos3-Edge not run `audio_image2video`? Give the architectural
   reason, not the table entry.
2. What does audio conditioning supply that a prompt cannot?
3. Where does the guardrail sit, and what are the two things it screens?
4. A run exits 0, writes a 40 KB MP4, and `RunResult.ok` is `True`. What is
   `ok` actually claiming, and what is it not?
5. Name the three run outcomes a pipeline must distinguish, and the different
   action each demands.
6. `check_hf_access` reports a token present and status 403. What is wrong, and
   what would status 401 with no token have meant instead?
7. Why is a token set in a terminal after Jupyter started not visible to a
   generation subprocess?
8. Which repository did your runs actually pull for the guardrail, and how do
   you know?
9. You measured almost no VRAM difference from `--offload-guardrail-models`.
   Give the mechanism.
10. State the strongest case *for* disabling the guardrail, and then the thing
    that case has to be paired with to be responsible.

### Practical completion test

1. Generate a video and check for an audio stream with `ffprobe`.
2. Demonstrate a clean-exit failure and show that `verify_result` catches what
   the exit code does not.
3. Classify at least three runs as blocked, failed or succeeded, with reasons.
4. Write `outputs/09/failure_signatures.md` from your own observations.
5. Measure the guardrail's VRAM cost with and without offloading, and say
   whether the difference is larger than your measurement noise.
""")

nb.code('''
def lesson_09_complete():
    passed, notes = [], []

    assert cc.MODEL_TIERS["Cosmos3-Edge"]["supports_audio"] is False
    assert cc.MODEL_TIERS["Cosmos3-Nano"]["supports_audio"] is True
    passed.append("capability table checked from the installed package")

    if BLANK.exists():
        blank_checks = cc.verify_result(fake, verbose=False)
        process = [c for c in blank_checks if c.name == "process"][0]
        video = [c for c in blank_checks if c.name == "video"]
        assert process.passed, "the synthetic run should report a clean exit"
        assert video and not video[0].passed, \\
            "the synthetic blank clip should fail the video check"
        passed.append("clean-exit failure demonstrated: process PASS, content FAIL")
    else:
        notes.append("blank-clip demonstration skipped — ffmpeg is not installed")

    assert SIGNATURES.exists(), "failure_signatures.md was not written"
    passed.append(f"failure signatures recorded ({SIGNATURES.stat().st_size} bytes)")

    verdicts = {label: classify_run(entry["result"])[0] for label, entry in RUNS.items()}
    if verdicts:
        passed.append("run verdicts: " + ", ".join(f"{k}={v}" for k, v in verdicts.items()))
    else:
        notes.append("no runs to classify — generation was disabled")

    with_audio = [label for label, entry in RUNS.items()
                  if entry["result"] is not None and entry["result"].video_path
                  and has_audio(entry["result"].video_path)]
    if with_audio:
        passed.append(f"audio stream confirmed in: {', '.join(with_audio)}")
    else:
        notes.append("no output carried an audio stream — record why in your notes")

    if len(offload_rows) == 2:
        delta = offload_rows[1]["peak_gb"] - offload_rows[0]["peak_gb"]
        passed.append(f"offload measured: {delta:+.2f} GB peak VRAM change")
    else:
        notes.append("offload comparison incomplete")

    kind = diagnose_gating()[0]
    passed.append(f"guardrail access: {kind}")

    for item in passed:
        print(f"  PASS  {item}")
    for item in notes:
        print(f"  ----  {item}")
    return passed, notes


_ = lesson_09_complete()
''')

nb.md("""
### Summary

- **`audio_image2video`** conditions on an image *and* an audio track. The image
  pins the first latent slice; the audio supplies temporal structure — *when*
  things happen — which no prompt provides.
- **`text2video` with `enable_sound`** generates a soundtrack instead of
  consuming one.
- **Cosmos3-Edge has no sound tokenizer**, so neither works there. Super has one
  and needs ~128 GB for framework inference. Nano is the only option on one
  H100.
- The **guardrail** screens the prompt before encoding and the frames after
  decoding. It is on by default and has been running since Lesson 01.
- **`nvidia/Cosmos-Guardrail1` is the only gated repository** in the stack. One
  click, granted immediately. The cookbook's `nvidia/Cosmos-1.0-Guardrail` is a
  second, separately gated copy; check your cache to see which you pulled.
- **A guardrail rejection exits zero.** It writes a valid file or no file, and
  the log may say nothing useful. `RunResult.ok` is satisfied by an exit code
  and a file; only `verify_result` opens the file.
- Distinguish **blocked / failed / succeeded**, because each demands a different
  action. Never retry a blocked prompt.
- **`--offload-guardrail-models`** trades a little time for VRAM. Measure it
  before you claim it, and compare the difference against your run-to-run noise.
- **`--no-guardrails`** is a decision, not a workaround. If you take it, say what
  replaces it.

### Common misconceptions

| Belief | Correction |
|---|---|
| "Edge just needs the audio flag" | There is no sound tokenizer in the checkpoint. It is not a flag. |
| "The Cosmos 3 models are gated" | None of the nine are. Only the guardrail. |
| "Accepting the licence in the browser is enough" | The subprocess also needs a token in its environment, and a kernel restart to see it. |
| "A zero exit code means it worked" | A guardrail rejection exits zero. That is the whole lesson. |
| "`RunResult.ok` means the output is good" | It means the process exited cleanly and wrote something. Content is `verify_result`'s job. |
| "Retry the blocked prompt with a different seed" | The prompt screen does not depend on the seed. |
| "Offloading the guardrail will fix my OOM" | The peak happens inside the denoising loop, where the guardrail is idle. Measure it. |
| "Disabling the guardrail is a performance tweak" | It is a safety decision, and it also disables face blurring. |

### Suggested extensions

- Feed a generated video back through the guardrail alone, without generating,
  to time the frame screen in isolation. That separates the two screens, which
  the flag does not.
- Find the boundary: take a prompt that passes and edit it one word at a time
  toward one that does not. Where the verdict flips tells you far more about the
  filter than either endpoint.
- Screen a batch of Lesson 08's augmentation outputs and report the rejection
  rate. An augmentation pipeline that silently loses 15% of its variants to a
  screen is a pipeline whose yield you do not know.

### Mastery checklist

- [ ] I generated a video and confirmed its audio stream with `ffprobe`.
- [ ] I can say why Edge cannot do this without looking it up.
- [ ] I can draw where the guardrail sits and name what each screen inspects.
- [ ] I produced a clean-exit failure and showed what caught it.
- [ ] I can tell blocked from failed from succeeded, with reasons.
- [ ] I diagnosed a gating error and know both of its causes.
- [ ] I measured the offload flag rather than assuming its effect.
- [ ] `outputs/09/failure_signatures.md` is written in my own words.

## Module 2 is finished — free everything and count the cost

This is the end of Module 2, and the next module (Act) starts from a clean
machine. Two things to do before you leave.

**Give back the GPU.** The generator ran as a subprocess so the operating system
reclaimed its VRAM at exit, but a timed-out run can leave a worker behind, and
an orphaned worker holding 30 GB is invisible until the next launch fails.
Verify rather than assume.

**Count the disk.** Module 2 has produced video, and video is large. The cell
below reports what each lesson wrote and what the Hugging Face cache now holds,
so the decision about what to delete is made with numbers. Keep the checkpoints —
Module 3 needs Nano, and re-downloading 34.9 GB to reclaim disk you were not
short of is a poor trade. The generated media is the disposable part, and
`scripts/cleanup.sh` removes exactly that.
""")

nb.code('''
import gc

gc.collect()
try:
    import torch as _torch
    if _torch.cuda.is_available():
        _torch.cuda.empty_cache()
        free_b, total_b = _torch.cuda.mem_get_info()
        print(f"device: {free_b / 1e9:.1f} GB free of {total_b / 1e9:.1f} GB")
        if free_b / total_b < 0.7:
            print("  Under 70% free while this kernel holds nothing. Look for an orphan:")
            print("      ps aux | grep cosmos_framework      then      nvidia-smi")
        else:
            print("  The card is clear. Module 3 can have it.")
except Exception as exc:
    print(f"could not read device memory: {type(exc).__name__}: {exc}")

print()
print("Disk written by Module 2:")
total = 0.0
for lesson in ("06", "07", "08", "09"):
    size = dir_size_gb(cc.OUTPUT_ROOT / lesson)
    total += size
    print(f"  outputs/{lesson}   {size:>7.2f} GB")
print(f"  {'module total':<12} {total:>7.2f} GB")

print()
print("Model weights (keep these):")
for repo in (cc.MODEL_TIERS["Cosmos3-Edge"]["hf_repo"],
             cc.MODEL_TIERS["Cosmos3-Nano"]["hf_repo"],
             "nvidia/Cosmos-Guardrail1"):
    print(f"  {repo:<28} {dir_size_gb(hf_cache_dir(repo)):>7.2f} GB")

print()
print(f"free on this filesystem: {shutil.disk_usage(COURSE_ROOT).free / 1e9:.0f} GB")
print()
print("To reclaim the generated media without touching the model cache:")
print("    bash scripts/cleanup.sh")
print("Read it before you run it — it tells you what it will remove and asks.")
''')

nb.md(FOOTER_MD)

nb.write(ROOT / "09_generation_audio_guardrail.ipynb")
