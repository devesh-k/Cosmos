"""Minimal notebook builder used to author this course.

Notebooks are JSON, and hand-writing JSON is a reliable way to ship a broken
notebook. The lessons are therefore authored as Python files under ``tools/``
that call into this module, which guarantees valid structure, consistent
metadata, a uniform kernelspec, and no accidental committed outputs.

This is a build tool, not course material — but it ships so the notebooks are
regenerable rather than hand-maintained artefacts.

    from nbbuild import Notebook
    nb = Notebook("Lesson title")
    nb.md("## Overview\\n\\nSome prose.")
    nb.code("print('hi')")
    nb.write("../02_reasoning_captioning.ipynb")
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

KERNEL_NAME = "cosmos3-h100"
KERNEL_DISPLAY = "Cosmos 3 (H100)"


class Notebook:
    """Accumulates cells, then writes a valid nbformat 4.5 notebook."""

    def __init__(self, title: str | None = None, *, kernel: str = KERNEL_NAME):
        self.cells: list[dict[str, Any]] = []
        self.kernel = kernel
        self.title = title
        self._ids: set[str] = set()

    # ---- cell ids ---------------------------------------------------------
    def _cell_id(self, kind: str, text: str) -> str:
        """A stable, unique cell id.

        nbformat **4.5 requires** an ``id`` on every cell (see the ``required``
        list in ``nbformat.v4.5.schema.json``). Omitting it makes
        ``nbformat.validate`` fail once per cell, which is invisible on a
        machine without nbformat installed and loud on one with it.

        The id is derived from the cell's content rather than its index so that
        inserting a cell does not renumber every id after it — a regenerated
        notebook then produces a diff of the cells that actually changed.
        """
        digest = hashlib.sha1(f"{kind}:{text}".encode("utf-8")).hexdigest()[:12]
        candidate = f"c{digest}"
        suffix = 1
        while candidate in self._ids:          # identical cells do occur
            candidate = f"c{digest}-{suffix}"
            suffix += 1
        self._ids.add(candidate)
        return candidate

    # ---- cell constructors ------------------------------------------------
    def md(self, text: str, *, tags: list[str] | None = None) -> "Notebook":
        """Add a markdown cell. Leading/trailing blank lines are trimmed."""
        body = text.strip("\n")
        self.cells.append(
            {
                "id": self._cell_id("markdown", body),
                "cell_type": "markdown",
                "metadata": {"tags": tags} if tags else {},
                "source": _split(body),
            }
        )
        return self

    def code(self, source: str, *, tags: list[str] | None = None) -> "Notebook":
        """Add a code cell with no outputs and no execution count."""
        body = source.strip("\n")
        self.cells.append(
            {
                "id": self._cell_id("code", body),
                "cell_type": "code",
                "execution_count": None,
                "metadata": {"tags": tags} if tags else {},
                "outputs": [],
                "source": _split(body),
            }
        )
        return self

    # ---- structured helpers ----------------------------------------------
    def hint(self, summary: str, body: str) -> "Notebook":
        """A collapsible hint. Learners open it only when they want it."""
        return self.md(
            f"<details>\n<summary><b>Hint — {summary}</b></summary>\n\n{body}\n\n</details>"
        )

    def answer(self, body: str, *, summary: str = "Answer") -> "Notebook":
        return self.md(
            f"<details>\n<summary><b>{summary}</b> (try it yourself first)</summary>\n\n"
            f"{body}\n\n</details>"
        )

    def callout(self, kind: str, body: str) -> "Notebook":
        """A visually distinct aside. `kind` is one of note / warning / gotcha / deeper."""
        icons = {
            "note": ("Note", "#0b7285"),
            "warning": ("Warning", "#c92a2a"),
            "gotcha": ("Gotcha", "#e8590c"),
            "deeper": ("Go deeper", "#5f3dc4"),
            "h100": ("On your H100", "#2b8a3e"),
            "vram": ("VRAM budget", "#a61e4d"),
            "upstream": ("Upstream drift", "#862e9c"),
        }
        label, colour = icons.get(kind, ("Note", "#0b7285"))
        return self.md(
            f'<div style="border-left:4px solid {colour};padding:.6em 1em;margin:1em 0;'
            f'background:rgba(128,128,128,.08);border-radius:0 4px 4px 0">\n\n'
            f"**{label}** — {body}\n\n</div>"
        )

    def predict_run_explain(
        self, *, predict: str, change: str, explain: str, hint: str | None = None
    ) -> "Notebook":
        """The course's core interaction pattern."""
        self.md(
            "### Predict, run, explain\n\n"
            "Before you run anything, write down your answer. Getting it wrong is the point — "
            "a prediction you have committed to is what makes the result stick.\n\n"
            f"1. **Predict.** {predict}\n"
            f"2. **Change.** {change}\n"
            "3. **Run** the cell.\n"
            f"4. **Explain.** {explain}"
        )
        if hint:
            self.hint("if you are stuck", hint)
        return self

    def exercise(
        self,
        level: str,
        title: str,
        *,
        goal: str,
        instructions: str,
        success: str,
        starter: str | None = None,
        hints: list[str] | None = None,
        solution_ref: str | None = None,
    ) -> "Notebook":
        """One exercise, with everything a learner needs to know when they are done."""
        badge = {
            "foundation": ("Foundation", "#2b8a3e"),
            "applied": ("Applied", "#1971c2"),
            "challenge": ("Challenge", "#c92a2a"),
        }.get(level.lower(), (level.title(), "#495057"))

        self.md(
            f'### <span style="background:{badge[1]};color:#fff;padding:2px 8px;'
            f'border-radius:3px;font-size:.8em">{badge[0]}</span> {title}\n\n'
            f"**Goal.** {goal}\n\n"
            f"**What to do.**\n\n{instructions}\n\n"
            f"**Done when.** {success}"
        )
        if starter:
            self.code(starter)
        for i, h in enumerate(hints or [], 1):
            self.hint(f"{i}", h)
        if solution_ref:
            self.md(
                f"*Reference solution: `{solution_ref}`. Read it after you have a working "
                f"answer of your own — comparing two solutions teaches more than reading one.*"
            )
        return self

    def checkpoint(self, description: str, code: str) -> "Notebook":
        """A cell that confirms the learner is on track before they continue."""
        self.md(f"**Checkpoint.** {description}")
        return self.code(code)

    # ---- output ----------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return {
            "cells": self.cells,
            "metadata": {
                "kernelspec": {
                    "display_name": KERNEL_DISPLAY,
                    "language": "python",
                    "name": self.kernel,
                },
                "language_info": {
                    "name": "python",
                    "mimetype": "text/x-python",
                    "file_extension": ".py",
                    "codemirror_mode": {"name": "ipython", "version": 3},
                    "pygments_lexer": "ipython3",
                    "nbconvert_exporter": "python",
                },
            },
            "nbformat": 4,
            "nbformat_minor": 5,
        }

    def write(self, path: Path | str) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(self.to_dict(), indent=1, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        n_code = sum(1 for c in self.cells if c["cell_type"] == "code")
        n_md = len(self.cells) - n_code
        print(f"  wrote {path.name}: {len(self.cells)} cells ({n_code} code, {n_md} md), "
              f"{path.stat().st_size / 1024:.0f} KB")
        return path


def _split(text: str) -> list[str]:
    """Split into nbformat's list-of-lines-with-trailing-newlines representation."""
    if not text:
        return []
    lines = text.split("\n")
    return [line + "\n" for line in lines[:-1]] + [lines[-1]]


# ---------------------------------------------------------------------------
# Shared fragments every lesson uses, so wording stays consistent.
# ---------------------------------------------------------------------------
SETUP_CELL = '''\
# ---------------------------------------------------------------------------
# Configuration. Run this first; everything below depends on it.
#
# Nothing here is hard-coded to a particular machine — paths resolve from the
# course root, and the device is detected rather than assumed.
# ---------------------------------------------------------------------------
import os
import sys
from pathlib import Path

# Make the course package importable whether or not it was pip-installed.
COURSE_ROOT = Path.cwd()
while not (COURSE_ROOT / "cosmos_course").is_dir() and COURSE_ROOT != COURSE_ROOT.parent:
    COURSE_ROOT = COURSE_ROOT.parent
sys.path.insert(0, str(COURSE_ROOT))

import cosmos_course as cc

# MODEL TIER  (sizes verified against Hugging Face, August 2026)
#   Cosmos3-Edge   4B total, ~9.1 GB download, ungated, 256p/480p   <- start here
#   Cosmos3-Nano  16B total / 8B active MoT, ~35 GB, ungated, up to 768p
#   Cosmos3-Super 64B total / 32B active, ~133 GB — will NOT fit one H100 for
#                 framework inference (needs ~128 GB). Reasoner NIM can serve
#                 it FP8 on one H100; the generator cannot.
# Override from the shell with:  export COSMOS_COURSE_MODEL=Cosmos3-Nano
MODEL = os.environ.get("COSMOS_COURSE_MODEL", "Cosmos3-Edge")

# RUN MODE — "reduced" keeps every cell to a few minutes; "full" uses the
# settings you would use for real output. Start reduced. Always.
MODE = os.environ.get("COSMOS_COURSE_MODE", "reduced")

DEVICE = cc.select_device()
OUTPUT_DIR = cc.OUTPUT_ROOT / Path(globals().get("__lesson__", "lesson"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

print(f"course root : {COURSE_ROOT}")
print(f"model       : {MODEL}")
print(f"mode        : {MODE}")
print(f"device      : {DEVICE}")
print(f"outputs     : {OUTPUT_DIR}")
'''

FOOTER_MD = """\
---

<div style="opacity:.7;font-size:.9em">

*Physical AI with Cosmos 3 on a single H100* — adapted from NVIDIA DLI course
`S-OV-57-V1`, restructured and extended for one 80 GB H100.
See `planning/` for the curriculum design and `assets/reference/COSMOS3_FACTS.md`
for the verified facts every lesson is built on.

</div>
"""
