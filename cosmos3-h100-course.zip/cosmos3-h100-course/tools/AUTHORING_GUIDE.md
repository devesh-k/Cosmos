# Authoring guide — how lessons in this course are built

Read this before writing any `build_NN.py`. It exists so that twenty notebooks
written at different times feel like one course.

## The mechanism

Notebooks are **generated**, never hand-edited. Each lesson has a builder at
`tools/build_NN.py` which imports `tools/nbbuild.py` and writes the `.ipynb`.
Hand-writing notebook JSON reliably ships broken notebooks; generating it
guarantees valid structure, a uniform kernelspec, and no committed outputs.

```python
"""Build 07_generation_conditioned.ipynb."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
nb = Notebook("Lesson 07 — Image-conditioned generation")
nb.md("...")
nb.code("...")
nb.md(FOOTER_MD)
nb.write(ROOT / "07_generation_conditioned.ipynb")
```

Run it, then run `python3 scripts/validate_notebooks.py` and
`python3 tools/api_check.py`, and fix what they report.

### Builder API

| Call | Use |
|---|---|
| `nb.md(text)` | markdown cell |
| `nb.code(src)` | code cell, no outputs, no execution count |
| `nb.md(text, tags=[...])` / `nb.code(src, tags=[...])` | tagged cell |
| `nb.hint(summary, body)` | collapsible `<details>` hint |
| `nb.answer(body)` | collapsible answer, hidden until they try |
| `nb.callout(kind, body)` | aside. Kinds: `note`, `warning`, `gotcha`, `deeper`, `h100`, `vram`, `upstream` |
| `nb.predict_run_explain(predict=, change=, explain=, hint=)` | the core interaction |
| `nb.exercise(level, title, goal=, instructions=, success=, starter=, hints=[], solution_ref=)` | levels: `foundation`, `applied`, `challenge` |
| `nb.checkpoint(description, code)` | a cell that confirms they are on track |

### Cell tags with meaning

| Tag | Effect |
|---|---|
| `skip-execution` | `scripts/run_all.sh` drops it (needs a second venv, a simulator, or deliberately errors) |
| `teaching-antipattern` | exempts the cell from `validate_notebooks.py` bans — use for code shown *because it is wrong* |
| `expensive` | long or storage-heavy; must be opt-in behind a flag |

## Required lesson structure

Each of the numbered sections below starts with its own `nb.md()` carrying the
heading. Do not append a `## Heading` to the end of the previous cell: it
renders as a section that begins with no heading at all, and `api_check.py`
rejects it for `## Exercises`, `## Debugging lab` and `## Assessment`.

Every lesson, in this order:

1. **Title block** — one line each: what they will build, time, GPU needed, downloads, prerequisites.
2. **Learning objectives** — 4–6 bullets, each starting with an observable verb: implement, measure, compare, debug, profile, optimise, explain, predict. Never "understand" or "learn about".
3. **Conceptual foundation** — the idea before the code. Define every term at first use. Use a small worked example, a table or ASCII diagram where it genuinely helps. Do not write more than about 400 words before the learner does something.
4. **Environment and prerequisites** — the standard setup cell, plus a verification cell that fails early with a useful message.
5. **Guided lab** — small cells, markdown before each important operation, expected behaviour stated, checkpoints.
6. **Predict–run–explain** — at least two per lesson, at genuinely uncertain moments.
7. **Exercises** — exactly three: one foundation, one applied, one challenge.
8. **Debugging lab** — at least one realistic failure, worked through as symptom → hypothesis → diagnosis → repair → verification.
9. **Assessment and reflection** — knowledge check, practical completion test, summary, common misconceptions, suggested extensions, mastery checklist.
10. `nb.md(FOOTER_MD)`

## Standards that are not negotiable

**Every notebook runs top to bottom from a clean kernel.** No cell may depend on
a variable defined in a cell the learner is told to skip. Cross-check with
`python3 tools/nameflow_check.py`.

**`RunResult`'s accessors are properties, not methods.** `ok`, `videos`,
`images`, `jsons`, `video_path`, `image_path`, `text_path` and `sample_outputs`
are all `@property`. Write `result.video_path`, never `result.video_path()` —
the latter parses, passes `nameflow_check.py`, and raises
`TypeError: 'PosixPath' object is not callable` on the first machine that turns
generation on. `python3 tools/api_check.py` catches it, and introspects the
property list rather than trusting this paragraph to stay current.

**Configuration lives in one cell near the top.** `MODEL`, `MODE`
(`reduced`/`full`), `DEVICE`, `OUTPUT_DIR`. Everything downstream reads those.
`MODE="reduced"` must complete in minutes; `MODE="full"` is opt-in.

**Never claim a performance number.** Do not write "this is 3x faster". Write
the measurement code, run it, and have the learner interpret what they got.
Anything the course asserts about speed or memory must be produced by
`cosmos_course.measure` on the learner's own machine.

**Never assume success from an exit code.** Generation output is verified with
`cosmos_course.checks.verify_result`, and the lesson says why.

**Warn before anything expensive.** Print the download size or expected runtime
*before* starting it, and put anything over about ten minutes behind an opt-in
flag.

**Paths are relative and configurable.** No `/dli/task`, no `C:\Users\...`, no
`/home/someone`. Resolve from `cosmos_course.config`.

**No secrets.** Read tokens from the environment. Never print them, never write
them to a file, never put them in a cell that could be committed with output.

**Free large resources.** Delete big tensors, call `torch.cuda.empty_cache()`,
stop the NIM when a lesson stops needing it, and say why you are doing it.

## Facts

`assets/reference/COSMOS3_FACTS.md` is authoritative. If you need a number, get
it from there. If it is not there, either measure it in the notebook or label it
an estimate. Three corrections you will keep needing:

- `model_mode: "policy"` is dead; it is **`wam`**.
- Only `nvidia/Cosmos-Guardrail1` is gated. The Cosmos3 checkpoints are not.
- Transfer is `video2video` **plus a control hint**, not its own mode.

Where upstream documentation is wrong, use `nb.callout("upstream", ...)` to say
so and to tell the learner how to check for themselves. Teaching someone to
verify against the enum rather than the prose is worth more than the fact.

## Voice

Write to an intelligent reader who is new to this specific topic. Assume no
prior exposure to diffusion models, vision-language models, robotics or Cosmos.
Start from zero on any new concept and build up. Over-explaining is better than
assuming.

Be direct. State the thing, then explain it. Prefer a short concrete example
over an abstract description. It is fine — good, even — to say "this is
confusing and here is why" or "NVIDIA's docs are wrong here".

Avoid: marketing language, "delve", "it's not just X, it's Y", "seamless",
"leverage" as a verb, exclamation marks, emoji, suspiciously neat lists of
three, and long stretches of theory with nothing to run.

Never say "simply", "just", or "obviously" about anything that took you a
paragraph to explain.

## Exercises

An exercise whose answer can be copied from the cell above is not an exercise.
Each one must require a decision.

- **Foundation** — modify or complete a guided example. Should take 5–10 minutes.
- **Applied** — a realistic task with partial scaffolding. 15–25 minutes.
- **Challenge** — integrate several concepts with minimal scaffolding. 30+ minutes.

Every exercise needs: goal, instructions, success criteria, starter code where
useful, at least one hint, and `solution_ref="solutions/NN_solutions.ipynb"`.
Where feasible, give an automated check the learner can run — a function that
asserts the success criteria and prints what passed.

Reference solutions go in `solutions/NN_solutions.ipynb`, built by
`tools/build_sol_NN.py`. They are complete, runnable, and commented to explain
the *reasoning*, not just the answer. They must never be inlined in the lesson.

## Debugging labs

Introduce a real failure — one that a learner will actually hit. Good candidates,
drawn from the source material and from what genuinely goes wrong here:

- CUDA OOM from an over-ambitious resolution/frame combination
- `model_mode: "policy"` rejected by the enum
- a video the NIM cannot decode (AV1) returning HTTP 422 with zero frames
- `CUDA_VISIBLE_DEVICES=1` on a single-GPU box, hiding the only GPU
- the NIM holding VRAM the generator then cannot get
- an aspect ratio written `16:9` instead of `16,9`
- a control video whose frame count does not match the requested output
- a JSONL dataset where every record is silently filtered out
- a clean exit that produced a blank frame because the guardrail rejected the prompt

Work each through **symptom → hypothesis → diagnostic step → repair →
verification**, and explain the underlying cause. Never just show corrected code.
Use the `teaching-antipattern` tag on cells that contain deliberately wrong code,
and `skip-execution` on cells that deliberately raise.

## Length

Aim for 45–70 cells per lesson, roughly 55/45 markdown to code. A code cell over
about 40 lines should usually be split, unless it is one cohesive unit that
would be harder to read broken up — in which case leave it and let the validator
warn.
