"""Build 02_serving_the_reasoner.ipynb.

Lesson 02 is new material — it does not exist in the source DLI course, which
had a second GPU and reached the reasoner over a docker-compose service DNS
name. On one H100 with localhost, getting the model served is itself the lesson,
and VRAM contention is the skill the rest of the course spends.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 02 — Serving the reasoner on one GPU")

# ---------------------------------------------------------------- 1. title
nb.md("""
# Lesson 02 — Serving the reasoner on one GPU

**What you will build.** A running Cosmos 3 Reasoner NIM on your own H100, a
measured VRAM budget for sharing that one card between the reasoner and the
generator, and a written plan (`outputs/02/vram_plan.json`) that the next four
lessons depend on.

| | |
|---|---|
| **Time** | ~90 minutes, of which 20–40 is unattended download |
| **GPU** | 1 × H100 80 GB. The NIM will try to take most of it. |
| **Downloads** | NIM image 8.28 GB compressed, plus ~20 GB of FP8 nano weights on first start |
| **Disk** | ~30 GB free before you begin |
| **Prerequisites** | Lesson 00 (environment check) and Lesson 01 (mental model). Docker with GPU passthrough. An NGC API key — the free NVIDIA Developer Program tier is enough. |

This lesson is the bridge between "Cosmos 3 exists" and "Cosmos 3 answers my
questions". It is also where you meet the constraint that shapes every later
lesson: **a served model and a generating model both want the whole card, and
you have one card.**
""")

# ------------------------------------------------------- 2. objectives
nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Explain** what a NIM is to someone who has never met one — what it packages,
   what protocol it speaks, and what that buys you.
2. **Start and stop** the Cosmos 3 Reasoner NIM from Python, and read every flag
   in the `docker run` command it builds.
3. **Measure** the VRAM the running container actually holds, and account for the
   gap between that number and the size of the model's weights.
4. **Predict** whether a Cosmos3-Nano generation can start while the NIM is
   running, do the arithmetic, and then test the prediction.
5. **Implement** both single-GPU sharing strategies — take turns, and cap the NIM
   — and state what capping costs you.
6. **Diagnose** four distinct reasons a NIM fails to start, from its symptom to
   its repair, using `nim_logs()` as the primary instrument.
7. **Send** a multimodal chat completion through the OpenAI-compatible API and
   describe how the media got there.
""")

# ------------------------------------------- 3. conceptual foundation
#
# Deferred, not deleted. The environment and verification cells below are
# emitted first so the notebook opens by running something; these two blocks
# are then emitted after them, with a runnable cell in between. Keeping them
# as strings here preserves the order they were written in.
WHAT_IS_A_NIM = """
## What a NIM is

A **NIM** (NVIDIA Inference Microservice) is a Docker container with three things
inside it:

1. a **model** — here, the reasoner tower of a Cosmos 3 checkpoint;
2. an **optimised inference server** — batching, paged attention, FP8 kernels,
   all the engineering that turns a checkpoint into something that answers many
   requests per second;
3. an **HTTP API** in front of both, which happens to be **the same shape as
   OpenAI's chat API**.

That third point is the one that matters to you today. "OpenAI-compatible" means
the server accepts a `POST /v1/chat/completions` with the same JSON body that
OpenAI's service accepts, and answers with the same JSON shape. So the standard
`openai` Python client talks to it with no modification:

```python
from openai import OpenAI
client = OpenAI(base_url="http://localhost:8000/v1", api_key="not-used")
client.chat.completions.create(model=..., messages=[...])
```

No request leaves your machine. `openai` here is a *client library for a wire
protocol*, not a connection to OpenAI. The protocol became a de-facto standard,
so vLLM, TGI, llama.cpp, Ollama and every NIM all speak it.
"""

WHY_IT_MATTERS = """
### Why that is worth caring about

Because it decouples your code from the thing serving the model.

```
   your notebook                    the serving side
   ------------                     ----------------
   openai client  ──HTTP/JSON──▶    Reasoner NIM (Docker, FP8, port 8000)
                                    vLLM + vllm-cosmos3 plugin
                                    a NIM on another machine
                                    a hosted endpoint at build.nvidia.com
```

Every row on the right accepts the same request. Swapping between them is a
change to one URL. Later in this lesson you will document the vLLM fallback
precisely because that substitution is real: if you cannot get an NGC key, the
same notebook code works against a different backend.
"""

WHY_IT_MATTERS_2 = """

That last row is not hypothetical, and it is worth knowing about **before** you
spend an hour on Docker: NVIDIA hosts the Nano reasoner at
<https://build.nvidia.com/nvidia/cosmos3-nano-reasoner>. Upload a frame, type a
prompt, read the answer — no container, no GPU, no key. It will not run the rest
of this course, it will not let you measure anything, and it is rate-limited. But
if you want to see what a physical-world reasoner *does* before you commit to
installing one, or if your NIM start is failing and you want to know whether the
model or your environment is the problem, open it in a browser now.

The cost of this convenience: the server is a **separate process, in a separate
container, with its own filesystem and its own claim on your GPU**. All three of
those facts will bite you in the next hour, and all three are the lesson.

> **Two NIMs exist for Cosmos 3 and people mix them up.** This course uses the
> **Reasoner** NIM (`nvcr.io/nim/nvidia/cosmos3-reasoner`), which reads pixels
> and writes text. There is also a **Generator** NIM, which writes pixels — and
> its per-device VRAM floor for nano is ~79 GiB, i.e. your entire H100 with
> nothing left over. This course generates through the Cosmos Framework instead,
> which is why Module 2 looks nothing like this lesson.
"""

# ------------------------------- 4. environment and prerequisites
nb.md("""
## Environment and prerequisites

Start here rather than with the theory: the setup cell, then a verification cell
that fails on the four things which make this lesson impossible. Everything
downstream reads `MODEL`, `MODE`, `DEVICE` and `OUTPUT_DIR` from the first one,
and nothing below hard-codes a path.

Failing in the verification cell costs you five seconds and tells you what to
fix. Failing twenty cells later, with a `ConnectionRefusedError`, costs you the
afternoon. Run both, then come back to what a NIM actually is.
""")

nb.code('__lesson__ = "02"   # makes OUTPUT_DIR resolve to outputs/02\n\n' + SETUP_CELL)

nb.code('''
# Fail early, and say what to do about it.
import shutil
import subprocess

problems = []

if shutil.which("docker") is None:
    problems.append(
        "docker is not on PATH. Install Docker Engine and the NVIDIA Container "
        "Toolkit, then re-run Lesson 00."
    )
else:
    probe = subprocess.run(["docker", "info"], capture_output=True, text=True)
    if probe.returncode != 0:
        problems.append(
            "the docker daemon did not answer `docker info`. Is it running, and "
            "is your user in the `docker` group? (`sudo usermod -aG docker $USER`, "
            "then log out and back in.)"
        )

if shutil.which("nvidia-smi") is None:
    problems.append("nvidia-smi is not on PATH, so VRAM cannot be measured.")

if not os.environ.get("NGC_API_KEY"):
    problems.append(
        "NGC_API_KEY is not set in this kernel's environment.\\n"
        "      1. Get a key at https://ngc.nvidia.com/setup/api-key (free tier is enough)\\n"
        "      2. export NGC_API_KEY=...   in your shell, ideally in ~/.bashrc\\n"
        "      3. RESTART THIS KERNEL — it inherited its environment when it started."
    )

free_gb = shutil.disk_usage(Path.home()).free / 1e9
if free_gb < 30:
    problems.append(
        f"only {free_gb:.0f} GB free on the volume holding your home directory. "
        f"The NIM needs ~8 GB for the image and ~20 GB for the FP8 nano profile."
    )

if problems:
    raise RuntimeError(
        "This lesson cannot start yet:\\n\\n  - " + "\\n\\n  - ".join(problems)
    )

print(f"docker      : ok")
print(f"nvidia-smi  : ok")
print(f"NGC_API_KEY : set (value never printed)")
print(f"free disk   : {free_gb:.0f} GB")
''')

# The conceptual foundation, now that the learner has run something.
nb.md(WHAT_IS_A_NIM)

nb.code('''
# "The same JSON body OpenAI accepts" is checkable rather than quotable. Build
# the request body by hand and look at it. Nothing is sent; this is the wire
# format on its own.
import json

request_body = {
    "model": "nvidia/cosmos3-nano-reasoner",
    "messages": [
        {"role": "user", "content": [
            {"type": "text", "text": "What is happening in this image?"},
            {"type": "image_url",
             "image_url": {"url": "data:image/png;base64,<the bytes go here>"}},
        ]},
    ],
    "max_tokens": 128,
    "temperature": 0.0,
}

print("POST http://localhost:8000/v1/chat/completions")
print(json.dumps(request_body, indent=2))
print()
print("Nothing in that body names NVIDIA, Cosmos or a NIM except the value of")
print("'model'. That is the whole point of an OpenAI-compatible server: the")
print("shape is the standard one, so the client library does not need to know")
print("what is answering. Note how the image travels — inline, base64-encoded,")
print("inside the JSON — because the container has its own filesystem and cannot")
print("open a path on yours.")
''')

nb.md(WHY_IT_MATTERS)

nb.code('''
# "Swapping between them is a change to one URL" — check it rather than believe
# it. Nothing here connects to anything; these are four addresses and one body.
BACKENDS = {
    "Reasoner NIM, this machine": "http://localhost:8000/v1",
    "vLLM + vllm-cosmos3 plugin": "http://localhost:8001/v1",
    "a NIM on another box":       "http://gpu-box.local:8000/v1",
    "NVIDIA-hosted endpoint":     "https://integrate.api.nvidia.com/v1",
}

for label, url in BACKENDS.items():
    print(f"  {label:<28} {url}")
print()

# The body does not mention the backend at all, so it is the same object for
# every one of them. If that were false, "OpenAI-compatible" would be marketing.
bodies = {label: json.dumps(request_body, sort_keys=True) for label in BACKENDS}
assert len(set(bodies.values())) == 1, "the request body should not vary by backend"

print(f"{len(BACKENDS)} backends, {len(set(bodies.values()))} distinct request body.")
print("The only thing that changed between them is base_url. That is what")
print("'decoupled' means here, and it is why the vLLM fallback later in this")
print("lesson is a real fallback and not a rewrite.")
''')

nb.md(WHY_IT_MATTERS_2)

# --------------------------------------------- 5. NGC authentication
nb.md("""
## NGC authentication: two separate things

This trips up nearly everyone, so it is worth being precise. There are **two**
credentials in play and they are used at different moments by different
processes.

| # | Who needs it | When | What it does |
|---|---|---|---|
| 1 | the **Docker daemon on your host** | at `docker pull` / `docker run` | proves you may download the image layers from `nvcr.io` |
| 2 | the **process inside the running container** | at container start | proves the NIM may download *model profiles* from NGC |

Number 1 is established once with `docker login nvcr.io`, and Docker stores the
result in `~/.docker/config.json` or your OS keychain. Number 2 is a live
environment variable, `NGC_API_KEY`, which must be visible **inside** the
container.

Getting only #1 right produces a container that pulls fine and then sits there
failing to fetch weights. Getting only #2 right produces a 401 at pull time,
before the container exists at all. They fail differently, which is how you tell
them apart.

> **Never print, echo, log or paste your key.** `start_nim` passes it to Docker
> as `-e NGC_API_KEY` **with no `=value`**, which tells Docker to copy the value
> from the current process environment. The key therefore never appears in this
> process's argv — not in `ps`, not in your shell history, not in a notebook
> output cell, not in an exception traceback. If you ever find yourself writing
> `-e NGC_API_KEY=$NGC_API_KEY`, stop.
""")

nb.code('''
from cosmos_course.nim import ensure_ngc_login

# Returns True if docker holds credentials for nvcr.io. A negative result is
# not conclusive — a credential helper keeps the secret in your OS keychain,
# where this cannot see it — so it prints the login command rather than raising.
logged_in = ensure_ngc_login()
print()
print(f"docker credentials for nvcr.io detected: {logged_in}")
''')

nb.md("""
If that reported no credentials, run the login command it printed **in a
terminal**, not in a cell. It is idempotent and costs nothing to repeat. The
username is the literal seven-character string `$oauthtoken` — it is not a
variable, and the single quotes in the printed command exist to stop your shell
expanding it to the empty string. That is the single most common way this
command fails.

## Before you start anything: the VRAM plan

You have one 80 GB card. Two things want it:

- the **Reasoner NIM**, whose FP8 nano weights are roughly 8 GB;
- the **generator**, which for Cosmos3-Nano is documented at 32 GB and for
  Cosmos3-Edge is around 12 GB (a working estimate, measured properly in
  Lesson 06).

8 + 32 = 40, comfortably under 80. So there is no problem. Except there is,
and the reason is the single most useful thing in this lesson.

`print_vram_plan()` lays out both strategies with the arithmetic attached.
Read the output before you read the next markdown cell.
""")

nb.code('''
from cosmos_course.nim import print_vram_plan

budget = print_vram_plan()
''')

nb.md("""
### Why 8 + 32 is the wrong sum

A modern inference server does not allocate memory per request. It allocates a
large block of **currently free** VRAM at startup and keeps it for the life of
the process, as a pool for the **KV cache**.

The KV cache is where the attention keys and values for every token in every
in-flight request live. A vision-language model turns each sampled video frame
into hundreds of image tokens, so a single request over a 10-second clip can be
tens of thousands of tokens. The server reserves cache space up front so it can
*promise* to admit a long request later, instead of discovering mid-generation
that it cannot.

The consequence is blunt: **the NIM's resting footprint is not its weight
footprint.** On an idle 80 GB H100 the container will settle somewhere far above
8 GB. Nothing is leaking. That is the design.

You are about to measure exactly where it settles on your machine.

> **Before you take a baseline.** If the "used" figure below is already several
> GB and no NIM is running, you have a leftover process holding the card —
> usually a Python kernel from an earlier lesson, or an orphaned generation
> subprocess. Find it with `nvidia-smi` and kill it *now*. Every VRAM number you
> measure for the rest of this lesson will otherwise be wrong by that amount,
> and the eventual OOM will look like a Cosmos problem.
""")

nb.predict_run_explain(
    predict=(
        "Write down two numbers before you run anything. (a) How many GB will "
        "`nvidia-smi` report as *used* on your H100 once the NIM is ready and "
        "idle? (b) How many GB will be *free*? Commit to actual numbers, not a "
        "range."
    ),
    change=(
        "Nothing to change yet — run the baseline cell below to record the "
        "starting state, then start the NIM in the section after it."
    ),
    explain=(
        "After the NIM is up, compare your prediction against the measurement. "
        "Then account for the difference between the measured number and the "
        "~8 GB of FP8 weights. Where did the rest go, and what would make it "
        "smaller?"
    ),
    hint=(
        "The weights are a fixed cost. The other allocation scales with how much "
        "VRAM was free when the server started — which means starting the NIM on "
        "a busy card and starting it on an empty card give different answers."
    ),
)

nb.code('''
from cosmos_course.nim import NimConfig, nim_status, print_status

# One config object, used by every NIM call in this notebook. Defaults are tuned
# for a single H100 running the nano reasoner at FP8.
NIM = NimConfig()
print(NIM.describe())
print()

baseline = nim_status(NIM)
print(f"GPU total : {baseline['gpu_total_gb']} GB")
print(f"GPU used  : {baseline['gpu_used_gb']} GB   <-- baseline, before the NIM")
print(f"container : {'running' if baseline['running'] else 'not running'}")
''')

# ------------------------------------------------- 7. starting the NIM
nb.md("""
## Starting the NIM

`start_nim` builds and runs a `docker run` command. It prints the full command
before executing it, which you should read. Here is every flag and why it is
there.

| Flag | Why |
|---|---|
| `-d` | detached — the container outlives the cell that started it |
| `--name cosmos3-reasoner` | a stable name, so `stop`, `logs` and `top` can find it |
| `--gpus all` | hands the GPU through to the container. Without it the container starts, sees no CUDA device, and fails at model load with an error that does not mention GPUs |
| `--shm-size 32gb` | `/dev/shm` inside the container. Docker's default is 64 MB; the NIM's inference workers pass tensors through shared memory and 64 MB produces a "Bus error" that reads like a model bug |
| `-v ~/.cache/nim:/opt/nim/.cache` | the weight cache, bind-mounted from your host. This is the difference between a 20 GB download **once** and a 20 GB download **every restart** |
| `-p 8000:8000` | host port 8000 maps to the container's 8000. The container always listens on 8000 internally; change only the left-hand side |
| `-e NGC_API_KEY` | copies the value from *this* process's environment. No `=value`, so the secret never appears in argv |
| `-e NIM_MODEL_SIZE=nano` | selects which profile to serve — `nano` (8B active) or `super` (32B active). Both fit one H100 *for reasoning* |
| `-u <uid>:<gid>` | run as you, not root, so the cache directory does not fill with root-owned files you then need `sudo` to delete |

There is deliberately **no** `--restart` policy. On a teaching machine, a
container that silently comes back after you stopped it to free VRAM is a
genuinely baffling failure.

> **First start downloads about 20 GB.** The image itself is 8.28 GB
> compressed; on top of that the container fetches the FP8 nano profile, which
> is ~20 GB on disk (~40 GB for super). There is no progress bar on the Python
> side of it, so watch the container instead: `docker logs -f cosmos3-reasoner`.
> Subsequent starts reuse the bind-mounted cache and skip the download entirely.
""")

nb.code('''
import time
from cosmos_course.nim import start_nim

# start_nim is idempotent: if a healthy NIM is already answering it returns
# immediately, so re-running this cell is free.
#
# timeout is generous on purpose. 1800 s looks absurd until the first run.
started_at = time.perf_counter()
info = start_nim(NIM, wait=True, timeout=2400)
elapsed = time.perf_counter() - started_at

print()
print(f"already running : {info['already_running']}")
print(f"wall clock here : {elapsed:.0f} s")
print(f"startup_seconds : {info['startup_seconds']}")
''', tags=["expensive"])

nb.checkpoint(
    "The container is running and the endpoint answers. If `ready` is False, do "
    "not continue — go to the debugging lab near the end of this notebook.",
    '''
state = print_status(NIM)
assert state["running"], "the container is not running — see the debugging lab"
assert state["ready"], "the container is up but not ready — it is still loading, or it failed"
print()
print("checkpoint passed: the NIM is serving.")
''',
)

# ------------------------------------- 8. health and readiness
nb.md("""
## Health, readiness, and why the difference matters

NIM containers expose two health endpoints, and they answer different questions.

| Endpoint | Question it answers | Becomes true after |
|---|---|---|
| `/v1/health/live` | is the process alive? | a couple of seconds |
| `/v1/health/ready` | will it answer a request? | the weights are loaded — minutes, or tens of minutes on first run |

Polling `live` tells you the container did not immediately crash. Polling
`ready` tells you that you may send a request. If you send a chat completion
between those two moments you get a connection reset or a 503, and it looks like
the server is broken rather than merely busy.

That is why `wait_for_nim` polls `ready` and not `live`, and why the retry logic
in `Reasoner` treats a connection error as transient rather than fatal.

`/v1/models` is a third thing again: it is the *model catalogue*, and it tells
you which model id the server will accept. That id depends on `NIM_MODEL_SIZE`
at container start, so a NIM you left running yesterday may not be serving what
today's notebook assumes. Ask; do not guess.

> **Upstream drift.** The source DLI course polled `/v1/health/ready` in a bare
> `while` loop with a 20-minute ceiling and a `requests` dependency. That is
> fine on their docker-compose setup where the container was already warm. On
> your machine the first start includes a 20 GB download, so the ceiling has to
> be higher and the failure message has to explain *what to look at* — which is
> why `wait_for_nim()` raises with a numbered list rather than a bare
> `TimeoutError`. Read that function; it is short, and its error message is the
> actual teaching.
""")

nb.code('''
import json
import urllib.request

def get_json(url, timeout=10):
    """Plain urllib. A health check is not worth a dependency."""
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.read().decode("utf-8", "replace")

live_code, _ = get_json(NIM.base_url + "/v1/health/live")
ready_code, _ = get_json(NIM.base_url + "/v1/health/ready")
models_code, models_body = get_json(NIM.base_url + "/v1/models")

print(f"GET /v1/health/live   -> HTTP {live_code}")
print(f"GET /v1/health/ready  -> HTTP {ready_code}")
print(f"GET /v1/models        -> HTTP {models_code}")
print()
print(json.dumps(json.loads(models_body), indent=2)[:900])
''')

# -------------------------------------- 9. THE VRAM CONTENTION LESSON
nb.md("""
## The VRAM contention lesson

This is the most important practical skill in the course. Everything else here
is plumbing.

Measure what the NIM is *actually* holding. Note that `nim_status` attributes
memory by matching the container's host PIDs (from `docker top`) against
`nvidia-smi --query-compute-apps`, which reports host PIDs even for processes
inside containers. That is why the number is per-container and not just
"whatever is used on the card".
""")

nb.code('''
held = nim_status(NIM)

print(f"GPU total          : {held['gpu_total_gb']} GB")
print(f"GPU used (all)     : {held['gpu_used_gb']} GB")
print(f"held by the NIM    : {held['vram_gb']} GB")
if held["gpu_total_gb"] and held["gpu_used_gb"] is not None:
    print(f"free               : {held['gpu_total_gb'] - held['gpu_used_gb']:.1f} GB")
for note in held["notes"]:
    print(f"  note: {note}")
''')

nb.md("""
### Now do the arithmetic

Compare the measurement against the documented weight size and against what
generation needs. Do not read past this cell until you have looked at the
numbers it prints.

Then go back to the prediction you wrote down. How close were you, and — more
useful — was the *direction* of your error the same as the direction of the
mechanism? People almost always underestimate, because they budget against the
weights. Write the answer down in one sentence before continuing. The sentence
you want is of the form: *the NIM holds N GB because ...*
""")

nb.code('''
NIM_WEIGHTS_FP8_GB = 8.0          # COSMOS3_FACTS.md section 4, nano at FP8
NANO_GENERATION_GB = cc.MODEL_TIERS["Cosmos3-Nano"]["inference_vram_gb"]   # 32, NVIDIA figure
EDGE_GENERATION_GB = cc.MODEL_TIERS["Cosmos3-Edge"]["inference_vram_gb"]   # ~12, working estimate

total = held["gpu_total_gb"] or 80.0
used = held["gpu_used_gb"] or 0.0
free = total - used
nim_share = held["vram_gb"]

print(f"card total                       {total:8.1f} GB")
print(f"currently used                   {used:8.1f} GB")
print(f"currently free                   {free:8.1f} GB")
print()
if nim_share is not None:
    print(f"the NIM holds                    {nim_share:8.1f} GB")
    print(f"  of which weights (documented)  {NIM_WEIGHTS_FP8_GB:8.1f} GB")
    print(f"  unaccounted (KV cache + ctx)   {nim_share - NIM_WEIGHTS_FP8_GB:8.1f} GB")
else:
    print("nvidia-smi could not attribute per-process memory on this machine.")
    print("Use the used-with-NIM minus used-without-NIM difference instead.")
print()
print(f"Cosmos3-Nano generation needs    {NANO_GENERATION_GB:8.1f} GB   (NVIDIA figure)")
print(f"Cosmos3-Edge generation needs    {EDGE_GENERATION_GB:8.1f} GB   (working estimate)")
print()
print(f"can Nano generation start now?   {'YES' if free >= NANO_GENERATION_GB else 'NO'}")
print(f"can Edge generation start now?   {'YES' if free >= EDGE_GENERATION_GB else 'NO'}")
''')

nb.predict_run_explain(
    predict=(
        "Second prediction, and this one has a yes/no answer. With the NIM in "
        "its current state, will a Cosmos3-Nano generation run start "
        "successfully, or will it fail with CUDA out of memory? Say which, and "
        "say what number you based it on."
    ),
    change=(
        "Run the cell below. It does not launch a real generation — that would "
        "cost you the whole of Lesson 06's download — it does the admission "
        "check the CUDA allocator would do, against the memory that is really "
        "free right now."
    ),
    explain=(
        "If the answer was NO, say precisely what would have to change for it to "
        "become YES. There are at least three different answers, and they are the "
        "three strategies in the next section."
    ),
    hint=(
        "A CUDA allocation does not negotiate. If the driver cannot satisfy the "
        "request from free memory it raises; it does not evict another process's "
        "pages. The NIM is not going to give any of its pool back while it lives."
    ),
)

nb.code('''
def can_it_fit(need_gb, label):
    """The admission check a generation launch would make, done cheaply."""
    st = nim_status(NIM)
    total_gb = st["gpu_total_gb"] or 80.0
    free_gb = total_gb - (st["gpu_used_gb"] or 0.0)
    verdict = "would start" if free_gb >= need_gb else "WOULD OOM"
    print(f"{label:<28} needs {need_gb:5.1f} GB, free {free_gb:5.1f} GB  ->  {verdict}")
    return free_gb >= need_gb

print("With the NIM running:\\n")
nano_fits_now = can_it_fit(NANO_GENERATION_GB, "Cosmos3-Nano generation")
edge_fits_now = can_it_fit(EDGE_GENERATION_GB, "Cosmos3-Edge generation")
''')

# ---------------------------------------- 10. the two strategies
nb.md("""
> **VRAM budget.** That check is a *lower bound on failure*, not a guarantee of
> success. Free VRAM being larger than the documented requirement does not
> promise a run completes — fragmentation, activation peaks and the guardrail
> models all take more than the steady-state figure. It does, however, reliably
> tell you when a run **cannot** start. Use it that way: as a cheap veto, not as
> a green light.

## Two strategies, and their prices


### (a) Take turns — the course default

`stop_nim(NIM)` before you generate, `start_nim(NIM)` after. Neither side is
compromised: the NIM gets the whole card and can hold a long video's worth of KV
cache; the generator gets the whole card and can render at 768p.

The cost is a cold start on every switch. After the first pull the weights are
on your disk, so this is a model load, not a download.

### (b) Cap the NIM so both coexist

Start the NIM with an explicit memory limit that leaves room for the generator.
Both processes stay resident, and you stop paying model-load latency on every
switch. This is the right call for a workflow that alternates rapidly between
reasoning and generation — the capstone's plan-then-render loop, for instance.

**What capping costs you is exactly one thing: KV cache.** A capped NIM has less
room for long contexts, so a request over a long video at a high sampling rate
may be refused where an uncapped one would have served it. Nothing else degrades
— the weights are the same, the precision is the same, the answers on short
inputs are the same.

### (c) The one that is not a strategy

Do not reach for the Generator NIM to solve this. Its per-device floor for nano
is ~79 GiB at any precision. There is no fraction you can set. This is why the
course generates through the Cosmos Framework.

### The honest part: we do not know what the knob is called

Here is something the course will not pretend about.

The environment variable that caps a NIM's VRAM claim has had several different
names across NIM families and releases. This course was written without a live
NIM 1.7 container to interrogate, so `cosmos_course.nim.NIM_MEMORY_ENV` holds a
**plausible guess**, not a verified fact — read the comment above it in
`nim.py`, which says so in capital letters.

That is tolerable rather than sloppy for one reason: **the input is uncertain but
the output is directly observable.** Set the flag, start the NIM, read
`nim_status(NIM)["vram_gb"]`. If the number did not move, the name is wrong.

`discover_memory_env()` runs `docker run --rm <image> --help` — which loads no
model and needs no GPU — and greps the output for every `NIM_*` name containing
MEM, GPU, KV, CACHE or UTIL.
""")

nb.code('''
from cosmos_course.nim import NIM_MEMORY_ENV, NIM_MEMORY_ENV_CANDIDATES, discover_memory_env

print(f"this module currently uses : {NIM_MEMORY_ENV}")
print(f"candidates it knows about  : {', '.join(NIM_MEMORY_ENV_CANDIDATES)}")
print()

found = discover_memory_env(NIM)
''')

nb.md("""
Whatever that reported, record it. If it found a name different from the one the
module assumed, set it for your shell and restart the kernel:

```bash
export COSMOS_COURSE_NIM_MEMORY_ENV=<the name it found>
```

If it found nothing at all, that is also a normal outcome — not every NIM image
documents its environment in `--help`. Two further places to look:

```bash
docker exec cosmos3-reasoner env | grep NIM_
```

and <https://docs.nvidia.com/nim/cosmos/latest/>.

And if you never find it: strategy (a) works, needs no flag, and is what every
lesson in this course does by default.
""")

nb.code('''
from cosmos_course.nim import suggest_memory_fraction

for tier in ("Cosmos3-Edge", "Cosmos3-Nano"):
    frac = suggest_memory_fraction(tier)
    if frac is None:
        print(f"{tier:<14} coexistence is not feasible — take turns.")
    else:
        gb = frac * (held["gpu_total_gb"] or 80.0)
        print(f"{tier:<14} cap the NIM at fraction {frac:.2f}  (~{gb:.0f} GB, "
              f"of which ~{NIM_WEIGHTS_FP8_GB:.0f} GB is weights)")
''')

# ------------------------------------------ 11. first inference
nb.md("""
## First inference

Now the part you came for. `Reasoner` is a thin HTTP client around the
OpenAI-compatible API — all the interesting engineering is on the far side of
the socket.
""")

nb.code('''
from cosmos_course.models import Reasoner

reasoner = Reasoner(base_url=NIM.base_url)

# The model id is asked for, not assumed. It depends on NIM_MODEL_SIZE at
# container start, and sending the wrong one is a 404 that reads like a server
# fault.
print(f"endpoint : {reasoner.base_url}")
print(f"model    : {reasoner.model}")
print(f"healthy  : {reasoner.health()}")
''')

nb.code('''
# Cookbook assets are resolved by NAME, never by path, so that a change in the
# cookbook's layout is one edit in cosmos_course/assets.py rather than nine
# edits spread across notebooks.
def need_asset(name):
    """Resolve a cookbook asset, or explain exactly how to get it."""
    try:
        return cc.asset(name)
    except FileNotFoundError as exc:
        raise RuntimeError(
            f"{exc}\\n"
            f"  Fetch the cookbook (it is a git-LFS checkout, a few GB):\\n"
            f"      python3 scripts/fetch_assets.py\\n"
            f"  Then re-run this cell."
        ) from None

scene = need_asset("robot_planning")
print(f"asset: {scene}")
cc.show_image(scene, caption="robot_planning.png — a tabletop scene with cameras")
''')

nb.code('''
answer = reasoner.ask(
    "Describe this scene. What objects are on the table, and what is the robot "
    "arm positioned near?",
    images=scene,
    max_tokens=1024,
)
print(answer)
print()
print(f"latency      : {reasoner.last_latency_s} s")
print(f"token usage  : {reasoner.last_usage}")
print()

# Never trust a 200. A guardrail rejection, an empty prompt field and a broken
# reasoner tower all return HTTP 200 with a body.
verdict = cc.check_text(answer)
print(verdict)
''')

nb.md("""
### What that request actually looked like

The OpenAI chat schema lets `content` be either a plain string or a **list of
content parts**. Multimodal requests use the list form. Each part is a small
dict with a `type` and a payload keyed by that type:

```python
{"role": "user", "content": [
    {"type": "image_url", "image_url": {"url": "data:image/png;base64,iVBORw0..."}},
    {"type": "text",      "text": "Describe this scene."},
]}
```

Two things about that are worth stopping on.

**Media parts come before the text part.** That is the convention the chat
templates in this model family expect. Putting the question first works often
enough to hide the problem, then fails on the one prompt where ordering matters.

**The URL is a base64 `data:` URL, not a path.** The NIM is a container with its
own filesystem. It cannot open `/your/home/clip.mp4`. Worse than failing, a path
that *does* happen to resolve inside the container gives you a silent wrong
answer about a different file. Inlining removes the ambiguity entirely.

The price is roughly 33% payload inflation from base64, plus the JSON encode. A
300 MB video becomes a ~400 MB request body. Trim long clips **before** they get
here, not after.
""")

nb.code('''
import base64
import mimetypes

# Build the same content list by hand, so the shape is concrete. This is not
# sent anywhere — it is printed with the payload elided.
mime = mimetypes.guess_type(scene.name)[0]
b64 = base64.b64encode(scene.read_bytes()).decode("ascii")

content_parts = [
    {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}},
    {"type": "text", "text": "Describe this scene."},
]

print(f"part 0 type      : {content_parts[0]['type']}")
print(f"  url prefix     : {content_parts[0]['image_url']['url'][:40]} ...")
print(f"  base64 chars   : {len(b64):,}")
print(f"  source bytes   : {scene.stat().st_size:,}")
print(f"  inflation      : {len(b64) / scene.stat().st_size:.2f}x")
print(f"part 1 type      : {content_parts[1]['type']}")
''')

# --------------------------------------------- 12. FP8 vs BF16
nb.md("""
## FP8 versus BF16, and what quantisation is

A model's parameters are numbers. **Precision** is how many bits each number
gets. Fewer bits means less memory and — on hardware with the right tensor cores
— more arithmetic per second, at the cost of representing each number less
exactly.

- **BF16** (brain float 16) — 16 bits per parameter. The default training and
  inference format for large models. 8 billion parameters × 2 bytes = 16 GB.
- **FP8** — 8 bits per parameter. Half the memory, and Hopper (H100, compute
  capability 9.0) has tensor cores that execute FP8 matrix multiplies natively.
  8 billion parameters × 1 byte = 8 GB.

**Quantisation** is the process of converting the trained BF16 weights into the
lower-precision format. It is not simply rounding: values are grouped and each
group gets a scale factor, so the 8-bit numbers cover the range that group
actually occupies. Done well, the output is very close to the BF16 model's. Done
badly — or on a layer that is sensitive to it — it degrades quality in ways that
are hard to see in one sample and obvious across a hundred.

Whether it degrades *your* task is an empirical question. This course does not
assert an answer; Lesson 15 has you measure one.

### What that means for your machine

From `COSMOS3_FACTS.md` §4:

**Nano (8B active) reasoner**

| GPU | Memory | Precision | GPUs needed | Disk |
|---|---|---|---|---|
| any | > 56 GB | BF16 | 1 | 30 GB |
| **H100 SXM / PCIe** | **80 GB** | **FP8** | **1** | **20 GB** |
| L40S | 48 GB | FP8 | 1 | 20 GB |
| H200 / GH200 | 141 GB | FP8 | 1 | 20 GB |

**Super (32B active) reasoner**

| GPU | Memory | Precision | GPUs needed | Disk |
|---|---|---|---|---|
| **H100 SXM / PCIe** | **80 GB** | **FP8** | **1** | **40 GB** |
| H100 SXM / PCIe | 80 GB | BF16 | 2 | 70 GB |

Minimum compute capability is 7.0 overall, 8.0 for BF16, **8.9 for FP8**. Your
H100 is 9.0, so FP8 is available and is what the profile selector will choose.

The asymmetry worth carrying forward: **on one H100 you can serve the 32B
reasoner.** What does not fit on one H100 is Super *generation* (~128 GB), not
Super *reasoning*. People routinely get this backwards.
""")

nb.code('''
# Confirm the compute capability the FP8 claim depends on, rather than assuming it.
try:
    import torch

    if torch.cuda.is_available():
        major, minor = torch.cuda.get_device_capability(0)
        name = torch.cuda.get_device_name(0)
        print(f"device            : {name}")
        print(f"compute capability: {major}.{minor}")
        print(f"BF16 (needs 8.0)  : {'available' if (major, minor) >= (8, 0) else 'NOT available'}")
        print(f"FP8  (needs 8.9)  : {'available' if (major, minor) >= (8, 9) else 'NOT available'}")
    else:
        print("torch reports no CUDA device — see Lesson 00.")
except ImportError:
    print("torch is not installed in this kernel; run scripts/setup.sh.")
''')

# ------------------------------------------- 13. vLLM fallback
nb.md("""
## The vLLM fallback (documented, not run here)

There is **no separate reasoner checkpoint on Hugging Face.** You serve the same
omni checkpoint and select the reasoner tower. Three ways to do that without a
NIM:

1. **vLLM** with the `vllm-cosmos3` plugin — same OpenAI wire protocol, so your
   notebook code does not change. No NGC key needed.
2. **Transformers** — `Cosmos3OmniForConditionalGeneration.from_pretrained(...)`
   loads only the reasoner tower and drops the generator, audio and action
   parameters.
3. **Cosmos Framework** — `model_mode: "reasoner"`.

Option 1 is the closest substitute for what you just started, so it is the one
worth writing down. Notice the last three lines of the script the cell below
writes: `Reasoner()` reads `NIM_BASE_URL` from the environment before falling
back to `http://localhost:8000`. That is the entire cost of switching backends —
one environment variable — and it is the concrete payoff of the
"OpenAI-compatible" property from the top of this lesson.
""")

nb.callout("gotcha", """
**vLLM needs its own virtualenv, and this is not a preference.** The Cosmos
Framework's `vllm` dependency group (`vllm==0.19.1`) is declared as *conflicting*
with every `cu*` group — the CUDA-pinned groups you install the training and
inference stack with.

Why a conflict exists at all: vLLM ships its own compiled kernels built against
one specific torch build and one specific CUDA minor version. The framework's
`cu130-train` group pins a different torch, with `flash-attn-3-nv` built against
*that* one. Two packages, each demanding a different exact `torch==`, cannot be
resolved into one environment — a solver cannot satisfy both, so `uv` declares
them mutually exclusive rather than letting you install a broken mixture.

The practical consequence: `uv sync --group=vllm` in the framework checkout will
refuse, and forcing it produces a venv where `import torch` and `import vllm`
disagree about which libtorch is loaded. Build a second venv instead. You will
do exactly the same thing again in Lesson 13 for the simulator.
""")

nb.code('''
# Writes a runnable script. Deliberately NOT executed here: it builds a second
# virtualenv and downloads a checkpoint, neither of which belongs in the middle
# of this lesson. Tagged skip-execution so scripts/run_all.sh drops it.
FALLBACK = """#!/usr/bin/env bash
# vLLM fallback for the Cosmos 3 reasoner. Same OpenAI-compatible API as the
# NIM, no NGC key required. MUST live in its own venv - see COSMOS3_FACTS.md
# section 3, "Known conflict".
set -euo pipefail

python3 -m venv ~/.venvs/cosmos3-vllm
source ~/.venvs/cosmos3-vllm/bin/activate

pip install --upgrade pip
pip install 'vllm==0.19.1' vllm-cosmos3

# Selecting the reasoner tower out of the omni checkpoint is the whole trick:
# there is no reasoner-only repo on Hugging Face.
vllm serve nvidia/Cosmos3-Nano \\\\
  --hf-overrides '{"architectures":["Cosmos3ReasonerForConditionalGeneration"]}' \\\\
  --tensor-parallel-size 1 \\\\
  --mm-encoder-tp-mode data \\\\
  --async-scheduling \\\\
  --media-io-kwargs '{"video":{"num_frames":-1}}' \\\\
  --port 8000

# Then, with no change to any notebook code:
#   export NIM_BASE_URL=http://localhost:8000
#   Reasoner()  picks it up automatically.
"""

script = OUTPUT_DIR / "vllm_fallback.sh"
script.write_text(FALLBACK)
script.chmod(0o755)
print(f"wrote {script}")
print()
print(FALLBACK)
''', tags=["skip-execution"])

# ------------------------------------------ 14. debugging lab
nb.md("""
## Debugging lab: the NIM will not start

Four failures, all of which a learner on this course hits. Each is worked as
**symptom → hypothesis → diagnostic step → repair → verification**.

The single instrument that matters is `nim_logs()`. A container that failed
almost always said why, and the message is in its logs and nowhere else. Get
into the habit of reading them *before* forming a theory.

The cell below prints the logs of a *working* container. Read them now, while
nothing is wrong, so you know what normal looks like. Recognising the shape of a
healthy startup is what lets you spot the line where a broken one diverges.
""")

nb.code('''
from cosmos_course.nim import nim_logs

print(nim_logs(NIM, tail=25))
''')

nb.code('''
# The diagnostic: five independent probes, each isolating one failure class.
import socket

def diagnose_start_failure(cfg):
    """Five probes, each isolating one cause of a failed NIM start."""
    report = {}

    # 1. is docker there and talking?
    report["docker_present"] = shutil.which("docker") is not None
    info = subprocess.run(["docker", "info"], capture_output=True, text=True) \\
        if report["docker_present"] else None
    report["docker_daemon"] = bool(info and info.returncode == 0)

    # 2. credentials for nvcr.io
    report["ngc_key_set"] = bool(os.environ.get("NGC_API_KEY"))
    report["docker_login"] = ensure_ngc_login(quiet=True)

    # 3. GPU passthrough. Uses the small CUDA base image Lesson 00 pulled, not
    #    the NIM, so this is fast and does not load a model.
    gpu = subprocess.run(
        ["docker", "run", "--rm", "--gpus", "all",
         "nvidia/cuda:12.8.0-base-ubuntu22.04", "nvidia-smi", "-L"],
        capture_output=True, text=True, timeout=300,
    ) if report["docker_daemon"] else None
    report["gpu_passthrough"] = bool(gpu and gpu.returncode == 0)
    report["gpu_passthrough_stderr"] = (gpu.stderr.strip()[:200] if gpu else "")

    # 4. is the port free? Bind it and see. SO_REUSEADDR is deliberately NOT
    #    set: we want to know whether a real listener owns it.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind(("127.0.0.1", cfg.port))
            report["port_free"] = True
        except OSError as exc:
            report["port_free"] = False
            report["port_error"] = str(exc)

    # 5. disk, on the volume the weight cache lives on, plus how much of the
    #    ~20 GB nano FP8 profile has actually landed
    cache = cfg.cache_dir
    usage = shutil.disk_usage(cache if cache.exists() else Path.home())
    report["cache_dir"] = str(cache)
    report["cache_free_gb"] = round(usage.free / 1e9, 1)
    report["cache_size_gb"] = round(
        sum(f.stat().st_size for f in cache.rglob("*") if f.is_file()) / 1e9, 1
    ) if cache.exists() else 0.0

    return report

diag = diagnose_start_failure(NIM)
for key, value in diag.items():
    print(f"  {key:<24} {value}")
print()
print("cache_size_gb should be roughly 20 once the nano FP8 profile has fully")
print("downloaded. Substantially less, on a NIM that will not become ready, is")
print("the signature of cause 4 below.")
''')

nb.md("""
### Cause 1 — bad or absent NGC key: a 401 at pull time

**Symptom.** `start_nim` raises immediately, in seconds, before any container
exists. The message contains something like:

```
Error response from daemon: pull access denied for nvcr.io/nim/nvidia/cosmos3-reasoner,
repository does not exist or may require 'docker login': denied: requested access to
the resource is denied
```

or a bare `unauthorized: authentication required`.

**Hypothesis.** This is credential #1 from the top of the lesson — the *Docker
daemon* cannot authenticate to the registry. Note what it is **not**: the
container never started, so this is not `NGC_API_KEY` being invisible inside it.

**Diagnostic.** `diag["docker_login"]` above, and directly:

```bash
docker pull nvcr.io/nim/nvidia/cosmos3-reasoner:1.7
```

Do that in a terminal. It reproduces the failure in isolation, with no Python in
the way.

**Repair.**

```bash
echo "$NGC_API_KEY" | docker login nvcr.io -u '$oauthtoken' --password-stdin
```

The username is the literal string `$oauthtoken`. The single quotes stop your
shell expanding it to nothing, which is the failure mode inside the failure
mode. If that itself returns `unauthorized`, your key is wrong or expired —
generate a fresh one at <https://ngc.nvidia.com/setup/api-key>.

**Verification.** `docker pull` completes, then `ensure_ngc_login()` returns
True, then `start_nim()` gets as far as printing a container id.

**Related but different.** If the pull succeeds and the container then exits
after a minute with an authentication error *in its logs*, that is credential
#2: `NGC_API_KEY` is not reaching the container. Check `docker exec
cosmos3-reasoner env | grep NGC` — and remember that a Jupyter kernel inherits
its environment at launch, so exporting the key in a terminal after starting
Jupyter does nothing until you restart the kernel.
""")

nb.code('''
# Cause 1, read off your own machine. The two credential layers are separate
# things and the distinction is the whole point of this cause.
print("credential layer 1 — Docker daemon -> nvcr.io (needed to PULL the image)")
print(f"    docker login to nvcr.io succeeded : {diag['docker_login']}")
print()
print("credential layer 2 — NGC_API_KEY inside the container (needed to fetch WEIGHTS)")
print(f"    NGC_API_KEY visible to this kernel: {diag['ngc_key_set']}")
print()

if not diag["docker_login"]:
    print("VERDICT: layer 1 is broken. start_nim() would fail in seconds with a 401")
    print("         'pull access denied' and no container would ever exist.")
elif not diag["ngc_key_set"]:
    print("VERDICT: layer 1 is fine, layer 2 is not. The pull would succeed and the")
    print("         container would start, then die a minute later with an auth error")
    print("         in its own logs. Same word, different layer, different fix.")
else:
    print("VERDICT: both layers are satisfied, which is why your NIM is up.")
    print("         Cause 1 is excluded.")
''')

nb.md("""
### Cause 2 — no GPU passthrough

**Symptom.** `docker run` fails instantly with:

```
docker: Error response from daemon: could not select device driver "" with
capabilities: [[gpu]].
```

Or — the nastier variant — the container *starts*, runs for a minute, and dies
with a CUDA initialisation error. In that variant the logs mention CUDA and not
Docker, so people go looking for a driver problem.

**Hypothesis.** `--gpus all` requires the **NVIDIA Container Toolkit**, which is
a separate package from the driver. `nvidia-smi` working on the host tells you
the driver is fine and tells you nothing about the toolkit.

**Diagnostic.** `diag["gpu_passthrough"]` above, or by hand:

```bash
docker run --rm --gpus all nvidia/cuda:12.8.0-base-ubuntu22.04 nvidia-smi -L
```

That should print one line naming your H100. If it errors, the toolkit is the
problem and the NIM is innocent.

**Repair.** Install `nvidia-container-toolkit`, run
`sudo nvidia-ctk runtime configure --runtime=docker`, then
`sudo systemctl restart docker`. The restart is not optional; the toolkit
registers itself as a runtime hook and the daemon reads that at start.

**Verification.** Re-run the one-line `docker run` above and get your GPU's name
back. Then `start_nim()`.
""")

nb.code('''
# Cause 2. The probe already ran; this is the interpretation, which is the part
# that is easy to get wrong.
print(f"container saw a GPU : {diag['gpu_passthrough']}")
if diag["gpu_passthrough_stderr"]:
    print(f"stderr              : {diag['gpu_passthrough_stderr']}")
print()

if diag["gpu_passthrough"]:
    print("VERDICT: the NVIDIA Container Toolkit is installed and registered as a")
    print("         Docker runtime. Cause 2 is excluded. Note this says nothing")
    print("         about how much VRAM is free — that is a different failure.")
else:
    print("VERDICT: containers on this host cannot see the GPU. Note that this is")
    print("         true even though nvidia-smi works for you on the host: the")
    print("         driver and the container toolkit are separate packages, and")
    print("         only the toolkit is missing.")
''')

nb.md("""
### Cause 3 — the port is already bound

**Symptom.**

```
docker: Error response from daemon: driver failed programming external
connectivity on endpoint cosmos3-reasoner: Bind for 0.0.0.0:8000 failed:
port is already allocated
```

**Hypothesis.** Something else owns host port 8000. On a machine that has run
this course before, the overwhelmingly likely culprit is a **previous NIM
container that was stopped but not removed**, or one that is still running under
a different name.

**Diagnostic.** `diag["port_free"]` above. To find the owner:

```bash
docker ps --filter publish=8000
sudo ss -ltnp | grep :8000
```

**Repair.** Two options, and the choice tells you something.

- If it is an old NIM: `docker rm -f cosmos3-reasoner`. `stop_nim()` removes
  rather than merely stops for exactly this reason — a stopped container keeps
  its name and its port reservation, and the next `docker run --name` then fails
  with "name is already in use".
- If it is something you need: move the NIM. `NimConfig(port=8001)` changes only
  the host side of the mapping; the container still listens on 8000 internally,
  and `NimConfig.base_url` follows automatically, so nothing else in the notebook
  changes.

**Verification.** The bind probe in the diagnostic cell succeeds, then
`start_nim()` completes and `print_status()` shows the endpoint answering on the
port you chose. Right now that probe *should* report the port as taken, by your
own NIM — a passing probe here would mean nothing is listening.
""")

nb.code('''
# Cause 3, with the expectation deliberately inverted. Everywhere else in this
# course a probe passing is good news. Here it is bad news, because your own NIM
# is supposed to own this port right now.
print(f"port {NIM.port} free : {diag['port_free']}")
if not diag["port_free"]:
    print(f"reason           : {diag.get('port_error', '(no message)')}")
print()

assert not diag["port_free"], (
    f"Port {NIM.port} is free, which means nothing is listening on it. Your NIM "
    "is not running, so the rest of this lesson has no server to talk to. Go back "
    "and re-run start_nim()."
)
print("VERDICT: the port is taken, which is exactly right — it is taken by the")
print("         NIM you started. A learner hitting cause 3 for real sees the same")
print("         False here, but nim_status() says the container is not theirs.")
''')

nb.md("""
### Cause 4 — out of disk part-way through the download

**Symptom.** The most confusing of the four, because it arrives late and wearing
a disguise. The container starts, runs for ten or twenty minutes, and then either
exits with `No space left on device` in the logs, or — worse — exits with a
checkpoint-loading error about a corrupt or truncated safetensors file.

**Hypothesis.** The FP8 nano profile is ~20 GB, and it is written into the
bind-mounted cache directory on your host. If that volume fills, the download
stops part-way and leaves a partial file behind. On the *next* start, the NIM
finds a file of the right name and the wrong size, and reports it as a load
failure rather than a disk failure.

**Diagnostic.**

```bash
df -h ~
du -sh ~/.cache/nim
docker system df
```

`diag["cache_free_gb"]` above gives you the first of those from Python. Compare
against 20 GB for nano, 40 GB for super, plus the 8.28 GB compressed image which
lives in Docker's own storage, not in the cache directory.

**Repair.** Free space, then **delete the partial cache entry** — this second
step is the one people skip, and skipping it converts a disk problem into a
mysterious model problem:

```bash
docker system prune            # reclaims dangling images and layers
rm -rf ~/.cache/nim/<the partial profile directory>
```

**Verification.** `df -h` shows enough room, the cache directory no longer holds
a partial profile, and `start_nim()` runs to `ready` with the download visible in
`docker logs -f cosmos3-reasoner`.
""")

nb.code('''
# Cause 4 is arithmetic, so do the arithmetic rather than eyeballing df.
IMAGE_GB = 8.28          # compressed NIM image; lives in Docker storage, not the cache
PROFILE_GB = {"nano FP8": 20.0, "super FP8": 40.0}

free = diag["cache_free_gb"]
print(f"cache dir        : {diag['cache_dir']}")
print(f"already cached   : {diag['cache_size_gb']:.1f} GB")
print(f"free on that vol : {free:.1f} GB")
print()
print(f"{'profile':<12} {'needs':>8} {'+image':>8} {'headroom':>10}  verdict")
for name, gb in PROFILE_GB.items():
    total = gb + IMAGE_GB
    room = free - total
    verdict = "fits" if room > 0 else f"SHORT by {abs(room):.1f} GB"
    print(f"{name:<12} {gb:>7.1f}G {total:>7.1f}G {room:>9.1f}G  {verdict}")
print()
print("A profile that is partly cached needs less than the full figure, but a")
print("*partial* cache entry is the trap: the next start reads a file of the right")
print("name and the wrong size and reports a model error, not a disk error.")
''')

nb.md("""
### A fifth, for completeness: it started but never became ready

Not a start failure — a *readiness* failure, and it is worth separating because
the diagnosis is different. `docker ps` shows `Up 8 minutes`; `/v1/health/ready`
returns nothing.

Three sub-cases, distinguished by one command each:

| Sub-case | Command | What you see |
|---|---|---|
| still downloading | `docker logs -f cosmos3-reasoner` | download progress, and `nvidia-smi` shows 0% GPU utilisation |
| CUDA OOM at load | `nim_logs()` | an out-of-memory traceback; `nvidia-smi` shows another process holding the card |
| crashed and restarted | `docker ps -a` | `Restarting` or a rising restart count |

The first one just needs patience. The second is the VRAM contention lesson
arriving from the other direction: something else — very often a leftover
generation subprocess from Module 2 — took the card first.
""")

# ------------------------------------------------ 15. the artefact
nb.md("""
## Write down the plan

The artefact for this lesson. Lessons 03–05 read it, and so does the capstone.

The `justification` field in it is not decoration. Write the paragraph. A
learner who can state *why* they chose take-turns over capping — in terms of the
number they measured, not the number the docs quote — is the learner who will
diagnose the Module 2 OOM in thirty seconds instead of forty minutes.
""")

nb.code('''
import json

final = nim_status(NIM)

plan = {
    "gpu_total_gb": final["gpu_total_gb"],
    "nim_resting_vram_gb": final["vram_gb"],
    "gpu_used_with_nim_gb": final["gpu_used_gb"],
    "nim_weights_fp8_gb": NIM_WEIGHTS_FP8_GB,
    "model_id": final["model_id"],
    "memory_env_var_assumed": NIM_MEMORY_ENV,
    "memory_env_candidates_found": found["known_candidates_found"] + found["other_matches"],
    "nano_generation_gb": NANO_GENERATION_GB,
    "edge_generation_gb": EDGE_GENERATION_GB,
    "nano_can_coexist_now": bool(nano_fits_now),
    "edge_can_coexist_now": bool(edge_fits_now),
    "suggested_fraction_for_edge": suggest_memory_fraction("Cosmos3-Edge"),
    "suggested_fraction_for_nano": suggest_memory_fraction("Cosmos3-Nano"),
    "chosen_strategy": "take_turns",
    "justification": "REPLACE THIS with one paragraph in your own words.",
}

plan_path = OUTPUT_DIR / "vram_plan.json"
plan_path.write_text(json.dumps(plan, indent=2))
print(json.dumps(plan, indent=2))
print()
print(f"wrote {plan_path}")
''')

# ---------------------------------------------- 16. exercises
nb.md("""
## Exercises

Three, in increasing order of independence. Do them in order; the third builds
on the second.
""")

nb.exercise(
    "foundation",
    "Stop, measure, start, measure",
    goal=(
        "Observe the full VRAM cycle for yourself, so that 'the NIM holds "
        "memory' becomes a number you produced rather than a claim you read."
    ),
    instructions=(
        "1. Record `nvidia-smi` used-VRAM with the NIM running.\n"
        "2. Call `stop_nim(NIM)` and record it again. Note that `stop_nim` "
        "polls, because the driver does not hand memory back the instant the "
        "process dies — there is a CUDA context teardown first.\n"
        "3. Call `start_nim(NIM)` and record it a third time.\n"
        "4. Print a small table of the three measurements plus the two deltas.\n"
        "5. Answer in a comment: was the restart figure the same as the "
        "original? If it differed, why might it?"
    ),
    success=(
        "You have three measurements and two deltas, the freed amount is close "
        "to the amount held, and you have a written explanation for any "
        "difference between the first and third readings."
    ),
    starter='''
from cosmos_course.nim import stop_nim

readings = {}

readings["with_nim"] = nim_status(NIM)["gpu_used_gb"]
print(f"with NIM running : {readings['with_nim']} GB")

# YOUR CODE: stop the NIM, record readings["after_stop"], restart it,
# record readings["after_restart"], then print the table and the deltas.
''',
    hints=[
        "`stop_nim` already returns `vram_before_gb`, `vram_after_gb` and "
        "`vram_freed_gb`. You can use those directly instead of measuring "
        "around it — but measure independently at least once, so you have "
        "checked the helper rather than trusted it.",
        "The restart figure can legitimately differ from the original. The "
        "server sizes its KV cache pool against the VRAM that is *free at "
        "startup*, so if anything else grabbed a few GB in between, the second "
        "pool is smaller. That is not a bug; it is the mechanism, observed.",
    ],
    solution_ref="solutions/02_solutions.ipynb",
)

nb.exercise(
    "applied",
    "A context manager that restores the prior state",
    goal=(
        "Write `nim_running()`, a context manager that guarantees the NIM is up "
        "inside the block and leaves the machine in the state it found it. "
        "Every later lesson would be shorter if this existed."
    ),
    instructions=(
        "1. Write a `@contextmanager` function `nim_running(cfg)`.\n"
        "2. On entry: if the NIM is already ready, remember that and do "
        "nothing. If it is not, start it.\n"
        "3. Yield a `Reasoner` bound to `cfg.base_url`.\n"
        "4. On exit: if *you* started it, stop it. If it was already running, "
        "leave it alone. Restore, do not impose.\n"
        "5. Make it exception-safe — a failure inside the block must not leak a "
        "container.\n"
        "6. Write `test_nim_running()` that asserts all four cases and prints "
        "what passed. Run it."
    ),
    success=(
        "`test_nim_running()` prints four passing assertions: (a) inside the "
        "block the reasoner answers, (b) an already-running NIM survives the "
        "block, (c) a NIM you started is stopped on exit, (d) an exception "
        "raised inside the block still triggers the correct cleanup."
    ),
    starter='''
from contextlib import contextmanager

@contextmanager
def nim_running(cfg=None):
    """Ensure a NIM is serving for the duration of the block, then restore."""
    cfg = cfg or NimConfig()
    # YOUR CODE: decide whether it is already up, start if needed,
    # yield a Reasoner, and restore in a finally.
    raise NotImplementedError


def test_nim_running():
    """Assert the four behaviours and print each one that passes."""
    # YOUR CODE
    raise NotImplementedError
''',
    hints=[
        "`nim_status(cfg)['ready']` before you do anything is the whole of the "
        "entry logic. Store it in a local named something like "
        "`was_already_up` and branch on it in the `finally`.",
        "Case (d) is the one people get wrong. Wrap the yield in "
        "`try: ... finally: ...` — not `try: ... except: ...` — so the cleanup "
        "runs whether or not the block raised, and the exception still "
        "propagates to the caller. Testing case (c) honestly means starting "
        "from a stopped NIM, which costs you a model load; do it once, at the "
        "end of your test, and record how long it took on your machine.",
    ],
    solution_ref="solutions/02_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "Find the dual-tenancy frontier empirically",
    goal=(
        "Determine, by measurement rather than arithmetic, the largest NIM "
        "memory fraction under which a Cosmos3-Edge generation still succeeds "
        "on your machine — and report the frontier with its uncertainty."
    ),
    instructions=(
        "1. Write `dual_tenancy(fraction)`: stop the NIM, restart it with "
        "`NimConfig(gpu_memory_fraction=fraction)`, verify with "
        "`nim_status()['vram_gb']` that the cap actually took effect, then "
        "attempt one small Edge generation and record success or OOM.\n"
        "2. **Before searching, verify the knob works at all.** Compare the "
        "measured `vram_gb` at fraction 0.5 against the uncapped measurement. "
        "If they are the same, `NIM_MEMORY_ENV` is wrong on your image and the "
        "whole experiment is measuring nothing. Say so and stop; that is a "
        "valid, reportable result.\n"
        "3. Binary-search the fraction over a stated range. Justify your "
        "starting bracket from `vram_budget()`.\n"
        "4. Repeat the boundary point at least three times. Generation is not "
        "perfectly deterministic in its peak allocation, so a frontier reported "
        "from one trial is a coin flip.\n"
        "5. Confirm that a *successful* run really produced output — use "
        "`cc.verify_result()`, not the exit code.\n"
        "6. Write `outputs/02/dual_tenancy.md`: the frontier, the number of "
        "trials, the observed variance, what the arithmetic in `vram_budget()` "
        "predicted, and where the two disagree."
    ),
    success=(
        "You can state a fraction and a confidence interval, you have shown the "
        "cap has a measurable effect on held VRAM, and your report explains any "
        "gap between the measured frontier and the predicted one."
    ),
    starter='''
# Scaffolding only. The search, the repetition and the reporting are yours.
def dual_tenancy(fraction, *, trials=1):
    """Cap the NIM at `fraction`, then attempt an Edge generation `trials` times.

    Returns a dict with at least: fraction, measured_nim_vram_gb,
    successes, failures, and a note on whether the cap appeared to take effect.
    """
    raise NotImplementedError
''',
    hints=[
        "Keep the generation small and fixed across every trial — 256p, the "
        "minimum frame count, few steps. You are measuring an admission "
        "boundary, not image quality, and a large job just makes each probe "
        "slow.",
        "The cap-verification step in instruction 2 is the part that makes this "
        "an experiment rather than a ritual. `nim_status()['vram_gb']` is "
        "ground truth from nvidia-smi; the flag is a request. And a failed run "
        "is data — record the `diagnose()` output alongside each failure so "
        "your report can distinguish 'OOM at model load' from 'OOM during "
        "denoising', which have different frontiers.",
        "This exercise needs Cosmos3-Edge on disk (Lesson 01, 9.1 GB). If you "
        "have not got it yet, do the search with the admission check from "
        "earlier in this lesson instead of a real generation, and say clearly "
        "in your report that the frontier is predicted rather than observed.",
    ],
    solution_ref="solutions/02_solutions.ipynb",
)

# --------------------------------- 17. assessment and reflection
nb.md("""
## Assessment and reflection

### Knowledge check

Answer from memory, then check yourself against the notebook.

1. What are the three things a NIM packages, and which one lets you use the
   `openai` client?
2. Two credentials are involved in starting the NIM. Name each, say which
   process consumes it and when, and describe how each one fails.
3. The NIM's FP8 nano weights are about 8 GB. Why did it hold much more than
   that on your card, and what would make the resting figure smaller without
   changing the model?
4. What is the difference between `/v1/health/live` and `/v1/health/ready`, and
   what goes wrong if you poll the wrong one?
5. Why is media sent as a base64 `data:` URL rather than as a file path? Name
   the failure mode that a path would produce, and say why it is worse than an
   error.
6. What does capping the NIM's memory cost you? Be specific — name the thing
   that gets smaller and the kind of request that then fails.
7. Why can one H100 serve the *Super* reasoner but not run *Super* generation?
8. Why does `vllm` need its own virtualenv, in terms of dependency resolution
   rather than "they conflict"?

### Practical completion test

Do all five, in one sitting, without consulting the cells above:

1. Stop the NIM and confirm from `nvidia-smi` that the VRAM came back.
2. Start it again with `NIM_MODEL_SIZE` unchanged and confirm `/v1/models`
   reports the id you expect.
3. Ask it one question about one image and verify the answer with
   `cc.check_text()`.
4. State, with the number you measured, whether a Cosmos3-Nano generation could
   start right now.
5. Produce the last 30 lines of the container's logs and point at the line that
   indicates the model finished loading.
""")

nb.code('''
def self_test():
    """Automated version of the practical test. Prints what passed."""
    passed = []

    st = nim_status(NIM)
    assert st["ready"], "the NIM is not ready"
    passed.append("NIM is ready")

    assert st["model_id"], "/v1/models returned no model id"
    passed.append(f"serving {st['model_id']}")

    reply = reasoner.ask("In one sentence, what is in this image?",
                         images=scene, max_tokens=200)
    result = cc.check_text(reply)
    assert result.passed, f"reasoner output failed check_text: {result.reason}"
    passed.append("reasoner answered and the answer looks like language")

    assert (OUTPUT_DIR / "vram_plan.json").exists(), "vram_plan.json was not written"
    passed.append("vram_plan.json exists")

    logs = nim_logs(NIM, tail=30)
    assert logs and "docker unavailable" not in logs, "could not read container logs"
    passed.append("container logs are readable")

    for item in passed:
        print(f"  PASS  {item}")
    return passed

_ = self_test()
''')

nb.md("""
### Summary

- A NIM is a model, an optimised server and an OpenAI-compatible HTTP API in one
  container. The third part is why your code does not care which of them is
  running.
- Two credentials: `docker login nvcr.io` for the pull, `NGC_API_KEY` inside the
  container for the weights. They fail at different moments and look different.
- A serving stack reserves KV cache from free VRAM at startup, so its resting
  footprint is far larger than its weights. That is the design, and it is why
  the NIM and the generator cannot naively share your card.
- Two strategies: take turns (the default, no flag needed), or cap the NIM
  (faster switching, less KV cache). The name of the capping variable is
  unverified on NIM 1.7 — discover it, then trust the measured VRAM over the
  flag.
- Media is inlined as base64 because the container cannot see your filesystem.
- When the NIM will not start: read the logs first, then work through
  credentials, GPU passthrough, port, and disk.
""")

nb.code('''
# The summary above as your own numbers rather than as prose. Every line here
# comes from something this notebook measured or wrote.
print("what this lesson produced on THIS machine")
print(f"  GPU total                  : {final['gpu_total_gb']:.1f} GB")
print(f"  NIM resting VRAM           : {final['vram_gb']:.1f} GB")
print(f"  nano FP8 weights           : {NIM_WEIGHTS_FP8_GB:.1f} GB")
print(f"  unexplained by weights     : "
      f"{final['vram_gb'] - NIM_WEIGHTS_FP8_GB:.1f} GB  <- the KV cache pool")
print(f"  chosen strategy            : {plan['chosen_strategy']}")
print()

wrote_own = not plan["justification"].startswith("REPLACE THIS")
print(f"  vram_plan.json exists      : {plan_path.exists()}")
print(f"  justification written by you: {wrote_own}")
if not wrote_own:
    print()
    print("  The justification is still the placeholder. That is the one part of")
    print("  the artefact nothing can generate for you, and Lessons 03-05 and the")
    print("  capstone all read this file. Go back and write the paragraph.")
''')

nb.md("""
### Common misconceptions

| Belief | Correction |
|---|---|
| "8 GB of weights + 32 GB of generator = 40 GB, so both fit" | The server holds a KV cache pool sized against free VRAM at startup, not against its weights. Measure it. |
| "`openai` means my data goes to OpenAI" | It is a client library for a wire protocol. The request goes to `localhost:8000`. |
| "The container can read my files" | It has its own filesystem. A path either 404s or silently resolves to the wrong file. |
| "`docker login` is enough" | That covers the pull. The running container separately needs `NGC_API_KEY` to fetch model profiles. |
| "Super does not fit on one H100" | Super *generation* does not (~128 GB). Super *reasoning* does, at FP8, on one card. |
| "`stop_nim` returning means the VRAM is free" | The driver tears down the CUDA context asynchronously. `stop_nim` polls for the release; a naive stop-then-generate can still OOM. |
| "Exit code 0 means it worked" | Not for anything in this course. Verify the artefact. |

### Suggested extensions

- Start the NIM with `NIM_MODEL_SIZE=super` and measure the resting VRAM at FP8.
  Compare against nano. Note that this is a 40 GB download.
- Put the NIM behind a reverse proxy and point `NIM_BASE_URL` at it, to prove to
  yourself that nothing in the notebook code knows where the server is.
- Read `cosmos_course/nim.py` end to end. It is the module Lessons 03–05 lean on
  hardest, and its error messages are written to be read.

### Mastery checklist

- [ ] I can explain what a NIM is without using the word "microservice".
- [ ] I can name both credentials and describe how each fails.
- [ ] I have measured, not read, the NIM's resting VRAM on my own card.
- [ ] I can account for the gap between that number and 8 GB.
- [ ] I can start and stop the NIM and predict the VRAM at each step.
- [ ] I have `outputs/02/vram_plan.json` with a justification I wrote myself.
- [ ] I know which of the four start failures I would check first, and why.
- [ ] I know why the vLLM fallback needs its own venv.
""")

nb.code('''
# Four of those checklist items are machine-checkable. Tick them from evidence
# rather than from memory; the rest are yours to judge.
evidence = {
    "measured the NIM's resting VRAM":
        final["vram_gb"] > 0,
    "can account for the gap between that and the weights":
        abs(final["vram_gb"] - NIM_WEIGHTS_FP8_GB) > 0,
    "have outputs/02/vram_plan.json":
        plan_path.exists(),
    "wrote the justification myself":
        not plan["justification"].startswith("REPLACE THIS"),
}

for item, done in evidence.items():
    print(f"  [{'x' if done else ' '}] {item}")

outstanding = [k for k, v in evidence.items() if not v]
print()
print("all four confirmed" if not outstanding
      else f"still outstanding: {outstanding}")
''')

nb.md("""
### Resources

Carried from the source course (`S-OV-57-V1`, notebook 02), which listed three
and dropped none of the useful ones:

- **[Try the reasoner in your browser](https://build.nvidia.com/nvidia/cosmos3-nano-reasoner)** —
  `build.nvidia.com/nvidia/cosmos3-nano-reasoner`. Hosted Nano reasoner, no
  install, no GPU, no NGC key. The fastest way to answer "is it the model or is
  it my machine?"
- **[Reasoner NIM on the NGC catalog](https://catalog.ngc.nvidia.com/orgs/nim/teams/nvidia/containers/cosmos3-reasoner)** —
  the container this lesson pulls, its tags, and its release notes. Check the tag
  list here when the pin in `cosmos_course/nim.py` stops resolving.
- **[Cosmos 3 cookbook — reasoner](https://github.com/NVIDIA/cosmos/tree/main/cookbooks/cosmos3/reasoner)** —
  where every clip and still Lessons 03–05 use comes from, and where NVIDIA's own
  reasoner examples live. `scripts/fetch_assets.py` pulls from here.

## Leaving the NIM running

Lessons 03, 04 and 05 all need the reasoner, so **leave the container up**. Each
of those lessons opens with a check that fails clearly and points back here if
it is not.

Lesson 05 stops it at the end, because Module 2 needs the whole card.

If you are stopping for the day, stop it yourself — a container holding 60+ GB
of VRAM is not a good neighbour:

```python
from cosmos_course.nim import stop_nim
stop_nim(NIM)
```
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "02_serving_the_reasoner.ipynb")
