"""Shared scaffolding for the reference-solution notebooks.

`tools/build_NN.py` builds a lesson; `tools/build_sol_NN.py` builds the matching
`solutions/NN_solutions.ipynb`. Nineteen solution notebooks written one at a time
drift apart unless the framing is generated from one place, so the framing lives
here: the header, the per-solution heading, the "why this approach" block and the
"how to extend it" block.

Everything specific to a lesson — the setup cell, the prelude the exercises
depend on, the implementations and the commentary — belongs in the individual
builder. This module deliberately holds no course content.

    from solbuild import SolutionNotebook
    nb = SolutionNotebook("00", "Environment check", lesson_file="00_environment_check.ipynb")
    nb.header("...one paragraph on what these three exercises were about...")
    nb.code(SETUP)
    nb.solution("foundation", "Report the interconnect topology",
                goal="...", success="...")
    nb.code("...")
    nb.why("...")
    nb.extend("...")
    nb.finish()
"""

from __future__ import annotations

from pathlib import Path

from nbbuild import FOOTER_MD, Notebook

ROOT = Path(__file__).resolve().parent.parent

_BADGE = {
    "foundation": ("Foundation", "#2b8a3e"),
    "applied": ("Applied", "#1971c2"),
    "challenge": ("Challenge", "#c92a2a"),
}


class SolutionNotebook(Notebook):
    """A `Notebook` that knows the shape every solutions file shares."""

    def __init__(self, lesson: str, lesson_title: str, *, lesson_file: str):
        super().__init__(f"Lesson {lesson} — reference solutions")
        self.lesson = lesson
        self.lesson_title = lesson_title
        self.lesson_file = lesson_file
        self._n = 0

    # ---- framing ---------------------------------------------------------
    def header(self, blurb: str) -> "SolutionNotebook":
        """Title block. `blurb` says in a paragraph what the three exercises ask."""
        self.md(
            f"# Lesson {self.lesson} — reference solutions\n\n"
            f"**{self.lesson_title}** · worked answers to the three exercises in "
            f"`{self.lesson_file}`.\n\n"
            f"{blurb}"
        )
        self.callout(
            "warning",
            "**Write your own answer first.** These notebooks are worth reading only "
            "once you have something of your own to compare them against. Reading a "
            "solution before you have struggled with the problem produces the feeling "
            "of understanding without the substance of it — you will recognise every "
            "line and be unable to reproduce any of them.",
        )
        self.md(
            "### One defensible solution, not the only one\n\n"
            "Each answer below is *a* solution. Several of these exercises have a "
            "genuinely different second answer that is just as good, and a few have one "
            "that is better for a purpose the exercise did not state. Where the choice "
            "was close, the commentary names the alternative and says why this branch "
            "was taken, so you can disagree with the reasoning rather than just the "
            "code.\n\n"
            "The most useful thing you can do with this file is **diff it against your "
            "own answer** and account for every difference. A difference you cannot "
            "explain is the thing worth chasing. A difference you *can* explain, where "
            "your reason is better, means your answer is better — keep yours."
        )
        self.md(
            "### Running this notebook\n\n"
            f"It is self-contained. It repeats the setup cell from `{self.lesson_file}` "
            "and the handful of helpers the exercises build on, so you can open it from "
            "a cold kernel and run it top to bottom. Anything that needs a GPU, a "
            "network download, a running NIM or a long job is behind the same opt-in "
            "flag the lesson uses, and degrades to an explanation of what would have "
            "happened rather than a traceback."
        )
        return self

    def prelude(self, note: str) -> "SolutionNotebook":
        self.md(f"## Setup\n\n{note}")
        return self

    def solution(
        self,
        level: str,
        title: str,
        *,
        goal: str,
        success: str,
        approach: str | None = None,
    ) -> "SolutionNotebook":
        """Open a solution section: badge, restated goal, restated success criteria."""
        self._n += 1
        label, colour = _BADGE.get(level.lower(), (level.title(), "#495057"))
        body = (
            f"---\n\n"
            f'## Solution {self._n} — <span style="background:{colour};color:#fff;'
            f'padding:2px 8px;border-radius:3px;font-size:.8em">{label}</span> {title}\n\n'
            f"**The goal.** {goal}\n\n"
            f"**Done when.** {success}"
        )
        if approach:
            body += f"\n\n**The approach taken here.** {approach}"
        self.md(body)
        return self

    def why(self, body: str) -> "SolutionNotebook":
        """The reasoning. This is the part that is worth more than the code."""
        return self.md(f"### Why this approach\n\n{body}")

    def extend(self, body: str) -> "SolutionNotebook":
        return self.md(f"### How this could be extended\n\n{body}")

    def model_answer(self, body: str, *, heading: str = "A model answer") -> "SolutionNotebook":
        """For open-ended exercises: a real argument, marked as one position."""
        return self.md(
            f"### {heading}\n\n"
            f"*This is one position, argued. It is not the marking scheme. An answer "
            f"that reaches a different conclusion from evidence you can point at is "
            f"worth more than one that agrees with this and cannot say why.*\n\n{body}"
        )

    # ---- output ----------------------------------------------------------
    def finish(self) -> Path:
        self.md(
            "---\n\n## If your answers differed\n\n"
            "Work through the differences in this order, because that is the order in "
            "which they matter:\n\n"
            "1. **Did yours satisfy the stated success criteria?** If it did, it is a "
            "correct answer, whatever it looks like.\n"
            "2. **Does it fail on an input this one survives, or the reverse?** Trade a "
            "test case in each direction; that is the cheapest way to find out which "
            "assumptions each of you made.\n"
            "3. **Which one would you rather debug in six months?** That question "
            "settles more design arguments than elegance does.\n\n"
            f"If you find a real error here, it is an error — say so. The lesson is "
            f"`{self.lesson_file}`; the facts these answers rest on are in "
            "`assets/reference/COSMOS3_FACTS.md`."
        )
        self.md(FOOTER_MD)
        return self.write(ROOT / "solutions" / f"{self.lesson}_solutions.ipynb")


def setup_cell(lesson: str, body: str | None = None) -> str:
    """The lesson's own configuration cell, with `__lesson__` set for this lesson.

    Solutions write to the same `outputs/<lesson>/` directory the lesson uses, so
    a solution run and a learner run land side by side and can be compared.
    """
    from nbbuild import SETUP_CELL

    return (
        f"# The same configuration cell {lesson}'s lesson notebook uses, so the two\n"
        f"# runs write to the same place and can be compared file by file.\n"
        f'__lesson__ = "{lesson}"\n\n' + (body if body is not None else SETUP_CELL)
    )
