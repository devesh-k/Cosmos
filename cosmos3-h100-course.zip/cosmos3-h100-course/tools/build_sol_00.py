"""Build solutions/00_solutions.ipynb — reference answers for Lesson 00."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("00", "Environment check", lesson_file="00_environment_check.ipynb")

nb.header(
    "Lesson 00's three exercises are all about the same discipline: **find out what "
    "this machine actually is, before you spend an hour discovering it the expensive "
    "way.** The foundation exercise reads the interconnect topology and interprets it; "
    "the applied one turns the tier table into a predicate that answers *will this job "
    "fit* before you launch it; the challenge one turns the environment probe into a "
    "preflight gate that a later lesson can call as its first cell."
)

# ---------------------------------------------------------------------------
nb.prelude(
    "Three cells: the lesson's configuration cell, the lesson's `run_cmd` helper, and "
    "the torch/CUDA probe that defines `cuda_available`. The exercises below use all "
    "three, so they are repeated here rather than assumed."
)
nb.code(setup_cell("00"))

nb.code('''
# `run_cmd` from the lesson's hand-built probe. Every external command in this
# notebook goes through it, because the failure mode we care about most is
# "the tool is not installed", and that must not raise.
import platform
import re
import shutil
import subprocess


def run_cmd(argv, timeout=30):
    """Run a command; return (stdout, error_message). Never raises."""
    if shutil.which(argv[0]) is None:
        return None, f"{argv[0]} is not on PATH"
    try:
        done = subprocess.run(argv, capture_output=True, text=True,
                              timeout=timeout, check=True)
    except subprocess.CalledProcessError as exc:
        return None, f"{argv[0]} exited {exc.returncode}: {(exc.stderr or '').strip()[:200]}"
    except (OSError, subprocess.SubprocessError) as exc:
        return None, f"{type(exc).__name__}: {exc}"
    return done.stdout.strip(), None


print("run_cmd ready:", run_cmd(["python3", "--version"])[0]
      or run_cmd([sys.executable, "--version"])[0])
''')

nb.code('''
# The lesson's torch layer, condensed. Exercise 2 needs `cuda_available` and
# `torch`; both are optional here so the notebook still runs on a laptop.
torch = None
cuda_available = False
try:
    import torch  # noqa: F811

    cuda_available = bool(torch.cuda.is_available())
except ImportError:
    print("torch is not installed in this kernel — the VRAM numbers below will "
          "fall back to the documented 80 GB H100 figure, which is exactly the "
          "fallback Exercise 2 asks for.")

print(f"torch            : {getattr(torch, '__version__', 'not installed')}")
print(f"cuda available   : {cuda_available}")
print(f"platform         : {platform.machine()}")
''')

# ---------------------------------------------------------------------------
# Exercise 1
# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Report the interconnect topology",
    goal="Extend the hand-built probe with an eighth layer: the GPU interconnect "
         "topology, and an interpretation of it in one sentence.",
    success="`parse_topology` returns a dict on this machine without raising, "
            "`interpret_topology` produces a sentence you would defend, and both "
            "return something sensible when `topo_text` is `None`.",
    approach="Parse the matrix positionally — read the header row for the column "
             "labels, then read each `GPU<n>` row against those labels — and treat "
             "`None` as a first-class input rather than an error case bolted on at "
             "the end.",
)

nb.code('''
topo_text, topo_err = run_cmd(["nvidia-smi", "topo", "-m"])
print(topo_text or f"(no topology available: {topo_err})")
''')

nb.code('''
LINK_CODES = {"NV", "PIX", "PXB", "PHB", "NODE", "SYS", "X"}


def _is_link(token):
    """Is this cell one of nvidia-smi's link codes rather than a number?"""
    token = token.strip()
    if not token:
        return False
    if token == "X":                      # the diagonal: a GPU with itself
        return True
    if re.fullmatch(r"NV\\d+", token):     # NV12 = twelve NVLink connections
        return True
    return token in LINK_CODES


def parse_topology(text):
    """Parse `nvidia-smi topo -m` into a dict. Return the empty shape if text is None.

    The empty shape is returned, not raised, because a machine without
    nvidia-smi is a *finding* about that machine, not a bug in this function.
    Everything downstream can then treat "no topology" and "one GPU, no links"
    through the same code path.
    """
    parsed = {"gpu_count": 0, "gpu_labels": [], "link_types": set(),
              "affinity": [], "available": False}
    if not text:
        return parsed

    # Everything after "Legend" is documentation, not data.
    body = text.split("Legend")[0]
    lines = [ln for ln in body.splitlines() if ln.strip()]
    if not lines:
        return parsed
    parsed["available"] = True

    # The header row names the columns. It is indented, because its first cell —
    # the row-label column — is empty. Splitting on runs of whitespace therefore
    # gives the column names in order with no placeholder for that first column,
    # which is why the row parser below drops the row label before zipping.
    header = lines[0].split()
    gpu_cols = [i for i, name in enumerate(header) if re.fullmatch(r"GPU\\d+", name)]
    parsed["gpu_labels"] = [header[i] for i in gpu_cols]

    try:
        affinity_col = header.index("CPU") if "CPU" in header else None
    except ValueError:                                  # pragma: no cover
        affinity_col = None

    for line in lines[1:]:
        cells = line.split()
        if not cells or not re.fullmatch(r"GPU\\d+", cells[0]):
            continue                                    # NIC rows, blank rows
        parsed["gpu_count"] += 1
        row = cells[1:]
        for col in gpu_cols:
            if col < len(row) and _is_link(row[col]) and row[col] != "X":
                parsed["link_types"].add(row[col].strip())
        # "CPU Affinity" is two header tokens but one column, so the affinity
        # value sits at the first index past the GPU (and NIC) columns. Reading
        # it by offset from the end is more robust than counting NIC columns.
        if affinity_col is not None and len(row) > len(gpu_cols):
            parsed["affinity"].append(row[len(row) - (len(header) - affinity_col)]
                                      if len(header) - affinity_col <= len(row) else "")
    return parsed


def interpret_topology(parsed):
    """One sentence about what this topology means for this course."""
    if not parsed["available"]:
        return ("No topology could be read (nvidia-smi is absent or failed), so treat "
                "this as a zero-GPU machine: every GPU cell in this course will "
                "degrade to its CPU explanation, which is useful for reading but "
                "will not produce a video.")
    n = parsed["gpu_count"]
    if n == 0:
        return ("nvidia-smi answered but listed no GPUs, which usually means "
                "CUDA_VISIBLE_DEVICES is filtering them out — check it before "
                "concluding the card is broken.")
    if n == 1:
        return ("One GPU, so there is no inter-GPU link to interpret and no "
                "interpretation to make: rungs 3 and 4 of NVIDIA's OOM ladder "
                "(raise the FSDP shard degree, raise the context-parallel degree) "
                "are unavailable to you, because both spend memory by spreading it "
                "across ranks you do not have — leaving expandable_segments, "
                "activation checkpointing, a smaller batch and LoRA as the whole "
                "toolbox.")
    slowest = "SYS" if "SYS" in parsed["link_types"] else (
        "NODE" if "NODE" in parsed["link_types"] else "a PCIe-class link")
    fastest = sorted(x for x in parsed["link_types"] if x.startswith("NV"))
    if fastest:
        return (f"{n} GPUs with NVLink ({', '.join(fastest)}) between at least one "
                f"pair, so multi-GPU sharding is a real option here — but this "
                f"course is written for one card and every budget in it assumes one, "
                f"so treat the extra GPUs as headroom rather than as the plan.")
    return (f"{n} GPUs, but the fastest link between them is {slowest} rather than "
            f"NVLink, so sharding a model across them would move gradients over the "
            f"PCIe/CPU path — possible, and slower than the single-card path this "
            f"course assumes.")


parsed = parse_topology(topo_text)
print(parsed)
print()
print(interpret_topology(parsed))
''')

nb.code('''
# The success criterion says "and both return something sensible when topo_text
# is None". Assert it rather than assume it — this is the branch that will
# actually run for anyone reading these notebooks on a laptop.
empty = parse_topology(None)
assert empty["gpu_count"] == 0 and empty["link_types"] == set(), empty
assert isinstance(interpret_topology(empty), str) and len(interpret_topology(empty)) > 40
print("PASS parse_topology(None) returns the empty shape:", empty)
print("PASS interpret_topology(empty) returns a sentence")

# And a synthetic two-GPU matrix, so the multi-GPU branch is exercised on a
# machine that does not have two GPUs. This is the whole reason the parser takes
# text rather than calling nvidia-smi itself.
FAKE_2GPU = """\\
\\tGPU0\\tGPU1\\tCPU Affinity\\tNUMA Affinity
GPU0\\t X \\tNV12\\t0-31\\t0
GPU1\\tNV12\\t X \\t32-63\\t1

Legend:
  X    = Self
"""
two = parse_topology(FAKE_2GPU)
assert two["gpu_count"] == 2, two
assert "NV12" in two["link_types"], two
print("PASS synthetic 2-GPU matrix:", two)
print()
print(interpret_topology(two))
''')

nb.why(
    "**Why parse text instead of calling a library.** `pynvml` exposes topology "
    "programmatically and would be less fragile than string-splitting. It is also one "
    "more dependency, and the point of Lesson 00's hand-built probe is that you can "
    "interrogate a machine with nothing but `nvidia-smi` and the standard library — on "
    "a box where the Python environment is the thing you are debugging, that matters. "
    "If you reached for `pynvml`, your answer is arguably better engineering and worse "
    "for the exercise's purpose; both positions are defensible.\n\n"
    "**Why `parse_topology` takes text rather than running the command.** Because then "
    "the multi-GPU branch is testable on a single-GPU machine, which is the only kind "
    "of machine this course assumes you have. The synthetic `FAKE_2GPU` matrix in the "
    "cell above exercises code that would otherwise be dead on your hardware and "
    "discovered to be broken by someone else. Any time a function's behaviour depends "
    "on hardware you do not have, push the hardware read to the caller.\n\n"
    "**Why the empty shape rather than an exception.** `parse_topology(None)` returning "
    "`{'gpu_count': 0, ...}` lets `interpret_topology` handle \"no GPU\" and \"one GPU\" "
    "in the same shape, so the caller never needs a try/except. The cost is that a "
    "genuine parse failure looks identical to no GPU — which is why there is an "
    "explicit `available` flag, so the two *can* be distinguished by anyone who cares. "
    "That flag is the compromise between an exception and a silent zero.\n\n"
    "**Why the interpretation is negative on one GPU.** This is the part of the "
    "exercise with real content. The topology matrix is usually read for what it "
    "enables. On a one-GPU box the informative reading is what it *forecloses*: "
    "`COSMOS3_FACTS.md` §5 lists NVIDIA's OOM ladder as (1) expandable_segments, "
    "(2) activation checkpointing, (3) raise FSDP shard degree, (4) raise "
    "context-parallel degree, (5) smaller batch, (6) LoRA. Rungs 3 and 4 both buy "
    "memory by dividing it across ranks. With one rank, the divisor is 1. Knowing this "
    "in Lesson 00 is what stops you from spending Lesson 17 trying to configure your "
    "way out of an arithmetic problem."
)

nb.extend(
    "Two directions worth the time:\n\n"
    "- **Add the NIC rows.** `nvidia-smi topo -m` also reports GPU-to-NIC affinity "
    "(`mlx5_0` and friends). The parser above skips those rows deliberately. On a "
    "multi-node box they are what tells you whether GPUDirect RDMA has a path, which "
    "is the multi-node analogue of the NVLink question.\n"
    "- **Fold it into `cc.probe_environment()`.** `EnvReport` has no topology field. "
    "Adding `interconnect: str` and having `_assess()` emit a warning when a "
    "multi-GPU box has no NVLink would put the finding where the rest of the course "
    "already looks for problems, instead of in a cell nobody re-runs."
)

# ---------------------------------------------------------------------------
# Exercise 2
# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "A will-it-fit predicate",
    goal="Write `will_it_fit(model, resolution, frames)` that answers, before you "
         "launch anything, whether a generation job is possible on this card — and "
         "says why when the answer is no.",
    success="`check_will_it_fit()` prints three PASS lines and returns True, and every "
            "rejection message names the specific field that caused it.",
    approach="Collect every reason rather than returning on the first, and separate "
             "*capability* rejections (the tier cannot do this) from *capacity* "
             "rejections (the card cannot hold this), because they have different "
             "fixes — one is a different model, the other is a smaller job.",
)

nb.code('''
CARD_GB = (torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
           if cuda_available else 80.0)
# Say which of the two it is. A silent fallback that reports the wrong card as
# fact is worse than no check at all.
provenance = ("measured from this card" if cuda_available
              else "assumed — no GPU visible, using the documented H100 80GB figure")
print(f"card: {CARD_GB:.1f} GB  ({provenance})")
''')

nb.code('''
def will_it_fit(model, resolution, frames, reserve_gb=4.0):
    """Can this machine run this generation job? Explain either answer.

    Returns {"fits": bool, "reasons": [str], "cost_units": int}. `reasons` is
    populated whether or not it fits: when it does not, they are the rejections;
    when it does, they are the warnings that did not rise to a rejection.
    """
    result = {"fits": False, "reasons": [], "cost_units": 0}
    tier = cc.MODEL_TIERS.get(model)
    if tier is None:
        result["reasons"].append(
            f"unknown model {model!r}; known tiers are "
            f"{', '.join(sorted(cc.MODEL_TIERS))}")
        return result

    # ---- capability: what this tier is documented to do --------------------
    # Resolution tiers are names that happen to look like pixel heights, so they
    # compare as integers, not as strings ("768" > "480" is true as a string
    # here only by luck; "96" > "480" would not be).
    if int(resolution) > int(tier["max_resolution_tier"]):
        result["reasons"].append(
            f"max_resolution_tier: {model} is documented to "
            f"{tier['max_resolution_tier']}p, you asked for {resolution}p")
    low, high = tier["frames_range"]
    if not (low <= frames <= high):
        result["reasons"].append(
            f"frames_range: {model} accepts {low}-{high} frames, you asked for {frames}")

    # ---- capacity: what this card can hold ---------------------------------
    need = tier["inference_vram_gb"] + reserve_gb
    if need > CARD_GB:
        result["reasons"].append(
            f"inference_vram_gb: {model} needs ~{tier['inference_vram_gb']} GB plus "
            f"{reserve_gb:.0f} GB reserve = {need:.0f} GB, and this card has "
            f"{CARD_GB:.0f} GB. No resolution or frame count changes this — the "
            f"weights alone do not fit.")

    # ---- cost: only meaningful for configurations that got this far --------
    est = cc.estimate_generation_cost(
        num_frames=frames, resolution=resolution, model=model)
    result["cost_units"] = est["cost_units"]
    result["relative"] = est["relative_to_480p_121f_35s"]
    for w in est.get("warnings", []):
        result["reasons"].append(f"estimate_generation_cost warning: {w}")

    # A warning is not a rejection. See the commentary below for why.
    hard = [r for r in result["reasons"]
            if not r.startswith("estimate_generation_cost warning")]
    result["fits"] = not hard
    return result
''')

nb.code('''
CASES = [
    ("Cosmos3-Nano", "480", 121, True,
     "the course's normal working configuration"),
    ("Cosmos3-Edge", "768", 121, False,
     "Edge is documented to 480p; the tier, not the card, is the limit"),
    ("Cosmos3-Super", "480", 121, False,
     "128 GB of inference VRAM does not fit an 80 GB card at any resolution"),
]


def check_will_it_fit():
    """Check the three known cases and report what passed."""
    failures = []
    for model, resolution, frames, expected, why in CASES:
        try:
            got = bool(will_it_fit(model, resolution, frames)["fits"])
        except Exception as exc:
            failures.append(f"FAIL {model} {resolution}p {frames}f raised {exc!r}")
            continue
        if got == expected:
            print(f"PASS {model:<14} {resolution}p {frames:>3}f -> fits={got}   ({why})")
        else:
            failures.append(f"FAIL {model:<14} {resolution}p {frames:>3}f -> fits={got}, "
                            f"expected {expected}   ({why})")
    for line in failures:
        print(line)
    return not failures


assert check_will_it_fit(), "the three documented cases must pass"
''')

nb.code('''
# The success criterion also says "every rejection message names the specific
# field that caused it". Check that too, since it is the part a reader is most
# likely to skip.
for model, resolution, frames, expected, _why in CASES:
    verdict = will_it_fit(model, resolution, frames)
    if verdict["fits"]:
        continue
    print(f"{model} {resolution}p {frames}f")
    for reason in verdict["reasons"]:
        field = reason.split(":")[0]
        assert field in {"max_resolution_tier", "frames_range", "inference_vram_gb",
                         "fps_range", "estimate_generation_cost warning"}, reason
        print(f"    [{field}] {reason.split(': ', 1)[-1]}")
    print()

# And the comparison the exercise says the cost is for: two configurations that
# both fit, ranked. Relative cost, not seconds — this is not a time prediction.
for res, frames in [("256", 61), ("480", 61), ("480", 121)]:
    v = will_it_fit("Cosmos3-Nano", res, frames)
    print(f"Nano {res}p {frames:>3}f  fits={v['fits']}  "
          f"cost={v['cost_units']:>10,}  relative={v['relative']:.2f}x")
''')

nb.why(
    "**The judgement call the hint flags: should a warning force `fits=False`?** "
    "`cc.estimate_generation_cost` returns its own `warnings` list, and the exercise "
    "deliberately leaves it open whether those count as rejections. This solution says "
    "no, and keeps them in `reasons` where the caller can see them.\n\n"
    "The argument: `will_it_fit` answers *is this possible*, not *is this wise*. A "
    "configuration that will take four hours is possible; a configuration that needs "
    "128 GB on an 80 GB card is not. Collapsing both into one boolean throws away the "
    "distinction that decides what you do next — one is fixed by waiting, the other "
    "only by changing model. Keeping the warnings visible means a caller who wants the "
    "stricter policy can implement it in one line (`fits and not warnings`), while a "
    "caller who wants the permissive one cannot recover the information if the "
    "predicate has already thrown it away. Given a choice, put the policy at the call "
    "site and the facts in the function.\n\n"
    "**Why capability and capacity are separated.** The three test cases are chosen to "
    "make exactly this point, and it is worth stating explicitly: Edge at 768p fails "
    "for a reason that has nothing to do with your hardware, and Super at 480p fails "
    "for a reason that has nothing to do with your request. Those two failures have "
    "opposite fixes — switch tier versus shrink the job — and a message that just says "
    "\"does not fit\" sends the learner to the wrong one. Hence the Super message says "
    "in so many words that no resolution or frame count changes the answer.\n\n"
    "**Why collect all reasons rather than returning on the first.** Same reason "
    "Exercise 3 makes it a requirement: a person who fixes one problem, re-runs, and "
    "discovers a second has been made to wait twice for information you already had. "
    "That is a small cost here and a large one in Lesson 17, where the re-run is a "
    "training job.\n\n"
    "**Why `CARD_GB` falls back to 80.0.** So the function is testable with no GPU. The "
    "cell prints which of the two it used, because a silent fallback that reports the "
    "wrong card as fact is worse than no check at all — and someone will eventually run "
    "this on a 24 GB card and need to know why it lied."
)

nb.extend(
    "`will_it_fit` currently budgets the model and nothing else. The obvious next step "
    "is to make it aware of what is **already resident**: `cc.vram_budget()` plans the "
    "split between a running Reasoner NIM and the generator, and Lesson 02's central "
    "problem is that the NIM holds VRAM the generator then cannot get. Passing "
    "`CARD_GB - already_used` instead of `CARD_GB` turns this from a static "
    "spec-sheet check into a live one, and would have caught that failure before it "
    "happened. The measurement to feed it is `cc.memory_snapshot(include_smi=True)`, "
    "whose `smi_used_gb` sees the NIM's allocation — which `torch.cuda.memory_allocated` "
    "does not, because the NIM is a different process."
)

# ---------------------------------------------------------------------------
# Exercise 3
# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "A preflight that a later lesson could call",
    goal="Write `preflight(report)` that a later lesson can call as its first cell, "
         "failing with a message specific enough to act on for each of five distinct "
         "broken environments.",
    success="`test_preflight()` prints six PASS lines — one healthy, five broken — and "
            "`preflight(cc.probe_environment(check_docker=False))` on this machine "
            "either passes silently or names a real problem you agree with.",
    approach="Order the checks most-specific-first so the hidden-device case claims the "
             "report before the generic no-GPU case can, and collect every failure into "
             "one raise so a single restart is enough.",
)

nb.code('''
def preflight(report, model="Cosmos3-Edge", *, disk_headroom_gb=10.0):
    """Refuse to start a lesson on a machine that cannot finish it.

    Raises RuntimeError listing EVERY problem found, so one restart is enough.
    """
    tier = cc.MODEL_TIERS[model]
    found = []

    # (d) A hidden device. This is checked FIRST because it presents with the
    #     same symptoms as (a) and (b) — no usable GPU — and the specific
    #     diagnosis is far more useful than the generic one. CUDA_VISIBLE_DEVICES
    #     set to an index this machine does not have is the single-GPU box's
    #     classic self-inflicted wound; the source DLI course shipped it,
    #     because it ran on two cards.
    visible = (report.visible_devices or "").strip()
    hidden = False
    if visible and visible not in {"", "all"}:
        requested = [tok for tok in re.split(r"[,\\s]+", visible) if tok]
        numeric = [int(t) for t in requested if t.lstrip("-").isdigit()]
        # Count physical GPUs from whatever the report still knows about. When
        # CUDA_VISIBLE_DEVICES filters everything out, gpu_count is 0 and the
        # names list is empty, so any non-zero index requested is out of range.
        physical = max(report.gpu_count, len(report.gpu_names))
        if numeric and (physical == 0 or max(numeric) >= physical):
            hidden = True
            found.append(
                f"CUDA_VISIBLE_DEVICES={visible!r} selects a device index this "
                f"machine does not have (it enumerates {physical} GPU(s), so the "
                f"only valid index is 0). "
                f"FIX: `unset CUDA_VISIBLE_DEVICES` (or set it to 0) and restart "
                f"the kernel. Setting it in a notebook cell after torch has "
                f"initialised has no effect — it must be set before the process "
                f"starts.")

    # (a) No NVIDIA GPU visible at all.
    if not hidden and report.gpu_count == 0 and not report.gpu_names:
        found.append(
            "no NVIDIA GPU is visible. FIX: confirm you are on a GPU instance and "
            "that `nvidia-smi` runs in a terminal. If nvidia-smi works but this "
            "does not, you are in a container without `--gpus all`.")

    # (b) A GPU is present but torch cannot use it.
    elif not hidden and not report.torch_cuda_available:
        if report.torch_cuda_version is None:
            found.append(
                f"a GPU is present ({report.gpu_names[0] if report.gpu_names else '?'}) "
                f"but torch {report.torch_version} is a CPU-only build "
                f"(torch.version.cuda is None). FIX: reinstall torch from the CUDA "
                f"index — `pip install torch --index-url "
                f"https://download.pytorch.org/whl/cu128` — or re-run "
                f"scripts/setup.sh and select the 'Cosmos 3 (H100)' kernel.")
        else:
            found.append(
                f"a GPU is present but torch.cuda.is_available() is False with a CUDA "
                f"build ({report.torch_cuda_version}). FIX: this is almost always a "
                f"driver older than the runtime. Compare `nvidia-smi`'s CUDA version "
                f"against torch.version.cuda; if the driver is lower, update it.")

    # (c) A GPU with too little VRAM for the requested tier.
    if report.gpu_vram_total_gb:
        largest = max(report.gpu_vram_total_gb)
        need = tier["inference_vram_gb"]
        if largest < need:
            found.append(
                f"largest GPU has {largest:.1f} GB but {model} needs about {need} GB "
                f"for inference. FIX: drop to a smaller tier "
                f"(COSMOS_COURSE_MODEL=Cosmos3-Edge needs about "
                f"{cc.MODEL_TIERS['Cosmos3-Edge']['inference_vram_gb']} GB), or use a "
                f"bigger card. Lower resolution will not close a gap this size — the "
                f"weights are resident before a single frame is generated.")

    # (e) Insufficient free disk for the requested tier's download.
    if report.disk_free_gb is not None:
        need_disk = tier["download_gb"] + disk_headroom_gb
        if report.disk_free_gb < need_disk:
            found.append(
                f"only {report.disk_free_gb:.1f} GB free, and {model} needs "
                f"{tier['download_gb']:.1f} GB for the checkpoint plus "
                f"{disk_headroom_gb:.0f} GB of working room = {need_disk:.1f} GB. "
                f"FIX: free space, or point the cache elsewhere with "
                f"`export HF_HOME=/some/larger/volume`. Check what is already "
                f"cached with `du -sh ~/.cache/huggingface` before downloading again.")

    if found:
        raise RuntimeError("preflight failed:\\n  - " + "\\n  - ".join(found))
    return True
''')

nb.code('''
def make_report(**overrides):
    """A synthetic EnvReport for testing. Healthy H100 by default."""
    base = dict(
        machine="x86_64", python_version="3.12.3", gpu_count=1,
        gpu_names=["NVIDIA H100 80GB HBM3"], gpu_vram_total_gb=[79.6],
        compute_capability="9.0", torch_version="2.8.0", torch_cuda_version="12.8",
        torch_cuda_available=True, disk_free_gb=400.0, visible_devices=None,
    )
    base.update(overrides)
    return cc.EnvReport(**base)


BROKEN = {
    "no gpu": make_report(gpu_count=0, gpu_names=[], gpu_vram_total_gb=[],
                          torch_cuda_available=False),
    "torch cannot use it": make_report(torch_cuda_available=False, torch_cuda_version=None),
    "too little vram": make_report(gpu_vram_total_gb=[7.8],
                                   gpu_names=["NVIDIA GeForce RTX 2080"]),
    "hidden device": make_report(visible_devices="1", gpu_count=0,
                                 torch_cuda_available=False),
    "disk full": make_report(disk_free_gb=3.0),
}


def test_preflight():
    """A healthy report must pass; each broken one must fail for its own reason."""
    failures = []
    try:
        preflight(make_report())
        print("PASS healthy report is accepted")
    except RuntimeError as exc:
        failures.append(f"FAIL healthy report was rejected: {exc}")
    for label, broken in BROKEN.items():
        try:
            preflight(broken)
            failures.append(f"FAIL {label!r} was accepted and should not have been")
        except RuntimeError as exc:
            print(f"PASS {label!r} rejected: {str(exc).splitlines()[-1][:90]}")
    for line in failures:
        print(line)
    return not failures


assert test_preflight(), "all six cases must pass"
''')

nb.code('''
# "and no others" — the exercise asks that each broken report triggers ITS OWN
# message. Six PASS lines would also be printed by a function that always raises
# the same generic complaint, so check the discrimination explicitly.
SIGNATURE = {
    "no gpu": "no NVIDIA GPU is visible",
    "torch cannot use it": "CPU-only build",
    "too little vram": "needs about",
    "hidden device": "CUDA_VISIBLE_DEVICES",
    "disk full": "GB free",
}
for label, broken in BROKEN.items():
    try:
        preflight(broken)
        raise AssertionError(f"{label} was accepted")
    except RuntimeError as exc:
        text = str(exc)
        assert SIGNATURE[label] in text, f"{label}: expected {SIGNATURE[label]!r} in {text}"
        # The hidden-device case must NOT also emit the generic no-GPU message,
        # or the more specific diagnosis is buried.
        if label == "hidden device":
            assert "no NVIDIA GPU is visible" not in text, (
                "the hidden-device case leaked the generic no-GPU message:\\n" + text)
        print(f"PASS {label:<22} -> distinct message containing {SIGNATURE[label]!r}")
''')

nb.code('''
# The other half of the success criterion: run it against this actual machine.
# check_docker=False because docker is not what this gate is about and probing
# it is slow.
report = cc.probe_environment(check_docker=False)
try:
    preflight(report, model=MODEL)
    print(f"preflight PASSED for {MODEL} on this machine")
except RuntimeError as exc:
    print(exc)
    print()
    print("If you are reading this on a machine without an H100, that output is the "
          "correct answer, not a failure of the gate — which is the point of the "
          "exercise.")
''')

nb.why(
    "**The hard part is (b) versus (d), and the hint says why: both present as "
    "`torch_cuda_available=False`.** The discriminator chosen here is *what the report "
    "still knows about the hardware*. A CPU-only torch build leaves the GPU enumerated "
    "by `nvidia-smi` — `gpu_count` is 1, `gpu_names` is populated — and leaves "
    "`torch_cuda_version` as `None`. `CUDA_VISIBLE_DEVICES=1` on a one-GPU box leaves "
    "`visible_devices` set to an index that does not exist and `gpu_count` at 0, "
    "because the filtering happens below the level the probe reads.\n\n"
    "So the check runs most-specific-first: the hidden-device case is tested before "
    "either of the generic ones and sets a `hidden` flag that suppresses them. Without "
    "that suppression the learner gets both \"no GPU is visible\" and "
    "\"CUDA_VISIBLE_DEVICES selects a device you do not have\", and the true diagnosis "
    "is one bullet among two — which trains people to read the first line and stop. "
    "The rule generalises: *when two checks can fire on the same evidence, the more "
    "specific one must run first and silence the other.*\n\n"
    "**Why every message carries a FIX.** The exercise says \"no GPU\" is not "
    "actionable, and it is right, but the deeper reason is that a preflight gate is "
    "read by someone who is *blocked*. They are not going to go and read the "
    "documentation; they are going to read your error and act on it. Every string above "
    "therefore names the command to run. The disk message goes one further and tells "
    "them to check what is already cached before downloading again, because the "
    "commonest cause of a full disk here is two copies of the same checkpoint.\n\n"
    "**Why VRAM is checked independently of the torch checks.** A report can have a "
    "working CUDA torch *and* a card too small for the tier — an RTX 2080 with a "
    "perfectly good driver. Making the VRAM check an `elif` on the torch branch would "
    "hide it on exactly the machine where it is the only thing wrong. Note that "
    "`test_preflight`'s `too little vram` case has `torch_cuda_available=True`, so an "
    "`elif` would silently pass it — a bug that six PASS lines would not have caught, "
    "which is why the extra discrimination cell exists.\n\n"
    "**Why raise rather than return False.** A gate that returns a falsy value is a "
    "gate you can forget to check, and the whole premise is that this is the *first "
    "cell* of a later lesson. `raise` cannot be ignored in a notebook: the cell goes "
    "red and nothing after it runs. Returning `True` on success rather than `None` is "
    "so it can also be used inside an `assert` if a caller prefers that."
)

nb.extend(
    "Two extensions with genuine content:\n\n"
    "- **Make the tier argument do more work.** Right now `model` selects VRAM and disk "
    "thresholds. It could also select *mode* thresholds: Lesson 09's audio work is "
    "impossible on Edge (`supports_audio: False`), and Lesson 08's transfer work is "
    "impossible on Edge too. A `preflight(report, model=MODEL, needs=('audio',))` "
    "signature would let each lesson declare what it requires and fail in Lesson 09's "
    "first cell instead of forty minutes in.\n"
    "- **Separate fatal from advisory.** `cc.probe_environment()` already fills both "
    "`report.problems` and `report.warnings`, and `_assess()` deliberately leaves the "
    "fatal/advisory decision to the caller. A `preflight(..., strict=False)` that "
    "prints warnings and raises only on problems would let Lesson 00 run on a laptop "
    "for reading while Lesson 17 refuses to start without the card. The reason not to "
    "do this by default is that a warning nobody reads is indistinguishable from no "
    "check at all."
)

nb.finish()
