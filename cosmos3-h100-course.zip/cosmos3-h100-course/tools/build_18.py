"""Build 18_evaluation.ipynb.

The last lesson of Module 5, and the one with the most awkward premise: the
repository ships no way to answer "did it get better?".

Primary sources:

`docs/code_structure.md` — `cosmos_framework/evaluation/` is tagged
**`[planned]`**, and the document says explicitly that the tagged directories
"are intentionally absent on disk". Same for `algorithm/` (loss, reward, rl),
`launcher/`, `controller/`, `communicator/` and `workers/`. So there is no
offline metric harness, no action-MSE script, and no validation-loss loop in
this release. The notebook says that in its first paragraph and then has the
learner verify it in their own checkout.

`docs/action_policy_libero_posttrain.md` (via COSMOS3_FACTS.md §5) — closed-loop
simulation eval exists and needs a second virtualenv (`robosuite==1.4.1`,
`mujoco==2.3.7`, `torch<2.6`), which is Lesson 13's territory.

The pedagogical core is a **synthetic model pair with a known ground-truth
effect size**. This matters: an evaluator you have never validated is not
evidence, and you cannot validate one against a real fine-tune because you do
not know the truth there. So the lesson calibrates the harness on a simulator
whose effect size is a constant in the notebook, shows the learner that a
realistic effect is invisible at n=4 and visible at n=40 paired, and only then
points the same harness at whatever Lesson 17 produced.

Everything runs with **no GPU and no downloads**. The only optional cell is a
real base-vs-fine-tuned generation, gated behind an environment variable.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 18 — Evaluating a post-trained model")

# --------------------------------------------------------------- title block
nb.md("""
# Lesson 18 — Evaluating a post-trained model

**What you will build.** `outputs/18/` containing an offline evaluation harness
you wrote — fixed prompt set, fixed seeds, base against fine-tuned, automatic
verification, structured records — a leakage detector, a seed-variance estimate,
and `eval_report.md`: a result you are willing to defend, including a section on
what it does not show.

| | |
|---|---|
| **Time** | ~2 hours |
| **GPU** | **None** for the harness. One optional section uses the H100. |
| **Downloads** | **None.** |
| **Prerequisites** | Lesson 17 — with or without a successful fine-tune. Lesson 13 for the closed-loop section. |

### The headline, first

**`cosmos_framework/evaluation/` does not exist in this release.**
`docs/code_structure.md` lists it, and every other planned subpackage, with the
tag `[planned]`, and states that "the directories are intentionally absent on
disk." There is no offline metric harness. There is no action-MSE script. There
is no validation-loss loop. If you went looking for the evaluation module
because a fine-tune finished and you wanted a number, there is nothing to find.

So this lesson does what you would have to do anyway: build the missing thing,
badly at first, and then well enough to trust. That is not a consolation prize.
Evaluation design is the part of machine learning that most often decides
whether a result is real, and it is the part most often skipped because a
framework happened to ship a `--eval` flag.
""")

# ---------------------------------------------------------------- objectives
nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Verify** that the evaluation subpackage is absent from your own checkout,
   rather than taking this notebook's word for it.
2. **Explain** what a held-out set is, why it must be held out, and what breaks
   when it is not.
3. **Distinguish** a falling training loss from a better model, and state what
   each does and does not license you to claim.
4. **Implement** an offline evaluator: fixed prompts, fixed seeds, two models,
   automatic verification, structured records.
5. **Calibrate** that evaluator against a known effect size before trusting it
   on an unknown one.
6. **Measure** seed variance and **decide** whether a difference survives it.
7. **Compute** how many samples you need before a difference means anything.
8. **Detect** and **quantify** data leakage between a training set and an
   evaluation set.
9. **Explain** why closed-loop evaluation is the gold standard for action
   policies and why it is out of reach on this machine.
10. **Write** a result honestly — method, sample size, confounds, and an
    explicit list of what the evidence does not support.
""")

# ------------------------------------------------- conceptual foundation (1)
nb.md("""
## What exists, and what does not

**Does not exist in `v1.2.2`:** `cosmos_framework/evaluation/`, and with it any
offline metric harness, dataset-driven eval loop, or reporting. Also absent:
`algorithm/` (so no reward models, no RL), `launcher/`, `controller/`,
`communicator/`, `workers/`.

**Does exist:** closed-loop *simulation* evaluation for action policies. LIBERO
through `action_policy_server_libero` plus `closed_loop_eval.py`, and DROID
through RoboLab. Lesson 13 covered both, and covered why they need a separate
virtualenv: `robosuite==1.4.1`, `mujoco==2.3.7` and `torch<2.6` cannot coexist
with a CUDA-13 torch and FlashAttention-3. That is a real constraint, not an
inconvenience, and it is why closed-loop eval is documented in this course
rather than run.

**Also missing, and worth naming:** there is no validation-loss loop. The
shipped TOMLs have a `[dataloader_train]` section and no `[dataloader_val]`.
The BridgeData2 dataset ships a `val/` split with 51 clips and inference prompt
files — but nothing in the training loop consumes it. Validation is something
you do afterwards, by hand, with the tools you are about to write.

Do not take this from a notebook. Check.
""")

nb.callout(
    "upstream",
    "`docs/code_structure.md` is the rare upstream document that is honest about "
    "its own gaps: it draws the full intended tree, tags six subpackages "
    "`[planned]`, and says in a note that \"the directories are intentionally "
    "absent on disk\". That is much better than silence — but it also means a "
    "reader who skims the tree and misses the note will spend an afternoon "
    "looking for `cosmos_framework/evaluation/`. Read the tags, then run `ls`. "
    "The cell below does exactly that against your own checkout.",
)

nb.md("""
## Environment

Everything in this lesson runs on CPU. The synthetic model pair used to
calibrate the harness is a few lines of NumPy, and the only optional section
needs a GPU and a checkpoint from Lesson 17.
""")

nb.code('__lesson__ = "18"   # OUTPUT_DIR resolves to outputs/18\n\n' + SETUP_CELL)

nb.code('''
# ---------------------------------------------------------------------------
# Configuration. One optional section is gated; everything else is free.
# ---------------------------------------------------------------------------
import hashlib
import json
import math
import statistics
from dataclasses import dataclass, field, asdict

import numpy as np
from PIL import Image

# Opt-in: generate with the REAL models for the base-vs-fine-tuned section.
#   export COSMOS_COURSE_RUN_EVAL_GEN=1
RUN_REAL_GENERATION = os.environ.get("COSMOS_COURSE_RUN_EVAL_GEN", "0") == "1"

# Where Lesson 17's export would be, if you have one.
FINETUNED_MODEL = (cc.OUTPUT_ROOT / "17" / "train" / "cosmos3" / "sft"
                   / "vision_sft_edge" / "model")

N_FRAMES = 8          # frames per synthetic sample. Small on purpose.
FRAME_SIZE = 64       # pixels. Also small on purpose.

print(f"RUN_REAL_GENERATION : {RUN_REAL_GENERATION}")
print(f"fine-tuned export   : {FINETUNED_MODEL}")
print(f"  present           : {FINETUNED_MODEL.exists()}")
print()
print("If that says False, this lesson still works completely. The harness is")
print("the artefact; the checkpoint is optional input to it.")
''')

nb.code('''
# Verify the headline in YOUR checkout rather than believing this notebook.
FW = cc.COSMOS3_REPO / "cosmos_framework"
DOCUMENTED = ["algorithm", "callbacks", "checkpoint", "communicator", "configs",
              "controller", "data", "evaluation", "inference", "launcher",
              "model", "tools", "trainer", "utils", "workers", "scripts"]

if FW.is_dir():
    print(f"{FW}\\n")
    for name in DOCUMENTED:
        exists = (FW / name).is_dir()
        print(f"  {'present' if exists else 'ABSENT ':<8s} {name}")
    absent = [n for n in DOCUMENTED if not (FW / n).is_dir()]
    print()
    print(f"absent: {', '.join(absent) if absent else 'none'}")
    print("Compare that against the [planned] tags in docs/code_structure.md.")
else:
    print(f"no checkout at {FW} — check it yourself when you have one:")
    print(f"  ls {FW}")
    print("docs/code_structure.md tags algorithm, communicator, controller,")
    print("evaluation, launcher and workers as [planned], and says they are")
    print("intentionally absent on disk. Everything else in that tree exists.")
''')

# ------------------------------------------------- conceptual foundation (2)
nb.md("""
## Evaluation from first principles

Three ideas, none of which is complicated, all of which are routinely skipped.

**A held-out set is data the model has never been trained on, chosen before you
look at any results.** Both halves of that matter. "Never trained on" is
obvious. "Chosen before you look" is the part people violate: if you run the
evaluation, dislike the answer, and swap in different prompts, you have turned
your held-out set into a training set for your own judgement. The prompt list
is part of the experiment and it gets fixed at the start.

**Training loss falling is not the model getting better.** Training loss
measures how well the model fits the examples it is being shown *while being
shown them*. It falls when the model learns something general, and it also
falls when the model memorises, when the learning rate schedule happens to be
in a helpful phase, and when the data distribution shifts to easier batches. It
is a necessary condition for learning and evidence of almost nothing on its
own. The honest statement after Lesson 17's smoke run is "gradients flowed",
not "the model improved".

**One before/after comparison on one prompt is not evidence.** Generation is
stochastic. Change the seed and you get a different video from the *same* model.
If the seed-to-seed difference is bigger than the base-to-fine-tuned
difference — and after 20 iterations it certainly is — then a single comparison
tells you about the seed. This is the single most common error in fine-tuning
write-ups, and it is entirely avoidable: run more than one seed and look at the
spread before you look at the means.

Those three give you the shape of the harness: a **fixed** prompt set that is
genuinely **held out**, run at **multiple seeds** on **both** models, with every
output **verified** rather than assumed.
""")

# --------------------------------------------------------------- the harness
nb.md("""
## Building the harness

Start with the data structure, because it decides what questions you can ask
later. A record needs enough to reproduce the sample and enough to compare it,
and it needs to exist even when the sample **failed** — a harness that silently
drops failures reports the mean of the successes, which flatters whichever model
fails more often.
""")

nb.code('''
@dataclass
class EvalCase:
    """One prompt in the suite, with the metadata that makes it interpretable."""
    prompt_id: str
    prompt: str
    category: str        # "in-domain" | "near-domain" | "out-of-domain"
    note: str = ""


@dataclass
class EvalRecord:
    """One (model, prompt, seed) sample. Written whether or not it succeeded."""
    model: str
    prompt_id: str
    seed: int
    ok: bool
    path: str | None = None
    metrics: dict = field(default_factory=dict)
    checks: dict = field(default_factory=dict)
    error: str = ""


def write_records(records, path):
    """Append-only JSONL. One line per sample, failures included."""
    with Path(path).open("w") as fh:
        for r in records:
            fh.write(json.dumps(asdict(r)) + "\\n")
    return path
''')

nb.md("""
### A model pair with a known answer

Here is a thing most evaluation write-ups skip, and it is the reason so many of
them are wrong: **an evaluator you have never validated is not evidence.**

You cannot validate one against a real fine-tune, because you do not know the
truth there — that is what you are trying to find out. So validate it against
something whose truth is a constant in your own code. Below is a pair of
synthetic "models" that differ by a known amount, plus seed noise of a known
size. If your harness cannot recover an effect you planted yourself, it will
not recover a real one either.

**Be clear about what this is not.** It is not a model of Cosmos 3, it does not
generate video, and its numbers mean nothing about any real checkpoint. It is a
test fixture for your evaluator. The moment the harness is calibrated, we point
it at real outputs and the fixture goes away.
""")

nb.code('''
def _rng(*parts):
    """Deterministic RNG from arbitrary keys.

    NOT Python's hash(): str hashing is salted per process, so a notebook that
    used it would give different answers on every kernel restart. That is the
    kind of irreproducibility an evaluation lesson cannot afford.
    """
    key = "|".join(str(p) for p in parts).encode()
    seed = int.from_bytes(hashlib.sha1(key).digest()[:8], "big")
    return np.random.default_rng(seed)


# The two "models". They differ in exactly one number: `effect`, the amount by
# which the fine-tune raises rendered smoothness on IN-DOMAIN prompts.
MODELS = {
    "base":      {"base_smoothness": 0.45, "effect": 0.00,
                  "seed_noise": 0.03, "memorised": ()},
    "finetuned": {"base_smoothness": 0.45, "effect": 0.05,
                  "seed_noise": 0.03, "memorised": ()},
}

# A fine-tune does not improve everything uniformly. It helps in its domain,
# helps less nearby, and can HURT far from it -- catastrophic forgetting is a
# real thing and an evaluation that only tests in-domain will never see it.
CATEGORY_GAIN = {"in-domain": 1.0, "near-domain": 0.5, "out-of-domain": -0.4}


def prompt_difficulty(prompt_id):
    """A property of the PROMPT, identical for every model.

    Real prompts differ enormously in how much structure their videos have, and
    that difference dwarfs most fine-tuning effects. It is also the thing
    pairing cancels -- which is exactly why pairing works.
    """
    return float(_rng(prompt_id, "difficulty").normal(0, 0.07))


def effective_smoothness(model, case, seed, *, noise=True, difficulty=True):
    cfg = MODELS[model]
    s = cfg["base_smoothness"] + cfg["effect"] * CATEGORY_GAIN[case.category]
    if difficulty:
        s += prompt_difficulty(case.prompt_id)
    if case.prompt_id in cfg["memorised"]:
        s += 0.15          # memorisation bonus; used by the leakage lab below
    if noise:
        s += _rng(model, case.prompt_id, seed, "noise").normal(0, cfg["seed_noise"])
    return float(np.clip(s, 0.05, 0.95))


for name, cfg in MODELS.items():
    print(f"  {name:<10s} base {cfg['base_smoothness']:.2f}  "
          f"effect {cfg['effect']:+.2f}  seed noise sd {cfg['seed_noise']:.2f}")
print()
print("category gains:", CATEGORY_GAIN)
print()
print("Note the negative out-of-domain gain. A suite that only tests in-domain")
print("cannot tell an improvement from a trade.")
''')

nb.code('''
def _spatial_smooth(a, strength, passes=6):
    """Blend `a` towards its blur, `strength` at a time. Continuous in strength.

    Deliberately NOT `for _ in range(int(passes * strength))`: an integer number
    of passes quantises the effect, so a 0.05 change in strength would sometimes
    do nothing at all. A fixture whose effect size is not continuous cannot
    calibrate an evaluator.
    """
    out = a.copy()
    for _ in range(passes):
        blur = (out
                + np.roll(out, 1, 0) + np.roll(out, -1, 0)
                + np.roll(out, 1, 1) + np.roll(out, -1, 1)) / 5.0
        out = (1.0 - strength) * out + strength * blur
    return out


def render(smoothness, content_key, out_dir):
    """Write a frame stack at an explicit smoothness. `content_key` seeds the
    underlying random field -- and note that it does NOT include the model, so
    two models at the same (prompt, seed) see the same content. That mirrors
    fixing the latent noise across models at inference, and it is what makes
    the paired comparison below work."""
    rng = _rng(*content_key)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    frames, prev = [], rng.normal(0, 1, (FRAME_SIZE, FRAME_SIZE))
    for i in range(N_FRAMES):
        # Temporal AR(1): consecutive frames are related, as in real video.
        prev = 0.8 * prev + 0.2 * rng.normal(0, 1, (FRAME_SIZE, FRAME_SIZE))
        img = _spatial_smooth(prev, smoothness)
        arr = ((img - img.min()) / (np.ptp(img) + 1e-9) * 255).astype(np.uint8)
        path = out_dir / f"frame_{i:03d}.png"
        Image.fromarray(arr).save(path)
        frames.append(path)
    return frames


def synthesise(model, case, seed, out_dir):
    """The `generate_fn` the harness calls. Same signature as the real one."""
    return render(effective_smoothness(model, case, seed),
                  (case.prompt_id, seed), out_dir)
''')

# ------------------------------------------------------------- metrics
nb.md("""
### Metrics, and what each one is blind to

Three cheap proxies. Each is stated with what it cannot see, because a metric
whose blind spots you have not written down will eventually be used outside
them.

| Metric | What it measures | Blind to |
|---|---|---|
| **structure** | spatial autocorrelation — how much a pixel predicts its neighbours | *what* the structure is. Coherent noise scores well. |
| **aliveness** | mean absolute difference between consecutive frames | direction. A shaking camera and a moving robot look the same. |
| **stability** | variance of the frame-to-frame difference | slow drift. A scene dissolving over 8 frames scores as stable. |

None of them measures whether the video shows what you asked for. That is not a
gap in this implementation, it is a property of every automated proxy of this
kind, including the expensive ones — and it is why the honest workflow is
"screen automatically, then look at what survives".
""")

nb.code('''
def load_stack(paths):
    return np.stack([np.asarray(Image.open(p), dtype=np.float64) for p in paths])


def structure(stack):
    """Spatial autocorrelation at lag 1, averaged over frames and both axes.

    1.0 means neighbouring pixels are identical; 0.0 means independent noise.
    This is the same idea cosmos_course.checks uses to catch the grey-noise
    failure that every amplitude-based check sails past.
    """
    vals = []
    for f in stack:
        for shifted in (np.roll(f, 1, 0), np.roll(f, 1, 1)):
            a, b = f.ravel(), shifted.ravel()
            a = a - a.mean()
            b = b - b.mean()
            denom = math.sqrt((a * a).sum() * (b * b).sum()) + 1e-9
            vals.append(float((a * b).sum() / denom))
    return sum(vals) / len(vals)


def aliveness(stack):
    """Mean |frame[i+1] - frame[i]|, normalised to 0-1. Zero means a still."""
    if len(stack) < 2:
        return 0.0
    return float(np.abs(np.diff(stack, axis=0)).mean() / 255.0)


def stability(stack):
    """Standard deviation of the per-frame change. High means jitter."""
    if len(stack) < 3:
        return 0.0
    per_frame = np.abs(np.diff(stack, axis=0)).mean(axis=(1, 2))
    return float(np.std(per_frame) / 255.0)


def measure(paths):
    stack = load_stack(paths)
    return {"structure": round(structure(stack), 4),
            "aliveness": round(aliveness(stack), 4),
            "stability": round(stability(stack), 4)}
''')

nb.md("""
### Calibrate the metric against the effect you planted

You now have a fixture with a known effect and a metric that claims to see it.
Those are two different things, and the step between them is the one that gets
skipped. Before running any comparison, check three properties:

1. **Monotonicity.** Does the metric move in the right direction as the planted
   parameter moves? A metric that is not monotone in the thing you care about
   will produce confident nonsense.
2. **Scale.** How many metric units is one unit of the planted effect? Without
   this, a difference of "0.03" means nothing to you.
3. **Sign on out-of-domain.** The fixture's out-of-domain gain is negative. If
   your metric reports an improvement there, the metric is not measuring what
   you think.

The output of this cell is `TRUE_EFFECT` — the in-domain effect expressed in the
units your metric actually reports. Every comparison later in the lesson is
judged against it.
""")

nb.code('''
CAL_DIR = OUTPUT_DIR / "calibration"

def metric_at(smoothness, tag="cal"):
    """Noise-free metric value for a given smoothness, on fixed content."""
    return measure(render(smoothness, ("calibration",), CAL_DIR / tag))["structure"]

print("monotonicity and scale")
print(f"{'smoothness':>11s} {'structure':>10s}")
prev = None
for s in (0.30, 0.40, 0.45, 0.50, 0.60, 0.70):
    m = metric_at(s, f"s{int(s * 100)}")
    arrow = "" if prev is None else ("  up" if m > prev else "  DOWN — not monotone")
    print(f"{s:>11.2f} {m:>10.4f}{arrow}")
    prev = m

# The in-domain effect, in metric units. Difficulty and seed noise are switched
# off so this is the planted effect and nothing else.
cal_case = EvalCase("calibration", "calibration probe", "in-domain")
s_base = effective_smoothness("base", cal_case, 0, noise=False, difficulty=False)
s_tuned = effective_smoothness("finetuned", cal_case, 0, noise=False, difficulty=False)
TRUE_EFFECT = metric_at(s_tuned, "tuned") - metric_at(s_base, "base")


def expected_pooled_effect(cases):
    """What a mean over THIS suite should come to, given its composition.

    Approximate: the metric is concave in the planted parameter, so a weighted
    average of gains is not exactly the average of the metric changes. Close
    enough to check an answer against, and the gap is itself informative.
    """
    gains = [CATEGORY_GAIN[c.category] for c in cases]
    return TRUE_EFFECT * (sum(gains) / len(gains))


print()
print(f"in-domain smoothness  {s_base:.3f} -> {s_tuned:.3f}")
print(f"TRUE_EFFECT (metric)  {TRUE_EFFECT:+.4f}   <- IN-DOMAIN only")
print()
print("That number is the ground truth for the rest of this lesson. In a real")
print("evaluation you do not have one — which is the entire reason to build")
print("confidence in the harness here, where you do.")
''')

nb.callout(
    "warning",
    "Nothing produced by this fixture is a fact about Cosmos 3. The two "
    "\"models\" are twelve lines of NumPy, the \"videos\" are smoothed noise, and "
    "the effect size is a constant somebody typed. Its entire job is to answer "
    "the question \"does my evaluator find an effect that is definitely there?\" "
    "before you ask it \"is there an effect?\" about something real. When you "
    "swap in `cosmos_generate` later, delete these numbers — do not carry them "
    "into a report as a baseline.",
)

nb.code('''
def run_suite(models, cases, seeds, root, *, generate=synthesise):
    """Every (model, case, seed). Verified, measured, recorded -- failures too.

    Note the loop order and what is held fixed: the SAME seed is used for every
    model on a given case, so base and fine-tuned differ only by the model. An
    unpaired comparison needs several times the samples for the same power.
    """
    records = []
    for model in models:
        for case in cases:
            for seed in seeds:
                out = Path(root) / model / case.prompt_id / f"seed{seed}"
                try:
                    paths = generate(model, case, seed, out)
                except Exception as exc:                      # noqa: BLE001
                    records.append(EvalRecord(model, case.prompt_id, seed,
                                              ok=False, error=repr(exc)))
                    continue
                # Verify BEFORE measuring. A metric computed on a blank frame
                # is a number, and it will happily go in your mean.
                check = cc.check_image(paths[0])
                records.append(EvalRecord(
                    model=model, prompt_id=case.prompt_id, seed=seed,
                    ok=bool(check.passed), path=str(out),
                    metrics=measure(paths),
                    checks={"first_frame": check.passed,
                            "reason": check.reason[:120],
                            "metrics": check.metrics},
                ))
    return records
''')

nb.code('''
SUITE = [
    EvalCase("bridge_pick",
             "A robotic manipulator lifts a cylinder out of a shallow bin.",
             "in-domain"),
    EvalCase("bridge_place",
             "A gripper sets a wooden block down beside a ceramic mug.",
             "in-domain"),
    EvalCase("kitchen_pour", "A robot arm pours liquid from a jug into a cup.",
             "near-domain"),
    EvalCase("hand_sort", "A human hand sorts almonds into two piles.",
             "near-domain", note="same task, different embodiment"),
    EvalCase("coastal_road", "A car drives along a coastal road at sunset.",
             "out-of-domain", note="regression check — should NOT improve"),
    EvalCase("forest_path", "Sunlight falls through trees onto a forest path.",
             "out-of-domain", note="regression check — should NOT improve"),
]
SEEDS = [0, 1, 2, 3, 4, 5, 6, 7]

records = run_suite(["base", "finetuned"], SUITE, SEEDS,
                    OUTPUT_DIR / "runs")
rec_path = write_records(records, OUTPUT_DIR / "records.jsonl")

n_ok = sum(r.ok for r in records)
print(f"{len(records)} samples, {n_ok} passed verification, "
      f"{len(records) - n_ok} failed")
print(f"records -> {rec_path.relative_to(COURSE_ROOT)}")
print()
for r in records[:3]:
    print(f"  {r.model:<10s} {r.prompt_id:<14s} seed {r.seed}  "
          f"ok={r.ok}  {r.metrics}")
''')

nb.checkpoint(
    "Before comparing anything, confirm the harness is sound: every sample "
    "produced a record, failures are represented rather than dropped, and the "
    "pairing is intact.",
    '''
by_model = {}
for r in records:
    by_model.setdefault(r.model, []).append(r)

expected = len(SUITE) * len(SEEDS)
for model, rs in by_model.items():
    print(f"  {model:<10s} {len(rs)} records (expected {expected}), "
          f"{sum(r.ok for r in rs)} verified ok")
    assert len(rs) == expected, "a sample vanished — find out which and why"

pairs = {(r.prompt_id, r.seed) for r in by_model["base"]}
assert pairs == {(r.prompt_id, r.seed) for r in by_model["finetuned"]}
print()
print(f"  {len(pairs)} matched (prompt, seed) pairs — the comparison is paired")
''')

# ------------------------------------------------------ the naive comparison
nb.md("""
## The comparison people actually run

One prompt, one seed, look at both, form an opinion. Do it, so you can see what
is wrong with it.
""")

nb.code('''
def value(records, model, prompt_id, seed, metric="structure"):
    for r in records:
        if (r.model, r.prompt_id, r.seed) == (model, prompt_id, seed):
            return r.metrics.get(metric)
    return None

b = value(records, "base", "bridge_pick", 0)
f = value(records, "finetuned", "bridge_pick", 0)
print("The n=1 comparison")
print(f"  base      structure {b:.4f}")
print(f"  finetuned structure {f:.4f}")
print(f"  difference          {f - b:+.4f}")
print(f"  true effect         {TRUE_EFFECT:+.4f}  (we planted it, so we know)")
print()
print("Now the same comparison on every other seed of the SAME prompt:")
for s in SEEDS[1:]:
    d = value(records, "finetuned", "bridge_pick", s) - \\
        value(records, "base", "bridge_pick", s)
    print(f"  seed {s}: difference {d:+.4f}")
''')

nb.predict_run_explain(
    predict=(
        "You are about to average the difference over all 5 prompts × 4 seeds. "
        "Predict: (a) will the pooled mean land near `TRUE_EFFECT`, which is the "
        "**in-domain** effect you just calibrated? Look at the suite's "
        "composition before you answer. (b) will the difference be "
        "*statistically* distinguishable from zero at n=20 paired samples? "
        "(c) if you instead compared the two models on different seeds — "
        "unpaired — would you need more samples or fewer for the same "
        "confidence?"
    ),
    change=(
        "Nothing to change yet. Run the two cells below: the first does the "
        "paired comparison, the second does the unpaired one on the same data."
    ),
    explain=(
        "On (a): the pooled mean is a **composition-weighted** average. This "
        "suite is two in-domain, two near-domain and two out-of-domain, whose "
        "gains are 1.0, 0.5 and −0.4, so the expected pooled effect is about a "
        "third of `TRUE_EFFECT` — and at this sample size it may not clear zero "
        "at all, even though the fine-tune genuinely helps in-domain. Change "
        "the suite and you change the answer without "
        "touching either model — which means 'the fine-tune improved things by "
        "X' is a statement about your prompt list as much as about the model. "
        "Report per-category, always.\n\n"
        "On (b) and (c): pairing removes the prompt's and the seed's "
        "contributions from the comparison, because both models saw the same "
        "prompt at the same seed and both effects cancel in the difference. "
        "That is why the paired standard error is far smaller than the unpaired "
        "one on identical data. If you take one habit from this lesson, take "
        "this: **fix the seed across the models you are comparing, and vary it "
        "across repeats to estimate variance.** Two different jobs for one knob."
    ),
    hint=(
        "Compute the differences first, then take their mean and standard "
        "deviation. Compare that standard deviation against the standard "
        "deviation of the raw base scores. If pairing is working, the former is "
        "much smaller."
    ),
)

nb.code('''
def paired_differences(records, metric="structure", model_a="base",
                       model_b="finetuned", cases=None):
    """One difference per (prompt, seed). Drops pairs where either side failed."""
    index = {(r.model, r.prompt_id, r.seed): r for r in records}
    keys = sorted({(r.prompt_id, r.seed) for r in records
                   if cases is None or r.prompt_id in cases})
    diffs, used = [], []
    for prompt_id, seed in keys:
        ra = index.get((model_a, prompt_id, seed))
        rb = index.get((model_b, prompt_id, seed))
        if not (ra and rb and ra.ok and rb.ok):
            continue
        diffs.append(rb.metrics[metric] - ra.metrics[metric])
        used.append((prompt_id, seed))
    return diffs, used


def summarise(diffs, label):
    n = len(diffs)
    mean = statistics.mean(diffs)
    sd = statistics.stdev(diffs) if n > 1 else float("nan")
    se = sd / math.sqrt(n) if n > 1 else float("nan")
    lo, hi = mean - 1.96 * se, mean + 1.96 * se
    print(f"{label}")
    print(f"  n            {n}")
    print(f"  mean diff    {mean:+.4f}")
    print(f"  sd           {sd:.4f}")
    print(f"  se           {se:.4f}")
    print(f"  95% interval [{lo:+.4f}, {hi:+.4f}]")
    print(f"  excludes 0   {'YES' if lo > 0 or hi < 0 else 'no'}")
    return {"n": n, "mean": mean, "sd": sd, "se": se, "ci": (lo, hi)}


diffs, used = paired_differences(records)
paired = summarise(diffs, "PAIRED (same prompt and seed for both models)")
print(f"  in-domain effect     {TRUE_EFFECT:+.4f}")
print(f"  expected for THIS suite  {expected_pooled_effect(SUITE):+.4f}"
      "   <- composition-weighted")
print()
print("Per category, which is what you should actually report:")
for cat in ("in-domain", "near-domain", "out-of-domain"):
    ids = {c.prompt_id for c in SUITE if c.category == cat}
    d, _ = paired_differences(records, cases=ids)
    if d:
        print(f"  {cat:<14s} n={len(d):<3d} mean {statistics.mean(d):+.4f}"
              f"   expected {TRUE_EFFECT * CATEGORY_GAIN[cat]:+.4f}")
''')

nb.code('''
# The same data, compared as if the seeds had not been matched. Nothing about
# the models changed -- only how you looked at them.
base_scores = [r.metrics["structure"] for r in records
               if r.model == "base" and r.ok]
tuned_scores = [r.metrics["structure"] for r in records
                if r.model == "finetuned" and r.ok]

mean_diff = statistics.mean(tuned_scores) - statistics.mean(base_scores)
sd_pooled = math.sqrt(statistics.variance(base_scores) / len(base_scores)
                      + statistics.variance(tuned_scores) / len(tuned_scores))
lo, hi = mean_diff - 1.96 * sd_pooled, mean_diff + 1.96 * sd_pooled

print("UNPAIRED (treating the two groups as independent)")
print(f"  n per group  {len(base_scores)}")
print(f"  mean diff    {mean_diff:+.4f}")
print(f"  se           {sd_pooled:.4f}")
print(f"  95% interval [{lo:+.4f}, {hi:+.4f}]")
print(f"  excludes 0   {'YES' if lo > 0 or hi < 0 else 'no'}")
print()
print(f"paired se {paired['se']:.4f}  vs  unpaired se {sd_pooled:.4f}  "
      f"-> {sd_pooled / paired['se']:.1f}x wider")
print("Identical samples. Identical models. Different conclusion.")
''')

# ------------------------------------------------------- seed variance
nb.md("""
## Seed variance, and how many samples you need

The width of that interval is set by two things: how noisy a single sample is,
and how many samples you took. You control the second. Measure the first before
you design the experiment, not after you dislike the answer.
""")

nb.code('''
# How much does the seed alone move the metric, with the model held fixed?
per_prompt_sd = []
for case in SUITE:
    vals = [r.metrics["structure"] for r in records
            if r.model == "base" and r.prompt_id == case.prompt_id and r.ok]
    if len(vals) > 1:
        per_prompt_sd.append(statistics.stdev(vals))
        print(f"  {case.prompt_id:<14s} sd across {len(vals)} seeds: "
              f"{statistics.stdev(vals):.4f}")

seed_sd = statistics.mean(per_prompt_sd)
print()
print(f"mean seed-to-seed sd : {seed_sd:.4f}")
print(f"true effect          : {TRUE_EFFECT:.4f}")
print(f"effect / seed sd     : {TRUE_EFFECT / seed_sd:.2f}")
print()
print("A ratio below about 1 means a single before/after comparison is roughly")
print("a coin flip. Yours is above 1 here only because the fixture was built")
print("that way; a 20-iteration fine-tune will be far below it.")
''')

nb.code('''
def samples_needed(effect, sd, *, power=0.8, alpha=0.05):
    """Paired samples needed to detect `effect` given per-sample sd.

    n >= ((z_alpha/2 + z_power) * sd / effect)^2.  Normal approximation, which
    is optimistic at small n -- so treat the answer as a floor, not a target.
    """
    z_a, z_p = 1.96, 0.84            # alpha=0.05 two-sided, power=0.80
    if effect == 0:
        return float("inf")
    return math.ceil(((z_a + z_p) * sd / abs(effect)) ** 2)


paired_sd = paired["sd"]
print(f"observed paired sd : {paired_sd:.4f}")
print()
print(f"{'effect size':>12s} {'paired n needed':>16s}  interpretation")
for eff in (0.20, 0.10, 0.05, 0.02, 0.01, 0.005, 0.002):
    n = samples_needed(eff, paired_sd)
    verdict = ("trivial" if n <= 20 else "a morning" if n <= 200
               else "a day of GPU" if n <= 2000 else "not happening")
    print(f"{eff:>12.3f} {n:>16d}  {verdict}")
print()
MINUTES_PER_GENERATION = 5      # a 61-frame 256p clip on an H100. Measure yours.
n_tiny = samples_needed(0.002, paired_sd)
hours = 2 * n_tiny * MINUTES_PER_GENERATION / 60
print(f"Read the bottom rows. At {MINUTES_PER_GENERATION} minutes per real")
print(f"generation, an effect of 0.002 needs {n_tiny} paired samples — "
      f"{2 * n_tiny} generations,")
print(f"about {hours:.0f} GPU-hours. Deciding that BEFORE you run is the")
print("difference between an experiment and a hope.")
''')

nb.predict_run_explain(
    predict=(
        "Predict what happens to the confidence interval if you keep the same "
        "five prompts but raise the seed count from 4 to 16, versus keeping four "
        "seeds and raising the prompt count from 5 to 20. Both give n = 80. Will "
        "they give the same precision? Predict which is better and why."
    ),
    change=(
        "Run the cell below, which resamples the existing records to simulate "
        "both designs at matched n."
    ),
    explain=(
        "More seeds on the same prompts reduces seed variance but leaves prompt "
        "variance entirely — and generalisation across prompts is usually the "
        "claim you actually want to make. More prompts samples the thing you are "
        "generalising over. If you can only afford one, buy prompts. State which "
        "you bought, because it changes what your result is about."
    ),
    hint=(
        "Think about what each design lets you say. Sixteen seeds on five "
        "prompts supports 'on these five prompts, the fine-tune helps'. Four "
        "seeds on twenty prompts supports 'on prompts of this kind, the "
        "fine-tune helps'. Those are different claims."
    ),
)

nb.code('''
def design_precision(diffs, n_take, trials=400, rng=None):
    """Bootstrap the standard error you would see at a given sample size."""
    rng = rng or np.random.default_rng(0)
    ses = []
    for _ in range(trials):
        draw = rng.choice(diffs, size=n_take, replace=True)
        ses.append(float(np.std(draw, ddof=1) / math.sqrt(n_take)))
    return statistics.mean(ses)


print(f"{'n':>5s} {'expected se':>13s} {'95% half-width':>16s}")
for n_take in (5, 10, 20, 40, 80):
    se = design_precision(diffs, n_take)
    print(f"{n_take:>5d} {se:>13.4f} {1.96 * se:>16.4f}")

print()
print("Precision improves as 1/sqrt(n): quadrupling the samples halves the")
print("interval. That is the whole cost curve of evaluation, and it is why")
print("'run a few more' is rarely the answer -- you need four times as many.")
print()
print("What this bootstrap CANNOT tell you: whether the extra samples should be")
print("seeds or prompts. That is a question about your claim, not your data.")
''')

# ------------------------------------------------------------ leakage
nb.md("""
## Data leakage

A model that has seen an evaluation example during training will do well on it
for a reason that does not generalise. In a video fine-tune it happens three
ways, in increasing order of how easy it is to miss:

1. **The same clip in train and eval.** Obvious once you look, and it happens
   constantly when a script splits a directory listing without deduplicating.
2. **Near-duplicate frames.** Two clips from the same episode, a few seconds
   apart. Different files, different uuids, nearly the same content. A
   filename-based split will not catch this.
3. **The same caption text.** This is the one specific to Cosmos 3's generator
   dataset: the model trains on `caption_json`, which is *the same structured
   prompt format you use at inference*. If your evaluation prompts were written
   by the same captioner over the same footage, you are evaluating recall.

That third one is worth sitting with. `docs/dataset_jsonl.md` is explicit that
training on `caption_json` keeps post-training "aligned with inference" — which
is a genuine advantage for quality and a genuine hazard for evaluation, because
it makes train and eval inputs literally the same kind of object.
""")

nb.callout(
    "gotcha",
    "The leakage that catches people is never the obvious kind. Nobody puts the "
    "same file in both splits on purpose. What happens is: a clip is split into "
    "windows, the windows get different uuids, some go to train and some to val, "
    "and now your held-out set is *four seconds later in the same episode*. "
    "Cosmos 3's `t2w_windows` structure makes this the default outcome of a "
    "naive record-level split, because one clip legitimately produces several "
    "records. Split on `uuid`'s episode prefix, not on records.",
)

nb.code('''
def tokens(text, n=3):
    """Lowercased word n-grams. Crude, cheap, and enough to catch real leakage."""
    words = [w.strip(".,!?;:\\"'()").lower() for w in text.split()]
    words = [w for w in words if w]
    return {" ".join(words[i:i + n]) for i in range(max(len(words) - n + 1, 0))}


def overlap(prompt, corpus, n=3):
    """Max Jaccard-style overlap between one prompt and any training caption."""
    p = tokens(prompt, n)
    if not p:
        return 0.0, None
    best, who = 0.0, None
    for key, text in corpus.items():
        c = tokens(text, n)
        if not c:
            continue
        score = len(p & c) / len(p)
        if score > best:
            best, who = score, key
    return best, who


def leakage_report(cases, corpus, *, threshold=0.30, n=3):
    rows = []
    for case in cases:
        score, who = overlap(case.prompt, corpus, n)
        rows.append({"prompt_id": case.prompt_id, "overlap": round(score, 3),
                     "closest_training_item": who,
                     "leaked": score >= threshold})
    return rows
''')

# --------------------------------------------------------- debugging lab
nb.md("""
## Debugging lab — the flattering result

### Symptom

A colleague hands you an evaluation. Same harness, same metric, same code. Their
fine-tuned model beats the base model by a wide margin with a tight interval,
across ten prompts and four seeds. The result looks *better* than yours in every
respect. That is the symptom.
""")

nb.code('''
# Their training captions, and their evaluation suite. Read both before running.
TRAIN_CAPTIONS = {
    "clip_0001": "A robotic arm picks up a small object from a tray.",
    "clip_0002": "A robotic gripper places a block onto a table.",
    "clip_0003": "A robot arm slides a cup across a wooden counter.",
    "clip_0004": "A robotic arm sorts coloured blocks into bins.",
    "clip_0005": "A gripper lifts a metal tool from a workbench.",
}

THEIR_SUITE = [
    EvalCase("eval_a", "A robotic arm picks up a small object from a tray.",
             "in-domain"),
    EvalCase("eval_b", "A robotic gripper places a block onto a table.",
             "in-domain"),
    EvalCase("eval_c", "A robot arm slides a cup across a wooden counter.",
             "in-domain"),
    EvalCase("eval_d", "A robotic arm sorts coloured blocks into bins.",
             "in-domain"),
    EvalCase("eval_e", "A gripper lifts a metal tool from a workbench.",
             "in-domain"),
]

# Their fine-tuned model memorised the clips it trained on. Same true effect
# on everything else -- memorisation is the ONLY difference from `finetuned`.
MODELS["their_finetuned"] = dict(MODELS["finetuned"],
                                 memorised=tuple(c.prompt_id for c in THEIR_SUITE))

leaked_records = run_suite(["base", "their_finetuned"], THEIR_SUITE, SEEDS,
                           OUTPUT_DIR / "leaked")
leaked_diffs, _ = paired_differences(
    leaked_records, model_b="their_finetuned")
leaked = summarise(leaked_diffs, "THEIR RESULT (paired)")
print(f"  expected for this suite  {expected_pooled_effect(THEIR_SUITE):+.4f}"
      "   (all in-domain)")
print()
print(f"Their reported effect is "
      f"{leaked['mean'] / expected_pooled_effect(THEIR_SUITE):.1f}x the real one,")
print("with a tighter interval than yours. Both of those are symptoms.")
''')

nb.md("""
### Hypotheses

A result that is much better than yours has a short list of explanations, and
"their fine-tune was better" is only one of them:

1. **They trained longer or on more data.** Plausible, and checkable — ask.
2. **They used a different metric, or a different threshold on the same one.**
   Checkable.
3. **They dropped failures.** A harness that skips samples where generation
   errored reports the mean of the successes. Checkable: compare their sample
   count against prompts × seeds.
4. **Their evaluation set leaks.** The prompts came from the same captioner over
   the same footage as the training set, so the model is being asked to
   reproduce things it was trained to reproduce.

Hypothesis 4 is the one to check first, because it costs nothing and because it
is the one that invalidates the result rather than merely explaining it.

### Diagnostic step
""")

nb.code('''
rows = leakage_report(THEIR_SUITE, TRAIN_CAPTIONS)
print(f"{'prompt':<10s} {'overlap':>8s}  {'closest training clip':<12s} leaked?")
for r in rows:
    print(f"{r['prompt_id']:<10s} {r['overlap']:>8.2f}  "
          f"{str(r['closest_training_item']):<12s} "
          f"{'YES' if r['leaked'] else 'no'}")

n_leaked = sum(r["leaked"] for r in rows)
print()
print(f"{n_leaked} of {len(rows)} evaluation prompts overlap the training set "
      f"at >= 0.30 trigram overlap.")
print("At 1.00 overlap the prompt IS a training caption, verbatim.")
print()
print("The same check against the suite we used earlier in this lesson:")
for r in leakage_report(SUITE, TRAIN_CAPTIONS):
    print(f"  {r['prompt_id']:<14s} overlap {r['overlap']:.2f}  "
          f"{'LEAKED' if r['leaked'] else 'clean'}")
print()
print("Clean -- but notice that we did not check until now. 'Clean by")
print("construction' is a claim, and an unchecked claim is a hope.")
''')

nb.md("""
### Repair

Do not "remove the leaked prompts and re-run". That is the tempting move and it
is wrong twice over: you would be choosing your evaluation set after seeing
results, and the surviving prompts are the ones that happened to be worded
differently, not the ones that are genuinely held out.

The repair is to fix the split, at the source:

1. **Hold out clips, not prompts.** Choose evaluation clips before training and
   exclude them from the JSONL. The BridgeData2 dataset already ships a `val/`
   split for exactly this; use it rather than inventing one.
2. **Deduplicate by content, not filename.** Near-duplicate frames from the same
   episode are the case a filename split misses. A perceptual hash on the first
   frame catches most of it.
3. **Write evaluation prompts independently.** If the same captioner produced
   both, they are not independent — regardless of which clips they describe.
4. **Run the leakage check as a gate**, before the evaluation, every time. It
   costs milliseconds and it is the only thing standing between you and a result
   that is entirely explained by memorisation.
""")

nb.code('''
CLEAN_SUITE = [
    EvalCase("clean_a", "A mechanical claw transfers a cylinder between two "
             "shelves.", "in-domain", note="written independently"),
    EvalCase("clean_b", "An articulated manipulator opens a drawer and reaches "
             "inside.", "in-domain"),
    EvalCase("clean_c", "A gantry robot lowers a component onto a conveyor.",
             "in-domain"),
    EvalCase("clean_d", "A human hand stacks three wooden rings onto a peg.",
             "near-domain"),
    EvalCase("clean_e", "Waves break against rocks beneath a lighthouse.",
             "out-of-domain", note="regression check: must NOT improve"),
    EvalCase("clean_f", "Traffic moves through a city intersection at dusk.",
             "out-of-domain", note="regression check: must NOT improve"),
]

gate = leakage_report(CLEAN_SUITE, TRAIN_CAPTIONS)
worst = max(r["overlap"] for r in gate)
print(f"max overlap against the training captions: {worst:.2f}")
assert worst < 0.30, "the clean suite is not clean — rewrite the offenders"
print("gate passed — now, and only now, run the evaluation")
print()

clean_records = run_suite(["base", "their_finetuned"], CLEAN_SUITE, SEEDS,
                          OUTPUT_DIR / "clean")
clean_diffs, _ = paired_differences(clean_records, model_b="their_finetuned")
clean = summarise(clean_diffs, "THEIR MODEL, CLEAN SUITE (paired)")
print(f"  expected for this suite  {expected_pooled_effect(CLEAN_SUITE):+.4f}")
''')

nb.md("""
### Verification, and the lesson

Three things to check, in order:

1. **The clean result is close to the true effect.** It is, because the
   memorisation bonus only applied to memorised prompts. In a real setting you
   do not have a true effect to check against — which is precisely why you
   validate the harness on a fixture first.
2. **The out-of-domain prompt did not improve.** A fine-tune on robot
   manipulation that also improves lighthouse footage is telling you your metric
   is measuring something other than what you think.
3. **The gate is now part of the harness**, not a thing you remembered to do.

The general lesson is uncomfortable and worth stating plainly: **the leaked
result was not a mistake in the evaluation code.** Every line of their harness
was correct. The fault was in the *split*, which happened days earlier, in a
different file, and was invisible from inside the evaluation. Most bad results
look like this.
""")

nb.code('''
OOD = {c.prompt_id for c in CLEAN_SUITE if c.category == "out-of-domain"}
ood_diffs, _ = paired_differences(clean_records, model_b="their_finetuned",
                                  cases=OOD)
ood_change = statistics.mean(ood_diffs)
ood_base = statistics.mean([r.metrics["structure"] for r in clean_records
                            if r.model == "base"
                            and r.prompt_id in OOD and r.ok])
ood_tuned = ood_base + ood_change

print(f"Regression check ({len(OOD)} out-of-domain prompts, n={len(ood_diffs)})")
print(f"  base mean      {ood_base:.4f}")
print(f"  finetuned mean {ood_tuned:.4f}")
print(f"  paired change  {ood_change:+.4f}   "
      f"expected {TRUE_EFFECT * CATEGORY_GAIN['out-of-domain']:+.4f}")
print()
print("A fine-tune that made out-of-domain content WORSE is a trade, not an")
print("improvement. A suite with no out-of-domain prompts cannot see the")
print("difference, and will report the trade as a win.")
print()
print("Summary, same two models throughout — only the prompt list changed:")
for label, res, cases in (("leaked suite", leaked, THEIR_SUITE),
                          ("clean suite", clean, CLEAN_SUITE)):
    print(f"  {label:<14s} mean {res['mean']:+.4f}  "
          f"95% [{res['ci'][0]:+.4f}, {res['ci'][1]:+.4f}]  "
          f"expected {expected_pooled_effect(cases):+.4f}")
''')

# ------------------------------------------------------------ proxies
nb.md("""
## Proxies you will be tempted by, and what they cost

**CLIP-style similarity.** Embed the prompt and the generated frames with a
joint text-image model and take the cosine similarity. It measures *whether the
video is of the kind of thing the prompt describes*. It does not measure
physical plausibility, temporal coherence, or whether the robot's gripper
actually closed. It is also biased towards the aesthetics of its own training
distribution, so it will reward a stylised render over a realistic one. This
course does not ship it because it means another model download and another set
of pins, and because adding a number that looks authoritative to an evaluation
you have not validated makes the evaluation worse, not better.

**Reasoner-as-judge.** Ask the Cosmos 3 reasoner whether the video is
physically plausible, as in Lesson 04. Cheap, already running, and produces
something close to what you care about. The problem is **circularity**: the
reasoner and the generator are two towers of the same checkpoint. A generator
fine-tune shifts the joint distribution both towers were trained on, so the
judge is not independent of the thing it is judging. Mitigations: use a
*different* model as the judge, use a reasoner that is not from the same
checkpoint family, or restrict the judge to questions that are close to
mechanical ("is there a gripper visible in frame 40?") rather than evaluative
("is this good?").

**Frame-difference statistics** — what you implemented above. Nearly free, and
they catch the failures that matter most in practice: blank output, frozen
output, and noise. They cannot rank two working videos.

**Human viewing.** The only method that measures what you actually want, and the
one you have the least of. Spend it on what the automatic screens could not
decide, and record what you saw in the same structured record as everything
else.

No automated proxy substitutes for looking at the output. What they buy you is
the ability to look at twenty videos instead of two hundred.
""")

nb.code('''
# Optional: the same harness, pointed at real checkpoints. Gated because it
# needs a GPU, Lesson 17's export, and several minutes per sample.
from cosmos_course.specs import InferenceSpec

def cosmos_generate(model, case, seed, out_dir):
    """Drop-in replacement for `synthesise` that calls the real generator."""
    from cosmos_course.models import Generator
    ckpt = "Cosmos3-Edge" if model == "base" else str(FINETUNED_MODEL)
    spec = InferenceSpec(model_mode="text2video", name=case.prompt_id,
                         prompt=case.prompt, resolution="256",
                         aspect_ratio="1,1", num_frames=61, fps=5, seed=seed)
    result = Generator(checkpoint=ckpt).run(spec, out_dir, seed=seed)
    if not result.video_path:
        raise RuntimeError(f"no video produced: {result.diagnose()}")
    return [result.video_path]


if RUN_REAL_GENERATION and FINETUNED_MODEL.exists():
    print("Running the real comparison. Expect several minutes per sample.")
    print(f"That is {len(CLEAN_SUITE)} prompts x {len(SEEDS)} seeds x 2 models "
          f"= {len(CLEAN_SUITE) * len(SEEDS) * 2} generations.")
    real_records = run_suite(["base", "finetuned"], CLEAN_SUITE, SEEDS,
                             OUTPUT_DIR / "real", generate=cosmos_generate)
    write_records(real_records, OUTPUT_DIR / "real_records.jsonl")
    real_diffs, _ = paired_differences(real_records)
    summarise(real_diffs, "REAL: base vs fine-tuned, clean suite, paired")
else:
    print("skipped — needs COSMOS_COURSE_RUN_EVAL_GEN=1, a GPU, and a")
    print("fine-tuned export from Lesson 17.")
    print()
    print("Note what changes and what does not: `cosmos_generate` replaces")
    print("`synthesise` and NOTHING else in the harness moves. The suite, the")
    print("pairing, the leakage gate, the verification and the statistics are")
    print("identical. That is the payoff for having built it against a fixture.")
    print()
    print("You will also need `measure()` to work on video rather than PNGs.")
    print("`load_stack` is the only function to change — that is the exercise.")
''', tags=["expensive"])

# ------------------------------------------------------ closed loop
nb.md("""
## Closed-loop evaluation, and why it is not here

For an action policy, everything above is a proxy. The question you actually
care about is "does the robot complete the task", and the only way to answer it
is to let the policy act and see.

That is closed-loop evaluation: the simulator steps, the policy sees the new
observation, predicts the next action chunk, the simulator steps again. The
metric is a success rate over trials, which is the thing you would put in a
paper.

Lesson 13 covered why you cannot run it here. Briefly: it needs a second
process (a policy server plus a simulator client), a second virtualenv
(`robosuite==1.4.1`, `mujoco==2.3.7`, `torch<2.6`, none of which coexist with a
CUDA-13 torch and FlashAttention-3), and — for LIBERO specifically — a
post-trained checkpoint, because the base DCP has no action heads at all.

It also has four documented parity gotchas, every one of which is train/serve
skew and none of which raises an error: the camera concat layout must be
`agentview,wrist` at 256px, the gripper sign is flipped between sim and training
(`1 − 2·g`), simulator frames are rotated 180° relative to training frames, and
`--action-normalization quantile_rot` is mandatory. A policy that evaluates at
0% because of any one of these looks exactly like a policy that did not learn.

The honest position: **success rate in simulation is the number that matters for
a policy, this course cannot produce it, and the proxies above are not
substitutes for it.** They are what you use to decide which checkpoints are
worth the cost of a real evaluation.
""")

# ------------------------------------------------------ writing it up
nb.md("""
## Writing it up honestly

A report that claims more than the evidence supports is worse than no report,
because someone will act on it. Four sections, and the fourth is the one that
makes the other three trustworthy.

1. **Method.** What you compared, on what, at what seeds, with what metric.
   Enough that someone could rerun it.
2. **Results.** The numbers, with intervals. Including the ones you did not
   like.
3. **Threats to validity.** Leakage checks you ran, confounds you could not
   remove, ways the metric could be fooled.
4. **What this does not show.** Written as explicit sentences, not implied by
   omission. "This does not show that the improvement generalises beyond these
   five prompts." "This does not show the fine-tune helped on out-of-domain
   content; it was not tested." "This does not separate the fine-tune's effect
   from the reduced global batch it was trained under."

A null result gets exactly the same four sections. "We could not detect a
difference at n=20 with a paired standard error of 0.008, which means any real
effect is smaller than about 0.016" is a genuinely useful sentence — it bounds
the effect. "It didn't seem to help" is not.
""")

nb.code('''
def write_eval_report(path, *, method, results, threats, not_shown, records=None):
    """Assemble the report. The fourth section is not optional."""
    lines = ["# Evaluation report", "",
             "## Method", method, "",
             "## Results", results, "",
             "## Threats to validity", threats, "",
             "## What this does NOT show", not_shown, ""]
    if records:
        n_ok = sum(r.ok for r in records)
        lines += ["## Sample accounting",
                  f"- samples attempted: {len(records)}",
                  f"- passed verification: {n_ok}",
                  f"- failed: {len(records) - n_ok}  (included in the records, "
                  "excluded from paired comparisons)", ""]
    Path(path).write_text("\\n".join(lines))
    return Path(path)


report = write_eval_report(
    OUTPUT_DIR / "eval_report.md",
    method=(
        f"Paired comparison of two synthetic models on {len(CLEAN_SUITE)} "
        f"independently-written prompts at seeds {SEEDS}, metric = lag-1 "
        "spatial autocorrelation. Same seed used for both models on each "
        "prompt. Leakage gate (trigram overlap < 0.30 against training "
        "captions) run before evaluation."),
    results=(
        f"Mean paired difference {clean['mean']:+.4f} "
        f"(95% CI [{clean['ci'][0]:+.4f}, {clean['ci'][1]:+.4f}], "
        f"n={clean['n']}). Out-of-domain regression check: "
        f"{ood_change:+.4f} over {len(OOD)} prompts."),
    threats=(
        "- The metric rewards spatial smoothness and cannot distinguish "
        "coherent structure from coherent noise.\\n"
        f"- {len(CLEAN_SUITE)} prompts is a small sample of prompt space; the "
        "interval reflects sampling error, not prompt-selection error.\\n"
        "- Both models are synthetic fixtures. These numbers say nothing "
        "about any Cosmos 3 checkpoint."),
    not_shown=(
        "- Does not show that any improvement generalises beyond these "
        "prompts.\\n"
        "- Does not show that a human would prefer the output.\\n"
        "- Does not separate a model effect from a metric artefact, because "
        "only one metric was used.\\n"
        "- Does not establish anything about real Cosmos 3 fine-tuning."),
    records=clean_records,
)
print(report.read_text())
''')

# ------------------------------------------------------------ exercises
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "Run the evaluator and tabulate the result",
    goal=(
        "Produce a per-prompt table of base against fine-tuned with intervals, "
        "and say for each prompt whether the difference survives seed variance."
    ),
    instructions=(
        "1. Run `run_suite` on `CLEAN_SUITE` with at least six seeds.\n"
        "2. For each prompt separately, compute the mean paired difference, its "
        "   standard deviation across seeds, and a 95% interval.\n"
        "3. Tabulate: prompt, category, base mean, tuned mean, difference, "
        "   interval, and whether the interval excludes zero.\n"
        "4. Answer in writing: how many of the prompts show a difference "
        "   that survives seed variance? Is that number what you would expect "
        "   given the true effect and the seed noise you measured?\n"
        "5. Repeat with the `aliveness` metric instead of `structure`. Explain "
        "   why the answer changes, in terms of what each metric measures.\n\n"
        "If you have a real fine-tuned checkpoint from Lesson 17, do all of the "
        "above again with `cosmos_generate`. Expect a different — probably "
        "duller — answer."
    ),
    success=(
        "A table with one row per prompt, intervals on every difference, and a "
        "written answer to step 4 that refers to your measured seed variance "
        "rather than to intuition. You can state which metric you would report "
        "and why."
    ),
    starter='''
def per_prompt_table(records, metric="structure",
                     model_a="base", model_b="finetuned"):
    """One row per prompt: means, paired difference, interval, verdict."""
    rows = []
    for case in CLEAN_SUITE:
        d, _ = paired_differences(records, metric=metric, model_a=model_a,
                                  model_b=model_b, cases={case.prompt_id})
        # TODO: mean, sd, se, 95% interval, excludes-zero flag.
        # TODO: also record the raw means for both models, for context.
        rows.append({"prompt_id": case.prompt_id, "category": case.category})
    return rows

# TODO: run with more seeds, build the table, print it, answer steps 4 and 5.
''',
    hints=[
        "With four seeds you have four paired differences per prompt, so the "
        "per-prompt standard error is `sd / sqrt(4)` — halving the sd, not much "
        "else. Six seeds barely helps. That is the point: per-prompt intervals "
        "are wide, and pooling across prompts is what buys you precision.\n\n"
        "For step 5, `aliveness` measures temporal change and the planted effect "
        "is spatial. Expect it to show nothing, and be able to say that this is "
        "the metric behaving correctly rather than failing.",
    ],
    solution_ref="solutions/18_solutions.ipynb",
)

nb.exercise(
    "applied",
    "Does the difference survive a variance estimate?",
    goal=(
        "Add a proper variance estimate over N seeds and decide, with a stated "
        "rule fixed in advance, whether the difference is real."
    ),
    instructions=(
        "1. **Fix your decision rule before you look at anything.** Write it "
        "   down: for example, \"I will claim an improvement if the 95% paired "
        "   interval excludes zero AND the out-of-domain prompt does not also "
        "   improve.\"\n"
        "2. Sweep N from 2 to 32 seeds. At each N, compute the paired mean and "
        "   interval, and record whether your rule fires.\n"
        "3. Plot the interval half-width against N and overlay the true effect. "
        "   Identify the N at which the rule starts firing reliably.\n"
        "4. Now do the same on a model pair with **zero** true effect (copy the "
        "   base config under a new name). Sweep N and count how often your rule "
        "   fires anyway. That is your false-positive rate — it should be near "
        "   5% and you should check.\n"
        "5. Write two paragraphs: what N you would use in practice, and what "
        "   your false-positive rate means for how much you should trust a "
        "   single positive result."
    ),
    success=(
        "A decision rule written before the analysis, a plot of half-width "
        "against N, a measured false-positive rate on a null model pair, and a "
        "chosen N with a justification. If your false-positive rate is far from "
        "5%, you have found a bug in your interval and you say so."
    ),
    starter='''
MODELS["null_model"] = dict(MODELS["base"])     # identical to base: zero effect

DECISION_RULE = """
TODO: write your rule here, BEFORE running anything below.
Include the metric, the interval, and the regression check.
"""

def sweep_seeds(model_b, cases, max_seeds=32, metric="structure"):
    """For N = 2..max_seeds, return (n, mean, half_width, rule_fires)."""
    out = []
    for n in range(2, max_seeds + 1, 2):
        seeds = list(range(n))
        recs = run_suite(["base", model_b], cases, seeds,
                         OUTPUT_DIR / f"sweep_{model_b}_{n}")
        # TODO: paired_differences, summarise, evaluate DECISION_RULE
    return out

# TODO: sweep the real pair, sweep the null pair, plot, measure the
# false-positive rate, and write the two paragraphs.
''',
    hints=[
        "Generating 32 seeds × 5 prompts × 2 models × 8 frames is a few thousand "
        "small PNGs. Write them to a temporary directory and delete it between "
        "sweeps, or reuse frames in memory rather than on disk — the harness "
        "does not care where `load_stack` reads from.\n\n"
        "Your false-positive rate is measured over repeated *experiments*, not "
        "repeated samples. Run the whole null sweep many times with different "
        "base seed offsets and count how often the rule fires at your chosen N.",
    ],
    solution_ref="solutions/18_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "A complete evaluation report for your Lesson 17 fine-tune",
    goal=(
        "Produce the harness and the report you would be willing to attach your "
        "name to — including a recommendation and an explicit account of what "
        "the evidence cannot support."
    ),
    instructions=(
        "This is the module's artefact. It has four deliverables.\n\n"
        "**1. The harness.** Extend what you built here so it runs against real "
        "checkpoints: `load_stack` must read video, `measure` must work on "
        "video frames, and the leakage gate must run against the actual JSONL "
        "captions from your Lesson 16 dataset rather than a hand-written list.\n\n"
        "**2. The evaluation.** At least eight independently-written prompts "
        "across in-domain, near-domain and out-of-domain, at least four seeds, "
        "base against fine-tuned, paired, with every output verified by "
        "`cc.verify_result`. Include the failures in the record.\n\n"
        "**3. The report.** Method, results with intervals, threats to "
        "validity, what it does not show, and a **recommendation**: would you "
        "deploy this checkpoint, keep training, change the data, or stop? "
        "Justify it from your numbers.\n\n"
        "**4. The honest paragraph.** Lesson 17 trained for 20 or 100 "
        "iterations at a fraction of the shipped global batch, inside a warmup "
        "schedule that had not finished. State what that means for your "
        "conclusion. If your answer is \"I cannot distinguish this fine-tune "
        "from the base model\", that is very likely the correct answer and it "
        "belongs in the report as the headline, not as a footnote.\n\n"
        "If you have no fine-tuned checkpoint, run base-against-base at "
        "different seeds. The report is then about your harness's null "
        "behaviour, which is a genuinely useful thing to have measured before "
        "you ever get a real checkpoint."
    ),
    success=(
        "A runnable harness, a records file including failures, and a report "
        "with all four sections and a recommendation. The \"what this does not "
        "show\" section has at least four specific items. Someone who disagreed "
        "with your conclusion could check it from what you wrote."
    ),
    starter='''
# The one function that has to change to move from fixtures to real video.
def load_stack_video(path, max_frames=16):
    """Read up to `max_frames` evenly-spaced frames from a video as an array.

    cosmos_course.checks already does this internally for check_video; look at
    _read_frames there before writing your own. Reusing it means your metrics
    and your verification see the same frames, which matters more than it
    sounds -- a metric computed on different frames than the check ran on can
    disagree with it for no interesting reason.
    """
    raise NotImplementedError

# TODO: swap load_stack for load_stack_video inside measure().
# TODO: build the leakage gate from outputs/16/my_dataset/train/*.jsonl captions.
# TODO: run the suite with cosmos_generate, verify with cc.verify_result.
# TODO: write the report with write_eval_report(), all four sections.
''',
    hints=[
        "For the leakage gate against your real dataset, read each JSONL record's "
        "`t2w_windows[*].caption` (and the `temporal_caption` inside "
        "`caption_json`) into the corpus dict. Both are text the model trained "
        "on, and either can leak.\n\n"
        "For the recommendation: a defensible \"keep training\" needs you to say "
        "what you would expect to change and how you would detect it. A "
        "defensible \"stop\" needs you to say what the cost of continuing would "
        "be against the effect size you could still detect. Either is fine. "
        "\"Inconclusive\" with no next step is not.",
    ],
    solution_ref="solutions/18_solutions.ipynb",
)

# ------------------------------------------------------------ assessment
nb.md("""
## Assessment

### Knowledge check

1. Your training loss fell from 0.41 to 0.37. What are you entitled to claim?
2. Why do you fix the seed when comparing two models, and vary it when
   estimating variance? Is that a contradiction?
3. You have budget for 80 more generations. Should you add seeds or prompts?
4. Why is reasoner-as-judge circular for evaluating a Cosmos 3 generator
   fine-tune, and what would fix it?
5. An evaluation set was built by captioning the same footage the model trained
   on, but with a different captioner and different clips from the same
   episodes. Is it leaked?
6. Your harness reports a mean over successful samples only. Which model does
   that flatter, and why?
7. What does closed-loop evaluation measure that none of this lesson's metrics
   can?

Three of those have evidence sitting in the records you produced. The next cell
recomputes it. Answer from the numbers, then open the answers.
""")

nb.code('''
# Evidence for questions 2, 3 and 6, recomputed from this notebook's own
# records. Nothing new is generated here; it is all arithmetic on what you ran.

# Q6 -- who does a mean over successful samples flatter?
print("verification accounting, per model")
for model_name, model_records in by_model.items():
    failures = [r for r in model_records if not r.ok]
    print(f"  {model_name:<12s} {len(model_records):>3d} samples, "
          f"{len(failures):>2d} failed "
          f"({100 * len(failures) / len(model_records):.0f}%)")
print("  A mean over the survivors is a mean over a filtered sample, and the")
print("  filter is not the same for both models unless you have checked.")
print()

# Q2 -- what pairing bought, on identical data.
print("pairing, same samples both ways")
print(f"  paired standard error   {paired['se']:.4f}")
print(f"  unpaired standard error {sd_pooled:.4f}")
print(f"  ratio                   {sd_pooled / paired['se']:.1f}x")
print()

# Q3 -- both designs in the question reach n = 80. Price the precision.
print("bootstrapped precision from your own paired differences")
for n_take in (20, 80):
    half = 1.96 * design_precision(diffs, n_take)
    print(f"  n={n_take:<3d} expected 95% half-width {half:.4f}")
print("  The bootstrap prices precision. It cannot price the claim, and the")
print("  claim is what question 3 is actually about.")
''')

nb.answer("""
1. That **gradients flowed and the data pipeline was connected**. Nothing about
   held-out behaviour. Training loss measures fit to the batches being shown,
   and it falls for memorisation, for schedule effects and for easier batches as
   readily as it falls for learning.

2. Not a contradiction — two different jobs. **Fixed across models**, the seed
   is a control: both models face the same random draw, so the seed's
   contribution cancels in the difference and the comparison gets much tighter.
   **Varied across repeats**, the seed is the *source* of the variance you are
   trying to measure. Fixing it for the comparison and varying it for the
   estimate is exactly right.

3. **Prompts**, almost always. More seeds on the same prompts shrinks seed
   variance and leaves prompt variance untouched, so it makes you more confident
   about five prompts. More prompts samples the population you actually want to
   generalise over. The exception is when you have very few seeds and are trying
   to establish that any effect exists at all.

4. Because the reasoner and the generator are **two towers of the same
   checkpoint**. Fine-tuning the generator shifts the joint distribution both
   were trained on, so the judge is not independent of what it judges. Fixes: a
   judge from a different model family, or restricting the judge to nearly
   mechanical questions ("is a gripper visible in frame 40?") rather than
   evaluative ones.

5. **Yes.** Near-duplicate frames from the same episodes are leakage regardless
   of who wrote the captions or what the filenames are. The model has seen this
   content. Hold out **episodes**, not clips, and deduplicate by content.

6. It flatters **whichever model fails more often** — usually the one you are
   hoping to prove better, since a fine-tune that has destabilised the model
   produces more blank or degenerate output, and those are exactly the samples
   your mean quietly dropped. Record failures and report the failure rate as a
   result in its own right.

7. **Whether the task gets done.** Every metric here measures a property of the
   output. Closed-loop measures the consequence of acting on it, with the errors
   compounding as they would in reality. For an action policy it is the only
   number that answers the question you asked.
""")

nb.code('''
# The completion test below, run rather than eyeballed. Every row is checked
# against what is on disk or in memory, not against your memory of running it.
REPORT_SECTIONS = ("## Method", "## Results", "## Threats to validity",
                   "## What this does NOT show")

report_text = report.read_text() if report.exists() else ""
record_lines = (len(rec_path.read_text().strip().splitlines())
                if rec_path.exists() else 0)

completion = [
    ("records.jsonl exists", rec_path.exists()),
    ("every sample has a line in it, failures included",
     record_lines == len(records)),
    ("a leakage gate ran before the evaluation and could have failed it",
     worst < 0.30),
    ("a paired comparison with an interval",
     math.isfinite(paired["ci"][0]) and math.isfinite(paired["ci"][1])),
    ("a seed-variance estimate", seed_sd > 0.0),
    ("eval_report.md, all four sections",
     all(section in report_text for section in REPORT_SECTIONS)),
]

for label, done in completion:
    print(f"  [{'x' if done else ' '}] {label}")

print()
print(f"records.jsonl : {record_lines} lines for {len(records)} samples, "
      f"{sum(1 for r in records if not r.ok)} of them failures")
print(f"eval_report   : {report.name}, {len(report_text.splitlines())} lines")

assert all(done for _, done in completion), (
    "one of the rows above is unticked — find which, and re-run the cell that "
    "should have produced it rather than writing the artefact by hand"
)
''')

nb.md("""
### Practical completion test

That cell is the test. You have finished when `outputs/18/` contains:

- `records.jsonl` with one line per sample, failures included;
- a leakage gate that runs *before* the evaluation and can fail it;
- a paired comparison with an interval, and a seed-variance estimate;
- `eval_report.md` with all four sections, including "what this does not show".

### Summary

- **`cosmos_framework/evaluation/` is `[planned]` and absent.** No offline
  metric harness, no action-MSE script, no validation-loss loop. Verify it in
  your own checkout.
- **A held-out set is chosen before you look at results.** Swapping prompts
  after seeing an answer turns it into a training set for your judgement.
- **Falling training loss is not a better model.** After a smoke run, the honest
  claim is "gradients flowed".
- **Validate the evaluator against a known effect first.** An evaluator you have
  never calibrated is not evidence.
- **Pair on the seed.** Same seed for both models cancels the seed effect and
  shrinks the interval by several times, on identical data.
- **Precision improves as 1/√n.** Quadruple the samples to halve the interval —
  which is why "run a few more" is rarely the answer.
- **Buy prompts, not seeds**, when the claim is about generalisation.
- **Leakage is a split bug, not an evaluation bug.** It happens days earlier and
  is invisible from inside the harness, so gate for it every time.
- **The generator trains on `caption_json`, the same object you prompt with.**
  Convenient for alignment, hazardous for evaluation.
- **Every proxy is blind to something.** Write the blind spot down next to the
  metric, and never let a proxy replace looking at the output.
- **Closed-loop success rate is the number that matters for a policy**, and this
  machine cannot produce it. Say so rather than substituting a proxy silently.
- **A null result with a bound on the effect size is a real result.** "It didn't
  seem to help" is not.
""")

nb.code('''
# The summary as numbers, all of them produced by cells you ran. None of it is
# a fact about Cosmos 3 -- both "models" are fixtures -- and every line of it is
# a fact about your harness, which is the thing this lesson was about.
print(f"{'planted in-domain effect':<38s} {TRUE_EFFECT:+.4f}")
print(f"{'paired mean, first suite':<38s} {paired['mean']:+.4f}  "
      f"95% [{paired['ci'][0]:+.4f}, {paired['ci'][1]:+.4f}]")
print(f"{'paired mean, leaked suite':<38s} {leaked['mean']:+.4f}  "
      f"95% [{leaked['ci'][0]:+.4f}, {leaked['ci'][1]:+.4f}]")
print(f"{'paired mean, clean suite':<38s} {clean['mean']:+.4f}  "
      f"95% [{clean['ci'][0]:+.4f}, {clean['ci'][1]:+.4f}]")
print(f"{'out-of-domain change, clean suite':<38s} {ood_change:+.4f}")
print(f"{'seed-to-seed sd, model held fixed':<38s} {seed_sd:.4f}")
print(f"{'paired samples for an effect of 0.01':<38s} "
      f"{samples_needed(0.01, paired_sd)}")
print()
print("The two suite rows are the same two models. The headline moved because")
print("the prompt list moved, which is the least comfortable bullet above.")
''')

nb.md("""
### Common misconceptions

| Belief | Correction |
|---|---|
| "The framework will have an eval script somewhere" | It does not. `evaluation/` is `[planned]` and absent on disk. |
| "The loss curve is the evaluation" | It is a diagnostic of the training loop, measured on the training data, while training. |
| "I compared them side by side and the fine-tune was better" | At n=1 you compared two seeds. Run four and look at the spread first. |
| "More seeds is more evidence" | More evidence about the prompts you already have. It says nothing new about prompts you have not tried. |
| "My eval prompts are different sentences, so there is no leakage" | Different wording over the same footage is still leakage. Hold out episodes. |
| "The metric went up, so quality went up" | The metric went up. Every proxy here can be raised without improving anything a person would notice. |
| "A null result means I wasted the run" | A null result with an interval bounds the effect, which is information you did not have. |
| "Automatic metrics let me skip watching the videos" | They let you watch twenty instead of two hundred. |

### Suggested extensions

- Add CLIP-style prompt-video similarity as a fourth metric, then deliberately
  break it: find a prompt/video pair that scores well and is obviously wrong.
  The exercise is not adding the metric, it is finding its failure case before
  you rely on it.
- Implement a perceptual-hash near-duplicate detector over your Lesson 16
  dataset and count how many "distinct" clips are actually near-copies. On
  episode-derived data the number is usually startling.
- Build a two-alternative forced-choice viewer: show two videos side by side in
  random order, record which you prefer, and reveal the labels afterwards.
  Twenty of those is a stronger result than any metric in this notebook, and it
  takes about fifteen minutes.
""")

nb.code('''
# Five of the ten boxes in the checklist below are claims about what this
# session produced, so they can be ticked from the session rather than from
# memory. The other five are about what you can explain, and no cell can check
# those for you.
established = [
    ("built an evaluator that records failures rather than dropping them",
     f"{len(records)} records kept, "
     f"{sum(1 for r in records if not r.ok)} of them failures"),
    ("calibrated it against a known effect before trusting it",
     f"TRUE_EFFECT = {TRUE_EFFECT:+.4f}, measured on the calibration probe"),
    ("measured seed variance and computed the samples my effect needs",
     f"seed sd {seed_sd:.4f}; n = {samples_needed(0.01, paired_sd)} for 0.01"),
    ("detected and quantified leakage, and fixed the split rather than the "
     "prompt list",
     f"leaked mean {leaked['mean']:+.4f} vs clean mean {clean['mean']:+.4f}"),
    ("wrote a report with a \\"what this does not show\\" section",
     f"{report.name}, {len(report.read_text().splitlines())} lines"),
]

for claim, evidence in established:
    print(f"  [x] {claim}")
    print(f"      {evidence}")

print()
print("The remaining five are yours to tick. Read them and be honest about")
print("which of them you could explain to somebody else right now.")
''')

nb.md("""
### Mastery checklist

- [ ] I verified in my own checkout that `evaluation/` does not exist.
- [ ] I can state what a falling training loss does and does not license.
- [ ] I built an evaluator that records failures rather than dropping them.
- [ ] I calibrated it against a known effect size before trusting it.
- [ ] I can explain why pairing on the seed shrinks the interval.
- [ ] I measured seed variance and computed the samples needed for my effect.
- [ ] I detected and quantified leakage, and fixed the split rather than the
      prompt list.
- [ ] I can name the blind spot of every metric I used.
- [ ] I know what closed-loop evaluation would add and why I cannot run it.
- [ ] My report has a "what this does not show" section with specific items.

**Module 5 is complete.** You can compute what a fine-tune costs, attempt one on
hardware nobody documented it for, and tell whether it did anything. The
capstone puts all of it together.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "18_evaluation.ipynb")
