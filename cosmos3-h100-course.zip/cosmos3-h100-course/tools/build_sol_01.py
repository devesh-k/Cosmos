"""Build solutions/01_solutions.ipynb — reference answers for Lesson 01."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("01", "The Cosmos 3 mental model",
                      lesson_file="01_cosmos3_mental_model.ipynb")

nb.header(
    "Lesson 01's exercises are three different attacks on the same habit: **replace an "
    "impression with a number you can defend.** The foundation exercise turns \"the "
    "seeds look different\" into a pairwise difference matrix with a measured floor. "
    "The applied one turns `estimate_generation_cost`'s unitless numbers into a time "
    "budget calibrated on your machine. The challenge one reads a checkpoint's real "
    "identity off disk instead of trusting this course's table — and then checks the "
    "table against it."
)

nb.prelude(
    "The lesson's configuration cell, its generation configuration, and its "
    "`read_model_modes()` helper. `ALLOW_DOWNLOAD` stays `False` here, exactly as in "
    "the lesson: every cell below that would generate says what it would have done and "
    "runs its logic against synthetic inputs instead, so the reasoning is checkable "
    "without a card."
)
nb.code(setup_cell("01"))

nb.code('''
import json
import re
import shutil
import subprocess

import numpy as np

from cosmos_course.config import AUXILIARY_DOWNLOADS_GB, RESOLUTION_TIERS
from cosmos_course.measure import MeasurementLog

try:
    import torch
except ImportError:
    torch = None

# The lesson's generation configuration, unchanged. ALLOW_DOWNLOAD stays False:
# these solutions must be readable and mostly runnable with no GPU.
ALLOW_DOWNLOAD = False    # <- set True to download and generate

RESOLUTION = "256" if MODE == "reduced" else "480"
NUM_STEPS = 12 if MODE == "reduced" else 35
PROMPT = (
    "A wide, evenly lit industrial kitchen. A single-arm robot stands at a "
    "stainless steel counter holding a folded blue towel. Shallow depth of field, "
    "photographic, no text."
)

generator = cc.Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=False)
READY = ALLOW_DOWNLOAD and DEVICE == "cuda" and not framework_problems
RUN_TIMEOUT = 7200

print(f"mode={MODE}  resolution={RESOLUTION}  steps={NUM_STEPS}")
print(f"ALLOW_DOWNLOAD={ALLOW_DOWNLOAD}  device={DEVICE}  READY={READY}")
for problem in framework_problems:
    print(f"  ! {problem}")
if not READY:
    print("\\nGeneration is off. Every cell below still runs; the ones that would "
          "have generated say what they would have done.")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Three seeds, measured rather than eyeballed",
    goal="Generate the same prompt at three seeds and quantify how much they differ, "
         "instead of saying \"they look different\".",
    success="A 3x3 matrix of pairwise differences with a zero diagonal, and a written "
            "answer to the determinism question with the number that supports it.",
    approach="Separate the *metric* from the *generation*, so the metric can be tested "
             "against images whose difference is known in advance. Then the only "
             "uncertainty left when the real run happens is the model, not the "
             "measurement.",
)

nb.code('''
def image_difference(path_a, path_b):
    """Mean absolute grayscale difference, 0 = identical.

    What this metric CANNOT see:

    * **Position.** Shift an image two pixels to the right and the mean absolute
      difference jumps, even though a human would call the images identical. It
      measures per-pixel disagreement, not similarity of content. A rendering of
      the same scene from a camera 1 cm to the left scores as "very different".
    * **Colour.** `.convert("L")` throws away hue. A blue towel and an orange
      towel of the same luminance score zero difference here.
    * **Structure.** Two images of pure noise with the same mean score low
      against each other and high against a flat grey, which is backwards if
      what you care about is "does this look like a kitchen".

    It is used anyway because for THIS question — is the pipeline deterministic
    at a fixed seed — per-pixel disagreement is exactly the right question, and
    the metric's blindness to content does not matter. Choose the metric for the
    question, not for its general virtue.
    """
    from PIL import Image

    a = Image.open(path_a).convert("L")
    b = Image.open(path_b).convert("L").resize(a.size)
    return float(np.abs(np.asarray(a, float) - np.asarray(b, float)).mean())


def difference_matrix(paths_by_key):
    """Full pairwise matrix. Keys down the rows, keys across the columns."""
    keys = list(paths_by_key)
    return {a: {b: image_difference(paths_by_key[a], paths_by_key[b]) for b in keys}
            for a in keys}


def print_matrix(matrix, title="pairwise mean |difference|"):
    keys = list(matrix)
    print(title)
    print("        " + "".join(f"{str(k):>9}" for k in keys))
    for a in keys:
        print(f"{str(a):>8}" + "".join(f"{matrix[a][b]:>9.3f}" for b in keys))
''')

nb.code('''
# Test the metric before trusting it, on images whose difference is known.
# This is the part of the exercise that does not need a GPU, and it is the part
# that would otherwise silently be wrong.
import tempfile

from PIL import Image

_tmp = Path(tempfile.mkdtemp(prefix="cosmos-sol01-"))
rng = np.random.default_rng(0)

flat_a = np.full((64, 96), 100, dtype=np.uint8)
flat_b = np.full((64, 96), 130, dtype=np.uint8)      # exactly 30 greylevels apart
shifted = np.roll(flat_a, 0)                          # identical
noise = rng.integers(0, 256, (64, 96), dtype=np.uint8)

paths = {}
for name, arr in [("flat100", flat_a), ("flat130", flat_b),
                  ("flat100_copy", shifted), ("noise", noise)]:
    p = _tmp / f"{name}.png"
    Image.fromarray(arr).save(p)
    paths[name] = p

assert image_difference(paths["flat100"], paths["flat100"]) == 0.0
assert abs(image_difference(paths["flat100"], paths["flat130"]) - 30.0) < 1e-6
assert image_difference(paths["flat100"], paths["flat100_copy"]) == 0.0
print("PASS metric is 0 for identical images and exactly 30 for a 30-level offset")

# And the blindness, demonstrated rather than asserted: a two-pixel shift of a
# structured image is scored as a large difference.
edges = np.zeros((64, 96), dtype=np.uint8)
edges[:, ::8] = 255
Image.fromarray(edges).save(_tmp / "edges.png")
Image.fromarray(np.roll(edges, 2, axis=1)).save(_tmp / "edges_shift2.png")
d_shift = image_difference(_tmp / "edges.png", _tmp / "edges_shift2.png")
print(f"two-pixel shift of the same image scores {d_shift:.1f} — the metric calls "
      f"a translated copy 'very different', which is the blindness documented above")
''')

nb.code('''
SEEDS = [0, 1, 2]
seed_images = {}

if READY:
    for seed in SEEDS:
        seed_spec = cc.InferenceSpec(
            model_mode="text2image", name=f"seed_{seed}", prompt=PROMPT,
            resolution=RESOLUTION, aspect_ratio="16,9", num_frames=1,
            num_steps=NUM_STEPS, guidance=7.0, seed=seed,
        )
        # The seed goes in BOTH places. The spec field and the CLI flag are
        # separate knobs, and a mismatch between them is exactly the kind of
        # silent inconsistency this exercise is designed to surface.
        run = generator.run(seed_spec, OUTPUT_DIR / f"seed_{seed}",
                            seed=seed, timeout=RUN_TIMEOUT)
        for check in cc.verify_result(run, verbose=False):
            print(f"  {check}")
        if run.image_path:
            seed_images[seed] = run.image_path

    # The determinism re-run: seed 0 again, into a different directory.
    rerun_spec = cc.InferenceSpec(
        model_mode="text2image", name="seed_0_again", prompt=PROMPT,
        resolution=RESOLUTION, aspect_ratio="16,9", num_frames=1,
        num_steps=NUM_STEPS, guidance=7.0, seed=0,
    )
    rerun = generator.run(rerun_spec, OUTPUT_DIR / "seed_0_again",
                          seed=0, timeout=RUN_TIMEOUT)
    if rerun.image_path:
        seed_images["0 (rerun)"] = rerun.image_path
else:
    print("Generation skipped (ALLOW_DOWNLOAD is False). What would have happened:")
    print(f"  4 runs of text2image at {RESOLUTION}p, {NUM_STEPS} steps: seeds "
          f"{SEEDS} plus a repeat of seed 0.")
    print(f"  Relative cost of each: "
          f"{cc.estimate_generation_cost(num_frames=1, resolution=RESOLUTION, num_steps=NUM_STEPS, model=MODEL)['cost_units']:,} units.")
    print("  The matrix cell below reports what it needs and does not fail.")
''')

nb.code('''
if len(seed_images) >= 2:
    matrix = difference_matrix(seed_images)
    print_matrix(matrix)
    diagonal = [matrix[k][k] for k in matrix]
    assert all(d == 0.0 for d in diagonal), diagonal
    print("\\nzero diagonal confirmed — an image compared with itself scores 0.0, "
          "which is the floor every other number is read against")

    if "0 (rerun)" in matrix and 0 in matrix:
        repeat = matrix[0]["0 (rerun)"]
        across = [matrix[a][b] for a in SEEDS for b in SEEDS if a != b]
        print(f"\\nseed 0 vs seed 0 re-run : {repeat:.4f}")
        print(f"different seeds, range  : {min(across):.3f} to {max(across):.3f}")
        if repeat == 0.0:
            print("VERDICT: bit-identical. The pipeline is deterministic at a fixed "
                  "seed on this machine.")
        elif repeat < 0.01 * max(across):
            print("VERDICT: not bit-identical, but the repeat difference is under 1% "
                  "of the between-seed difference. Non-determinism exists and is "
                  "negligible for anything this course measures. The usual cause is "
                  "non-deterministic reduction order in attention kernels.")
        else:
            print("VERDICT: the repeat differs materially. Before blaming the model, "
                  "check that the seed really reached the sampler — print the spec "
                  "the framework received, not the one you wrote.")
else:
    print("No generated images available, so no matrix. The exercise's numeric "
          "answer needs a GPU; the metric it depends on was verified above.")
    print()
    print("Determinism, stated as a prediction to be checked rather than a fact: "
          "the expected result is a repeat difference of exactly 0.0, because the "
          "sampler is seeded and the weights are fixed. A small non-zero value is "
          "still consistent with a correct pipeline — attention kernels can reduce "
          "in a non-deterministic order — and the way to tell 'small' from "
          "'meaningful' is the ratio to the between-seed differences, not the "
          "absolute number. Record what you actually get.")
''')

nb.why(
    "**Why the metric is tested separately from the generation.** The generation costs "
    "GPU minutes and a download; the metric costs nothing. If you write both and run "
    "them together, a bug in the metric looks like a surprising result from the model, "
    "and you will spend the next hour on the wrong half. Testing `image_difference` "
    "against a pair of flat images whose difference is *exactly 30 by construction* "
    "means that when the real matrix comes back strange, the metric is not a suspect.\n\n"
    "**Why the self-comparison floor matters more than it looks.** The exercise asks "
    "for it and the reason is subtle: a difference metric has no natural scale. \"The "
    "seeds differ by 18.4\" means nothing on its own. It only becomes a statement once "
    "you know that identical images score 0 and that different seeds score 15–25 on "
    "this prompt at this resolution. The diagonal establishes one end of that scale, "
    "and the re-run establishes the interesting question: is the repeat closer to the "
    "diagonal or to the off-diagonal?\n\n"
    "**Why the determinism verdict is expressed as a ratio.** The hint makes this point "
    "and it generalises well beyond this exercise. A repeat difference of 0.003 proves "
    "nothing by itself. Compared against a between-seed difference of 20, it says the "
    "non-determinism is four orders of magnitude below the signal and can be ignored. "
    "Compared against a between-seed difference of 0.004, it says your seeds are not "
    "reaching the sampler at all. Same number, opposite conclusions — which is why the "
    "code computes the comparison instead of thresholding on an absolute value.\n\n"
    "**The alternative metric that was rejected.** SSIM or LPIPS would be less blind to "
    "translation and closer to human judgement, and for \"do these two images look "
    "alike\" they are better tools. They were rejected here for two reasons: they add a "
    "dependency (`scikit-image` or a pretrained network) to a lesson whose point is the "
    "mental model rather than the tooling, and — more importantly — a perceptual metric "
    "is *worse* for the determinism question, because it is designed to be insensitive "
    "to exactly the small numeric differences you are trying to detect. If your answer "
    "used SSIM for the seed comparison and mean-absolute-difference for the determinism "
    "check, that is a better answer than this one."
)

nb.extend(
    "The natural extension is to ask *what* differs between seeds, not just how much. "
    "Take the per-pixel absolute difference array rather than its mean, and look at "
    "where the mass is. If the differences concentrate on one object, the seed is "
    "changing that object's identity; if they are spread uniformly, the seed is "
    "changing texture and lighting everywhere. That distinction tells you whether the "
    "prompt is under-specified about a particular thing — which is directly actionable "
    "in a way that a scalar is not, and is the same diagnostic you will want in Lesson "
    "08 when a control hint fails to constrain what you expected it to."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "The largest job that fits a time budget",
    goal="Write `largest_that_fits(seconds)` choosing the resolution, frame count and "
         "step count that make the most of a stated time budget on this machine — "
         "calibrated by one measured run rather than assumed.",
    success="`largest_that_fits(600)` returns a configuration whose predicted time is "
            "under ten minutes, the ranking rule is written down, and you can name the "
            "biggest source of error in the prediction.",
    approach="Fit `seconds = fixed + units / rate` when there are two or more "
             "measurements at different costs, fall back to a stated upper bound when "
             "there is only one, and rank on **pixel-seconds of delivered video** — "
             "with the argument for that choice spelled out below.",
)

nb.code('''
measurements = cc.MeasurementLog(OUTPUT_DIR / "measurements.jsonl").load()
print(f"{len(measurements)} measurement(s) available from your own runs")


def _cost_of(record, model=None):
    """Rebuild a record's cost_units from the fields the lesson logged."""
    return cc.estimate_generation_cost(
        num_frames=int(record.get("num_frames", 1)),
        resolution=str(record.get("resolution", "480")),
        num_steps=int(record.get("num_steps", 35)),
        aspect_ratio=record.get("aspect_ratio", "16,9"),
        model=record.get("model", model or MODEL),
    )["cost_units"]


def calibrate_units_per_second(records, model=None):
    """Derive units-per-second for this machine from measured runs.

    Returns (rate, fixed_seconds, provenance). `rate` is None when there is
    nothing to calibrate from.

    The problem the exercise points at: a measured `seconds` contains weight
    loading, which is a large fixed cost and is NOT proportional to cost units.
    Dividing units by seconds therefore understates the machine's throughput,
    and understates it worst on the cheapest run.

    Two measurements at different costs let you separate the two terms with a
    straight line: seconds = fixed + units / rate. One measurement does not, so
    with one we set fixed = 0 and say so — the resulting rate is a LOWER bound
    on throughput, hence the predicted times are an UPPER bound, which is the
    safe direction to be wrong in when you are answering "will this fit".
    """
    usable = []
    for r in records:
        secs = r.get("seconds")
        if not isinstance(secs, (int, float)) or secs <= 0:
            continue
        try:
            usable.append((float(_cost_of(r, model)), float(secs)))
        except Exception:
            continue
    if not usable:
        return None, 0.0, "no usable measurements"
    if len(usable) == 1:
        units, secs = usable[0]
        return units / secs, 0.0, ("one measurement; weight loading is folded into "
                                   "the rate, so this is a lower bound on throughput "
                                   "and predictions are upper bounds on time")
    # Least-squares line through (units, seconds). slope = 1/rate.
    xs = np.array([u for u, _ in usable])
    ys = np.array([s for _, s in usable])
    if float(xs.max() - xs.min()) < 1e-9:
        return float(xs.mean() / ys.mean()), 0.0, ("all measurements have the same "
                                                   "cost; cannot separate the fixed "
                                                   "term")
    slope, intercept = np.polyfit(xs, ys, 1)
    if slope <= 0:
        return float(xs.sum() / ys.sum()), 0.0, "degenerate fit; fell back to the ratio"
    return (float(1.0 / slope), float(max(intercept, 0.0)),
            f"{len(usable)} measurements, fitted seconds = fixed + units/rate")
''')

nb.code('''
def largest_that_fits(seconds, model=None, units_per_second=None, fixed_seconds=0.0,
                      frame_choices=(1, 61, 121, 189), step_choices=(12, 20, 35, 50)):
    """Best configuration that should finish within `seconds`.

    RANKING RULE, stated as the exercise requires: candidates are ranked by
    **pixel-seconds of delivered video** — width * height * num_frames / fps —
    with cost units as the tie-break, preferring the CHEAPER of two candidates
    that deliver the same output.

    Why that and not the alternatives:

    * Not `cost_units`, because cost includes `num_steps`, and steps are effort
      spent, not output delivered. Ranking by cost rewards a configuration for
      being slow, which inverts the question.
    * Not raw pixel count, because it ignores duration: a single 768p frame
      would beat five seconds of 480p video, which is not what anyone asking
      "the largest job that fits" means.
    * Not `num_frames`, because it ignores resolution the same way.

    Pixel-seconds is the amount of *watchable output*, and that is the thing the
    budget is being spent to produce. It is still a choice, not a truth: if you
    are generating a still for a poster, rank by pixels and ignore duration.
    """
    model = model or MODEL
    tier = cc.MODEL_TIERS[model]
    if units_per_second is None:
        return None
    candidates = []
    for resolution in RESOLUTION_TIERS:
        if int(resolution) > int(tier["max_resolution_tier"]):
            continue
        low, high = tier["frames_range"]
        for frames in frame_choices:
            if not (low <= frames <= high):
                continue
            if frames > cc.MAX_FRAMES_BY_TIER.get(resolution, high):
                continue
            for steps in step_choices:
                est = cc.estimate_generation_cost(
                    num_frames=frames, resolution=resolution, num_steps=steps,
                    model=model)
                predicted = fixed_seconds + est["cost_units"] / units_per_second
                if predicted > seconds:
                    continue
                w, h = cc.resolution_wh(resolution)
                fps = tier["fps_range"][0]
                pixel_seconds = w * h * frames / fps
                candidates.append({
                    "model": model, "resolution": resolution, "num_frames": frames,
                    "num_steps": steps, "predicted_seconds": round(predicted, 1),
                    "cost_units": est["cost_units"],
                    "pixel_seconds": round(pixel_seconds), "width": w, "height": h,
                })
    # Best output first; among equal output, cheapest first.
    candidates.sort(key=lambda c: (-c["pixel_seconds"], c["cost_units"]))
    return candidates[0] if candidates else None
''')

nb.code('''
# Calibrate from your own log if it has anything in it; otherwise from two
# clearly-labelled PLACEHOLDER records so the logic is still exercised.
#
# THESE NUMBERS ARE NOT MEASUREMENTS. They are two invented points chosen only
# to make the arithmetic run. Replace them by running Lesson 01's generation
# section, which writes real records to outputs/01/measurements.jsonl.
PLACEHOLDER_RECORDS = [
    {"label": "PLACEHOLDER — replace with your own run", "seconds": 100.0,
     "resolution": "256", "num_frames": 1, "num_steps": 12, "model": MODEL},
    {"label": "PLACEHOLDER — replace with your own run", "seconds": 340.0,
     "resolution": "480", "num_frames": 1, "num_steps": 35, "model": MODEL},
]

using_placeholders = len(measurements) < 1
records = measurements if not using_placeholders else PLACEHOLDER_RECORDS
rate, fixed, provenance = calibrate_units_per_second(records)

print("calibration source :", "your measurements.jsonl" if not using_placeholders
      else "PLACEHOLDER numbers — not measured, replace them")
print("provenance         :", provenance)
print(f"units per second   : {rate:,.0f}" if rate else "units per second   : None")
print(f"fixed overhead (s) : {fixed:.1f}")

winner = largest_that_fits(600, units_per_second=rate, fixed_seconds=fixed)
print()
print("largest_that_fits(600) ->")
for k, v in (winner or {}).items():
    print(f"    {k:<18} {v}")

if winner:
    assert winner["predicted_seconds"] <= 600, winner
    print("\\nPASS predicted time is inside the ten-minute budget")
    if using_placeholders:
        print("      ...but predicted from placeholder numbers, so the CONFIGURATION "
              "is real and the TIME is not. Re-run after Lesson 01's generation "
              "section to get a number that means something.")
''')

nb.code('''
# The calibration logic is the part worth checking, and it can be checked
# exactly: manufacture records from a known rate and fixed cost, then see
# whether the fit recovers them.
TRUE_RATE = 5000.0        # units per second
TRUE_FIXED = 60.0         # seconds of weight loading

synthetic = []
for res, frames, steps in [("256", 1, 12), ("480", 1, 35), ("480", 61, 35)]:
    units = cc.estimate_generation_cost(num_frames=frames, resolution=res,
                                        num_steps=steps, model=MODEL)["cost_units"]
    synthetic.append({"seconds": TRUE_FIXED + units / TRUE_RATE, "resolution": res,
                      "num_frames": frames, "num_steps": steps, "model": MODEL})

r, f, prov = calibrate_units_per_second(synthetic)
print(f"recovered rate  {r:,.1f}  (true {TRUE_RATE:,.1f})")
print(f"recovered fixed {f:,.1f}s (true {TRUE_FIXED:,.1f}s)")
assert abs(r - TRUE_RATE) / TRUE_RATE < 0.01, r
assert abs(f - TRUE_FIXED) < 1.0, f
print("PASS the two-term fit recovers both the rate and the fixed overhead")

# And the single-measurement path, which must be conservative rather than wrong.
r1, f1, prov1 = calibrate_units_per_second(synthetic[:1])
print(f"\\nsingle measurement -> rate {r1:,.1f}, fixed {f1:.1f}s")
print(f"  {prov1}")
assert r1 < TRUE_RATE, "folding fixed cost into the rate must UNDERSTATE throughput"
print("PASS one measurement understates throughput, so predicted times are upper "
      "bounds — the safe direction for a 'will it fit' question")
''')

nb.model_answer(
    "**The biggest source of error in the prediction, and it is not the fit.**\n\n"
    "The fit above recovers a synthetic rate to within 1%, which makes it tempting to "
    "believe the predicted seconds to within 1%. It is not that good, and the dominant "
    "error is *the assumption that cost units are proportional to time at all*.\n\n"
    "`estimate_generation_cost` computes latent tokens times steps. That is proportional "
    "to the number of transformer forward passes, which is the right first-order model. "
    "It is wrong in three ways that matter on one H100:\n\n"
    "1. **Attention is quadratic in sequence length, and the cost model is linear.** "
    "Doubling the frame count at fixed resolution roughly doubles the token count and "
    "therefore doubles the estimate — but quadruples the attention term. A rate "
    "calibrated on a 1-frame run will badly under-predict a 121-frame run. This is the "
    "single largest error, and it is systematic rather than noisy, which makes it worse: "
    "it does not average out.\n"
    "2. **The fixed term is not actually fixed.** Weight loading depends on whether the "
    "checkpoint is in the page cache. The first run after a reboot pays disk; the "
    "second pays memcpy. Fitting one `fixed` across both gives a number that describes "
    "neither.\n"
    "3. **It ignores everything that is not the denoiser** — VAE decode, guardrail "
    "passes, and writing the file. These scale with output size rather than with steps, "
    "so a low-step run is proportionally more overhead than the model admits.\n\n"
    "**What follows practically.** Calibrate on a run whose *shape* resembles the job "
    "you are predicting: use a video measurement to predict video, not an image one. "
    "And treat the prediction as an order-of-magnitude gate — good for \"is this ten "
    "minutes or two hours\", not for \"is this 9 minutes or 11\". Lesson 14 replaces "
    "this whole approach with direct measurement for exactly that reason. The value of "
    "this exercise is not the estimator; it is knowing precisely why the estimator is "
    "not to be trusted, which is what stops you from quoting it later as though it were "
    "a measurement."
)

nb.extend(
    "Add the quadratic term. `estimate_generation_cost` exposes `latent_tokens`, so "
    "fitting `seconds = fixed + a * tokens * steps + b * tokens**2 * steps` needs three "
    "measurements instead of two and would capture the attention scaling that dominates "
    "the error above. The reason not to reach for it immediately: with three noisy "
    "points and three free parameters you will fit the noise perfectly and predict "
    "nothing. Get five or six measurements across a real spread of frame counts first, "
    "then fit — and check the fitted `b` against the sequence lengths where you would "
    "expect attention to start dominating."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "A model card reader with no hard-coded facts",
    goal="Build `read_model_card(repo_or_path)` reporting a checkpoint's tier, active "
         "and total parameter counts, supported modes and whether this machine can run "
         "it — read from the local checkpoint and the installed framework, with no "
         "facts hard-coded from this course.",
    success="`read_model_card(\"nvidia/Cosmos3-Edge\")` returns a dict with the six "
            "fields, every value traceable to a file on disk or a `torch` call, and the "
            "comparison against `cc.MODEL_TIERS` printed with any disagreement "
            "explained.",
    approach="Read the safetensors index for total size, sum the shard header shapes "
             "for a real parameter count, infer the active count from the tower naming "
             "convention the SFT recipes select on — and return `None` with a reason "
             "wherever the evidence does not support an answer.",
)

nb.code('''
def read_model_modes():
    """Return (modes, source). Tries three strategies; never raises.

    Unchanged from the lesson — this is the "read it from the installed
    framework" half of the exercise, and reusing it is the point.
    """
    try:
        from cosmos_framework.inference.args import ModelMode

        return sorted(m.value for m in ModelMode), "imported in this kernel"
    except Exception:
        pass

    venv_python = cc.COSMOS3_REPO / ".venv" / "bin" / "python"
    snippet = ("import json; from cosmos_framework.inference.args import ModelMode; "
               "print(json.dumps(sorted(m.value for m in ModelMode)))")
    if venv_python.exists():
        try:
            done = subprocess.run([str(venv_python), "-c", snippet],
                                  cwd=str(cc.COSMOS3_REPO), capture_output=True,
                                  text=True, timeout=180, check=True)
            return json.loads(done.stdout.strip().splitlines()[-1]), "framework venv subprocess"
        except Exception:
            pass

    source = cc.COSMOS3_REPO / "cosmos_framework" / "inference" / "args.py"
    if source.exists():
        text = source.read_text(errors="replace")
        block = re.search(r"class\\s+ModelMode\\s*\\([^)]*\\)\\s*:(.*?)(?=\\nclass\\s|\\Z)",
                          text, re.S)
        if block:
            found = re.findall(r"^\\s+[A-Z][A-Z0-9_]*\\s*=\\s*[\\"\\']([a-z0-9_]+)[\\"\\']",
                               block.group(1), re.M)
            if found:
                return sorted(set(found)), f"parsed {source.name}"
    return [], "could not read the enum from this machine"


checkout_modes, mode_source = read_model_modes()
print(f"modes from: {mode_source}")
print(f"  {checkout_modes or '(none readable on this machine)'}")
''')

nb.code('''
def find_local_checkpoint(repo_id):
    """Return the snapshot directory for a cached HF repo, or None.

    The layout is models--<org>--<name>/snapshots/<sha>/, and the exercise says
    not to assume a layout you have not checked — so this VERIFIES rather than
    assumes: it requires the directory to exist AND to contain a config.json,
    and it picks the newest snapshot when there are several, because a repo
    updated in place leaves the old revision behind.
    """
    hf_home = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface"))
    org, _, name = repo_id.partition("/")
    if not name:
        org, name = "nvidia", org
    repo_dir = hf_home / "hub" / f"models--{org}--{name}"
    snapshots = repo_dir / "snapshots"
    if not snapshots.is_dir():
        return None
    candidates = [d for d in snapshots.iterdir()
                  if d.is_dir() and (d / "config.json").exists()]
    if not candidates:
        return None
    return max(candidates, key=lambda d: d.stat().st_mtime)


_DTYPE_BYTES = {"float32": 4, "float16": 2, "bfloat16": 2, "float8_e4m3fn": 1,
                "float8_e5m2": 1, "int8": 1, "uint8": 1, "int64": 8, "int32": 4,
                "F32": 4, "F16": 2, "BF16": 2, "F8_E4M3": 1, "F8_E5M2": 1,
                "I64": 8, "I32": 4, "I8": 1, "U8": 1, "BOOL": 1}


def _safetensors_header(path):
    """Read a .safetensors file's JSON header without loading a single weight.

    The format is: 8 bytes little-endian header length, then that many bytes of
    UTF-8 JSON, then the tensor data. Reading the header alone is a few
    kilobytes of IO for a file that may be tens of gigabytes.
    """
    with open(path, "rb") as fh:
        n = int.from_bytes(fh.read(8), "little")
        return json.loads(fh.read(n).decode("utf-8"))
''')

nb.code('''
# The active-count convention. The SFT recipes select generator-tower parameters
# with `optimizer.keys_to_select = ["moe_gen", ...]` (COSMOS3_FACTS.md section 5),
# so a parameter name containing one of these markers belongs to that tower.
# THIS IS THE ASSUMPTION MOST LIKELY TO BREAK on a future release, and the
# reader records it in `notes` rather than burying it.
TOWER_MARKERS = {
    "generator": ("moe_gen", "vae2llm", "llm2vae", "time_embedder"),
    "reasoner": ("moe_und", "_und_", "vision_tower", "visual"),
}


def read_model_card(repo_id):
    """Report what a local checkpoint actually is. No hard-coded course facts."""
    card = {
        "repo_id": repo_id,
        "local_path": None,
        "disk_gb": None,
        "params_total_b": None,
        "params_active_b": None,      # None with a reason is a valid answer
        "supported_modes": [],
        "runnable_here": None,
        "notes": [],
    }

    card["supported_modes"], mode_src = read_model_modes()
    card["notes"].append(f"modes: {mode_src}")

    path = Path(repo_id) if Path(repo_id).is_dir() else find_local_checkpoint(repo_id)
    if path is None:
        card["notes"].append(
            "checkpoint is not in the local HF cache, so every weight-derived field "
            "is None. That is the honest answer: nothing here is guessed from the "
            "repo name.")
        return card
    card["local_path"] = str(path)

    config_path = path / "config.json"
    config = json.loads(config_path.read_text()) if config_path.exists() else {}
    dtype = (config.get("torch_dtype") or config.get("dtype")
             or (config.get("text_config") or {}).get("torch_dtype"))
    card["notes"].append(f"config.json torch_dtype: {dtype!r}")

    # ---- on-disk size -----------------------------------------------------
    index_path = path / "model.safetensors.index.json"
    index = json.loads(index_path.read_text()) if index_path.exists() else None
    if index and "total_size" in (index.get("metadata") or {}):
        card["disk_gb"] = index["metadata"]["total_size"] / 1e9
        card["notes"].append("disk_gb from index metadata.total_size")
    else:
        total = 0
        for shard in sorted(path.glob("*.safetensors")):
            try:
                total += shard.stat().st_size
            except OSError:
                continue
        if total:
            card["disk_gb"] = total / 1e9
            card["notes"].append("disk_gb summed from shard file sizes (no index)")

    # ---- parameter counts -------------------------------------------------
    # Preferred route: sum the products of the tensor shapes from the shard
    # headers. That is an exact count and is dtype-independent, which matters
    # because a checkpoint can mix dtypes and bytes/total_size cannot.
    shards = sorted(path.glob("*.safetensors"))
    per_tensor = {}
    dtypes_seen = set()
    for shard in shards:
        try:
            header = _safetensors_header(shard)
        except Exception as exc:
            card["notes"].append(f"could not read header of {shard.name}: {exc}")
            continue
        for name, meta in header.items():
            if name == "__metadata__" or "shape" not in meta:
                continue
            count = 1
            for dim in meta["shape"]:
                count *= int(dim)
            per_tensor[name] = count
            dtypes_seen.add(meta.get("dtype", "?"))

    if per_tensor:
        card["params_total_b"] = sum(per_tensor.values()) / 1e9
        card["notes"].append(
            f"params_total_b summed from {len(per_tensor)} tensor shapes across "
            f"{len(shards)} shard(s) — exact, not derived from bytes")
        if len(dtypes_seen) > 1:
            card["notes"].append(
                f"checkpoint MIXES dtypes {sorted(dtypes_seen)}; any bytes-per-param "
                f"figure would be an average and is not reported")
    elif card["disk_gb"] and dtype in _DTYPE_BYTES:
        bpp = _DTYPE_BYTES[dtype]
        card["params_total_b"] = card["disk_gb"] * 1e9 / bpp / 1e9
        card["notes"].append(
            f"params_total_b DERIVED from bytes / {bpp} bytes-per-param ({dtype}); "
            f"less trustworthy than a shape sum")

    # ---- active count -----------------------------------------------------
    if per_tensor:
        buckets = {tower: 0 for tower in TOWER_MARKERS}
        unassigned = 0
        for name, count in per_tensor.items():
            for tower, markers in TOWER_MARKERS.items():
                if any(marker in name for marker in markers):
                    buckets[tower] += count
                    break
            else:
                unassigned += count
        assigned = sum(buckets.values())
        if assigned and assigned > 0.05 * sum(per_tensor.values()):
            # Shared parameters (embeddings, norms) flow through both towers, so
            # one tower's active count is its own parameters plus the shared ones.
            largest_tower = max(buckets, key=buckets.get)
            card["params_active_b"] = (buckets[largest_tower] + unassigned) / 1e9
            card["notes"].append(
                f"params_active_b = largest tower ({largest_tower}: "
                f"{buckets[largest_tower] / 1e9:.2f}B) + shared/unassigned "
                f"({unassigned / 1e9:.2f}B). Convention: parameter names carry a "
                f"tower marker, which is how the SFT recipes select them. If a "
                f"future release renames those markers this number becomes wrong "
                f"silently — check TOWER_MARKERS against the checkpoint's actual "
                f"names before believing it.")
        else:
            card["notes"].append(
                "params_active_b is None: no tower markers matched, so this looks "
                "like a dense checkpoint (active == total) OR the naming convention "
                "changed. Cannot tell those apart from the names alone, and an "
                "honest None beats a confident guess.")

    # ---- runnable here ----------------------------------------------------
    if torch is not None and torch.cuda.is_available():
        card_gb = torch.cuda.get_device_properties(0).total_memory / 1e9
        active = card["params_active_b"] or card["params_total_b"]
        if active is not None:
            need = active * 2.0 + 8.0     # bf16 weights, plus working room
            card["runnable_here"] = bool(need < card_gb)
            card["notes"].append(
                f"runnable_here: {active:.1f}B active x 2 bytes + 8 GB working room "
                f"= {need:.1f} GB against a {card_gb:.1f} GB card")
    else:
        card["notes"].append("runnable_here is None: no CUDA device to measure against")
    return card
''')

nb.code('''
card = read_model_card(f"nvidia/{MODEL}")
print(json.dumps(card, indent=2, default=str))

print()
expected = cc.MODEL_TIERS.get(MODEL, {})
for field in ("params_total_b", "params_active_b", "download_gb"):
    print(f"  course table {field:<18} = {expected.get(field)}")

# The comparison the exercise asks for. Note the direction of suspicion: when
# these disagree, the reader is checked FIRST, because the course table was
# copied from a model card and the reader was written by us.
print()
pairs = [("params_total_b", "params_total_b", 0.05),
         ("params_active_b", "params_active_b", 0.10),
         ("disk_gb", "download_gb", 0.15)]
if card["local_path"] is None:
    print("No local checkpoint, so nothing to compare. Run Lesson 01's generation "
          "section (ALLOW_DOWNLOAD = True) to populate the cache, then re-run this.")
else:
    for mine, theirs, tol in pairs:
        a, b = card.get(mine), expected.get(theirs)
        if a is None or b is None:
            print(f"  {mine:<16} not comparable (mine={a}, table={b})")
            continue
        agree = abs(a - b) <= tol * max(abs(b), 1e-9)
        verdict = "agree" if agree else "DISAGREE"
        print(f"  {mine:<16} mine={a:>8.2f}  table={b:>8.2f}  {verdict}")
        if not agree:
            print(f"      Before assuming the table is wrong: is your count including "
                  f"buffers and non-parameter tensors? Is the table quoting the "
                  f"marketing number (8B/32B active) rather than the safetensors "
                  f"total (16B/64B)? COSMOS3_FACTS.md section 1 says BOTH are correct "
                  f"and explains which is which.")
''')

nb.code('''
# The reader can be exercised without a 9 GB download, by building a checkpoint
# whose answers are known by construction. This is the only way to know the
# tower-splitting logic is right rather than merely plausible.
import struct

fake = Path(tempfile.mkdtemp(prefix="cosmos-sol01-ckpt-")) / "snapshot"
fake.mkdir(parents=True)
(fake / "config.json").write_text(json.dumps({"torch_dtype": "bfloat16"}))


def write_fake_safetensors(path, tensors):
    """Write a real safetensors file whose header we control. dtype BF16."""
    header, offset = {}, 0
    for name, shape in tensors.items():
        n = 1
        for d in shape:
            n *= d
        header[name] = {"dtype": "BF16", "shape": list(shape),
                        "data_offsets": [offset, offset + n * 2]}
        offset += n * 2
    blob = json.dumps(header).encode("utf-8")
    with open(path, "wb") as fh:
        fh.write(struct.pack("<Q", len(blob)))
        fh.write(blob)
        fh.write(b"\\x00" * offset)


# 1000 + 2000 + 500 parameters: a generator tower, a reasoner tower, and shared.
write_fake_safetensors(fake / "model-00001-of-00001.safetensors", {
    "layers.0.moe_gen.q_proj.weight": (20, 50),        # 1000  generator
    "layers.0.moe_und.q_proj.weight": (40, 50),        # 2000  reasoner
    "embed_tokens.weight": (10, 50),                   #  500  shared
})
(fake / "model.safetensors.index.json").write_text(json.dumps({
    "metadata": {"total_size": 7000},
    "weight_map": {"layers.0.moe_gen.q_proj.weight": "model-00001-of-00001.safetensors"},
}))

fake_card = read_model_card(str(fake))
total_params = fake_card["params_total_b"] * 1e9
active_params = fake_card["params_active_b"] * 1e9
print(f"total  : {total_params:,.0f}  (expected 3,500)")
print(f"active : {active_params:,.0f}  (expected 2,500 = reasoner 2,000 + shared 500)")
assert abs(total_params - 3500) < 1, total_params
assert abs(active_params - 2500) < 1, active_params
assert abs(fake_card["disk_gb"] * 1e9 - 7000) < 1, fake_card["disk_gb"]
print("PASS shape-sum total, tower-split active count, and index total_size all correct")

for note in fake_card["notes"]:
    print(f"  note: {note}")
''')

nb.code('''
# And the honest-None path: a dense checkpoint with no tower markers must NOT
# get an invented active count.
dense = Path(tempfile.mkdtemp(prefix="cosmos-sol01-dense-")) / "snapshot"
dense.mkdir(parents=True)
(dense / "config.json").write_text(json.dumps({"torch_dtype": "bfloat16"}))
write_fake_safetensors(dense / "model.safetensors", {
    "layers.0.attn.q_proj.weight": (30, 50),
    "layers.0.attn.k_proj.weight": (30, 50),
})
dense_card = read_model_card(str(dense))
assert dense_card["params_total_b"] * 1e9 == 3000, dense_card["params_total_b"]
assert dense_card["params_active_b"] is None, dense_card["params_active_b"]
print("PASS a checkpoint with no tower markers returns params_active_b=None "
      "with a stated reason rather than a guess:")
print("     " + [n for n in dense_card["notes"] if "params_active_b is None" in n][0])

shutil.rmtree(fake.parent, ignore_errors=True)
shutil.rmtree(dense.parent, ignore_errors=True)
shutil.rmtree(_tmp, ignore_errors=True)
''')

nb.why(
    "**Why shapes and not bytes.** `metadata.total_size` divided by two is the obvious "
    "route to a parameter count and it is wrong often enough to matter. It counts every "
    "byte in the file, including buffers, non-parameter tensors and any tensor stored "
    "at a different dtype — and Cosmos checkpoints are exactly the kind that mix "
    "dtypes. Summing the products of the shapes in the safetensors headers is an exact "
    "count, dtype-independent, and costs a few kilobytes of IO because the header is at "
    "the front of the file. The bytes route is kept as a fallback and *labelled as "
    "derived* in `notes`, so a reader can see which number they got.\n\n"
    "**Why the active count is the hard part, and how far the evidence actually "
    "stretches.** There is no `num_active_params` field. What exists is a naming "
    "convention: `COSMOS3_FACTS.md` §5 records that the shipped SFT recipe selects the "
    "generator pathway with `optimizer.keys_to_select = [\"moe_gen\", \"time_embedder\", "
    "\"vae2llm\", \"llm2vae\", ...]`. Those substrings are upstream's own way of "
    "addressing one tower, which makes them the most defensible thing to key on. The "
    "count is then *one tower plus everything unassigned*, because shared parameters — "
    "embeddings, final norms — flow through whichever tower is running.\n\n"
    "This will break. When it does, it will break *silently*, returning a plausible "
    "number from a convention that no longer holds. That is why the assumption is "
    "written into `notes` on every successful read, and why the no-match case returns "
    "`None` instead of falling back to the total. A reader that says \"I could not tell\" "
    "is repairable; one that says \"8.0B\" when the markers have been renamed is not.\n\n"
    "**Why the fake checkpoint exists.** The tower-splitting arithmetic — largest tower "
    "plus unassigned — is three lines and easy to get subtly wrong (double-counting a "
    "tensor that matches two markers, or forgetting the shared parameters). Verifying "
    "it against a real 9 GB download would take an hour and would only tell you the "
    "answer matches a number you already believed. A 3,500-parameter checkpoint with "
    "1,000 generator, 2,000 reasoner and 500 shared makes the expected answer arithmetic "
    "you can do in your head, and it runs in milliseconds on any machine. Building the "
    "fixture is more code than the function; it is still the cheaper path.\n\n"
    "**Why the reader is suspected before the table.** Step 6 of the exercise says to "
    "work out which is wrong before assuming it is yours. The comparison cell prints the "
    "specific thing to check first — whether you are comparing the safetensors total "
    "against the marketing active figure, which `COSMOS3_FACTS.md` §1 flags as the "
    "naming trap that catches everyone. \"Nano is 8B\" and \"Nano is 16B\" are both "
    "true statements about different numbers, and a disagreement of exactly 2x between "
    "your reader and the table is almost certainly that, not a bug."
)

nb.extend(
    "The reader answers *what is this checkpoint*. The version worth having answers "
    "*what changed*: point it at two snapshot directories of the same repo and diff the "
    "tensor-name sets. A release that renames `moe_gen` is invisible to a size "
    "comparison and obvious in a name diff, and that is precisely the failure this "
    "reader is most exposed to. It is also the cheapest possible upstream-drift alarm — "
    "no download beyond the one you already have, and it runs from the headers."
)

nb.finish()
