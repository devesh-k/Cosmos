"""Build solutions/12_solutions.ipynb — reference answers for Lesson 12."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("12", "Action: the World Action Model (wam)",
                      lesson_file="12_action_wam.ipynb")

nb.header(
    "`wam` produces two things at once — a rollout video and an action sequence — from an "
    "observation and an instruction. The three exercises interrogate each part of that "
    "sentence. The foundation exercise asks whether the **instruction** controls the "
    "action at all, and insists on a seed control before believing the answer. The "
    "applied one converts the raw action array into phase labels a human can read, and "
    "tests the converter against ground truth it constructed. The challenge one asks "
    "whether the two outputs **agree with each other**, which is the question that "
    "decides whether the model is one system or two."
)

nb.callout(
    "warning",
    "**`wam`, not `policy`.** `COSMOS3_FACTS.md` §2: upstream renamed the mode and "
    "`docs/inference.md`, `docs/faq.md` and the action cookbook README all still say "
    "`policy`. Trust the enum. This lesson also needs Cosmos3-Nano, gated behind "
    "`ALLOW_NANO_DOWNLOAD` as in the lesson. The segmenter, its synthetic ground truth, "
    "the distance tables and the consistency measure all run and are verified here.",
)

nb.prelude("The lesson's configuration and its `wam` spec builder.")
nb.code(setup_cell("12"))

nb.code('''
import json
import math
import subprocess

import numpy as np

from cosmos_course.models import Generator

ACTION_MODEL = "Cosmos3-Nano"
ALLOW_NANO_DOWNLOAD = os.environ.get("COSMOS_COURSE_ALLOW_NANO", "0") == "1"
gen = cc.Generator(checkpoint=ACTION_MODEL)
framework_problems = gen.check(verbose=False)

CHUNK = 16                       # the cookbook's value for this example
FPS = 5                          # ...and its frame rate
TIMEOUT_S = 1800 if MODE == "reduced" else 3600
INSTRUCTION = "Put the pot to the left of the purple item."
RUN = ALLOW_NANO_DOWNLOAD and not framework_problems and DEVICE.startswith("cuda")

episode = cc.asset_or_none("bridge_episode")
OBSERVATION = None
if episode is not None:
    frames = sorted(Path(episode).rglob("*.png")) + sorted(Path(episode).rglob("*.jpg"))
    OBSERVATION = frames[0] if frames else (episode if Path(episode).is_file() else None)

print(f"RUN         : {RUN}   chunk={CHUNK} fps={FPS}")
print(f"instruction : {INSTRUCTION!r}")
print(f"observation : {OBSERVATION}")
for p in framework_problems:
    print(f"  ! {p}")


def wam_spec(name, instruction, *, seed=0, chunk=None, observation=None):
    """A wam spec. `model_mode` is 'wam' — 'policy' is dead (FACTS section 2)."""
    return cc.InferenceSpec(
        model_mode="wam", name=name, prompt=instruction,
        vision_path=str(observation or OBSERVATION),
        domain_name="bridge_orig_lerobot", view_point="ego_view",
        action_chunk_size=chunk or CHUNK, fps=FPS, image_size=480, seed=seed)


def as_action_array(payload):
    """`payload` as a [steps, 10] float array, or None if it is not one."""
    try:
        arr = np.asarray(payload, dtype=np.float64)
    except (TypeError, ValueError):
        return None             # ragged, or not numeric at all
    return arr if arr.ndim == 2 and arr.shape[1] == 10 else None


def read_action(result):
    """Pull the [steps, 10] action array out of a wam RunResult, or None.

    `sample_outputs` and `jsons` are PROPERTIES of RunResult, not methods.
    Two things worth copying from this function:

    * The fallback is a sibling of the first attempt, not code inside its
      `except` block. A fallback that runs *during* handling of another
      exception reports its own failure as "during handling of the above
      exception, another exception occurred", which buries the real cause.
    * Each `except` names the failures it actually expects and says something
      when it takes them. A bare `except Exception: continue` around this
      would turn "you called a property" into "no action array", and you
      would go looking for the bug in the model.
    """
    if result is None:
        return None

    # Preferred source: the first JSON output, parsed, in the layout wam writes.
    try:
        actions = result.sample_outputs["outputs"][0]["content"]["action"]
    except (KeyError, IndexError, TypeError):
        actions = None          # not the wam layout — try the raw JSON outputs
    if actions is not None:
        arr = as_action_array(actions)
        if arr is not None:
            return arr
        print("  ! sample_outputs carried an 'action' that is not a [steps, 10] "
              "array; scanning the JSON outputs instead")

    # Fallback: any JSON output that is itself a [steps, 10] array.
    for path in result.jsons:
        try:
            payload = json.loads(Path(path).read_text())
        except (json.JSONDecodeError, OSError) as exc:
            print(f"  ! {Path(path).name}: not readable JSON ({exc})")
            continue
        arr = as_action_array(payload)
        if arr is not None:
            return arr

    print(f"  ! no [steps, 10] action array in {len(result.jsons)} JSON output(s)")
    return None
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Three instructions, one observation",
    goal="Establish, with numbers rather than impressions, how much the instruction "
         "actually controls the predicted action.",
    success="A pairwise distance table including a same-instruction different-seed "
            "control, and a written note on what the impossible instruction produced.",
    approach="Put the seed control **in the same table** as the instruction pairs, so "
             "the comparison is unavoidable rather than something a reader has to "
             "remember to make.",
)

nb.code('''
INSTRUCTIONS = {
    "pot_left": INSTRUCTION,
    "other_object": "Pick up the purple item and move it towards the camera.",
    "impossible": "Pour the contents of the pot into the blue mug on the right.",
}
print("Chosen so the three are genuinely different (step 1):")
for tag, text in INSTRUCTIONS.items():
    print(f"  {tag:<14} {text!r}")
print()
print("`impossible` names a blue mug that is not in the observation. That is the "
      "point: a policy asked for something the scene cannot support has no correct "
      "action, and what it does instead is the diagnostic.")


# tag -> RunResult, so Exercise 3 can reach the ROLLOUT VIDEO from these same
# runs. A wam call returns both outputs at once; throwing the result away and
# keeping only the actions would mean re-running the model to get the video,
# which doubles the GPU cost and changes the sample it is compared against.
RESULTS = {}


def run_instruction(tag, text, seed=0):
    """Run wam with one instruction; return the predicted action array.

    Keyed into RESULTS by the same label `runs` uses, so the two dicts line up.
    """
    key = tag if seed == 0 else f"{tag} (seed {seed})"
    spec = wam_spec(f"instr_{tag}_s{seed}", text, seed=seed)
    if not RUN:
        print(f"skipped {key!r}: generation is disabled")
        return None
    result = gen.run(spec, OUTPUT_DIR / "instructions", seed=seed, timeout=TIMEOUT_S)
    cc.verify_result(result)
    RESULTS[key] = result
    return read_action(result)


def pairwise_distance(a, b):
    """Mean per-step Euclidean distance between two sequences' translations.

    Hint 2: sequences can come back at different lengths if a run is truncated.
    Comparing over min(len(a), len(b)) and REPORTING that count is what stops a
    short run flattering itself — a truncated sequence compared over its own
    few steps can look arbitrarily close.
    """
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    n = min(a.shape[0], b.shape[0])
    if n == 0:
        return float("nan"), 0
    return float(np.linalg.norm(a[:n, :3] - b[:n, :3], axis=1).mean()), n


# Check the distance function on arrays whose answer is arithmetic.
_a = np.zeros((10, 10)); _a[:, 0] = 1.0
_b = np.zeros((6, 10)); _b[:, 0] = 1.5
d, n = pairwise_distance(_a, _b)
assert n == 6 and abs(d - 0.5) < 1e-12, (d, n)
print(f"\\nPASS pairwise_distance is exact and reports the compared length ({n})")
''')

nb.code('''
runs = {tag: run_instruction(tag, text) for tag, text in INSTRUCTIONS.items()}
# Step 4: the control. The FIRST instruction again at a different seed.
runs["pot_left (seed 1)"] = run_instruction("pot_left", INSTRUCTIONS["pot_left"], seed=1)

if not any(v is not None for v in runs.values()):
    # PLACEHOLDER ACTIONS — invented. Constructed so that two instructions differ
    # clearly, one differs marginally, and the seed control has a non-trivial
    # spread; that combination is what makes the reading of the table an
    # exercise in judgement rather than a lookup. NOT model output.
    print("PLACEHOLDER ACTIONS — invented, not model output.\\n")
    rng = np.random.default_rng(12)
    base = np.zeros((CHUNK, 10))
    base[:, 0] = np.linspace(0.0, -0.06, CHUNK)      # move left
    base[:, 2] = np.linspace(0.0, 0.02, CHUNK)
    base[:, 3] = base[:, 7] = 1.0
    base[6:, 9] = 1.0                                 # gripper closes at step 6

    def jitter(arr, scale):
        out = arr.copy()
        out[:, :3] += rng.normal(0, scale, (arr.shape[0], 3))
        return out

    # `other_object` gets a genuinely different TEMPORAL profile — motion late
    # rather than early — not merely a sign flip, because a sign flip would be
    # invisible to the magnitude-based measure in Exercise 3 and would make the
    # null there look broken for the wrong reason.
    late = np.zeros_like(base)
    late[:, 0] = np.concatenate([np.zeros(CHUNK // 2),
                                 np.linspace(0.0, 0.08, CHUNK - CHUNK // 2)])
    late[:, 3] = late[:, 7] = 1.0
    late[10:, 9] = 1.0
    runs = {
        "pot_left": jitter(base, 0.002),
        "other_object": jitter(late, 0.002),
        "impossible": jitter(base * 0.25, 0.002),     # hedged: much smaller motion
        "pot_left (seed 1)": jitter(base, 0.004),
    }

labels = list(runs)
print(f"{'':<20}" + "".join(f"{lab[:16]:>18}" for lab in labels))
table = {}
for a_lab in labels:
    row = []
    for b_lab in labels:
        if runs[a_lab] is None or runs[b_lab] is None:
            row.append(None)
            print_val = "      n/a"
        else:
            d, n = pairwise_distance(runs[a_lab], runs[b_lab])
            row.append((d, n))
        table[(a_lab, b_lab)] = row[-1]
    print(f"{a_lab[:18]:<20}" + "".join(
        f"{(v[0] if v else float('nan')):>18.5f}" for v in row))

noise = table[("pot_left", "pot_left (seed 1)")]
if noise:
    floor = noise[0]
    print(f"\\nNOISE FLOOR (same instruction, different seed): {floor:.5f}")
    print(f"steps compared in each cell: "
          f"{sorted({v[1] for v in table.values() if v})}")
    print()
    for a_lab in ("other_object", "impossible"):
        v = table.get(("pot_left", a_lab))
        if not v:
            continue
        ratio = v[0] / floor if floor else float("inf")
        verdict = ("clears the floor — a real instruction effect" if ratio >= 2
                   else "does NOT clear the floor — indistinguishable from seed noise")
        print(f"  pot_left vs {a_lab:<14} {v[0]:.5f}  ({ratio:.2f}x floor)  {verdict}")
''')

nb.model_answer(
    "**What the impossible instruction produced, and what the table is allowed to say.**\n\n"
    "**On the control, first, because it governs everything else.** Hint 1 is right that "
    "without it the exercise cannot conclude anything, and the reason is worth stating "
    "precisely: `wam` is a sampler. Two runs with the same instruction and different "
    "seeds produce different action sequences, and the size of that difference is the "
    "resolution of your instrument. A between-instruction distance that does not clear it "
    "is not evidence of anything, however suggestive the two videos look. The control is "
    "put *in the same table* rather than reported alongside it, precisely so that the "
    "comparison cannot be skipped.\n\n"
    "**What an impossible instruction can do, and how to tell which.** There are four "
    "distinguishable behaviours, and each says something different about the model:\n\n"
    "1. **Hedging.** Much smaller motion than any feasible instruction produces — the "
    "policy declines to commit. Diagnostic: the `impossible` row's *path length* is "
    "small compared with the others, not just its distance from them. This is the "
    "best-behaved failure and it is the one to hope for, because a small action is a "
    "recoverable one.\n"
    "2. **Substitution.** It executes a plausible nearby task — reaching for the purple "
    "item because there is no blue mug. Diagnostic: `impossible` sits *closer* to "
    "`other_object` than to `pot_left`. This is the dangerous case: confident, "
    "well-formed, and wrong, and it is the action-space analogue of Lesson 04's ghost "
    "mug.\n"
    "3. **Ignoring.** It does whatever it would have done with any instruction. "
    "Diagnostic: `impossible` sits within the noise floor of *everything*, and so does "
    "`other_object`. That would be the strongest finding available here — that the "
    "instruction channel is not doing much — and it would deserve chasing rather than "
    "shrugging at.\n"
    "4. **Degeneracy.** Near-zero rows throughout, or NaNs. Diagnostic: obvious from "
    "`cc.check_action`.\n\n"
    "The table above distinguishes these because it contains the noise floor and all "
    "three pairwise distances. That is the entire value of building it as a table rather "
    "than as three comparisons.\n\n"
    "**One more thing worth measuring and not asked for.** The gripper channel. An "
    "instruction that names an object to *pick up* should close the gripper; an "
    "impossible instruction naming a nonexistent object gives the model nothing to close "
    "on. Comparing the step at which column 9 transitions across the three runs is one "
    "line and is more interpretable than the translation distance, because it is a "
    "discrete event rather than a continuous magnitude. Exercise 2 builds the machinery "
    "for exactly this.\n\n"
    "*If the numbers above came from the placeholder block, the pattern shown is "
    "hedging, chosen because it is the behaviour worth being able to recognise. It is "
    "not a claim about what Cosmos 3 does.*"
)

nb.extend(
    "Three instructions and one seed each is the minimum that can support any "
    "conclusion. The version worth running is three seeds per instruction, which turns "
    "every cell from a point into a distribution and lets you ask the better question: "
    "is the *within-instruction* spread smaller than the *between-instruction* spread? "
    "That is a one-way ANOVA in all but name, it costs nine runs instead of four, and it "
    "converts \"this pair clears the floor\" into a statement about the instruction "
    "channel as a whole rather than about one pair of prompts."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "Segment a trajectory into reach, grasp, move and release",
    goal="Turn a raw 10-column array into a description a human can read — and validate "
         "that the description is right rather than plausible.",
    success="Written phase definitions, a segmenter that passes a synthetic test with "
            "known ground truth, timelines for both real predictions, and one documented "
            "failure case.",
    approach="Write the definitions before the code, infer the gripper polarity from the "
             "data, use hysteresis on both the gripper and the motion threshold, and set "
             "the motion threshold relative to the trajectory's own scale.",
)

nb.md(
    "### The phase definitions, written before any code\n\n"
    "Step 2 asks for these first, and the order matters: definitions written after the "
    "implementation describe what the code happens to do.\n\n"
    "| phase | definition |\n|---|---|\n"
    "| `grasp` | the step at which the gripper crosses from open to closed |\n"
    "| `release` | the step at which it crosses from closed to open |\n"
    "| `reach` | the gripper is open **and** the end effector is moving |\n"
    "| `move` | the gripper is closed **and** the end effector is moving |\n"
    "| `idle` | the end effector is not moving, and this is not a transition step |\n\n"
    "Two things are deliberately *not* in these definitions. There is no ordering "
    "constraint — the segmenter labels each step from local evidence and does not "
    "enforce that `reach` precedes `grasp`, because enforcing it would hide exactly the "
    "failures worth seeing. And there is no notion of the *target*: `reach` means moving "
    "with an open gripper, not moving towards the right object. The segmenter cannot see "
    "intent, only kinematics."
)

nb.code('''
PHASES = ("idle", "reach", "grasp", "move", "release")


def infer_gripper_polarity(gripper, *, quantile=0.15):
    """Which end of the gripper channel means CLOSED? Returns 'high' or 'low'.

    Step 3 forbids hard-coding this, and the reason is concrete: COSMOS3_FACTS.md
    section 5 records that LIBERO's gripper sign is FLIPPED between simulator and
    training (`1 - 2g`), so a constant is wrong for at least one of the two.

    The inference: a manipulation episode spends most of its time in one gripper
    state and a minority in the other, and the minority state is almost always
    the closed one — you grasp for part of an episode, not most of it. So the
    less common extreme is 'closed'. This is a heuristic and it FAILS on an
    episode that is mostly holding something, which is why the function returns
    its confidence and the caller can override.
    """
    g = np.asarray(gripper, dtype=np.float64)
    lo, hi = float(np.min(g)), float(np.max(g))
    if hi - lo < 1e-9:
        return "high", 0.0                    # constant channel; no information
    mid = (lo + hi) / 2.0
    frac_high = float((g > mid).mean())
    polarity = "high" if frac_high <= 0.5 else "low"
    confidence = abs(0.5 - frac_high) * 2.0
    return polarity, confidence


def segment_trajectory(action, fps, *, gripper_index=9, closed_is=None,
                       motion_fraction=0.25, hysteresis=0.2):
    """Return a list of per-step phase labels.

    Hint 1: a pure threshold CHATTERS. A gripper value hovering near the
    threshold flips the label every step, and the timeline becomes unreadable.
    Hysteresis — separate thresholds for closing and opening — fixes it, and the
    same problem appears in every signal-to-symbol conversion.

    Hint 2: the motion threshold is RELATIVE to the trajectory's own scale — a
    fraction of the MEDIAN per-step magnitude — not an absolute constant. A
    fixed metres-per-step number is wrong for a different robot, a different
    `translation_scale`, or a different fps.

    A quantile of the magnitudes is the tempting alternative and it has a nasty
    degenerate case: on a trajectory that moves at a constant speed for most of
    its steps, the 35th percentile IS that speed, and `mag > threshold` is then
    false everywhere. Every moving step gets labelled `idle`. A fraction of the
    median cannot land on the modal value like that.
    """
    action = np.asarray(action, dtype=np.float64)
    gripper = action[:, gripper_index]
    if closed_is is None:
        closed_is, _conf = infer_gripper_polarity(gripper)

    lo, hi = float(gripper.min()), float(gripper.max())
    span = max(hi - lo, 1e-9)
    # Two thresholds, 20% of the span apart, so a crossing must be decisive.
    close_at = lo + span * (0.5 + hysteresis / 2)
    open_at = lo + span * (0.5 - hysteresis / 2)

    closed_state = []
    state = False
    for value in gripper:
        if closed_is == "high":
            if value >= close_at:
                state = True
            elif value <= open_at:
                state = False
        else:
            if value <= open_at:
                state = True
            elif value >= close_at:
                state = False
        closed_state.append(state)

    magnitudes = np.linalg.norm(action[:, :3], axis=1)
    scale = float(np.median(magnitudes))
    if scale <= 1e-12:
        scale = float(np.max(magnitudes))
    moving = magnitudes > max(motion_fraction * scale, 1e-12)

    labels = []
    for i in range(action.shape[0]):
        transition = i > 0 and closed_state[i] != closed_state[i - 1]
        if transition:
            labels.append("grasp" if closed_state[i] else "release")
        elif moving[i]:
            labels.append("move" if closed_state[i] else "reach")
        else:
            labels.append("idle")
    return labels
''')

nb.code('''
def synthetic_episode(n_steps=20, closes_at=6, opens_at=15, closed_value=1.0):
    """Build an action array with a KNOWN segmentation, for testing."""
    arr = np.zeros((n_steps, 10), dtype=np.float64)
    arr[:, 3] = arr[:, 7] = 1.0                       # identity-ish rotation
    # Motion everywhere except the last few steps, which are deliberately still.
    arr[:n_steps - 4, 0] = 0.05
    arr[closes_at:opens_at, 9] = closed_value          # gripper closed window
    expected = (["reach"] * closes_at + ["grasp"]
                + ["move"] * (opens_at - closes_at - 1) + ["release"]
                + ["reach"] * (n_steps - opens_at - 1))
    # The last four steps have no motion, so they are idle rather than reach.
    for i in range(n_steps - 4, n_steps):
        if expected[i] in ("reach", "move"):
            expected[i] = "idle"
    return arr, expected


arr, expected = synthetic_episode()
got = segment_trajectory(arr, fps=FPS)
print("expected:", expected)
print("got     :", got)
assert got == expected, [(i, a, b) for i, (a, b) in enumerate(zip(expected, got))
                         if a != b]
print("\\nPASS the segmenter recovers a known ground-truth segmentation exactly")

# Polarity inference, both ways round: the same episode with the gripper sign
# flipped must produce the SAME labels.
flipped = arr.copy()
flipped[:, 9] = 1.0 - flipped[:, 9]
assert infer_gripper_polarity(arr[:, 9])[0] == "high"
assert infer_gripper_polarity(flipped[:, 9])[0] == "low"
assert segment_trajectory(flipped, fps=FPS) == expected
print("PASS polarity is inferred from the data, and flipping the gripper sign "
      "leaves the segmentation unchanged")

# Hysteresis, demonstrated: a noisy gripper hovering at the midpoint.
noisy = arr.copy()
rng = np.random.default_rng(5)
noisy[:, 9] = 0.5 + rng.normal(0, 0.06, arr.shape[0])
labels_hyst = segment_trajectory(noisy, fps=FPS, closed_is="high", hysteresis=0.6)
labels_none = segment_trajectory(noisy, fps=FPS, closed_is="high", hysteresis=0.0)
flips_hyst = sum(1 for a, b in zip(labels_hyst, labels_hyst[1:]) if a != b)
flips_none = sum(1 for a, b in zip(labels_none, labels_none[1:]) if a != b)
print(f"\\nlabel changes on a noisy gripper: {flips_none} without hysteresis, "
      f"{flips_hyst} with")
assert flips_hyst < flips_none, (flips_hyst, flips_none)
print("PASS hysteresis suppresses chatter")
''')

nb.code('''
def timeline(labels, *, width=1):
    """One-character-per-step timeline plus a run-length summary."""
    glyph = {"idle": ".", "reach": "-", "grasp": "[", "move": "=", "release": "]"}
    line = "".join(glyph.get(x, "?") * width for x in labels)
    runs, current, count = [], None, 0
    for x in labels:
        if x == current:
            count += 1
        else:
            if current is not None:
                runs.append((current, count))
            current, count = x, 1
    if current is not None:
        runs.append((current, count))
    return line, runs


real_actions = {}
for tag, text in list(INSTRUCTIONS.items())[:2]:
    arr_real = runs.get(tag)
    if arr_real is not None:
        real_actions[tag] = np.asarray(arr_real, dtype=np.float64)

for tag, arr_real in real_actions.items():
    labels = segment_trajectory(arr_real, fps=FPS)
    line, run_lengths = timeline(labels)
    polarity, confidence = infer_gripper_polarity(arr_real[:, 9])
    print(f"{tag}   (gripper polarity {polarity!r}, confidence {confidence:.2f})")
    print(f"  {line}")
    print(f"  {run_lengths}")
    print()
print("legend:  . idle   - reach   [ grasp   = move   ] release")
if not real_actions:
    print("\\n(no real predictions available; the synthetic test above is what "
          "validates the segmenter)")
''')

nb.model_answer(
    "**One case where the segmenter is wrong or ambiguous, and what would resolve it.**\n\n"
    "**The failure: a re-grasp.** The robot closes on the pot, lifts it, the grip slips, "
    "and it closes again without ever fully opening. The gripper channel dips towards "
    "open and comes back, crossing neither hysteresis threshold. The segmenter labels the "
    "whole thing `move`, and the timeline says the robot carried the object smoothly "
    "throughout. That is the single most important event in the episode and it is "
    "invisible.\n\n"
    "This is not a bug in the thresholds; it is inherent to converting a continuous "
    "signal into symbols with a two-state model. Widening the hysteresis makes it worse. "
    "Narrowing it reintroduces the chatter that hysteresis was added to remove. The two "
    "requirements genuinely conflict.\n\n"
    "**A second, softer ambiguity:** `idle` versus slow `reach`. The motion threshold is "
    "the 35th percentile of the trajectory's *own* magnitudes, so an episode that moves "
    "slowly throughout gets a third of its steps labelled `idle` purely because they are "
    "the slowest third. A relative threshold is right for portability (hint 2) and wrong "
    "for absolute statements about whether the robot moved. Both are defensible and the "
    "cost of the choice should be stated.\n\n"
    "**What extra signal would resolve the re-grasp.** In order of how much I would want "
    "it:\n\n"
    "1. **Gripper force or current**, if the embodiment reports it. A slip shows as a "
    "force spike with no position change, and it is unambiguous. Not available in a 10-D "
    "bridge action, which carries position only.\n"
    "2. **The gripper channel's derivative rather than its level.** A re-grasp is a "
    "*local minimum* in the gripper signal even when it never crosses a threshold. "
    "Detecting turning points in addition to crossings would catch it, at the cost of "
    "more false positives on noise — which is exactly the trade hysteresis is making, "
    "moved to a different place.\n"
    "3. **The rollout video.** The jaws visibly move. This is available and it is what "
    "Exercise 3 goes on to build machinery for, which is a good illustration of why the "
    "two exercises are adjacent: the segmenter's blind spot is precisely where the video "
    "has information the action array does not.\n\n"
    "**The general lesson**, and it is why hint 1 says the problem appears in every "
    "signal-to-symbol conversion: a threshold turns a continuous quantity into a "
    "discrete one and *destroys* the information that was in the margin. Whatever you "
    "then do with the symbols cannot recover it. If an event matters, check whether your "
    "symbolisation can represent it before you build anything on top."
)

nb.extend(
    "The segmenter labels steps independently, which is why the re-grasp is invisible and "
    "why illegal sequences (`grasp` immediately followed by `grasp`) are possible. A "
    "small hidden Markov model or even a hand-written transition table would enforce "
    "the phase grammar and, more usefully, would report *how surprised it is* — a "
    "sequence with a low likelihood under the grammar is exactly the anomalous episode "
    "you want flagged. That reframes the segmenter from a labeller into a detector, and "
    "it needs no extra data."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "Are the predicted video and the predicted actions consistent?",
    goal="Design, run and honestly report an experiment measuring whether the two "
         "outputs of a `wam` run agree with each other.",
    success="A falsifiable hypothesis, a measure with a video-derived component, a "
            "matched-versus-mismatched null that the measure separates (or a clear "
            "statement that it does not), and two named blind spots.",
    approach="State the hypothesis as a step count with a tolerance; build the measure "
             "from the video's motion profile correlated against the action's "
             "translation magnitude; and establish the null with mismatched pairs before "
             "reporting anything.",
)

nb.md(
    "### The hypothesis, stated so it can fail\n\n"
    "**H1.** For a single `wam` run, the per-step translation magnitude of the predicted "
    "action sequence and the per-frame motion magnitude of the predicted rollout video, "
    "each standardised and resampled to a common length, have a Pearson correlation of "
    "at least **0.5** — and this correlation is at least **0.25 higher** than the "
    "correlation between the same video and the action sequence from a *different* "
    "instruction.\n\n"
    "**H2.** The step at which the gripper channel transitions is within **one step** of "
    "the frame (scaled to step units) at which motion in the lower-central region of the "
    "frame — where the jaws are — peaks.\n\n"
    "Both are falsifiable, both have a threshold stated in advance, and H1's second "
    "clause is the part that makes it a test rather than an observation: a high "
    "correlation that mismatched pairs also achieve is not evidence of consistency."
)

nb.code('''
def video_motion_profile(video_path, n_frames=64, region=None):
    """Per-frame motion magnitude from a clip. Optionally within a region.

    `region` is (row_lo, row_hi, col_lo, col_hi) as fractions, so the same call
    gives the whole-frame profile (for H1) and the gripper-region profile
    (for H2) without a second decoder.
    """
    frames = []
    try:
        import imageio.v3 as iio
        for i, f in enumerate(iio.imiter(str(video_path))):
            arr = np.asarray(f)
            frames.append(arr.mean(axis=2) if arr.ndim == 3 else arr)
            if len(frames) >= n_frames:
                break
    except Exception:
        return None
    if len(frames) < 3:
        return None
    if region is not None:
        r0, r1, c0, c1 = region
        h, w = frames[0].shape
        frames = [f[int(r0 * h):int(r1 * h), int(c0 * w):int(c1 * w)] for f in frames]
    return np.array([float(np.abs(frames[i + 1] - frames[i]).mean())
                     for i in range(len(frames) - 1)])


def standardise(x):
    x = np.asarray(x, dtype=np.float64)
    sd = x.std()
    return (x - x.mean()) / sd if sd > 1e-12 else np.zeros_like(x)


def resample(x, n):
    x = np.asarray(x, dtype=np.float64)
    if len(x) == n:
        return x
    return np.interp(np.linspace(0, 1, n), np.linspace(0, 1, len(x)), x)


def consistency(video_path, action, fps, *, n=32):
    """Agreement between the two outputs of one wam run.

    Hint 1's caveat, stated where it applies: standardising to zero mean and
    unit variance throws away ABSOLUTE MAGNITUDE. After this normalisation the
    measure cannot tell a rollout that moves the commanded distance from one
    that moves ten times too far — it only compares the SHAPE of the two
    profiles over time. That is a real loss and it is accepted because the two
    series are in incomparable units (pixels of frame difference against
    whatever the action's translation units are), so there is no common scale
    to preserve.
    """
    profile = video_motion_profile(video_path, n_frames=n + 1)
    if profile is None:
        return {"error": "could not decode the rollout"}
    action = np.asarray(action, dtype=np.float64)
    a = standardise(resample(np.linalg.norm(action[:, :3], axis=1), n))
    v = standardise(resample(profile, n))
    r = float(np.corrcoef(a, v)[0, 1]) if a.std() and v.std() else float("nan")
    return {"correlation": r, "n": n}


# Check the correlation machinery on series whose answer is known.
_x = np.sin(np.linspace(0, 4 * np.pi, 40))
assert abs(float(np.corrcoef(standardise(resample(_x, 32)),
                             standardise(resample(_x, 32)))[0, 1]) - 1.0) < 1e-9
assert abs(float(np.corrcoef(standardise(resample(_x, 32)),
                             standardise(resample(-_x, 32)))[0, 1]) + 1.0) < 1e-9
print("PASS resample+standardise+correlate gives +1 for a series against itself "
      "and -1 against its negation")
''')

nb.md(
    "### Where the video side comes from\n\n"
    "The exercise has one hard requirement: **at least one component must be "
    "computed from the video, not from the action array**. That is the "
    "requirement a placeholder cannot satisfy, because a motion profile "
    "synthesised from the actions agrees with them by construction — it "
    "measures the synthesiser.\n\n"
    "So the video side is the **rollout `wam` actually wrote**, taken from the "
    "`RunResult` of the Foundation exercise's runs. `wam` returns both outputs "
    "from one call, which is the whole reason this exercise is possible: the "
    "actions and the video came out of the same forward pass, at the same seed, "
    "for the same instruction. Re-running the model to fetch the video would "
    "double the GPU cost *and* change the sample.\n\n"
    "`RunResult.video_path` is a **property** (`videos[0] or None`), not a "
    "method — calling it raises `TypeError`, and a `try/except` around that "
    "turns a one-character mistake into a silent \"no video\". `rollout_video` "
    "reads it as an attribute and then checks the file is on disk, because "
    "`video_path` is also `None` when a run produced JSON only.\n\n"
    "**The fallback, and what it costs.** With no GPU there is no rollout, and "
    "the cell falls back to synthesised profiles. That path is labelled "
    "everywhere it prints, it is labelled in the report it writes, and it does "
    "**not** satisfy the exercise — it exercises the measure and the null, and "
    "nothing more. The video-derived path is the one that answers the question, "
    "and it runs as soon as Lesson 12's runs exist."
)

nb.code('''
# Step 3 and 4: matched and mismatched pairs. The null is the whole experiment —
# a measure that cannot separate them is not measuring consistency.
def rollout_video(key):
    """The mp4 a wam run wrote, or None if that run did not happen.

    `video_path` is a PROPERTY on RunResult -- `self.videos[0] if self.videos
    else None`. It is also None for a run that produced only JSON, so the file
    is checked on disk rather than trusted: a zero-byte mp4 from a run that
    exited cleanly is exactly the failure Lesson 06 spent a section on.
    """
    result = RESULTS.get(key)
    path = getattr(result, "video_path", None)
    if path is None:
        return None
    path = Path(path)
    return path if path.exists() and path.stat().st_size > 1024 else None


action = runs.get("pot_left")
alt_action = runs.get("other_object")
wam_video = rollout_video("pot_left")
alt_video = rollout_video("other_object")

pairs = []
if action is not None and alt_action is not None:
    # Each rollout is paired with its OWN actions and with the other
    # instruction's, so every video that exists contributes one matched and one
    # mismatched pair. One of the two rollouts missing halves the experiment
    # rather than ending it.
    if wam_video is not None:
        pairs += [("matched    pot_left/pot_left", wam_video, action),
                  ("mismatched pot_left/other", wam_video, alt_action)]
    if alt_video is not None:
        pairs += [("matched    other/other", alt_video, alt_action),
                  ("mismatched other/pot_left", alt_video, action)]

VIDEO_DERIVED = bool(pairs)
if VIDEO_DERIVED:
    print("VIDEO-DERIVED PROFILES — the video side is decoded from the rollouts "
          "wam wrote:")
    for label, video, _ in pairs:
        print(f"  {label:<30} {video}")
    print()

if not pairs:
    # PLACEHOLDER PROFILES — invented. A synthetic "video" profile is built to
    # follow each action's own magnitude curve plus noise, so matched pairs
    # correlate and mismatched pairs do not. This exercises the null and the
    # reporting; it is NOT evidence about Cosmos 3, and it cannot be, because
    # the video side is constructed from the action side by definition.
    print("PLACEHOLDER PROFILES — no rollout video on this machine, so the "
          "video side is SYNTHESISED from the action side. The matched "
          "correlations below are therefore true by construction. They "
          "demonstrate that the measure and the null work; they say nothing "
          "about the model, and this path does NOT satisfy the exercise's "
          "requirement that a component be computed from the video.\\n")
    if not RUN:
        print("  (generation is disabled: set COSMOS_COURSE_ALLOW_NANO=1 on a "
              "CUDA box and re-run the Foundation cells to get real rollouts.)\\n")
    rng = np.random.default_rng(7)

    def fake_profile(arr):
        mag = np.linalg.norm(np.asarray(arr)[:, :3], axis=1)
        return resample(mag, 40) * 100 + rng.normal(0, 0.6, 40)

    fake_videos = {tag: fake_profile(arr) for tag, arr in runs.items()
                   if arr is not None}

    def consistency_from_profile(profile, arr, n=32):
        a = standardise(resample(np.linalg.norm(np.asarray(arr)[:, :3], axis=1), n))
        v = standardise(resample(profile, n))
        return {"correlation": float(np.corrcoef(a, v)[0, 1]), "n": n}

    results = [
        ("matched    pot_left/pot_left",
         consistency_from_profile(fake_videos["pot_left"], runs["pot_left"])),
        ("mismatched pot_left/other",
         consistency_from_profile(fake_videos["pot_left"], runs["other_object"])),
        ("matched    other/other",
         consistency_from_profile(fake_videos["other_object"], runs["other_object"])),
        ("mismatched other/pot_left",
         consistency_from_profile(fake_videos["other_object"], runs["pot_left"])),
    ]
else:
    results = [(label, consistency(video, arr, FPS)) for label, video, arr in pairs]

print(f"{'pair':<30}{'correlation':>13}")
print("-" * 44)
for label, m in results:
    print(f"{label:<30}{m.get('correlation', float('nan')):>13.4f}")

matched = [m["correlation"] for label, m in results if label.startswith("matched")]
mismatched = [m["correlation"] for label, m in results if label.startswith("mismatched")]
gap = float(np.mean(matched) - np.mean(mismatched))
print(f"\\nmean matched   : {np.mean(matched):.4f}")
print(f"mean mismatched: {np.mean(mismatched):.4f}")
print(f"separation     : {gap:.4f}")
print()
print(f"H1 clause 1 (matched correlation >= 0.5): "
      f"{'SUPPORTED' if np.mean(matched) >= 0.5 else 'NOT SUPPORTED'}")
print(f"H1 clause 2 (separation >= 0.25)        : "
      f"{'SUPPORTED' if gap >= 0.25 else 'NOT SUPPORTED'}")
if gap < 0.25:
    print("\\nA measure that does not separate matched from mismatched pairs is not "
          "measuring consistency. Report that, rather than reporting the matched "
          "correlation on its own.")
''')

nb.code('''
# The blind spots, MEASURED rather than described. Take one action array and a
# motion profile that matches it, then corrupt the action in four known ways and
# see which corruptions the measure notices. A limitation you have quantified is
# worth more than one you have asserted.
def _profile_of(arr, n=40):
    return resample(np.linalg.norm(np.asarray(arr)[:, :3], axis=1), n)


def _corr(profile, arr, n=32):
    a = standardise(resample(np.linalg.norm(np.asarray(arr)[:, :3], axis=1), n))
    v = standardise(resample(profile, n))
    if a.std() < 1e-12 or v.std() < 1e-12:
        return float("nan")
    return float(np.corrcoef(a, v)[0, 1])


ref = np.asarray(runs["pot_left"], dtype=np.float64)
ref_profile = _profile_of(ref)
_rng = np.random.default_rng(21)

corruptions = {
    "unchanged": ref,
    "sign-flipped (moves the OPPOSITE way)": ref * np.array([-1, -1, -1] + [1] * 7),
    "scaled 10x (moves ten times too far)": ref * np.array([10, 10, 10] + [1] * 7),
    "steps shuffled (same steps, wrong order)": ref[_rng.permutation(len(ref))],
    "time-reversed": ref[::-1],
}
print(f"{'corruption':<44}{'correlation':>13}   detected?")
print("-" * 74)
scores = {}
for label, arr_c in corruptions.items():
    r = _corr(ref_profile, arr_c)
    scores[label] = r
    detected = "no  <- BLIND SPOT" if r > 0.8 else "yes"
    print(f"{label:<44}{r:>13.4f}   {'' if label == 'unchanged' else detected}")

print()
assert scores["sign-flipped (moves the OPPOSITE way)"] > 0.95, scores
print("MEASURED blind spot 1: reversing the DIRECTION of every step leaves the "
      "correlation at "
      f"{scores['sign-flipped (moves the OPPOSITE way)']:.4f}. The measure "
      "cannot see direction at all.")
assert scores["scaled 10x (moves ten times too far)"] > 0.95, scores
print("MEASURED blind spot 2: scaling every step by 10 leaves the correlation at "
      f"{scores['scaled 10x (moves ten times too far)']:.4f}. Standardisation "
      "removed magnitude, exactly as its docstring says.")
assert scores["steps shuffled (same steps, wrong order)"] < 0.8, scores
print("Shuffling the step ORDER does drop the correlation, so the measure is at "
      "least sensitive to temporal structure — which is the one thing it is "
      "actually for.")
''')

nb.code('''
lines = [
    "# wam output consistency — Lesson 12, Exercise 3",
    "",
    ("Measured on this machine. The video side is decoded from the rollouts wam "
     "wrote: " + ", ".join(f"`{name}`" for name in
                           sorted({v.name for _, v, _ in pairs})) + "."
     if VIDEO_DERIVED else
     "**PLACEHOLDER RESULTS.** No wam rollout on this machine, so the video side "
     "of the measure is SYNTHESISED from the action side. The matched correlations are "
     "therefore true by construction and are evidence about the measure, not about the "
     "model. This does not satisfy the exercise, which requires a component computed "
     "from the video."),
    "",
    "## Hypotheses (stated before measuring)",
    "",
    "**H1.** Standardised per-step action translation magnitude and standardised "
    "per-frame video motion magnitude, resampled to a common length, correlate at "
    "**>= 0.5**, AND that correlation exceeds the mismatched-pair correlation by "
    "**>= 0.25**.",
    "",
    "**H2.** The gripper transition step is within **one step** of the peak of motion "
    "in the lower-central frame region.",
    "",
    "## Measure",
    "",
    "Pearson correlation between two time series: one derived from the ACTION array "
    "(per-step translation magnitude) and one derived from the VIDEO (per-frame mean "
    "absolute difference). Both standardised and resampled to 32 points.",
    "",
    "## Null",
    "",
    "The same measure computed between each rollout and the action array from a "
    f"DIFFERENT instruction. {len(results)} pairs: "
    f"{sum(1 for lab, _ in results if lab.startswith('matched'))} matched, "
    f"{sum(1 for lab, _ in results if lab.startswith('mismatched'))} mismatched.",
    "",
    "| pair | correlation |",
    "|---|---:|",
]
for label, m in results:
    lines.append(f"| {label} | {m.get('correlation', float('nan')):.4f} |")

lines += [
    "",
    f"- mean matched: **{np.mean(matched):.4f}**",
    f"- mean mismatched: **{np.mean(mismatched):.4f}**",
    f"- separation: **{gap:.4f}** "
    + ("(clears the 0.25 threshold)" if gap >= 0.25 else
       "(does NOT clear the 0.25 threshold — the measure does not separate "
       "matched from mismatched pairs, and no consistency claim can be made "
       "from it)"),
    "",
    "## What this measure cannot detect",
    "",
    f"**1. Direction — MEASURED, not asserted.** Reversing the direction of every "
    f"step leaves the correlation at "
    f"**{scores['sign-flipped (moves the OPPOSITE way)']:.4f}**. "
    "The measure uses translation *magnitude* and frame-difference "
    "*magnitude*. Both are unsigned. A rollout in which the arm moves right while the "
    "action array commands left scores a perfect correlation, because the speed "
    "profiles are identical and only the sign differs. This is the single largest "
    "blind spot and it covers a failure that matters enormously — an action sequence "
    "and a video that disagree about *where the robot went* is exactly the "
    "inconsistency the exercise is looking for.",
    "",
    f"**2. Absolute scale — MEASURED.** Scaling every step by 10 leaves the "
    f"correlation at **{scores['scaled 10x (moves ten times too far)']:.4f}**. "
    "Standardisation to zero mean and unit variance discards "
    "magnitude by construction (see the `consistency` docstring). A rollout moving ten "
    "times too far, with the same profile shape, is indistinguishable from a correct "
    "one. The normalisation is necessary — the two series are in incomparable units — "
    "so this blind spot is the price of being able to compare them at all, not an "
    "oversight.",
    "",
    "**3. Temporal offset.** Correlation at zero lag punishes a rollout that is "
    "correct but one frame late as though it were wrong. Reporting the maximum "
    "correlation over lags -2..+2, and the lag that achieved it, would separate 'wrong' "
    "from 'late' — and a consistently non-zero best lag would be a frame-indexing bug "
    "worth finding.",
    "",
    "**4. Everything outside the two channels.** Rotation and the gripper are not in "
    "H1's measure at all. H2 addresses the gripper; nothing here addresses rotation.",
    "",
    "## On the inverse-dynamics alternative",
    "",
    "Running Lesson 11's inverse dynamics on the rollout and comparing the recovered "
    "actions against the predicted ones would be far more direct: it is signed, it is "
    "in action units, and it would catch blind spots 1 and 2. It was not used as the "
    "primary measure because of the circularity — the same checkpoint would be "
    "generating the rollout, predicting the action, and grading the agreement between "
    "them. Correlated bias across those three roles is invisible to the comparison, "
    "and the three roles are maximally likely to share a bias because they are one "
    "model. It is the right SECOND measure precisely because it fails differently from "
    "a pixel statistic; it is the wrong ONLY measure.",
]
report_path = OUTPUT_DIR / "consistency_report.md"
report_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {report_path}")
print("\\n".join(lines[-24:]))
''')

nb.why(
    "**Why the hypothesis has a second clause.** \"Matched pairs correlate at 0.7\" is "
    "not a result until you know what mismatched pairs score. Two motion profiles from "
    "the same scene, the same robot and the same episode length will correlate somewhat "
    "*whatever* the instruction was, because they share the scene's dynamics and the "
    "episode's overall arc. The null is therefore not zero, and guessing it is not "
    "acceptable — it has to be measured, which is what step 3 is for. Writing the "
    "separation threshold into the hypothesis *before* measuring is what stops the "
    "threshold being chosen afterwards to fit.\n\n"
    "**Why standardisation is admitted as a loss rather than described as "
    "preprocessing.** Hint 1 asks what the normalisation throws away and the answer is "
    "load-bearing: after standardising, the measure compares *shapes* and is blind to "
    "*magnitudes*. That is not a detail — it means the measure cannot detect a rollout "
    "that moves ten times too far, which is a real and plausible inconsistency. The "
    "normalisation is still necessary, because pixels-of-frame-difference and "
    "action-translation-units have no common scale. Both things are true and the report "
    "says both.\n\n"
    "**Why direction is the blind spot to lead with.** Hint 2 offers it and it deserves "
    "the top of the list because it is the failure most likely to *matter* and least "
    "likely to be noticed. A robot that moves smoothly and confidently in the wrong "
    "direction scores perfectly on every magnitude-based measure ever written. A "
    "signed measure — comparing the video's optical-flow direction against the action's "
    "translation direction — would fix it, and needs an optical-flow estimator, which is "
    "a dependency this course does not have.\n\n"
    "**Why the placeholder path is fenced off so hard.** When no model is available, the "
    "\"video\" profile is synthesised from the action array, so the matched correlations "
    "are 1.0-ish *by construction*. That is genuinely useful — it demonstrates that the "
    "measure, the resampling, the standardisation and the null all work — and it is "
    "genuinely not evidence about Cosmos 3. Any solution that quietly presented those "
    "numbers as a result would be worse than one with no numbers at all, which is why "
    "the print statement says so in the first line.\n\n"
    "**Why the video side is taken from `RESULTS` rather than left as a variable to "
    "fill in.** The obvious shape for this cell is `wam_video = None  # your rollout "
    "here`, and it is a trap: with `None` there the `pairs` list is always empty, so "
    "`video_motion_profile` and `consistency` are never called and the only path that "
    "ever executes is the one the exercise forbids. Wiring `wam_video` to "
    "`RESULTS['pot_left'].video_path` means the video-derived branch is the branch that "
    "runs the moment Lesson 12's runs exist, and the placeholder is the fallback rather "
    "than the default.\n\n"
    "**H2 is stated and not measured here**, because it needs a real rollout and a "
    "region of the frame where the jaws actually are. Stating a hypothesis you could not "
    "test is better than dropping it: it tells the next person what to do, and "
    "`video_motion_profile` already takes the `region` argument it would need."
)

nb.extend(
    "The most valuable version of this experiment is a **negative control on the model "
    "rather than on the pairing**: take the predicted action array, corrupt it in a known "
    "way — reverse it, scale it, shuffle its steps — and re-run the consistency measure "
    "against the original rollout. The measure should degrade in a predictable order: "
    "shuffling should destroy the correlation, reversing should leave a magnitude-based "
    "measure untouched (which demonstrates blind spot 1 directly rather than describing "
    "it), and scaling should leave a standardised measure untouched (blind spot 2). That "
    "converts two paragraphs of admitted limitations into two measured numbers, and it "
    "costs no model runs at all."
)

nb.finish()
