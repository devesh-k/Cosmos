"""Build solutions/17_solutions.ipynb — reference answers for Lesson 17."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("17", "Post-training on one GPU",
                      lesson_file="17_posttraining_one_gpu.ipynb")

nb.header(
    "Lesson 17 attempts something **NVIDIA does not document**: single-GPU SFT. Every "
    "shipped recipe assumes eight GPUs or more, so the three exercises are structured as "
    "an experiment rather than a procedure. The foundation one records a prediction, runs "
    "the smoke configuration and reports what happened — including an OOM, which is a "
    "complete answer. The applied one bisects the token cap and reports a *frontier with "
    "an interval*. The challenge one asks whether the fine-tune helped, and expects the "
    "answer to be \"no detectable difference\", which is a real result."
)

nb.callout(
    "warning",
    "**The most likely honest outcome of this lesson is a documented failure.** "
    "`COSMOS3_FACTS.md` §5 is explicit: NVIDIA documents no single-GPU training path, and "
    "the Edge generation-pathway configuration is an *experiment with a predicted "
    "outcome, not a promise*. A report that says \"it OOMed at iteration 3, here is the "
    "traceback, here is the setting\" satisfies the success criteria completely. Do not "
    "tune until it passes and then report only the pass.",
)

nb.prelude(
    "The lesson's configuration, paths, opt-in flags, `finalise()` and the training "
    "runner. All three switches stay off; every gated cell reports what it would have run."
)
nb.code(setup_cell("17"))

nb.code('''
import json
import math
import re
import shutil
import statistics
import subprocess
import time
from datetime import datetime, timezone

import numpy as np

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

from cosmos_course import finetune

REPO = cc.COSMOS3_REPO
ALLOW_DOWNLOADS = os.environ.get("COSMOS_COURSE_ALLOW_SFT_DOWNLOAD", "0") == "1"
RUN_TRAINING = os.environ.get("COSMOS_COURSE_RUN_SFT", "0") == "1"

MAX_ITER = 20 if MODE == "reduced" else 100
SAVE_ITER = MAX_ITER
TOKEN_CAP = 12288                # down from the shipped 45056. Bisect this.
GRAD_ACCUM = 8                   # up from 2, to recover the global batch

DATASET_PATH = REPO / "examples/data/BridgeData2-Subset-Synthetic-Captions/sft_dataset_bridge"
BASE_CKPT = REPO / "examples/checkpoints/Cosmos3-Edge"
WAN_VAE = REPO / "examples/checkpoints/wan22_vae/Wan2.2_VAE.pth"
TRAIN_OUT = OUTPUT_DIR / "train"
WORK_TOML = OUTPUT_DIR / "vision_sft_edge_1gpu.toml"
LOG_PATH = OUTPUT_DIR / "train.log"

READY = all(p.exists() for p in (DATASET_PATH, BASE_CKPT, WAN_VAE))
print(f"framework repo   : {REPO}  ({'present' if REPO.exists() else 'MISSING'})")
print(f"inputs ready     : {READY}")
print(f"ALLOW_DOWNLOADS  : {ALLOW_DOWNLOADS}")
print(f"RUN_TRAINING     : {RUN_TRAINING}")
print(f"knobs            : max_iter={MAX_ITER} token_cap={TOKEN_CAP} "
      f"grad_accum={GRAD_ACCUM}")
''')

nb.code('''
def finalise(argv, env):
    """Insert the `--` separator and the three required env vars.

    Both halves matter and both fail confusingly. Without `--`, Hydra never
    sees the overrides and the run proceeds at the SHIPPED token cap of 45056 —
    which looks like success right up to the OOM. Without the env vars, the
    TOML's `${oc.env:WAN_VAE_PATH}` interpolation fails before iteration 1
    with an OmegaConf error that names the variable but not the cause: raw
    `torchrun` does not resolve them, only the launch shell does.
    """
    argv = list(argv)
    i = next(k for k, a in enumerate(argv) if a.startswith("--sft-toml="))
    if "--" not in argv:
        argv = argv[:i + 1] + ["--"] + argv[i + 1:]
    env = dict(env)
    env.update({"DATASET_PATH": str(DATASET_PATH),
                "BASE_CHECKPOINT_PATH": str(BASE_CKPT),
                "WAN_VAE_PATH": str(WAN_VAE)})
    env.pop("_COSMOS_COURSE_WARNING", None)
    return argv, env


def run_training(argv, env, log_path, timeout_s=None):
    """Run the training subprocess, tee its output, and return the exit code."""
    full_env = {**os.environ, **env}
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as fh:
        proc = subprocess.Popen(argv, cwd=str(REPO), env=full_env,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in proc.stdout:
            fh.write(line)
            print(line.rstrip())
        proc.wait(timeout=timeout_s)
    return proc.returncode


def gpu_is_clear(threshold_gb=2.0):
    """Anything already resident comes out of your training budget."""
    if not shutil.which("nvidia-smi"):
        return None, "nvidia-smi not available"
    out = subprocess.run(
        ["nvidia-smi", "--query-gpu=memory.used,memory.total",
         "--format=csv,noheader,nounits"],
        capture_output=True, text=True).stdout.strip().splitlines()
    used_mib, total_mib = (float(x) for x in out[0].split(","))
    used_gb = used_mib * (1024 ** 2) / 1e9
    total_gb = total_mib * (1024 ** 2) / 1e9
    return used_gb < threshold_gb, f"{used_gb:.1f} GB used of {total_gb:.1f} GB"


# The working TOML: the shipped recipe with nothing changed. Every deviation
# goes through Hydra overrides, so the diff between shipped and ours is exactly
# the override dict and nothing is hidden in an edited file.
SHIPPED_TOML_SRC = REPO / "examples/toml/sft_config/vision_sft_edge.toml"
if SHIPPED_TOML_SRC.exists():
    WORK_TOML.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SHIPPED_TOML_SRC, WORK_TOML)
    print(f"copied the shipped TOML -> {WORK_TOML.name}")
else:
    print(f"{SHIPPED_TOML_SRC} not found; the command below is still assembled "
          f"so its shape can be checked, and it will not run.")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Run the smoke configuration and report it",
    goal="Execute the 20-iteration configuration, or document precisely why you could "
         "not, and produce a loss curve and a peak-memory figure.",
    success="`training_report.md` exists and contains a prediction made before the run, "
            "the exact command that ran, and either a loss curve or a traceback with a "
            "named cause. Someone else could reproduce the run from it.",
    approach="Record the prediction to disk **first**, assemble the command and assert "
             "on its shape before running anything, and write the report from whatever "
             "actually happened — including nothing.",
)

nb.code('''
# Step 1: what the GPU looked like before. Recorded, not assumed.
clear, gpu_detail = gpu_is_clear()
print(f"GPU: {gpu_detail}")
if clear is False:
    print("  ! Something is already holding VRAM. Find it with:")
    print("      nvidia-smi --query-compute-apps=pid,used_memory --format=csv")
    print("  This is the single most common cause of an OOM that has nothing to "
          "do with your configuration, and it is why the report records this line.")

# The prediction, written to disk BEFORE anything runs and never edited after.
est = finetune.estimate_sft_memory("Cosmos3-Edge", trainable_fraction=0.5,
                                   ema=False, card_gb=80.0)
print()
print(est)

PREDICTION = {
    "predicted_state_gb": round(est.state_gb, 1),
    "my_predicted_peak_gb": 58.0,
    "my_predicted_activations_gb": round(58.0 - est.state_gb, 1),
    "will_it_fit": "yes, narrowly",
    "most_likely_blocker": "max_num_tokens_after_packing",
    "reasoning": (
        "State is about 40 GB with EMA off, leaving roughly 36 GB of the 80 GB "
        "card for activations after a 4 GB reserve. A token cap of 12288 is "
        "about 27% of the shipped 45056, and activation memory is roughly "
        "linear in the cap, so activations should land near 18 GB and fit with "
        "room. The risk is not the mean batch but the WORST packed batch: the "
        "packer fits a different number of samples at each cap and attention is "
        "quadratic in sequence length within a sample, so the peak is set by an "
        "unlucky batch that may not appear in the first few iterations."),
    "config": {"max_iter": MAX_ITER, "token_cap": TOKEN_CAP,
               "grad_accum": GRAD_ACCUM, "ema": False, "compile": False},
    "gpu_state_before": gpu_detail,
    "recorded_at": datetime.now(timezone.utc).isoformat(),
}
pred_path = OUTPUT_DIR / "prediction.json"
pred_path.write_text(json.dumps(PREDICTION, indent=2) + "\\n", encoding="utf-8")
print()
print(f"prediction recorded -> {pred_path.name}")
print("Do not edit it after the run. Edit your understanding instead.")
''')

nb.code('''
overrides = finetune.single_gpu_overrides(token_cap=TOKEN_CAP,
                                          grad_accum=GRAD_ACCUM,
                                          max_iter=MAX_ITER, save_iter=SAVE_ITER)
argv, env = finetune.build_train_command(
    WORK_TOML, repo=REPO, nproc=1, overrides=overrides,
    output_root=TRAIN_OUT, master_port=50012)
ARGV, ENV = finalise(argv, env)

print("$ " + " \\\\\\n    ".join(
    [f"{k}={v}" for k, v in sorted(ENV.items()) if v] + list(ARGV)))
print()

# Assert on the SHAPE of the command before spending anything. Both of these
# failures are the ones hint 1 describes, and the second is the dangerous one:
# missing overrides look like a successful run at the shipped token cap.
assert "--" in ARGV, "the Hydra separator is missing; overrides would be dropped"
for key in ("DATASET_PATH", "BASE_CHECKPOINT_PATH", "WAN_VAE_PATH"):
    assert key in ENV, f"{key} missing; the TOML interpolation will fail"
joined = " ".join(ARGV)
assert f"max_num_tokens_after_packing={TOKEN_CAP}" in joined.replace(" ", ""), \\
    "the token-cap override is not in the command"
assert "ema.enabled=False" in joined or "ema.enabled=false" in joined.lower(), \\
    "EMA is not being disabled; that is 8 GB of state for nothing"
print("PASS the command carries the separator, all three env vars, the token cap "
      "and the EMA override. Nothing has run.")
''')

nb.code('''
RETURNCODE = None
if RUN_TRAINING and READY:
    print(f"starting: max_iter={MAX_ITER}, token_cap={TOKEN_CAP}, "
          f"grad_accum={GRAD_ACCUM}, ema=off, compile=off")
    print("This is undocumented and unvalidated by NVIDIA. Report what happens.")
    RETURNCODE = run_training(ARGV, ENV, LOG_PATH)
else:
    reasons = []
    if not RUN_TRAINING:
        reasons.append("COSMOS_COURSE_RUN_SFT is not set")
    if not READY:
        missing = [str(p) for p in (DATASET_PATH, BASE_CKPT, WAN_VAE)
                   if not p.exists()]
        reasons.append(f"inputs missing: {missing}")
    print("NOT RUN — " + "; ".join(reasons))
    print()
    print("The report below records exactly this, which is a complete answer to "
          "'or document precisely why you could not'.")

SYNTHETIC_LOG = """\\
[SYNTHETIC LOG - not a real run. Do not report these numbers.]
[INFO] loading checkpoint from examples/checkpoints/Cosmos3-Edge
[INFO] trainable parameters: 1.94B of 3.86B (keys_to_select)
[INFO] iter: 1  loss: 0.4132  lr: 2.0e-06
[INFO] iter: 2  loss: 0.4098  lr: 4.0e-06
[INFO] iter: 5  loss: 0.4011  lr: 1.0e-05
[INFO] iter: 10 loss: 0.3874  lr: 2.0e-05
[INFO] iter: 15 loss: 0.3810  lr: 3.0e-05
[INFO] iter: 20 loss: 0.3722  lr: 4.0e-05
[INFO] memory: 61.4 GB peak reserved (allocated 58.9 GB)
[INFO] saving checkpoint to checkpoints/iter_000000020
[INFO] training complete
"""

if LOG_PATH.exists() and RETURNCODE is not None:
    watch_path, log_is_real = LOG_PATH, True
    print(f"\\nparsing YOUR run: {watch_path}")
else:
    watch_path = OUTPUT_DIR / "synthetic_example.log"
    watch_path.write_text(SYNTHETIC_LOG, encoding="utf-8")
    log_is_real = False
    print("\\nparsing the SYNTHETIC example — your run has not happened yet")

watch = finetune.TrainingWatch(watch_path).parse()
print()
print(watch.summary())
''')

nb.code('''
if plt is not None and watch.iters:
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.4))
    suffix = "" if log_is_real else "  (SYNTHETIC)"
    ax[0].plot(watch.iters, watch.losses, marker="o", ms=3)
    ax[0].set_xlabel("iteration")
    ax[0].set_ylabel("loss")
    ax[0].set_title("loss" + suffix)
    ax[0].grid(alpha=.3)
    ax[1].plot(watch.iters, watch.lrs, marker="o", ms=3, color="#e8590c")
    ax[1].set_xlabel("iteration")
    ax[1].set_ylabel("learning rate")
    ax[1].set_title("lr schedule" + suffix)
    ax[1].grid(alpha=.3)
    plt.tight_layout()
    plt.show()
else:
    print("no iterations parsed, or matplotlib absent")
''')

nb.code('''
REPORT = OUTPUT_DIR / "training_report.md"


def write_report(watch, prediction, overrides, returncode, *, extra="",
                 argv=None, env=None, real=True, wall_s=None):
    """Assemble the report. Facts only; interpretation goes in `extra`."""
    lines = [
        "# Lesson 17 — single-GPU SFT attempt",
        "",
        "**This configuration is undocumented by NVIDIA.** It is an experiment.",
        "",
        ("**The log parsed below is SYNTHETIC.** No training ran on this machine, "
         "so every loss and memory number here is illustrative and must not be "
         "reported as a result." if not real else
         "Measured on this machine."),
        "",
        "## Prediction (recorded before the run)",
        "```json", json.dumps(prediction, indent=2), "```",
        "",
        "## The exact command",
        "```",
    ]
    if argv:
        lines += [" ".join(f"{k}={v}" for k, v in sorted((env or {}).items()) if v),
                  " ".join(argv)]
    else:
        lines.append("(not assembled)")
    lines += ["```", "", "## Overrides", "```",
              *[f"{k}={v}" for k, v in overrides.items()], "```", "",
              "## Outcome",
              f"- exit code: {returncode}",
              f"- iterations parsed: {len(watch.iters)}",
              f"- OOM detected in the log: {watch.oom}",
              f"- reached 'training complete': {watch.finished}",
              f"- peak memory reported by the log: {watch.peak_mem_gb} GB",
              f"- wall clock: {f'{wall_s:.0f} s' if wall_s else 'not measured'}",
              f"- GPU state before the run: {prediction.get('gpu_state_before')}"]
    if watch.iters:
        lines += ["", "| iteration | loss | lr |", "|---:|---:|---:|"]
        for it, loss, lr in zip(watch.iters, watch.losses, watch.lrs):
            lines.append(f"| {it} | {loss:.4f} | {lr:.2e} |")
        first, last = watch.losses[0], watch.losses[-1]
        lines += ["",
                  f"loss moved from {first:.4f} to {last:.4f} "
                  f"({100 * (last - first) / first:+.1f}%) over "
                  f"{len(watch.iters)} logged points"]
    if watch.oom:
        lines += ["", "## The traceback", "```",
                  "\\n".join(watch.log_path.read_text(errors='replace')
                            .splitlines()[-25:]), "```"]
    lines += ["", "## Interpretation", extra or "TODO"]
    REPORT.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
    return REPORT


# The interpretation, comparing the prediction against the outcome — written to
# handle all three outcomes, because which one happened is not knowable here.
if watch.oom:
    interpretation = (
        f"The run OOMed. The prediction said it would fit narrowly at a peak of "
        f"{PREDICTION['my_predicted_peak_gb']} GB, and it did not. The named "
        f"blocker in the prediction was `max_num_tokens_after_packing`, and the "
        f"repair is to cut it — by a third rather than by half, adjusting "
        f"`grad_accum_iter` inversely to hold the global batch. Exercise 2 "
        f"bisects for the frontier rather than guessing at it. Note that an OOM "
        f"at iteration 3 rather than iteration 1 supports the prediction's "
        f"reasoning: the peak is set by an unlucky packed batch, not by the mean.")
elif watch.iters and log_is_real:
    peak = watch.peak_mem_gb
    predicted = PREDICTION["my_predicted_peak_gb"]
    error = (100 * (peak - predicted) / predicted) if (peak and predicted) else None
    interpretation = (
        f"The run completed {len(watch.iters)} logged iterations. Predicted peak "
        f"{predicted} GB, measured {peak} GB"
        + (f" ({error:+.0f}%)." if error is not None else ".")
        + " Whether the loss curve means anything is a separate question and the "
          "answer is probably no: twenty iterations at a reduced global batch is "
          "a smoke test, and a loss that falls over twenty steps is consistent "
          "with the learning-rate warm-up alone. Exercise 3 asks whether the "
          "resulting checkpoint differs from the base model, and expects it not to.")
else:
    interpretation = (
        "NOTHING RAN. The inputs, the command and the prediction are all recorded "
        "above, so this report is reproducible: set "
        "COSMOS_COURSE_ALLOW_SFT_DOWNLOAD=1, restart the kernel, run the download "
        "step, then set COSMOS_COURSE_RUN_SFT=1, restart again, and run. The "
        "prediction was made before any of that and must not be edited "
        "afterwards. This is a complete answer to 'or document precisely why you "
        "could not' — what it is not is a result.")

path = write_report(watch, PREDICTION, overrides, RETURNCODE,
                    extra=interpretation, argv=ARGV, env=ENV, real=log_is_real)
print(f"wrote {path}")
print()
print(path.read_text(encoding="utf-8")[:1200])
''')

nb.why(
    "**Why the prediction is written to a file before the command is even "
    "assembled.** Not because anyone will check, but because *you* will not remember what "
    "you believed. A predicted peak of 58 GB and a measured peak of 61 GB is a "
    "calibration you can improve. A predicted peak recalled after seeing 61 GB is 60 GB, "
    "always, and you learn nothing. The lesson's instruction — \"do not edit it after the "
    "run; edit your understanding instead\" — is the entire mechanism.\n\n"
    "**Why the command is asserted on before running.** Hint 1 names two failures and "
    "they are not equally bad. A missing env var produces an OmegaConf error before "
    "iteration 1: loud, immediate, and cheap. A missing `--` separator silently drops "
    "every override, so the run proceeds at the **shipped token cap of 45056** — sized "
    "for eight-way sharding — and OOMs, and you spend an hour tuning a configuration that "
    "was never applied. The assertion on "
    "`max_num_tokens_after_packing={TOKEN_CAP}` costs nothing and makes that impossible.\n\n"
    "**Why the working TOML is a straight copy of the shipped one.** Every deviation goes "
    "through Hydra overrides, so the override dict *is* the complete diff from the "
    "shipped recipe. Editing the TOML would work equally well and would hide half the "
    "changes in a file nobody diffs — and when the run behaves oddly, \"what did I change\" "
    "must be answerable in one place.\n\n"
    "**Why the report handles three outcomes and not one.** The success criteria say a "
    "traceback with a named cause is a complete answer, and the interpretation branch for "
    "an OOM is written out in full rather than left as a TODO. That is the point: on a "
    "configuration NVIDIA does not document, the failing outcome is at least as likely as "
    "the passing one, and a report template that only handles success quietly pressures "
    "you into producing success.\n\n"
    "**One detail in the OOM branch worth noticing.** It says an OOM at iteration 3 "
    "rather than iteration 1 *supports* the prediction's reasoning. That is because the "
    "prediction named the worst packed batch rather than the mean as the risk, and a "
    "failure that arrives a few iterations in is exactly what a variable batch predicts. "
    "A prediction that is confirmed by the *shape* of its failure is more valuable than "
    "one confirmed by a number."
)

nb.extend(
    "The report captures one run. The artefact worth having after a few is a **run "
    "ledger**: one JSONL line per attempt with the overrides, the peak, the outcome and "
    "the prediction, appended rather than overwritten. Exercise 2's `frontier.jsonl` is "
    "exactly that shape for one variable, and generalising it means the question \"what "
    "have I already tried\" becomes a query instead of an archaeology exercise. On a "
    "configuration nobody has documented, that ledger is the documentation."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "Find the token-cap frontier by bisection",
    goal="Determine the largest `max_num_tokens_after_packing` that completes a short run "
         "on your card, and report the frontier with its uncertainty.",
    success="A table of at least five rows with (cap, grad accum, iterations survived, "
            "peak memory, outcome), a plotted peak-versus-cap curve, a stated interval, "
            "and a justified margin for a 500-iteration run.",
    approach="Adjust `grad_accum` inversely to hold the global batch, set `save_iter` far "
             "beyond `max_iter` so failed probes write nothing, and fit the "
             "peak-versus-cap line — which predicts the frontier better than the "
             "bisection does.",
)

nb.code('''
FRONTIER = OUTPUT_DIR / "frontier.jsonl"
PROBE_ITERS = 20        # rule 3: enough that a worst-case packed batch appears
BASE_CAP, BASE_ACCUM = TOKEN_CAP, GRAD_ACCUM


def accum_for(cap, *, base_cap=BASE_CAP, base_accum=BASE_ACCUM):
    """Rule 2: hold the global batch roughly constant.

    Global batch is (tokens per micro-batch) x (accumulation steps). Halving
    the cap therefore needs a doubling of accumulation to compensate, so the
    relationship is INVERSE and proportional — not a reflex doubling whenever
    the cap moves. Rounded to at least 1.
    """
    return max(1, round(base_accum * base_cap / cap))


def relative_global_batch(cap, accum, *, base_cap=BASE_CAP, base_accum=BASE_ACCUM):
    return (cap * accum) / (base_cap * base_accum)


for cap in (4096, 8192, 12288, 16384, 24576):
    accum = accum_for(cap)
    print(f"cap {cap:>6}  accum {accum:>3}  relative global batch "
          f"{relative_global_batch(cap, accum):.2f}x")
assert accum_for(6144) == 16, accum_for(6144)
assert abs(relative_global_batch(6144, accum_for(6144)) - 1.0) < 0.01
print("\\nPASS halving the cap doubles the accumulation and holds the global "
      "batch to within 1%")
''')

nb.code('''
def attempt(token_cap, grad_accum=None, max_iter=PROBE_ITERS):
    """One bisection step. Returns a record; appends it to FRONTIER."""
    grad_accum = grad_accum or accum_for(token_cap)
    # Hint 1: save_iter far beyond max_iter. Otherwise every probe writes a
    # 20-40 GB checkpoint and the disk fills halfway through the bisection —
    # which then looks like a training failure.
    ov = finetune.single_gpu_overrides(token_cap=token_cap, grad_accum=grad_accum,
                                       max_iter=max_iter, save_iter=max_iter * 10)
    a, e = finalise(*finetune.build_train_command(
        WORK_TOML, repo=REPO, nproc=1, overrides=ov,
        output_root=TRAIN_OUT, master_port=50012))
    log = OUTPUT_DIR / f"probe_{token_cap}.log"

    record = {"token_cap": token_cap, "grad_accum": grad_accum,
              "relative_global_batch": round(relative_global_batch(
                  token_cap, grad_accum), 3),
              "max_iter": max_iter, "iters": 0, "peak_gb": None, "oom": None,
              "seconds": None, "outcome": "not run", "measured": False}

    if not (RUN_TRAINING and READY):
        record["outcome"] = "not run (RUN_TRAINING off or inputs missing)"
    else:
        started = time.perf_counter()
        rc = run_training(a, e, log)
        record["seconds"] = round(time.perf_counter() - started, 1)
        watch = finetune.TrainingWatch(log).parse()
        record.update(iters=len(watch.iters), peak_gb=watch.peak_mem_gb,
                      oom=watch.oom, measured=True,
                      outcome=("oom" if watch.oom else
                               "completed" if watch.finished else
                               f"stopped early (exit {rc})"))
    with FRONTIER.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record) + "\\n")
    return record


def bisect_frontier(lo_ok, hi_fail, *, tolerance=1024, max_steps=5):
    """Largest cap that completes. Returns (interval, records)."""
    records = [attempt(lo_ok), attempt(hi_fail)]
    lo, hi = lo_ok, hi_fail
    for _ in range(max_steps):
        if hi - lo <= tolerance:
            break
        mid = int(round((lo + hi) / 2 / 512) * 512)     # keep caps tidy
        if mid in (lo, hi):
            break
        rec = attempt(mid)
        records.append(rec)
        if rec["outcome"] == "completed":
            lo = mid
        else:
            hi = mid
    return (lo, hi), records
''')

nb.code('''
if RUN_TRAINING and READY:
    (lo, hi), rows = bisect_frontier(8192, 32768)
    measured = True
else:
    # PLACEHOLDER ROWS — invented, so the curve fit, the extrapolation and the
    # margin argument can all be exercised. The shape encodes what the
    # mechanism predicts: peak memory roughly linear in the cap, with an
    # intercept equal to the state memory. NOT measurements.
    #
    # Note what that construction costs. Every row below is built as
    # peak = state_gb + cap * 0.00155, so the intercept check in the cell after
    # next is CIRCULAR on this path: it recovers est.state_gb because
    # est.state_gb is what put the numbers there. It cannot fail, and a check
    # that cannot fail is not a check.
    measured = False
    print("PLACEHOLDER FRONTIER — invented rows, not measurements. The fit and "
          "the margin argument below are real; the numbers are not.\\n")
    state_gb = round(est.state_gb, 1)
    rows = []
    for cap, outcome in [(8192, "completed"), (12288, "completed"),
                         (16384, "completed"), (20480, "completed"),
                         (24576, "oom"), (32768, "oom")]:
        peak = state_gb + cap * 0.00155
        rows.append({"token_cap": cap, "grad_accum": accum_for(cap),
                     "relative_global_batch": round(relative_global_batch(
                         cap, accum_for(cap)), 3),
                     "max_iter": PROBE_ITERS,
                     "iters": PROBE_ITERS if outcome == "completed" else 3,
                     "peak_gb": round(peak, 1) if outcome == "completed" else None,
                     "oom": outcome == "oom", "seconds": 240.0,
                     "outcome": outcome, "measured": False, "placeholder": True})
    lo = max(r["token_cap"] for r in rows if r["outcome"] == "completed")
    hi = min(r["token_cap"] for r in rows if r["outcome"] == "oom")
    with FRONTIER.open("w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r) + "\\n")

# One provenance label, computed once and printed on every result derived from
# these rows. A number that does not carry its own provenance gets pasted into
# a report without it, and by then nobody can tell.
DATA_SOURCE = "MEASURED on this machine" if measured else "PLACEHOLDER — invented rows"

print(f"data source: {DATA_SOURCE}\\n")
print(f"{'cap':>7}{'accum':>7}{'rel batch':>11}{'iters':>7}{'peak GB':>10}  outcome")
print("-" * 62)
for r in sorted(rows, key=lambda r: r["token_cap"]):
    peak = f"{r['peak_gb']:.1f}" if r["peak_gb"] else "  -"
    print(f"{r['token_cap']:>7}{r['grad_accum']:>7}"
          f"{r['relative_global_batch']:>11.2f}{r['iters']:>7}{peak:>10}  "
          f"{r['outcome']}")
# This counts POINTS TO FIT and nothing else. Five invented rows are still five
# invented rows: an assertion on the length of a list cannot say where the list
# came from, so passing it certifies no data. Read DATA_SOURCE for that.
assert len(rows) >= 5, (
    f"only {len(rows)} points — a line fit and a plot need at least five to be "
    f"worth drawing. This checks how many points there are, not where they "
    f"came from.")
print(f"\\n[{DATA_SOURCE}] FRONTIER INTERVAL: largest cap that completed = {lo}; "
      f"smallest that failed = {hi}")
print(f"Reported as an interval [{lo}, {hi}], not as a number. The true frontier "
      f"is somewhere inside it and the bisection never visits it.")
if not measured:
    print("That interval is a property of the invented table above. It "
          "describes no card, including yours.")
''')

nb.md(
    "### The intercept check, and when it is worth nothing\n\n"
    "The next cell fits a straight line through the (cap, peak) points and compares the "
    "fitted **intercept** against `est.state_gb`, the state memory Lesson 16 computes from "
    "parameter counts and optimiser state. The idea is sound: at zero tokens there are no "
    "activations, so a correct model puts the intercept at the state memory, and two "
    "numbers arrived at by two independent routes agreeing is evidence that the model "
    "holds.\n\n"
    "**On the placeholder path that comparison is circular, and it is the default path.** "
    "The placeholder rows are generated as `peak = state_gb + cap * 0.00155`. They lie "
    "exactly on a straight line whose intercept is `state_gb`, so fitting a line to them "
    "returns `state_gb` — not because the memory model is right, but because `state_gb` is "
    "what put the numbers there. There is one route, travelled twice. The check cannot "
    "fail, and a check that cannot fail tells you nothing about the world; it tells you "
    "`np.polyfit` can invert a straight line.\n\n"
    "So the intercept line is only a result when `measured` is `True` and `rows` came from "
    "real training runs. The cell prints which path it is on and labels the comparison "
    "accordingly. If the label says PLACEHOLDER, the intercept agreement is not a finding "
    "and must not be reported as one.\n\n"
    "This is worth generalising, because it is easy to build by accident: **whenever a "
    "validity check compares an output against a constant that also went into producing "
    "that output, it is circular.** The way to notice is to ask what result would have "
    "made the check fail. If you cannot construct one, you have not written a check."
)

nb.code('''
# Rule 4: the peak-versus-cap curve is the useful artefact, and its slope
# predicts the frontier better than the bisection does.
#
# READ THE LABEL BEFORE READING THE INTERCEPT. The comparison below puts the
# fitted intercept next to est.state_gb. On the PLACEHOLDER path that is
# CIRCULAR: the rows were built as peak = state_gb + cap * 0.00155, so polyfit
# hands est.state_gb straight back. It is arithmetic, not evidence, and it
# cannot come out any other way. The comparison is a real check only when
# `measured` is True, because only then did the two numbers come from two
# independent routes — a fit to measured peaks, and Lesson 16's parameter
# arithmetic.
fitted = [(r["token_cap"], r["peak_gb"]) for r in rows if r["peak_gb"]]
if len(fitted) >= 2:
    xs = np.array([c for c, _ in fitted], float)
    ys = np.array([p for _, p in fitted], float)
    slope, intercept = np.polyfit(xs, ys, 1)
    print(f"[{DATA_SOURCE}]")
    print(f"fit: peak_gb = {intercept:.1f} + {slope * 1000:.3f} GB per 1000 tokens")
    if measured:
        print(f"     intercept {intercept:.1f} GB vs predicted STATE "
              f"{est.state_gb:.1f} GB — a REAL check here: the intercept comes "
              f"from a line through measured peaks, the state figure comes from "
              f"Lesson 16's parameter arithmetic, and nothing links them except "
              f"the model being right. They should agree, because at zero tokens "
              f"there are no activations. A large disagreement means the fit is "
              f"picking up something other than activation memory.")
    else:
        print(f"     intercept {intercept:.1f} GB vs predicted STATE "
              f"{est.state_gb:.1f} GB — CIRCULAR, so ignore the agreement. The "
              f"placeholder rows were generated from est.state_gb, so the fit "
              f"returns it whatever it is. This line becomes a check the moment "
              f"the rows come from runs; on this path it tests polyfit.")
    CARD_GB, RESERVE_GB = 80.0, 4.0
    predicted_frontier = (CARD_GB - RESERVE_GB - intercept) / slope
    print(f"\\n[{DATA_SOURCE}] extrapolated frontier "
          f"(peak = {CARD_GB - RESERVE_GB:.0f} GB): {predicted_frontier:,.0f} tokens")
    print(f"[{DATA_SOURCE}] bisected interval                : [{lo}, {hi}]")
    print()
    print("Hint 1: the relationship is CLOSE to linear and is not exactly "
          "linear, because the packer fits a different number of samples at "
          "each cap and attention is quadratic in sequence length WITHIN a "
          "sample. So the extrapolation is a hypothesis. Verify it by probing "
          "at the extrapolated value rather than trusting it — that is one run, "
          "and it either confirms the line or tells you where it bends.")

    if plt is not None:
        fig, ax = plt.subplots(figsize=(7, 4))
        ok = [r for r in rows if r["outcome"] == "completed"]
        bad = [r for r in rows if r["outcome"] == "oom"]
        ax.plot([r["token_cap"] for r in ok], [r["peak_gb"] for r in ok], "o-",
                label="completed")
        for r in bad:
            ax.axvline(r["token_cap"], color="#c92a2a", ls=":", alpha=.6)
        grid = np.linspace(min(xs) * 0.5, max(xs) * 2.2, 50)
        ax.plot(grid, intercept + slope * grid, "--", color="grey",
                label="linear fit")
        ax.axhline(CARD_GB - RESERVE_GB, color="#c92a2a",
                   label=f"card - reserve ({CARD_GB - RESERVE_GB:.0f} GB)")
        ax.axvspan(lo, hi, alpha=.12, color="#1971c2", label="frontier interval")
        ax.set_xlabel("max_num_tokens_after_packing")
        ax.set_ylabel("peak memory (GB)")
        ax.set_title("PLACEHOLDER DATA — not a measurement" if not measured
                     else "measured on this machine", fontsize=10)
        ax.legend(fontsize=8)
        plt.tight_layout()
        plt.show()
else:
    slope = intercept = predicted_frontier = None
    print("Not enough peak-memory points to fit a line.")
''')

nb.model_answer(
    "**How much headroom I would leave for a 500-iteration run, and why.**\n\n"
    "**Not the frontier. About 70% of it.** The answer is a rule for reading your own "
    "table, not a cap I can name for you. Take two numbers off the cells above: `lo`, the "
    "largest cap that completed a 20-iteration probe, and the extrapolated frontier the "
    "fit prints. Run 500 iterations at whichever is smaller of **0.7 x the extrapolated "
    "frontier** and **0.8 x `lo`**, rounded down to a multiple of 512. If those two "
    "candidates disagree by more than about 15%, stop and find out why before committing "
    "hours of training: the line and the bisection are describing different machines, and "
    "one of them is wrong.\n\n"
    "*One worked example of the `lo` branch, so the arithmetic is unambiguous — and these "
    "are numbers off the invented placeholder table this notebook prints when training is "
    "off, not a measurement of anything.* In that table `lo` is 20480 and the smallest "
    "failing cap is 24576, so 0.8 x 20480 gives 16384, already a multiple of 512. Whether "
    "that is the binding branch depends on where the fit puts the extrapolated frontier, "
    "which moves with `est.state_gb` and therefore with your model and optimiser — take "
    "the smaller of the two and do not assume it is this one. Substitute your own numbers "
    "and the answer moves with them: a bisection that returned [8192, 12288] gives "
    "0.8 x 8192 = 6553.6, rounded down to **6144**, and that is the correct answer for "
    "that card even though it looks nothing like the example.\n\n"
    "The argument for the margin has four parts and each is a separate risk:\n\n"
    "**1. The probe length is the dominant uncertainty.** Rule 3 says it and the "
    "arithmetic makes it stark: 20 iterations sample 20 packed batches; 500 sample 500. "
    "If the peak is set by the largest batch the packer happens to assemble, then a "
    "20-iteration probe has seen the 95th percentile at best, and the 500-iteration run "
    "will meet something worse. This is not a small correction — batch composition varies "
    "because the packer fits a different number of samples depending on their lengths, "
    "and attention cost is quadratic in sequence length *within* a sample, so the tail is "
    "heavier than the mean suggests.\n\n"
    "**2. The cost of being wrong is asymmetric and large.** A cap 20% below the frontier "
    "costs proportionally more iterations to reach the same global batch — recoverable, "
    "linear, boring. A cap at the frontier that OOMs at iteration 380 costs the entire "
    "run, and on a single GPU that is hours. When one error is linear and the other is "
    "total, the threshold does not sit where the expected values cross.\n\n"
    "**3. The card is not exclusively yours for the whole run.** Anything that grabs even "
    "a gigabyte mid-run — a stray Jupyter kernel, a leftover Reasoner NIM, a monitoring "
    "process — moves the effective ceiling down. The probes were run on a clear card; a "
    "500-iteration run is a much longer window for something to appear.\n\n"
    "**4. Checkpointing is not free and is not in the probes.** `save_iter` was pushed "
    "beyond `max_iter` during bisection precisely so probes would not write checkpoints "
    "(hint 1, and it is what stops the disk filling). But the real run *will* save, and "
    "saving touches memory. The frontier was therefore measured on a configuration that "
    "does strictly less than the one it is being used to size.\n\n"
    "**Why the fitted line is more useful than the bisection.** The bisection gives an "
    "interval and nothing else. The line gives a *mechanism*: peak = state + slope x cap, "
    "with an intercept that should equal the state memory computed in Lesson 16. If it "
    "does, the model is right and the extrapolation is credible. If the intercept comes "
    "out well above the predicted state, the fit is picking up something that is not "
    "activation memory — fragmentation, a workspace, a leak — and that is a more "
    "interesting finding than the frontier.\n\n"
    "**With one condition on that check, and it is not a small one.** Comparing the "
    "intercept against Lesson 16's state figure is only a check when `rows` are "
    "measurements. On the placeholder path the rows are generated from that same state "
    "figure, so the fit returns it by construction and the agreement is circular — see "
    "the note above the fit cell. The cell prints MEASURED or PLACEHOLDER for exactly "
    "this reason. Read the label first; on the placeholder path the intercept line is not "
    "evidence of anything and belongs in no report.\n\n"
    "**And the extrapolation must be verified, not trusted.** Hint 1 is explicit that the "
    "relationship is close to linear and not exactly linear. One probe at the "
    "extrapolated value settles it: either the line holds, or you have located where it "
    "bends, and either outcome is worth one run.\n\n"
    "*If the numbers above came from the placeholder set, none of this is a finding about "
    "Cosmos 3. The structure of the argument is the deliverable; the frontier is yours to "
    "measure.*"
)

nb.extend(
    "The bisection searches one variable while holding the global batch fixed. The "
    "two-dimensional version is more useful: sweep the cap *and* `grad_accum` "
    "independently and plot iterations-per-hour against peak memory. That turns a "
    "feasibility boundary into a **throughput frontier**, and it answers the question you "
    "actually have — not \"what is the largest cap that fits\" but \"what configuration "
    "finishes 500 iterations soonest without OOMing\". Those can have different answers, "
    "because a larger cap costs more memory *and* fewer accumulation steps, and the "
    "wall-clock optimum is not usually at the memory limit."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "Base versus fine-tuned, argued properly",
    goal="Run both models over a held-out prompt set at fixed seeds and make a defensible "
         "argument about whether the fine-tune helped, including what the evidence cannot "
         "establish.",
    success="A written argument with a stated claim, a sample size, a seed-variance "
            "estimate, and a limitations section naming at least three things you cannot "
            "conclude.",
    approach="A **paired** design — same prompt, same seed, both checkpoints — because "
             "pairing cancels the prompt and seed effects and needs far fewer samples "
             "than an unpaired comparison.",
)

nb.code('''
# Step 1: eight held-out prompts, none from the training captions, categorised
# by what they probe. How I ensured they are held out: the training set is
# nvidia/BridgeData2-Subset-Synthetic-Captions, whose captions describe a fixed
# tabletop manipulation setup with a single arm. These were written by hand and
# every one names an object, a setting or a camera behaviour absent from that
# corpus; the near- and out-of-domain ones cannot be in it by construction.
HELD_OUT = [
    ("in_domain", "A robotic gripper lifts a red cube from a white tray, static camera."),
    ("in_domain", "A single-arm robot slides a metal bowl to the left across a bench."),
    ("in_domain", "A gripper closes on a folded blue cloth and lifts it clear."),
    ("near_domain", "A human hand lifts a red cube from a white tray, static camera."),
    ("near_domain", "Two robotic arms hand an object between them over a workbench."),
    ("near_domain", "A robotic gripper works on a reflective glass surface at dusk."),
    ("out_of_domain", "A coastal road at sunset seen from a moving car, no robots."),
    ("out_of_domain", "A wide landscape of rolling hills under fast-moving clouds."),
]
SEEDS = [0, 1, 2, 3]
PRIMARY_SEED = 0

print(f"{len(HELD_OUT)} prompts: "
      f"{sum(1 for c, _ in HELD_OUT if c == 'in_domain')} in-domain, "
      f"{sum(1 for c, _ in HELD_OUT if c == 'near_domain')} near-domain, "
      f"{sum(1 for c, _ in HELD_OUT if c == 'out_of_domain')} out-of-domain")
print(f"seeds: {SEEDS} (all prompts at seed {PRIMARY_SEED}; a subset at all four "
      f"for the variance estimate)")
print()
print("The three categories probe different claims. In-domain asks whether the "
      "fine-tune improved what it trained on. Near-domain asks whether it "
      "generalised. Out-of-domain asks whether it FORGOT anything — a fine-tune "
      "that improves robots and destroys landscapes is a result, and a "
      "comparison with only in-domain prompts cannot see it.")
''')

nb.code('''
FINETUNED_CKPT = TRAIN_OUT / "checkpoints" / f"iter_{MAX_ITER:09d}"
HAVE_FINETUNED = FINETUNED_CKPT.exists()
COMPARE_DIR = OUTPUT_DIR / "compare"


def sweep(checkpoint, prompts, seeds, out_dir, *, label):
    """Generate every (prompt, seed) pair and verify each output."""
    results = []
    generator = cc.Generator(checkpoint=str(checkpoint))
    problems = generator.check(verbose=False)
    for index, (category, prompt) in enumerate(prompts):
        for seed in seeds:
            record = {"checkpoint": label, "prompt_index": index,
                      "category": category, "seed": seed, "path": None,
                      "checks": [], "ok": False, "error": None}
            if problems or not RUN_TRAINING:
                record["error"] = (problems[0][:70] if problems
                                   else "generation not enabled in this notebook")
                results.append(record)
                continue
            spec = cc.InferenceSpec(
                model_mode="text2video", name=f"{label}_p{index}_s{seed}",
                prompt=prompt, resolution="480", aspect_ratio="16,9",
                num_frames=61, num_steps=20, guidance=7.0, seed=seed)
            run = generator.run(spec, out_dir / label, seed=seed, timeout=3600)
            # Step 3: verify EVERY output before looking at any of them.
            checks = cc.verify_result(run, verbose=False)
            record.update(path=str(run.video_path or ""),
                          checks=[{"name": c.name, "passed": c.passed,
                                   "reason": c.reason} for c in checks],
                          ok=bool(run.ok and all(c.passed for c in checks)))
            results.append(record)
    return results


print(f"fine-tuned checkpoint: {FINETUNED_CKPT}")
print(f"  present: {HAVE_FINETUNED}")
if not HAVE_FINETUNED:
    print("  There is no fine-tuned checkpoint, so the comparison cannot be run. "
          "The design, the pairing, the variance estimate and the limitations "
          "below are the deliverable, and they are what the exercise grades.")
''')

nb.code('''
# The comparison metric and its bias, stated before any output exists.
def clip_stats(path):
    """Per-frame motion and per-frame contrast. Two cheap, biased numbers."""
    try:
        import imageio.v3 as iio
        frames = []
        for i, f in enumerate(iio.imiter(str(path))):
            arr = np.asarray(f)
            frames.append(arr.mean(axis=2) if arr.ndim == 3 else arr)
            if len(frames) >= 32:
                break
    except Exception:
        return None
    if len(frames) < 3:
        return None
    motion = float(np.mean([np.abs(frames[i + 1] - frames[i]).mean()
                            for i in range(len(frames) - 1)]))
    contrast = float(np.mean([f.std() for f in frames]))
    return {"motion": motion, "contrast": contrast}


def paired_differences(base_rows, tuned_rows):
    """Per (prompt, seed) differences. Hint 1: pairing cancels prompt and seed."""
    tuned_by_key = {(r["prompt_index"], r["seed"]): r for r in tuned_rows}
    pairs = []
    for b in base_rows:
        t = tuned_by_key.get((b["prompt_index"], b["seed"]))
        if not (t and b.get("ok") and t.get("ok")):
            continue
        bs, ts = clip_stats(b["path"]), clip_stats(t["path"])
        if not bs or not ts:
            continue
        pairs.append({"prompt_index": b["prompt_index"], "category": b["category"],
                      "seed": b["seed"],
                      "d_motion": ts["motion"] - bs["motion"],
                      "d_contrast": ts["contrast"] - bs["contrast"]})
    return pairs


base_rows = sweep(cc.MODEL_TIERS[MODEL]["hf_repo"], HELD_OUT, [PRIMARY_SEED],
                  COMPARE_DIR, label="base") if RUN_TRAINING else []
tuned_rows = sweep(FINETUNED_CKPT, HELD_OUT, [PRIMARY_SEED], COMPARE_DIR,
                   label="finetuned") if (RUN_TRAINING and HAVE_FINETUNED) else []
pairs = paired_differences(base_rows, tuned_rows)

if not pairs:
    print("No pairs. Nothing generated on this machine.")
    print()
    print("What the analysis WOULD do, and why the pairing matters: for each "
          "(prompt, seed) there is exactly one base output and one fine-tuned "
          "output produced under identical conditions, so the prompt effect and "
          "the seed effect cancel in the difference. An unpaired comparison of "
          "8 base clips against 8 fine-tuned ones would be swamped by "
          "between-prompt variance, which is far larger than any effect a "
          "20-iteration fine-tune could produce.")
else:
    d = np.array([p["d_motion"] for p in pairs])
    print(f"paired differences in motion: mean {d.mean():+.4f}, "
          f"sd {d.std(ddof=1):.4f}, n {len(d)}")
''')

nb.code('''
# Seed variance: the same checkpoint, the same prompt, four seeds. This is the
# floor. Any paired difference smaller than it is not a difference.
subset = [(i, p) for i, (c, p) in enumerate(HELD_OUT) if c == "in_domain"][:2]
seed_rows = []
if RUN_TRAINING:
    seed_rows = sweep(cc.MODEL_TIERS[MODEL]["hf_repo"],
                      [HELD_OUT[i] for i, _ in subset], SEEDS, COMPARE_DIR,
                      label="base_seeds")

seed_spread = None
if seed_rows:
    by_prompt = {}
    for r in seed_rows:
        if r.get("ok"):
            stats = clip_stats(r["path"])
            if stats:
                by_prompt.setdefault(r["prompt_index"], []).append(stats["motion"])
    spreads = [max(v) - min(v) for v in by_prompt.values() if len(v) >= 2]
    seed_spread = float(np.mean(spreads)) if spreads else None

if seed_spread is None:
    print("Seed variance not measured (nothing generated).")
    print()
    print("It is NOT optional. Without it, any paired difference you compute is "
          "uninterpretable: a mean difference of 0.4 in a statistic whose "
          "seed-to-seed spread is 1.2 is noise, and the same 0.4 against a "
          "spread of 0.05 is a large effect. The measurement is 2 prompts x 4 "
          "seeds = 8 extra generations on the BASE model only, and it is the "
          "cheapest thing in this exercise.")
else:
    print(f"seed spread (same checkpoint, same prompt, 4 seeds): {seed_spread:.4f}")
    if pairs:
        d = np.array([p["d_motion"] for p in pairs])
        print(f"paired mean difference: {d.mean():+.4f}")
        print(f"ratio to seed spread  : {abs(d.mean()) / seed_spread:.2f}x")
        print("A ratio below 1 means the difference is inside the noise, and the "
              "correct conclusion is 'no detectable difference'.")
''')

nb.model_answer(
    "**The argument, written as it would be if the run had happened.**\n\n"
    "**Claim.** After 20 iterations of generation-pathway SFT on Cosmos3-Edge at a "
    "reduced global batch, I find **no detectable difference** between the base and "
    "fine-tuned checkpoints on an eight-prompt held-out set at a fixed seed, where "
    "\"detectable\" means a paired mean difference exceeding the seed-to-seed spread of "
    "the same statistic on the base model.\n\n"
    "**Method.** Paired design: for each (prompt, seed) there is exactly one base output "
    "and one fine-tuned output, produced with identical resolution, frame count, step "
    "count, guidance and seed. Pairing cancels the prompt and seed effects, which is what "
    "makes eight prompts a usable sample — an unpaired comparison would be swamped by "
    "between-prompt variance. Every output was verified with `cc.verify_result` **before** "
    "any of them was inspected, so a blank clip that would pass an eye test cannot enter "
    "the comparison.\n\n"
    "**Bias of the comparison, stated.** Frame-to-frame motion and per-frame contrast are "
    "cheap statistics that are blind to almost everything a fine-tune would change: they "
    "cannot see whether the gripper looks right, whether the scene matches the prompt, or "
    "whether object identity holds. They are used because they are objective and because "
    "the honest alternative — me watching sixteen clips knowing which is which — is worse, "
    "not better. A reasoner-as-judge score would be a genuine improvement and introduces "
    "its own circularity, which Lesson 04 characterises.\n\n"
    "**Sample size.** 8 prompts x 1 seed = 8 pairs for the primary comparison; 2 prompts x "
    "4 seeds = 8 base generations for the variance estimate. That is small, and it is "
    "sized to detect only a *large* effect. It cannot detect a small one, which matters "
    "because a small real improvement and no improvement lead to the same conclusion here.\n\n"
    "**Why this is the expected result and not a failure.** Twenty iterations at a "
    "reduced global batch is on the order of a few hundred samples through a 2B-parameter "
    "trainable set whose learning rate has not finished warming up (the shipped scheduler "
    "warms up over 50 steps — the run ends before warm-up completes). Expecting a visible "
    "change would be the unreasonable position. The lesson says so in advance, and "
    "reporting \"no detectable difference\" is the result.\n\n"
    "**What this evidence does NOT support** — at least three, as required, and these are "
    "the part that matters:\n\n"
    "1. **That the fine-tune does not work.** Absence of a detectable effect at n = 8 with "
    "a blunt metric is not evidence of absence. A larger effect, a longer run, a "
    "sharper metric or a bigger sample could all reveal one.\n"
    "2. **That it generalises, or fails to, beyond these eight prompts.** The prompts were "
    "written by me, in one sitting, and share whatever assumptions I hold about what a "
    "robot video looks like. Three out-of-domain prompts is a gesture at coverage, not "
    "coverage.\n"
    "3. **That a longer run would help.** Only one training length was run. The claim "
    "\"more iterations would improve it\" is a hypothesis with no evidence in this "
    "experiment, and it is the one everybody asserts anyway.\n"
    "4. **That the checkpoint is the *same* as the base.** No detectable difference in "
    "these two statistics is compatible with substantial changes the statistics cannot "
    "see. Comparing the weight tensors directly would settle whether anything changed at "
    "all, and is a strictly better first check than any generation — if the weights are "
    "identical, the training did not train, and that is a bug rather than a null result.\n\n"
    "**The one thing I would add before running any of this.** A weight diff. "
    "`torch.load` both checkpoints, compare a few tensors, and confirm the optimizer "
    "actually updated the parameters `keys_to_select` selected — and *only* those. It "
    "costs a minute, needs no generation, and distinguishes \"the fine-tune had no "
    "visible effect\" from \"the fine-tune had no effect\", which are completely "
    "different findings and are indistinguishable from the videos."
)

nb.extend(
    "The comparison here is one checkpoint against one baseline. What would make it "
    "scientifically interesting is a **checkpoint series**: save at iterations 5, 10, 20, "
    "50, 100 and run the same paired comparison against the base at each. That converts "
    "the binary \"did it help\" into a trajectory, and a trajectory can answer the "
    "question the single comparison cannot — whether the effect is growing, plateaued, or "
    "absent. It costs disk (each Edge checkpoint is several GB, so plan for it) and "
    "nothing else, since the generations are the same count per point."
)

nb.finish()
