"""Build 14_performance_and_memory.ipynb.

Module 4, lesson 1. Nothing in the source DLI course corresponds to this — it
contains no measurement of any kind, which is precisely the gap.

The thesis of the lesson is that **most reported speedups in ML notebooks are
measurement artefacts**, and the deliverable is a learner who can produce a
number they are willing to defend.

Design decisions worth knowing before editing this file:

* Almost everything runs on **synthetic workloads** — matmuls, convolutions,
  allocations, a child process that allocates VRAM. No checkpoint download, no
  generation, seconds per cell. The concepts land harder when the workload is
  small enough to iterate on, and the lesson stays runnable for someone who
  took Module 1 and skipped Module 2.
* Real generation appears once, behind an opt-in flag, and reuses whatever
  Lesson 06 already measured (`outputs/06/measurements.jsonl` and
  `outputs/06/calibration.json`) rather than re-running it.
* **No number is asserted anywhere.** Every ratio, every gigabyte and every
  ranking in this notebook is produced by a cell on the learner's own machine.
  If you are tempted to write "this is about 100x", write the measurement
  instead.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 14 — Performance and memory")

# =====================================================================
# 1. Title block
# =====================================================================
nb.md("""
# Lesson 14 — Measuring properly

**What you will build.** A timing harness you can defend, a memory profiler that
tells you the truth about a subprocess, and `outputs/14/benchmark_report.json` —
a benchmark of *your* H100 with medians, spreads, a stated methodology and an
honest limitations section.

| | |
|---|---|
| **Time** | ~2.5 hours. Most cells finish in seconds. |
| **GPU** | 1 × H100 80 GB. The synthetic workloads need a few GB; one section deliberately fills the card and then gives it back. |
| **Downloads** | **None.** Everything here is synthetic unless you opt in to the one real-generation section, which reuses what Module 2 already pulled. |
| **Prerequisites** | Modules 0–3, or at least Module 0 plus one of the others. You have run things on this GPU; you have never benchmarked them. |
""")

# =====================================================================
# 2. Learning objectives
# =====================================================================
nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Demonstrate** that a `time.perf_counter()` around a CUDA call times the
   kernel *launch* rather than the kernel, by producing an impossible speedup
   and then removing it with one line.
2. **Measure** the first-call penalty in a fresh process and in a warm one, and
   attribute it to CUDA context creation, kernel autotuning, cuBLAS/cuDNN
   algorithm selection and allocator growth.
3. **Report** a distribution — median and inter-quartile range — instead of a
   single number, and justify the median over the mean with your own samples.
4. **Compare** CUDA event timing against wall-clock timing on the same
   workload, and state which is right for which question.
5. **Separate** load time from compute time and explain why reporting their sum
   as "inference time" makes the number meaningless.
6. **Distinguish** `memory_allocated`, `memory_reserved` and `nvidia-smi` for
   one workload, and explain why the gap between them is cache and not a leak.
7. **Profile** a process you cannot see from inside — the framework generator
   runs out of process — by sampling the device, and state honestly what that
   measurement can and cannot attribute.
8. **Compute** a throughput figure for video generation that means something
   (frames of output per second, latent tokens per second) and distinguish it
   from latency.
9. **Induce** a real CUDA out-of-memory error, catch it, walk `oom_advice()`'s
   ladder, recover, and name the rungs that do not exist on one GPU.
10. **Debug** a benchmark that reports a large speedup which is entirely an
    artefact, find all three bugs in it, and report the real figure.
""")

# =====================================================================
# 3. Environment and prerequisites
# =====================================================================
nb.md("""
## Environment and prerequisites

Two cells, and they are the first thing you run.
""")

nb.code('# This lesson writes to outputs/14/. The setup cell below reads this name.\n'
        '__lesson__ = "14"\n\n' + SETUP_CELL)

nb.code('''
import gc
import json
import statistics
import subprocess
import threading
import time

try:
    import torch
except ImportError:
    torch = None

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None
    print("matplotlib is not installed — the plots below will be skipped.")

from cosmos_course.measure import MeasurementLog

cc.require(
    torch is not None,
    "torch is not installed, so there is nothing to measure.",
    fix="Run scripts/setup.sh, then select the 'Cosmos 3 (H100)' kernel.",
)
cc.require(
    torch.cuda.is_available(),
    "No CUDA device is visible. Every measurement in this lesson is a GPU "
    "measurement; on CPU the lesson has no content.",
    fix="Check `nvidia-smi`, then `torch.cuda.is_available()`, then "
        "`echo $CUDA_VISIBLE_DEVICES` — an inherited value that hides device 0 "
        "is the usual cause on a single-GPU machine.",
)

# torch.OutOfMemoryError is the modern spelling; older builds only have the
# torch.cuda one. Resolve it once rather than guessing in an except clause.
OOM_ERROR = getattr(torch, "OutOfMemoryError", None) or torch.cuda.OutOfMemoryError

props = torch.cuda.get_device_properties(0)
TOTAL_VRAM_GB = props.total_memory / 1e9
free_b, _ = torch.cuda.mem_get_info()

# Reduced mode keeps every synthetic workload to seconds. Full mode buys tighter
# distributions and costs minutes. Both are honest; one is faster to iterate on.
if MODE == "full":
    MATMUL_N, WARM_ITERS, TIMED_ITERS, N_SAMPLES = 8192, 5, 30, 41
else:
    MATMUL_N, WARM_ITERS, TIMED_ITERS, N_SAMPLES = 4096, 3, 15, 21

log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
RESULTS = {}

print(f"device        : {props.name}")
print(f"capability    : sm_{props.major}{props.minor}")
print(f"VRAM          : {TOTAL_VRAM_GB:.1f} GB total, {free_b / 1e9:.1f} GB free right now")
print(f"torch         : {torch.__version__}  (CUDA {torch.version.cuda})")
print(f"mode          : {MODE!r} -> matmul {MATMUL_N}x{MATMUL_N}, "
      f"{TIMED_ITERS} timed iterations, {N_SAMPLES} samples")
print(f"measurements  : {log.path}")

if free_b / props.total_memory < 0.7:
    print()
    print("Less than 70% of the card is free before this lesson has allocated")
    print("anything. Something else owns it — the Reasoner NIM, or an orphaned")
    print("run. `nvidia-smi` will name the process. The memory sections below")
    print("will still work, but the device-wide numbers include that process.")
''')

# =====================================================================
# 4. Conceptual foundation
# =====================================================================
nb.md("""
## Why this lesson exists

That verification cell is strict about needing a CUDA device on purpose: a
measurement lesson with nothing to measure is a reading exercise.

`MODE="reduced"` shrinks the synthetic workloads so every cell finishes in
seconds. `MODE="full"` uses larger matrices and more repeats, which gives
tighter distributions and takes a few minutes longer. Start reduced.

Here is the claim this lesson exists to make good on.

> Most reported speedups in machine-learning notebooks are measurement
> artefacts. Not fraud, not even carelessness — just three specific mistakes
> that every one of us makes the first time, and that produce numbers which are
> confidently, spectacularly wrong.

You are about to make all three deliberately, watch the absurd results they
produce, and then never make them again by accident.

Nothing in this notebook asserts a number. Every figure is produced on your
machine, by you, and any claim the course makes about speed or memory is one you
can check by re-running the cell that made it.
""")

nb.md("""
## The thing that makes GPU timing different

Start from zero, because this is the root of nearly everything that follows.

When you write `c = a @ b` on the CPU, Python does the multiplication and then
returns. The work is finished by the time the next line runs. Time either side
of it and you have timed the work.

A GPU does not work like that. Your Python process (the **host**) and the GPU
(the **device**) are separate processors connected by a queue. `a @ b` on CUDA
tensors does not multiply anything. It writes a *kernel launch* into a queue and
returns immediately, typically in a few microseconds. The GPU picks the work up
whenever it gets to it, and it may still be running long after your Python code
has moved on.

```
   HOST (your Python process)                DEVICE (the H100)
   ---------------------------               ---------------------------
   t=0.000   c = a @ b        --launch-->    [ queued ]
   t=0.00002 return                          [ running ... ]
   t=0.00003 stop the clock  <-- you are here
             print("0.03 ms!")               [ still running ... ]
   t=0.031                                   [ done ]
```

The clock stopped at the arrow. The work finished later — how much later is a
question about your machine, and you will answer it in a few cells. You have
measured the cost of *asking*, not the cost of *doing*.

Before measuring anything with an instrument, find out what the instrument
costs. That is the next cell, and it is the shortest honest measurement in the
lesson.
""")

nb.code('''
# Know your instrument. Two overheads sit inside every timing you will take in
# this lesson, and both are properties of THIS machine, so measure them rather
# than looking them up.
CLOCK_CALLS = 10_000

t0 = time.perf_counter()
for _ in range(CLOCK_CALLS):
    time.perf_counter()
clock_call_s = (time.perf_counter() - t0) / CLOCK_CALLS

# synchronize() on an already-empty queue does no waiting, so what is left is
# the cost of asking the driver "are you finished?".
torch.cuda.synchronize()
empty_syncs = []
for _ in range(50):
    t0 = time.perf_counter()
    torch.cuda.synchronize()
    empty_syncs.append(time.perf_counter() - t0)
empty_sync_s = statistics.median(empty_syncs)

print(f"perf_counter resolution        : {time.get_clock_info('perf_counter').resolution * 1e9:,.0f} ns")
print(f"one perf_counter() call        : {clock_call_s * 1e9:,.0f} ns")
print(f"synchronize() on an empty queue: {empty_sync_s * 1e6:,.1f} us  (median of 50)")
print()
print("Those two numbers are the floor of what you can time honestly. Anything")
print("whose duration is close to them is mostly instrument, not workload — so")
print("time a batch of repetitions and divide, rather than timing one call.")

RESULTS["clock"] = {"perf_counter_call_s": clock_call_s,
                    "empty_sync_s": empty_sync_s}
''')

nb.md("""
### Synchronise before you stop the clock

`torch.cuda.synchronize()` blocks the host until the queue is empty. Putting one
before you start the clock and one before you stop it is the whole fix. It costs
what you just measured, and it is the difference between a number and a fiction.

### Three ways a GPU benchmark lies to you

| Mistake | What you actually measured | Direction of the error |
|---|---|---|
| No synchronisation | kernel launch overhead | your code looks impossibly fast |
| No warm-up | context creation, JIT, cuDNN algorithm search, allocator growth | your code looks slow, and unpredictably so |
| One run, reported as a number | one sample from a noisy distribution | either, and you cannot tell which |

There is a fourth that is not about timing at all: reporting **load time** —
reading tens of gigabytes of weights off NVMe — as part of "inference time".
That is not a subtle statistical issue. It is measuring the wrong thing.
""")

# =====================================================================
# 5. Guided lab — the asynchrony demo
# =====================================================================
nb.md("""
## A workload small enough to argue about

Everything in the first half of this lesson runs on a square matrix
multiplication. That is a deliberate choice, not laziness:

- It is **pure compute**. No file I/O, no Python overhead worth speaking of, no
  randomness in how long it takes. If a measurement of it moves, the measurement
  moved, not the workload.
- Its cost is **arithmetically known**. An $n \\times n$ by $n \\times n$ matmul
  is $2n^3$ floating-point operations. You can divide by your measured seconds
  and get a FLOP/s figure to sanity-check against the H100's published peak — a
  number you should be suspicious of if your benchmark reports more than it.
- It **saturates the GPU**, so it is a fair stand-in for the dense linear algebra
  that dominates a diffusion transformer.

It is not a Cosmos 3 generation. Everything you learn about *how to measure*
transfers; nothing you learn about *how long things take* does. The real
workload appears later, behind an opt-in flag.
""")

nb.code('''
A = torch.randn(MATMUL_N, MATMUL_N, device="cuda", dtype=torch.bfloat16)
B = torch.randn(MATMUL_N, MATMUL_N, device="cuda", dtype=torch.bfloat16)

FLOPS_PER_MATMUL = 2 * MATMUL_N ** 3


def matmul_workload(iters=1):
    """Queue `iters` large matmuls. Returns immediately; the GPU does not."""
    out = None
    for _ in range(iters):
        out = A @ B
    return out


# Warm up ONCE here, so the next demo isolates a single variable. The warm-up
# problem gets its own section; mixing the two would make both unreadable.
matmul_workload(WARM_ITERS)
torch.cuda.synchronize()

print(f"operands      : 2 x {MATMUL_N}x{MATMUL_N} bfloat16 "
      f"= {2 * MATMUL_N * MATMUL_N * 2 / 1e9:.2f} GB")
print(f"arithmetic    : {FLOPS_PER_MATMUL / 1e12:.2f} TFLOP per matmul")
print(f"this cell will queue {TIMED_ITERS} of them per measurement")
print()
print("Warm-up done. The GPU has now selected its cuBLAS algorithm for this")
print("shape and dtype, and the allocator has grown its pool. Both measurements")
print("below start from that same warm state.")
''')

nb.predict_run_explain(
    predict=(
        "The next cell times exactly the same work twice. The first timing has "
        "no `torch.cuda.synchronize()` before the clock stops; the second has "
        "one. Write down the ratio you expect between them — the \"speedup\" the "
        "naive version will appear to report. Is it 1.1x? 2x? 10x? More? Commit "
        "to an order of magnitude before you run it."
    ),
    change=(
        "Nothing to edit. Run the cell and compare your number against the "
        "measured ratio."
    ),
    explain=(
        "Explain the ratio in terms of what the host actually did during the "
        "unsynchronised timing. Then answer this: does the ratio depend on "
        "`TIMED_ITERS`? Change it to 1 and to 50 and find out, and say why the "
        "answer is what it is."
    ),
    hint=(
        "Time the *launch* of a kernel and you are timing a few microseconds of "
        "host-side bookkeeping — writing a command into a queue. Time the "
        "*execution* and you are timing the matmul. Both numbers are real; only "
        "one of them is an answer to the question 'how long does this take?'\\n\\n"
        "For the second part: launching costs roughly the same per iteration "
        "however long the kernel runs, and the queue is deep enough that the "
        "host does not have to wait. So what happens to the ratio as you queue "
        "more work?"
    ),
)

nb.code('''
# ---- the mistake -----------------------------------------------------------
torch.cuda.synchronize()                      # start from an empty queue
t0 = time.perf_counter()
matmul_workload(TIMED_ITERS)
naive_s = time.perf_counter() - t0            # <-- clock stops before the GPU does

# This sync is NOT part of the naive measurement. It is here because the work is
# still running, and without it the honest measurement below would inherit it.
torch.cuda.synchronize()

# ---- the fix ---------------------------------------------------------------
torch.cuda.synchronize()
t0 = time.perf_counter()
matmul_workload(TIMED_ITERS)
torch.cuda.synchronize()                      # <-- wait for the work to finish
honest_s = time.perf_counter() - t0

RESULTS["async"] = {"naive_s": naive_s, "honest_s": honest_s,
                    "iters": TIMED_ITERS}

total_flops = FLOPS_PER_MATMUL * TIMED_ITERS
print(f"naive   (no synchronize) : {naive_s * 1e3:10.3f} ms  "
      f"-> {total_flops / naive_s / 1e12:12,.0f} TFLOP/s")
print(f"honest  (synchronized)   : {honest_s * 1e3:10.3f} ms  "
      f"-> {total_flops / honest_s / 1e12:12,.0f} TFLOP/s")
print()
print(f"apparent 'speedup' of doing nothing differently: {honest_s / naive_s:,.1f}x")
print()
print("Check the TFLOP/s column against the published peak for this card before")
print("you believe either row. A benchmark reporting more arithmetic than the")
print("silicon can perform has told you it is wrong, in the clearest terms")
print("available. That is a gift; most broken benchmarks are merely plausible.")
''')

nb.md("""
### What just happened

The naive timing measured how long it took the host to write `TIMED_ITERS`
kernel launches into a queue. That is real work and it takes real time, but it
is not the matmul. The GPU was still busy when the clock stopped.

This is the single most common way a speedup gets invented. The pattern is
always the same shape: someone changes something, times it without
synchronising, and the "optimised" version comes out faster because it queued
its work slightly more efficiently — or, more often, because the *baseline* was
accidentally synchronised by something (a `.item()`, a `print` of a tensor, a
`.cpu()`) and the candidate was not.

Any of these force a synchronisation without saying so:

| Call | Why it synchronises |
|---|---|
| `tensor.item()` | has to read a device value into a Python float |
| `float(tensor)` / `tensor.cpu()` / `.numpy()` | copies device memory to host |
| `print(tensor)` | formats the values, so it reads them |
| `torch.cuda.memory_allocated()` | no, this one does **not** — it reads the allocator's bookkeeping |

That last row matters: you can read memory statistics inside a timed region
without perturbing it. You cannot print a loss.

<div style="border-left:4px solid #e8590c;padding:.6em 1em;margin:1em 0;background:rgba(128,128,128,.08);border-radius:0 4px 4px 0">

**Gotcha** — the failure mode is worse than a wrong number, because it is
*directional*. A benchmark with no synchronisation systematically favours
whichever side queues more work before something forces a sync. If your
candidate implementation happens to avoid a `.item()` that your baseline has,
you will measure a large speedup that is entirely the missing `.item()`. This
is how a change that made nothing faster gets merged.

</div>
""")

# =====================================================================
# Warm-up
# =====================================================================
nb.md("""
## The first call is not like the others

The second lie. The first time a process touches CUDA it pays for a pile of
one-off setup that never happens again:

- **CUDA context creation** — the driver builds per-process state on the device.
  This also permanently costs you a few hundred megabytes of VRAM, which is why
  `nvidia-smi` shows a process using memory before it has allocated a tensor.
- **Module loading and kernel JIT** — the fat binary for your architecture gets
  loaded, and anything not precompiled for `sm_90` is compiled now.
- **cuBLAS / cuDNN algorithm selection** — these libraries have many kernels for
  the same operation and pick between them at first use, sometimes by *running*
  several and keeping the fastest. That is `torch.backends.cudnn.benchmark`, and
  it is a genuine autotune with a genuine cost.
- **Allocator pool growth** — the first allocation of a given size calls
  `cudaMalloc`, which is slow and synchronising. The second reuses the pool.

The next two cells measure both halves of this: the fresh-process cost, which
you can only see from outside, and the in-process first-call cost, which you can
see from here.
""")

nb.code('''
# ---- part 1: the cost a fresh process pays, measured from outside -----------
# A subprocess is the only honest way to measure context creation: this kernel
# created its context long ago and cannot un-create it.
CONTEXT_PROBE = """
import json, time
t0 = time.perf_counter()
import torch
t_import = time.perf_counter() - t0

t0 = time.perf_counter()
torch.cuda.init()
x = torch.ones(1, device="cuda")
torch.cuda.synchronize()
t_context = time.perf_counter() - t0

a = torch.randn(2048, 2048, device="cuda", dtype=torch.bfloat16)
t0 = time.perf_counter()
c = a @ a
torch.cuda.synchronize()
t_first_matmul = time.perf_counter() - t0

t0 = time.perf_counter()
c = a @ a
torch.cuda.synchronize()
t_second_matmul = time.perf_counter() - t0

print(json.dumps({
    "import_torch_s": t_import,
    "context_plus_first_alloc_s": t_context,
    "first_matmul_s": t_first_matmul,
    "second_matmul_s": t_second_matmul,
    "context_vram_gb": torch.cuda.memory_reserved() / 1e9,
}))
"""

proc = subprocess.run([sys.executable, "-c", CONTEXT_PROBE],
                      capture_output=True, text=True, timeout=600)
if proc.returncode == 0 and proc.stdout.strip():
    cold = json.loads(proc.stdout.strip().splitlines()[-1])
    RESULTS["cold_start"] = cold
    print("A FRESH PROCESS, measured from outside:")
    for key, value in cold.items():
        unit = "GB" if key.endswith("_gb") else "s"
        print(f"  {key:<28} {value:10.4f} {unit}")
    ratio = cold["first_matmul_s"] / max(cold["second_matmul_s"], 1e-9)
    print()
    print(f"  first matmul / second matmul in that process: {ratio:,.1f}x")
else:
    cold = {}
    print("probe failed; stderr tail:")
    print((proc.stderr or "")[-800:])
''')

nb.code('''
# ---- part 2: the first call at a NEW shape, in this warm process ------------
# The context exists and torch is imported. What is left is algorithm selection
# and allocator growth, and cuDNN's autotune makes that visible.
torch.backends.cudnn.benchmark = True

conv = torch.nn.Conv2d(64, 128, kernel_size=3, padding=1).cuda().to(torch.float16)
x = torch.randn(16, 64, 256, 256, device="cuda", dtype=torch.float16)

per_call = []
with torch.no_grad():
    for _ in range(10):
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        conv(x)
        torch.cuda.synchronize()
        per_call.append(time.perf_counter() - t0)

RESULTS["warmup"] = {"per_call_s": [round(s, 6) for s in per_call]}

print("cuDNN convolution, same input, ten times in a row:")
for i, seconds in enumerate(per_call):
    bar = "#" * max(1, int(60 * seconds / max(per_call)))
    print(f"  call {i:>2}: {seconds * 1e3:9.3f} ms  {bar}")

steady = statistics.median(per_call[1:])
print()
print(f"  first call         : {per_call[0] * 1e3:9.3f} ms")
print(f"  median of the rest : {steady * 1e3:9.3f} ms")
print(f"  first-call penalty : {per_call[0] / steady:,.1f}x")
print()
print("cudnn.benchmark=True is why the first call is expensive: cuDNN times")
print("several algorithms for this exact shape and keeps the winner. Change the")
print("input shape and it pays again — which is why a model with variable input")
print("sizes and benchmark=True can be slower than one without it.")
''')

nb.md("""
### What this does to a short benchmark

Suppose you benchmark something by running it five times and taking the mean,
and you forgot to warm up. The first call is one fifth of your samples and it is
the one that paid for everything. The cell below does that arithmetic on the
convolution numbers you just measured — no assumption, your data.

The correct shape of a benchmark is: **warm up outside the timed region, then
measure.** `cosmos_course.measure.benchmark()` does exactly that, with
`warmup=1` by default. One warm-up call is usually enough for a fixed shape; it
is not enough if your workload has several shapes, because each one autotunes
separately.
""")

nb.code('''
naive_mean = statistics.mean(per_call[:5])
warm_median = statistics.median(per_call[1:])

print(f"reported as 'mean of 5 runs, no warm-up' : {naive_mean * 1e3:9.3f} ms")
print(f"reported as 'median after warm-up'       : {warm_median * 1e3:9.3f} ms")
print(f"inflation from the first call            : {naive_mean / warm_median:,.2f}x")
print()
print("Both numbers came from the same ten measurements. The difference is")
print("entirely which ones were included. This is why a methodology section is")
print("not bureaucracy — without it, a reader cannot tell these two apart.")
''')

# =====================================================================
# Distribution
# =====================================================================
nb.md("""
## One number is not a measurement

The third lie is subtler than the first two and it is the one that survives
peer review. You warm up, you synchronise, you run it once, and you report
"12.4 seconds". But an H100 in a warm rack under sustained load throttles; your
machine has other processes; the allocator's state differs between runs. What
you have is one sample from a distribution, presented as a constant.

Run it many times and report:

- the **median**, because it does not move when one run is slow;
- the **inter-quartile range** (IQR — the 25th to 75th percentile span), because
  it tells a reader how much to trust the median;
- optionally the min, which is the closest thing to "what this machine can do
  when nothing else is happening".

Why the median rather than the mean? Because the noise here is **one-sided**.
Nothing makes a run finish faster than the hardware allows, but plenty of things
make one run slow: a clock or power excursion, another process waking up, a page
fault on first touch. A mean absorbs every one of those; a median ignores them
unless they happen to more than half your samples.
""")

nb.code('''
def timed_matmul_once():
    """One honest sample: synchronised either side, warm on entry."""
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    matmul_workload(1)
    torch.cuda.synchronize()
    return time.perf_counter() - t0


matmul_workload(WARM_ITERS)                  # warm-up, outside the samples
torch.cuda.synchronize()

samples = sorted(timed_matmul_once() for _ in range(N_SAMPLES))


def quartiles(values):
    """Median and IQR without a dependency. values must be sorted."""
    n = len(values)
    med = statistics.median(values)
    lower = values[: n // 2]
    upper = values[(n + 1) // 2:]
    return med, statistics.median(lower), statistics.median(upper)


median_s, q1_s, q3_s = quartiles(samples)
RESULTS["distribution"] = {
    "n": len(samples), "median_s": median_s, "q1_s": q1_s, "q3_s": q3_s,
    "min_s": samples[0], "max_s": samples[-1],
    "mean_s": statistics.mean(samples),
}

print(f"n           : {len(samples)}")
print(f"min         : {samples[0] * 1e3:9.3f} ms")
print(f"q1          : {q1_s * 1e3:9.3f} ms")
print(f"median      : {median_s * 1e3:9.3f} ms")
print(f"q3          : {q3_s * 1e3:9.3f} ms")
print(f"max         : {samples[-1] * 1e3:9.3f} ms")
print(f"mean        : {statistics.mean(samples) * 1e3:9.3f} ms")
print()
print(f"IQR         : {(q3_s - q1_s) * 1e3:9.3f} ms "
      f"({100 * (q3_s - q1_s) / median_s:.1f}% of the median)")
print(f"full spread : {(samples[-1] - samples[0]) * 1e3:9.3f} ms "
      f"({100 * (samples[-1] - samples[0]) / median_s:.1f}% of the median)")
print()
print("Compare the IQR against the full spread. If the full spread is several")
print("times the IQR, most of your samples agree and a few do not — which is")
print("exactly the shape that makes a mean untrustworthy and a median fine.")
''')

nb.code('''
# How fragile is each statistic? Take YOUR samples and add one slow run — a
# duplicate of your own worst sample. No fabricated data; just your own tail,
# counted twice.
perturbed = sorted(samples + [samples[-1]])

print(f"{'statistic':<12} {'as measured':>14} {'with one more slow run':>24} {'shift':>10}")
for name, fn in (("median", statistics.median), ("mean", statistics.mean)):
    before, after = fn(samples), fn(perturbed)
    print(f"{name:<12} {before * 1e3:>13.3f}ms {after * 1e3:>23.3f}ms "
          f"{100 * (after - before) / before:>9.2f}%")

print()
print("Now do it the other way round: what would each statistic report if your")
print("machine had been perfectly quiet and the slowest sample never happened?")
trimmed = samples[:-1]
for name, fn in (("median", statistics.median), ("mean", statistics.mean)):
    print(f"  {name:<8} without the worst sample: {fn(trimmed) * 1e3:9.3f} ms")

if plt is not None:
    fig, ax = plt.subplots(figsize=(7, 2.6))
    ax.eventplot([[s * 1e3 for s in samples]], colors="C0", lineoffsets=0, linelengths=0.8)
    ax.axvline(median_s * 1e3, color="C3", label="median")
    ax.axvspan(q1_s * 1e3, q3_s * 1e3, color="C3", alpha=0.15, label="IQR")
    ax.set_xlabel("milliseconds per matmul")
    ax.set_yticks([])
    ax.legend(loc="upper right", fontsize=8)
    ax.set_title(f"{len(samples)} samples of the same operation")
    plt.tight_layout()
    plt.show()
''')

nb.md("""
### The course helper does this for you

`cosmos_course.measure.benchmark()` takes a callable, runs it `warmup` times
outside the timed region, then times it `repeats` times with a synchronise
either side of each, and returns the median plus the spread. It also prints a
warning when the run-to-run spread exceeds 25% of the median, because at that
point the number is soft and you should say so rather than quoting three decimal
places.

Cross-check it against your hand-rolled statistics. If the two disagree by more
than the IQR you measured, one of them is wrong and it is worth finding out
which — `measure.py` is course material, not a black box, and you are allowed to
disagree with it.
""")

nb.code('''
result = cc.benchmark(lambda: matmul_workload(1),
                      label="matmul (measure.benchmark)",
                      warmup=WARM_ITERS, repeats=min(N_SAMPLES, 15))

print()
print(f"hand-rolled median : {median_s * 1e3:9.3f} ms  (n={len(samples)})")
print(f"benchmark() median : {result['median_s'] * 1e3:9.3f} ms  (n={result['repeats']})")
delta = abs(result["median_s"] - median_s)
print(f"difference         : {delta * 1e3:9.3f} ms "
      f"({100 * delta / median_s:.1f}% of the median, IQR is "
      f"{100 * (q3_s - q1_s) / median_s:.1f}%)")

log.record(label="matmul_median", model=MODEL, mode=MODE,
           median_s=result["median_s"], repeats=result["repeats"],
           matmul_n=MATMUL_N, dtype="bfloat16")
''')

nb.checkpoint(
    "Your two medians should agree to well inside the IQR you measured, and the "
    "TFLOP/s implied by the honest timing should be *below* the published peak "
    "for this card. If either fails, stop here — everything after this point "
    "assumes your harness is sound.",
    '''
implied_tflops = FLOPS_PER_MATMUL / median_s / 1e12
iqr_s = q3_s - q1_s

print(f"implied throughput      : {implied_tflops:,.0f} TFLOP/s (bf16 matmul)")
print(f"medians agree to        : {abs(result['median_s'] - median_s) * 1e3:.3f} ms")
print(f"your IQR                : {iqr_s * 1e3:.3f} ms")
print()
ok_medians = abs(result["median_s"] - median_s) <= max(iqr_s, 1e-4)
print(f"  {'PASS' if ok_medians else 'CHECK'}  the two harnesses agree")
print("  ----  compare the throughput above against this card's published bf16")
print("        peak. Above it means a bug; far below it can mean a small matrix,")
print("        a thermal cap, or another process. Say which one you think it is.")
''')

# =====================================================================
# CUDA events
# =====================================================================
nb.md("""
## CUDA events: asking the device what time it is

Wall-clock timing with synchronisation works, but it measures a host-side
interval that *contains* the device work. It therefore includes launch overhead,
the sync itself, and any host hiccup in between. For a workload that runs for
seconds that is irrelevant; for a kernel that runs for 200 microseconds it is
most of your measurement.

CUDA **events** are markers you push into the stream. The device timestamps them
as it reaches them, and `elapsed_time()` gives you the device-side interval
between two of them, in milliseconds.

```
  stream:  [ start_event ][ kernel ][ kernel ][ end_event ]
                     |__________________________|
                        elapsed_time(), device clock
```

Two properties that matter:

- You still need **one** synchronise before reading the result, because the
  events have not been recorded until the device gets to them. But you need one
  per *measurement batch*, not one per iteration.
- Events measure device time only. If your host is the bottleneck — a Python
  loop too slow to keep the GPU fed — events will look fast while your wall
  clock crawls, and the events are not lying. They are answering a different
  question.

**Which to use.** Wall clock answers "how long did my user wait?". Events answer
"how long did the device spend on this kernel?". Report wall clock for a
generation run. Report events when you are comparing two kernels.

<div style="border-left:4px solid #5f3dc4;padding:.6em 1em;margin:1em 0;background:rgba(128,128,128,.08);border-radius:0 4px 4px 0">

**Go deeper** — events are also how you time a *region* of a longer run without
stopping the pipeline. Record an event before and after the denoising loop
inside an inference run and you get the loop's device time without a host sync
per step — which matters, because a host sync per step serialises the host and
device and can change the thing you are measuring. That is the observer effect,
and it is real: a heavily instrumented run is a different run.

</div>
""")

nb.code('''
def time_with_events(fn, iters):
    """Per-iteration device time, one host sync for the whole batch."""
    starts = [torch.cuda.Event(enable_timing=True) for _ in range(iters)]
    ends = [torch.cuda.Event(enable_timing=True) for _ in range(iters)]
    torch.cuda.synchronize()
    for i in range(iters):
        starts[i].record()
        fn()
        ends[i].record()
    torch.cuda.synchronize()                       # exactly one sync
    return [starts[i].elapsed_time(ends[i]) / 1e3 for i in range(iters)]


def time_with_wall_clock(fn, iters):
    """Per-iteration host time, one sync per iteration."""
    out = []
    torch.cuda.synchronize()
    for _ in range(iters):
        t0 = time.perf_counter()
        fn()
        torch.cuda.synchronize()
        out.append(time.perf_counter() - t0)
    return out


matmul_workload(WARM_ITERS)
torch.cuda.synchronize()

event_s = time_with_events(lambda: matmul_workload(1), TIMED_ITERS)
wall_s = time_with_wall_clock(lambda: matmul_workload(1), TIMED_ITERS)

RESULTS["events"] = {"event_median_s": statistics.median(event_s),
                     "wall_median_s": statistics.median(wall_s)}

print(f"{'':<22} {'median':>12} {'min':>12} {'total':>12}")
for name, series in (("cuda events (device)", event_s), ("wall clock (host)", wall_s)):
    print(f"{name:<22} {statistics.median(series) * 1e3:>11.3f}ms "
          f"{min(series) * 1e3:>11.3f}ms {sum(series) * 1e3:>11.3f}ms")

gap = statistics.median(wall_s) - statistics.median(event_s)
print()
print(f"per-iteration gap (wall - event): {gap * 1e6:,.0f} microseconds")
print()
print("That gap is launch overhead plus the cost of the synchronise itself.")
print("Whether it matters is a ratio question: compare it against your median.")
print("For a workload that runs for minutes it is nothing. For a 100-microsecond")
print("kernel it is the measurement.")
''')

# =====================================================================
# Load vs compute
# =====================================================================
nb.md("""
## Reading 35 GB off a disk is not inference

Cosmos3-Nano is ~34.9 GB of safetensors. Loading it means reading those bytes
from NVMe, deserialising them, and copying them to the device over PCIe. None of
that is inference, and none of it scales with your prompt, your resolution or
your step count.

Report the sum as "inference time" and every conclusion you draw is wrong:

- the cost of a *second* generation looks the same as the first, when it is not;
- doubling `num_steps` appears to be sublinear, because the fixed cost dilutes it;
- a model that loads faster looks like a model that generates faster.

Lesson 06 already separated these for real generation — the `fixed_overhead_s`
in `outputs/06/calibration.json` is exactly this cost. Here, measure the shape
of it on a synthetic weight file so you can see the parts.

One honest caveat up front: this cell writes the file and then reads it, so the
"cold" read is served from the host page cache and is a **lower bound**, not a
true cold read. A genuine cold-read measurement needs the cache dropped
(`vmtouch -e <file>`, or root and `/proc/sys/vm/drop_caches`), which this
notebook will not do to your machine. The cell says so rather than quietly
reporting an optimistic number.
""")

nb.code('''
WEIGHTS_PATH = OUTPUT_DIR / "synthetic_weights.pt"
WEIGHT_MB = 512 if MODE == "full" else 256
n_elements = WEIGHT_MB * 1024 * 1024 // 2                       # bfloat16 = 2 bytes

state = {"w": torch.randn(n_elements, dtype=torch.bfloat16)}    # on the host
torch.save(state, WEIGHTS_PATH)
del state
gc.collect()

t0 = time.perf_counter()
loaded = torch.load(WEIGHTS_PATH, map_location="cpu", weights_only=True)
read_1_s = time.perf_counter() - t0

del loaded
gc.collect()
t0 = time.perf_counter()
loaded = torch.load(WEIGHTS_PATH, map_location="cpu", weights_only=True)
read_2_s = time.perf_counter() - t0

torch.cuda.synchronize()
t0 = time.perf_counter()
on_device = loaded["w"].to("cuda", non_blocking=False)
torch.cuda.synchronize()
h2d_s = time.perf_counter() - t0

side = 2048
mat = on_device[: side * side].reshape(side, side).clone()
matmul_compute = lambda: mat @ mat
matmul_compute()
torch.cuda.synchronize()
compute_s = statistics.median(time_with_events(matmul_compute, 10))

RESULTS["load_vs_compute"] = {
    "file_mb": WEIGHT_MB, "read_1_s": read_1_s, "read_2_s": read_2_s,
    "h2d_s": h2d_s, "compute_s": compute_s,
}

print(f"file                       : {WEIGHT_MB} MB of bfloat16")
print(f"read from disk, first time : {read_1_s:8.3f} s  "
      f"({WEIGHT_MB / read_1_s:7.0f} MB/s)")
print(f"read again (page cache)    : {read_2_s:8.3f} s  "
      f"({WEIGHT_MB / read_2_s:7.0f} MB/s)")
print(f"host -> device copy        : {h2d_s:8.3f} s  "
      f"({WEIGHT_MB / h2d_s / 1024:7.2f} GB/s over PCIe)")
print(f"one {side}x{side} matmul on it : {compute_s * 1e3:8.3f} ms")
print()
print("Extrapolate the read rate to a real checkpoint yourself:")
for name, tier in cc.MODEL_TIERS.items():
    gb = tier["download_gb"]
    print(f"  {name:<16} {gb:>6.1f} GB at your measured rate: "
          f"{gb * 1024 / (WEIGHT_MB / read_2_s) / 60:6.1f} min (warm cache)")
print()
print("This is an extrapolation from one small file, not a measurement of a")
print("real checkpoint load. Large safetensors files are read differently")
print("(memory-mapped, often in parallel shards), so treat it as an order of")
print("magnitude and measure the real thing when you care.")

del on_device, mat, loaded
gc.collect()
torch.cuda.empty_cache()
''')

# =====================================================================
# Memory
# =====================================================================
nb.md("""
## Memory on a discrete GPU, properly

Your H100 is a **discrete** GPU: it has its own HBM framebuffer, physically
separate from host RAM. That makes the tools straightforward — `nvidia-smi`
reports real per-device VRAM and `torch.cuda.mem_get_info()` returns real
free/total. There is no unified-memory weirdness to account for here (if you
ever move to a GB10 or GH200, read the module docstring in
`cosmos_course/measure.py` first, because none of what follows holds there).

So the problem is not the tools. It is PyTorch's **caching allocator**, and it
catches nearly everyone exactly once.

### And memory, which lies differently

Three tools report three different numbers for the same workload, and all three
are correct:

| Reading | What it means |
|---|---|
| `torch.cuda.memory_allocated()` | bytes held by **live tensors** right now |
| `torch.cuda.memory_reserved()` | bytes PyTorch has taken from the driver and is **keeping in its pool** |
| `nvidia-smi` | what the **whole device** is holding: every process's reserved pool, plus each process's CUDA context |

`reserved - allocated` is memory your process owns that no tensor is using.
Nearly everyone meets that number for the first time in a bug report titled
"PyTorch is leaking memory". It is not a leak. It is cache, and you are about to
measure it yourself.

Start by reading all three numbers for a device that is doing nothing.
""")

nb.code('''
torch.cuda.empty_cache()
baseline = cc.describe_memory("baseline (nothing allocated by us)")

print()
print(f"allocated  {baseline.torch_allocated_gb:.3f} GB   <- live tensors in THIS process")
print(f"reserved   {baseline.torch_reserved_gb:.3f} GB   <- pool this process holds from the driver")
print(f"nvidia-smi {(baseline.smi_used_gb or float('nan')):.3f} GB   <- the WHOLE device, all processes, + contexts")
''')

nb.predict_run_explain(
    predict=(
        "The next cell allocates a 4 GiB tensor on the GPU, reads the three "
        "memory numbers, then deletes the tensor and reads them again. Write "
        "down what you expect `memory_allocated()` and `memory_reserved()` to "
        "be **after the delete**. Most people get one of these two right."
    ),
    change=(
        "Nothing to edit. Commit both numbers — allocated and reserved — before "
        "you run it."
    ),
    explain=(
        "One of them went back to roughly where it started and one did not. "
        "Explain why the allocator behaves that way, and then answer the "
        "consequence: if you are about to launch a subprocess that needs 40 GB, "
        "does the number that stayed high matter to it? (Careful — this one has "
        "a real answer and it is not the obvious one.)"
    ),
    hint=(
        "`cudaMalloc` and `cudaFree` are slow and they synchronise the device. "
        "An allocator that called them on every tensor would spend more time "
        "allocating than computing. So what would you do instead, if you were "
        "writing the allocator?\\n\\n"
        "For the consequence: memory held by *this process* is not available to "
        "*another* process, no matter which of PyTorch's counters it shows up "
        "in. That is why the course stops the NIM before generating."
    ),
)

nb.code('''
GIB = 1024 ** 3
elements = 4 * GIB // 4                                  # 4 GiB of float32

torch.cuda.empty_cache()
torch.cuda.reset_peak_memory_stats()
before = cc.memory_snapshot(include_smi=True)

big = torch.empty(elements, dtype=torch.float32, device="cuda")
during = cc.memory_snapshot(include_smi=True)

del big
gc.collect()
after_delete = cc.memory_snapshot(include_smi=True)

torch.cuda.empty_cache()
after_empty = cc.memory_snapshot(include_smi=True)

rows = [("before allocation", before), ("4 GiB tensor alive", during),
        ("after `del`", after_delete), ("after empty_cache()", after_empty)]

print(f"{'':<22} {'allocated':>11} {'reserved':>11} {'unused':>11} {'nvidia-smi':>12}")
for label, probe in rows:
    print(f"{label:<22} {probe.torch_allocated_gb:>10.2f}G "
          f"{probe.torch_reserved_gb:>10.2f}G "
          f"{probe.reserved_unused_gb:>10.2f}G "
          f"{(probe.smi_used_gb if probe.smi_used_gb is not None else float('nan')):>11.2f}G")

RESULTS["allocator"] = {label: {
    "allocated_gb": p.torch_allocated_gb, "reserved_gb": p.torch_reserved_gb,
    "unused_gb": p.reserved_unused_gb, "smi_gb": p.smi_used_gb,
} for label, p in rows}

print()
cc.describe_memory("after `del`, before empty_cache", include_smi=False)
''')

nb.md("""
### What the allocator is doing, and why it is right

`cudaMalloc` and `cudaFree` are expensive: they take a driver lock and they
synchronise the device. A framework that called them for every intermediate
tensor in a transformer block would spend a large fraction of its time in the
driver.

So PyTorch reserves large **segments** from the driver and sub-allocates your
tensors out of them. When you delete a tensor, the block is marked free *inside
the pool* and kept for reuse. `reserved` therefore ratchets up and does not come
back down on its own, which is exactly what you saw.

That is why the three numbers diverge:

- `memory_allocated()` — your live tensors. Went to roughly zero on `del`.
- `memory_reserved()` — the pool. Stayed high, deliberately.
- `nvidia-smi` — the pool **plus the CUDA context** (a few hundred MB), plus
  every other process on the card. Stayed high for the same reason, and is
  higher still.

**`reserved - allocated` is not a leak.** It is cache. It becomes a problem only
when it is *fragmented* — many small free blocks and none large enough for the
next request — which is the classic "tried to allocate 2.00 GiB … 8.53 GiB
free" error. `empty_cache()` does hand the unused pool back to the driver, but
it throws away the cache you just paid for. Use it to make a measurement
readable or to hand memory to another process, not as a fix.

### Peak, and why you must reset it

`max_memory_allocated()` is a high-water mark since the process started, or
since you last called `reset_peak_memory_stats()`. Reading it without resetting
tells you about the largest thing your kernel has ever done, which is almost
never the question. The pattern is always: reset, run the region you care about,
read.
""")

nb.code('''
torch.cuda.empty_cache()
torch.cuda.reset_peak_memory_stats()

# A workload with an obvious transient: build a large intermediate, then drop it.
keep = torch.randn(2048, 2048, device="cuda", dtype=torch.float32)
transient = torch.randn(6144, 6144, device="cuda", dtype=torch.float32)
_ = transient @ transient
del transient
torch.cuda.synchronize()

peak_alloc = torch.cuda.max_memory_allocated() / 1e9
peak_reserved = torch.cuda.max_memory_reserved() / 1e9
now_alloc = torch.cuda.memory_allocated() / 1e9
now_reserved = torch.cuda.memory_reserved() / 1e9

print(f"peak allocated   {peak_alloc:7.2f} GB   <- compare THIS against a documented VRAM figure")
print(f"peak reserved    {peak_reserved:7.2f} GB   <- what the allocator needed to serve that peak")
print(f"now  allocated   {now_alloc:7.2f} GB")
print(f"now  reserved    {now_reserved:7.2f} GB")
print()

stats = torch.cuda.memory_stats()
inactive_split = stats.get("inactive_split_bytes.all.current", 0) / 1e9
segments = stats.get("segment.all.current", 0)
retries = stats.get("num_alloc_retries", 0)

print("Fragmentation, three ways of looking at it:")
print(f"  reserved - allocated        {now_reserved - now_alloc:7.2f} GB  "
      f"(cache; a proxy, and a loose one)")
print(f"  inactive_split_bytes        {inactive_split:7.2f} GB  "
      f"(free remainders INSIDE split blocks — the tighter proxy)")
print(f"  segments held               {segments:7.0f}     "
      f"(more segments for the same bytes means more fragmentation)")
print(f"  num_alloc_retries           {retries:7.0f}     "
      f"(times the allocator had to free cache and retry — the real signal)")
print()
print("num_alloc_retries above zero means fragmentation actually cost you")
print("something. Zero means the gap above is healthy cache, whatever its size.")

RESULTS["peak"] = {"peak_alloc_gb": peak_alloc, "peak_reserved_gb": peak_reserved,
                   "inactive_split_gb": inactive_split, "segments": segments,
                   "alloc_retries": retries}

del keep
gc.collect()
torch.cuda.empty_cache()
''')

nb.md("""
## `expandable_segments`, and why you cannot turn it on from here

Rung one of NVIDIA's OOM ladder is:

```bash
export PYTORCH_ALLOC_CONF=expandable_segments:True
```

It changes the allocator from "reserve fixed-size segments and stitch them
together" to "grow one virtual address range on demand". Freed space inside an
expandable segment can be reused by an allocation of a *different* size, which
is precisely the case that defeats the default allocator.

It is free, it is rung one, and it is the first thing to try after an OOM that
reported plenty of free memory.

The catch is that the allocator reads the variable **once**, when the CUDA
caching allocator initialises — which happens on your first CUDA allocation.
Setting `os.environ[...]` in a notebook cell after that point does nothing at
all, silently. (Older PyTorch spells it `PYTORCH_CUDA_ALLOC_CONF`; recent
versions accept either. Setting both is harmless.)

So the only honest way to measure its effect is to run the same fragmenting
workload in two fresh subprocesses, one with the variable and one without. That
is what the next cell does. Note what you find: on an 80 GB card with plenty
free, the difference may be nothing — and reporting "no measurable effect on
this workload" is a result, not a failure.
""")

nb.code('''
FRAG_PROBE = """
import json, torch

blocks = []
for _ in range(160):
    blocks.append(torch.empty(32 * 1024 * 1024, dtype=torch.uint8, device="cuda"))
del blocks[::2]                       # free every other one: swiss cheese

big = []
try:
    for _ in range(10):
        big.append(torch.empty(768 * 1024 * 1024, dtype=torch.uint8, device="cuda"))
except Exception as exc:
    failure = type(exc).__name__
else:
    failure = None

s = torch.cuda.memory_stats()
print(json.dumps({
    "big_blocks_placed": len(big),
    "failure": failure,
    "allocated_gb": torch.cuda.memory_allocated() / 1e9,
    "reserved_gb": torch.cuda.memory_reserved() / 1e9,
    "inactive_split_gb": s.get("inactive_split_bytes.all.current", 0) / 1e9,
    "segments": s.get("segment.all.current", 0),
    "alloc_retries": s.get("num_alloc_retries", 0),
}))
"""


def run_frag_probe(expandable):
    env = dict(os.environ)
    for name in ("PYTORCH_ALLOC_CONF", "PYTORCH_CUDA_ALLOC_CONF"):
        if expandable:
            env[name] = "expandable_segments:True"
        else:
            env.pop(name, None)
    done = subprocess.run([sys.executable, "-c", FRAG_PROBE], env=env,
                          capture_output=True, text=True, timeout=900)
    if done.returncode != 0 or not done.stdout.strip():
        print((done.stderr or "")[-500:])
        return None
    return json.loads(done.stdout.strip().splitlines()[-1])


off = run_frag_probe(False)
on = run_frag_probe(True)
RESULTS["expandable_segments"] = {"off": off, "on": on}

if off and on:
    keys = ["big_blocks_placed", "reserved_gb", "inactive_split_gb",
            "segments", "alloc_retries", "failure"]
    print(f"{'metric':<22} {'default':>16} {'expandable':>16}")
    for key in keys:
        print(f"{key:<22} {str(off[key]):>16} {str(on[key]):>16}")
    print()
    print("Read `alloc_retries` and `big_blocks_placed` first: those say whether")
    print("fragmentation actually cost this workload anything. `reserved_gb` and")
    print("`segments` say how the allocator arranged itself to avoid it.")
    print("If the two columns are identical, say so. A knob that did nothing on")
    print("your workload is a finding you should report, not one to hide.")
else:
    print("One of the probes did not complete — see the stderr above.")
''')

# =====================================================================
# Subprocess measurement
# =====================================================================
nb.md("""
## Measuring something you are not inside

`cosmos_course.models.Generator` runs Cosmos Framework inference as a **separate
process**, against the framework's own virtualenv. That is deliberate (see the
`models.py` docstring: incompatible environments, memory hygiene, and matching
the documented command line) and it has one consequence for this lesson:

> `torch.cuda.memory_allocated()` in your kernel knows nothing about the
> generator's memory. Different process, different allocator, different
> bookkeeping. Every counter you just learned is blind to it.

What you can still see is the **device**. Poll `nvidia-smi` on a background
thread while the child runs, and you get a time series of device-wide VRAM from
which the peak is a good estimate of the child's high-water mark — as long as
you also record a baseline and are honest about what else is on the card.

Be clear about the limitation, because it is not small: this measures the
**device**, not the **process**. If the Reasoner NIM is running, its memory is
in your number. `nvidia-smi --query-compute-apps` does give per-process figures,
which we also read below, but it only reports processes that are alive at the
moment you sample, so a short-lived child can be missed entirely between polls.
""")

nb.code('''
class GpuSampler:
    """Poll device-wide VRAM on a background thread. Peak and baseline, in GB.

    Interval is a real trade: each poll shells out to nvidia-smi and costs tens
    of milliseconds of *host* time (it does not touch the device), so polling at
    10 Hz is fine and polling at 1 kHz is a way to measure your own sampler.
    """

    def __init__(self, interval=0.25, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self.timestamps = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_gb()
            if value is not None:
                self.samples.append(value)
                self.timestamps.append(time.perf_counter())

    def __enter__(self):
        self.samples = [self._read_gb() or 0.0]
        self.timestamps = [time.perf_counter()]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def baseline_gb(self):
        return self.samples[0] if self.samples else None

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None

    @property
    def attributable_gb(self):
        """Peak minus baseline. The child's contribution, if nothing else moved."""
        if self.peak_gb is None or self.baseline_gb is None:
            return None
        return self.peak_gb - self.baseline_gb


print(f"GpuSampler ready. Default interval {GpuSampler().interval} s.")
''')

nb.code('''
# A child that allocates a known amount, holds it, and exits. Knowing the true
# answer is what makes this a test of the sampler rather than a demo of it.
CHILD_GB = 6.0
CHILD = f"""
import time, torch
x = torch.empty(int({CHILD_GB} * 1e9), dtype=torch.uint8, device="cuda")
torch.cuda.synchronize()
time.sleep(4.0)
del x
"""

with GpuSampler(interval=0.2) as sampler:
    child = subprocess.run([sys.executable, "-c", CHILD],
                           capture_output=True, text=True, timeout=600)

RESULTS["sampler"] = {
    "requested_gb": CHILD_GB,
    "baseline_gb": sampler.baseline_gb,
    "peak_gb": sampler.peak_gb,
    "attributable_gb": sampler.attributable_gb,
    "n_samples": len(sampler.samples),
}

print(f"child requested        : {CHILD_GB:6.2f} GB")
print(f"device baseline        : {sampler.baseline_gb:6.2f} GB")
print(f"device peak            : {sampler.peak_gb:6.2f} GB")
print(f"peak - baseline        : {sampler.attributable_gb:6.2f} GB")
print(f"samples taken          : {len(sampler.samples)}")
print()
print("The difference between 'peak - baseline' and what the child asked for is")
print("the child's CUDA context plus allocator rounding — real memory that a")
print("naive estimate of 'weights times bytes' will miss on every process you")
print("ever launch.")
print()
print("Per-process attribution, for comparison (whoever is on the card now):")
try:
    apps = subprocess.run(
        ["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory",
         "--format=csv,noheader"],
        capture_output=True, text=True, timeout=10, check=True).stdout.strip()
    print(apps or "  (no compute processes reported)")
except Exception as exc:
    print(f"  could not query compute apps: {type(exc).__name__}")
print()
print("Note that the child is gone by now, so it does not appear. That is the")
print("limitation in one line: per-process is accurate and only works while the")
print("process lives; device-wide sampling catches the peak and cannot say whose")
print("it was.")
''')

# =====================================================================
# Throughput vs latency
# =====================================================================
nb.md("""
## Throughput and latency are different questions

Two words that get used interchangeably and should not be.

- **Latency** — how long one unit of work takes, end to end, from the point of
  view of whoever asked for it. Seconds per generation. This is what a person
  waiting on a result cares about.
- **Throughput** — how much work completes per unit time under sustained load.
  This is what a data pipeline cares about, and it is not `1 / latency` in
  general, because batching, pipelining and overlap can raise throughput while
  leaving latency unchanged or worse.

For video generation, "generations per hour" is a weak throughput metric because
generations are not comparable — a 61-frame 256p clip and a 121-frame 768p clip
are not one unit each. Two metrics that do mean something:

- **output frames per second** — frames of finished video divided by wall clock.
  Directly interpretable, and it is what a dataset-building budget is denominated
  in.
- **latent tokens per second** — the unit `estimate_generation_cost()` counts,
  divided by compute time. Comparable across resolutions and frame counts,
  because it is what the transformer actually processes.

Note the denominators differ. Frames per second should use **wall clock**,
because that is the cost you pay. Tokens per second should use **compute time**
with the fixed overhead subtracted, because that is what scales. Report both,
say which is which.

The cell below computes these from measurements you already have — Lesson 06's
log and calibration — rather than from anything invented here. If you have not
done Lesson 06, it says so and computes nothing.
""")

nb.code('''
CAL_PATH = cc.OUTPUT_ROOT / "06" / "calibration.json"
L06_LOG = cc.OUTPUT_ROOT / "06" / "measurements.jsonl"

calibration = {}
if CAL_PATH.exists():
    try:
        calibration = json.loads(CAL_PATH.read_text())
    except json.JSONDecodeError:
        calibration = {}

prior_runs = MeasurementLog(L06_LOG).load() if L06_LOG.exists() else []
FIXED_OVERHEAD_S = calibration.get("fixed_overhead_s") or 0.0

print(f"calibration file : {CAL_PATH}  ({'found' if calibration else 'missing'})")
print(f"lesson 06 log    : {len(prior_runs)} record(s)")
if calibration.get("fixed_overhead_s") is not None:
    print(f"fixed overhead   : {FIXED_OVERHEAD_S:.1f} s (measured in Lesson 06)")
else:
    print("fixed overhead   : unknown, so tokens/s below uses total time and")
    print("                   will therefore understate the compute rate")
print()


def throughput(seconds, num_frames, resolution, num_steps, overhead_s=0.0):
    """Frames/s on wall clock, tokens/s on compute time. Both, labelled."""
    est = cc.estimate_generation_cost(resolution=str(resolution),
                                      num_frames=int(num_frames),
                                      num_steps=int(num_steps))
    compute_s = max(seconds - overhead_s, 1e-6)
    return {
        "latency_s": seconds,
        "output_fps": num_frames / seconds,
        "latent_tokens_per_s": est["latent_tokens"] / compute_s,
        "cost_units_per_s": est["cost_units"] / compute_s,
    }


usable = [r for r in prior_runs
          if r.get("seconds") and r.get("num_frames") and r.get("resolution")
          and r.get("num_steps")]

if usable:
    print(f"{'run':<24} {'latency':>10} {'frames/s':>10} {'tokens/s':>13} {'units/s':>14}")
    for record in usable:
        t = throughput(record["seconds"], record["num_frames"],
                       record["resolution"], record["num_steps"],
                       overhead_s=FIXED_OVERHEAD_S)
        print(f"{str(record.get('label', '?'))[:23]:<24} "
              f"{t['latency_s']:>9.1f}s {t['output_fps']:>10.2f} "
              f"{t['latent_tokens_per_s']:>13,.0f} {t['cost_units_per_s']:>14,.0f}")
    RESULTS["throughput"] = [throughput(r["seconds"], r["num_frames"],
                                        r["resolution"], r["num_steps"],
                                        overhead_s=FIXED_OVERHEAD_S)
                             for r in usable]
    print()
    print("Frames/s is a budget number: divide your target dataset size by it.")
    print("Tokens/s should be roughly stable across rows; where it is not, the")
    print("unit model is missing something about that configuration, and saying")
    print("which row disagrees is more useful than averaging them together.")
else:
    print("No Lesson 06 measurements found, so there is nothing real to divide.")
    print("The function above is correct and will work the moment you have a run.")
    print("Rather than invent a number, run Lesson 06 (or enable the opt-in")
    print("section below) and come back. That refusal is the lesson.")
''')

nb.md("""
### Optional: measure one real generation

Everything so far was synthetic and took seconds. This section runs Cosmos 3
once, so that the throughput arithmetic above has real data and so that you have
seen the subprocess sampler pointed at the thing it was written for.

It is **off by default**. Turn it on only if you already have a checkpoint
locally from Module 2 — the cell checks your Hugging Face cache and tells you
what a run would download *before* downloading anything. A reduced-mode run is a
small number of minutes; it is not a lesson-blocking wait, but it is not free
either.
""")

nb.code('''
from cosmos_course.models import Generator

# Two flags, deliberately separate — the same pattern as Lesson 06. Turning on
# generation can then never start a multi-gigabyte pull by accident.
RUN_GENERATION = False
ALLOW_DOWNLOAD = False


def hf_cache_gb(repo_id):
    root = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface")) / "hub"
    path = root / ("models--" + repo_id.replace("/", "--"))
    if not path.exists():
        return 0.0
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file()) / 1e9


generator = Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=True)
repo = cc.MODEL_TIERS[MODEL]["hf_repo"]
cached_gb = hf_cache_gb(repo)

needs_download = cached_gb < 1.0
print(f"\\n{repo}: {cached_gb:.1f} GB cached locally")
if needs_download:
    print(f"  A run would download ~{cc.MODEL_TIERS[MODEL]['download_gb']:.1f} GB "
          f"plus first-run auxiliaries "
          f"({sum(cc.AUXILIARY_DOWNLOADS_GB.values()):.1f} GB).")
    print("  This lesson does not need it — everything above was synthetic. Leave")
    print("  both flags False unless you want the real-workload numbers and have")
    print("  the disk and the time.")

GEN_OK = (RUN_GENERATION and not framework_problems
          and (not needs_download or ALLOW_DOWNLOAD))
print(f"\\nreal generation enabled: {GEN_OK}")

gen_measurement = None
if GEN_OK:
    prompt_path = cc.asset_or_none("prompt_robot_kitchen")
    prompt_text = (json.dumps(json.loads(prompt_path.read_text()), separators=(",", ":"))
                   if prompt_path else
                   "a wheeled robot tidying a bright domestic kitchen, steady camera")
    spec = cc.InferenceSpec(
        model_mode="text2video", name="measured_run", prompt=prompt_text,
        resolution="256", aspect_ratio="16,9", num_frames=61,
        num_steps=20, guidance=7.0, shift=10.0, seed=0,
    )
    print(f"\\ncost: {spec.cost()['cost_units']:,} units")
    with GpuSampler(interval=0.5) as gen_sampler:
        with cc.timer("cosmos generation", track_memory=False) as gen_timing:
            gen_result = generator.run(spec, OUTPUT_DIR / "generation",
                                       seed=0, timeout=3600)
    gen_measurement = {
        "seconds": gen_timing.seconds,
        "device_baseline_gb": gen_sampler.baseline_gb,
        "device_peak_gb": gen_sampler.peak_gb,
        "attributable_gb": gen_sampler.attributable_gb,
        "num_frames": 61, "resolution": "256", "num_steps": 20,
    }
    RESULTS["generation"] = gen_measurement
    log.record(label="cosmos_generation", model=MODEL, mode=MODE, **gen_measurement)
    print()
    for key, value in gen_measurement.items():
        print(f"  {key:<22} {value}")
    print()
    cc.verify_result(gen_result)
    print()
    print(throughput(gen_measurement["seconds"], 61, "256", 20,
                     overhead_s=FIXED_OVERHEAD_S))
''')

# =====================================================================
# OOM
# =====================================================================
nb.md("""
## Running out of memory on purpose

You will hit a CUDA OOM in this course. It is better to meet one now, when
nothing is at stake, than forty minutes into a 768p run.

The cell below allocates 2 GB blocks until the device refuses, catches the
error, reads the numbers out of it, and gives everything back. This is safe —
PyTorch raises a normal Python exception rather than killing the process — but
it does briefly fill the card, so do not run it while something else on the
machine is doing work you care about.

Read the error message carefully when it arrives. It contains the whole
diagnosis:

- **"Tried to allocate X"** — the size of the single request that failed. A
  large X points at geometry (resolution, frames, batch); a small X with the
  card nearly full points at genuine exhaustion.
- **"Y is free"** — if Y is comfortably larger than X, you have a fragmentation
  problem, not a capacity problem, and rung one may fix it outright.
- **"Z reserved by PyTorch but unallocated"** — the cache. Large Z next to a
  failed allocation is the signature of fragmentation.
""")

nb.code('''
torch.cuda.empty_cache()
torch.cuda.reset_peak_memory_stats()

blocks = []
oom_message = ""
try:
    # Bounded, not `while True`. 200 blocks is 400 GiB — far past any H100 — so
    # the loop always ends in the exception it is here to produce, and never in
    # a hung cell if something unexpected makes allocation always succeed.
    for _ in range(200):
        blocks.append(torch.empty(2 * GIB, dtype=torch.uint8, device="cuda"))
except OOM_ERROR as exc:
    oom_message = str(exc)
    print(f"OOM after {len(blocks)} blocks "
          f"({len(blocks) * 2:.0f} GiB requested by this process)")
    print()
    print(oom_message[:900])
finally:
    peak_before_recovery = torch.cuda.max_memory_allocated() / 1e9
    del blocks
    gc.collect()
    torch.cuda.empty_cache()

recovered = cc.memory_snapshot(include_smi=True)
RESULTS["oom"] = {
    "peak_allocated_gb": peak_before_recovery,
    "recovered_allocated_gb": recovered.torch_allocated_gb,
    "recovered_reserved_gb": recovered.torch_reserved_gb,
}

print()
print(f"peak allocated before the failure : {peak_before_recovery:6.2f} GB")
print(f"after recovery, allocated         : {recovered.torch_allocated_gb:6.2f} GB")
print(f"after recovery, reserved          : {recovered.torch_reserved_gb:6.2f} GB")
print()
print("The process survived. An OOM is a recoverable exception in PyTorch, which")
print("means a long job CAN catch one, shrink its batch and continue — and it is")
print("also why a failed run can leave a kernel holding tens of GB if nobody")
print("deletes the tensors. That is what the `finally` block above is for.")
''')

nb.code('''
ladder = cc.oom_advice(peak_before_recovery, model=MODEL,
                       total_gb=TOTAL_VRAM_GB,
                       resolution="768", num_frames=189, num_steps=50)

unavailable = [line.strip() for line in ladder
               if "shard degree" in line or "context-parallel" in line]
print()
print("=" * 72)
print(f"Rungs this machine does not have: {len(unavailable)}")
for line in unavailable:
    print(f"   {line}")
print()
print("Both work by splitting state across additional ranks. With one device")
print("there is nothing to split onto. Any advice that opens with 'increase the")
print("shard degree' was written for a node — recognising that instantly is worth")
print("more than the rest of the ladder combined.")
''')

# =====================================================================
# 8. Debugging lab
# =====================================================================
nb.md("""
## Debugging lab — the benchmark that reports a huge speedup

### Symptom

A colleague sends you a notebook cell. It compares a "baseline" matmul against
an "optimised" one and reports a speedup so large it would be a research result
if it were real. They are pleased. You are suspicious.

Your job is not to be suspicious in general. It is to find the **three specific
bugs**, one at a time, and then to report the real number — which may still be a
speedup, and if so is worth having.

Run the cell. Note the figure it reports. Do not read ahead until you have
written down at least one hypothesis of your own.
""")

nb.code('''
# DELIBERATELY BROKEN. Three bugs. Do not copy this pattern.
A32 = torch.randn(MATMUL_N, MATMUL_N, device="cuda", dtype=torch.float32)
B32 = torch.randn(MATMUL_N, MATMUL_N, device="cuda", dtype=torch.float32)
A16 = A32.to(torch.bfloat16)
B16 = B32.to(torch.bfloat16)


def broken_benchmark(iters=20):
    """Reports a spectacular speedup for bfloat16 over float32. It is wrong."""
    # "optimised": bfloat16
    t0 = time.perf_counter()
    for _ in range(iters):
        fast_out = A16 @ B16
    fast = time.perf_counter() - t0

    # "baseline": float32
    t0 = time.perf_counter()
    slow_out = A32 @ B32
    torch.cuda.synchronize()
    slow = time.perf_counter() - t0

    print(f"  baseline (fp32) : {slow * 1e3:9.3f} ms")
    print(f"  optimised (bf16): {fast * 1e3:9.3f} ms")
    print(f"  SPEEDUP         : {slow / fast:9.1f}x")
    return slow / fast


claimed = broken_benchmark()
''', tags=["teaching-antipattern"])

nb.md("""
### Hypothesis

Work through it the way you would if nobody had told you there were three.

**Bug one — the clock stops before the work does.** The bfloat16 branch has no
`torch.cuda.synchronize()` before `t1`. You have already measured what that does
to a matmul timing; you know the direction and roughly the size. The float32
branch *does* synchronise. So one side is timing execution and the other is
timing launches, and the comparison is meaningless before anything else is
considered.

**Bug two — one side is cold.** `A32 @ B32` is the first float32 matmul at this
shape in this process. It pays cuBLAS algorithm selection and, because the
output tensor is a new size, an allocator segment. The bfloat16 side has been
warm since the top of this notebook. Even with the sync fixed, this comparison
puts a first call against a steady state.

**Bug three — the two sides do different amounts of work.** The candidate runs
`iters` matmuls; the baseline runs one. The totals are then divided as though
they were comparable. This alone inflates the ratio by a factor of `iters`.

Three bugs, all in the same direction. Multiply them together and a difference
that is real but modest becomes a headline.

### Diagnostic step

Fix them **one at a time** and watch the reported speedup fall. Changing all
three at once tells you the answer but not which bug was worth how much, and the
second thing is what stops you making the same mistake again.
""")

nb.code('''
def variant(sync, warmup, equal_work, iters=20):
    """One row of the diagnosis. Each flag repairs exactly one bug."""
    if warmup:
        for _ in range(3):
            A32 @ B32
            A16 @ B16
        torch.cuda.synchronize()

    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(iters):
        A16 @ B16
    if sync:
        torch.cuda.synchronize()
    fast = time.perf_counter() - t0
    torch.cuda.synchronize()                       # never pollute the next timing

    n_slow = iters if equal_work else 1
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(n_slow):
        A32 @ B32
    torch.cuda.synchronize()
    slow = time.perf_counter() - t0

    return slow / fast


rows = [
    ("as received (all three bugs)", False, False, False),
    ("+ synchronise the candidate",  True,  False, False),
    ("+ warm up both sides",         True,  True,  False),
    ("+ equal iteration counts",     True,  True,  True),
]

print(f"{'configuration':<32} {'reported speedup':>18}")
measured_ratios = {}
for label, sync, warmup, equal in rows:
    ratio = variant(sync, warmup, equal)
    measured_ratios[label] = ratio
    print(f"{label:<32} {ratio:>17.1f}x")

RESULTS["debugging_lab"] = measured_ratios
print()
print("Each line removes one bug. The size of each drop tells you what that bug")
print("was worth on YOUR machine — which is the number to quote when someone")
print("sends you a benchmark with the same shape.")
''')

nb.md("""
### Repair, and the number you can actually defend

The last row of that table is honest but still thin: one measurement of each
side. Rebuild it properly — warm up, synchronise, repeat, report a median and a
spread — and quote *that*.

Two things to notice in the result. First, whatever ratio survives is real and
is worth knowing; bfloat16 matmul on Hopper uses different tensor-core paths
from float32, and the difference is not nothing. Second, the honest ratio and
the claimed one are not in the same league, and the gap was three bugs, not
dishonesty.
""")

nb.code('''
matmul_workload(WARM_ITERS)
torch.cuda.synchronize()

fp32_bench = cc.benchmark(lambda: A32 @ B32, label="fp32 matmul",
                          warmup=3, repeats=11)
bf16_bench = cc.benchmark(lambda: A16 @ B16, label="bf16 matmul",
                          warmup=3, repeats=11)

honest_ratio = fp32_bench["median_s"] / bf16_bench["median_s"]
RESULTS["debugging_lab"]["honest_ratio"] = honest_ratio

print()
print(f"claimed by the broken benchmark : {claimed:8.1f}x")
print(f"defensible, median of 11 each   : {honest_ratio:8.2f}x")
print(f"  fp32 median {fp32_bench['median_s'] * 1e3:8.3f} ms "
      f"(min {fp32_bench['min_s'] * 1e3:.3f}, max {fp32_bench['max_s'] * 1e3:.3f})")
print(f"  bf16 median {bf16_bench['median_s'] * 1e3:8.3f} ms "
      f"(min {bf16_bench['min_s'] * 1e3:.3f}, max {bf16_bench['max_s'] * 1e3:.3f})")
print()
print(f"the claim was inflated by a factor of {claimed / honest_ratio:,.0f}")
print()
print("Write the honest figure down the way you would publish it:")
print(f"  \\"bf16 matmul at {MATMUL_N}x{MATMUL_N} on this H100 completes in a")
print(f"   median {bf16_bench['median_s'] * 1e3:.2f} ms over 11 runs after 3 warm-up")
print(f"   runs, against {fp32_bench['median_s'] * 1e3:.2f} ms for fp32 — a factor of")
print(f"   {honest_ratio:.2f}. Timings are wall clock with synchronisation either side.\\"")

del A32, B32, A16, B16
gc.collect()
torch.cuda.empty_cache()
log.record(label="bf16_vs_fp32_honest", model=MODEL, mode=MODE,
           ratio=honest_ratio, matmul_n=MATMUL_N,
           fp32_median_s=fp32_bench["median_s"], bf16_median_s=bf16_bench["median_s"])
''')

nb.md("""
### Verification

You have not finished debugging a benchmark until you can state what each bug
contributed. From your own table:

1. **No synchronisation** — the candidate's clock stopped before its work did.
2. **No warm-up** — the baseline paid algorithm selection and allocator growth
   that the candidate had already paid at the top of the notebook.
3. **Unequal work** — `iters` matmuls compared against one, undivided.

And the general rule that falls out of it: **a benchmark comparing two things
must differ in exactly one respect.** Not one flag, one *respect* — same warm-up,
same iteration count, same synchronisation, same shapes, same allocator state.
Every additional difference is a place for a factor to hide.
""")

# =====================================================================
# 9. Exercises
# =====================================================================
nb.md("""
## Exercises

Three, increasing in scope. The first repairs a harness someone else broke, the
second builds a tool you will use in Lesson 15 and the capstone, and the third
asks you to publish a number with your name on it.
""")

nb.exercise(
    "foundation",
    "Repair a broken timing harness",
    goal=(
        "Take a plausible-looking `time_op()` and make it produce a figure you "
        "would be willing to defend, then prove it with the supplied automated "
        "check."
    ),
    instructions=(
        "1. Read `time_op_broken` below and find every mistake. There are at "
        "least three, and they are not the same three as the debugging lab.\n"
        "2. Write `time_op_fixed(fn, warmup=..., repeats=...)` returning a dict "
        "with `median_s`, `q1_s`, `q3_s`, `min_s`, `n` and `warmup`.\n"
        "3. Run `check_timing_harness(time_op_fixed)`. It tests your harness "
        "against a workload whose device time is known independently, so a "
        "harness that forgets to synchronise fails loudly rather than silently.\n"
        "4. Report the corrected figure for the convolution from earlier in this "
        "notebook — median and IQR — and say in one sentence how it differs from "
        "what `time_op_broken` reports for the same operation."
    ),
    success=(
        "`check_timing_harness()` prints all-pass, and you have one corrected "
        "figure written down with its spread and its warm-up count."
    ),
    starter='''
def time_op_broken(fn, repeats=5):
    """Plausible. Wrong in at least three ways. Find them before you rewrite it."""
    total = 0.0
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn()
        total += time.perf_counter() - t0
    torch.cuda.synchronize()
    return total / repeats


def time_op_fixed(fn, warmup=3, repeats=11):
    """Your version. Median and IQR, warm-up outside the timed region."""
    raise NotImplementedError


def check_timing_harness(harness):
    """Automated check. A harness that does not synchronise cannot pass this.

    The ground truth is torch.cuda._sleep, which busy-waits on the DEVICE for a
    fixed number of cycles and costs the host almost nothing. Any harness that
    times the launch instead of the work reports near zero for it.
    """
    passed = []

    if not hasattr(torch.cuda, "_sleep"):
        print("  ----  torch.cuda._sleep unavailable; using a matmul instead")
        device_only = lambda: matmul_workload(4)
    else:
        cycles = 400_000_000
        device_only = lambda: torch.cuda._sleep(cycles)

    reference = statistics.median(time_with_events(device_only, 7))
    got = harness(device_only, warmup=2, repeats=9)

    for key in ("median_s", "q1_s", "q3_s", "min_s", "n", "warmup"):
        assert key in got, f"the returned dict is missing {key!r}"
    passed.append("returns median, quartiles, min, n and warmup")

    assert got["median_s"] > 0.5 * reference, (
        f"reported {got['median_s'] * 1e3:.3f} ms against an event-measured "
        f"{reference * 1e3:.3f} ms — this harness is timing the launch, "
        f"not the work")
    passed.append(f"agrees with CUDA events to within 2x "
                  f"({got['median_s'] * 1e3:.3f} vs {reference * 1e3:.3f} ms)")

    assert got["n"] == 9 and got["warmup"] == 2, \\
        "n and warmup must report what was actually done"
    passed.append("reports its own methodology honestly")

    assert got["q1_s"] <= got["median_s"] <= got["q3_s"], "quartiles are out of order"
    passed.append("quartiles bracket the median")

    for item in passed:
        print(f"  PASS  {item}")
    return passed
''',
    hints=[
        "The three bugs in `time_op_broken`, in the order they bite: the "
        "synchronise is outside the loop so every iteration but the last is "
        "timing launches; there is no warm-up, so the first sample carries "
        "algorithm selection; and it returns a mean, which one slow run moves.\\n\\n"
        "A fourth, subtler one: it never synchronises *before* starting the "
        "clock, so work queued by a previous cell is charged to your first "
        "iteration.",
    ],
    solution_ref="solutions/14_solutions.ipynb",
)

nb.exercise(
    "applied",
    "A memory profiler for an out-of-process run",
    goal=(
        "Write `profile_run(command)` that reports peak allocated, peak "
        "reserved, device-wide peak and a fragmentation figure for work that "
        "happens in a process you are not inside."
    ),
    instructions=(
        "1. Implement `profile_run(command, interval=0.25)` where `command` is "
        "an argv list. Use `GpuSampler` for the device-wide series and "
        "`nvidia-smi --query-compute-apps` for per-process attribution while the "
        "child is alive.\n"
        "2. Return a dict with at least: `wall_s`, `device_baseline_gb`, "
        "`device_peak_gb`, `attributable_gb`, `samples`, and `child_reported` — "
        "the child's own `torch.cuda.max_memory_allocated()` and "
        "`max_memory_reserved()`, printed as JSON by the child and parsed by "
        "you.\n"
        "3. Compute `fragmentation_gb` as the child's reserved peak minus its "
        "allocated peak, and say in a comment why that is a proxy rather than a "
        "measurement.\n"
        "4. Run `check_profiler()`, which launches a child that allocates a "
        "known amount.\n"
        "5. Then point it at a real generation (`generator._build_command(...)` "
        "or simply re-run the opt-in cell with your profiler wrapped around it) "
        "and write down the three peaks side by side. Explain, in writing, why "
        "the device-wide peak exceeds the child's own `max_memory_allocated()`."
    ),
    success=(
        "`check_profiler()` passes, and you can state the difference between "
        "the child's reported peak and the device-wide peak in gigabytes, with "
        "a correct explanation of where those gigabytes went."
    ),
    starter='''
def profile_run(command, interval=0.25):
    """Profile a child process's GPU memory from outside it."""
    raise NotImplementedError


def check_profiler():
    """Launch a child of known size and check the profiler agrees."""
    passed = []
    target_gb = 4.0
    child = (
        "import json, time, torch\\n"
        f"x = torch.empty(int({target_gb} * 1e9), dtype=torch.uint8, device='cuda')\\n"
        "torch.cuda.synchronize(); time.sleep(3.0)\\n"
        "print(json.dumps({'max_alloc_gb': torch.cuda.max_memory_allocated() / 1e9,\\n"
        "                  'max_reserved_gb': torch.cuda.max_memory_reserved() / 1e9}))\\n"
    )
    out = profile_run([sys.executable, "-c", child])

    for key in ("wall_s", "device_baseline_gb", "device_peak_gb",
                "attributable_gb", "samples", "child_reported"):
        assert key in out, f"missing key {key!r}"
    passed.append("returns every required field")

    assert out["samples"] >= 5, \\
        f"only {out['samples']} samples over {out['wall_s']:.1f}s — poll faster"
    passed.append(f"{out['samples']} samples in {out['wall_s']:.1f} s")

    assert out["attributable_gb"] >= 0.8 * target_gb, (
        f"attributed {out['attributable_gb']:.2f} GB to a child that allocated "
        f"{target_gb} GB — the sampler is missing the peak")
    passed.append(f"attributed {out['attributable_gb']:.2f} GB of {target_gb} GB")

    reported = out["child_reported"].get("max_alloc_gb")
    assert reported and out["attributable_gb"] > reported, (
        "the device-wide figure must EXCEED the child's own allocated peak — "
        "if it does not, you are not seeing the CUDA context")
    passed.append(f"device-wide {out['attributable_gb']:.2f} GB exceeds the "
                  f"child's {reported:.2f} GB, as it must")

    for item in passed:
        print(f"  PASS  {item}")
    return out
''',
    hints=[
        "Have the child print one JSON object on its last line and parse "
        "`stdout.strip().splitlines()[-1]`. Anything the framework logs before "
        "that is noise you should skip rather than try to suppress.\\n\\n"
        "For the write-up: the device-wide figure includes the child's CUDA "
        "context (a few hundred MB), its reserved-but-unallocated pool, any "
        "cuBLAS/cuDNN workspaces, and anything else already resident on the "
        "card. Only the first three belong to the child.",
    ],
    solution_ref="solutions/14_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "Publish a defensible benchmark of your own H100",
    goal=(
        "Produce `outputs/14/benchmark_report.json` and a README that a "
        "sceptical reader could use to reproduce your numbers and to decide how "
        "much to trust them."
    ),
    instructions=(
        "1. Choose a sweep. A resolution tier crossed with a step count is the "
        "obvious one; a synthetic attention-shaped workload swept over sequence "
        "length is acceptable and much cheaper. Say which you chose and why.\n"
        "2. For every point: warm up, synchronise, repeat at least five times, "
        "and record median, IQR, min, max and n. A single sample is not a point.\n"
        "3. Record the machine: GPU name, compute capability, driver, torch "
        "version, CUDA version, and whether anything else was on the card. "
        "`cc.probe_environment()` gives you most of it in one call.\n"
        "4. Write a **methodology** section as structured data, not prose: "
        "warm-up count, repeat count, synchronisation strategy, which clock, "
        "what was held fixed, what varied.\n"
        "5. Write a **limitations** section with at least four entries, each "
        "naming something specific your measurement cannot see. Thermal state "
        "over a long sweep, page-cache effects on the first point, a single "
        "prompt, one seed, no confidence interval on a five-sample median, "
        "device-wide rather than process-attributed memory — pick the ones that "
        "are actually true of your run.\n"
        "6. Save the JSON and write `outputs/14/README.md` alongside it, "
        "including one sentence a reader could quote and one sentence saying "
        "what would change the result.\n"
        "7. Run `check_report()` before you call it done."
    ),
    success=(
        "`check_report()` passes, the JSON has at least six swept points each "
        "with n >= 5, and the limitations section names at least four specific "
        "things — not 'more testing is needed'."
    ),
    starter='''
REPORT_PATH = OUTPUT_DIR / "benchmark_report.json"
README_PATH = OUTPUT_DIR / "README.md"


def build_report():
    """Run your sweep and return the report dict. Save nothing here."""
    raise NotImplementedError


def check_report(path=REPORT_PATH):
    """Refuse to accept a report that a reader could not evaluate."""
    passed = []
    report = json.loads(Path(path).read_text())

    for key in ("machine", "methodology", "points", "limitations", "generated_at"):
        assert key in report, f"missing top-level key {key!r}"
    passed.append("has machine, methodology, points, limitations, generated_at")

    for key in ("warmup", "repeats", "synchronisation", "clock", "held_fixed", "varied"):
        assert key in report["methodology"], f"methodology is missing {key!r}"
    passed.append("methodology is complete enough to reproduce")

    points = report["points"]
    assert len(points) >= 6, f"only {len(points)} points; sweep something wider"
    for point in points:
        for key in ("median_s", "q1_s", "q3_s", "min_s", "max_s", "n", "config"):
            assert key in point, f"a point is missing {key!r}"
        assert point["n"] >= 5, f"a point has n={point['n']}; five is the floor"
        assert point["q1_s"] <= point["median_s"] <= point["q3_s"], \\
            "quartiles out of order"
    passed.append(f"{len(points)} points, all with n >= 5 and ordered quartiles")

    limits = report["limitations"]
    assert len(limits) >= 4, f"only {len(limits)} limitations; look harder"
    assert all(len(str(item)) > 40 for item in limits), \\
        "a one-line limitation is a placeholder, not a limitation"
    passed.append(f"{len(limits)} specific limitations")

    assert README_PATH.exists(), "no README next to the JSON"
    passed.append(f"README present ({README_PATH.stat().st_size} bytes)")

    for item in passed:
        print(f"  PASS  {item}")
    return passed
''',
    hints=[
        "The limitations section is the part that makes the report worth "
        "reading, and it is the part everyone skips. Concrete beats "
        "comprehensive: 'the sweep ran for eleven minutes and the last points "
        "were measured on a hotter card than the first, which I did not control "
        "for' is worth more than a paragraph about generalisability.\\n\\n"
        "If you want to know whether thermal drift affected you, run the sweep "
        "forwards and then backwards and compare the two orderings. A "
        "difference is drift; agreement is evidence you can quote.",
    ],
    solution_ref="solutions/14_solutions.ipynb",
)

# =====================================================================
# 10. Assessment and reflection
# =====================================================================
nb.md("""
## Assessment and reflection

### Knowledge check

Answer from memory; check yourself against your own measurements afterwards.

1. Why does timing a CUDA matmul without `synchronize()` produce a number that
   barely changes when you make the matrix larger?
2. Name three calls that force a synchronisation without saying so, and one
   that looks as though it would and does not.
3. You warm up once, then benchmark a model whose input shapes vary between
   calls. Why is one warm-up not enough, and what would you do instead?
4. Your samples have a median of 100 ms and a max of 400 ms. What does that
   shape suggest, and which statistic would you publish?
5. When is a CUDA event the right tool and when is a wall clock, and what does
   each one include that the other does not?
6. `memory_allocated()` reads 22 GB and `nvidia-smi` reads 60 GB for the same
   process. Give the two components of the difference.
7. You deleted every tensor and `memory_reserved()` did not drop. Is that a
   bug? What single call would make it drop, and why is calling it usually a
   bad idea?
8. Which allocator statistic tells you that fragmentation actually **cost** you
   something, as opposed to merely existing?
9. Why can `PYTORCH_ALLOC_CONF` not be set from a notebook cell partway through
   a session?
10. You sample `nvidia-smi` on a thread during a generation subprocess and see a
    peak of 41 GB. Name two reasons that figure may overstate the generator's
    own use.
11. Give a throughput metric for video generation that stays comparable across
    resolutions, and say which denominator it needs.
12. Two rungs of NVIDIA's OOM ladder do not exist on this machine. Name them and
    say what they would have done.

### Practical completion test

1. Produce two timings of the same operation — one correct, one wrong by
   construction — and explain the mechanism of the difference.
2. Show `memory_allocated`, `memory_reserved` and `nvidia-smi` for one workload
   and account for both gaps.
3. Attribute a known amount of VRAM to a child process using the sampler.
4. Trigger an OOM, recover from it, and name the rung of the ladder you would
   try first for a 768p job.
5. Save a benchmark report that passes `check_report()`.
""")

nb.code('''
def lesson_14_complete():
    """Check the artefacts, and the numbers that show the ideas landed."""
    passed, notes = [], []

    async_r = RESULTS["async"]
    assert async_r["honest_s"] > async_r["naive_s"], \\
        "the synchronised timing should be the larger one; re-run the async cell"
    passed.append(f"asynchrony demonstrated: naive timing was "
                  f"{async_r['honest_s'] / async_r['naive_s']:,.0f}x optimistic")

    warm = RESULTS["warmup"]["per_call_s"]
    assert warm[0] > statistics.median(warm[1:]), \\
        "the first call should be the slow one; if not, something warmed it first"
    passed.append(f"first-call penalty measured: "
                  f"{warm[0] / statistics.median(warm[1:]):,.1f}x")

    dist = RESULTS["distribution"]
    assert dist["n"] >= 15, "collect more samples before trusting the quartiles"
    passed.append(f"distribution over {dist['n']} samples, IQR "
                  f"{100 * (dist['q3_s'] - dist['q1_s']) / dist['median_s']:.1f}% "
                  f"of the median")

    alloc = RESULTS["allocator"]
    after = alloc["after `del`"]
    assert after["reserved_gb"] > after["allocated_gb"] + 1.0, \\
        "reserved should still exceed allocated after the delete"
    passed.append(f"caching allocator observed: {after['reserved_gb']:.1f} GB "
                  f"reserved against {after['allocated_gb']:.1f} GB allocated "
                  f"after deleting the tensor")

    sampled = RESULTS["sampler"]
    assert sampled["attributable_gb"] > 0.8 * sampled["requested_gb"], \\
        "the sampler missed the child's peak — poll faster or check nvidia-smi"
    passed.append(f"subprocess profiled: {sampled['attributable_gb']:.2f} GB "
                  f"attributed to a child that asked for "
                  f"{sampled['requested_gb']:.1f} GB")

    assert RESULTS["oom"]["peak_allocated_gb"] > 0.5 * TOTAL_VRAM_GB, \\
        ("the OOM demo peaked below half the card. Either it did not run, or "
         "another process (the Reasoner NIM?) already owned most of the VRAM — "
         "check `nvidia-smi` and say which")
    passed.append(f"OOM induced and recovered at "
                  f"{RESULTS['oom']['peak_allocated_gb']:.1f} GB peak")

    lab = RESULTS["debugging_lab"]
    if "honest_ratio" in lab:
        passed.append(f"broken benchmark corrected: claimed "
                      f"{lab['as received (all three bugs)']:,.0f}x, defensible "
                      f"{lab['honest_ratio']:.2f}x")

    if "throughput" in RESULTS:
        passed.append(f"throughput computed for {len(RESULTS['throughput'])} "
                      f"real run(s) from Lesson 06")
    else:
        notes.append("no Lesson 06 measurements were available for the "
                     "throughput section — run Lesson 06, or the opt-in cell")

    report_path = OUTPUT_DIR / "benchmark_report.json"
    if report_path.exists():
        passed.append(f"benchmark report written ({report_path.stat().st_size} bytes)")
    else:
        notes.append("outputs/14/benchmark_report.json not written yet — that is "
                     "the challenge exercise")

    for item in passed:
        print(f"  PASS  {item}")
    for item in notes:
        print(f"  ----  {item}")
    return passed, notes


_ = lesson_14_complete()

SUMMARY_PATH = OUTPUT_DIR / "session_measurements.json"
SUMMARY_PATH.write_text(json.dumps(RESULTS, indent=2, default=str) + "\\n")
print(f"\\nwrote {SUMMARY_PATH}")
''')

nb.md("""
### Summary

- A CUDA launch is asynchronous. Without `torch.cuda.synchronize()` you are
  timing the launch, and the error is large, directional, and flatters whichever
  side queues more work.
- The first call in a process pays context creation, kernel JIT, cuBLAS/cuDNN
  algorithm selection and allocator growth. Warm up outside the timed region;
  warm up once per *shape*, not once per program.
- Report a median and an IQR over repeats. The noise on a GPU is one-sided, so a
  mean absorbs every hiccup and a median does not.
- CUDA events give device time with one host sync per batch. Wall clock gives
  the interval a user experienced. Different questions.
- Load time is not compute time. Measure and report them separately or your
  scaling conclusions are wrong.
- `memory_allocated` is live tensors, `memory_reserved` is the pool,
  `nvidia-smi` is the whole device including contexts. The gap is cache; it is
  fragmentation only when `num_alloc_retries` says so.
- `PYTORCH_ALLOC_CONF=expandable_segments:True` is rung one, is free, and must be
  set before the first CUDA allocation.
- A subprocess is invisible to your allocator counters. Sample the device on a
  thread, subtract a baseline, and say out loud that the result is device-wide.
- Throughput is not `1/latency`. For video, frames per second on wall clock and
  latent tokens per second on compute time both mean something.
- Two rungs of NVIDIA's OOM ladder need more GPUs than you have.

### Common misconceptions

| Belief | Correction |
|---|---|
| "`time.perf_counter()` around GPU work is fine" | It times the launch. The fix is one line and this lesson opened with what happens without it. |
| "One warm-up call is always enough" | Enough for one shape. cuDNN and cuBLAS autotune per shape and dtype. |
| "Take the mean of five runs" | The noise is one-sided. Take the median of more runs, and publish the spread. |
| "`reserved` not dropping is a memory leak" | It is the caching allocator holding freed blocks for reuse. `empty_cache()` releases it and throws away the cache you paid for. |
| "`nvidia-smi` and `memory_allocated()` disagree, so one is broken" | Both are right. One is the device including contexts and other processes; the other is your live tensors. |
| "A big `reserved - allocated` gap means fragmentation" | It means cache. Fragmentation is when `num_alloc_retries` rises or a large allocation fails with plenty free. |
| "`expandable_segments` can be enabled mid-session" | The allocator reads it once, at first CUDA allocation. Set it in the environment before the kernel starts. |
| "`nvidia-smi` during a run gives me the generator's memory" | It gives you the device's. Subtract a baseline, and name what else is resident. |
| "Cutting steps will fix my OOM" | Steps are sequential and their activations are transient. Peak memory is set by geometry; drop a resolution tier. |
| "Throughput is one over latency" | Only without batching, pipelining or overlap. Measure both and say which you mean. |
| "The benchmark reported a large speedup, so there is one" | The debugging lab in this notebook reported one, and three bugs later it reported something much smaller. Ask what the two sides differed in besides the change. |

### Suggested extensions

- Run your challenge sweep forwards and then backwards. Any difference between
  the two orderings is thermal drift, and you will have measured it rather than
  worried about it.
- Set `CUDA_LAUNCH_BLOCKING=1` in a subprocess and re-run the asynchrony demo.
  The naive and honest timings converge, and the *total* gets worse. Explain
  both halves of that.
- Use `torch.cuda.memory._record_memory_history()` and
  `_dump_snapshot()` around the fragmentation cell, then open the result in
  PyTorch's memory visualiser. It shows you the segments directly instead of
  through a proxy.
- Wrap `GpuSampler` around the Reasoner NIM starting up (Lesson 02) and watch
  KV-cache pre-allocation happen in the time series.

### Mastery checklist

- [ ] I produced an impossible speedup on purpose and removed it with one line.
- [ ] I measured the first-call penalty in a fresh process and in a warm one.
- [ ] I report medians and IQRs, and I know why not means.
- [ ] I can say when to use a CUDA event and when to use a wall clock.
- [ ] I can account for the gap between `memory_allocated`, `memory_reserved`
      and `nvidia-smi` for a workload I ran.
- [ ] I profiled a process I was not inside, and I stated the limitation.
- [ ] I induced an OOM, recovered, and named the ladder rung I would try first.
- [ ] I have a saved benchmark report with a methodology and real limitations.

### Next

Lesson 15 spends this. Now that you can tell a real speedup from an artefact,
you get to go looking for real ones: precision, attention backends, the
parallelism presets, and the four knobs that actually cost you time — ranked by
measured effect on your machine, not by folklore.

## Free what you allocated, and say why

Two reasons, neither of them tidiness.

**This kernel is holding a reserved pool.** You allocated multi-gigabyte tensors
and filled the card on purpose. Even after deleting them, the allocator is
keeping the pool, and Lesson 15 launches generation subprocesses that will want
that memory. The allocator does not negotiate across processes: the child either
gets what it asks for or raises.

**The synthetic weight file is on disk.** A few hundred megabytes of random
numbers is not worth keeping.
""")

nb.code('''
for name in ("A", "B", "conv", "x", "big", "keep", "transient", "on_device", "mat"):
    globals().pop(name, None)

if plt is not None:
    plt.close("all")
gc.collect()
torch.cuda.empty_cache()

if WEIGHTS_PATH.exists():
    WEIGHTS_PATH.unlink()
    print(f"removed {WEIGHTS_PATH.name}")

free_b, total_b = torch.cuda.mem_get_info()
print(f"device: {free_b / 1e9:.1f} GB free of {total_b / 1e9:.1f} GB")
print(f"this kernel holds {torch.cuda.memory_allocated() / 1e9:.2f} GB allocated, "
      f"{torch.cuda.memory_reserved() / 1e9:.2f} GB reserved")
print()
if free_b / total_b < 0.8:
    print("Under 80% free while this kernel holds almost nothing. Something else")
    print("owns the card — check `nvidia-smi`. Lesson 15 will OOM otherwise.")
else:
    print("The card is clear. Lesson 15 can have it.")
print(f"\\nmeasurements logged: {log.path}")
''')

nb.md(FOOTER_MD)

nb.write(ROOT / "14_performance_and_memory.ipynb")
