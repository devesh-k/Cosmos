"""Build 12_action_wam.ipynb.

Derived from the source DLI course `S-OV-57-V1`, notebook 04, cells 16-24.

**This is the lesson where the source course is broken and this course fixes
it.** The source's policy cell sets `"model_mode": "policy"`. That value was
removed from `ModelMode`; the mode is now `wam`. The lesson opens with the
rename, has the learner verify it against the enum in their own checkout, and
only then runs anything.

Verified against upstream `main` (August 2026):
  * `docs/inference.md` mode table lists `wam` — "observation image/video +
    prompt" in, "predicted action sequence in sample_outputs.json + future
    visual rollout in vision.mp4" out.
  * The shipped `inputs/omni/action_policy_robot.json` contains
    `"model_mode": "wam"`. Only the FILENAME still says policy.
  * `EMBODIMENT_TO_RAW_ACTION_DIM["bridge_orig_lerobot"] == 10`.
  * `docs/action_policy_libero_posttrain.md`: LIBERO actions are
    "10D = pos 3 + rot6d 6 + gripper 1", and the eval client applies `1 - 2g`
    because the model's gripper range and the environment's disagree. That sign
    flip is a per-dataset convention, which is why this lesson determines the
    polarity empirically rather than asserting one.

The source fetches its start observation from a pinned raw GitHub URL in the
middle of the lesson. This version uses the cookbook's local
`bridge_lerobot_example` episode instead, and falls back to a cached download
only if that is missing.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 12 — The World Action Model")

# --------------------------------------------------------------- title block
nb.md("""
# Lesson 12 — The World Action Model

**What you will build.** `outputs/12/` containing a `wam` rollout with both of
its outputs, an integrated end-effector path with the gripper signal beside it,
a second run under a changed instruction, and a written comparison.

| | |
|---|---|
| **Time** | ~105 minutes |
| **GPU** | 1 × H100 80 GB. Cosmos3-Nano, already downloaded in Lesson 10. |
| **Downloads** | None if you completed Lesson 10. |
| **Prerequisites** | Lesson 11. You should be comfortable with 6-D rotations and pose integration. |

Lessons 10 and 11 ran the model as a **dynamics model** — a thing that knows how
the world changes. This lesson runs it as a **policy** — a thing that decides
what to do. That is a different kind of object with a different failure surface,
and the difference is worth being precise about before you run anything.

It is also where the source course this material is adapted from stops working,
because a mode was renamed. Fixing that is the first thing you will do with the
framework.
""")

# ---------------------------------------------------------------- objectives
nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Define** a policy and distinguish it from a dynamics model, in terms of
   what each one maps from and to.
2. **Verify** the live name of the world-action mode against the `ModelMode`
   enum in your own checkout, and **explain** why the documentation disagrees.
3. **Write** and run a `wam` spec that produces both a rollout video and an
   action sequence from one observation plus an instruction.
4. **Decompose** a 10-D end-effector action, **integrate** its translation
   deltas into a 3-D path, and **read** a grasp from the gripper channel.
5. **Determine** the gripper polarity empirically rather than assuming it, and
   explain why assuming it is exactly the class of bug that breaks deployment.
6. **Compare** two action sequences produced from the same observation under
   different instructions, with a number rather than an impression.
7. **Explain** what open-loop means here, what it cannot tell you, and why
   compounding error is a structural rather than incidental problem.
""")

# ------------------------------------------------------------- environment
nb.md("""
## Environment

One cell, and it is the first thing you run. It finds the course root, picks a
device and prints what every cell below will use. It downloads nothing.
""")

nb.code('__lesson__ = "12"   # OUTPUT_DIR resolves to outputs/12\n\n' + SETUP_CELL)

# --------------------------------------------------- what a policy is
nb.md("""
## What a policy is

A **policy** is a function from what you can see to what you should do:

```
   policy:   observation  (and usually a goal)   ->   action
```

That is the whole definition. It contains no model of physics, no simulation and
no planning; those may be inside it, but they are not what makes it a policy.
What makes it a policy is the type signature.

Contrast it with the two things you have already run:

| | Maps from | Maps to | Answers |
|---|---|---|---|
| Forward dynamics | state + action | next state | *what happens if I do this* |
| Inverse dynamics | two states | the action between them | *what did I do* |
| **Policy** | state + goal | **action** | *what should I do* |

The first two describe the world. The third makes a choice. Two consequences
follow and both matter:

**A policy needs a goal, and the dynamics models do not.** "What happens if I do
this" is a complete question. "What should I do" is not — you have to say what
you are trying to achieve. In Cosmos 3 that goal arrives as a natural-language
instruction in the `prompt` field, which is why the same observation with a
different instruction is a genuinely different query.

**A policy can be wrong in a way a dynamics model cannot.** A dynamics model
that predicts implausible physics is *inaccurate*. A policy that predicts a
smooth, physically perfect motion towards the wrong object is completely
accurate and completely useless. Verifying a policy therefore means checking
that it did what you asked, not only that its output is well formed — which is
harder, and is the subject of this lesson's exercises.
""")

nb.code('''
# The table above, written so you can interrogate it instead of reading it.
# Each entry is one mapping: what goes in, what comes out, and the question it
# answers.
MAPPINGS = {
    "forward dynamics": {"maps_from": ("state", "action"),
                         "maps_to": "next state",
                         "answers": "what happens if I do this"},
    "inverse dynamics": {"maps_from": ("state", "next state"),
                         "maps_to": "action",
                         "answers": "what did I do"},
    "policy":           {"maps_from": ("state", "goal"),
                         "maps_to": "action",
                         "answers": "what should I do"},
}

for name, mapping in MAPPINGS.items():
    print(f"{name:<18} {' + '.join(mapping['maps_from']):>20}  ->  "
          f"{mapping['maps_to']:<12} ({mapping['answers']})")

# The definition as a test rather than a sentence. Two of the three emit an
# action; only one of those is also told what it is trying to achieve.
emit_actions = [n for n, m in MAPPINGS.items() if m["maps_to"] == "action"]
policies = [n for n in emit_actions if "goal" in MAPPINGS[n]["maps_from"]]
assert policies == ["policy"], policies

print()
print(f"output is an action        : {emit_actions}")
print(f"...and needs a goal as well: {policies}")
''')

nb.md("""
### What makes Cosmos 3's version unusual

Cosmos 3's world action model does not only emit actions. It emits **both** a
predicted future rollout **video** and the **action sequence**, from one
forward pass:

```
   observation  +  "Put the pot to the left of the purple item."
                          |
                          v
        +-----------------+------------------+
        |                                    |
   vision.mp4                        sample_outputs.json
   what it thinks                    what it would do
   will happen                       to make that happen
```

Those two outputs are predictions of the same future in two different
languages, so they can be checked against each other. If the video shows the
gripper closing halfway through and the action sequence keeps the gripper open
throughout, something is wrong even though neither output is malformed. That
cross-check is free, it needs no ground truth, and the source course does not
do it. You will.
""")

nb.code('''
# The two artefacts a wam run leaves behind, and whether you have them yet.
# Nothing has been generated at this point, so "not yet" is the expected
# reading now. Re-run this cell at the end of the lesson.
WAM_OUTPUTS = {
    "vision.mp4": "what it thinks will happen",
    "sample_outputs.json": "what it would do to make that happen",
}

print(f"outputs land in: {OUTPUT_DIR}")
for filename, meaning in WAM_OUTPUTS.items():
    found = sorted(OUTPUT_DIR.rglob(filename))
    print(f"  {filename:<20} {(str(len(found)) + ' found') if found else 'not yet':<10} "
          f"{meaning}")
''')

# --------------------------------------------------- the rename
nb.md("""
## First: the mode was renamed, and the source is broken

Here is the spec from the source DLI course, notebook 04, unchanged:

```json
{
  "action_chunk_size": 16,
  "domain_name": "bridge_orig_lerobot",
  "fps": 5,
  "image_size": 480,
  "view_point": "ego_view",
  "model_mode": "policy",
  "name": "robot_policy",
  "prompt": "Put the pot to the left of the purple item.",
  "seed": 0,
  "vision_path": "..."
}
```

`"model_mode": "policy"` is dead. Upstream renamed the mode to **`wam`** — World
Action Model — and removed the old name from the enum. A run with the old value
fails validation.

What makes this worth a section rather than a footnote is where the old name
still lives. As of August 2026, `docs/inference.md`, `docs/faq.md` and the action
cookbook's `README.md` all still say `policy`. The shipped example files are
still *named* `action_policy_av.json` and `action_policy_robot.json` — and both
contain `"model_mode": "wam"` inside.

So the documentation says one thing, the filenames say another, and the code says
a third. The code wins, always. Do not take that from this notebook either:
check the enum in your own checkout in a moment.
""", tags=["teaching-antipattern"])

nb.callout("upstream", """
Three independent confirmations that `wam` is the live name, from
`COSMOS3_FACTS.md` §2: `ACTION_MODEL_MODES` in the framework contains
`ModelMode.WAM`; the defaults directory contains `defaults/wam/` and no
`defaults/policy/`; and the shipped `action_policy_*.json` inputs contain
`"model_mode": "wam"`. If you go looking yourself, fetch
`raw.githubusercontent.com/.../refs/heads/main/...` rather than `.../main/...` —
the latter serves a stale cached copy that still shows `POLICY = "policy"`, and
finding that out cost real time.
""")

# ------------------------------------------------------------ prerequisites
nb.md("""
## Prerequisites: the checkpoint and the episode

The next cell is the one that can stop you. It imports what the lesson needs,
names the checkpoint and what it costs, and fails with a fix if the Cosmos3-Nano
weights or the example episode are missing. Everything after it assumes both.
""")

nb.code('''
import json
import subprocess

import numpy as np

from cosmos_course.models import Generator

ACTION_MODEL = "Cosmos3-Nano"
tier = cc.MODEL_TIERS[ACTION_MODEL]
ALLOW_NANO_DOWNLOAD = os.environ.get("COSMOS_COURSE_ALLOW_NANO", "0") == "1"

print(f"checkpoint : {tier['hf_repo']}  ({tier['download_gb']} GB download, "
      f"{tier['inference_vram_gb']} GB VRAM)")
print(f"ALLOW_NANO_DOWNLOAD = {ALLOW_NANO_DOWNLOAD}")
cc.require(
    ALLOW_NANO_DOWNLOAD,
    "Cosmos3-Nano has not been opted into.",
    fix="export COSMOS_COURSE_ALLOW_NANO=1 and restart the kernel (see Lesson 10).",
)

gen = Generator(checkpoint=ACTION_MODEL)
cc.require(not gen.check(verbose=True), "The Cosmos Framework is not usable.",
           fix="See scripts/setup.sh, or set COSMOS3_REPO.")

report = cc.check_assets(["bridge_episode", "robolab_rollout"], verbose=True)
cc.require(
    "bridge_episode" not in report["missing"],
    "The cookbook's bridge_lerobot_example episode is missing.",
    fix="python3 scripts/fetch_assets.py    (the media are git-LFS objects)",
)

CHUNK = 16                       # the cookbook's value for this example
FPS = 5                          # ...and its frame rate
TIMEOUT_S = 1800 if MODE == "reduced" else 3600
INSTRUCTION = "Put the pot to the left of the purple item."
print()
print(f"instruction: {INSTRUCTION!r}")
''')

# ------------------------------------------------------- verify the enum
nb.md("""
## Verify the enum, do not trust this notebook

The single most useful habit in this lesson is not the fix. It is the *method*:
when a framework rejects a value, read the enum in the source rather than the
docs. Do it now, against your own checkout.

The framework lives in its own virtualenv, so ask its interpreter. One small
question, answered in JSON.
""")

nb.code('''
def framework_eval(snippet, args=(), *, timeout=300):
    """Run a snippet in the framework venv; return stdout. Raises on failure."""
    proc = subprocess.run(
        [str(gen.python), "-c", snippet, *[str(a) for a in args]],
        cwd=str(gen.repo),
        env={**os.environ, "LD_LIBRARY_PATH": "", "PYTHONNOUSERSITE": "1"},
        capture_output=True, text=True, timeout=timeout,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"framework venv failed (exit {proc.returncode}):\\n"
            f"{proc.stderr.strip()[-1500:]}"
        )
    return proc.stdout.strip()

ENUM_QUERY = """
import json
from cosmos_framework.inference.args import ModelMode
try:
    from cosmos_framework.inference.args import ACTION_MODEL_MODES
    action_modes = sorted(str(m) for m in ACTION_MODEL_MODES)
except Exception:
    action_modes = None
print(json.dumps({
    "file": ModelMode.__module__,
    "members": sorted(m.value for m in ModelMode),
    "action_model_modes": action_modes,
}))
"""

enum_info = json.loads(framework_eval(ENUM_QUERY))
print(f"read from: {enum_info['file']}")
print()
print("every member of ModelMode in YOUR checkout:")
for member in enum_info["members"]:
    print(f"    {member}")
print()
print(f"action modes: {enum_info['action_model_modes']}")
print()
print(f"'wam'    in the enum : {'wam' in enum_info['members']}")
print(f"'policy' in the enum : {'policy' in enum_info['members']}")

(OUTPUT_DIR / "model_modes.json").write_text(json.dumps(enum_info, indent=2))
''')

nb.md("""
**Checkpoint.** If those last two lines read `True` and `False`, you have
verified the rename against the code rather than against prose. If they read
otherwise, your checkout differs from the one this course was written against —
which is useful information, and the assertion below will tell you plainly.
""")

nb.code('''
modes = set(enum_info["members"])
assert "wam" in modes, (
    "your checkout has no 'wam' mode. Either it predates the rename, or the "
    f"members are: {sorted(modes)}"
)
assert "policy" not in modes, (
    "your checkout still has 'policy'. If you fetched via "
    "raw.githubusercontent.com/.../main/... you may be reading a stale cache; "
    "this cell read the installed package, so a 'policy' here means an older "
    "framework version."
)
print("checkpoint passed: wam is live, policy is gone, verified in your own checkout")
''')

nb.code('''
# The course helper that exists precisely because both names are in circulation.
from cosmos_course.specs import normalize_policy_mode

for name in ("policy", "wam", "forward_dynamics"):
    print(f"normalize_policy_mode({name!r}) -> {normalize_policy_mode(name)!r}")
print()
print("And the local validator's message when the dead name reaches it:")
for problem in cc.validate_spec(
    {"model_mode": "policy", "name": "x", "domain_name": "av", "vision_path": "v.mp4"},
    strict=False,
):
    print(f"    {problem}")
print()
print("Note what happened: validate_spec normalised 'policy' to 'wam' before")
print("checking, so it reports no mode problem. The course helpers are")
print("deliberately forgiving. The FRAMEWORK is not, which is what the")
print("debugging lab at the end of this lesson demonstrates.")
''', tags=["teaching-antipattern"])

# ------------------------------------------------------- the observation
nb.md("""
## The observation

The source course fetches its start observation from a pinned
`raw.githubusercontent.com` URL in the middle of the lesson. That is a bad idea
in teaching material for three reasons: it needs network access at exactly the
wrong moment, it silently changes if the pin moves, and it makes the lesson
un-runnable offline.

The cookbook ships an equivalent episode locally:
`bridge_lerobot_example/`, a LeRobot v3 recording of a WidowX arm in a kitchen.
LeRobot v3 stores its video as MP4 shards under `videos/<camera>/chunk-000/`,
its numeric data as Parquet, and its metadata in `meta/info.json`. Use that.

One thing to check before handing it to the model: the codec. LeRobot v3 shards
are frequently **AV1**, which several decoders in this stack cannot open, and a
video that fails to decode reaches the model as zero frames rather than as an
error. `Reasoner.ensure_h264` is the course's transcoder for exactly this — it
is a method on the reasoner client but it does no network I/O, so borrowing it
here without a NIM running is safe.
""")

nb.code('''
EPISODE = cc.asset("bridge_episode")

shards = sorted(EPISODE.glob("videos/*/chunk-*/*.mp4"))
cc.require(
    bool(shards),
    f"no video shard found under {EPISODE}",
    fix=("The episode directory is there but its media are not. The cookbook "
         "uses git-LFS:\\n        cd $COSMOS_ROOT && git lfs pull"),
)
for shard in shards:
    print(f"    {shard.relative_to(EPISODE)}   {shard.stat().st_size / 1e6:.2f} MB")

info_path = EPISODE / "meta" / "info.json"
if info_path.exists():
    info = json.loads(info_path.read_text())
    print()
    print(f"codebase_version : {info.get('codebase_version')}")
    print(f"fps              : {info.get('fps')}")
    print(f"total_episodes   : {info.get('total_episodes')}")
    print(f"features         : {sorted(info.get('features', {}))[:8]}")
''')

nb.code('''
from cosmos_course.models import Reasoner

# Borrowed as a transcoder only. Constructing a Reasoner opens no connection;
# ensure_h264 probes with ffprobe and re-encodes only when it has to, caching
# the result. See the docstring in cosmos_course/models.py for why AV1 is a
# problem in this stack at all.
OBSERVATION = Reasoner().ensure_h264(shards[0])
print(f"observation: {OBSERVATION}")
print(f"transcoded : {OBSERVATION != shards[0]}")
print()
cc.show_video(OBSERVATION, width=420,
              caption="the start observation the policy will be given")
''')

# --------------------------------------------------------------- the run
nb.md("""
## The `wam` spec

Compare this against the source's JSON at the top of the lesson. One field
differs. Everything else — `action_chunk_size`, `domain_name`, `fps`,
`image_size`, `view_point`, `prompt`, `seed` — is the cookbook's, unchanged.

There is no `action_path`. `wam` predicts the actions; supplying them would be
answering its question for it. (The shipped `inputs/omni/action_policy_robot.json`
does pass one, for its own regression-test purposes. The documented requirement
is `domain_name` plus `vision_path`, and that is what this uses.)
""")

nb.code('''
wam_spec = cc.InferenceSpec(
    model_mode="wam",                       # NOT "policy"
    name="robot_wam",
    prompt=INSTRUCTION,
    vision_path=str(OBSERVATION),
    domain_name="bridge_orig_lerobot",
    view_point="ego_view",
    action_chunk_size=CHUNK,
    fps=FPS,
    image_size=480,
    seed=0,
)
print(wam_spec.describe())
print()
print("the JSON the framework will receive - diff this against the source's:")
print(json.dumps(wam_spec.to_dict(), indent=2))
print()
print("validation:", cc.validate_spec(wam_spec, strict=False) or "no problems")
print()
print("required fields for wam:", sorted(cc.specs.REQUIRED_FIELDS["wam"]))
''')

nb.predict_run_explain(
    predict=(
        "This run produces two predictions of the same future: a rollout video "
        "and an action sequence. Before running, commit to answers: (a) will "
        "the gripper close at the same point in the video as in the action "
        "sequence's gripper channel? (b) if they disagree, which of the two "
        "would you trust more, and on what grounds? (c) how would you *measure* "
        "agreement between a video and a 10-column array, given that they are "
        "not the same kind of object?"
    ),
    change=(
        "Nothing to edit. Run the cell below, then the extraction and plotting "
        "cells after it, and come back to (c) once you have seen both outputs."
    ),
    explain=(
        "Play the rollout and read off, in seconds, when the gripper visibly "
        "closes. Convert that to a step index using `fps`. Compare against the "
        "step index where the gripper channel transitions. Report both numbers "
        "and the gap. Then answer (b) with evidence rather than intuition."
    ),
    hint=(
        "At 5 fps a 16-step chunk is a little over three seconds of predicted "
        "future, so 'when the gripper closes' has a resolution of about a fifth "
        "of a second. That is coarse enough that a one-step disagreement is not "
        "evidence of anything, which is itself worth stating in your answer."
    ),
)

nb.code('''
with cc.timer("wam robot_wam", quiet=True) as t_wam:
    wam_result = gen.run(wam_spec, OUTPUT_DIR / "robot_wam",
                         seed=0, timeout=TIMEOUT_S)

cc.verify_result(wam_result)
cc.require(wam_result.ok, "the wam run produced no usable output.",
           fix="Read the diagnosis printed above.")
print()
print(f"wall clock : {t_wam.seconds:.1f} s")
print(f"videos     : {[p.name for p in wam_result.videos]}")
print(f"json       : {[p.name for p in wam_result.jsons]}")
''')

nb.md("""
### Two outputs, from one forward pass

`vision.mp4` is what the model thinks the next few seconds look like.
`sample_outputs.json` is what it would do to bring them about. Look at each,
then at both together.
""")

nb.code('''
if wam_result.video_path:
    cc.show_video(wam_result.video_path, width=420,
                  caption=f"predicted rollout: {INSTRUCTION}")
else:
    print("no rollout video was produced - check the run summary above")
''')

nb.code('''
action = np.asarray(
    wam_result.sample_outputs["outputs"][0]["content"]["action"], dtype=np.float64
)
print(f"action shape : {action.shape}   [steps, dims]")
print()
print(cc.check_action(action, expected_dims=10))
print()
print("first three steps, rounded:")
print(np.round(action[:3], 4))

(OUTPUT_DIR / "wam_action.json").write_text(json.dumps(action.tolist()))
''')

nb.callout("note", """
You now have a `[steps, 10]` array on disk and no way to look at it except the
plots you are about to write. NVIDIA hosts a viewer for exactly this:
**[Cosmos3 Action Viewer](https://huggingface.co/spaces/nvidia/Cosmos3-Action-Viewer)**,
a Hugging Face Space that renders an action array alongside its rollout video in
a browser. The source DLI course linked it and this course previously did not,
which was a loss — it is the quickest sanity check on an action sequence you
will find, and it costs nothing to open in a tab.

Two caveats worth keeping. It is a *convenience*, not a verification: reading a
trajectory that looks plausible is exactly the trap `cc.check_action` exists to
close, and a Space can change or disappear without notice. And uploading
`wam_action.json` means uploading it — do not paste anything you would not want
on someone else's server. The plots below run locally and are what the rest of
this lesson relies on.
""")

# ------------------------------------------------------- end-effector layout
nb.md("""
## The end-effector action layout

An AV action was 9-D. A Bridge robot action is **10-D**, and the extra number is
the one that does the work:

```
   index:   0    1    2  |  3    4    5    6    7    8  |    9
          [ dx   dy   dz | r0   r1   r2   r3   r4   r5 | gripper ]
           \___________/   \_________________________/   \_____/
            translation           rotation (6-D)          open /
              delta               same encoding            close
                                  as Lesson 10
```

The first nine are the same idea you already know, applied to the **end
effector** — the gripper at the end of the arm — rather than to a camera. The
tenth is a scalar for the gripper.

Nothing about this is guesswork: `EMBODIMENT_TO_RAW_ACTION_DIM` in the framework
gives `bridge_orig_lerobot` a raw width of 10, `droid_lerobot` 10, and `av` 9,
and upstream's LIBERO post-training guide spells the layout out as
"10D = pos 3 + rot6d 6 + gripper 1".

Integrating the translation deltas gives the path the gripper traces through
space. Because the deltas accumulate, a small systematic bias shows up as
visible drift by the end — the same compounding you measured in Lesson 11.
""")

nb.code('''
positions = np.cumsum(action[:, :3], axis=0)
gripper = action[:, 9]

print(f"steps                 : {len(action)}")
print(f"predicted duration    : {len(action) / FPS:.2f} s at {FPS} fps")
print(f"path extent (x, y, z) : {np.round(positions.max(axis=0) - positions.min(axis=0), 4)}")
print(f"total path length     : {np.linalg.norm(np.diff(positions, axis=0), axis=1).sum():.4f}")
print()
print(f"gripper range         : {gripper.min():.4f} .. {gripper.max():.4f}")
print(f"gripper values        : {np.round(gripper, 3).tolist()}")

fig = cc.plot_end_effector_path(
    action, gripper_index=9,
    title=f"Predicted end-effector path ({len(action)} steps)",
)
''')

# ------------------------------------------------------- the gripper channel
nb.md("""
## Reading a grasp from the gripper channel

The gripper column is a scalar per step. What it means at each end is a
**per-dataset convention**, and this is not a pedantic caveat — upstream's own
LIBERO evaluation client applies `1 − 2·g` to the model's gripper output before
handing it to the simulator, precisely because the model's range and the
environment's range disagree. Their documentation adds "flip the sign if the
gripper never opens", which tells you how often this bites.

So do not assume the polarity. Determine it:

1. Find where the channel changes substantially — the transitions.
2. Convert each transition's step index to a time using `fps`.
3. Watch the rollout at those times and see whether the gripper is opening or
   closing.

A grasp has a characteristic shape: approach with the gripper at one extreme,
one transition to the other extreme, a period of holding, and often a transition
back at release. If you see many rapid transitions, either the task involves
repeated grasping or the model is uncertain — and those look identical in the
numbers, which is why you check the video.
""")

nb.code('''
def gripper_transitions(g, *, threshold=None):
    """Locate substantial changes in the gripper channel.

    The threshold defaults to a fraction of the channel's own observed range,
    rather than an absolute number, because the range is a per-dataset
    convention and a fixed constant would be wrong somewhere.
    """
    g = np.asarray(g, dtype=np.float64)
    span = float(g.max() - g.min())
    if threshold is None:
        threshold = max(span * 0.25, 1e-6)
    changes = np.diff(g)
    idx = np.where(np.abs(changes) >= threshold)[0]
    return [
        {
            "step": int(i + 1),
            "time_s": round(float((i + 1) / FPS), 3),
            "from": round(float(g[i]), 4),
            "to": round(float(g[i + 1]), 4),
            "direction": "increasing" if changes[i] > 0 else "decreasing",
        }
        for i in idx
    ], threshold, span

transitions, thr, span = gripper_transitions(gripper)
print(f"channel span      : {span:.4f}")
print(f"threshold used    : {thr:.4f}  (25% of span)")
print(f"transitions found : {len(transitions)}")
for t in transitions:
    print(f"    step {t['step']:>3}  t={t['time_s']:>5.2f}s  "
          f"{t['from']:+.3f} -> {t['to']:+.3f}  ({t['direction']})")
print()
if not transitions:
    print("No transition. Either the predicted chunk does not contain a grasp,")
    print("or the channel is flat because the model declined to move the")
    print("gripper. Both are possible; the rollout video distinguishes them.")
else:
    print("Now watch the rollout at those timestamps. Whichever direction")
    print("corresponds to the jaws visibly closing is 'close' FOR THIS DATASET.")
    print("Write it down; do not carry an assumption into Lesson 13.")
''')

nb.code('''
# Record the polarity you observed, so Lesson 13 has something to compare against.
GRIPPER_POLARITY = {
    "dataset": "bridge_orig_lerobot",
    "channel_index": 9,
    "observed_min": round(float(gripper.min()), 4),
    "observed_max": round(float(gripper.max()), 4),
    "transitions": transitions,
    # Fill this in after watching the rollout: "increasing" or "decreasing".
    "direction_that_closes_the_jaws": "TODO - watch the rollout and decide",
    "note": (
        "Upstream's LIBERO eval client applies 1 - 2*g before passing the "
        "gripper to the simulator, and documents flipping the sign if the "
        "gripper never opens. Polarity is a per-dataset convention."
    ),
}
(OUTPUT_DIR / "gripper_polarity.json").write_text(json.dumps(GRIPPER_POLARITY, indent=2))
print(json.dumps(GRIPPER_POLARITY, indent=2))
''')

# ------------------------------------------------------ instruction ablation
nb.md("""
## Changing the instruction, holding the observation fixed

A policy is a function of observation **and goal**. If the goal is doing any
work, changing it while holding everything else fixed must change the action.
If it does not, the model is ignoring your instruction and predicting the most
likely continuation of the video — which would make it a video model wearing a
policy's interface.

This is a cheap, decisive experiment, and it is the one to run first whenever
you meet a new instruction-conditioned model.
""")

nb.predict_run_explain(
    predict=(
        "The next run uses the same observation, the same seed and the same "
        "everything, with the instruction changed to something that implies a "
        "different direction of motion. Predict: (a) will the *first* action "
        "step differ noticeably between the two runs, or will they only diverge "
        "later? (b) will the gripper channel differ? (c) roughly what fraction "
        "of the total path length do you expect the two paths to differ by?"
    ),
    change=(
        "Edit `SECOND_INSTRUCTION` below if you want a different contrast. Pick "
        "something the scene can actually support — an instruction referring to "
        "an object that is not in frame tests a different thing."
    ),
    explain=(
        "The comparison cell reports per-step translation differences and the "
        "gripper difference. Use it to answer (a) with a number. Then answer "
        "the question underneath: if the two action sequences had come back "
        "*identical*, what would you conclude, and what would you check next?"
    ),
    hint=(
        "Think about when a policy can know that the instruction matters. Both "
        "runs start from the same pixels, so any difference in the first step "
        "has to come from the instruction alone. If step 0 is identical and "
        "step 8 is not, the model is deferring the commitment."
    ),
)

nb.code('''
SECOND_INSTRUCTION = "Pick up the pot and lift it straight up."

alt_spec = cc.InferenceSpec(
    model_mode="wam",
    name="robot_wam_alt",
    prompt=SECOND_INSTRUCTION,
    vision_path=str(OBSERVATION),
    domain_name="bridge_orig_lerobot",
    view_point="ego_view",
    action_chunk_size=CHUNK,
    fps=FPS,
    image_size=480,
    seed=0,                              # same seed: the instruction is the only change
)

with cc.timer("wam robot_wam_alt", quiet=True) as t_alt:
    alt_result = gen.run(alt_spec, OUTPUT_DIR / "robot_wam_alt",
                         seed=0, timeout=TIMEOUT_S, stream_logs=False)
cc.verify_result(alt_result)

alt_action = np.asarray(
    alt_result.sample_outputs["outputs"][0]["content"]["action"], dtype=np.float64
)
print()
print(f"first  instruction : {INSTRUCTION!r}  -> {action.shape}")
print(f"second instruction : {SECOND_INSTRUCTION!r}  -> {alt_action.shape}")
''')

nb.code('''
n = min(len(action), len(alt_action))
a, b = action[:n], alt_action[:n]

trans_diff = np.linalg.norm(a[:, :3] - b[:, :3], axis=1)
rot_diff = np.linalg.norm(a[:, 3:9] - b[:, 3:9], axis=1)
grip_diff = np.abs(a[:, 9] - b[:, 9])

print(f"{'step':>5}{'|d translation|':>18}{'|d rotation|':>15}{'|d gripper|':>14}")
print("-" * 52)
for i in range(n):
    print(f"{i:>5}{trans_diff[i]:>18.5f}{rot_diff[i]:>15.5f}{grip_diff[i]:>14.5f}")
print("-" * 52)
print(f"{'mean':>5}{trans_diff.mean():>18.5f}{rot_diff.mean():>15.5f}{grip_diff.mean():>14.5f}")
print()

path_a = np.cumsum(a[:, :3], axis=0)
path_b = np.cumsum(b[:, :3], axis=0)
len_a = np.linalg.norm(np.diff(path_a, axis=0), axis=1).sum()
endpoint_gap = float(np.linalg.norm(path_a[-1] - path_b[-1]))
print(f"path length under instruction 1 : {len_a:.5f}")
print(f"gap between the two endpoints   : {endpoint_gap:.5f}")
print(f"endpoint gap as a fraction      : {endpoint_gap / max(len_a, 1e-9):.2%}")
print()
print("A near-zero row at step 0 with growing rows later means the model")
print("defers its commitment. Near-zero rows THROUGHOUT would mean the")
print("instruction changed nothing, which is a finding worth chasing rather")
print("than a null result to shrug at.")

(OUTPUT_DIR / "instruction_ablation.json").write_text(json.dumps({
    "instruction_a": INSTRUCTION,
    "instruction_b": SECOND_INSTRUCTION,
    "steps_compared": int(n),
    "mean_translation_diff": round(float(trans_diff.mean()), 6),
    "mean_rotation_diff": round(float(rot_diff.mean()), 6),
    "mean_gripper_diff": round(float(grip_diff.mean()), 6),
    "endpoint_gap": round(endpoint_gap, 6),
    "endpoint_gap_fraction": round(endpoint_gap / max(len_a, 1e-9), 6),
}, indent=2))
''')

# ----------------------------------------------------- open vs closed loop
nb.md("""
## Open loop, and why it is a weak form of control

Everything in this lesson has been **open-loop**:

```
   observation  --->  policy  --->  16 actions  --->  execute all 16  --->  hope
```

One observation goes in. One sequence comes out. Nothing looks at the world
again until the whole sequence has been executed. **Closed-loop** control
interposes feedback:

```
   observation --> policy --> chunk --> execute --> NEW observation --> policy --> ...
        ^                                                 |
        +-------------------------------------------------+
```

Three things break in the open-loop version, and none of them is a quality
problem you can fix by training a better model.

**Compounding error.** You measured this in Lesson 11: relative predictions
accumulate, so a small per-step bias becomes a large end-of-sequence deviation.
Over 16 steps the drift may be tolerable. Over 200 it is not, and the growth is
not linear in any way you can rely on.

**No recovery from disturbance.** If the pot slips, or a human moves it, or the
arm is nudged, an open-loop plan carries on regardless — because it never looks.
The plan was computed for a world that no longer exists.

**No recovery from the policy's own mistakes.** This is the subtle one. Suppose
the first three actions are slightly wrong and the gripper ends up two
centimetres left of where the plan assumed. Actions 4 through 16 were computed
for the *intended* position, not the actual one. Every subsequent action is now
being applied in the wrong place, and the error grows with no mechanism to
notice.

The fix is structural, not statistical: re-query the policy every chunk with a
fresh observation. That is Lesson 13 — along with an honest account of why you
cannot run the full version of it on one machine.
""")

nb.code('''
# Open loop versus closed loop is a cadence, not a philosophy. Count it on your
# own rollout: how many observations would each cadence consume, and how many
# actions get executed between one look at the world and the next?
print(f"{'re-query every':>16} {'observations used':>19} {'actions executed blind':>24}")
for chunk in (len(action), 8, 4, 1):
    observations = -(-len(action) // chunk)          # ceiling division
    print(f"{chunk:>16} {observations:>19} {min(chunk, len(action)):>24}")

print()
print(f"Your run is the first row: {len(action)} actions from one observation.")
print("Lesson 13 moves down this table, and pays for it in latency.")
''')

# ----------------------------------------------------------- debugging lab
nb.md("""
## Debugging lab: `model_mode: "policy"`

**Symptom.** You follow a tutorial written before the rename — or the current
`docs/inference.md`, which still says `policy` — and the run dies before
producing anything. The error mentions a value that is not permitted, and lists
a set of names, and the name you used is not among them.

**Reproduce it deliberately.** This is worth doing once so the error is familiar
rather than alarming when it turns up in the middle of something else.

Note what the cell has to work around: `InferenceSpec` normalises `policy` to
`wam` in `__post_init__`, and `Generator._materialise_spec` normalises plain
dicts too. The course helpers are *deliberately* forgiving, so to see the real
failure you have to bypass them and hand the framework the raw JSON — which is
what a tutorial would have done.

`parallelism_preset="latency"` in the cell means "finish this one answer
quickly" rather than "most samples per hour"; the comment there says more, and
Lesson 15 measures whether the choice changes anything on one GPU.
""")

nb.code('''
# DELIBERATELY WRONG, and deliberately bypassing the course's helpers so the
# framework sees the dead name. Tagged skip-execution because it exists to fail
# and because a failed launch can still cost a minute or two. Nothing below
# depends on anything defined here.
from cosmos_course.specs import build_inference_command

dead_spec_path = OUTPUT_DIR / "dead_mode_spec.json"
dead_spec_path.write_text(json.dumps({
    "action_chunk_size": 16,
    "domain_name": "bridge_orig_lerobot",
    "fps": 5,
    "image_size": 480,
    "view_point": "ego_view",
    "model_mode": "policy",              # <-- the dead name, written by hand
    "name": "robot_policy",
    "prompt": INSTRUCTION,
    "seed": 0,
    "vision_path": str(OBSERVATION),
}, indent=2))

argv, env_over = build_inference_command(
    dead_spec_path, OUTPUT_DIR / "dead_mode",
    checkpoint=ACTION_MODEL, framework_repo=gen.repo,
    # parallelism_preset picks what the framework optimises for when it has a
    # choice: "latency" = finish this one answer as soon as possible;
    # "throughput" = most samples per unit time across a queue. Every action
    # mode uses "latency" (Lesson 10 gave the reason: a control loop asks one
    # question at a time). It is not load-bearing here — this run fails at
    # argument validation long before the preset matters. Lesson 15 measures
    # whether the two differ at all at world size 1.
    parallelism_preset="latency",
)
env = {**os.environ, **env_over, "RANK": "0", "WORLD_SIZE": "1", "LOCAL_RANK": "0"}

try:
    proc = subprocess.run(argv, cwd=str(gen.repo), env=env,
                          capture_output=True, text=True, timeout=300)
    output = (proc.stdout + proc.stderr)
    print(f"exit code: {proc.returncode}")
    print()
    print("last 25 lines:")
    for line in output.strip().splitlines()[-25:]:
        print("   ", line)
    print()
    for hint in cc.models.diagnose(output, returncode=proc.returncode):
        print(hint)
except subprocess.TimeoutExpired:
    print("timed out - the framework got past argument validation and started")
    print("loading. That would be surprising for an invalid enum value; check")
    print("whether your checkout still accepts the old name.")
''', tags=["teaching-antipattern", "skip-execution"])

nb.md("""
**Hypothesis.** `model_mode` is validated against an enum, and the value is not
a member.

**Diagnostic step.** You already did it: read the enum. That is the whole
technique and it generalises well beyond this one field. When a framework
rejects a value, the authoritative list is in the code, and it is usually one
grep away. Documentation describes what was true when it was written;
an enum describes what is true now.

Here is the general form, so you have it for the next time — a small function
that dumps any enum from any module in the framework's environment.
""")

nb.code('''
def framework_enum(module_path, enum_name):
    """List the members of an enum defined in the framework's environment."""
    snippet = """
import json, sys
mod = __import__(sys.argv[1], fromlist=[sys.argv[2]])
enum = getattr(mod, sys.argv[2])
print(json.dumps({
    "module": sys.argv[1],
    "enum": sys.argv[2],
    "members": [getattr(m, "value", str(m)) for m in enum],
}))
"""
    return json.loads(framework_eval(snippet, [module_path, enum_name]))

for module_path, enum_name in [
    ("cosmos_framework.inference.args", "ModelMode"),
    ("cosmos_framework.inference.args", "TransferHintKey"),
]:
    try:
        info = framework_enum(module_path, enum_name)
        print(f"{info['enum']}: {info['members']}")
    except RuntimeError as exc:
        print(f"{enum_name}: could not read it - {str(exc).splitlines()[-1][:120]}")
print()
print("Grep is the offline version of the same move:")
print("    grep -rn 'class ModelMode' $COSMOS3_REPO/cosmos_framework/")
''')

nb.md("""
**Repair.** `"model_mode": "wam"`. That is all.

**Verification.** Not "it ran". Three things, in order:

1. the mode you used is a member of `ModelMode` in *your* checkout — you
   asserted that near the top of this lesson;
2. the run produced **both** outputs, `vision.mp4` and `sample_outputs.json`,
   because a `wam` run that produces only one of them has not done what the mode
   promises;
3. the action array has the width the domain expects — 10 for
   `bridge_orig_lerobot` — which is Lesson 10's preflight applied to an output
   instead of an input.

**Checkpoint.** All three below should pass.
""")

nb.code('''
assert "wam" in enum_info["members"]
assert wam_result.video_path is not None, "wam produced no rollout video"
assert wam_result.jsons, "wam produced no sample_outputs.json"
assert action.shape[1] == 10, (
    f"expected 10-D bridge actions, got {action.shape[1]} - check domain_name"
)
print("checkpoint passed: correct mode, both outputs present, correct action width")
''')

# -------------------------------------------------------------- exercises
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "Three instructions, one observation",
    goal=(
        "Establish, with numbers rather than impressions, how much the "
        "instruction actually controls the predicted action."
    ),
    instructions=(
        "1. Choose three instructions for the same observation. Make them "
        "genuinely different: one about the pot, one about a different object "
        "in the scene, and one that is deliberately impossible given what is in "
        "frame.\n"
        "2. Run all three with everything else held fixed, including the seed.\n"
        "3. Build a 3×3 table of pairwise mean per-step translation distance "
        "between the action sequences.\n"
        "4. Add a control: run the *first* instruction again at a different "
        "seed, and put that distance in the table too. It is your noise floor. "
        "Any pairwise distance smaller than it is not a difference.\n"
        "5. Report what the impossible instruction produced. A policy asked for "
        "something the scene cannot support has no correct answer, and what it "
        "does instead is diagnostic."
    ),
    success=(
        "A pairwise distance table including a same-instruction different-seed "
        "control, and a written note on what happened with the impossible "
        "instruction."
    ),
    starter='''
INSTRUCTIONS = {
    "pot_left": INSTRUCTION,
    "other_object": "TODO: name something else visible in the observation",
    "impossible": "TODO: something the scene cannot support",
}

def run_instruction(tag, text, seed=0):
    """Run wam with one instruction; return the predicted action array."""
    raise NotImplementedError

def pairwise_distance(a, b):
    """Mean per-step Euclidean distance between two action sequences' translations."""
    raise NotImplementedError
''',
    hints=[
        "Without the seed control this exercise cannot conclude anything. Two "
        "runs of the *same* instruction at different seeds give you the scale of "
        "run-to-run variation, and a between-instruction distance that does not "
        "clear it is noise no matter how suggestive it looks.",
        "Sequences may come back at different lengths if a run is truncated. "
        "Compare over `min(len(a), len(b))` steps and report how many steps you "
        "compared, so a short run cannot quietly flatter itself.",
    ],
    solution_ref="solutions/12_solutions.ipynb",
)

nb.exercise(
    "applied",
    "Segment a trajectory into reach, grasp, move and release",
    goal=(
        "Turn a raw 10-column array into a description a human can read — and "
        "then validate that the description is right rather than plausible."
    ),
    instructions=(
        "1. Write `segment_trajectory(action, fps)` that labels every step as "
        "one of `reach`, `grasp`, `move`, `release` or `idle`, using the "
        "gripper channel together with the translation deltas.\n"
        "2. Define each phase operationally before you write any code. For "
        "example: `grasp` is the step at which the gripper transitions towards "
        "closed; `reach` is motion before that with the gripper open; `move` is "
        "motion after it with the gripper closed; `release` is the transition "
        "back. Write your definitions down, then implement exactly them.\n"
        "3. Do **not** hard-code the gripper polarity. Determine it from the "
        "data, or take it as an argument with a default you justify.\n"
        "4. Validate on synthetic input first: construct an action array where "
        "you know the ground-truth segmentation, and check that your function "
        "recovers it. A segmenter that has only ever seen real data has not "
        "been tested.\n"
        "5. Run it on both of this lesson's real predictions, print a timeline, "
        "and check it against the rollout videos.\n"
        "6. Report one case where your segmenter is wrong or ambiguous, and say "
        "what extra signal would resolve it."
    ),
    success=(
        "Written phase definitions, a segmenter that passes a synthetic test "
        "with known ground truth, timelines for both real predictions, and one "
        "documented failure case."
    ),
    starter='''
PHASES = ("idle", "reach", "grasp", "move", "release")

def synthetic_episode(n_steps=20, closes_at=6, opens_at=15, closed_value=1.0):
    """Build an action array with a KNOWN segmentation, for testing."""
    raise NotImplementedError

def segment_trajectory(action, fps, *, gripper_index=9, closed_is="high"):
    """Return a list of per-step phase labels."""
    raise NotImplementedError

# Test before you trust.
# expected = ["reach"] * 6 + ["grasp"] + ["move"] * 8 + ["release"] + ["idle"] * 4
''',
    hints=[
        "A pure-threshold segmenter chatters: a gripper value hovering near your "
        "threshold flips label every step. Hysteresis — two thresholds, one for "
        "each direction — fixes it, and is worth understanding because the same "
        "problem appears in every signal-to-symbol conversion you will ever "
        "write.",
        "'Motion' needs a threshold too, and the right one is relative to the "
        "trajectory's own scale rather than absolute, for the same reason the "
        "gripper threshold was. A fixed metre-per-step constant will be wrong "
        "for a different robot.",
    ],
    solution_ref="solutions/12_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "Are the predicted video and the predicted actions consistent?",
    goal=(
        "Design, run and honestly report an experiment measuring whether the "
        "two outputs of a `wam` run agree with each other."
    ),
    instructions=(
        "1. State a precise hypothesis. Not 'the outputs are consistent' — "
        "something falsifiable, such as 'the step at which the gripper channel "
        "transitions is within one step of the frame at which the jaws visibly "
        "close in the rollout'.\n"
        "2. Design a quantitative consistency measure. At least one component "
        "must be computed from the **video**, not from the action array. "
        "Options: frame-to-frame motion magnitude compared against per-step "
        "translation magnitude; the gripper-region pixel change compared against "
        "the gripper channel; running Lesson 11's inverse dynamics on the "
        "rollout and comparing the recovered actions against the predicted ones. "
        "The last is the most direct and has the most obvious circularity — "
        "discuss it either way.\n"
        "3. Establish a null. Compute your measure between a rollout and the "
        "actions from a *different* instruction. If your measure cannot separate "
        "matched from mismatched pairs, it is not measuring consistency.\n"
        "4. Run it on at least four (video, action) pairs, matched and "
        "mismatched.\n"
        "5. Write `outputs/12/consistency_report.md`: hypothesis, measure, null, "
        "results, and — the part that matters most — an honest section on what "
        "your measure **cannot** detect. Name at least two specific failure "
        "modes that would pass your test."
    ),
    success=(
        "A falsifiable hypothesis, a measure with a video-derived component, a "
        "matched-versus-mismatched null that your measure separates (or a clear "
        "statement that it does not), and two named blind spots."
    ),
    starter='''
def video_motion_profile(video_path, n_frames=32):
    """Per-frame motion magnitude from a clip. One component of your measure."""
    raise NotImplementedError

def consistency(video_path, action, fps):
    """Return a scalar (or dict) measuring agreement between the two outputs."""
    raise NotImplementedError

PAIRS = [
    ("matched",    wam_result.video_path, action),
    ("mismatched", wam_result.video_path, alt_action),
]
''',
    hints=[
        "Correlating two time series of different lengths and different units "
        "is the core difficulty. Normalise each to zero mean and unit variance "
        "and resample to a common length before correlating, and say what that "
        "normalisation throws away — it discards absolute magnitude, which "
        "means your measure can no longer detect a rollout that moves ten times "
        "too far.",
        "Two blind spots worth considering for the report. First, a measure "
        "based on total motion is blind to direction: a rollout moving the "
        "opposite way with the same speed profile scores perfectly. Second, any "
        "measure built from the model's own inverse dynamics is comparing the "
        "model against itself, so a consistent bias in both directions is "
        "invisible.",
    ],
    solution_ref="solutions/12_solutions.ipynb",
)

# ------------------------------------------------------------- assessment
nb.md("""
## Assessment and reflection

### Knowledge check

1. Give the type signature of a policy and of a forward dynamics model. What
   does the policy need that the dynamics model does not?
2. A policy predicts a physically flawless motion towards the wrong object. Is
   that an accuracy failure? What would you have to measure to catch it?
3. What is the live name of the world-action mode, and name three places
   upstream that still use the old one.
4. Someone shows you a doc page using `policy`. What is the fastest way to
   settle whether it works, without running a job?
5. Write out the 10-D end-effector layout by index.
6. Why does this lesson refuse to state which end of the gripper channel means
   closed?
7. `1 − 2·g`: what does that transform do to a channel on `[0, 1]`, and why does
   upstream's evaluation client apply it?
8. Name the three distinct things that break in open-loop control, and say which
   one you already measured in Lesson 11.

### Practical completion test

1. Verify the `ModelMode` enum in your own checkout and state what is and is not
   in it.
2. Run `wam` and show both outputs.
3. Integrate the end-effector path and locate every gripper transition in
   seconds.
4. Change the instruction, hold everything else fixed, and report a number for
   how much the action changed.
5. Reproduce the dead-mode error and explain the general technique it teaches.
""")

nb.code('''
def self_test():
    passed = []

    assert "wam" in enum_info["members"] and "policy" not in enum_info["members"]
    passed.append("ModelMode verified against your own checkout")

    assert wam_result.ok and wam_result.video_path and wam_result.jsons
    passed.append("wam produced both a rollout video and sample_outputs.json")

    assert action.ndim == 2 and action.shape[1] == 10
    passed.append(f"action is [{action.shape[0]}, 10] as bridge_orig_lerobot requires")

    assert cc.check_action(action, expected_dims=10).passed
    passed.append("action passes check_action at the domain's width")

    assert alt_result.ok, "the instruction-ablation run did not complete"
    ablation = json.loads((OUTPUT_DIR / "instruction_ablation.json").read_text())
    passed.append(
        f"instruction ablation: mean translation difference "
        f"{ablation['mean_translation_diff']}, endpoint gap "
        f"{ablation['endpoint_gap_fraction']:.1%} of path length"
    )

    polarity = json.loads((OUTPUT_DIR / "gripper_polarity.json").read_text())
    if polarity["direction_that_closes_the_jaws"].startswith("TODO"):
        passed.append("NOTE: gripper polarity not filled in - watch the rollout "
                      "and edit gripper_polarity.json before Lesson 13")
    else:
        passed.append(f"gripper polarity recorded: "
                      f"{polarity['direction_that_closes_the_jaws']}")

    for item in passed:
        print(f"  PASS  {item}" if not item.startswith("NOTE") else f"  ----  {item}")
    return passed

_ = self_test()
''')

nb.md("""
### Summary

- A **policy** maps observation and goal to action. Dynamics models describe the
  world; a policy makes a choice, which is why it needs a goal and why it can be
  wrong in ways a dynamics model cannot.
- The mode is **`wam`**, not `policy`. The old name is gone from the enum while
  `docs/inference.md`, `docs/faq.md` and the cookbook README still use it, and
  the shipped `action_policy_*.json` files contain `"model_mode": "wam"` despite
  their names. Trust the enum.
- The general skill is worth more than the fact: when a framework rejects a
  value, read the enum in the source. `framework_enum(module, name)` in this
  notebook does it for any enum in the framework's environment.
- `wam` produces **two** outputs from one pass — a rollout video and an action
  sequence — and they are predictions of the same future in different languages,
  so they can be cross-checked without any ground truth.
- A Bridge end-effector action is **10-D**: 3 translation deltas, 6-D rotation,
  1 gripper. The width comes from `EMBODIMENT_TO_RAW_ACTION_DIM`, not from
  guessing.
- The gripper channel's polarity is a **per-dataset convention**. Upstream's own
  evaluation client applies `1 − 2·g` and documents flipping the sign when the
  gripper never opens. Determine it from the data and the video.
- Changing the instruction while holding the observation and seed fixed is the
  decisive test of whether the goal is doing any work. Always run it with a
  same-instruction different-seed control, or you cannot tell a difference from
  noise.
- This was all **open-loop**. Compounding error, no disturbance recovery, and no
  recovery from the policy's own mistakes are structural consequences of never
  looking again, not quality problems.

### Common misconceptions

| Belief | Correction |
|---|---|
| "`policy` still works, the docs say so" | The docs are stale. The enum is the truth, and you verified it. |
| "The example files are named `action_policy_*`, so the mode is `policy`" | The filenames lagged the rename. Open one: it contains `"model_mode": "wam"`. |
| "A well-formed action sequence is a correct one" | A perfect motion towards the wrong object is well-formed and useless. |
| "Gripper 1 means closed" | It means whatever the dataset says. Upstream flips the sign for LIBERO because the conventions disagree. |
| "The rollout video and the actions must agree" | They are two heads of one model. Testing that they agree is a real experiment with a real chance of failing. |
| "Different instructions obviously give different actions" | Obvious until you measure it against a seed control and find the difference is inside the noise. |
| "Open-loop is fine for short horizons" | Possibly. The point is you have not measured *your* horizon, and the failure is not gradual in any dependable way. |

### Suggested extensions

- Run `wam` on the `droid_lerobot_example` episode with `domain_name` set to
  `droid_lerobot`. Also 10-D, different robot, different camera set. What
  transfers?
- Feed the `wam` prediction's own actions back into `forward_dynamics` and
  compare the result against the `wam` rollout video. Both are predictions of
  the same future by the same model through two different paths.
- Take the rollout's last frame as a new observation and query `wam` again with
  the same instruction. That is one manual step of a closed loop, using
  predicted rather than real observations — which is exactly the thing Lesson 13
  explains you cannot get away with, and worth seeing fail.

### Mastery checklist

- [ ] I can define a policy and distinguish it from a dynamics model.
- [ ] I verified `ModelMode` in my own checkout rather than trusting prose.
- [ ] I ran `wam` and extracted both of its outputs.
- [ ] I can write down the 10-D layout from memory.
- [ ] I determined the gripper polarity from data and video, not assumption.
- [ ] I compared two instructions with a number and a seed control.
- [ ] I can state the three failure modes of open-loop control.

Lesson 13 closes the loop — and is honest about which parts of it fit on one
machine.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "12_action_wam.ipynb")
