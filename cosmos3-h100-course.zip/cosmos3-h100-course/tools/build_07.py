"""Build 07_generation_conditioned.ipynb.

Derived from the source DLI course `S-OV-57-V1`, notebook 03, section 3
(cells 12-15): image-to-video from `car_driving.jpg` with `car_driving.json`.
The asset pair and the example are preserved.

What this lesson adds:

* an explanation of *how* the conditioning enters — the image is encoded to
  latents and pinned as the first temporal slice — which the source omits;
* a measurement of what the model preserved from the frame and what it invented,
  rather than an assertion;
* the `"16,9"` comma format and the silent geometry failure that follows from
  getting it wrong, worked as a debugging lab;
* the course's through-line: a scene record captioned by the reasoner in Lesson
  03 becomes the prompt for a generation here. The source asserts this loop in
  its introduction and never builds it.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 07 — Image-conditioned generation")

# =====================================================================
# Title and objectives
# =====================================================================
nb.md("""
# Lesson 07 — Image-conditioned generation

**What you will build.** `outputs/07/` containing videos animated from a
cookbook still, from an image of your own, and from a caption the reasoner wrote
in Lesson 03 — plus a measured account of what the model kept from the
conditioning frame and what it made up.

| | |
|---|---|
| **Time** | ~100 minutes. Around ten short generation runs in reduced mode. |
| **GPU** | 1 × H100 80 GB, exclusively. Stop the Reasoner NIM before you start. |
| **Downloads** | None beyond what Lesson 06 already pulled. Cookbook assets only. |
| **Prerequisites** | Lesson 06, including its `outputs/06/calibration.json`. Lesson 03 for the through-line — a canned scene record is provided if you took Module 2 first. |

Lesson 06 asked the model to invent a scene. This lesson gives it one and asks
what happens next. That difference is most of what makes generation useful for
data work: you rarely want *a* video, you want a video of **this**, varied in a
way you chose.
""")

nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Explain** the mechanism of first-frame conditioning: the image is encoded
   by the VAE and pinned as the first temporal slice of the latent, and the
   sampler denoises only the rest.
2. **Measure** what an `image2video` run preserved from its conditioning frame
   and what it invented, using frame-to-frame correlation rather than an
   impression.
3. **Predict** where image conditioning fails — ambiguous motion, contradicted
   prompts — and demonstrate both.
4. **Apply** the `"16,9"` comma-separated aspect format, and **diagnose** an
   aspect mismatch from output geometry rather than from an exit code.
5. **Compare** the same intent written as one sentence and as a structured JSON
   prompt, at a fixed seed, and **state** what structure buys you and what it
   does not.
6. **Build** a caption-to-video pipeline that takes a Lesson 03 scene record and
   produces a conditioned generation from it.
7. **Plan** each run against the calibration measured in Lesson 06, and report
   the prediction error.
""")

# =====================================================================
# Conceptual foundation
# =====================================================================
nb.md("""
## How an image becomes conditioning

In Lesson 06 the sampler started from pure noise everywhere and denoised
everything. Image conditioning changes one thing about that, and it is worth
being precise because the imprecise version ("the model looks at the image")
predicts the wrong failures.

The video latent has shape roughly `[C, T', H', W']` — channels, compressed
time, compressed height, compressed width. Your conditioning image is a single
frame, so it goes through the same VAE encoder and becomes **one temporal
slice**. That slice is then written into the latent and held fixed:

```
  latent time index:   0     1     2     3    ...   T'-1
                     +-----+-----+-----+-----+     +-----+
  at every step:     | FIX | noise|noise|noise| ... |noise|
                     +-----+-----+-----+-----+     +-----+
                        ^
                        |
                encoded conditioning image, re-imposed after every
                denoising step so it cannot drift
```

Every denoising step updates the whole latent, and then slice 0 is put back.
The rest of the tensor is being denoised in the presence of a slice that never
moves, and because the transformer attends across time, that fixed slice
constrains everything else.

Two consequences follow directly.

**Why `image2video` is usually more controllable than `text2video`.** A
structured prompt is a description; the model has enormous freedom in how to
realise it. A conditioning frame is not a description, it is an answer — the
composition, the palette, the lens, the objects and their positions are all
already decided. The model is no longer choosing the scene, only its future.

**Where it fails.** The model must invent plausible motion, and if the frame
does not imply any, it has to guess. A parked car on an empty road might drive
off, or the camera might pan, or nothing might happen; all three are consistent
with the frame. Ambiguous scenes drift, and "drift" here is not random noise but
the model committing to *some* interpretation and then following it. If your
prompt contradicts the image, something has to give — and which one gives is a
question you will answer by measurement rather than by reasoning about it.
""")

# =====================================================================
# Environment
# =====================================================================
nb.md("""
## Environment and prerequisites

Same configuration cell as always. `MODE="reduced"` keeps each run to a few
minutes; `MODE="full"` uses shipping settings.

The verification cell also loads `outputs/06/calibration.json`. Every run below
prints a predicted time before it starts, and the measured time afterwards. If
you skipped Lesson 06 the predictions come out as `n/a` and everything else
still works — but go back and do Lesson 06, because planning against a budget is
half of what makes a single GPU tolerable.
""")

nb.code('# This lesson writes to outputs/07/. The setup cell below reads this name.\n'
        '__lesson__ = "07"\n\n' + SETUP_CELL)

nb.code('''
import json
import shutil
import subprocess
import threading
import time

import numpy as np

from cosmos_course.config import ASPECT_RATIOS
from cosmos_course.measure import MeasurementLog
from cosmos_course.models import Generator

cc.require(DEVICE.startswith("cuda"),
           "No CUDA device is visible; the generation cells cannot run.",
           fix="Check `nvidia-smi` and `torch.cuda.is_available()`. If the Reasoner "
               "NIM is still up from Module 1, stop it: "
               "`from cosmos_course.nim import stop_nim, NimConfig; stop_nim(NimConfig())`")

generator = Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=True)

if MODE == "full":
    RES, N_FRAMES, N_STEPS = "480", 121, 35
else:
    RES, N_FRAMES, N_STEPS = "480", 61, 12

RUN_TIMEOUT = 3600 if MODE == "full" else 1800
RUN = (not framework_problems) and DEVICE.startswith("cuda")

# Lesson 06's calibration, if it exists. Predictions are for THIS machine only.
CALIB_PATH = cc.OUTPUT_ROOT / "06" / "calibration.json"
CALIB = json.loads(CALIB_PATH.read_text()) if CALIB_PATH.exists() else {}


def predict_seconds(resolution, num_frames, num_steps, aspect_ratio="16,9"):
    """Predicted wall clock from Lesson 06's calibration, or None."""
    ups = CALIB.get("units_per_second")
    if not ups:
        return None
    units = cc.estimate_generation_cost(
        resolution=resolution, num_frames=num_frames,
        num_steps=num_steps, aspect_ratio=aspect_ratio)["cost_units"]
    return (CALIB.get("fixed_overhead_s") or 0.0) + units / ups


log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
RUNS = {}

print()
print(f"mode {MODE!r}: {RES}p, {N_FRAMES} frames, {N_STEPS} steps")
print(f"calibration: {'loaded from ' + str(CALIB_PATH) if CALIB else 'MISSING (run Lesson 06)'}")
if CALIB.get("units_per_second"):
    print(f"  {CALIB['units_per_second']:,.0f} units/s, "
          f"{CALIB.get('fixed_overhead_s') or 0:.0f} s fixed overhead")
print(f"generation enabled: {RUN}")
''')

nb.md("""
The measurement harness is the same as Lesson 06's: a background thread samples
device-wide VRAM through `nvidia-smi` because the generator is a separate
process and this kernel's allocator cannot see it. `run_and_verify` adds one
thing here — it prints the predicted time before launching, so every run is a
small test of the calibration.
""")

nb.code('''
class GpuSampler:
    """Poll device-wide VRAM on a thread; report baseline and peak, in GB."""

    def __init__(self, interval=1.0, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_gb()
            if value is not None:
                self.samples.append(value)

    def __enter__(self):
        self.samples = [self._read_gb() or 0.0]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None
''')

nb.code('''
def run_and_verify(spec, subdir, *, label=None, timeout=None):
    """Predict, run, sample VRAM, verify by content, and record."""
    label = label or spec.name
    if not RUN:
        print(f"skipped {label!r}: generation is disabled")
        return None

    problems = cc.validate_spec(spec, strict=False)
    if problems:
        print("spec problems:", problems)

    predicted = predict_seconds(spec.resolution, spec.num_frames or 1,
                                spec.num_steps or 1, spec.aspect_ratio or "16,9")
    print(f"{label}: predicted "
          + (f"{predicted:.0f} s" if predicted else "n/a (no calibration)"))

    with GpuSampler() as sampler:
        with cc.timer(label, track_memory=False) as timing:
            result = generator.run(spec, OUTPUT_DIR / subdir, seed=spec.seed or 0,
                                   timeout=timeout or RUN_TIMEOUT)

    error = (100 * (predicted - timing.seconds) / timing.seconds) if predicted else None
    RUNS[label] = {"seconds": timing.seconds, "peak_gb": sampler.peak_gb,
                   "predicted_s": predicted, "prediction_error_pct": error,
                   "result": result}
    log.record(label=label, model=MODEL, mode=MODE,
               **{k: v for k, v in RUNS[label].items() if k != "result"})

    print(f"\\n  measured {timing.seconds:.1f} s"
          + (f"  (prediction off by {error:+.0f}%)" if error is not None else ""))
    print(f"  peak device VRAM {sampler.peak_gb:.1f} GB")
    print()
    cc.verify_result(result)
    return result
''')

# =====================================================================
# The cookbook pair
# =====================================================================
nb.md("""
## The cookbook's image and its prompt

`car_driving.jpg` and `car_driving.json` ship together, and reading them
together is the point: the prompt does not describe a scene from scratch, it
describes what should *happen* to the scene in the image. That is the shift in
how you write prompts for this mode, and it is easy to miss because the JSON
schema is identical to the one you used for `text2video`.
""")

nb.code('''
def compact(obj):
    """Serialise a structured prompt as the single string the framework wants."""
    if isinstance(obj, (str, Path)):
        obj = json.loads(Path(obj).read_text())
    return json.dumps(obj, ensure_ascii=True, separators=(",", ":"))


def image_wh(path):
    from PIL import Image
    with Image.open(path) as im:
        return im.size


COND_IMAGE = cc.asset("image_car_driving")
COND_PROMPT = json.loads(cc.asset("prompt_car_driving").read_text())
NEG_I2V = compact(cc.asset("neg_prompt_i2v"))

w, h = image_wh(COND_IMAGE)
print(f"conditioning image : {COND_IMAGE.name}  {w} x {h}  "
      f"(aspect {w / h:.3f})")
print(f"negative prompt    : {len(NEG_I2V):,} characters")
print()
print("prompt fields:")
for key, value in COND_PROMPT.items():
    text = json.dumps(value)
    print(f"  {key}: {text[:110]}{'...' if len(text) > 110 else ''}")

cc.show_image(COND_IMAGE, width=520, caption="the frame the model is given")
''')

nb.md("""
### Building the spec

Three fields do the conditioning work:

* `model_mode="image2video"` selects the mode. `validate_spec` will tell you
  this mode requires `prompt` and `vision_path`.
* `vision_path` points at the image. `write_spec` resolves it to an absolute
  path before writing, because the framework resolves conditioning paths
  **relative to the spec file** and relative-path confusion here produces a
  confusing failure a long way from its cause.
* `aspect_ratio` must be the comma-separated string form, and it should match
  the image. The next section is entirely about what happens when it does not.
""")

nb.code('''
i2v_spec = cc.InferenceSpec(
    model_mode="image2video",
    name="i2v_car_driving",
    prompt=compact(COND_PROMPT),
    negative_prompt=NEG_I2V,
    vision_path=str(COND_IMAGE),
    resolution=RES,
    aspect_ratio="16,9",
    num_frames=N_FRAMES,
    fps=24,
    num_steps=N_STEPS,
    guidance=7.0,
    shift=10.0,
    seed=0,
)
print(i2v_spec.describe())
print()

i2v_result = run_and_verify(i2v_spec, "i2v")
if i2v_result is not None and i2v_result.video_path:
    cc.show_video(i2v_result.video_path, width=560,
                  caption="image2video from car_driving.jpg")
''')

# =====================================================================
# What was preserved, what was invented
# =====================================================================
nb.md("""
## What did it keep, and what did it make up?

"The first frame is preserved" is a claim, and claims get measured. Take the
conditioning image and the generated video, convert both to grayscale at a
common size, and correlate the conditioning image against frames at several
points in the clip.

You should see a very high correlation at frame 0 — that slice was pinned — and
a correlation that falls as the clip progresses. **The rate at which it falls is
the model's invention.** A clip whose correlation stays at 1.0 throughout has
not animated anything; a clip whose correlation collapses immediately has thrown
your conditioning away.

Note what this does *not* measure. Correlation of grayscale intensity is
sensitive to a camera pan and insensitive to an object changing colour. It is a
crude instrument, chosen because it is transparent — you can predict what it
will do. Say that when you report it.
""")

nb.code('''
def read_frame(path, index=0):
    """Return one RGB frame as a numpy array, or None if it cannot be decoded."""
    try:
        import imageio.v3 as iio
        for i, frame in enumerate(iio.imiter(path)):
            if i == index:
                return np.asarray(frame)
    except Exception:
        pass
    try:
        import cv2
        cap = cv2.VideoCapture(str(path))
        cap.set(cv2.CAP_PROP_POS_FRAMES, index)
        ok, frame = cap.read()
        cap.release()
        if ok:
            return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    except Exception:
        pass
    return None


def gray(array_or_path, size=(160, 90)):
    """Grayscale, resized to a common grid so two sources are comparable."""
    from PIL import Image
    img = (Image.open(array_or_path) if isinstance(array_or_path, (str, Path))
           else Image.fromarray(np.asarray(array_or_path).astype(np.uint8)))
    return np.asarray(img.convert("L").resize(size), dtype=np.float64)


def correlate(a, b):
    """Pearson correlation of two equally-shaped arrays. 1.0 = identical."""
    x, y = a.ravel(), b.ravel()
    if x.std() < 1e-6 or y.std() < 1e-6:
        return float("nan")
    return float(((x - x.mean()) * (y - y.mean())).mean() / (x.std() * y.std()))


def preservation_profile(video_path, image_path, indices=(0, 10, 30, 60)):
    """Correlate the conditioning image against frames through the clip."""
    reference = gray(image_path)
    rows = []
    for i in indices:
        frame = read_frame(video_path, i)
        if frame is None:
            continue
        rows.append({"frame": i, "correlation": correlate(reference, gray(frame))})
    return rows


if i2v_result is not None and i2v_result.video_path:
    profile = preservation_profile(i2v_result.video_path, COND_IMAGE,
                                   indices=(0, N_FRAMES // 4, N_FRAMES // 2, N_FRAMES - 1))
    print(f"{'frame':>7} {'correlation with the conditioning image':>42}")
    for row in profile:
        bar = "#" * int(max(0.0, row["correlation"]) * 40)
        print(f"{row['frame']:>7} {row['correlation']:>10.4f}  {bar}")
    print()
    print("Frame 0 near 1.0 means the pinning worked. A steady decline afterwards")
    print("is the model animating. A flat line means nothing moved; a cliff means")
    print("the conditioning stopped mattering.")
else:
    profile = []
    print("No video to profile — generation was disabled or the run failed.")
''')

# =====================================================================
# Structured prompt vs one sentence
# =====================================================================
nb.md("""
## The structured prompt, against one sentence

The source DLI course says this once, in passing, and never returns to it:

> Cosmos 3 generation takes a **structured JSON prompt** (a rich,
> attribute-by-attribute scene description) rather than a single sentence.

That is true and it is the least helpful true thing in the package, because it
tells you *what* without telling you *why* or *how much it matters*. The model
will accept a single sentence. Nothing rejects it. So the question is not
whether prose works — it is what you give up by using it.

Here is the experiment. One intent, stated in English once, expressed two ways,
generated with **the same seed, the same conditioning image and the same
everything else**, so the prompt string is the only thing that differs.

**The intent.** *The car keeps driving forward along the same road. Late
afternoon, low sun, long shadows. The chase camera holds its position behind the
car and does not move. Nothing else enters the frame. Documentary realism, no
stylisation.*

That paragraph is the specification. Both encodings below are attempts at it,
and you should read them and satisfy yourself that neither is a straw man before
you predict anything.
""")

nb.code('''
# ---------------------------------------------------------------- encoding A
# One sentence. What almost everyone types first.
SENTENCE_PROMPT = (
    "The car keeps driving forward along the same road in the late afternoon "
    "with low sun and long shadows, filmed from a chase camera that holds its "
    "position behind the car, with nothing else entering the frame, in a "
    "documentary realistic style."
)

# ---------------------------------------------------------------- encoding B
# The same intent, one attribute per key.
STRUCTURED_PROMPT = {
    "description": "The car continues driving forward along the same road.",
    "subjects": [
        {"name": "car", "action": "drives forward at a steady speed, staying in lane"}
    ],
    "scene": {"location": "the same road", "time_of_day": "late afternoon"},
    "lighting": "low sun, long shadows, warm directional light",
    "camera": {"motion": "chase camera holding position behind the car",
               "framing": "unchanged throughout"},
    "style": "documentary realism, natural colour, no stylisation",
}

print(f"sentence   : {len(SENTENCE_PROMPT):>5} characters, 1 addressable unit")
print(f"structured : {len(compact(STRUCTURED_PROMPT)):>5} characters, "
      f"{len(STRUCTURED_PROMPT)} addressable units "
      f"({', '.join(STRUCTURED_PROMPT)})")
print()
print("Roughly the same information. Read both again and check that.")
print("The difference is not what is said. It is what is separately nameable.")
''')

nb.md("""
### Addressability, before any GPU is involved

The argument for structure does not need a generation to make itself. It is
about what happens on the **second** attempt, which is where all the real work
is: you looked at the output, one thing was wrong, and you want to change that
one thing and nothing else.

The cell below performs the same edit — *make it overcast instead of low sun* —
on both encodings, and reports how much of each prompt the edit disturbed. This
runs everywhere, with or without a GPU, because it is string manipulation.
""")

nb.code('''
import difflib

def edit_distance_fraction(before, after):
    """Fraction of the prompt string that changed, by difflib's similarity ratio."""
    return 1.0 - difflib.SequenceMatcher(None, before, after).ratio()


# The edit, on the structured prompt: assign one key.
structured_edited = dict(STRUCTURED_PROMPT)
structured_edited["lighting"] = "flat overcast daylight, no visible shadows, cool white balance"

# The same edit, on the sentence: there is no key to assign, so you rewrite the
# clause -- and to do that you first have to find it, which is the whole problem.
sentence_edited = SENTENCE_PROMPT.replace(
    "in the late afternoon with low sun and long shadows",
    "under flat overcast daylight with no visible shadows",
)

pairs = [
    ("structured", compact(STRUCTURED_PROMPT), compact(structured_edited)),
    ("sentence", SENTENCE_PROMPT, sentence_edited),
]
print(f"{'encoding':<12} {'changed':>9}  {'keys touched':>13}")
for label, before, after in pairs:
    frac = edit_distance_fraction(before, after)
    keys = "1 of %d" % len(STRUCTURED_PROMPT) if label == "structured" else "n/a"
    print(f"{label:<12} {frac:>8.1%}  {keys:>13}")

print()
print("Do not read too much into the percentages. Both are small, both depend on")
print("how the two prompts happen to be worded, and neither settles anything.")
print()
print("The point is the third column, and the fact that the sentence edit above")
print("is a `str.replace` with a hard-coded clause in it. It works because the")
print("author knew the exact substring. Change the sentence and it silently")
print("becomes a no-op -- try it: `SENTENCE_PROMPT.replace('afternoon sun', ...)`")
print("returns the string unchanged and reports no error. The structured edit")
print("cannot fail that way, because `d['lighting'] = x` either sets the field or")
print("there is no such field.")
print()
print("A prompt you can address by name is a prompt you can sweep, template,")
print("diff and generate from a scene record. Lesson 03's records became a")
print("prompt later in this lesson for exactly this reason -- try writing")
print("`record_to_prompt` so it emits a fluent English sentence instead.")
''')

nb.predict_run_explain(
    predict=(
        "The next two cells generate the same intent twice — once from "
        "`SENTENCE_PROMPT`, once from `STRUCTURED_PROMPT` — at seed 0, on the "
        "same conditioning image, with everything else identical. Commit to "
        "answers for two separate questions, because they have different "
        "answers. **(a) Control:** which encoding gives you more control over "
        "the result, and what do you mean by control — is it a claim about this "
        "one output, or about what you can do next? **(b) Output:** will the "
        "two clips differ *visibly*? Predict yes or no, and predict what the "
        "correlation profiles will look like relative to each other."
    ),
    change=(
        "Nothing to edit yet. Write both predictions down. Then decide, before "
        "running, what result would make you say the structured prompt was not "
        "worth the trouble — if no result could, you are not predicting, you "
        "are rooting."
    ),
    explain=(
        "Most people predict yes to (b) and are surprised. Explain the result "
        "you got in terms of where the two prompts differ: they contain nearly "
        "the same words, and the encoder sees text either way. Then explain why "
        "your answer to (a) does not depend on your answer to (b) at all."
    ),
    hint=(
        "There is no JSON parser in the text encoder. The structured prompt is "
        "serialised to a string and tokenised like any other string — the braces "
        "and quotes become tokens. So the model is not 'reading fields'. The "
        "structure is a discipline for the *human* and a contract for the *code "
        "that generates prompts*, and those are worth having whether or not a "
        "single output changes."
    ),
)

nb.code('''
# Same seed, same image, same geometry, same steps. Only the prompt differs.
COMPARISON_SEED = 0

sentence_spec = cc.InferenceSpec(
    model_mode="image2video", name="prompt_sentence",
    prompt=SENTENCE_PROMPT,               # a bare string, not compact(...)
    negative_prompt=NEG_I2V,
    vision_path=str(COND_IMAGE),
    resolution=RES, aspect_ratio="16,9",
    num_frames=N_FRAMES, fps=24, num_steps=N_STEPS,
    guidance=7.0, shift=10.0, seed=COMPARISON_SEED,
)

structured_spec = cc.InferenceSpec(
    model_mode="image2video", name="prompt_structured",
    prompt=compact(STRUCTURED_PROMPT),    # the same dict, serialised
    negative_prompt=NEG_I2V,
    vision_path=str(COND_IMAGE),
    resolution=RES, aspect_ratio="16,9",
    num_frames=N_FRAMES, fps=24, num_steps=N_STEPS,
    guidance=7.0, shift=10.0, seed=COMPARISON_SEED,
)

# Prove the specs are identical except for the prompt, rather than asserting it.
from dataclasses import fields as dataclass_fields

differing = sorted(
    f.name for f in dataclass_fields(cc.InferenceSpec)
    if getattr(sentence_spec, f.name) != getattr(structured_spec, f.name)
)
print(f"fields that differ between the two specs: {differing}")
print("Expected: ['name', 'prompt'] and nothing else. If anything else appears,")
print("the comparison is confounded and the result below means nothing.")
''')

nb.code('''
sentence_result = run_and_verify(sentence_spec, "prompt_sentence")
structured_result = run_and_verify(structured_spec, "prompt_structured")
''')

nb.code('''
indices = (0, N_FRAMES // 4, N_FRAMES // 2, N_FRAMES - 1)
comparison = {}
for label, res in (("sentence", sentence_result), ("structured", structured_result)):
    if res is None or not res.video_path:
        continue
    comparison[label] = {
        "profile": {r["frame"]: r["correlation"]
                    for r in preservation_profile(res.video_path, COND_IMAGE, indices)},
        "metrics": cc.check_video(res.video_path).metrics,
    }

if len(comparison) == 2:
    print(f"{'frame':>7} {'sentence':>10} {'structured':>12} {'difference':>12}")
    for i in indices:
        s = comparison["sentence"]["profile"].get(i)
        t = comparison["structured"]["profile"].get(i)
        gap = f"{t - s:+.4f}" if (s is not None and t is not None) else "-"
        print(f"{i:>7} {(f'{s:.4f}' if s is not None else '-'):>10} "
              f"{(f'{t:.4f}' if t is not None else '-'):>12} {gap:>12}")
    print()
    print(f"{'metric':<24} {'sentence':>10} {'structured':>12}")
    for key in ("mean_frame_difference", "mid_frame_std", "mid_frame_autocorrelation"):
        s = comparison["sentence"]["metrics"].get(key)
        t = comparison["structured"]["metrics"].get(key)
        if s is None and t is None:
            continue
        print(f"{key:<24} {(f'{s:.4f}' if s is not None else '-'):>10} "
              f"{(f'{t:.4f}' if t is not None else '-'):>12}")
    print()
    print("Two clips at one seed. Whatever the gaps are, they are one sample of")
    print("a distribution and they do not establish that either prompt shape")
    print("produces better video. Say that when you report it.")
else:
    print("Generation is disabled or a run failed, so there are no clips to compare.")
    print()
    print("The addressability result above is the part that does not need a GPU,")
    print("and it is the part the argument actually rests on. If you want the")
    print("clips, set MODE and re-run with a working framework venv; nothing")
    print("below this cell depends on them.")

for label, res in (("sentence", sentence_result), ("structured", structured_result)):
    if res is not None and res.video_path:
        cc.show_video(res.video_path, width=440, caption=f"{label} prompt, seed {COMPARISON_SEED}")
''')

nb.md("""
### What this does and does not show

**Does not show.** That structured prompts produce better video. Two clips at
one seed cannot support that, and the honest expectation is that the outputs
look broadly similar — the two strings contain nearly the same words, and the
text encoder tokenises both as text. There is no JSON parser in the model.

**Does show.** That the structured prompt is the one you can *operate on*.
Every claim in it has a name, so you can change one and hold the rest; you can
sweep a field across values; you can generate one mechanically from a Lesson 03
scene record, which is what the last section of this lesson does; and you can
diff two prompts and get a list of what changed rather than a paragraph.

That is the honest version of the source's sentence. Structure is not a request
the model makes. It is what you need in order to run an experiment on a prompt
instead of retyping it.
""")

nb.callout("note", """
The cookbook's shipped prompts under `assets/prompts/` are all structured, which
is a useful signal about how NVIDIA expects these models to be driven — but note
what it is *not*: nothing in the framework validates the shape. `prompt` is a
string field. `compact()` exists in this notebook only to turn a dict into that
string, and passing a bare sentence, as `sentence_spec` does above, is accepted
without complaint. The discipline is entirely yours to keep.
""")

# =====================================================================
# Aspect ratio and geometry
# =====================================================================
nb.md("""
## Aspect ratio: a comma, not a colon

The framework wants `"16,9"`. Not `"16:9"`, not `16/9`, not `1.778`. Five values
are accepted: `16,9`, `9,16`, `1,1`, `4,3`, `3,4`.

This looks like pedantry and it is not, because of what `resolution` means here.
`resolution` is a **tier name** — a pixel budget — and `aspect_ratio` decides how
that budget is spent between width and height. `resolution_wh("480", "16,9")`
gives 832 × 480; `resolution_wh("480", "1,1")` gives roughly 640 × 640. Same
budget, very different picture.

So the aspect ratio is not cosmetic. It changes the shape of the latent, which
changes the token count, which changes both the cost and what fits.
""")

nb.callout("gotcha", """
`validate_spec` checks the aspect format explicitly and, when it sees a colon,
tells you to use a comma. That check exists because the framework's own error
for this is not clear, and because the failure mode when a *valid but wrong*
ratio slips through is silent — which is the debugging lab at the end of this
lesson.
""")

nb.code('''
def aspect_value(spec_string):
    aw, ah = (float(x) for x in spec_string.split(","))
    return aw / ah


def nearest_aspect(width, height):
    """The accepted aspect string closest to an actual image's shape."""
    target = width / height
    return min(ASPECT_RATIOS, key=lambda a: abs(aspect_value(a) - target))


print(f"{'aspect':>7} {'value':>7} {'480 tier w x h':>16} {'tokens (61 frames)':>20}")
for ratio in ASPECT_RATIOS:
    rw, rh = cc.resolution_wh("480", ratio)
    tokens = cc.estimate_generation_cost(resolution="480", aspect_ratio=ratio,
                                         num_frames=61, num_steps=1)["latent_tokens"]
    print(f"{ratio:>7} {aspect_value(ratio):>7.3f} {rw:>7} x {rh:<6} {tokens:>20,}")

print()
print(f"conditioning image is {w} x {h} (aspect {w / h:.3f})")
print(f"nearest accepted aspect: {nearest_aspect(w, h)!r}")
print()
print("The tier is a pixel budget; the aspect decides how it is spent. Note the")
print("token counts are close but not equal — the rounding to multiples of 16")
print("does not preserve area exactly.")
''')

# =====================================================================
# Predict-run-explain 1
# =====================================================================
nb.predict_run_explain(
    predict=(
        "The next run conditions on a still of a humanoid robot standing in a "
        "room, with a prompt that says the robot remains stationary and the "
        "camera does not move. Predict: does the output contain motion? Commit "
        "to yes or no, and to what `check_video` will say about it — that check "
        "*fails* a clip whose mean frame difference is under 0.15."
    ),
    change=(
        "Nothing to edit. Write your prediction down, including whether you "
        "expect the verification to pass or fail."
    ),
    explain=(
        "Compare the mean frame difference of this clip against the car clip. "
        "Then explain the result in terms of the training distribution: what "
        "fraction of the videos this model saw contained no motion at all?"
    ),
    hint=(
        "The model was trained on video, and video mostly moves. A generator "
        "conditioned on 'nothing happens' is being asked for a sample from a "
        "region of the distribution that is nearly empty. Whether it obeys, and "
        "what it does instead if it cannot, is exactly the question."
    ),
)

nb.code('''
STATIC_IMAGE = cc.asset("image_humanoid_robot")
sw, sh = image_wh(STATIC_IMAGE)

static_prompt = {
    "description": ("A humanoid robot stands still. Nothing in the scene moves. "
                    "The camera is locked off on a tripod and does not move."),
    "subjects": [{"name": "humanoid robot", "action": "stands motionless, no gesture"}],
    "camera": {"motion": "static, locked off", "framing": "unchanged throughout"},
    "style": "documentary realism, natural colour",
}

static_spec = cc.InferenceSpec(
    model_mode="image2video", name="i2v_static",
    prompt=compact(static_prompt), negative_prompt=NEG_I2V,
    vision_path=str(STATIC_IMAGE),
    resolution=RES, aspect_ratio=nearest_aspect(sw, sh),
    num_frames=N_FRAMES, fps=24, num_steps=N_STEPS,
    guidance=7.0, shift=10.0, seed=0,
)
static_result = run_and_verify(static_spec, "static")

print()
print(f"{'clip':<16} {'mean frame difference':>24}")
for label, res in (("car (moving)", i2v_result), ("robot (asked to be still)", static_result)):
    if res is not None and res.video_path:
        value = cc.check_video(res.video_path).metrics.get("mean_frame_difference")
        print(f"{label:<26} {value:>18.4f}")
print()
print("check_video's floor is 0.15. A clip below it is reported as a failure —")
print("which is correct behaviour for an aliveness check and the wrong verdict")
print("for a clip you deliberately asked to be still. The check does not know")
print("your intent. That is a limitation to state, not a bug to silence.")
''')

# =====================================================================
# Predict-run-explain 2
# =====================================================================
nb.predict_run_explain(
    predict=(
        "Now the prompt contradicts the image outright: the conditioning frame "
        "is a car on a road, and the prompt describes a kitchen with a robot at "
        "a worktop. Predict which wins. Does the clip start as a road and become "
        "a kitchen? Stay a road? Become an incoherent hybrid? Commit to one."
    ),
    change=(
        "Nothing to edit. Then decide, before running, what number would settle "
        "it — you already have `preservation_profile`."
    ),
    explain=(
        "Read the correlation profile. If frame 0 is still near 1.0 but later "
        "frames fall much faster than in the honest run, the conditioning held "
        "and the prompt pulled the future away from it. Explain that using the "
        "pinned-slice diagram: which part of the latent could the prompt "
        "actually influence?"
    ),
    hint=(
        "Slice 0 is re-imposed after every step, so no prompt can change it. "
        "Everything the prompt can affect is downstream of a frame it disagrees "
        "with, and the transformer has to reconcile the two through temporal "
        "attention. Watch what the reconciliation looks like."
    ),
)

nb.code('''
contradiction_prompt = {
    "description": ("A domestic kitchen. A white service robot stands at a marble "
                    "worktop chopping vegetables with a knife."),
    "subjects": [{"name": "service robot", "action": "chops vegetables steadily"}],
    "scene": {"location": "kitchen", "surfaces": "marble worktop, tiled splashback"},
    "lighting": "warm indoor light from above",
    "camera": {"motion": "static", "framing": "medium shot"},
}

contradiction_spec = cc.InferenceSpec(
    model_mode="image2video", name="i2v_contradiction",
    prompt=compact(contradiction_prompt), negative_prompt=NEG_I2V,
    vision_path=str(COND_IMAGE),          # a road; the prompt says kitchen
    resolution=RES, aspect_ratio="16,9",
    num_frames=N_FRAMES, fps=24, num_steps=N_STEPS,
    guidance=7.0, shift=10.0, seed=0,
)
contradiction_result = run_and_verify(contradiction_spec, "contradiction")

indices = (0, N_FRAMES // 4, N_FRAMES // 2, N_FRAMES - 1)
print()
print(f"{'frame':>7} {'agreeing prompt':>17} {'contradicting prompt':>22}")
honest = {r["frame"]: r["correlation"] for r in profile}
if contradiction_result is not None and contradiction_result.video_path:
    other = {r["frame"]: r["correlation"] for r in
             preservation_profile(contradiction_result.video_path, COND_IMAGE, indices)}
    for i in indices:
        a = honest.get(i)
        b = other.get(i)
        print(f"{i:>7} {(f'{a:.4f}' if a is not None else '-'):>17} "
              f"{(f'{b:.4f}' if b is not None else '-'):>22}")
    print()
    print("Watch the last row rather than the first. Frame 0 is pinned in both")
    print("runs and tells you nothing about the conflict.")

if contradiction_result is not None and contradiction_result.video_path:
    cc.show_video(contradiction_result.video_path, width=520,
                  caption="prompt contradicts the conditioning frame")
''')

# =====================================================================
# Your own image
# =====================================================================
nb.md("""
## Your own image

Cookbook assets are chosen to work. Yours are not, and that is the point — the
gap between "it works on the demo" and "it works on my data" is where most of
the real difficulty lives.

Set `MY_IMAGE` to a path of your own. Anything Pillow can open will do. The cell
picks the nearest accepted aspect ratio for you rather than assuming 16:9, which
is the single most common cause of a disappointing first result on a personal
image.
""")

nb.code('''
# Point this at an image of your own. Leave it None to use a cookbook still.
MY_IMAGE = None

my_image_path = Path(MY_IMAGE) if MY_IMAGE else cc.asset("image_humanoid_robot")
if not my_image_path.exists():
    raise FileNotFoundError(
        f"{my_image_path} does not exist. Set MY_IMAGE to a readable image, or "
        f"leave it None to fall back to a cookbook asset. If a cookbook asset is "
        f"missing, run scripts/fetch_assets.py."
    )

mw, mh = image_wh(my_image_path)
my_aspect = nearest_aspect(mw, mh)
gw, gh = cc.resolution_wh(RES, my_aspect)
print(f"image          : {my_image_path.name}  {mw} x {mh}  (aspect {mw / mh:.3f})")
print(f"nearest aspect : {my_aspect!r}")
print(f"output geometry: {gw} x {gh}")
distortion = abs((gw / gh) / (mw / mh) - 1)
print(f"shape error    : {distortion:.1%}"
      + ("  — acceptable" if distortion < 0.12 else "  — expect visible letterbox or stretch"))

my_prompt = {
    "description": "Describe what should happen next in this scene, in one or two sentences.",
    "subjects": [{"name": "main subject", "action": "the motion you want"}],
    "camera": {"motion": "static", "framing": "unchanged"},
    "style": "documentary realism, natural colour",
}

my_spec = cc.InferenceSpec(
    model_mode="image2video", name="i2v_mine",
    prompt=compact(my_prompt), negative_prompt=NEG_I2V,
    vision_path=str(my_image_path),
    resolution=RES, aspect_ratio=my_aspect,
    num_frames=N_FRAMES, fps=24, num_steps=N_STEPS,
    guidance=7.0, shift=10.0, seed=0,
)
my_result = run_and_verify(my_spec, "mine")
if my_result is not None and my_result.video_path:
    cc.show_video(my_result.video_path, width=520, caption=f"animated from {my_image_path.name}")
''')

# =====================================================================
# The through-line
# =====================================================================
nb.md("""
## The through-line: a caption becomes a prompt

This is the loop the source course describes in every introduction and never
builds. In Lesson 03 the reasoner watched cookbook clips and wrote structured
scene records to `outputs/03/scene_records.jsonl`, with the fields `subjects`,
`setting`, `actions`, `lighting` and `camera`. Those five fields were chosen
because they are what Module 2 knows how to condition on — which is only useful
if someone actually connects the two ends.

So: read a record the reasoner wrote, turn it into a generation prompt, and
animate a frame with it. If you took Module 2 first, a canned record stands in;
it is marked as canned so nobody mistakes it for their own output.
""")

nb.code('''
CANNED_RECORD = {
    "clip": "canned_example",
    "record": {
        "subjects": ["a silver sedan", "a two-lane road", "roadside trees"],
        "setting": "a rural road on an overcast afternoon, hills in the distance",
        "actions": ["the car travels forward along the road",
                    "the trees pass on the left"],
        "lighting": "flat overcast daylight, soft shadows, cool white balance",
        "camera": "chase view from behind and slightly above the car, moving with it",
    },
    "provenance": {"canned": True,
                   "why": "stand-in for outputs/03/scene_records.jsonl"},
}

records_path = cc.OUTPUT_ROOT / "03" / "scene_records.jsonl"
if records_path.exists():
    rows = [json.loads(line) for line in
            records_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    source_row = rows[0]
    print(f"using a real Lesson 03 record: {source_row['clip']} "
          f"({len(rows)} available)")
else:
    source_row = CANNED_RECORD
    print("outputs/03/scene_records.jsonl not found — using the CANNED record.")
    print("  This is a stand-in, not your output. Run Lesson 03 to close the loop")
    print("  properly; the capstone in Lesson 19 needs the real thing.")

record = source_row["record"]
print()
print(json.dumps(record, indent=2)[:600])


def record_to_prompt(rec):
    """Map a Lesson 03 scene record onto a Cosmos 3 structured prompt.

    The mapping is deliberately mechanical and lossy in one direction: a caption
    describes what WAS, a generation prompt describes what SHOULD BE. Nothing
    here invents detail the reasoner did not report.
    """
    subjects = rec.get("subjects") or []
    actions = rec.get("actions") or []
    return {
        "description": f"{rec.get('setting', 'unknown setting')}. "
                       + " ".join(actions[:3]),
        "subjects": [{"name": s, "action": actions[i] if i < len(actions) else "as described"}
                     for i, s in enumerate(subjects[:3])],
        "scene": {"location": rec.get("setting", "unknown")},
        "lighting": rec.get("lighting", "unknown"),
        "camera": {"framing": rec.get("camera", "unknown"), "motion": "as described"},
        "style": "documentary realism, natural colour, no stylisation",
    }


chained_prompt = record_to_prompt(record)
print()
print("generated prompt:")
print(json.dumps(chained_prompt, indent=2)[:600])
''')

nb.code('''
chained_spec = cc.InferenceSpec(
    model_mode="image2video", name="i2v_from_caption",
    prompt=compact(chained_prompt), negative_prompt=NEG_I2V,
    vision_path=str(COND_IMAGE),
    resolution=RES, aspect_ratio="16,9",
    num_frames=N_FRAMES, fps=24, num_steps=N_STEPS,
    guidance=7.0, shift=10.0, seed=0,
)
chained_result = run_and_verify(chained_spec, "from_caption")
if chained_result is not None and chained_result.video_path:
    cc.show_video(chained_result.video_path, width=560,
                  caption="reasoner caption -> structured prompt -> conditioned video")
''')

nb.checkpoint(
    "Six conditioned runs should exist and be verified: the cookbook pair, the "
    "sentence and structured prompts, the static test, the contradiction, and "
    "the caption-driven one. If fewer than four passed every check, stop and "
    "read the failures — the exercises build on this machinery.",
    '''
for name, entry in RUNS.items():
    if entry["result"] is None:
        print(f"  {name:<22} did not run")
        continue
    failed = [c.name for c in cc.verify_result(entry["result"], verbose=False)
              if not c.passed]
    verdict = "OK" if not failed else "FAILED " + ",".join(failed)
    err = entry.get("prediction_error_pct")
    print(f"  {name:<22} {entry['seconds']:>7.1f} s  "
          + (f"pred {err:+5.0f}%  " if err is not None else "" ) + verdict)
''')

# =====================================================================
# Debugging lab
# =====================================================================
nb.md("""
## Debugging lab — the aspect mismatch that exits zero

### Symptom

You conditioned on a 16:9 photograph, asked for a square output because you
wanted it for a square display, and the run finished. Exit code 0. A file was
written. `check_video` passed: the frames decode, they have spatial structure,
and they move.

And the video is wrong. The car is squashed, or there are black bars, or the
composition you chose has been cropped away. Nothing in the exit code, nothing
in the log, and nothing in `check_video` will tell you this, because from every
one of those points of view the run succeeded.

This is the general shape of the most expensive class of bug in generative
pipelines: **the machine did what you asked, and what you asked was wrong.** The
only instrument that catches it is one that compares the output against your
*intent*, and intent is not in the spec.
""")

nb.code('''
# Deliberately wrong: a 16:9 conditioning image forced into a 1:1 output.
mismatch_spec = cc.InferenceSpec(
    model_mode="image2video", name="i2v_mismatch",
    prompt=compact(COND_PROMPT), negative_prompt=NEG_I2V,
    vision_path=str(COND_IMAGE),
    resolution=RES,
    aspect_ratio="1,1",              # <- the bug. The image is 16:9.
    num_frames=N_FRAMES, fps=24, num_steps=max(8, N_STEPS // 2),
    guidance=7.0, shift=10.0, seed=0,
)

print("validate_spec says:", cc.validate_spec(mismatch_spec, strict=False) or "no problems")
print()
print("Read that carefully. '1,1' is a legal aspect ratio, so the validator is")
print("silent. Validation checks that a spec is well formed. It cannot check")
print("that a spec is what you meant.")
print()

mismatch_result = run_and_verify(mismatch_spec, "mismatch", label="i2v_mismatch")
''', tags=["teaching-antipattern"])

nb.md("""
### Hypothesis and diagnosis

Hypothesis: the output geometry follows the spec, not the conditioning image,
and the conditioning image has been squeezed or cropped to fit.

The diagnostic is not the exit code and not `check_video`'s verdict. It is
**geometry**: read the width and height of the output, compute its aspect, and
compare against the conditioning image's aspect. If they differ by more than the
rounding to multiples of 16 can explain, the image was reshaped.

Do this as a reusable function, because you will want it in every pipeline you
build after this one. Note that it returns a verdict *and* the numbers behind
it — a checker that only says "fail" trains people to ignore it.
""")

nb.code('''
def video_wh(path):
    """Pixel geometry of a video: ffprobe first, a decoded frame second.

    Deliberately NOT read from `cc.check_video(path).metrics`. That function is
    an *aliveness* check and it returns early — on a file under 5 KB, or one it
    cannot decode — before it ever records a width. Reaching into a checker's
    metrics for metadata is a category error, and it fails exactly on the
    degenerate files you most want geometry for.
    """
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        try:
            out = subprocess.run(
                [ffprobe, "-v", "error", "-select_streams", "v:0",
                 "-show_entries", "stream=width,height", "-of", "csv=p=0:s=x", str(path)],
                capture_output=True, text=True, timeout=60, check=True).stdout.strip()
            width, height = out.splitlines()[0].split("x")
            return int(width), int(height)
        except Exception:
            pass
    frame = read_frame(path, 0)
    if frame is not None:
        return frame.shape[1], frame.shape[0]
    return None, None


def check_geometry(video_path, image_path, tolerance=0.05):
    """Does the output's aspect match the conditioning image's?"""
    iw, ih = image_wh(image_path)
    vw, vh = video_wh(video_path)
    if not vw or not vh:
        return {"ok": None, "reason": "could not read the output's geometry"}
    source, output = iw / ih, vw / vh
    error = abs(output / source - 1)
    return {"ok": error <= tolerance,
            "source_wh": (iw, ih), "output_wh": (vw, vh),
            "source_aspect": round(source, 4), "output_aspect": round(output, 4),
            "relative_error": round(error, 4),
            "reason": ("aspects agree" if error <= tolerance else
                       f"output aspect is {error:.0%} away from the conditioning image; "
                       f"the frame was letterboxed, cropped or stretched")}


for label, res in (("honest run", i2v_result), ("mismatched run", mismatch_result)):
    if res is None or not res.video_path:
        print(f"{label:<16} did not run")
        continue
    verdict = check_geometry(res.video_path, COND_IMAGE)
    print(f"{label:<16} {verdict['source_wh']} -> {verdict['output_wh']}   "
          f"aspect {verdict['source_aspect']} -> {verdict['output_aspect']}   "
          f"{'OK' if verdict['ok'] else 'MISMATCH'}")
    print(f"                 {verdict['reason']}")

print()
print("For contrast, here is the version of this mistake that IS caught:")
typo = dict(model_mode="image2video", name="typo", prompt="x",
            vision_path=str(COND_IMAGE), aspect_ratio="16:9")
for problem in cc.validate_spec(typo, strict=False):
    print("  " + problem)
''')

nb.md("""
### Repair and verification

The repair is to derive the aspect ratio from the image rather than typing it,
and then to verify the geometry rather than trusting it. `nearest_aspect` picks
the closest accepted string; `check_geometry` proves the output honoured it.

If you genuinely want a square output from a 16:9 source, that is a legitimate
choice — but it is a *crop*, and you should do the crop yourself, on the
conditioning image, before it reaches the model. Then the model is conditioned
on exactly the frame you intend and the geometry agrees all the way through.
""")

nb.code('''
repaired_spec = cc.InferenceSpec(
    model_mode="image2video", name="i2v_repaired",
    prompt=compact(COND_PROMPT), negative_prompt=NEG_I2V,
    vision_path=str(COND_IMAGE),
    resolution=RES,
    aspect_ratio=nearest_aspect(*image_wh(COND_IMAGE)),   # derived, not typed
    num_frames=N_FRAMES, fps=24, num_steps=max(8, N_STEPS // 2),
    guidance=7.0, shift=10.0, seed=0,
)
print(f"derived aspect_ratio: {repaired_spec.aspect_ratio!r}")

repaired_result = run_and_verify(repaired_spec, "repaired", label="i2v_repaired")

if repaired_result is not None and repaired_result.video_path:
    verdict = check_geometry(repaired_result.video_path, COND_IMAGE)
    print()
    print(json.dumps(verdict, indent=2))
    assert verdict["ok"] is not False, \\
        "the repair did not fix the geometry — read the numbers above"
    print()
    print("Verified by geometry, not by exit code. Both runs exited 0; only one")
    print("of them produced what was intended.")
''')

# =====================================================================
# Exercises
# =====================================================================
nb.md("""
## Exercises
""")

nb.exercise(
    "foundation",
    "Three first frames, one prompt",
    goal=(
        "Establish how much of the output is decided by the conditioning frame "
        "by holding everything else constant and changing only the frame."
    ),
    instructions=(
        "1. Choose three conditioning images that differ substantially — the "
        "cookbook ships `image_car_driving`, `image_humanoid_robot` and "
        "`image_coastal_road_audio`, or use your own.\n"
        "2. Write **one** prompt general enough to be plausible for all three. "
        "Something about motion and camera behaviour rather than about content.\n"
        "3. Generate all three at a fixed seed, resolution, step count and "
        "guidance, deriving each aspect ratio from its own image.\n"
        "4. Report `preservation_profile` for each and put the three curves on "
        "one plot.\n"
        "5. Answer in writing: which frame produced the most motion, which the "
        "least, and what property of the image predicts that? Then say whether "
        "you could have predicted it in advance."
    ),
    success=(
        "Three verified videos, three preservation profiles on one plot, and a "
        "written answer that names a property of the images rather than "
        "restating the result."
    ),
    starter='''
FRAMES = ["image_car_driving", "image_humanoid_robot", "image_coastal_road_audio"]
SHARED_PROMPT = {
    "description": "The scene continues naturally for a few seconds.",
    "camera": {"motion": "static, locked off"},
    "style": "documentary realism, natural colour",
}

frame_profiles = {}
for name in FRAMES:
    path = cc.asset_or_none(name)
    if path is None:
        print(f"{name}: missing — run scripts/fetch_assets.py")
        continue
    # Build the spec, derive the aspect from image_wh(path), run it,
    # then store preservation_profile(video, path) in frame_profiles[name].
    pass

print(f"{len(frame_profiles)} profile(s)")
''',
    hints=[
        "Derive each aspect ratio with `nearest_aspect(*image_wh(path))`. Using "
        "16,9 for all three would introduce a second variable and quietly ruin "
        "the comparison — which is the mistake the debugging lab exists to make "
        "memorable.\n\n"
        "The property that predicts motion is usually whether the frame contains "
        "an object that is *obviously mid-action*. A car on a road is; a robot "
        "standing still is not.",
    ],
    solution_ref="solutions/07_solutions.ipynb",
)

nb.exercise(
    "applied",
    "A caption-to-video pipeline",
    goal=(
        "Build `animate(image_path)` — a function that takes any image, captions "
        "it with the reasoner, converts the caption into a structured prompt, "
        "and returns a verified video."
    ),
    instructions=(
        "1. Write `caption_image(path)` that sends the image to the Reasoner NIM "
        "with the Lesson 03 schema and returns a parsed record. The NIM competes "
        "with the generator for VRAM, so decide and document your strategy: take "
        "turns (`stop_nim` before generating) or cap the NIM's memory. Lesson 02 "
        "measured both.\n"
        "2. Reuse `record_to_prompt`, or improve it — its current mapping is "
        "deliberately mechanical and you can do better.\n"
        "3. Write `animate(path)` that chains caption, prompt, spec, run and "
        "`verify_result`, and returns a dict with the caption, the prompt, the "
        "output path and the check results.\n"
        "4. Run it over at least three images and report the yield: how many "
        "produced a video that passed every check.\n"
        "5. Handle the failure cases explicitly — the NIM being down, an "
        "unparseable caption, a failed generation — and say what your function "
        "does in each. Returning `None` for all three is not handling them."
    ),
    success=(
        "`animate()` runs end to end on three images without manual "
        "intervention, reports a yield, and its docstring states the VRAM "
        "strategy and why."
    ),
    starter='''
from cosmos_course.models import Reasoner


def caption_image(path, *, fps=4):
    """Caption one image into a Lesson 03 scene record. Raises on a bad parse."""
    raise NotImplementedError


def animate(image_path, *, seed=0):
    """Image -> caption -> structured prompt -> verified video.

    VRAM strategy: <state it here, and why you chose it>
    """
    raise NotImplementedError


def report_yield(results):
    ok = [r for r in results if r and all(c.passed for c in r["checks"])]
    print(f"yield: {len(ok)}/{len(results)} passed every check")
    for r in results:
        if not r:
            continue
        bad = [c.name for c in r["checks"] if not c.passed]
        print(f"  {Path(r['image']).name:<28} {'OK' if not bad else ','.join(bad)}")
    return ok
''',
    hints=[
        "The reasoner and the generator both want the whole card. Starting the "
        "NIM inside `animate()` and stopping it before the generation is the "
        "simplest correct answer, and it costs you the NIM's start-up time on "
        "every call — which is exactly the trade Lesson 02 asked you to measure. "
        "Amortise it by captioning all the images first, then generating all the "
        "videos.\n\n"
        "An unparseable caption is the most common failure and the easiest to "
        "recover from: retry once with `temperature=0` and a shorter schema "
        "before giving up.",
    ],
    solution_ref="solutions/07_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "An augmentation set, and an argument for it",
    goal=(
        "Turn one source image into N controlled variations that would be "
        "defensible as training data, and write the argument for why the set is "
        "diverse enough to be worth having."
    ),
    instructions=(
        "1. Choose one conditioning image and a target downstream task — 'a "
        "detector that must work at dusk', 'a policy that must tolerate camera "
        "shake'. The task decides what varying is *for*, and without it "
        "'diverse' means nothing.\n"
        "2. Design an axis set: at least three axes with at least three levels "
        "each, expressed as edits to single prompt fields. Lighting, camera "
        "motion, weather and surface material are natural axes for a driving "
        "scene.\n"
        "3. Generate the set. A full factorial is likely to be unaffordable — "
        "use your Lesson 06 calibration to compute the cost first, then choose a "
        "design (full factorial, one-factor-at-a-time, or a Latin square) and "
        "**justify the choice by its cost and what it can and cannot "
        "identify**.\n"
        "4. Screen every output with `verify_result` and `check_geometry`, and "
        "report the rejection rate.\n"
        "5. Quantify diversity. Pairwise distance between clips under a stated "
        "metric is the obvious approach; compare the within-axis distances "
        "against the between-axis ones. A set where varying the lighting moves "
        "clips less than re-running the same prompt at a new seed is not a "
        "varied set, it is noise.\n"
        "6. Write the argument. Half a page: what the set covers, what it does "
        "not, what you would generate next and why, and one honest sentence "
        "about the ways synthetic data from a single source frame is "
        "correlated in ways real data is not."
    ),
    success=(
        "A generated and screened set with a stated rejection rate, a diversity "
        "measurement that compares against a seed-noise baseline, and a written "
        "argument that includes a limitation you did not have to admit."
    ),
    starter='''
AXES = {
    # "lighting": ["overcast", "harsh midday sun", "dusk, low sun behind"],
    # "camera.motion": ["static", "slow dolly forward", "handheld"],
    # "scene.weather": ["dry", "light rain, wet road", "fog"],
}

def design_cost(axes, design="full_factorial"):
    """How many runs, and how long, from Lesson 06's calibration?"""
    raise NotImplementedError


def seed_noise_baseline(spec, seeds=(0, 1, 2)):
    """Distance between clips that differ ONLY by seed. The floor for diversity."""
    raise NotImplementedError
''',
    hints=[
        "Compute `design_cost` before generating anything. A three-by-three-by-"
        "three factorial is 27 runs, and your calibration will tell you in "
        "minutes what that costs. Discovering it after eleven runs is a worse "
        "lesson than discovering it now.",
        "The seed-noise baseline is what turns this from a demo into a result. "
        "Without it you cannot distinguish 'the lighting axis works' from 'these "
        "are different videos'. Measure it first, with the same metric you will "
        "use on the axes.",
    ],
    solution_ref="solutions/07_solutions.ipynb",
)

# =====================================================================
# Assessment
# =====================================================================
nb.md("""
## Assessment and reflection

### Knowledge check

1. Describe precisely what happens to your conditioning image between the file
   on disk and the first denoising step.
2. Why is `image2video` usually more controllable than `text2video`? Answer in
   terms of what the model still gets to choose.
3. Give a conditioning frame for which `image2video` should be expected to
   perform badly, and say why.
4. Your prompt says "kitchen" and your image shows a road. Which one determines
   frame 0, and why is that not a matter of relative emphasis?
5. `resolution="480"` with `aspect_ratio="1,1"` — what pixel dimensions, and is
   the token count higher or lower than at `"16,9"`?
6. A run exits 0, writes a file, and passes `check_video`, and the output is
   still wrong. Name two ways that happens and one check that catches each.
7. Why does the course derive the aspect ratio from the image rather than
   defaulting to `"16,9"`?
8. `check_video` failed a clip you deliberately asked to be motionless. Is the
   check wrong? What would you do about it in a pipeline?

### Practical completion test

1. Run `image2video` from the cookbook pair and verify it by content.
2. Produce a preservation profile and say what its shape means.
3. Produce, diagnose and repair an aspect mismatch, using geometry as the
   evidence.
4. Animate an image of your own with a derived aspect ratio.
5. Drive one generation from a Lesson 03 scene record, real or canned, and say
   which you used.
""")

nb.code('''
def lesson_07_complete():
    passed, notes = [], []

    verified = [n for n, e in RUNS.items()
                if e["result"] is not None
                and all(c.passed for c in cc.verify_result(e["result"], verbose=False))]
    if verified:
        passed.append(f"{len(verified)}/{len(RUNS)} runs passed every content check")
    else:
        notes.append("no verified runs — generation was disabled")

    if profile:
        first = profile[0]["correlation"]
        last = profile[-1]["correlation"]
        assert first > 0.5, (f"frame 0 correlates only {first:.2f} with the "
                             f"conditioning image; the pinning did not happen")
        passed.append(f"conditioning held: frame 0 correlation {first:.3f}, "
                      f"final frame {last:.3f}")
    else:
        notes.append("no preservation profile — the i2v run did not produce a video")

    mismatch = RUNS.get("i2v_mismatch", {}).get("result")
    if mismatch is not None and mismatch.video_path:
        bad = check_geometry(mismatch.video_path, COND_IMAGE)
        assert bad["ok"] is False, ("the mismatch run did not actually mismatch; "
                                    "the debugging lab has nothing to diagnose")
        passed.append(f"mismatch reproduced and detected by geometry "
                      f"({bad['relative_error']:.0%} off)")
    else:
        notes.append("mismatch run did not execute")

    repaired = RUNS.get("i2v_repaired", {}).get("result")
    if repaired is not None and repaired.video_path:
        good = check_geometry(repaired.video_path, COND_IMAGE)
        assert good["ok"] is not False, "the repair did not fix the geometry"
        passed.append("repair verified by geometry")

    passed.append("scene record source: "
                  + ("Lesson 03 output" if records_path.exists() else "CANNED stand-in"))

    errors = [e["prediction_error_pct"] for e in RUNS.values()
              if e.get("prediction_error_pct") is not None]
    if errors:
        passed.append(f"calibration predicted {len(errors)} run(s), median error "
                      f"{sorted(abs(x) for x in errors)[len(errors) // 2]:.0f}%")
    else:
        notes.append("no predictions — outputs/06/calibration.json is missing")

    for item in passed:
        print(f"  PASS  {item}")
    for item in notes:
        print(f"  ----  {item}")
    return passed, notes


_ = lesson_07_complete()
''')

nb.md("""
### Summary

- The conditioning image is encoded by the **same VAE** and pinned as the first
  temporal slice of the latent, re-imposed after every denoising step. The
  sampler denoises everything else in its presence.
- `image2video` is more controllable than `text2video` because composition,
  palette, lens and object placement are already decided. What remains free is
  the future.
- It fails where the frame does not imply motion, and where the prompt
  contradicts the frame. Neither failure is random: the model commits to an
  interpretation and follows it.
- Measure preservation with a **correlation profile** against the conditioning
  image. Frame 0 near 1.0 means the pinning worked; the rate of decline is the
  model's invention.
- Aspect ratio is `"16,9"` — a comma. The tier is a pixel budget and the aspect
  decides how it is spent, so this changes the latent shape and the cost.
- An aspect mismatch is a **clean-exit failure**: exit 0, a valid file, and
  `check_video` passes. Only geometry catches it. Derive the aspect from the
  image; never type it.
- A caption from Lesson 03 maps onto a generation prompt through five shared
  fields. That is the course's through-line and the capstone runs it at scale.

### Common misconceptions

| Belief | Correction |
|---|---|
| "The model looks at the image and copies its style" | It is given the image as a fixed latent slice and denoises around it. There is no separate style path. |
| "A stronger prompt will override the first frame" | Nothing overrides slice 0. The prompt only affects what comes after it. |
| "Passing `check_video` means the video is right" | It means the video is alive. Geometry, adherence and intent are separate questions. |
| "`16:9` and `16,9` are the same thing" | One is rejected by the validator. Worse, a legal-but-wrong ratio is not rejected at all. |
| "A square output from a 16:9 image just crops it" | You do not know which of crop, letterbox or stretch you got until you measure. Crop deliberately, before the model. |
| "Motion in the output means the model understood the prompt" | Test it: a contradicting prompt also produces motion. |
| "The demo assets prove it works on my data" | The demo assets were chosen. Run your own image before you believe anything. |

### Suggested extensions

- Condition on the **last** frame of a clip you generated and chain two clips
  together. Then measure whether the seam is visible under your correlation
  metric.
- Take one image, crop it three ways to three different aspect ratios, and
  compare the outputs. This separates "the model prefers 16:9" from "the crop
  removed the interesting part".
- Feed a generated video back to the reasoner for captioning and compare the
  caption against the prompt you used. Disagreement is a cheap adherence metric,
  and Lesson 18 discusses why it is also circular.

### Mastery checklist

- [ ] I can explain first-frame conditioning as a pinned latent slice.
- [ ] I measured what was preserved instead of asserting it.
- [ ] I produced and diagnosed an aspect mismatch using geometry.
- [ ] I derived an aspect ratio from an image rather than typing one.
- [ ] I animated an image of my own.
- [ ] I drove a generation from a reasoner-written scene record.
- [ ] I reported how far my Lesson 06 calibration was off, without adjusting it
      afterwards to look better.

### Next

Lesson 08 stops conditioning on one frame and starts conditioning on a whole
video, through a control hint. That is the mechanism behind synthetic data
augmentation, and it is also the part of the source material that is taught
wrongly — transfer is not a model mode. Read the warning at the top of Lesson 08
before you start it: it needs Cosmos3-Nano, which is a 34.9 GB download.

## Free the card, and say why

Lesson 08 loads a 16B checkpoint. This kernel holds almost nothing on the GPU —
the generator ran as a subprocess and the operating system reclaimed every byte
when it exited — but "almost nothing" is worth verifying rather than assuming,
because an orphaned worker from a timed-out run looks exactly like a clean
machine until the next launch fails.
""")

nb.code('''
import gc

for name in ("profile", "honest", "other"):
    globals().pop(name, None)
gc.collect()

try:
    import torch as _torch
    if _torch.cuda.is_available():
        _torch.cuda.empty_cache()
        free_b, total_b = _torch.cuda.mem_get_info()
        print(f"device: {free_b / 1e9:.1f} GB free of {total_b / 1e9:.1f} GB")
        nano = cc.MODEL_TIERS["Cosmos3-Nano"]["inference_vram_gb"]
        print(f"Cosmos3-Nano inference needs ~{nano} GB -> "
              f"{'fits' if free_b / 1e9 >= nano else 'DOES NOT FIT — find what is holding the card'}")
except Exception as exc:
    print(f"could not read device memory: {type(exc).__name__}: {exc}")


def dir_size_gb(path):
    path = Path(path)
    if not path.exists():
        return 0.0
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file()) / 1e9


print(f"\\noutputs/07 on disk: {dir_size_gb(OUTPUT_DIR):.2f} GB")
print("Videos dominate. scripts/cleanup.sh removes generated media and leaves the")
print("Hugging Face cache alone, which is the part you do not want to re-download.")
''')

nb.md(FOOTER_MD)

nb.write(ROOT / "07_generation_conditioned.ipynb")
