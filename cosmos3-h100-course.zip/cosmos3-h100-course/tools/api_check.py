#!/usr/bin/env python3
"""Check every notebook against the `cosmos_course` package as it actually is.

The other validators read the notebooks in isolation: `syntax_check.py` proves a
cell parses, `nameflow_check.py` proves a name is bound before it is read.
Neither one knows what `cosmos_course` contains, so neither can see the class of
bug this script exists for — code that is syntactically perfect, uses only names
that exist, and raises the moment it runs.

Three checks, all of them derived from the imported package rather than from a
list maintained here by hand:

1. **Properties called as methods.** `RunResult.video_path` is a `@property`.
   `result.video_path()` therefore evaluates to a `Path` and *then* calls it:
   `TypeError: 'PosixPath' object is not callable`. This is invisible in a
   course where generation is opt-in, because `res is None` short-circuits the
   expression on every machine that has not turned generation on. It surfaces
   for the one reader who does. The property list comes from walking the
   package's classes with `inspect`, so adding or removing a `@property` in
   `cosmos_course/` changes what this script enforces with no edit here.

2. **`cc.<name>` that does not exist.** Notebooks do `import cosmos_course as
   cc` and then reach for `cc.verify_result`, `cc.InferenceSpec` and so on. A
   rename in the package leaves an `AttributeError` sitting in a notebook that
   still parses. The alias is read from each notebook's own `import` statement,
   so `import cosmos_course as cc0` is checked too.

3. **Lesson structure.** Every lesson gets a `## Exercises` section, a
   `## Debugging lab` section and an assessment section, each as a heading that
   *starts* its own markdown cell. "Starts its own cell" is the point: Lesson 14
   once carried its `## Exercises` heading appended to the tail of the debugging
   lab's verification cell, which reads, in a rendered notebook, as three
   exercises appearing out of nowhere.

Checks 1 and 2 work on the parsed AST, never on the raw text. That matters: a
regex for `\\.ok\\s*\\(` flags the prose in Lesson 09's
`print(f"RunResult.ok (exit code + a file): {blocked_result.ok}")`, where the
parenthesis belongs to an English sentence inside a string literal. The AST sees
an `Attribute` inside a `FormattedValue` and correctly says nothing.

Usage:

    python3 tools/api_check.py             # every notebook
    python3 tools/api_check.py 14_performance_and_memory.ipynb

Exit code 0 when clean, 1 when anything is reported, 2 when the package will not
import (which is itself the finding).
"""
from __future__ import annotations

import ast
import importlib
import inspect
import json
import pkgutil
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Lesson sections. Each entry is (human name, regex the heading must match).
# The heading has to be the first non-empty line of a markdown cell — a section
# that begins halfway down someone else's cell is not a section.
REQUIRED_SECTIONS = [
    ("exercises", re.compile(r"^##\s+Exercises\b")),
    ("debugging lab", re.compile(r"^##\s+Debugging lab\b")),
    ("assessment", re.compile(r"^##\s+Assessment\b")),
]


# --------------------------------------------------------------------------
# Introspection — the source of truth for checks 1 and 2
# --------------------------------------------------------------------------
def package_properties(pkg) -> dict[str, list[str]]:
    """Every `@property` name defined on a class that belongs to `pkg`.

    Returns ``{property_name: [owning class names]}``. Submodules are imported
    explicitly because a class can live in one that ``__init__`` does not
    re-export, and a property there is just as uncallable.
    """
    found: dict[str, set[str]] = {}
    seen: set[int] = set()

    def walk(mod) -> None:
        if id(mod) in seen:
            return
        seen.add(id(mod))
        for obj in vars(mod).values():
            if not inspect.isclass(obj):
                continue
            if not getattr(obj, "__module__", "").startswith(pkg.__name__):
                continue
            for attr, value in vars(obj).items():
                if isinstance(value, property):
                    found.setdefault(attr, set()).add(obj.__name__)

    walk(pkg)
    for info in pkgutil.iter_modules(pkg.__path__):
        try:
            walk(importlib.import_module(f"{pkg.__name__}.{info.name}"))
        except Exception as exc:                      # noqa: BLE001 — reported
            print(f"  note  could not import {pkg.__name__}.{info.name}: {exc}")
    return {k: sorted(v) for k, v in sorted(found.items())}


# --------------------------------------------------------------------------
# Notebook plumbing
# --------------------------------------------------------------------------
def source(cell: dict) -> str:
    src = cell.get("source", "")
    return "".join(src) if isinstance(src, list) else str(src)


def parseable(src: str) -> tuple[ast.Module | None, list[str]]:
    """Parse a code cell, neutralising IPython magics first.

    Magic and shell lines are replaced by `pass` at the same indentation rather
    than dropped, so every `node.lineno` still indexes the original text.
    """
    lines = src.splitlines()
    cleaned = []
    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith(("%", "!")):
            cleaned.append(" " * (len(line) - len(stripped)) + "pass")
        else:
            cleaned.append(line)
    try:
        return ast.parse("\n".join(cleaned)), lines
    except SyntaxError:
        return None, lines


def line_at(lines: list[str], lineno: int) -> str:
    return lines[lineno - 1].strip() if 0 < lineno <= len(lines) else "?"


def package_aliases(nb: dict, pkg_name: str) -> set[str]:
    """Names this notebook binds to the package via `import <pkg> as <alias>`."""
    aliases: set[str] = set()
    for cell in nb["cells"]:
        if cell["cell_type"] != "code":
            continue
        tree, _ = parseable(source(cell))
        if tree is None:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    if a.name == pkg_name and a.asname:
                        aliases.add(a.asname)
    return aliases


# --------------------------------------------------------------------------
# The checks
# --------------------------------------------------------------------------
def check_notebook(path: Path, nb: dict, pkg, props: dict[str, list[str]],
                   problems: list[str]) -> None:
    rel = path.relative_to(ROOT)
    aliases = package_aliases(nb, pkg.__name__)

    for i, cell in enumerate(nb["cells"]):
        if cell["cell_type"] != "code":
            continue
        src = source(cell)
        tree, lines = parseable(src)
        if tree is None:
            problems.append(f"{rel}: cell {i} does not parse — run "
                            f"tools/syntax_check.py; API checks skipped for it")
            continue

        for node in ast.walk(tree):
            # 1. property called as a method
            if (isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute)
                    and node.func.attr in props):
                owners = ", ".join(props[node.func.attr])
                problems.append(
                    f"{rel}: cell {i} line {node.func.lineno}: "
                    f".{node.func.attr}() calls a @property of {owners} — "
                    f"drop the parentheses\n"
                    f"        {line_at(lines, node.func.lineno)}")

            # 2. cc.<name> that the package does not have
            if (isinstance(node, ast.Attribute)
                    and isinstance(node.value, ast.Name)
                    and node.value.id in aliases
                    and not hasattr(pkg, node.attr)):
                problems.append(
                    f"{rel}: cell {i} line {node.lineno}: "
                    f"{node.value.id}.{node.attr} does not exist on "
                    f"{pkg.__name__}\n"
                    f"        {line_at(lines, node.lineno)}")


def check_lesson_structure(path: Path, nb: dict, problems: list[str]) -> None:
    rel = path.relative_to(ROOT)
    openers = []
    for i, cell in enumerate(nb["cells"]):
        if cell["cell_type"] != "markdown":
            continue
        text = source(cell).lstrip()
        first = next((ln for ln in text.splitlines() if ln.strip()), "")
        openers.append((i, first))

    for name, pattern in REQUIRED_SECTIONS:
        if any(pattern.match(first) for _, first in openers):
            continue
        # Distinguish "absent" from "present but buried", because the fix differs.
        buried = [i for i, cell in enumerate(nb["cells"])
                  if cell["cell_type"] == "markdown"
                  for ln in source(cell).splitlines() if pattern.match(ln)]
        if buried:
            problems.append(
                f"{rel}: cell {buried[0]}: the {name} heading is inside another "
                f"cell instead of opening its own — the reader sees the section "
                f"start with no heading\n"
                f"        {next(ln for ln in source(nb['cells'][buried[0]]).splitlines() if pattern.match(ln)).strip()}")
        else:
            problems.append(f"{rel}: no {name} section "
                            f"(no markdown cell opening with {pattern.pattern!r})")


# --------------------------------------------------------------------------
def main() -> int:
    try:
        pkg = importlib.import_module("cosmos_course")
    except Exception as exc:                          # noqa: BLE001 — the finding
        print(f"FAIL  cannot import cosmos_course: {exc!r}")
        return 2

    props = package_properties(pkg)
    print(f"cosmos_course imported from {Path(pkg.__file__).parent}")
    print(f"{len(props)} @property name(s) introspected: {', '.join(props)}")
    print()

    if len(sys.argv) > 1:
        lessons = [ROOT / a for a in sys.argv[1:] if re.match(r"\d\d_", Path(a).name)]
        paths = [ROOT / a for a in sys.argv[1:]]
    else:
        lessons = sorted(ROOT.glob("[0-9][0-9]_*.ipynb"))
        paths = (lessons + sorted(ROOT.glob("solutions/*.ipynb"))
                 + sorted(ROOT.glob("exercises/*.ipynb")))

    if not paths:
        print("no notebooks found", file=sys.stderr)
        return 2

    problems: list[str] = []
    for path in paths:
        nb = json.loads(path.read_text(encoding="utf-8"))
        before = len(problems)
        check_notebook(path, nb, pkg, props, problems)
        if path in lessons:
            check_lesson_structure(path, nb, problems)
        status = "ok  " if len(problems) == before else "FAIL"
        n_code = sum(1 for c in nb["cells"] if c["cell_type"] == "code")
        print(f"[{status}] {str(path.relative_to(ROOT)):<42} "
              f"{len(nb['cells']):>3} cells ({n_code} code)")

    print()
    for item in problems:
        print(f"  PROBLEM  {item}")
    print(f"\n{len(paths)} notebook(s), {len(problems)} problem(s)")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
