"""Build 10_action_forward_dynamics.ipynb.

Derived from the source DLI course `S-OV-57-V1`, notebook 04, cells 1-10:
action as a modality, and forward dynamics on the cookbook's AV example.

What the source did and this lesson keeps: the AV forward-dynamics record, its
field values, and the `av_0.jpg` + `av_traj_forward.json` pairing.

What the source did not do and this lesson adds:
  * an explanation of what a 9-D action actually contains, including why the
    rotation block is 6-D rather than 3-D or 4-D;
  * the left/right steering comparison the source only mentions in prose;
  * the launch-shape difference (single process + latency preset) with the
    dispatch shown rather than asserted;
  * a wrong-`domain_name` debugging lab, verified against the framework's own
    EMBODIMENT_TO_RAW_ACTION_DIM table rather than against documentation.

Facts used here that were checked against upstream `main` (August 2026):
  * `docs/inference.md` "Action" section: action_chunk_size, domain_name,
    view_point, action_path, image_size, and "The action output is written to
    sample_outputs.json".
  * `cosmos_framework/data/generator/action/utils/domain_utils.py`:
    EMBODIMENT_TO_RAW_ACTION_DIM has av=9, camera_pose=9,
    bridge_orig_lerobot=10, droid_lerobot=10.
  * `cosmos_framework/data/generator/action/utils/pose_utils.py`: rot6d is the
    first two COLUMNS of the rotation matrix, flattened column-by-column.
  * The cookbook's `av_traj_forward.json` is a bare JSON list, 60 rows x 9 cols.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 10 — Action as a modality, and forward dynamics")

# --------------------------------------------------------------- title block
nb.md("""
# Lesson 10 — Action as a modality, and forward dynamics

**What you will build.** `outputs/10/` containing videos generated from three
different commanded trajectories on the same start frame, a measured
`action_chunk_size` sweep, a trajectory you wrote yourself, and a written
prediction-versus-outcome note.

| | |
|---|---|
| **Time** | ~105 minutes, of which 30–60 is the Nano download on a first run |
| **GPU** | 1 × H100 80 GB, nothing else resident. Stop the Reasoner NIM if it is up. |
| **Downloads** | `Cosmos3-Nano`, ~34.9 GB. Opt-in, and warned about before it starts. |
| **Prerequisites** | Lesson 07 (you can write and run an `InferenceSpec`). Module 1 is not required. |
""")

# ---------------------------------------------------------------- objectives
nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Explain** what an action token represents in Cosmos 3, and derive from that
   claim why the same model can answer three different questions.
2. **Decompose** a 9-D autonomous-vehicle action into its translation and
   rotation parts, and **explain** why the rotation part is 6-D rather than 3-D
   or 4-D.
3. **Write** a valid `forward_dynamics` spec from scratch and state what each of
   `domain_name`, `view_point`, `action_chunk_size`, `fps` and `image_size`
   controls.
4. **Compare** videos generated from three different commanded trajectories on
   one start frame, and say whether the model followed the command.
5. **Measure** what doubling `action_chunk_size` costs in output length and in
   wall-clock time on your own machine.
6. **Diagnose** a wrong `domain_name` by checking action dimensionality against
   the framework's embodiment table, and explain why the output still looked
   fine.
7. **Predict** the launch shape a mode will take, and explain why action modes
   do not go through `torchrun`.
""")

# -------------------------------------------------------------- environment
# The configuration cell comes before the theory on purpose. Everything in this
# lesson reads MODEL, MODE, DEVICE and OUTPUT_DIR from it, and a learner who has
# run one cell is in a different frame of mind from one who has read for ten
# minutes. The conceptual material follows, in short sections with something to
# run after each.
nb.md("""
## Environment

Configuration first, before the theory, because everything below reads from it.
The next cell finds the course root from wherever your kernel started, imports
the `cosmos_course` package, detects your GPU and creates `outputs/10/`. It
downloads nothing and loads no model — the 35 GB checkpoint decision comes later
in this lesson, once you know what an action is.

Run it, then read on. Each section after this one ends in something you run.
""")

nb.code('__lesson__ = "10"   # OUTPUT_DIR resolves to outputs/10\n\n' + SETUP_CELL)

# ------------------------------------------------- conceptual foundation (1)
nb.md("""
## Action as a modality

Modules 1 and 2 taught Cosmos 3 to *describe* a scene and to *imagine* one.
This module teaches it to **act** in one. The mechanism is a single idea that
takes about ninety seconds to state and the rest of the module to use properly:
Cosmos 3 treats **action** as a modality, in the same sense that text, image and
video are modalities.

Start from what a video model already does. A video model is trained on
sequences of frames and learns the distribution of "what frame comes next".
Nothing in that setup knows *why* the next frame differs from this one. A car
turns left in the video; the model learned that turning-left-shaped pixel
sequences happen; it has no handle you can pull to make it turn left.

Cosmos 3 adds that handle. Alongside the token streams for text, image and video
there is a token stream for **action**, and one action token stands for the
**transition between two consecutive visual states**. Not "the car's steering
angle" and not "the robot's joint torques" — the *change* from frame `i` to
frame `i+1`, expressed in whatever units that embodiment uses.

That framing is worth pausing on, because it is what makes one model able to
answer three separate questions. If actions and frames live in the same
sequence, then predicting some of the sequence given the rest is one operation
with three useful special cases:

| Mode | You give it | It predicts | The question |
|---|---|---|---|
| `forward_dynamics` | a start frame **and** actions | future video | *If I do this, what will I see?* |
| `inverse_dynamics` | a video | the actions | *What did I do to produce this?* |
| `wam` | a start observation **and** an instruction | video **and** actions | *What should I do to achieve this?* |

Three different questions. One checkpoint, one entry point, three values of
`model_mode`. That economy is the whole argument for treating action as a
modality rather than bolting a separate policy network onto a video model.

This lesson does the first row. Lesson 11 does the second, Lesson 12 the third.

The table above is a claim. Check it against the package before you rely on it.
""")

nb.code('''
# The three modes this module uses, read out of the course package's own table
# rather than retyped from the markdown above. cc.MODEL_MODES carries one line
# of explanation per mode.
ACTION_MODES = ("forward_dynamics", "inverse_dynamics", "wam")

for mode_name in ACTION_MODES:
    print(f"{mode_name:<18s} {cc.MODEL_MODES[mode_name]}")
print()

# The rename, checked rather than asserted. The old name is not a key in the
# table, and the course package carries a function whose whole job is to map it
# onto the live one.
print(f"'policy' is a mode name        : {'policy' in cc.MODEL_MODES}")
print(f"normalize_policy_mode('policy'): {cc.normalize_policy_mode('policy')!r}")

assert "policy" not in cc.MODEL_MODES
assert cc.normalize_policy_mode("policy") == "wam"
print()
print("Three questions, one checkpoint, three values of model_mode. The rest of")
print("this lesson is the first of them.")
''')

nb.callout("upstream", """
The third mode used to be called `policy`. It is **`wam`** — World Action Model
— and the old name is gone, which is what the cell above shows: `policy` is not
a key in the mode table, and the course package ships a function whose only job
is to map the dead name onto the live one. Several upstream documents, and the
DLI course this lesson is derived from, still say `policy`. Lesson 12 makes you
prove which one is live by reading the enum in your own checkout, rather than
taking this paragraph's word for it.
""")

# ------------------------------------------------- conceptual foundation (2)
nb.md("""
## What an action actually *is*

"Action" is abstract until you look at the numbers. For the autonomous-vehicle
domain, one action step is **nine floating-point numbers**:

```
   index:   0    1    2      3    4    5    6    7    8
          [ tx   ty   tz  | r0   r1   r2   r3   r4   r5 ]
           \___________/    \_________________________/
            translation            rotation (6-D)
             3 numbers               6 numbers
```

The first three are a **translation delta**: how far the camera moved between
this frame and the next, along each axis, in that camera's own coordinate frame.
The remaining six are a **rotation delta**: how the camera turned.

There is no absolute position anywhere in that vector. Every step is expressed
relative to the previous one. A trajectory is therefore a chain of small
relative moves, and you get an absolute path by composing them — which is
Lesson 11's job.
""")

nb.code('''
# The layout above, written down once so that later cells can assert against it
# instead of against a comment. Nothing is read from disk yet.
AV_ACTION_FIELDS = ["tx", "ty", "tz", "r0", "r1", "r2", "r3", "r4", "r5"]
AV_TRANSLATION_IDX = [0, 1, 2]
AV_ROTATION_IDX = [3, 4, 5, 6, 7, 8]

print(f"{'index':>5s}  {'name':<4s}  meaning")
for idx, field_name in enumerate(AV_ACTION_FIELDS):
    part = ("translation delta" if idx in AV_TRANSLATION_IDX
            else "rotation delta, 6-D")
    print(f"{idx:>5d}  {field_name:<4s}  {part}")

print()
print(f"translation numbers : {len(AV_TRANSLATION_IDX)}")
print(f"rotation numbers    : {len(AV_ROTATION_IDX)}")
print(f"total per step      : {len(AV_ACTION_FIELDS)}")

assert len(AV_TRANSLATION_IDX) + len(AV_ROTATION_IDX) == len(AV_ACTION_FIELDS)
assert len(AV_ACTION_FIELDS) == 9
print()
print("Nine numbers per step, and not one of them is an absolute position.")
''')

nb.md("""
### Why the rotation part is six numbers

This is the part almost nobody has met before, and it is a genuinely good idea,
so it is worth the paragraphs.

A 3-D rotation has three degrees of freedom. So the obvious encodings are:

- **Euler angles** — three numbers (roll, pitch, yaw). Three degrees of freedom,
  three numbers, no waste.
- **Quaternions** — four numbers with one constraint (unit length).
- **A rotation matrix** — nine numbers with six constraints (orthonormal
  columns, determinant +1).

Euler angles are the obvious choice and they are a trap. They have **gimbal
lock**: at certain orientations two of the three axes line up and a degree of
freedom disappears. They are also discontinuous — yaw wraps from 359° to 0°,
so two nearly-identical rotations can be numerically far apart.

Quaternions fix gimbal lock but keep a discontinuity: `q` and `−q` represent the
*same* rotation. A network asked to regress a quaternion has to pick one of two
equally correct answers, and near the boundary between them its output has to
jump.

Why does that matter? Because a neural network is a continuous function. If you
ask it to output a representation in which nearby rotations are sometimes
numerically far apart, you are asking it to approximate a discontinuous map with
a continuous one. It cannot, so it does the next best thing: it produces
garbage near the discontinuity. This is not a training-hyperparameter problem;
it is a topological one.

The result that settles it (Zhou et al., 2019, *On the Continuity of Rotation
Representations in Neural Networks*): **for the space of 3-D rotations there is
no continuous, singularity-free representation in three or four dimensions.**
Five is also impossible. Six is the smallest that works.
""")

nb.code('''
# The discontinuity, in two lines of arithmetic. Take two headings one degree
# apart that straddle the wrap point, and measure how far apart each encoding
# says they are. This is the 2-D version of the argument above, which is the
# version you can check by hand.
import math

a_deg, b_deg = 359.5, 0.5                       # one degree apart, really

raw_gap = abs(a_deg - b_deg)
a_vec = (math.cos(math.radians(a_deg)), math.sin(math.radians(a_deg)))
b_vec = (math.cos(math.radians(b_deg)), math.sin(math.radians(b_deg)))
vec_gap = math.dist(a_vec, b_vec)

print(f"two headings          : {a_deg} deg and {b_deg} deg")
print(f"truly apart by        : 1.0 deg")
print()
print(f"as raw angles         : {raw_gap:.3f}   <- the wrap-around")
print(f"as (cos, sin)         : {vec_gap:.5f}")

assert raw_gap > 100.0, "the angle encoding should look absurdly far apart"
assert vec_gap < 0.05, "the two-number encoding should look as close as it is"
print()
print("Same two rotations both times. A network asked to regress the first")
print("number has to jump 359 units across that boundary; asked to regress the")
print("pair, it does not. Six numbers buy the same property in 3-D.")
''')

nb.md("""
### What the six numbers are

Take the 3×3 rotation matrix and keep its **first two columns**. That is six
numbers. Throw the third column away.

You lose nothing, because the third column is recoverable: the columns of a
rotation matrix are mutually perpendicular unit vectors, so the third is the
cross product of the first two. Recovery looks like this:

```
   given  a = [r0 r1 r2]   (column 0, roughly)
          b = [r3 r4 r5]   (column 1, roughly)

   c = a x b                     third column, perpendicular to both
   R = [ a | b | c ]             assemble
   R = project_to_SO3(R)         snap to a real rotation
```

The network's raw output will not be exactly orthonormal — nothing constrains it
to be. The last step fixes that by finding the nearest true rotation matrix. The
classic recipe is Gram–Schmidt: normalise `a`, subtract from `b` its component
along `a`, normalise, cross for `c`. Cosmos 3's implementation does something
equivalent and slightly different, and Lesson 11 has you look at which.

The important property is **continuity**: two rotations that are close in space
have first-two-columns that are close in numbers, everywhere, with no wrap-around
and no lock. That is the whole point.
""")

nb.callout("deeper", """
The 6-D representation is over-parameterised — six numbers for three degrees of
freedom — and that is deliberate. Over-parameterisation is the price of
continuity. The same trade appears in 2-D: an angle is one number and wraps at
2π, so a network that must output a heading is usually asked for
`(cos θ, sin θ)` instead. Two numbers, one degree of freedom, no wrap. The 6-D
rotation is that same trick in 3-D.

**And the trap that follows from it.** `domain_name` selects an embodiment, and
each embodiment has a fixed raw action width — 9 for `av` and `camera_pose`, 10
for `bridge_orig_lerobot`, `droid_lerobot` and `umi`, 29 for `agibotworld`.
Passing a robot domain with AV data does not necessarily fail. When it does not,
you get a clean exit, a video that looks like driving, and an action
interpretation that is wrong in a way no statistical check can see. The
debugging lab at the end of this lesson produces exactly that and then diagnoses
it.
""")

nb.code('''
# The recovery, on a rotation simple enough to check on paper: a 90-degree turn
# about the camera's own Y axis. Its first two columns are the six numbers that
# would be transmitted; the third is rebuilt here and was never sent.
def cross3(a, b):
    """Cross product of two 3-vectors, written out rather than imported."""
    return [a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0]]


yaw90_6d = [0.0, 0.0, -1.0,   0.0, 1.0, 0.0]     # columns 0 and 1 of that turn
col_a, col_b = yaw90_6d[:3], yaw90_6d[3:]

# -0.0 is a legal float and a distraction in printed output, so fold it to 0.0.
col_c = [value if value else 0.0 for value in cross3(col_a, col_b)]

print(f"column 0, from the first three numbers  : {col_a}")
print(f"column 1, from the last three           : {col_b}")
print(f"column 2, recovered by cross product    : {col_c}")
print()
print("The two properties that make it a rotation matrix:")
print(f"  |column 0|          {math.dist(col_a, [0, 0, 0]):.4f}   (want 1)")
print(f"  |column 1|          {math.dist(col_b, [0, 0, 0]):.4f}   (want 1)")
print(f"  column 0 . column 1 {sum(x * y for x, y in zip(col_a, col_b)):+.4f}   (want 0)")

assert abs(math.dist(col_c, [0, 0, 0]) - 1.0) < 1e-9
print()
print("Six numbers in, nine out, nothing lost. You will do this on real data")
print("further down, where the numbers are not this tidy.")
''')

# ------------------------------------------------- conceptual foundation (3)
nb.md("""
## The five fields that describe an action job

A `forward_dynamics` spec needs `domain_name`, `vision_path` and `action_path`.
Four other fields are not formally required and get you nowhere if they are
wrong. Here is what each one does.

| Field | What it controls | Getting it wrong looks like |
|---|---|---|
| `domain_name` | Which **embodiment** the action vector belongs to. It selects the domain id and the action encoder/decoder weights trained for that robot or vehicle. | Well-formed numbers that mean something else. See the debugging lab. |
| `view_point` | A short viewpoint description injected into the action prompt, e.g. `ego_view`. | Degraded output; no error. |
| `action_chunk_size` | How many action steps are in the chunk. The action media loader reads at most `action_chunk_size + 1` observation frames. | Output shorter or longer than you expected. |
| `fps` | The frame rate the actions are assumed to be sampled at, and the rate the rollout is written at. 10 for AV, 5 for the Bridge robot, 30 for camera moves. | Motion at the wrong speed. |
| `image_size` | The resize bucket for the action *media*. The cookbook uses 480 for AV and 256 for LIBERO. | Wrong scale going in. |

`domain_name` is the one that deserves suspicion. It is a string, it is looked
up in a registry, and a valid-but-wrong value is accepted without complaint.
""")

nb.md("""
### The model tier, and the download you are about to start

Action modes need **Cosmos3-Nano**. Edge does not do action work well: it is a
4B dense model capped at 480p with no audio and no transfer, and the action
pathway is not where its capacity went. Super does not fit this machine for
generation at all.

The next cell prints the download size and the VRAM cost **before** anything
starts, and then stops unless you have opted in. Read the numbers, then either
set `ALLOW_NANO_DOWNLOAD = True` in the cell or export
`COSMOS_COURSE_ALLOW_NANO=1` in your shell and restart the kernel.
""")

nb.code('''
import json
import subprocess
import time

import numpy as np

ACTION_MODEL = "Cosmos3-Nano"
tier = cc.MODEL_TIERS[ACTION_MODEL]

# Opt-in. Flip this to True, or export COSMOS_COURSE_ALLOW_NANO=1.
ALLOW_NANO_DOWNLOAD = os.environ.get("COSMOS_COURSE_ALLOW_NANO", "0") == "1"

print(f"checkpoint      : {tier['hf_repo']}")
print(f"download        : {tier['download_gb']} GB  (once; cached in ~/.cache/huggingface)")
print(f"inference VRAM  : {tier['inference_vram_gb']} GB  (NVIDIA figure, docs/faq.md)")
print(f"gated           : {tier['gated']}")
print()
print("On a 500 Mbit link that download is roughly 10 minutes. On a slow or")
print("shared link it can be an hour. Nothing else in this lesson can start")
print("until it finishes.")
print()
print(f"ALLOW_NANO_DOWNLOAD = {ALLOW_NANO_DOWNLOAD}")

cc.require(
    ALLOW_NANO_DOWNLOAD,
    "Cosmos3-Nano has not been opted into, so this lesson stops here rather "
    "than starting a 35 GB download you did not ask for.",
    fix=(
        "Set ALLOW_NANO_DOWNLOAD = True in the cell above and re-run it, or\\n"
        "        export COSMOS_COURSE_ALLOW_NANO=1\\n"
        "      and restart the kernel. If disk is tight, check first:\\n"
        "        df -h ~ ; du -sh ~/.cache/huggingface"
    ),
)
''')

nb.md("""
### Preflight

Three things must be true before a run is worth starting: the framework
checkout exists with its own virtualenv, the cookbook assets are on disk, and
nothing else owns the GPU. Checking them takes two seconds and saves a model
load.
""")

nb.code('''
from cosmos_course.models import Generator

gen = Generator(checkpoint=ACTION_MODEL)
problems = gen.check(verbose=True)
cc.require(
    not problems,
    "The Cosmos Framework is not usable from this kernel.",
    fix=(
        "Follow scripts/setup.sh, or set COSMOS3_REPO to an existing checkout.\\n"
        "      The framework runs in ITS OWN venv as a subprocess; this notebook's\\n"
        "      kernel deliberately does not import it."
    ),
)

report = cc.check_assets(
    ["av_start_frame", "av_video", "av_traj_forward", "av_traj_left",
     "av_traj_right", "camera_action"],
    verbose=True,
)
cc.require(
    not report["missing"],
    f"Missing cookbook action assets: {report['missing']}",
    fix="python3 scripts/fetch_assets.py    (the media are git-LFS objects)",
)

# Whatever else is resident will be competing with a 32 GB model.
print()
mem = cc.describe_memory("before anything is loaded", include_smi=True)
free_gb = None
if mem.smi_used_gb is not None and mem.torch_total_gb:
    free_gb = mem.torch_total_gb - mem.smi_used_gb
    print()
    print(f"free VRAM       : {free_gb:.1f} GB")
    print(f"Nano needs      : {tier['inference_vram_gb']} GB")
    if free_gb < tier["inference_vram_gb"]:
        print()
        print("NOT ENOUGH. Something else is holding the card. The usual suspect is")
        print("the Reasoner NIM from Module 1:")
        print("    from cosmos_course.nim import stop_nim, NimConfig; stop_nim(NimConfig())")
''')

# ------------------------------------------------------------- launch shape
nb.md("""
## The launch shape, and why action modes differ

Generation modes in Modules 1 and 2 launched through `torchrun`. Action modes do
not. They run as a plain single process with `--parallelism-preset=latency`, and
with `RANK`, `WORLD_SIZE` and `LOCAL_RANK` set by hand.

Two separate reasons, and it is worth keeping them apart.

**Why single-process rather than `torchrun`.** `torchrun` exists to start N
worker processes and introduce them to each other. At N=1 it is pure overhead:
a rendezvous, a process-group init, and a second process to supervise. Worse, it
*insists* on setting the distributed environment variables itself, so a stale
`WORLD_SIZE` left in your environment by an earlier cell makes the launcher and
its worker disagree about the topology, and the run hangs at the rendezvous
rather than failing. Running the module directly avoids all of it — but then
nothing sets those variables, and the framework still expects them, so this
course sets them explicitly.

**Why `latency` rather than `throughput`.** The presets describe what to
optimise when there is a choice. `throughput` batches work to keep every device
busy and is the right answer when you have a queue of jobs and many GPUs.
`latency` minimises the time to *this* answer. Action inference is a single
short job on one GPU, so there is no queue to amortise across and nothing to
overlap. At world size 1 the two presets have little to distinguish them —
Lesson 15 measures whether "little" is "none" — but `latency` is the honest
description of the intent.

The dispatch lives in one line of `cosmos_course/models.py`. Read it rather than
trusting this paragraph.

One detail in the environment below is worth its own sentence.
`LD_LIBRARY_PATH` is deliberately set to the empty string. Inside the NGC
PyTorch container the image's bundled libtorch sits on that path and shadows the
framework venv's own copy; the import then fails with an undefined-symbol error
that reads like a corrupt installation. Clearing it costs nothing outside a
container, so this course does it unconditionally.
""")

nb.code('''
from cosmos_course.models import ACTION_MODEL_MODES
from cosmos_course.specs import build_inference_command

print("modes that take the single-process launch path:")
for mode in sorted(ACTION_MODEL_MODES):
    print(f"    {mode}")
print()
print("everything else goes through torchrun with the throughput preset.")
print()

# Build the command without running it, so the shape is visible.
#
# parallelism_preset picks what the framework optimises for when it has a
# choice: "latency" = finish this one answer as soon as possible; "throughput" =
# maximum samples per unit time across a queue. Action inference is one short
# job on one GPU, so "latency" is the honest description of the intent. See the
# paragraph above, and Lesson 15 measures whether the two differ at all at world
# size 1.
demo_argv, demo_env = build_inference_command(
    "sample.json",
    OUTPUT_DIR / "_dry_run",
    checkpoint=ACTION_MODEL,
    framework_repo=cc.COSMOS3_REPO,
    parallelism_preset="latency",
)
print("argv:")
for arg in demo_argv:
    print(f"    {arg}")
print()
print("environment the framework needs even at world size 1:")
for key in ("RANK", "WORLD_SIZE", "LOCAL_RANK", "MASTER_ADDR", "MASTER_PORT",
            "LD_LIBRARY_PATH", "PYTHONNOUSERSITE"):
    print(f"    {key}={demo_env.get(key)!r}")
''')

# --------------------------------------------------------- the trajectory
nb.md("""
## Reading a trajectory file

Before generating anything, look at the input. `av_traj_forward.json` is a bare
JSON list of lists — no header, no metadata, no units. Each row is one action
step; each column is one raw action dimension. That is the entire format, and
the fact that it carries no schema is exactly why `domain_name` has to be right.
""")

nb.code('''
FORWARD_TRAJ = cc.asset("av_traj_forward")
LEFT_TRAJ = cc.asset("av_traj_left")
RIGHT_TRAJ = cc.asset("av_traj_right")
START_FRAME = cc.asset("av_start_frame")

def load_trajectory(path):
    """Read an action JSON into a [steps, dims] float array."""
    rows = json.loads(Path(path).read_text())
    arr = np.asarray(rows, dtype=np.float64)
    if arr.ndim != 2:
        raise ValueError(
            f"{Path(path).name}: expected a list of equal-length rows, got shape {arr.shape}"
        )
    return arr

forward = load_trajectory(FORWARD_TRAJ)
print(f"{FORWARD_TRAJ.name}: {forward.shape[0]} steps x {forward.shape[1]} dimensions")
print()
print("first three steps, rounded:")
print(np.round(forward[:3], 5))
print()

# Split the columns the way the layout says, and look at each part separately.
translation = forward[:, :3]
rotation6d = forward[:, 3:9]

print("translation deltas (tx, ty, tz) per step")
print(f"    mean : {np.round(translation.mean(axis=0), 5)}")
print(f"    max  : {np.round(translation.max(axis=0), 5)}")
print(f"    total (naive sum): {np.round(translation.sum(axis=0), 4)}")
print()
print("rotation block, first row:", np.round(rotation6d[0], 5))
print()
print("Which translation axis carries the motion? The one with the largest")
print("total. Cosmos 3's camera convention is +Z forward, so a car driving")
print("straight should accumulate almost all of its movement in column 2.")
axis = int(np.argmax(np.abs(translation.sum(axis=0))))
print(f"    largest accumulated axis: column {axis}  "
      f"({'X' if axis == 0 else 'Y' if axis == 1 else 'Z'})")
''')

nb.md("""
### Is the rotation block really two columns of a rotation matrix?

You do not have to take the layout on faith. Decode it and check the property
that defines a rotation matrix: the columns are unit length and perpendicular to
each other. If the decode is right, both will hold to within rounding.
""")

nb.code('''
def rot6d_to_matrix(vec6):
    """Decode a 6-D rotation into a 3x3 matrix, the way the framework does.

    The 6 numbers are the first two COLUMNS of the matrix, laid out
    [col0(3), col1(3)]. The third column is their cross product. No
    orthonormalisation here on purpose - we want to SEE how close the raw
    numbers already are.
    """
    col0 = np.asarray(vec6[:3], dtype=np.float64)
    col1 = np.asarray(vec6[3:6], dtype=np.float64)
    col2 = np.cross(col0, col1)
    return np.stack([col0, col1, col2], axis=-1)   # columns, not rows

norms0, norms1, dots = [], [], []
for row in rotation6d:
    R = rot6d_to_matrix(row)
    norms0.append(np.linalg.norm(R[:, 0]))
    norms1.append(np.linalg.norm(R[:, 1]))
    dots.append(float(R[:, 0] @ R[:, 1]))

print(f"steps checked            : {len(norms0)}")
print(f"|col0| range             : {min(norms0):.6f} .. {max(norms0):.6f}   (want 1.0)")
print(f"|col1| range             : {min(norms1):.6f} .. {max(norms1):.6f}   (want 1.0)")
print(f"|col0 . col1| worst      : {max(abs(d) for d in dots):.2e}          (want 0.0)")
print()
print("If those three lines look like 1, 1 and ~0, the layout is confirmed:")
print("columns 3-8 really are the first two columns of a rotation matrix.")
''')

nb.checkpoint(
    "You should have a [60, 9] array, most of the motion in column 2, and a "
    "rotation block whose two columns are unit-length and perpendicular. If the "
    "dot products are not near zero, you decoded rows instead of columns.",
    '''
assert forward.shape[1] == 9, f"AV actions are 9-D; this file has {forward.shape[1]}"
assert max(abs(d) for d in dots) < 1e-3, "rotation columns are not perpendicular"
assert axis == 2, f"expected forward motion on column 2 (+Z), found column {axis}"
print("checkpoint passed: the file is a 9-D AV trajectory in the documented layout")
''',
)

# --------------------------------------------------------- forward dynamics
nb.md("""
## Forward dynamics: the first run

Now the spec. This is the source course's record, field for field, expressed as
an `InferenceSpec` so it gets validated locally before a 32 GB model load.

Two settings depend on `MODE`, so that a first pass through the lesson is
minutes rather than tens of minutes:

- `CHUNK` — 30 steps in `reduced`, the file's full 60 in `full`.
- `TIMEOUT_S` — a ceiling, not an estimate. A run that hits it was stuck, not slow.
""")

nb.code('''
CHUNK = 30 if MODE == "reduced" else 60
TIMEOUT_S = 1800 if MODE == "reduced" else 3600
AV_PROMPT = "You are an autonomous vehicle planning system."

def av_forward_spec(name, action_path, chunk=None):
    """A forward_dynamics spec for the AV domain."""
    return cc.InferenceSpec(
        model_mode="forward_dynamics",
        name=name,
        prompt=AV_PROMPT,
        vision_path=str(START_FRAME),
        action_path=str(action_path),
        domain_name="av",
        view_point="ego_view",
        action_chunk_size=chunk or CHUNK,
        fps=10,
        image_size=480,
        seed=0,
    )

fwd_spec = av_forward_spec("av_forward", FORWARD_TRAJ)
print(fwd_spec.describe())
print()
print("the JSON the framework will actually receive:")
print(json.dumps(fwd_spec.to_dict(), indent=2))
print()
print("local validation:", cc.validate_spec(fwd_spec, strict=False) or "no problems")
print()
cc.show_image(START_FRAME, width=480,
              caption="av_0.jpg - the single frame the model predicts forward from")
''')

nb.md("""
### Predict before you run

The next cell runs forward dynamics with the **forward** trajectory. After that
you will run the same start frame with the **left** trajectory. Commit to an
answer before you see either.
""")

nb.predict_run_explain(
    predict=(
        "Both runs start from the identical frame, the identical prompt and the "
        "identical seed. Only `action_path` differs. Write down: (a) how the two "
        "output videos will differ, in one sentence; (b) whether the *scene* — "
        "the road, the buildings, the other vehicles — will be the same in both, "
        "and why; (c) whether you expect the left run to take longer."
    ),
    change=(
        "Run the forward trajectory first, then the left trajectory in the cell "
        "after it. Do not skip ahead to look."
    ),
    explain=(
        "Play both. Did the commanded steering appear? Did the scene content "
        "stay put, drift, or change entirely? Now explain the result in terms of "
        "what the action tokens encode: they describe the *transition between "
        "consecutive states*, not the state itself. What does that predict about "
        "which parts of the output the action can and cannot control?"
    ),
    hint=(
        "Two things are being asked of the model at once: keep the scene "
        "consistent with the start frame, and move the camera the way the "
        "actions say. Those are separate jobs, and they can succeed and fail "
        "independently. Watch for the case where the steering is right and the "
        "buildings quietly change."
    ),
)

nb.code('''
log = cc.MeasurementLog(OUTPUT_DIR / "measurements.jsonl")

print(f"Running forward dynamics, {CHUNK} action steps at 10 fps.")
print("On a first run this also downloads Cosmos3-Nano (~35 GB) plus the")
print("guardrail, the VAE and the text guard. Expect that to dominate.")
print()

with cc.timer("forward_dynamics av_forward", quiet=True) as t_fwd:
    fwd_result = gen.run(fwd_spec, OUTPUT_DIR / "av_forward",
                         seed=0, timeout=TIMEOUT_S)

log.record_timing(t_fwd, mode="forward_dynamics", trajectory="forward",
                  chunk=CHUNK, checkpoint=ACTION_MODEL)
print()
print(f"wall clock: {t_fwd.seconds:.1f} s")
''')

nb.md("""
### Verify the output, do not trust the exit code

The framework can exit 0 having written nothing, or having written a file full
of noise. `verify_result` decodes what was produced and checks it holds
together. The exit code is reported as *one* signal among several, and that
asymmetry is the point: a non-zero code proves failure, a zero code proves
nothing.
""")

nb.code('''
fwd_checks = cc.verify_result(fwd_result)
cc.require(
    fwd_result.ok,
    "The forward-dynamics run did not produce a usable output.",
    fix=(
        "Read the diagnosis printed above. The three most common causes here "
        "are\\n      an OOM (something else holds the card), a partial "
        "checkpoint download,\\n      and the guardrail licence not yet "
        "accepted for nvidia/Cosmos-Guardrail1."
    ),
)
print()
print(f"video: {fwd_result.video_path}")
''')

nb.code('''
cc.show_video(fwd_result.video_path, width=512,
              caption="forward_dynamics, av_traj_forward.json")
''')

# ------------------------------------------------------- steering comparison
nb.md("""
## Same scene, steered differently

Now the comparison that is the actual lesson. Identical start frame, identical
prompt, identical seed, identical everything except the nine numbers per step in
`action_path`.
""")

nb.code('''
left_spec = av_forward_spec("av_left", LEFT_TRAJ)

with cc.timer("forward_dynamics av_left", quiet=True) as t_left:
    left_result = gen.run(left_spec, OUTPUT_DIR / "av_left",
                          seed=0, timeout=TIMEOUT_S)

log.record_timing(t_left, mode="forward_dynamics", trajectory="left",
                  chunk=CHUNK, checkpoint=ACTION_MODEL)
left_checks = cc.verify_result(left_result)
''')

nb.code('''
cc.show_video(left_result.video_path, width=512,
              caption="forward_dynamics, av_traj_left.json - same frame, steered left")
''')

nb.md("""
### What actually differs in the input

Before drawing conclusions from two videos, quantify how different the two
*commands* were. Two trajectories that differ by a hair should not produce
dramatically different video, and if they do, that tells you something about the
model rather than about steering.
""")

nb.code('''
left = load_trajectory(LEFT_TRAJ)
right = load_trajectory(RIGHT_TRAJ)

def summarise(name, arr, chunk):
    used = arr[:chunk]
    tx, ty, tz = used[:, 0].sum(), used[:, 1].sum(), used[:, 2].sum()
    return {
        "trajectory": name,
        "steps_used": int(chunk),
        "sum_x": round(float(tx), 4),
        "sum_y": round(float(ty), 4),
        "sum_z_forward": round(float(tz), 4),
        "lateral_over_forward": round(float(tx / tz), 4) if abs(tz) > 1e-9 else None,
    }

rows = [summarise(n, a, CHUNK) for n, a in
        (("forward", forward), ("left", left), ("right", right))]

header = f"{'traj':<9}{'sum X':>10}{'sum Y':>10}{'sum Z fwd':>12}{'X/Z':>10}"
print(header)
print("-" * len(header))
for r in rows:
    ratio = "n/a" if r["lateral_over_forward"] is None else f"{r['lateral_over_forward']:>10.4f}"
    print(f"{r['trajectory']:<9}{r['sum_x']:>10.4f}{r['sum_y']:>10.4f}"
          f"{r['sum_z_forward']:>12.4f}{ratio}")
print()
print("X is lateral, Z is forward. The X/Z ratio is roughly how much the")
print("vehicle drifts sideways per unit travelled - a crude steering measure.")
print("Whether the signs match your intuition about 'left' depends on the")
print("handedness of the frame, which is Lesson 11's problem.")

(OUTPUT_DIR / "trajectory_summary.json").write_text(json.dumps(rows, indent=2))
''')

nb.md("""
Now go back to your prediction. You have two videos and a table quantifying how
different the two commands were. Write two or three sentences in the cell below
(as a Python string, so it is saved with your outputs) covering: what you
predicted, what happened, and where the difference came from.
""")

nb.code('''
MY_PREDICTION_NOTE = """
Predicted:

Observed:

Explanation:
"""

note_path = OUTPUT_DIR / "prediction_note.md"
note_path.write_text(MY_PREDICTION_NOTE.strip() + "\\n")
print(f"wrote {note_path}")
print()
print(MY_PREDICTION_NOTE.strip())
''')

# -------------------------------------------------------- chunk size sweep
nb.md("""
## What `action_chunk_size` costs

`action_chunk_size` is the number of action steps in the chunk, and the action
media loader reads at most `action_chunk_size + 1` observation frames. So it
sets how much future the model is asked to produce in one go.

The obvious question is what doubling it costs. Do not guess. Measure it on your
machine, because the answer depends on your card, your resolution and whatever
else is resident.
""")

nb.predict_run_explain(
    predict=(
        "You are about to run the same trajectory at `action_chunk_size=15` and "
        "again at `30`. Write down two numbers before running: (a) the ratio of "
        "output video *durations* you expect, and (b) the ratio of wall-clock "
        "*times* you expect. State whether you think those two ratios will be "
        "the same, and why."
    ),
    change=(
        "Nothing to edit — the sweep below runs both. Commit your two numbers "
        "first."
    ),
    explain=(
        "Compare your two predictions against the measured table. If the "
        "duration ratio is close to 2 and the time ratio is not, account for the "
        "difference: which parts of a run are proportional to the amount of "
        "output, and which parts are paid once regardless?"
    ),
    hint=(
        "A run is not only denoising. Process start, checkpoint load, VAE "
        "construction and guardrail setup happen once and do not care how many "
        "frames you asked for. The fixed cost is a bigger fraction of a short "
        "run than a long one."
    ),
)

nb.code('''
SWEEP_CHUNKS = (15, 30)
sweep_rows = []

for chunk in SWEEP_CHUNKS:
    spec = av_forward_spec(f"av_chunk_{chunk}", FORWARD_TRAJ, chunk=chunk)
    with cc.timer(f"forward_dynamics chunk={chunk}", quiet=True) as t_chunk:
        res = gen.run(spec, OUTPUT_DIR / f"av_chunk_{chunk}",
                      seed=0, timeout=TIMEOUT_S, stream_logs=False)
    video_check = cc.check_video(res.video_path) if res.video_path else None
    sweep_rows.append({
        "action_chunk_size": chunk,
        "seconds": round(t_chunk.seconds, 1),
        "ok": bool(res.ok),
        "frames": (video_check.metrics.get("frames") if video_check else None),
        "video": str(res.video_path) if res.video_path else None,
    })
    log.record_timing(t_chunk, mode="forward_dynamics", trajectory="forward",
                      chunk=chunk, checkpoint=ACTION_MODEL)
    print(f"  chunk={chunk}: {t_chunk.seconds:.1f} s, ok={res.ok}")

print()
print(f"{'chunk':>7}{'frames':>9}{'seconds':>10}")
print("-" * 26)
for row in sweep_rows:
    frames = row["frames"] if row["frames"] is not None else "?"
    print(f"{row['action_chunk_size']:>7}{str(frames):>9}{row['seconds']:>10.1f}")

if len(sweep_rows) == 2 and all(r["frames"] for r in sweep_rows):
    frame_ratio = sweep_rows[1]["frames"] / sweep_rows[0]["frames"]
    time_ratio = sweep_rows[1]["seconds"] / max(sweep_rows[0]["seconds"], 1e-9)
    print()
    print(f"measured frame ratio : {frame_ratio:.2f}x")
    print(f"measured time  ratio : {time_ratio:.2f}x")
    print()
    print("Those are YOUR numbers on YOUR machine. This course does not tell you")
    print("what they should be; it tells you to measure them and explain the gap.")

(OUTPUT_DIR / "chunk_sweep.json").write_text(json.dumps(sweep_rows, indent=2))
''')

# ----------------------------------------------------------- debugging lab
nb.md("""
## Debugging lab: the wrong `domain_name`

**Symptom.** A colleague runs forward dynamics on AV footage and gets a video.
It looks like driving. It has the right length and the right frame rate, it
passes `check_video`, and the run exited 0. But the steering does not respond to
the trajectory they edited, and when they push the numbers around the output
barely changes. They ask you to look.

The spec they used is below. It is deliberately wrong, and it is tagged so the
course validator allows it here and nowhere else.
""")

nb.code('''
# DELIBERATELY WRONG. A robot manipulation domain, pointed at AV data.
wrong_spec = cc.InferenceSpec(
    model_mode="forward_dynamics",
    name="av_wrong_domain",
    prompt=AV_PROMPT,
    vision_path=str(START_FRAME),
    action_path=str(FORWARD_TRAJ),
    domain_name="bridge_orig_lerobot",   # <-- a WidowX kitchen robot, not a car
    view_point="ego_view",
    action_chunk_size=15,
    fps=10,
    image_size=480,
    seed=0,
)

# The local validator has no opinion about this, and says so.
print("local validation:", cc.validate_spec(wrong_spec, strict=False) or "no problems")
print()
print("Read that again. The spec is valid. `domain_name` is a free string as far")
print("as this validator is concerned, and nothing in the file it points at")
print("declares which embodiment it belongs to.")
''', tags=["teaching-antipattern"])

nb.md("""
**Hypothesis.** `domain_name` selects an embodiment, and each embodiment has a
fixed raw action width. If the width the domain expects does not match the width
of the file, then either the framework refuses the job (best case) or it
reinterprets the columns (worst case) — and column 9 of a 10-D robot action is
the **gripper**, while the AV file has no ninth column at all.

**Diagnostic step.** Ask the framework what width each domain expects. That
table is `EMBODIMENT_TO_RAW_ACTION_DIM` in
`cosmos_framework/data/generator/action/utils/domain_utils.py`, and it lives in
the framework's venv, not this kernel. So ask the framework's interpreter
directly.

This is a technique you will use repeatedly: when you need a fact from a package
that lives in another environment, run a one-line program in that environment
and read the answer back as JSON. It is more reliable than reading the docs,
because it is the code that will actually run.
""")

nb.code('''
def framework_eval(snippet, *, timeout=180):
    """Run a snippet in the framework's own venv and return its stdout.

    The framework is installed in its own virtualenv with its own torch and
    flash-attn build. This kernel cannot import it. Rather than pretending
    otherwise, we shell into that interpreter for one small question at a time.
    """
    proc = subprocess.run(
        [str(gen.python), "-c", snippet],
        cwd=str(gen.repo),
        env={**os.environ, "LD_LIBRARY_PATH": "", "PYTHONNOUSERSITE": "1"},
        capture_output=True, text=True, timeout=timeout,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"the framework venv could not run that snippet "
            f"(exit {proc.returncode}):\\n{proc.stderr.strip()[-1500:]}"
        )
    return proc.stdout.strip()

DOMAIN_QUERY = """
import json
mod = None
for name in (
    "cosmos_framework.data.generator.action.utils.domain_utils",
    "cosmos_framework.data.vfm.action.domain_utils",
):
    try:
        mod = __import__(name, fromlist=["x"])
        break
    except Exception:
        continue
if mod is None:
    print(json.dumps({"error": "domain_utils not found under either known path"}))
else:
    print(json.dumps({
        "module": mod.__name__,
        "dims": dict(sorted(mod.EMBODIMENT_TO_RAW_ACTION_DIM.items())),
    }))
"""

domain_info = json.loads(framework_eval(DOMAIN_QUERY))
print(f"module: {domain_info.get('module')}")
print()
for name in ("av", "camera_pose", "umi", "bridge_orig_lerobot", "droid_lerobot",
             "fractal", "agibotworld"):
    dim = domain_info.get("dims", {}).get(name)
    print(f"    {name:<22} {dim if dim is not None else 'not listed'}")
print()


def check_domain_matches_action(domain, action_path, dims_table):
    """Preflight: does this domain's expected width match this file's width?"""
    arr = load_trajectory(action_path)
    expected = dims_table.get(domain)
    problems = []
    if expected is None:
        problems.append(
            f"domain {domain!r} has no canonical raw width in the table. That is "
            f"not automatically wrong - libero and hand_pose set their width per "
            f"dataset - but inverse_dynamics and wam are unsupported for those."
        )
    elif arr.shape[1] != expected:
        problems.append(
            f"domain {domain!r} expects {expected} dimensions per step; "
            f"{Path(action_path).name} has {arr.shape[1]}."
        )
    return problems, arr.shape

dims = domain_info.get("dims", {})
for domain in ("av", "bridge_orig_lerobot"):
    problems, shape = check_domain_matches_action(domain, FORWARD_TRAJ, dims)
    print(f"{domain:<22} file shape {shape}")
    for p in problems:
        print(f"    MISMATCH: {p}")
    if not problems:
        print("    consistent")
''')

nb.md("""
That is the diagnosis, and it took two seconds rather than a model load. Now the
part that matters more than the fix.

**Why the output still looked fine.** Run the wrong spec and one of two things
happens, and you should be prepared for both:

- The framework rejects it, and the error names a dimension. Good outcome, easy
  day.
- The framework accepts it and produces a video. The video decodes, has the
  right frame count, and passes every statistical check this course owns —
  because nothing statistical can tell you that column 8 was interpreted as part
  of a rotation when it was meant as one, or that a gripper channel was invented
  from nothing.

The run below is short (15 steps) so you can afford to see which one you get.
""")

nb.code('''
RUN_WRONG_DOMAIN = True   # set False to skip; it costs one short generation

if RUN_WRONG_DOMAIN:
    wrong_result = gen.run(wrong_spec, OUTPUT_DIR / "av_wrong_domain",
                           seed=0, timeout=TIMEOUT_S, stream_logs=False)
    print()
    print(wrong_result.summary())
    print()
    if wrong_result.ok:
        print("IT EXITED CLEANLY AND WROTE OUTPUT. This is the dangerous case.")
        print("Nothing downstream will tell you the semantics were wrong.")
        cc.verify_result(wrong_result)
    else:
        print("It failed. Read the diagnosis above - if it names a dimension,")
        print("the framework caught what our preflight caught, and you got lucky.")
else:
    wrong_result = None
    print("skipped")
''', tags=["teaching-antipattern"])

nb.md("""
**A demonstration you can run without the GPU.** Here is the same failure in
miniature, entirely in this kernel: take the 9-D AV trajectory, pad it to 10-D
so it has the *shape* a robot domain wants, and ask the course's own action
check what it thinks. It will pass. Every number is finite, sensibly scaled and
correctly shaped. The gripper channel is pure fiction.
""")

nb.code('''
fake_robot_action = np.concatenate(
    [forward, np.zeros((len(forward), 1))], axis=1
)   # 9-D AV data wearing a 10-D robot costume

print("as AV (9-D), checked against the AV width:")
print("   ", cc.check_action(forward, expected_dims=9))
print()
print("as a 10-D robot action, checked against the robot width:")
print("   ", cc.check_action(fake_robot_action, expected_dims=10))
print()
print("Both pass. The second is nonsense. The 'gripper' column is a zero we")
print("invented, and columns 3-8 are a camera rotation being read as an")
print("end-effector rotation.")
print()
print("This is the honest limit of output verification: it can tell you a")
print("result is malformed, and it cannot tell you a well-formed result means")
print("the wrong thing. Only the domain/width preflight can.")
''')

nb.md("""
**Repair.** Set `domain_name="av"` and re-run. You already did that at the top of
the lesson, so the repair here is the preflight function, not another
generation: run `check_domain_matches_action` before every action job.

**Verification.** Not "the video looks better". Two checks a program can run:

1. the domain's expected width equals the file's width;
2. the predicted or commanded action passes `check_action(..., expected_dims=W)`
   for that same `W`.

Both are cheap, both run before the model loads, and together they catch every
instance of this class of bug.

**Checkpoint.** You can state the expected action width for `av` and for
`bridge_orig_lerobot`, and you have a preflight that would have caught the
mismatch before any GPU time was spent.
""")

nb.code('''
assert dims.get("av") == 9, "the framework's table says av is not 9-D; re-read it"
assert dims.get("bridge_orig_lerobot") == 10, "bridge_orig_lerobot should be 10-D"
assert check_domain_matches_action("av", FORWARD_TRAJ, dims)[0] == []
assert check_domain_matches_action("bridge_orig_lerobot", FORWARD_TRAJ, dims)[0] != []
print("checkpoint passed: the preflight accepts the right domain and rejects the wrong one")
''')

# -------------------------------------------------------------- exercises
nb.md("""
## Exercises

Three of them. The first is a variation on what you have already run; the second
asks you to author data; the third asks you to build a small tool and evaluate
its effect.
""")

nb.exercise(
    "foundation",
    "The third trajectory, and a different embodiment",
    goal=(
        "Complete the set of AV trajectories, then run something that is *not* "
        "an AV trajectory and discover that a correct action width is necessary "
        "and not sufficient."
    ),
    instructions=(
        "1. Run `av_traj_right.json` with the same spec builder you used for "
        "forward and left. Verify it, and add its row to your comparison table.\n"
        "2. Now `camera_action.json`. It is also 9-D, so your width preflight "
        "passes for `domain_name='av'`. It is not AV data. Find the right "
        "`domain_name` for it in the table you pulled from the framework, and "
        "find a start image in the cookbook that suits a camera move rather "
        "than a road.\n"
        "3. Run it twice: once with the wrong `domain_name` (`av`) and once "
        "with the right one. Both will pass the width check. Compare the two "
        "videos.\n"
        "4. Write two sentences on what the width preflight does and does not "
        "protect you from."
    ),
    success=(
        "Four videos exist (right, camera-wrong-domain, camera-right-domain, "
        "plus the two you already have), all verified with `verify_result`, and "
        "you have written down the limitation of the width check."
    ),
    starter='''
# The cookbook ships three still images intended for camera_pose moves.
CAMERA_TRAJ = cc.asset("camera_action")
CAMERA_IMAGES = sorted((cc.COOKBOOK / "generator/action/assets/images").glob("*_720.png"))
print("candidate start images:", [p.name for p in CAMERA_IMAGES])

# Which domain does a camera move belong to? Look it up rather than guessing.
print("9-D domains in the framework table:",
      [k for k, v in dims.items() if v == 9])

def run_camera(domain, image, chunk=15):
    """Build, validate and run a camera_pose forward-dynamics job."""
    raise NotImplementedError
''',
    hints=[
        "`camera_action.json` is 60 x 9, exactly like the AV files, which is "
        "precisely why the width check cannot separate them. The distinguishing "
        "information is not in the file at all — it is in your head, and "
        "`domain_name` is where you put it.",
        "The camera trajectory's first translation component is large and "
        "negative where the AV ones are near zero, and its `fps` is 30 rather "
        "than 10. Plot the three translation columns of both files side by side "
        "before you run anything.",
    ],
    solution_ref="solutions/10_solutions.ipynb",
)

nb.exercise(
    "applied",
    "Author your own trajectory: a gentle S-curve",
    goal=(
        "Write a 9-D action trajectory from scratch that steers left and then "
        "right, validate its format before spending any GPU time, and generate "
        "from it."
    ),
    instructions=(
        "1. Write `make_s_curve(steps, speed, max_yaw_deg)` returning a "
        "`[steps, 9]` array. Constant forward speed on the +Z column; a yaw "
        "that ramps one way and then the other; the rotation block encoded as "
        "the first two columns of the corresponding rotation matrix.\n"
        "2. Write `validate_trajectory(arr)` and run it **before** generating. "
        "At minimum it should check: 2-D shape; width 9; all finite; the two "
        "rotation columns are unit-length to within a tolerance you choose; the "
        "two rotation columns are perpendicular to within that tolerance; and "
        "per-step translation magnitudes are in the same range as the shipped "
        "AV files.\n"
        "3. Say what tolerance you picked and why. Measure the shipped files "
        "against your own validator first — if it rejects `av_traj_forward.json`, "
        "your validator is wrong, not the file.\n"
        "4. Write the array to JSON in the same bare-list format the cookbook "
        "uses, generate from it, and verify the output.\n"
        "5. Report whether the generated video shows the S you asked for."
    ),
    success=(
        "`validate_trajectory` accepts all three shipped AV files and your own; "
        "your JSON generates without error; the output passes `verify_result`; "
        "and you have a written verdict on whether the S is visible, including "
        "the case where it is not."
    ),
    starter='''
def yaw_to_rot6d(yaw_rad):
    """Rotation about the vertical (Y) axis, as the first two matrix columns."""
    raise NotImplementedError

def make_s_curve(steps=30, speed=0.04, max_yaw_deg=1.5):
    """Return a [steps, 9] AV action trajectory that bends left then right."""
    raise NotImplementedError

def validate_trajectory(arr, *, expected_dims=9, tol=1e-3):
    """Return a list of problems. Empty list means the format is sound."""
    raise NotImplementedError

# Calibrate against the shipped files BEFORE trusting your validator.
for name in ("av_traj_forward", "av_traj_left", "av_traj_right"):
    print(name, validate_trajectory(load_trajectory(cc.asset(name))))
''',
    hints=[
        "A yaw of θ about the +Y axis has rotation matrix columns "
        "col0 = (cos θ, 0, −sin θ) and col1 = (0, 1, 0). Concatenate those six "
        "numbers in that order. Sanity-check with θ=0: you should get "
        "[1,0,0, 0,1,0], which is what row 0 of the shipped files looks like.",
        "These are *per-step deltas*, so the yaw in each row is the small turn "
        "made during that one step, not the heading so far. A degree or two per "
        "step at 10 fps is already a brisk turn — look at the magnitudes in the "
        "shipped files before choosing yours. And if an aggressive yaw produces "
        "incoherent video, you have found an edge of the training distribution: "
        "a result to write down, not a bug to fix.",
    ],
    solution_ref="solutions/10_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "A trajectory editor, and evidence that the edit landed",
    goal=(
        "Build a small tool that loads a trajectory, applies a named transform, "
        "and regenerates — then produce quantitative evidence about whether the "
        "generated video actually reflects the edit."
    ),
    instructions=(
        "1. Implement `edit_trajectory(arr, op, **kwargs)` supporting at least: "
        "`scale_speed` (multiply the forward translation by k), `mirror_steering` "
        "(negate the lateral translation and the corresponding rotation term), "
        "and `truncate` (keep the first n steps). Each transform must return a "
        "trajectory that still passes your Exercise 2 validator.\n"
        "2. `mirror_steering` is the interesting one. Negating the lateral "
        "translation is easy. Mirroring a rotation is not, and getting it wrong "
        "produces a matrix with determinant −1 — a reflection, not a rotation. "
        "Detect that case and say what you did about it.\n"
        "3. Apply each transform to `av_traj_left.json` and generate. Keep the "
        "seed fixed.\n"
        "4. **Evaluate the edit.** Design at least two measures of whether the "
        "output changed in the commanded direction. One must be computed from "
        "the generated video rather than from the input trajectory — otherwise "
        "you are measuring your own arithmetic. Frame-differencing, optical "
        "flow, and running Lesson 11's inverse dynamics on your own output are "
        "all legitimate approaches; pick one and defend it.\n"
        "5. Write `outputs/10/editor_report.md`: the transforms, the measures, "
        "the numbers, and an honest statement of what your measures cannot "
        "detect."
    ),
    success=(
        "Three transforms implemented and validated, at least one edit "
        "generated per transform, at least two evaluation measures with one "
        "computed from the video, and a report that names a specific blind spot "
        "in your own evaluation."
    ),
    starter='''
def edit_trajectory(arr, op, **kwargs):
    """Return a transformed copy of a [steps, 9] trajectory."""
    raise NotImplementedError

def determinant_of_rot6d(vec6):
    """Decode and return det(R). A proper rotation has +1; a reflection has -1."""
    raise NotImplementedError

def evaluate_edit(original_video, edited_video):
    """Return a dict of measures comparing two generated clips."""
    raise NotImplementedError
''',
    hints=[
        "For `mirror_steering`, think about what mirroring means as a matrix "
        "operation: R' = M R M with M = diag(−1, 1, 1). That conjugation keeps "
        "the determinant at +1, whereas negating individual entries does not. "
        "Check `determinant_of_rot6d` on every edited row.",
        "The cheapest video-side measure is the mean absolute difference "
        "between consecutive frames, summed over the clip — a crude proxy for "
        "total motion. It will tell you that speed changed and almost nothing "
        "about direction. Running Lesson 11's inverse dynamics on your own "
        "output is far more direct and has its own weakness: you are using the "
        "same model to grade its own homework. Whichever you pick, say what it "
        "misses.",
    ],
    solution_ref="solutions/10_solutions.ipynb",
)

# ------------------------------------------------------------- assessment
nb.md("""
## Assessment and reflection

### Knowledge check

1. State what a single action token represents in Cosmos 3, and derive from that
   statement why `inverse_dynamics` is possible at all.
2. An AV action step has nine numbers. Say what each group is and how many
   degrees of freedom each group actually has.
3. Why can a 3-D rotation not be represented continuously with three numbers?
   Name the specific failure mode of Euler angles and the specific failure mode
   of quaternions.
4. Given the six numbers `[1, 0, 0, 0, 1, 0]`, write down the full 3×3 rotation
   matrix and say what rotation it represents.
5. You set `domain_name` to a robot domain on AV data and the run exited 0 with
   a plausible video. Name two checks that would have caught it and one that
   would not.
6. Why do the action modes not use `torchrun`? Give both reasons.
7. `action_chunk_size` doubled, and the wall-clock time went up by 1.4×, not 2×.
   Account for the difference.
8. A colleague says "the width check passed, so the domain is right". Give a
   concrete counter-example from this lesson.

### Practical completion test

You can do all of the following without looking anything up:

1. Write a valid `forward_dynamics` spec for the AV domain from memory, and say
   what each field controls.
2. Load a trajectory file and confirm its rotation block decodes to
   near-orthonormal columns.
3. Run the same start frame with two different trajectories and show the
   difference.
4. Run a preflight that catches a domain/width mismatch before the model loads.
5. Report a measured cost ratio for a doubled `action_chunk_size` on your own
   machine.
""")

nb.code('''
def self_test():
    """Confirm this lesson produced what it claims. Prints what passed."""
    passed = []

    assert fwd_result.ok, "the forward-dynamics run did not produce output"
    assert left_result.ok, "the left-trajectory run did not produce output"
    passed.append("two commanded-trajectory videos exist and verified")

    assert all(c.passed for c in fwd_checks if c.name == "video"), \\
        "the forward video failed check_video"
    assert all(c.passed for c in left_checks if c.name == "video"), \\
        "the left video failed check_video"
    passed.append("both videos decode and hold together")

    assert forward.shape == (60, 9), f"unexpected trajectory shape {forward.shape}"
    assert dims.get("av") == 9 and dims.get("bridge_orig_lerobot") == 10
    passed.append("action layout and the framework's width table agree")

    assert (OUTPUT_DIR / "chunk_sweep.json").exists()
    sweep = json.loads((OUTPUT_DIR / "chunk_sweep.json").read_text())
    assert len(sweep) == 2 and all(r["ok"] for r in sweep), "the chunk sweep did not complete"
    passed.append(f"chunk sweep measured at {[r['action_chunk_size'] for r in sweep]}")

    assert (OUTPUT_DIR / "prediction_note.md").exists()
    note = (OUTPUT_DIR / "prediction_note.md").read_text()
    if len(note.strip()) < 80:
        passed.append("NOTE: prediction_note.md is nearly empty - go back and fill it in")
    else:
        passed.append("prediction note written")

    for item in passed:
        print(f"  PASS  {item}" if not item.startswith("NOTE") else f"  ----  {item}")
    return passed

_ = self_test()
''')

nb.md("""
### Summary

- Cosmos 3 treats **action as a modality**. One action token encodes the
  transition between two consecutive visual states, which is why one checkpoint
  can answer three different questions with three values of `model_mode`.
- An AV action step is **9-D**: three translation deltas plus a 6-D rotation.
  Everything is relative to the previous frame; there is no absolute pose in the
  vector.
- The rotation is 6-D because **no continuous, singularity-free representation
  of 3-D rotations exists in three or four dimensions**. The six numbers are the
  first two columns of the rotation matrix; the third is their cross product,
  and the result is snapped back onto SO(3).
- `domain_name` selects an embodiment and therefore an action width. It is a
  free string, nothing in the action file declares which embodiment it belongs
  to, and a valid-but-wrong value produces well-formed nonsense.
- Check the domain's expected width against the file's width **before** running.
  It costs two seconds and it is the only check that catches this class of bug.
- Action modes launch as a single process with `--parallelism-preset=latency`
  and hand-set `RANK`/`WORLD_SIZE`/`LOCAL_RANK`. `torchrun` at world size 1 buys
  nothing and can hang on a stale environment variable.
- Cost ratios are measured, not quoted. The fixed cost of a run — process start,
  checkpoint load, VAE, guardrail — does not scale with `action_chunk_size`, so
  doubling the chunk does not double the time.

### Common misconceptions

| Belief | Correction |
|---|---|
| "Actions are absolute positions" | They are per-step deltas in the previous frame's coordinate system. |
| "Six numbers for three degrees of freedom is wasteful" | It is the price of continuity, and three or four numbers cannot buy it at any price. |
| "The rotation block is the first two *rows*" | Columns. Decoding rows gives you the transpose, which is the inverse rotation — plausible, wrong, and it still passes an orthonormality check. |
| "If `check_action` passes, the action is correct" | It passes for a 9-D AV trajectory padded to look like a robot action. Well-formed is not correct. |
| "A wrong `domain_name` will error" | Sometimes. When it does not, you get a clean exit and a plausible video. |
| "`action_chunk_size` is a quality knob" | It is a length knob. It sets how many steps are in the chunk and how many observation frames get read. |
| "`latency` versus `throughput` matters a lot here" | At world size 1 there is no queue to amortise. Lesson 15 measures whether it matters at all. |

### Suggested extensions

- Take the last row of `av_traj_forward.json`, repeat it 60 times, and generate.
  A constant-velocity command is the simplest possible trajectory and it tells
  you what the model does with no information.
- Scale every translation in a trajectory by 5 and generate. Where does the
  output stop being coherent? That boundary is the edge of the training
  distribution and it is worth knowing where it is before you rely on the model.
- Generate the same trajectory at three seeds. How much of what you attributed
  to the actions was actually sampling noise?

### Mastery checklist

- [ ] I can state what an action token represents and derive the three modes
      from it.
- [ ] I can decompose a 9-D AV action and explain the 6-D rotation.
- [ ] I can write a `forward_dynamics` spec from memory and justify every field.
- [ ] I ran the same frame with two trajectories and can describe the difference.
- [ ] I measured the cost of doubling `action_chunk_size` on my own machine.
- [ ] I have a domain/width preflight and I know what it does not catch.
- [ ] I can explain why action modes skip `torchrun`.

Lesson 11 runs the model backwards: given a video, what actions produced it? It
also confronts the pose mathematics this lesson has been carefully standing next
to.
""")

nb.md(FOOTER_MD)

nb.write(ROOT / "10_action_forward_dynamics.ipynb")
