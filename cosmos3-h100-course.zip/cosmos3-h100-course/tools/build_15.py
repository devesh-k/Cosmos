"""Build 15_optimisation.ipynb.

Module 4, lesson 2. Depends on Lesson 14: this lesson spends the measurement
skill rather than teaching it.

Design decisions worth knowing before editing this file:

* **Nothing is asserted.** Not the precision ranking, not the attention backend
  win, not the knob ranking. Every one of those is measured by a cell on the
  learner's machine. Where a fact comes from COSMOS3_FACTS.md (Hopper selects
  `flash-attn-3-nv`; Nano wants ~32 GB) it is labelled as a documented fact and
  the learner is shown how to verify it in their own checkout.
* Precision, attention and `torch.compile` are taught on **synthetic workloads
  shaped like the real one** — a stack of attention-plus-MLP blocks — so the
  whole first half runs in seconds with no checkpoint.
* Real generation is behind `RUN_GENERATION`, off by default, and reuses
  whatever Module 2 downloaded. `outputs/06/calibration.json` is read if it
  exists and rebuilt from measured runs if it does not.
* The framework's inference CLI is **not** assumed to expose a precision flag.
  The lesson has the learner probe `--help` in their own checkout and report
  what they find, which is both honest and a better habit than trusting a
  course to have got a flag name right.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from nbbuild import FOOTER_MD, SETUP_CELL, Notebook  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

nb = Notebook("Lesson 15 — Optimisation")

# =====================================================================
# 1. Title block
# =====================================================================
nb.md("""
# Lesson 15 — Optimisation, with the receipts

**What you will build.** A ranked table of every knob that costs you time on
*your* H100, measured rather than assumed; `optimise_for(time_budget, quality)`
that searches that space using your own calibration; and
`outputs/15/optimisation_study.json` — a defensible answer to "what is the
fastest configuration that still meets my quality bar?"

| | |
|---|---|
| **Time** | ~2.5 hours. The synthetic half is minutes; the generation half depends on what you opt in to. |
| **GPU** | 1 × H100 80 GB. Nothing else may hold the card during the generation sections. |
| **Downloads** | **None by default.** The optional generation sections reuse the checkpoint Module 2 already pulled and tell you the size before pulling anything. |
| **Prerequisites** | Lesson 14. Lesson 06 for `outputs/06/calibration.json` (this notebook rebuilds it if it is missing and you enable generation). |
""")

# =====================================================================
# 2. Learning objectives
# =====================================================================
nb.md("""
## Learning objectives

By the end of this lesson you can:

1. **Explain** float32, float16, bfloat16 and float8 at the bit level — sign,
   exponent, mantissa — and derive each format's range and precision from
   `torch.finfo` rather than from memory.
2. **Demonstrate** why float16 needs loss scaling and bfloat16 does not, by
   counting how many gradient-sized values underflow to zero in each.
3. **Measure** the throughput of the same matrix multiplication at every
   precision your card supports, and state which of those your workload can
   actually use.
4. **Detect** which attention backend is active on your machine, and explain
   what FlashAttention does and why it is a memory win as much as a speed win.
5. **Measure** attention memory against sequence length for a materialised
   implementation and a fused one, and identify the point where one fails.
6. **Compare** `--parallelism-preset=latency` against `throughput` on one GPU,
   and say what a preset can and cannot do at world size 1.
7. **Rank** `num_steps`, resolution tier, `num_frames` and guidance by their
   measured effect on your machine, and predict each one's scaling before
   measuring it.
8. **Locate** the knee on a quality-against-cost curve, and state honestly what
   an automated quality proxy misses.
9. **Quantify** the cost of a cold start against a warm one and decide when
   caching is worth the complexity.
10. **Predict and then measure** `torch.compile`'s warm-up cost, and compute the
    number of runs at which it pays for itself.
11. **Diagnose** an "optimisation" that made things slower, and explain the
    mechanism rather than just reverting it.
""")

# =====================================================================
# 3. Environment and prerequisites
# =====================================================================
nb.md("""
## Environment and prerequisites

Two cells, and they are the first thing you run.
""")

nb.code('# This lesson writes to outputs/15/. The setup cell below reads this name.\n'
        '__lesson__ = "15"\n\n' + SETUP_CELL)

nb.md("""
## Why nothing in this lesson is asserted

Lesson 14 taught you to tell a real speedup from an artefact. This lesson goes
looking for real ones — and the discipline holds: **not one number in this
notebook is asserted by the course.** Every ranking, every ratio and every
recommendation is produced by a cell you run.

That matters more here than anywhere else, because optimisation advice ages
badly. A blog post from two years ago about which precision is fastest was
probably right about a different GPU, a different PyTorch and a different kernel
library. The method survives; the numbers do not.

`MODE="reduced"`, which the cell above just printed, keeps the synthetic sweeps
small and the optional generation runs short.

The verification cell below reports what your card can do at the *hardware*
level: bfloat16 needs compute capability 8.0, float8 tensor cores need 8.9, and
FlashAttention-3 needs Hopper (9.0). An H100 is `sm_90`, so all three should be
available — but check rather than assume, because that is the habit this module
exists to build.
""")

nb.code('''
import gc
import json
import math
import statistics
import struct
import subprocess
import threading
import time

try:
    import torch
except ImportError:
    torch = None

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None
    print("matplotlib is not installed — the plots below will be skipped.")

from cosmos_course.measure import MeasurementLog

cc.require(torch is not None, "torch is not installed; nothing here can run.",
           fix="Run scripts/setup.sh, then select the 'Cosmos 3 (H100)' kernel.")
cc.require(torch.cuda.is_available(),
           "No CUDA device is visible. This lesson measures a GPU.",
           fix="Check `nvidia-smi`, then `torch.cuda.is_available()`, then "
               "`echo $CUDA_VISIBLE_DEVICES`.")

OOM_ERROR = getattr(torch, "OutOfMemoryError", None) or torch.cuda.OutOfMemoryError

props = torch.cuda.get_device_properties(0)
CC = (props.major, props.minor)
TOTAL_VRAM_GB = props.total_memory / 1e9

HAS_BF16 = torch.cuda.is_bf16_supported()
HAS_FP8_DTYPE = hasattr(torch, "float8_e4m3fn")
FP8_CAPABLE = CC >= (8, 9)
IS_HOPPER = CC == (9, 0)

if MODE == "full":
    SEQ_LENS, BENCH_REPEATS, MATMUL_N = (1024, 2048, 4096, 8192, 16384), 11, 8192
else:
    SEQ_LENS, BENCH_REPEATS, MATMUL_N = (1024, 2048, 4096, 8192), 7, 4096

log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
FINDINGS = {}

print(f"device            : {props.name}")
print(f"compute capability: sm_{CC[0]}{CC[1]}")
print(f"VRAM              : {TOTAL_VRAM_GB:.1f} GB")
print(f"torch             : {torch.__version__} (CUDA {torch.version.cuda})")
print()
print(f"bfloat16 supported            : {HAS_BF16}          (needs cc >= 8.0)")
print(f"float8 tensor cores by cc      : {FP8_CAPABLE}          (needs cc >= 8.9)")
print(f"float8 dtypes in this torch    : {HAS_FP8_DTYPE}")
print(f"Hopper (FlashAttention-3 path) : {IS_HOPPER}          (cc == 9.0)")
print()
print("Documented fact, not a measurement (COSMOS3_FACTS.md section 3): the")
print("Cosmos Framework selects its attention backend by architecture —")
print("Blackwell -> natten, Hopper -> flash-attn-3-nv, Ada/Ampere -> flash-attn.")
print("You verify the consequence of that below rather than taking it on trust.")
''')

# =====================================================================
# 4. Conceptual foundation
# =====================================================================
nb.md("""
## Optimisation is a search, not a list of flags

Most optimisation writing is a list of things to turn on. That is not what this
is, because on one GPU with one workload the list is short and most of it is
already on by default. What is left is a **search problem** with a shape worth
naming:

```
      you have:   a time budget          (seconds you are willing to wait)
                  a memory budget        (80 GB, minus anything else resident)
                  a quality bar          (what counts as good enough)

      you choose: num_steps              cost ~ linear
                  resolution tier        cost ~ quadratic in the linear scale
                  num_frames             cost ~ linear
                  guidance on/off        cost ~ 2x if it needs a second pass
                  model tier             cost ~ discrete, and changes capability

      you get:    one configuration, and an argument for why it is the one
```

The knobs are not equal, and they are not equal in a way you can predict from
first principles and then check. Latent tokens go as **pixel area**, so halving
each linear dimension is roughly a quarter of the tokens, not a half. Steps are
sequential, so they hit wall clock almost linearly and peak memory hardly at
all. Frames enter linearly after the VAE's temporal compression. Guidance is a
step function: off, one forward pass per step; on, two.

Three of those four you already met in Lesson 06's cost model. What this lesson
adds is **measurement of the model's error** — where the predicted ratios hold
on your machine and where they do not, which is exactly the information you need
to trust a plan you have not run.

The cell below fills that diagram in with your machine's numbers instead of the
diagram's, so you know what you are searching inside.
""")

nb.code('''
# The search space, with your own budgets in it. Only the memory line is a
# measurement; the scalings are the COST MODEL you are about to test.
free_b, total_b = torch.cuda.mem_get_info()
tier = cc.MODEL_TIERS[MODEL]

TIME_BUDGET_S = 120        # seconds you are willing to wait per clip. Edit it.
QUALITY_BAR = "recognisable subject, no obvious temporal flicker"

print("budgets")
print(f"  time    : {TIME_BUDGET_S} s per clip        (yours to choose)")
print(f"  memory  : {free_b / 1e9:.1f} GB free of {total_b / 1e9:.1f} GB   (measured, right now)")
print(f"  quality : {QUALITY_BAR}")
print()
print(f"{MODEL} wants {tier['inference_vram_gb']} GB for inference (documented in")
print(f"COSMOS3_FACTS.md, not measured), which leaves "
      f"{free_b / 1e9 - tier['inference_vram_gb']:+.1f} GB of headroom.")
print()

KNOB_MODEL = {
    "num_steps": ("linear", "sequential passes over the same latent"),
    "resolution tier": ("quadratic in scale", "latent tokens go as pixel area"),
    "num_frames": ("linear", "frames enter the token count linearly"),
    "guidance": ("step, about 2x", "a second forward pass per step"),
}

print(f"{'knob':<17} {'predicted cost':<20} why")
for knob, (scaling, why) in KNOB_MODEL.items():
    print(f"{knob:<17} {scaling:<20} {why}")
print()
print("Every entry in that second column is a PREDICTION. The rest of this")
print("lesson measures them and reports where the prediction is wrong.")
''')

nb.md("""
### The two things everybody reaches for first

**Precision.** Fewer bits per number means less memory moved, and on tensor
cores, more arithmetic per clock. It also means less numerical headroom. The
first half of this lesson is about what those bits actually are, because
"bfloat16 is more robust than float16" is a sentence you cannot evaluate without
knowing what is in a float.

**Attention.** The naive implementation of attention builds an $N \\times N$
score matrix. At the sequence lengths a video diffusion transformer works at,
that matrix is the single largest tensor in the model, and it exists only to be
immediately reduced by a softmax and a matmul. FlashAttention never builds it.
That is a memory win first and a speed win second, and you will measure both.

Everything else — presets, caching, `torch.compile` — is in the second half,
where the honest answer is more often "measure it, and be prepared for the
answer to be no".
""")

# =====================================================================
# 5. Precision
# =====================================================================
nb.md("""
## What is actually in a floating-point number

Start from zero. A floating-point number is three fields packed into a fixed
number of bits:

```
   sign  exponent            mantissa (also called significand)
   [s]   [e e e e e e e e]   [m m m m m m m m m m m m m m m m m m m m m m m]
    1            8                              23                    = float32
```

The value is roughly $(-1)^{s} \\times 1.m \\times 2^{e - \\text{bias}}$.

- The **exponent** field sets the *range* — how large and how small a number can
  be before it becomes infinity or zero. More exponent bits, wider range.
- The **mantissa** field sets the *precision* — how many distinct values fit
  between one power of two and the next. More mantissa bits, finer resolution.

Sixteen-bit formats have to split sixteen bits between those two jobs, and the
two common ones split them differently:

- **float16** spends bits on precision: fewer exponent bits, more mantissa.
- **bfloat16** spends bits on range: it keeps float32's *entire* exponent field
  and throws away mantissa instead. A bfloat16 is literally the top 16 bits of
  a float32.

That single design choice is why bfloat16 is the default for training. Gradients
span an enormous dynamic range and mostly need to *exist*, not to be precise.
Values that would flush to zero in float16 survive in bfloat16.

Rather than take any of that from me, derive it. The cell below reads the field
widths out of `torch.finfo` and decomposes a number you choose into its bits in
each format.
""")

nb.code('''
FORMATS = [("float32", torch.float32), ("float16", torch.float16)]
if HAS_BF16:
    FORMATS.append(("bfloat16", torch.bfloat16))
if HAS_FP8_DTYPE:
    FORMATS.append(("float8_e4m3fn", torch.float8_e4m3fn))
    FORMATS.append(("float8_e5m2", torch.float8_e5m2))


def field_widths(dtype):
    """Derive (exponent_bits, mantissa_bits) from finfo. No table to get wrong.

    eps is the gap between 1.0 and the next representable number, which is
    2 ** -mantissa_bits by construction. Everything else follows.
    """
    fi = torch.finfo(dtype)
    mantissa = int(round(-math.log2(fi.eps)))
    exponent = fi.bits - 1 - mantissa
    return exponent, mantissa


print(f"{'format':<16} {'bits':>5} {'sign':>5} {'exp':>4} {'mant':>5} "
      f"{'max finite':>13} {'smallest normal':>17} {'eps':>11}")
FORMAT_TABLE = {}
SUPPORTED = []
for name, dtype in FORMATS:
    # Guarded per format: an 8-bit dtype that this torch declares but does not
    # fully support should cost you that row, not the whole table.
    try:
        fi = torch.finfo(dtype)
        exp_bits, man_bits = field_widths(dtype)
        print(f"{name:<16} {fi.bits:>5} {1:>5} {exp_bits:>4} {man_bits:>5} "
              f"{fi.max:>13.3e} {fi.tiny:>17.3e} {fi.eps:>11.3e}")
    except Exception as exc:
        print(f"{name:<16} unavailable in this build: {type(exc).__name__}")
        continue
    FORMAT_TABLE[name] = {"bits": fi.bits, "exponent_bits": exp_bits,
                          "mantissa_bits": man_bits, "max": fi.max,
                          "tiny": fi.tiny, "eps": fi.eps}
    SUPPORTED.append((name, dtype))

FORMATS = SUPPORTED
FINDINGS["formats"] = FORMAT_TABLE
print()
print("Read the exponent column against the max-finite column: they are the same")
print("fact twice. Read the mantissa column against eps: also the same fact.")
print("If bfloat16 is in your table, compare its exponent width against float32's.")
''')

nb.code('''
# Decompose one number into bits, in each format. Change VALUE and re-run.
VALUE = 0.1


def bit_string(value, dtype):
    """The raw bit pattern of `value` stored as `dtype`, as a string."""
    t = torch.tensor([value], dtype=torch.float32).to(dtype)
    fi = torch.finfo(dtype)
    if fi.bits == 32:
        raw = struct.unpack(">I", struct.pack(">f", float(t.item())))[0]
    elif fi.bits == 16:
        raw = t.view(torch.int16).item() & 0xFFFF
    else:                                    # 8-bit formats
        raw = t.view(torch.int8).item() & 0xFF
    return format(raw, "0" + str(fi.bits) + "b")


print(f"VALUE = {VALUE!r}\\n")
print(f"{'format':<16} {'bits (sign | exponent | mantissa)':<46} {'stored as':>18} {'error':>12}")
for name, dtype in FORMATS:
    try:
        bits = bit_string(VALUE, dtype)
        exp_bits, man_bits = field_widths(dtype)
        grouped = f"{bits[0]} | {bits[1:1 + exp_bits]} | {bits[1 + exp_bits:]}"
        stored = float(torch.tensor([VALUE], dtype=torch.float32)
                       .to(dtype).to(torch.float32).item())
    except Exception as exc:
        print(f"{name:<16} could not be decomposed: {type(exc).__name__}")
        continue
    print(f"{name:<16} {grouped:<46} {stored:>18.10g} {abs(stored - VALUE):>12.3e}")

if HAS_BF16:
    fp32_bits = bit_string(VALUE, torch.float32)
    bf16_bits = bit_string(VALUE, torch.bfloat16)
    print()
    print(f"float32 top 16 bits : {fp32_bits[:16]}")
    print(f"bfloat16            : {bf16_bits}")
    print("Identical, or differing in the last bit from rounding. bfloat16 is not")
    print("a different encoding — it is float32 with the low mantissa truncated,")
    print("which is why converting between them is nearly free.")
''')

nb.md("""
### Why float16 needs loss scaling and bfloat16 does not

Here is the practical consequence, and it is not a stylistic preference.

Gradients in a large network are small — many of them are in the region of
$10^{-7}$ to $10^{-9}$. float16's smallest normal number is around $6 \\times
10^{-5}$ (your table above has the exact figure). Below that it has subnormals
for a few more orders of magnitude, and then zero.

A gradient that becomes exactly zero does not make training slightly worse. It
makes that parameter stop learning. Silently.

**Loss scaling** is the fix: multiply the loss by a large constant before the
backward pass, so every gradient is scaled up into float16's representable
range, then divide the gradients by the same constant before the optimiser step.
It works, and it is an entire subsystem — dynamic scale selection, overflow
detection, skipped steps — that exists solely because of those missing exponent
bits.

bfloat16 keeps float32's exponent, so its smallest normal is float32's. No
scaling subsystem needed. You pay for it in mantissa bits, which for gradient
accumulation matters much less than you would expect.

Count it rather than believe it. The cell below builds a tensor of realistic
gradient magnitudes and asks how many survive each cast.
""")

nb.code('''
torch.manual_seed(0)

# Gradient-shaped magnitudes: log-uniform across the range a real network shows.
n = 1_000_000
exponents = torch.empty(n).uniform_(-9.0, -3.0)          # 1e-9 .. 1e-3
grads = (10.0 ** exponents) * torch.sign(torch.randn(n))
grads = grads.cuda()

LOSS_SCALE = 2 ** 16


def survival(dtype, scale=1.0):
    """Fraction of values that are still non-zero after a round trip."""
    scaled = (grads * scale).to(dtype).to(torch.float32) / scale
    return float((scaled != 0).float().mean())


rows = [("float16, no loss scaling", torch.float16, 1.0),
        (f"float16, loss scale {LOSS_SCALE}", torch.float16, float(LOSS_SCALE))]
if HAS_BF16:
    rows.append(("bfloat16, no loss scaling", torch.bfloat16, 1.0))

print(f"{'cast':<32} {'gradients surviving':>21} {'lost':>10}")
survival_table = {}
for label, dtype, scale in rows:
    frac = survival(dtype, scale)
    survival_table[label] = frac
    print(f"{label:<32} {frac:>20.2%} {1 - frac:>9.2%}")

FINDINGS["gradient_survival"] = survival_table

print()
print(f"float16 smallest normal : {torch.finfo(torch.float16).tiny:.3e}")
if HAS_BF16:
    print(f"bfloat16 smallest normal: {torch.finfo(torch.bfloat16).tiny:.3e}")
print(f"float32 smallest normal : {torch.finfo(torch.float32).tiny:.3e}")
print()
print("Now the other half of the trade. Cast a value near 1.0 and measure the")
print("rounding error each format introduces:")
probe = torch.tensor([1.0 + 1e-3, 3.14159265, 1234.5678], device="cuda")
for name, dtype in [f for f in FORMATS
                    if f[0] in ("float32", "float16", "bfloat16")]:
    back = probe.to(dtype).to(torch.float32)
    rel = ((back - probe).abs() / probe.abs()).max().item()
    print(f"  {name:<12} worst relative error on those three values: {rel:.3e}")
print()
print("bfloat16 loses more precision than float16 and keeps more range. Which")
print("trade is right depends on whether your failure mode is underflow or")
print("rounding — for gradients it is underflow, which is why training defaults")
print("to bfloat16 and why inference can often get away with either.")

del grads
gc.collect()
torch.cuda.empty_cache()
''')

nb.md("""
### float8 on Hopper

Hopper (`sm_90`) has tensor cores that multiply 8-bit floats. Eight bits is not
many, so there are two formats and you pick per tensor:

- **E4M3** — 4 exponent bits, 3 mantissa. More precision, less range. Used for
  weights and activations in the forward pass.
- **E5M2** — 5 exponent, 2 mantissa. More range, less precision. Used for
  gradients, which need range.

What float8 buys is bandwidth and tensor-core throughput: half the bytes of
bfloat16 moving through the same memory system, and a faster matmul instruction.
What it costs is that you cannot simply cast to it and hope. Values must be
**scaled** into range per tensor, which is why the PyTorch entry point is
`torch._scaled_mm` and takes explicit scale factors rather than being a dtype
you pass to `@`.

That friction is the point: float8 is not a dtype swap, it is a numerics
project. The cell below measures whatever your build can actually do, and
reports honestly when a path is not available — which is a common and legitimate
outcome.
""")

nb.code('''
a32 = torch.randn(MATMUL_N, MATMUL_N, device="cuda", dtype=torch.float32)
b32 = torch.randn(MATMUL_N, MATMUL_N, device="cuda", dtype=torch.float32)
FLOPS = 2 * MATMUL_N ** 3

precision_results = {}


def measure_matmul(label, fn):
    """Benchmark one matmul path. Warm-up and repeats come from Lesson 14."""
    try:
        fn()
        torch.cuda.synchronize()
    except Exception as exc:
        print(f"{label:<24} unavailable: {type(exc).__name__}: {str(exc)[:90]}")
        return None
    out = cc.benchmark(fn, label=label, warmup=3, repeats=BENCH_REPEATS, quiet=True)
    out["tflops"] = FLOPS / out["median_s"] / 1e12
    precision_results[label] = out
    return out


tf32_was = torch.backends.cuda.matmul.allow_tf32
print(f"TF32 for matmul was {'ON' if tf32_was else 'OFF'} by default in this build.\\n")

torch.backends.cuda.matmul.allow_tf32 = False
measure_matmul("float32 (TF32 off)", lambda: a32 @ b32)

torch.backends.cuda.matmul.allow_tf32 = True
measure_matmul("float32 (TF32 on)", lambda: a32 @ b32)
torch.backends.cuda.matmul.allow_tf32 = tf32_was      # leave the build as we found it

a16 = a32.to(torch.float16)
b16 = b32.to(torch.float16)
measure_matmul("float16", lambda: a16 @ b16)

if HAS_BF16:
    abf = a32.to(torch.bfloat16)
    bbf = b32.to(torch.bfloat16)
    measure_matmul("bfloat16", lambda: abf @ bbf)

if HAS_FP8_DTYPE and FP8_CAPABLE and hasattr(torch, "_scaled_mm"):
    # _scaled_mm wants the second operand column-major and explicit scales.
    # If your torch spells this differently, the failure is reported, not hidden.
    a8 = a32.to(torch.float8_e4m3fn)
    b8 = b32.t().contiguous().t().to(torch.float8_e4m3fn)
    one = torch.tensor(1.0, device="cuda")

    def fp8_matmul():
        return torch._scaled_mm(a8, b8, scale_a=one, scale_b=one,
                                out_dtype=torch.bfloat16)

    measure_matmul("float8_e4m3 (scaled_mm)", fp8_matmul)
else:
    print("float8 matmul not attempted: needs cc >= 8.9, float8 dtypes and "
          "torch._scaled_mm")

print()
print(f"{'precision':<26} {'median':>11} {'TFLOP/s':>12} {'vs fp32(TF32 off)':>19}")
baseline = precision_results.get("float32 (TF32 off)", {}).get("median_s")
for label, out in precision_results.items():
    rel = f"{baseline / out['median_s']:.2f}x" if baseline else "n/a"
    print(f"{label:<26} {out['median_s'] * 1e3:>10.3f}ms {out['tflops']:>12,.0f} {rel:>19}")

FINDINGS["precision_matmul"] = {k: {"median_s": v["median_s"], "tflops": v["tflops"]}
                                for k, v in precision_results.items()}
log.record(label="precision_matmul", model=MODEL, mode=MODE, matmul_n=MATMUL_N,
           **{k.replace(" ", "_"): v["median_s"] for k, v in precision_results.items()})
''')

nb.md("""
### Read that table carefully before you generalise it

Three warnings, all of which apply to your own numbers above.

**It is a square matmul, not your workload.** A diffusion transformer is matmul
plus attention plus normalisation plus a VAE, and only some of that is on the
tensor-core path. A 3× matmul speedup does not become a 3× generation speedup —
Amdahl's law is not a suggestion.

**TF32 is not float32.** If your two float32 rows differ, that is TF32:
a 19-bit internal format the tensor cores use for float32 matmuls, on by default
in many builds. It is a precision change wearing a float32 label, and knowing
that it is on is part of knowing what you measured.

**The framework chooses, not you.** Cosmos Framework selects its own compute
dtype. Nothing you set in this kernel changes what the generation subprocess
does. What this table tells you is the *shape of the hardware's preferences* —
useful when you are reading a log and wondering why something is fast.

To find out what your checkout actually exposes, ask it. That is the next cell,
and the answer is whatever it prints, not whatever this course guessed.
""")

nb.code('''
from cosmos_course.models import Generator

generator = Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=True)

print()
if framework_problems:
    print("Framework checkout not usable, so its CLI cannot be interrogated.")
    print("Run this yourself once you have it:")
    print("    <repo>/.venv/bin/python -m cosmos_framework.scripts.inference --help")
    cli_help = ""
else:
    try:
        done = subprocess.run(
            [str(generator.python), "-m", "cosmos_framework.scripts.inference", "--help"],
            cwd=str(generator.repo), capture_output=True, text=True, timeout=300,
            env={**os.environ, "LD_LIBRARY_PATH": "", "PYTHONNOUSERSITE": "1"},
        )
        cli_help = (done.stdout or "") + (done.stderr or "")
    except Exception as exc:
        cli_help = ""
        print(f"could not run --help: {type(exc).__name__}: {exc}")

if cli_help:
    interesting = ["precision", "dtype", "fp8", "bf16", "quant", "compile",
                   "parallelism", "memory", "guardrail", "offload"]
    print(f"{len(cli_help.splitlines())} lines of help. Flags mentioning the words")
    print(f"{interesting}:")
    print()
    for line in cli_help.splitlines():
        low = line.lower()
        if any(word in low for word in interesting) and line.strip().startswith("-"):
            print("  " + line.strip()[:110])
    print()
    print("Whatever is above is the truth for YOUR checkout. If there is no")
    print("precision flag, that is the answer, and inventing one from a blog post")
    print("would waste an afternoon. Extra flags reach the CLI through")
    print("Generator.run(..., extra_args=[...]) if you find one worth trying.")

FINDINGS["cli_help_lines"] = len(cli_help.splitlines())
''')

# =====================================================================
# 6. Attention
# =====================================================================
nb.md("""
## Attention, and why FlashAttention is a memory result

Attention takes queries $Q$, keys $K$ and values $V$, each with $N$ rows, and
computes

$$\\mathrm{softmax}\\!\\left(\\frac{QK^{\\top}}{\\sqrt{d}}\\right)V.$$

The obvious implementation builds $QK^{\\top}$ — an $N \\times N$ matrix — takes
a softmax over it, and multiplies by $V$. For a video latent with tens of
thousands of tokens, per head, per layer, that intermediate is enormous, and it
exists for microseconds before being reduced away.

**FlashAttention never builds it.** It walks $K$ and $V$ in tiles that fit in
the GPU's on-chip SRAM, accumulating the softmax with a running maximum and a
running sum (the online-softmax trick), so the full score matrix is never
written to HBM at all. Memory goes from $O(N^2)$ to $O(N)$.

That is why the memory story matters as much as the speed story:

- **Memory**: the $N^2$ intermediate disappears. This is what lets a model take
  a longer video at a given VRAM budget, and it is often the difference between
  a configuration that fits and one that does not.
- **Speed**: attention at these sizes is bound by memory bandwidth, not
  arithmetic. Not writing the big matrix means not reading it back, so the
  kernel goes faster for the same reason it uses less memory.

`COSMOS3_FACTS.md` §3 records that the framework picks `flash-attn-3-nv` on
Hopper, `natten` on Blackwell and `flash-attn` on Ada/Ampere. That is a fact
about the framework, so verify what *your* PyTorch does independently: the cell
below forces each SDPA backend in turn and reports which ones your build can
actually run.
""")

nb.code('''
try:
    from torch.nn.attention import SDPBackend, sdpa_kernel
    BACKENDS = [("flash", SDPBackend.FLASH_ATTENTION),
                ("mem_efficient", SDPBackend.EFFICIENT_ATTENTION),
                ("math (materialises N x N)", SDPBackend.MATH)]
except ImportError:
    BACKENDS = []
    print("torch.nn.attention is unavailable in this build; falling back to the")
    print("global backend flags only.")

print("Globally enabled SDPA backends, as this build reports them:")
for name, probe in (("flash", "flash_sdp_enabled"),
                    ("mem_efficient", "mem_efficient_sdp_enabled"),
                    ("math", "math_sdp_enabled")):
    fn = getattr(torch.backends.cuda, probe, None)
    print(f"  {name:<16} {fn() if fn else 'unknown'}")

try:
    import flash_attn
    print(f"\\nflash_attn package: {getattr(flash_attn, '__version__', 'unknown')}")
except ImportError:
    print("\\nflash_attn package: not importable from THIS kernel. That is expected —")
    print("the framework has its own venv with its own build, and this kernel is")
    print("not that environment. It says nothing about what generation uses.")

B, H, D = 1, 8, 64
N_PROBE = 4096
q = torch.randn(B, H, N_PROBE, D, device="cuda", dtype=torch.float16)
k = torch.randn(B, H, N_PROBE, D, device="cuda", dtype=torch.float16)
v = torch.randn(B, H, N_PROBE, D, device="cuda", dtype=torch.float16)

backend_results = {}
for label, backend in BACKENDS:
    try:
        with sdpa_kernel(backend):
            torch.nn.functional.scaled_dot_product_attention(q, k, v)
            torch.cuda.synchronize()

            def run(be=backend):
                with sdpa_kernel(be):
                    return torch.nn.functional.scaled_dot_product_attention(q, k, v)

            out = cc.benchmark(run, label=label, warmup=3,
                               repeats=BENCH_REPEATS, quiet=True)
        backend_results[label] = out["median_s"]
        print(f"  {label:<28} usable, median {out['median_s'] * 1e3:8.3f} ms "
              f"at N={N_PROBE}")
    except Exception as exc:
        print(f"  {label:<28} NOT usable: {type(exc).__name__}: {str(exc)[:70]}")

FINDINGS["attention_backends"] = backend_results
del q, k, v
gc.collect()
torch.cuda.empty_cache()
''')

nb.code('''
def naive_attention(q, k, v):
    """The textbook version. Builds the whole N x N score matrix in HBM."""
    scores = (q @ k.transpose(-2, -1)) / math.sqrt(q.shape[-1])
    return torch.softmax(scores, dim=-1) @ v


def fused_attention(q, k, v):
    """Whatever your build's fastest fused kernel is."""
    return torch.nn.functional.scaled_dot_product_attention(q, k, v)


def peak_gb_of(fn, n):
    """Peak allocated VRAM for one call at sequence length n, or None on OOM."""
    qq = torch.randn(1, 8, n, 64, device="cuda", dtype=torch.float16)
    kk = torch.randn(1, 8, n, 64, device="cuda", dtype=torch.float16)
    vv = torch.randn(1, 8, n, 64, device="cuda", dtype=torch.float16)
    torch.cuda.synchronize()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    base = torch.cuda.memory_allocated()
    try:
        t0 = time.perf_counter()
        fn(qq, kk, vv)
        torch.cuda.synchronize()
        seconds = time.perf_counter() - t0
        peak = (torch.cuda.max_memory_allocated() - base) / 1e9
    except OOM_ERROR:
        peak, seconds = None, None
    finally:
        del qq, kk, vv
        gc.collect()
        torch.cuda.empty_cache()
    return peak, seconds


attention_scaling = []
print(f"{'N':>7} {'naive peak':>12} {'naive time':>12} {'fused peak':>12} "
      f"{'fused time':>12} {'memory ratio':>13}")
for n in SEQ_LENS:
    naive_peak, naive_t = peak_gb_of(naive_attention, n)
    fused_peak, fused_t = peak_gb_of(fused_attention, n)
    ratio = (naive_peak / fused_peak) if (naive_peak and fused_peak) else None
    attention_scaling.append({"n": n, "naive_gb": naive_peak, "fused_gb": fused_peak,
                              "naive_s": naive_t, "fused_s": fused_t})
    print(f"{n:>7} "
          f"{(f'{naive_peak:.3f} GB' if naive_peak else 'OOM'):>12} "
          f"{(f'{naive_t * 1e3:.1f} ms' if naive_t else '-'):>12} "
          f"{(f'{fused_peak:.3f} GB' if fused_peak else 'OOM'):>12} "
          f"{(f'{fused_t * 1e3:.1f} ms' if fused_t else '-'):>12} "
          f"{(f'{ratio:.1f}x' if ratio else '-'):>13}")

FINDINGS["attention_scaling"] = attention_scaling
print()
print("Check the naive column against N^2: doubling N should roughly quadruple")
print("its peak. Check the fused column against N: doubling N should roughly")
print("double it. Where the naive column says OOM and the fused one does not,")
print("you are looking at the reason long-context video generation is possible")
print("on one card at all.")
''')

nb.checkpoint(
    "Two things should be true before you go on. Your naive attention peak "
    "should grow roughly as $N^2$ (each doubling of N about quadrupling it) "
    "while the fused one grows roughly as $N$; and at least one reduced "
    "precision should have out-performed float32 with TF32 off. If either "
    "fails, the rest of this lesson will rank things wrongly — find out why "
    "first.",
    '''
scaling = FINDINGS["attention_scaling"]
pairs = [(a, b) for a, b in zip(scaling, scaling[1:])
         if a["naive_gb"] and b["naive_gb"]]
if pairs:
    print(f"{'N -> 2N':<16} {'naive growth':>14} {'fused growth':>14}")
    for a, b in pairs:
        naive = b["naive_gb"] / a["naive_gb"]
        fused = (b["fused_gb"] / a["fused_gb"]) if (a["fused_gb"] and b["fused_gb"]) else float("nan")
        print(f"{a['n']} -> {b['n']:<9} {naive:>13.2f}x {fused:>13.2f}x")
    print()
    print("  expect the naive column near 4 and the fused column near 2.")
else:
    print("  naive attention could not be measured at two adjacent sizes —")
    print("  it probably ran out of memory at the smallest one. Reduce SEQ_LENS.")

prec = FINDINGS["precision_matmul"]
if "float32 (TF32 off)" in prec:
    slowest = prec["float32 (TF32 off)"]["tflops"]
    faster = {k: v["tflops"] / slowest for k, v in prec.items()
              if v["tflops"] > slowest}
    print()
    print(f"  precisions beating float32/TF32-off: {len(faster)}")
    for name, ratio in sorted(faster.items(), key=lambda kv: -kv[1]):
        print(f"    {name:<26} {ratio:5.2f}x")
    if not faster:
        print("    none. That is unusual on Hopper — check whether TF32 was")
        print("    actually disabled, and whether the matrix is large enough to")
        print("    saturate the tensor cores at all.")
''')

# =====================================================================
# 7. Parallelism presets
# =====================================================================
nb.md("""
## The parallelism presets on one GPU

The framework takes `--parallelism-preset=latency` or `throughput`, and
`cosmos_course.models.Generator` chooses between them by mode: **latency** for
the action modes (`wam`, `forward_dynamics`, `inverse_dynamics`) and
**throughput** for generation. The reasoning is straightforward when you say it
out loud:

- **Latency** optimises for finishing *one* sample as fast as possible. An
  action model in a control loop is asked one question at a time and the answer
  is needed now.
- **Throughput** optimises for total samples per unit time and will happily make
  any single sample slower to do it. A batch of clips for a dataset does not
  care which one finishes first.

The honest part: these presets exist mainly to configure how work is split
across *ranks* — context parallelism, sequence sharding, that family of
decisions. **At world size 1 there is nothing to split.** What is left is
whatever within-rank scheduling and memory choices the preset also carries,
which may be nothing at all.

So the course does not tell you the answer. It shows you the two command lines,
which differ in exactly one token, and leaves measuring the difference on your
machine to the exercises. A preset that makes no measurable difference at world
size 1 is a perfectly good finding, and reporting it is more useful than
repeating a claim.
""")

nb.code('''
from cosmos_course.models import ACTION_MODEL_MODES
from cosmos_course.specs import build_inference_command

demo_spec = OUTPUT_DIR / "_specs" / "preset_demo.json"
demo_spec.parent.mkdir(parents=True, exist_ok=True)
demo_spec.write_text(json.dumps({
    "model_mode": "text2video", "name": "preset_demo",
    "prompt": "a robot in a kitchen", "resolution": "256",
    "num_frames": 61, "num_steps": 20,
}, indent=2) + "\\n")

argv_lat, _ = build_inference_command(demo_spec, OUTPUT_DIR / "preset_demo",
                                      checkpoint=MODEL, parallelism_preset="latency")
argv_thr, _ = build_inference_command(demo_spec, OUTPUT_DIR / "preset_demo",
                                      checkpoint=MODEL, parallelism_preset="throughput")

differences = [(a, b) for a, b in zip(argv_lat, argv_thr) if a != b]
print(f"the two command lines differ in {len(differences)} token(s):")
for a, b in differences:
    print(f"  latency   : {a}")
    print(f"  throughput: {b}")

print()
print("Which preset each mode gets, from cosmos_course.models:")
print(f"  action modes (latency)     : {sorted(ACTION_MODEL_MODES)}")
print("  everything else (throughput): generation modes")
print()
print("And the launch shape differs too, which is the bigger difference: action")
print("modes run as a single `python -m` process with RANK/WORLD_SIZE supplied by")
print("hand, generation runs under torchrun. Read Generator._build_command if you")
print("want the exact reasoning — it is commented for this.")

FINDINGS["preset_token_diff"] = len(differences)
''')

# =====================================================================
# 8. The knobs
# =====================================================================
nb.md("""
## The knobs that actually cost you, ranked

This is the practical payoff of the whole module. Four knobs, and they do not
cost the same:

| Knob | Predicted scaling | Why |
|---|---|---|
| `num_steps` | linear | steps are sequential passes over the same latent |
| resolution tier | quadratic in the linear scale | latent tokens go as pixel **area** |
| `num_frames` | linear | frames enter the token count linearly after 4× temporal compression |
| guidance | step function, roughly ×2 | classifier-free guidance needs a second, unconditional forward pass per step |

Note that guidance is not in `estimate_generation_cost()`, because it is not a
token-count effect — it is a *pass-count* effect. The cell below adds it as an
explicit multiplier so you can see the whole space in one table, and labels it
as a model rather than a measurement.

Predict first, from the cost model. Measure second, if you opt in. Then compare
the two and report where the model is wrong, because that is the useful part.
""")

nb.code('''
BASE = {"resolution": "480", "num_frames": 61, "num_steps": 20}


def modelled_cost(resolution, num_frames, num_steps, guidance_on=True):
    """Cost units, with an explicit pass multiplier for guidance.

    The pass multiplier is a MODEL of classifier-free guidance, not a
    measurement: CFG evaluates the network twice per step, once conditioned and
    once not. Whether your stack fuses those into one batched pass is exactly
    the sort of thing to check by measuring rather than assuming.
    """
    est = cc.estimate_generation_cost(resolution=str(resolution),
                                      num_frames=int(num_frames),
                                      num_steps=int(num_steps))
    passes = 2 if guidance_on else 1
    return est["cost_units"] * passes, est


base_units, base_est = modelled_cost(**BASE)

VARIATIONS = [
    ("num_steps 20 -> 10",     {**BASE, "num_steps": 10}, True),
    ("num_frames 61 -> 31",    {**BASE, "num_frames": 31}, True),
    ("resolution 480 -> 256",  {**BASE, "resolution": "256"}, True),
    ("guidance on -> off",     dict(BASE), False),
    ("resolution 480 -> 768",  {**BASE, "resolution": "768"}, True),
    ("num_steps 20 -> 40",     {**BASE, "num_steps": 40}, True),
]

print(f"base: {BASE['resolution']}p, {BASE['num_frames']} frames, "
      f"{BASE['num_steps']} steps, guidance on")
print(f"      {base_est['width']}x{base_est['height']}, "
      f"{base_est['latent_tokens']:,} latent tokens, {base_units:,} modelled units")
print()
print(f"{'change':<26} {'modelled units':>16} {'relative':>10} {'saving':>10}")
predicted = {}
for label, config, guided in VARIATIONS:
    units, _ = modelled_cost(**config, guidance_on=guided)
    predicted[label] = units / base_units
    print(f"{label:<26} {units:>16,} {units / base_units:>9.2f}x "
          f"{1 - units / base_units:>9.0%}")

FINDINGS["predicted_knob_ranking"] = predicted
print()
print("Rank those by saving. That ranking is a PREDICTION from a cost model with")
print("three assumptions in it: tokens go as area, steps are linear, guidance")
print("doubles the passes. Write down which one you least believe.")
''')

nb.predict_run_explain(
    predict=(
        "Of the four knobs — `num_steps`, resolution tier, `num_frames` and "
        "guidance — which gives the **largest time saving per unit of perceived "
        "quality lost**? That is a different question from the table above, "
        "which only ranks cost. Write down your ranking of all four, and for "
        "each one name the artefact you expect to see when you turn it down too "
        "far: blur? noise? temporal flicker? a shorter clip? prompt drift?"
    ),
    change=(
        "Enable the measured sweep below (`RUN_GENERATION = True`) if you have a "
        "checkpoint locally, or run the sweep on the synthetic block stack, which "
        "gives you the cost half of the answer without the quality half. Say "
        "which you did."
    ),
    explain=(
        "Compare your predicted ranking against the measured one. Where they "
        "disagree, the interesting question is which is wrong — your intuition "
        "about quality, or the cost model's assumption. Then answer this: is the "
        "answer the same for a dataset of 10,000 clips as it is for one hero "
        "clip? Say why not."
    ),
    hint=(
        "Cost and quality-per-unit-cost rank differently, and that is the whole "
        "point of the question. Resolution is the biggest cost lever *and* the "
        "most visible loss — you are throwing away pixels a viewer can count. "
        "Steps past the knee cost time and buy nothing measurable, which makes "
        "them free savings until they suddenly are not.\\n\\n"
        "For the last part: with 10,000 clips your currency is throughput and a "
        "small per-clip quality loss is amortised over a dataset. With one hero "
        "clip you have all night and quality is the only axis."
    ),
)

nb.md("""
### Optional: measure the knobs for real

Everything above was arithmetic. This section runs Cosmos 3 across a small
sweep so the ranking is measured rather than modelled.

It is **off by default**. Turn it on if you already have a checkpoint from
Module 2 — the cell checks your Hugging Face cache and reports what a run would
download before pulling anything. In reduced mode the sweep is a handful of
short runs at the smallest tier; it is minutes, not hours, but it is not free.

If you leave it off, everything downstream still works: the cells fall back to
Lesson 06's recorded measurements where they exist and say plainly when they
have nothing to work with. They will not invent a number to fill a table.
""")

nb.code('''
class GpuSampler:
    """Poll device-wide VRAM on a thread. Same class as Lesson 14, condensed."""

    def __init__(self, interval=0.5, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_gb()
            if value is not None:
                self.samples.append(value)

    def __enter__(self):
        self.samples = [self._read_gb() or 0.0]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def baseline_gb(self):
        return self.samples[0] if self.samples else None

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None


print("GpuSampler ready (device-wide, not process-attributed — Lesson 14 §7).")
''')

nb.code('''
# Two flags, deliberately separate — the same pattern as Lesson 06.
#   RUN_GENERATION  : run real generation at all
#   ALLOW_DOWNLOAD  : permit a checkpoint download if the cache is empty
# Keeping them apart means turning on generation can never start a 9-35 GB pull
# by accident. Read the cache report below before setting either.
RUN_GENERATION = False
ALLOW_DOWNLOAD = False


def hf_cache_gb(repo_id):
    root = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface")) / "hub"
    path = root / ("models--" + repo_id.replace("/", "--"))
    if not path.exists():
        return 0.0
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file()) / 1e9


repo = cc.MODEL_TIERS[MODEL]["hf_repo"]
cached_gb = hf_cache_gb(repo)
needs_download = cached_gb < 1.0
print(f"{repo}: {cached_gb:.1f} GB cached locally")
if needs_download:
    print(f"  A run would download ~{cc.MODEL_TIERS[MODEL]['download_gb']:.1f} GB plus "
          f"first-run auxiliaries "
          f"({sum(cc.AUXILIARY_DOWNLOADS_GB.values()):.1f} GB).")
    print("  If you did Module 2 this is unexpected — check COSMOS_COURSE_MODEL and")
    print("  HF_HOME point where you think. Otherwise set ALLOW_DOWNLOAD = True")
    print("  above, having read that figure.")
else:
    print("  Nothing to download; this reuses what Module 2 already pulled.")

GEN_OK = (RUN_GENERATION and not framework_problems
          and (not needs_download or ALLOW_DOWNLOAD))
print(f"\\nmeasured generation enabled: {GEN_OK}")

# Calibration from Lesson 06, reused if present. Rebuilt below if it is missing
# AND generation is enabled; otherwise left as None and reported as unknown.
CAL_PATH = cc.OUTPUT_ROOT / "06" / "calibration.json"
calibration = {}
if CAL_PATH.exists():
    try:
        calibration = json.loads(CAL_PATH.read_text())
    except json.JSONDecodeError:
        calibration = {}

UNITS_PER_SECOND = calibration.get("units_per_second")
FIXED_OVERHEAD_S = calibration.get("fixed_overhead_s") or 0.0
print(f"calibration    : {CAL_PATH} "
      f"({'found' if calibration else 'missing'})")
print(f"units/second   : "
      f"{UNITS_PER_SECOND:,.0f}" if UNITS_PER_SECOND else "units/second   : unknown")
print(f"fixed overhead : {FIXED_OVERHEAD_S:.1f} s")
''')

nb.code('''
SWEEP_RUNS = {}


def measured_run(label, resolution, num_frames, num_steps, guidance=7.0, seed=0):
    """One real generation, timed and sampled. Returns None when disabled."""
    if not GEN_OK:
        return None
    prompt_path = cc.asset_or_none("prompt_robot_kitchen")
    prompt = (json.dumps(json.loads(prompt_path.read_text()), separators=(",", ":"))
              if prompt_path else
              "a wheeled robot tidying a bright domestic kitchen, steady camera")
    spec = cc.InferenceSpec(
        model_mode="text2video", name=label, prompt=prompt,
        resolution=str(resolution), aspect_ratio="16,9",
        num_frames=int(num_frames), num_steps=int(num_steps),
        guidance=guidance, shift=10.0, seed=seed,
    )
    with GpuSampler() as sampler:
        with cc.timer(label, track_memory=False) as timing:
            result = generator.run(spec, OUTPUT_DIR / "sweep", seed=seed, timeout=3600)
    entry = {
        "label": label, "seconds": timing.seconds,
        "resolution": str(resolution), "num_frames": int(num_frames),
        "num_steps": int(num_steps), "guidance": guidance,
        "device_peak_gb": sampler.peak_gb, "device_baseline_gb": sampler.baseline_gb,
        "cost_units": spec.cost().get("cost_units"),
        "outputs": [str(p) for p in result.outputs],
        "ok": bool(result.ok),
    }
    SWEEP_RUNS[label] = entry
    log.record(model=MODEL, mode=MODE, **{k: v for k, v in entry.items()
                                          if k != "outputs"})
    cc.verify_result(result)
    return entry


SWEEP = [
    ("base",        "256", 61, 20, 7.0),
    ("half_steps",  "256", 61, 10, 7.0),
    ("half_frames", "256", 31, 20, 7.0),
    ("no_guidance", "256", 61, 20, 1.0),
]
if MODE == "full":
    SWEEP.append(("up_res", "480", 61, 20, 7.0))

if GEN_OK:
    total_units = sum(cc.estimate_generation_cost(
        resolution=r, num_frames=f, num_steps=s)["cost_units"] for _, r, f, s, _ in SWEEP)
    if UNITS_PER_SECOND:
        print(f"predicted total sweep time: "
              f"{(len(SWEEP) * FIXED_OVERHEAD_S + total_units / UNITS_PER_SECOND) / 60:.1f} min")
    else:
        print("no calibration, so the sweep duration cannot be predicted. It is")
        print(f"{len(SWEEP)} short runs; watch the first one and extrapolate.")
    for label, res, frames, steps, guide in SWEEP:
        measured_run(label, res, frames, steps, guidance=guide)
        print("-" * 72)
else:
    print("Measured sweep skipped. Falling back to Lesson 06's log where possible.")
    prior = MeasurementLog(cc.OUTPUT_ROOT / "06" / "measurements.jsonl").load()
    for record in prior:
        if record.get("seconds") and record.get("resolution"):
            SWEEP_RUNS[str(record.get("label", "l06"))] = {
                "label": record.get("label"), "seconds": record["seconds"],
                "resolution": str(record["resolution"]),
                "num_frames": record.get("num_frames"),
                "num_steps": record.get("num_steps"),
                "guidance": None, "device_peak_gb": record.get("peak_gb"),
                "cost_units": record.get("cost_units"), "ok": True,
            }
    print(f"recovered {len(SWEEP_RUNS)} run(s) from Lesson 06")
''')

nb.code('''
def modelled_ratio(entry, base_entry):
    """Predicted time ratio for one run against the base, from the cost model.

    Computed against the base that was ACTUALLY run rather than reused from the
    table above, whose base is a different configuration. Reusing a ratio across
    two different bases is exactly the kind of quiet mistake this module exists
    to stop.
    """
    for e in (entry, base_entry):
        if not (e.get("resolution") and e.get("num_frames") and e.get("num_steps")):
            return None
    mine, _ = modelled_cost(entry["resolution"], entry["num_frames"],
                            entry["num_steps"],
                            guidance_on=(entry.get("guidance") or 7.0) > 1.0)
    theirs, _ = modelled_cost(base_entry["resolution"], base_entry["num_frames"],
                              base_entry["num_steps"],
                              guidance_on=(base_entry.get("guidance") or 7.0) > 1.0)
    return mine / theirs if theirs else None


if "base" in SWEEP_RUNS:
    base_run = SWEEP_RUNS["base"]
    overhead = FIXED_OVERHEAD_S
    base_compute = max(base_run["seconds"] - overhead, 1e-6)

    print(f"fixed overhead subtracted before comparing: {overhead:.1f} s "
          f"({'from Lesson 06' if overhead else 'unknown, so none'})")
    print("The cost model has NO fixed-overhead term, so comparing it against")
    print("wall clock is comparing two different quantities. The 'compute' column")
    print("is the fair comparison; 'wall' is what you actually wait.\\n")

    print(f"{'change':<16} {'wall':>9} {'wall x':>8} {'compute x':>10} "
          f"{'predicted':>10} {'model error':>12} {'peak GB':>9}")
    ranked = []
    shorter_than_overhead = []
    for label, entry in SWEEP_RUNS.items():
        if label == "base" or not entry.get("seconds"):
            continue
        wall_ratio = entry["seconds"] / base_run["seconds"]
        # A run shorter than the measured fixed overhead cannot have its
        # compute time recovered by subtraction. Say so rather than printing a
        # clamped zero that looks like a measurement.
        compute_s = entry["seconds"] - overhead
        if compute_s > 0.5 and base_run["seconds"] - overhead > 0.5:
            compute_ratio = compute_s / base_compute
            compute_col = f"{compute_ratio:.2f}x"
        else:
            compute_ratio, compute_col = None, "n/a"
            shorter_than_overhead.append(label)
        pred = modelled_ratio(entry, base_run)
        error = (f"{100 * (pred - compute_ratio) / compute_ratio:+.0f}%"
                 if (pred and compute_ratio) else "n/a")
        ranked.append((1 - wall_ratio, label, wall_ratio))
        print(f"{label:<16} {entry['seconds']:>8.1f}s {wall_ratio:>7.2f}x "
              f"{compute_col:>10} {(f'{pred:.2f}x' if pred else 'n/a'):>10} "
              f"{error:>12} {(entry.get('device_peak_gb') or float('nan')):>9.1f}")

    if shorter_than_overhead:
        print()
        print(f"  {len(shorter_than_overhead)} run(s) were shorter than the "
              f"{overhead:.1f} s fixed overhead")
        print(f"  ({', '.join(shorter_than_overhead)}), so their compute time")
        print("  cannot be recovered by subtraction. Either the calibration is")
        print("  stale for this tier, or these runs are too short to calibrate")
        print("  against. Re-measure the overhead at the tier you care about.")

    print()
    print("Ranked by measured wall-clock saving, largest first — because wall")
    print("clock is the thing you pay:")
    for saving, label, ratio in sorted(ranked, reverse=True):
        print(f"  {saving:>6.0%}  {label:<16} ({ratio:.2f}x the base run)")
    FINDINGS["measured_knob_ranking"] = {label: ratio for _, label, ratio in ranked}
    print()
    print("Where the model error exceeds about 20%, the cost model is missing")
    print("something for your stack. Name it rather than averaging it away.")
    print("Candidates, in the order they are usually to blame:")
    print("  - your fixed overhead is stale (it was measured on a different tier)")
    print("  - guidance is fused into one batched pass, so it is not a 2x")
    print("  - a resolution tier crosses a kernel or tiling boundary")
    print("  - the run was not alone on the card")
else:
    print("No base run available, so there is nothing to rank.")
    print("Enable RUN_GENERATION, or run Lesson 06 first. The course would rather")
    print("show you an empty table than a plausible invented one.")
''')

nb.md("""
### Rebuilding the calibration, if Lesson 06 did not

Lesson 06 writes `outputs/06/calibration.json`: a fixed overhead $a$ and a rate
$b$ such that $t \\approx a + \\text{units}/b$ on this machine. Everything above
that predicted a duration read that file.

If it is missing and you enabled the sweep, the sweep contains what is needed to
rebuild it. Two runs at the same geometry and different step counts give two
equations in two unknowns:

$$b_{\\text{step}} = \\frac{t_{20} - t_{10}}{10}, \\qquad a = t_{10} - 10\\,b_{\\text{step}}$$

The cell below does that and writes the file back to `outputs/06/`, where the
rest of the course looks for it. It is a **weaker** calibration than Lesson 06's
— two points at one tier rather than several across tiers — and it says so in
the file it writes, because a calibration that does not record its own
provenance is one you will over-trust in three weeks.
""")

nb.code('''
if not UNITS_PER_SECOND and {"base", "half_steps"} <= set(SWEEP_RUNS):
    t20 = SWEEP_RUNS["base"]["seconds"]
    t10 = SWEEP_RUNS["half_steps"]["seconds"]
    per_step = (t20 - t10) / 10.0
    fitted_overhead = t10 - 10 * per_step

    rates = []
    for label, entry in SWEEP_RUNS.items():
        units = entry.get("cost_units")
        compute_s = entry["seconds"] - max(fitted_overhead, 0.0)
        if units and compute_s > 0.5:
            rates.append(units / compute_s)

    if rates and fitted_overhead > 0:
        UNITS_PER_SECOND = sorted(rates)[len(rates) // 2]          # median
        FIXED_OVERHEAD_S = fitted_overhead
        CAL_PATH.parent.mkdir(parents=True, exist_ok=True)
        CAL_PATH.write_text(json.dumps({
            "model": MODEL, "mode": MODE,
            "fixed_overhead_s": FIXED_OVERHEAD_S,
            "per_step_s_at_sweep_tier": per_step,
            "units_per_second": UNITS_PER_SECOND,
            "samples": [{"label": k, "seconds": v["seconds"],
                         "cost_units": v.get("cost_units")}
                        for k, v in SWEEP_RUNS.items()],
            "note": ("Rebuilt by Lesson 15 from a two-point step fit at one "
                     "resolution tier. Weaker than Lesson 06's multi-tier "
                     "calibration; re-run Lesson 06 when you can."),
        }, indent=2) + "\\n")
        print(f"rebuilt calibration -> {CAL_PATH}")
        print(f"  fixed overhead : {FIXED_OVERHEAD_S:8.1f} s")
        print(f"  per step       : {per_step:8.3f} s at the sweep tier")
        print(f"  units/second   : {UNITS_PER_SECOND:12,.0f} (median of "
              f"{len(rates)} run(s))")
    else:
        print("Could not fit a calibration from these runs.")
        print(f"  implied fixed overhead was {fitted_overhead:.1f} s, which is not")
        print("  physical if negative — that happens when the shorter run paid a")
        print("  first-touch cost the longer one did not. Re-run the sweep now")
        print("  that everything is warm, or run Lesson 06 properly.")
elif UNITS_PER_SECOND:
    print(f"Calibration already present: {UNITS_PER_SECOND:,.0f} units/s, "
          f"{FIXED_OVERHEAD_S:.1f} s overhead.")
    print(f"Source: {CAL_PATH}. Not overwritten — Lesson 06's is the better one.")
else:
    print("No calibration and no sweep runs to build one from. Every prediction")
    print("in this notebook that needs seconds will say 'unknown' rather than")
    print("guess, which is the behaviour you want.")
''')

# =====================================================================
# 9. Quality / cost frontier
# =====================================================================
nb.md("""
## The quality/cost frontier, and why the proxy is weak

Cost you can measure exactly. Quality you cannot, and pretending otherwise is
the most common dishonesty in optimisation write-ups.

What is available automatically is a set of **proxies**. `cc.check_image()`
returns `std`, `edge_density`, `autocorrelation` and `uniform_fraction` for
free, and `check_video()` adds a temporal-change figure. Sweep a knob, plot a
proxy against measured time, and the curve usually has a **knee**: a point past
which more cost buys no more proxy.

Then be honest about what the proxy misses, because it is most of what you care
about:

- **Prompt adherence.** Edge density does not know whether the robot is in a
  kitchen.
- **Physical plausibility.** A beautifully sharp video of an object falling
  upwards scores well on every statistic here.
- **Temporal coherence** beyond frame-to-frame difference — an object that
  changes identity halfway through a clip.
- **Semantic artefacts** — extra fingers, impossible reflections, text that is
  not text.
- **The direction of the effect.** More edge density can mean sharper detail or
  it can mean noise. The proxy cannot tell you which, and they are opposite
  outcomes.

So the knee is a *hypothesis about where to look*, not an answer. The procedure
that survives scrutiny is: use the proxy to pick two or three candidate
configurations, then look at the outputs yourself, then commit. Human judgement
is not a fallback here; it is the measurement, and the proxy is the thing that
tells you which handful of clips are worth your eyes.
""")

nb.code('''
frontier = []
for label, entry in SWEEP_RUNS.items():
    if not entry.get("seconds"):
        continue
    metrics = {}
    for raw in entry.get("outputs", []):
        path = Path(raw)
        if path.suffix.lower() == ".mp4":
            metrics = cc.check_video(path).metrics
            break
        if path.suffix.lower() in {".png", ".jpg", ".jpeg"}:
            metrics = cc.check_image(path).metrics
            break
    frontier.append({"label": label, "seconds": entry["seconds"],
                     "num_steps": entry.get("num_steps"),
                     "resolution": entry.get("resolution"), **metrics})

if frontier and any("edge_density" in row or "std" in row for row in frontier):
    key = "edge_density" if any("edge_density" in r for r in frontier) else "std"
    print(f"{'run':<16} {'seconds':>9} {key:>14}")
    for row in sorted(frontier, key=lambda r: r["seconds"]):
        value = row.get(key)
        print(f"{row['label']:<16} {row['seconds']:>8.1f}s "
              f"{(f'{value:.4f}' if value is not None else 'n/a'):>14}")
    if plt is not None and len(frontier) > 2:
        xs = [r["seconds"] for r in frontier if r.get(key) is not None]
        ys = [r[key] for r in frontier if r.get(key) is not None]
        labels = [r["label"] for r in frontier if r.get(key) is not None]
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(xs, ys, "o-")
        for x, y, name in zip(xs, ys, labels):
            ax.annotate(name, (x, y), fontsize=8,
                        textcoords="offset points", xytext=(4, 4))
        ax.set_xlabel("measured seconds")
        ax.set_ylabel(f"quality proxy ({key})")
        ax.set_title("Cost against a weak proxy for quality")
        plt.tight_layout()
        plt.show()
    FINDINGS["frontier"] = frontier
    print()
    print("Now open the outputs and look at them. If the proxy ranks them")
    print("differently from your eyes, the proxy is wrong for this workload and")
    print("that is the single most useful sentence you can write down today.")
else:
    print("No generated outputs to score, so there is no frontier to plot.")
    print("The code above is correct and runs the moment you have runs — but a")
    print("quality/cost curve with no quality measurements would be a drawing,")
    print("not a result.")
''')

# =====================================================================
# 10. Caching, reuse and batching
# =====================================================================
nb.md("""
## Never load the same model twice

The cheapest optimisation available to you is not a flag. It is not paying a
fixed cost twice.

Every subprocess generation run pays, before it denoises anything: process
start, `import torch`, CUDA context creation, weight load from disk (or page
cache), guardrail model load, and text encoding. Lesson 06 measured that as
`fixed_overhead_s`; Lesson 14 measured its floor — process start plus context
creation — directly.

The arithmetic is unforgiving. Ten separate runs pay it ten times. One batched
run pays it once. If the fixed cost is a meaningful fraction of a single run,
batching is the largest single optimisation available and it costs you nothing
in quality.

The cell below measures the floor of that fixed cost on your machine (it is the
same probe as Lesson 14, so this is a re-measurement, not a copied number), then
does the arithmetic for a ten-clip job.
""")

nb.code('''
COLD_PROBE = """
import json, time
t0 = time.perf_counter()
import torch
t_import = time.perf_counter() - t0
t0 = time.perf_counter()
torch.cuda.init()
x = torch.ones(1, device="cuda")
torch.cuda.synchronize()
t_context = time.perf_counter() - t0
print(json.dumps({"import_s": t_import, "context_s": t_context,
                  "context_vram_gb": torch.cuda.memory_reserved() / 1e9}))
"""

t0 = time.perf_counter()
done = subprocess.run([sys.executable, "-c", COLD_PROBE],
                      capture_output=True, text=True, timeout=600)
process_total_s = time.perf_counter() - t0

if done.returncode == 0 and done.stdout.strip():
    cold = json.loads(done.stdout.strip().splitlines()[-1])
    cold["process_total_s"] = process_total_s
    FINDINGS["cold_start"] = cold
    print("Floor of a cold start on this machine (no model weights at all):")
    for key, value in cold.items():
        print(f"  {key:<20} {value:8.3f}")
    print()
    n_clips = 10
    print(f"For a {n_clips}-clip job:")
    print(f"  {n_clips} separate processes : "
          f"{n_clips * process_total_s:7.1f} s of pure startup")
    print(f"  1 batched process     : {process_total_s:7.1f} s of pure startup")
    print(f"  saved                 : "
          f"{(n_clips - 1) * process_total_s:7.1f} s, before any weights are read")
    if FIXED_OVERHEAD_S:
        print()
        print(f"Lesson 06 measured the FULL fixed overhead (this plus weight load,")
        print(f"guardrail and text encoding) at {FIXED_OVERHEAD_S:.1f} s. Over "
              f"{n_clips} runs")
        print(f"that is {n_clips * FIXED_OVERHEAD_S / 60:.1f} minutes you can spend once "
              f"instead of {n_clips} times.")
else:
    cold = {}
    print("probe failed; stderr tail:")
    print((done.stderr or "")[-500:])
''')

nb.md("""
### Batching, where the framework supports it

`Generator.run()` accepts a **list** of specs and writes them as JSONL — one
sample per line, one process. That is the batching interface, and it is worth
knowing exactly what it does and does not buy you:

- It **does** amortise process start, context creation, weight load and guardrail
  load across every sample in the batch.
- It **does not** necessarily run samples concurrently on the device. Whether
  the framework fuses them into one larger forward pass or simply loops is an
  implementation detail you should check by measuring, not assume.

That distinction matters for what you conclude. If batching only amortises the
fixed cost, the saving is bounded by the fixed cost and is large only for short
runs. If it also fills the GPU better, the saving grows with batch size until
the device saturates — and finding *that* point is the debugging lab below.
""")

nb.code('''
batch_specs = []
for i, steps in enumerate((10, 14, 18)):
    batch_specs.append(cc.InferenceSpec(
        model_mode="text2video", name=f"batch_{i}",
        prompt="a robot tidying a kitchen, steady camera, natural light",
        resolution="256", aspect_ratio="16,9",
        num_frames=61, num_steps=steps, guidance=7.0, shift=10.0, seed=i,
    ))

batch_units = sum(s.cost().get("cost_units", 0) for s in batch_specs)
print(f"{len(batch_specs)} specs, {batch_units:,} cost units in total")
for spec in batch_specs:
    print(f"  {spec.name:<10} {spec.num_steps:>3} steps  "
          f"{spec.cost().get('cost_units', 0):>12,} units")

print()
if UNITS_PER_SECOND:
    serial = len(batch_specs) * FIXED_OVERHEAD_S + batch_units / UNITS_PER_SECOND
    batched = FIXED_OVERHEAD_S + batch_units / UNITS_PER_SECOND
    print(f"predicted, {len(batch_specs)} separate runs : {serial / 60:5.1f} min")
    print(f"predicted, one batched run  : {batched / 60:5.1f} min")
    print(f"predicted saving            : {100 * (1 - batched / serial):5.0f}%")
    print()
    print("That prediction assumes batching ONLY amortises the fixed cost. If the")
    print("measured saving is larger, the framework is doing more than that, and")
    print("finding out what is a better use of an hour than tuning a step count.")
else:
    print("No calibration, so there is nothing to predict against. Run Lesson 06.")

print()
print("To run it:  generator.run(batch_specs, OUTPUT_DIR / 'batch')")
print("It is left as a call you make deliberately rather than one this notebook")
print("makes for you, because it is minutes of GPU time.")
''')

# =====================================================================
# 11. torch.compile
# =====================================================================
nb.md("""
## `torch.compile`, and why this course turns it off

`torch.compile` traces your model into a graph, fuses operations that would
otherwise each read and write HBM, and generates specialised kernels with
Triton. For a model dominated by many small elementwise operations, the fusion
can be a large win: a chain of five pointwise ops becomes one kernel and four
round trips to memory disappear.

It costs you three things:

1. **A long first call.** Tracing and compiling take seconds to minutes. This is
   not warm-up in the cuDNN sense — it is a compiler running.
2. **Memory.** The compiler holds intermediate representations, and generated
   kernels can use more workspace than the eager path.
3. **Recompilation on shape change.** Every new input shape can trigger another
   compile. A model with variable resolution or frame count can spend its life
   compiling.

That third point is why `COSMOS3_FACTS.md` §5 records `torch.compile` being
turned **off** for the single-GPU training attempt in Lesson 17, and why this
course leaves it off for short inference runs: the fixed cost is real and a
handful of runs never amortises it.

"Never amortises it" is a claim with a number in it, and you are about to
compute that number for yourself.
""")

nb.predict_run_explain(
    predict=(
        "The next cell compiles a small transformer-style block and measures "
        "three things: the eager median, the compiled median, and the compiled "
        "**first call** (which includes compilation). Predict two numbers: how "
        "many seconds the first compiled call will take, and how many runs it "
        "takes before compiling has paid for itself. Then answer the practical "
        "question: within a 10-run session, does it pay back?"
    ),
    change=(
        "Nothing to edit for the prediction. Afterwards, change `BLOCK_DEPTH` "
        "and re-run — a deeper block has more to fuse. Does the payback point "
        "move in the direction you expected?"
    ),
    explain=(
        "Payback is `compile_cost / (eager_median - compiled_median)`. Explain "
        "what happens to that expression when the denominator is near zero or "
        "negative, and what it means for a model where compilation makes things "
        "slower. Then say what would have to be true of your workload for "
        "`torch.compile` to be worth enabling in this course."
    ),
    hint=(
        "The win comes from fusing memory-bound operations. A block that is "
        "mostly one big matmul has little to fuse, because a matmul is already a "
        "single well-optimised kernel that is compute-bound. A block with many "
        "small elementwise ops between the matmuls has a great deal to fuse.\\n\\n"
        "So before you predict the speedup, look at the block below and count "
        "how much of it is matmul and how much is everything else."
    ),
)

nb.code('''
BLOCK_DEPTH = 4
HIDDEN = 1024
TOKENS = 4096


class Block(torch.nn.Module):
    """Attention + MLP, the shape a diffusion transformer repeats."""

    def __init__(self, hidden):
        super().__init__()
        self.norm1 = torch.nn.LayerNorm(hidden)
        self.qkv = torch.nn.Linear(hidden, 3 * hidden)
        self.proj = torch.nn.Linear(hidden, hidden)
        self.norm2 = torch.nn.LayerNorm(hidden)
        self.fc1 = torch.nn.Linear(hidden, 4 * hidden)
        self.fc2 = torch.nn.Linear(4 * hidden, hidden)

    def forward(self, x):
        h = self.norm1(x)
        q, k, v = self.qkv(h).chunk(3, dim=-1)
        heads = 8
        b, n, c = q.shape
        shape = (b, n, heads, c // heads)
        q = q.view(shape).transpose(1, 2)
        k = k.view(shape).transpose(1, 2)
        v = v.view(shape).transpose(1, 2)
        a = torch.nn.functional.scaled_dot_product_attention(q, k, v)
        a = a.transpose(1, 2).reshape(b, n, c)
        x = x + self.proj(a)
        h = self.norm2(x)
        return x + self.fc2(torch.nn.functional.gelu(self.fc1(h)))


class Stack(torch.nn.Module):
    def __init__(self, depth, hidden):
        super().__init__()
        self.blocks = torch.nn.ModuleList([Block(hidden) for _ in range(depth)])

    def forward(self, x):
        for block in self.blocks:
            x = block(x)
        return x


dtype = torch.bfloat16 if HAS_BF16 else torch.float16
model = Stack(BLOCK_DEPTH, HIDDEN).cuda().to(dtype).eval()
sample = torch.randn(1, TOKENS, HIDDEN, device="cuda", dtype=dtype)

params = sum(p.numel() for p in model.parameters())
print(f"block stack: depth {BLOCK_DEPTH}, hidden {HIDDEN}, {TOKENS} tokens, "
      f"{params / 1e6:.1f}M parameters, dtype {dtype}")

with torch.no_grad():
    eager = cc.benchmark(lambda: model(sample), label="eager",
                         warmup=3, repeats=BENCH_REPEATS)
''')

nb.code('''
compile_findings = {}
try:
    torch.cuda.reset_peak_memory_stats()
    compiled = torch.compile(model)

    with torch.no_grad():
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        compiled(sample)                       # this call includes compilation
        torch.cuda.synchronize()
        first_call_s = time.perf_counter() - t0

        compiled_bench = cc.benchmark(lambda: compiled(sample), label="compiled",
                                      warmup=2, repeats=BENCH_REPEATS)

    compile_peak_gb = torch.cuda.max_memory_allocated() / 1e9
    per_run_saving = eager["median_s"] - compiled_bench["median_s"]
    compile_cost_s = first_call_s - compiled_bench["median_s"]

    compile_findings = {
        "eager_median_s": eager["median_s"],
        "compiled_median_s": compiled_bench["median_s"],
        "first_call_s": first_call_s,
        "compile_cost_s": compile_cost_s,
        "per_run_saving_s": per_run_saving,
        "peak_gb": compile_peak_gb,
    }

    print()
    print(f"eager median            : {eager['median_s'] * 1e3:9.3f} ms")
    print(f"compiled median         : {compiled_bench['median_s'] * 1e3:9.3f} ms")
    print(f"first compiled call     : {first_call_s:9.3f} s   (compilation)")
    print(f"compilation cost        : {compile_cost_s:9.3f} s")
    print(f"saving per run          : {per_run_saving * 1e3:9.3f} ms")
    print(f"peak allocated (compiled): {compile_peak_gb:8.2f} GB")
    print()
    if per_run_saving > 0:
        payback = compile_cost_s / per_run_saving
        compile_findings["payback_runs"] = payback
        print(f"payback point           : {payback:,.0f} runs")
        print(f"pays back within 10 runs: {payback <= 10}")
        print(f"within 100 runs         : {payback <= 100}")
    else:
        compile_findings["payback_runs"] = None
        print("compiled is NOT faster than eager on this workload, so there is no")
        print("payback point at any number of runs. That is a legitimate result and")
        print("it is why 'enable torch.compile' is not universal advice.")
    print()
    print("Now the part that decides it for this course: every generation run is a")
    print("fresh SUBPROCESS. It gets no compilation cache from the last one unless")
    print("you configure one, so a course of short runs pays the compile cost every")
    print("single time and amortises nothing.")
except Exception as exc:
    print(f"torch.compile unavailable or failed: {type(exc).__name__}: {exc}")
    print("That is a finding too — record it and move on.")

FINDINGS["compile"] = compile_findings
''')

# =====================================================================
# 12. Debugging lab
# =====================================================================
nb.md("""
## Debugging lab — the optimisation that made it slower

### Symptom

A colleague reports a win. They were running a batch of 32 items and it used
more memory than they liked, so they dropped the batch size to 2. Per-batch wall
clock fell by a large factor. They wrote it up as a speedup and reduced the
default.

The pipeline is now taking substantially longer to process the same dataset, and
nobody can see why.

Run the cell. It reproduces the reasoning, and the reported "speedup" is real —
that is what makes this a good bug.
""")

nb.code('''
# DELIBERATELY WRONG REASONING. The measurement is fine; the conclusion is not.
with torch.no_grad():
    big_batch = torch.randn(32, TOKENS // 8, HIDDEN, device="cuda", dtype=dtype)
    small_batch = torch.randn(2, TOKENS // 8, HIDDEN, device="cuda", dtype=dtype)

    big = cc.benchmark(lambda: model(big_batch), label="batch 32",
                       warmup=2, repeats=5, quiet=True)
    small = cc.benchmark(lambda: model(small_batch), label="batch 2",
                         warmup=2, repeats=5, quiet=True)

print(f"batch 32: {big['median_s'] * 1e3:9.3f} ms per batch")
print(f"batch  2: {small['median_s'] * 1e3:9.3f} ms per batch")
print(f"'SPEEDUP' from shrinking the batch: "
      f"{big['median_s'] / small['median_s']:.1f}x")
print()
print("Both numbers are correctly measured — warm-up, synchronisation, medians.")
print("The batch of 2 really does finish sooner. So what is wrong?")
''', tags=["teaching-antipattern"])

nb.md("""
### Hypothesis

The measurement is sound and the conclusion is wrong, which is a different and
more interesting failure than the one in Lesson 14.

The mistake is the **unit**. "Milliseconds per batch" is not a cost anybody
pays. What you pay is milliseconds per *item*, and a batch of 2 is doing
one sixteenth of the work.

Underneath that is a hardware fact worth naming. An H100 has a very large number
of streaming multiprocessors. A small batch does not produce enough independent
work to fill them, so most of the device idles while a few SMs do the job. Time
per batch falls; time per item does not fall nearly as much, and below some
batch size it stops falling at all and starts rising.

That is **saturation**, and every GPU workload has a saturation point. Below it
you are paying for silicon you are not using.

Hypothesis: *per-item throughput rises with batch size up to a saturation point,
so the "speedup" is a unit error and the true optimum is at or near saturation —
subject to memory.*

### Diagnostic step

Normalise. Sweep batch size, and plot items per second rather than seconds per
batch.
""")

nb.code('''
BATCH_SIZES = [1, 2, 4, 8, 16, 32, 64]
saturation = []

with torch.no_grad():
    for bs in BATCH_SIZES:
        try:
            batch = torch.randn(bs, TOKENS // 8, HIDDEN, device="cuda", dtype=dtype)
            torch.cuda.reset_peak_memory_stats()
            out = cc.benchmark(lambda: model(batch), label=f"bs{bs}",
                               warmup=2, repeats=5, quiet=True)
            saturation.append({
                "batch": bs,
                "per_batch_s": out["median_s"],
                "per_item_ms": out["median_s"] * 1e3 / bs,
                "items_per_s": bs / out["median_s"],
                "peak_gb": torch.cuda.max_memory_allocated() / 1e9,
            })
            del batch
        except OOM_ERROR:
            print(f"batch {bs}: OOM — that is the memory ceiling, and it is part")
            print("           of the answer, not an obstacle to it")
            break
        finally:
            gc.collect()
            torch.cuda.empty_cache()

FINDINGS["saturation"] = saturation
cc.require(bool(saturation),
           "not a single batch size completed, so there is no curve to read",
           fix="Something else is holding the card, or the block stack above is "
               "larger than this GPU. Check `nvidia-smi`, then reduce HIDDEN or "
               "TOKENS and re-run from the torch.compile section.")

print(f"{'batch':>6} {'per batch':>11} {'per item':>11} {'items/s':>11} "
      f"{'peak GB':>9} {'vs best':>9}")
best = max(row["items_per_s"] for row in saturation)
for row in saturation:
    print(f"{row['batch']:>6} {row['per_batch_s'] * 1e3:>10.2f}m "
          f"{row['per_item_ms']:>10.3f}m {row['items_per_s']:>11,.1f} "
          f"{row['peak_gb']:>9.2f} {row['items_per_s'] / best:>8.0%}")

knee = max(saturation, key=lambda r: r["items_per_s"])
print()
print(f"peak throughput at batch {knee['batch']}: "
      f"{knee['items_per_s']:,.1f} items/s, {knee['peak_gb']:.2f} GB peak")
smallest = saturation[0]
print(f"at batch {smallest['batch']}: {smallest['items_per_s']:,.1f} items/s "
      f"({smallest['items_per_s'] / best:.0%} of peak)")
print()
print("The 'optimisation' moved the pipeline from near the top of that column to")
print("near the bottom of it, and reported the move as a win because it measured")
print("the wrong unit.")

if plt is not None and len(saturation) > 2:
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    ax[0].plot([r["batch"] for r in saturation],
               [r["items_per_s"] for r in saturation], "o-")
    ax[0].set_xscale("log", base=2)
    ax[0].set_xlabel("batch size")
    ax[0].set_ylabel("items / second")
    ax[0].set_title("Throughput saturates")
    ax[1].plot([r["batch"] for r in saturation],
               [r["per_batch_s"] * 1e3 for r in saturation], "o-", color="C3")
    ax[1].set_xscale("log", base=2)
    ax[1].set_xlabel("batch size")
    ax[1].set_ylabel("ms / batch")
    ax[1].set_title("The misleading view")
    plt.tight_layout()
    plt.show()
''')

nb.md("""
### Repair, verification, and the mechanism

**Repair.** Pick the batch size at or just below the throughput knee, subject to
your memory ceiling. Report the decision in items per second and in peak GB, so
the next person can see both constraints that produced it.

**Verification.** Compute the end-to-end time for a realistic job at the
colleague's batch size and at the knee. That is the number that settles the
argument, because it is the number the pipeline actually pays.

**Mechanism, in one paragraph.** A GPU is a throughput machine with a large
number of parallel execution units and a deep memory hierarchy. Work is issued
as thread blocks that get scheduled onto streaming multiprocessors. A batch too
small to produce enough blocks leaves SMs idle, and the kernel's fixed costs —
launch, weight reads that are shared across the batch, tail effects — are
amortised over fewer items. Increasing the batch adds parallel work at almost no
marginal cost until either the SMs are full or memory bandwidth is the limit. At
that point throughput flattens, and beyond it memory pressure makes it fall
again.

**The general lesson.** A ratio without a denominator you have named is not a
result. "Twice as fast" — per what?
""")

nb.code('''
JOB_ITEMS = 1024
by_batch = {row["batch"]: row for row in saturation}
colleague = by_batch.get(2) or saturation[0]

print(f"end-to-end time for a {JOB_ITEMS}-item job:")
for row in saturation:
    total = JOB_ITEMS / row["items_per_s"]
    marker = ""
    if row["batch"] == colleague["batch"]:
        marker = "  <- the 'optimised' setting"
    if row["batch"] == knee["batch"]:
        marker += "  <- the throughput knee"
    print(f"  batch {row['batch']:>3}: {total:8.1f} s "
          f"({row['peak_gb']:5.2f} GB peak){marker}")

cost = JOB_ITEMS / colleague["items_per_s"] - JOB_ITEMS / knee["items_per_s"]
print()
print(f"the 'optimisation' costs {cost:,.1f} s per {JOB_ITEMS} items "
      f"({100 * cost / (JOB_ITEMS / knee['items_per_s']):.0f}% longer)")
print(f"and saves {knee['peak_gb'] - colleague['peak_gb']:.2f} GB of peak memory.")
print()
print("State it as the trade it is: seconds bought with gigabytes. If you have")
print("the gigabytes, it is a bad trade. If you do not, it is the only trade")
print("available and it is worth taking — but call it what it is.")

FINDINGS["debugging_lab"] = {
    "knee_batch": knee["batch"], "knee_items_per_s": knee["items_per_s"],
    "regressed_batch": colleague["batch"],
    "regressed_items_per_s": colleague["items_per_s"],
    "job_items": JOB_ITEMS, "cost_s": cost,
}
log.record(label="batch_saturation", model=MODEL, mode=MODE, **FINDINGS["debugging_lab"])

for _name in ("big_batch", "small_batch"):
    globals().pop(_name, None)
gc.collect()
torch.cuda.empty_cache()
''')

# =====================================================================
# 13. Exercises
# =====================================================================
nb.md("""
## Exercises

Three. The first is a controlled precision comparison, the second builds the
planner this module has been leading up to, and the third asks you to defend a
recommendation against the objection that will actually be made.
""")

nb.exercise(
    "foundation",
    "The same workload at three precisions",
    goal=(
        "Tabulate time, peak memory and a numerical-quality figure for the same "
        "generation-shaped workload at three precisions, and say which one you "
        "would ship."
    ),
    instructions=(
        "1. Use the `Stack` model already defined above. Run it at float32, "
        "float16 and bfloat16 (substitute another pair if your card lacks one).\n"
        "2. For each: median time over at least seven repeats after warm-up, "
        "peak allocated VRAM with `reset_peak_memory_stats()` first, and a "
        "**quality** figure — the maximum absolute and relative difference "
        "against the float32 output on identical input. That is a real quality "
        "metric for a numerical change, unlike an image proxy.\n"
        "3. Check whether any output contains a NaN or an Inf. A fast wrong "
        "answer is not a fast answer.\n"
        "4. Separately, find out whether your framework checkout exposes a "
        "precision flag: grep the `--help` output captured earlier, or run it "
        "yourself. Report what you find — including 'there is no such flag', "
        "which is a perfectly good answer.\n"
        "5. Run `check_precision_table()` and then write two sentences on which "
        "precision you would use for generation and why, with your numbers in "
        "them."
    ),
    success=(
        "`check_precision_table()` passes, and your two sentences cite a time, "
        "a memory figure and an error figure that you measured."
    ),
    starter='''
PRECISION_ROWS = []


def measure_precision(name, dtype, reference=None):
    """Return one row: time, peak memory, and error against the reference."""
    raise NotImplementedError


def check_precision_table(rows=None):
    """Refuse a table that does not support a decision."""
    rows = rows if rows is not None else PRECISION_ROWS
    passed = []

    assert len(rows) >= 3, f"only {len(rows)} precisions; the exercise asks for three"
    for row in rows:
        for key in ("name", "median_s", "peak_gb", "max_abs_err",
                    "max_rel_err", "has_nan", "repeats"):
            assert key in row, f"row {row.get('name', '?')} is missing {key!r}"
        assert row["repeats"] >= 7, f"{row['name']}: only {row['repeats']} repeats"
    passed.append(f"{len(rows)} precisions, each with >= 7 repeats")

    ref = [r for r in rows if r["name"].startswith("float32")]
    assert ref, "no float32 reference row"
    assert ref[0]["max_abs_err"] == 0.0, "the reference must have zero error against itself"
    passed.append("float32 reference present and self-consistent")

    assert not any(r["has_nan"] for r in rows), \\
        "one precision produced NaN — report it rather than tabulating it as fast"
    passed.append("no NaN or Inf in any output")

    low = [r for r in rows if not r["name"].startswith("float32")]
    assert all(r["peak_gb"] <= ref[0]["peak_gb"] * 1.05 for r in low), \\
        "a 16-bit path used more memory than float32 — explain that before believing it"
    passed.append("reduced precision did not increase peak memory")

    for item in passed:
        print(f"  PASS  {item}")
    return passed
''',
    hints=[
        "Build the reference once in float32 and keep the tensor; every other "
        "row compares against it. Cast the *input* as well as the model, or you "
        "are measuring a cast in the middle of your forward pass rather than a "
        "precision change.\\n\\n"
        "Relative error is the informative one. An absolute error of 0.01 means "
        "nothing until you know whether the activations are order 1 or order "
        "1000, and in a residual stack they grow with depth.",
    ],
    solution_ref="solutions/15_solutions.ipynb",
)

nb.exercise(
    "applied",
    "optimise_for(time_budget_s, min_quality)",
    goal=(
        "Write a planner that searches the knob space using your own calibration "
        "and returns a configuration, with an automated test that its prediction "
        "matches a real run within a tolerance you state."
    ),
    instructions=(
        "1. Implement `optimise_for(time_budget_s, min_quality, model=MODEL)` "
        "returning a dict with `resolution`, `num_frames`, `num_steps`, "
        "`guidance`, `predicted_seconds`, `predicted_quality` and `rationale`.\n"
        "2. Define `min_quality` yourself on a 0–1 scale, and **write down what "
        "it means** before you use it. A defensible construction: normalise "
        "`num_steps` against a knee you measured, resolution against the tier "
        "you consider full quality, and combine them explicitly. An "
        "indefensible one: invent weights and never say so.\n"
        "3. Respect the real constraints — `cc.MAX_FRAMES_BY_TIER`, "
        "`cc.MODEL_TIERS[model]['max_resolution_tier']`, and the memory ceiling "
        "you measured in Lesson 14.\n"
        "4. Use your Lesson 06 calibration for time. If you have none, the "
        "function must **say so and refuse**, not guess.\n"
        "5. Run `check_optimise_for()`. Then run the configuration it returns "
        "for a real budget and report the prediction error as a percentage. "
        "State your tolerance before you look.\n"
        "6. If the real run misses the budget, report the miss. Do not adjust "
        "the budget to fit the result."
    ),
    success=(
        "`check_optimise_for()` passes, and you have one real run whose measured "
        "time is inside the tolerance you stated in advance — or a written "
        "account of why it is not."
    ),
    starter='''
def quality_score(resolution, num_frames, num_steps, guidance):
    """Your quality model, 0-1. Document the assumptions in this docstring."""
    raise NotImplementedError


def optimise_for(time_budget_s, min_quality, model=None):
    """Best configuration predicted to fit the budget at or above min_quality."""
    raise NotImplementedError


def check_optimise_for():
    """Automated check. Run it before you believe your own planner."""
    passed = []
    if not UNITS_PER_SECOND:
        print("  ----  no calibration, so the planner cannot be checked. Run "
              "Lesson 06 or enable RUN_GENERATION above.")
        return []

    plans = {b: optimise_for(b, 0.5) for b in (60, 300, 1800)}
    for budget, plan in plans.items():
        for key in ("resolution", "num_frames", "num_steps", "guidance",
                    "predicted_seconds", "predicted_quality", "rationale"):
            assert key in plan, f"the {budget}s plan is missing {key!r}"
        assert plan["predicted_seconds"] <= budget, \\
            f"the {budget}s plan predicts {plan['predicted_seconds']:.0f}s"
        assert plan["predicted_quality"] >= 0.5, \\
            f"the {budget}s plan is below the quality floor it was given"
    passed.append("every plan fits its budget and clears its quality floor")

    def cost_of(plan):
        return cc.estimate_generation_cost(
            resolution=plan["resolution"], num_frames=plan["num_frames"],
            num_steps=plan["num_steps"])["cost_units"]

    units = {b: cost_of(p) for b, p in plans.items()}
    # Non-decreasing, not strictly increasing: on a fast machine every candidate
    # may fit every budget, and returning the same (largest) plan for all three
    # is then correct. A checker that failed there would be punishing a right
    # answer for the hardware it ran on.
    assert units[1800] >= units[300] >= units[60], \\
        "more budget must never buy a smaller job"
    passed.append(f"monotonic in budget ({units[60]:,} -> {units[1800]:,} units)")

    tiny = optimise_for(0.5, 0.5)
    assert tiny.get("predicted_seconds") is not None, \\
        "an impossible budget must still return a plan with a stated prediction " \\
        "(or raise on purpose) — silently returning something that does not fit " \\
        "is the one unacceptable answer"
    assert cost_of(tiny) <= units[1800], \\
        "a half-second budget returned a job at least as large as the 30-minute one"
    passed.append("an impossible budget is handled deliberately")

    strict = optimise_for(1800, 0.9)
    loose = optimise_for(1800, 0.2)
    assert strict["predicted_quality"] >= loose["predicted_quality"], \\
        "raising the quality floor must not lower the delivered quality"
    passed.append("respects the quality floor as a floor")

    big = optimise_for(1800, 0.5)
    ceiling = cc.MAX_FRAMES_BY_TIER[big["resolution"]]
    assert big["num_frames"] <= ceiling, f"exceeds the {big['resolution']} ceiling"
    tier_max = int(cc.MODEL_TIERS[MODEL]["max_resolution_tier"])
    assert int(big["resolution"]) <= tier_max, f"{MODEL} tops out at {tier_max}p"
    passed.append("respects the frame and resolution ceilings")

    assert len(str(plans[300]["rationale"])) > 60, \\
        "the rationale must be a sentence someone could argue with"
    passed.append("every plan explains itself")

    for item in passed:
        print(f"  PASS  {item}")
    return passed
''',
    hints=[
        "The search space is small — four tiers, a handful of frame counts, a "
        "handful of step counts, guidance on or off. Enumerate it, score every "
        "candidate, discard the ones that miss the budget or the quality floor, "
        "and take the best by a rule you have written down. Do not try to invert "
        "the cost formula.\\n\\n"
        "The hardest part is not the search, it is `quality_score`. If you "
        "cannot defend it, say so in the `rationale` string — a planner that "
        "reports the weakness of its own objective is more useful than one that "
        "hides it.",
    ],
    solution_ref="solutions/15_solutions.ipynb",
)

nb.exercise(
    "challenge",
    "A full optimisation study, defended against the obvious objection",
    goal=(
        "Pick a target output specification, find the fastest configuration that "
        "meets a stated quality bar, document the search, and defend the result "
        "against the charge that you overfitted to one prompt."
    ),
    instructions=(
        "1. **State the target** before you measure anything: output spec (frames, "
        "resolution, duration), quality bar, and time budget. Write it down "
        "first, because a target chosen after seeing the results is not a target.\n"
        "2. **Search.** Coarse sweep first to find the region, fine sweep second. "
        "Record every configuration you tried, including the ones you discarded "
        "and why — a search you cannot retrace is not a study.\n"
        "3. **Measure properly.** Lesson 14's rules apply in full: warm-up, "
        "synchronisation, medians, IQRs. A configuration measured once is a "
        "candidate, not a result.\n"
        "4. **Defend against overfitting.** This is the point of the exercise. "
        "Your winner was found on some prompt; validate it on at least three "
        "prompts you did not use during the search, and at least two seeds each. "
        "Report the variance. If the winner does not survive, say so and report "
        "the runner-up that does.\n"
        "5. **Name the failure mode.** Every configuration fails somehow. Find "
        "and document the case where yours produces something you would not "
        "ship.\n"
        "6. Save `outputs/15/optimisation_study.json` and write "
        "`outputs/15/how_to_fit_it.md` — a one-page reference for your machine "
        "that a colleague could act on without re-running anything.\n"
        "7. Run `check_study()`."
    ),
    success=(
        "`check_study()` passes: a stated target fixed in advance, at least "
        "eight searched configurations, held-out validation on at least three "
        "unseen prompts with variance reported, a documented failure mode, and "
        "a reference sheet on disk."
    ),
    starter='''
STUDY_PATH = OUTPUT_DIR / "optimisation_study.json"
FIT_SHEET = OUTPUT_DIR / "how_to_fit_it.md"

TARGET = {
    # Fill this in FIRST, before any measurement.
    "output_spec": None,        # e.g. "61 frames at 480p, 16:9, 24 fps"
    "quality_bar": None,        # what counts as good enough, in words
    "time_budget_s": None,
    "stated_at": None,          # timestamp, so the order is on the record
}


def run_study():
    """Coarse sweep, fine sweep, held-out validation. Return the study dict."""
    raise NotImplementedError


def check_study(path=STUDY_PATH):
    """A study that cannot answer the overfitting objection does not pass."""
    passed = []
    study = json.loads(Path(path).read_text())

    for key in ("target", "searched", "winner", "validation", "failure_mode",
                "machine", "methodology"):
        assert key in study, f"missing top-level key {key!r}"
    for key in ("output_spec", "quality_bar", "time_budget_s", "stated_at"):
        assert study["target"].get(key), f"target is missing {key!r}"
    passed.append("target was stated up front and is on the record")

    assert len(study["searched"]) >= 8, \\
        f"only {len(study['searched'])} configurations searched"
    assert all("discarded_because" in c or c.get("kept") for c in study["searched"]), \\
        "every discarded configuration needs a reason"
    passed.append(f"{len(study['searched'])} configurations, each accounted for")

    val = study["validation"]
    prompts = {v["prompt_id"] for v in val}
    assert len(prompts) >= 3, f"validated on only {len(prompts)} prompt(s)"
    assert all(len(v["seeds"]) >= 2 for v in val), "at least two seeds per prompt"
    assert all("variance" in v or "spread" in v for v in val), \\
        "report the variance, not just the mean"
    passed.append(f"held out {len(prompts)} unseen prompts, >= 2 seeds each")

    assert len(str(study["failure_mode"])) > 80, \\
        "name a specific case where the winner produces something you would not ship"
    passed.append("failure mode documented")

    winner = study["winner"]
    assert winner.get("n", 0) >= 5 and "iqr_s" in winner, \\
        "the winner needs a median over >= 5 runs and an IQR"
    assert winner["median_s"] <= study["target"]["time_budget_s"], \\
        "the winner does not meet the budget it was selected against"
    passed.append(f"winner measured over n={winner['n']} with an IQR")

    assert FIT_SHEET.exists() and FIT_SHEET.stat().st_size > 500, \\
        "how_to_fit_it.md is missing or too short to be useful"
    passed.append(f"reference sheet written ({FIT_SHEET.stat().st_size} bytes)")

    for item in passed:
        print(f"  PASS  {item}")
    return passed
''',
    hints=[
        "The overfitting objection is not rhetorical and it is not cheap to "
        "answer. A step count that looks sufficient on a static kitchen scene "
        "can be visibly insufficient on fast motion, because low-step sampling "
        "loses temporal detail first. Choose held-out prompts that differ along "
        "an axis you expect to matter — motion, scene complexity, lighting — "
        "rather than three variations of the same scene.\\n\\n"
        "If your winner survives held-out validation unchanged, be suspicious: "
        "either your quality bar is loose enough that everything passes, or your "
        "held-out prompts were not different enough. Both are worth saying.",
    ],
    solution_ref="solutions/15_solutions.ipynb",
)

# =====================================================================
# 14. Assessment
# =====================================================================
nb.md("""
## Assessment and reflection

### Knowledge check

1. bfloat16 and float16 are both 16 bits. Where does each spend them, and which
   failure does each one make more likely?
2. Why does float16 training need loss scaling? What exactly does the scaling
   prevent, and why does bfloat16 not need it?
3. Your two float32 matmul rows differed. What is TF32 and why is a number
   labelled float32 not necessarily float32?
4. What are E4M3 and E5M2, and why does PyTorch make you pass explicit scales to
   `_scaled_mm` instead of letting you write `a @ b`?
5. Explain FlashAttention to somebody who knows what attention is but not what
   SRAM is. Which resource does it save first?
6. Attention memory went from $O(N^2)$ to $O(N)$. Which of your measured columns
   demonstrates that, and at which N did the naive version stop being viable?
7. What can `--parallelism-preset` do at world size 1, and what can it not do?
8. Rank `num_steps`, resolution, `num_frames` and guidance by cost. Now rank
   them by cost saved per unit of quality lost. Why are the two rankings
   different?
9. Your measured knob ranking disagreed with the cost model somewhere. Name a
   concrete mechanism that would produce that disagreement.
10. Give three things an edge-density quality proxy cannot see, and say which of
    them would worry you most in synthetic training data.
11. `torch.compile` made your workload faster per run and slower overall for a
    ten-run session. Write the payback expression and say what makes it large.
12. Why does the batch-size regression in the debugging lab produce a *correctly
    measured* speedup?

### Practical completion test

1. Produce the format table and explain one row of it from the bit layout.
2. Measure matmul throughput at every precision your card supports.
3. Show attention memory against sequence length for two implementations and
   identify where one fails.
4. Produce a ranked knob table — predicted, and measured if you enabled
   generation.
5. Compute `torch.compile`'s payback point on your workload.
6. Find your batch-size saturation point and state the end-to-end cost of being
   below it.
""")

nb.code('''
def lesson_15_complete():
    """Check the artefacts, and the numbers that show the ideas landed."""
    passed, notes = [], []

    formats = FINDINGS["formats"]
    assert "float32" in formats and "float16" in formats, "format table incomplete"
    if "bfloat16" in formats:
        assert formats["bfloat16"]["exponent_bits"] == formats["float32"]["exponent_bits"], \\
            "bfloat16 should have float32's exponent width; check field_widths()"
        passed.append(f"bfloat16 keeps float32's {formats['float32']['exponent_bits']} "
                      f"exponent bits and drops to "
                      f"{formats['bfloat16']['mantissa_bits']} mantissa bits")

    survival = FINDINGS["gradient_survival"]
    unscaled = survival.get("float16, no loss scaling")
    scaled = next((v for k, v in survival.items() if "loss scale" in k), None)
    assert unscaled is not None and scaled is not None, "run the survival cell"
    assert scaled > unscaled, "loss scaling should rescue gradients, not lose them"
    passed.append(f"loss scaling measured: {unscaled:.1%} of gradients survive "
                  f"float16 unscaled, {scaled:.1%} scaled")

    prec = FINDINGS["precision_matmul"]
    assert len(prec) >= 3, f"only {len(prec)} precision(s) measured"
    fastest = max(prec.items(), key=lambda kv: kv[1]["tflops"])
    passed.append(f"{len(prec)} precisions measured; fastest here is "
                  f"{fastest[0]} at {fastest[1]['tflops']:,.0f} TFLOP/s")

    scaling = FINDINGS["attention_scaling"]
    largest = scaling[-1]
    if largest["naive_gb"] and largest["fused_gb"]:
        ratio = largest["naive_gb"] / largest["fused_gb"]
        passed.append(f"at N={largest['n']}, naive attention used {ratio:.1f}x the "
                      f"memory of the fused kernel")
    else:
        passed.append(f"naive attention ran out of memory at N={largest['n']} "
                      f"where the fused kernel did not")

    sat = FINDINGS["saturation"]
    lab = FINDINGS["debugging_lab"]
    assert len(sat) >= 4, "sweep more batch sizes"
    assert lab["knee_items_per_s"] > lab["regressed_items_per_s"], \\
        "the knee should out-throughput the regressed setting"
    passed.append(f"saturation found at batch {lab['knee_batch']}; the "
                  f"'optimisation' cost {lab['cost_s']:,.0f} s per "
                  f"{lab['job_items']} items")

    comp = FINDINGS.get("compile") or {}
    if comp.get("payback_runs"):
        passed.append(f"torch.compile payback at {comp['payback_runs']:,.0f} runs "
                      f"(within 10: {comp['payback_runs'] <= 10})")
    elif comp:
        passed.append("torch.compile measured and did not pay back on this "
                      "workload — a legitimate result")
    else:
        notes.append("torch.compile was not measurable in this environment")

    if FINDINGS.get("measured_knob_ranking"):
        passed.append(f"knob ranking measured over "
                      f"{len(FINDINGS['measured_knob_ranking'])} real runs")
    else:
        notes.append("knob ranking is modelled only — enable RUN_GENERATION or "
                     "run Lesson 06 to measure it")

    study = OUTPUT_DIR / "optimisation_study.json"
    if study.exists():
        passed.append(f"optimisation study written ({study.stat().st_size} bytes)")
    else:
        notes.append("outputs/15/optimisation_study.json not written yet — that "
                     "is the challenge exercise")

    for item in passed:
        print(f"  PASS  {item}")
    for item in notes:
        print(f"  ----  {item}")
    return passed, notes


_ = lesson_15_complete()

FINDINGS_PATH = OUTPUT_DIR / "findings.json"
FINDINGS_PATH.write_text(json.dumps(FINDINGS, indent=2, default=str) + "\\n")
print(f"\\nwrote {FINDINGS_PATH}")
''')

nb.md("""
### Summary

- A float is sign, exponent and mantissa. Exponent buys range, mantissa buys
  precision, and a 16-bit format has to choose. bfloat16 keeps float32's
  exponent; float16 keeps more mantissa.
- Loss scaling exists because float16's exponent cannot reach gradient
  magnitudes. You counted the gradients each format loses.
- float8 on Hopper is two formats (E4M3, E5M2) and a scaling discipline, not a
  dtype swap. `torch._scaled_mm` takes explicit scales for that reason.
- TF32 means a number labelled float32 may not be float32. Know whether it is on.
- FlashAttention tiles attention through SRAM and never materialises the
  $N \\times N$ score matrix. It is a memory result first — you measured the
  point at which the naive version stops fitting.
- On Hopper the framework selects `flash-attn-3-nv` (a documented fact); which
  SDPA backends your own PyTorch can run is something you measured.
- Parallelism presets configure how work splits across ranks. At world size 1
  there is little left for them to do, and "no measurable difference" is a
  legitimate finding to report.
- Knob costs: steps linear, resolution quadratic in the linear scale, frames
  linear, guidance a step function of roughly two. Predicted ranking and
  measured ranking are different things and the gap is the interesting part.
- Quality proxies are weak. They are a filter that tells you which handful of
  outputs to look at, not a substitute for looking.
- The largest cheap win is not paying a fixed cost repeatedly. Batch, and cache.
- `torch.compile` costs a long first call and pays back after a computable
  number of runs. For a course of short subprocess runs, that number is never
  reached.
- Below saturation a GPU is idle, and a correctly measured per-batch speedup can
  be a large per-item regression.

### Common misconceptions

| Belief | Correction |
|---|---|
| "bfloat16 is just a worse float16" | It has fewer mantissa bits and float32's full exponent. Different trade, chosen for gradients. |
| "float16 is fine, loss scaling is legacy" | Your own cell counted how many gradient-sized values it flushes to zero. |
| "float8 is a dtype you cast to" | It is a scaling discipline with a dtype attached. Casting without scaling produces garbage or overflow. |
| "float32 in PyTorch means IEEE float32 arithmetic" | Not for matmuls with TF32 enabled, which is a common default. |
| "FlashAttention is a speed optimisation" | It is a memory optimisation that is also fast, because attention at these sizes is bandwidth-bound. |
| "The preset matters on one GPU" | It configures cross-rank splitting. Measure it; expect little, and report what you get. |
| "Halving the resolution halves the cost" | Tokens go as area, so it is closer to a quarter. |
| "Fewer steps will fix my OOM" | Steps are a time lever. Peak memory is set by geometry. |
| "The quality proxy went up, so it is better" | Edge density rises for sharpness and for noise alike. |
| "`torch.compile` is free speed" | It is a compiler. Fixed cost, memory cost, and recompilation on shape change. |
| "Smaller batches are faster" | Per batch, yes. Per item, usually much worse. Name your denominator. |

### Suggested extensions

- Re-run the attention sweep with a causal mask and with a longer head
  dimension. The memory story is unchanged; the speed story may not be.
- Measure the parallelism presets end to end on a real generation, five runs
  each, and publish the medians and IQRs. A null result here is genuinely useful
  and nobody has published one for this framework.
- Set a compilation cache directory and re-run the compile cell in a fresh
  subprocess twice. Does the second process skip the compile? That single
  measurement decides whether compilation is viable for subprocess-per-run
  workflows.
- Take your `optimise_for` planner and run its output for ten different budgets.
  Plot predicted against measured. Systematic bias is a calibration problem;
  scatter is a variance problem, and they have different fixes.

### Mastery checklist

- [ ] I can draw the bit layout of float32, float16 and bfloat16 and say what
      each field buys.
- [ ] I measured how many gradients each 16-bit format loses.
- [ ] I know which precisions my card supports and how fast each one is here.
- [ ] I can explain FlashAttention and I measured its memory advantage.
- [ ] I know which attention backends my PyTorch can run.
- [ ] I have a ranked knob table for my machine and I know where the cost model
      is wrong.
- [ ] I can state what my quality proxy cannot see.
- [ ] I computed `torch.compile`'s payback point rather than guessing it.
- [ ] I found my saturation point and can state the cost of being below it.
- [ ] I have a configuration recommendation I would defend against the
      overfitting objection.

### Next

Module 5 uses everything here as its foundation. The single-GPU post-training
argument in Lesson 17 is a **memory** argument, and it only lands for somebody
who has measured memory rather than read about it. Lesson 16 starts with the
data, which is where most of the real work in post-training turns out to be.
""")

nb.md("""
## Free what you allocated, and say why

You built several large tensors, a compiled model and a block stack, and you
swept batch size until the device complained. All of that is sitting in this
kernel's allocator pool.

Module 5 launches training subprocesses that want the whole card, and a compiled
model in particular holds more than it looks like it does — generated kernels,
graph state, and the guards that decide whether to recompile. Drop it explicitly
rather than hoping garbage collection gets there.
""")

nb.code('''
for name in ("a32", "b32", "a16", "b16", "abf", "bbf", "a8", "b8",
             "model", "compiled", "sample", "batch", "big_batch", "small_batch"):
    globals().pop(name, None)

if plt is not None:
    plt.close("all")
gc.collect()
torch.cuda.empty_cache()

free_b, total_b = torch.cuda.mem_get_info()
print(f"device: {free_b / 1e9:.1f} GB free of {total_b / 1e9:.1f} GB")
print(f"this kernel holds {torch.cuda.memory_allocated() / 1e9:.2f} GB allocated, "
      f"{torch.cuda.memory_reserved() / 1e9:.2f} GB reserved")
print()
if free_b / total_b < 0.8:
    print("Under 80% free while this kernel holds almost nothing. Something else")
    print("owns the card — check `nvidia-smi` before starting Module 5, which")
    print("needs all of it.")
else:
    print("The card is clear.")

print(f"\\nfindings : {OUTPUT_DIR / 'findings.json'}")
print(f"measurements : {log.path}")
print("\\nBoth are yours, from your machine. Nothing in this notebook told you a")
print("number it had not measured — which is the only reason the numbers are")
print("worth anything.")
''')

nb.md(FOOTER_MD)

nb.write(ROOT / "15_optimisation.ipynb")
