"""Build solutions/08_solutions.ipynb — reference answers for Lesson 08."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("08", "Controlled generation (transfer)",
                      lesson_file="08_generation_control.ipynb")

nb.header(
    "Transfer is `video2video` plus a control hint — not a mode of its own — and Lesson "
    "08's exercises are all about making that pairing measurable. The foundation "
    "exercise compares two hints under **one shared prompt**, because the shipped "
    "per-hint prompts differ and would confound the comparison. The applied one builds a "
    "control map from your own footage, where the silent failures are frame counts and "
    "compression. The challenge one runs an augmentation set through an automated gate "
    "that returns *reasons*, and then argues about the thresholds."
)

nb.callout(
    "warning",
    "**This lesson needs Cosmos3-Nano.** `COSMOS3_FACTS.md` §1: Edge has "
    "`supports_transfer: false`, so there is no cheaper tier to fall back to. Generation "
    "is therefore off by default here and the download is opt-in. Everything that is not "
    "a generation — control-map construction, frame-count preconditions, the metrics, "
    "the gate and the reporting — runs and is verified against synthetic videos built in "
    "this notebook.",
)

nb.prelude(
    "The lesson's configuration, its video probes, its frame metrics and its "
    "`transfer_spec` builder, reproduced unchanged so the exercises read against the "
    "same names."
)
nb.code(setup_cell("08"))

nb.code('''
import json
import shutil
import subprocess
import threading
import time

import numpy as np

from cosmos_course.measure import MeasurementLog
from cosmos_course.models import Generator

# Lesson 08 overrides the setup cell's MODEL: only Nano supports transfer.
MODEL = "Cosmos3-Nano"
ALLOW_NANO_DOWNLOAD = False       # ~35 GB; opt in deliberately
generator = cc.Generator(checkpoint=MODEL)
framework_problems = generator.check(verbose=False)

if MODE == "full":
    CONTROL_FRAMES, N_STEPS = None, 35
else:
    CONTROL_FRAMES, N_STEPS = 33, 10
RES = "480"
RUN_TIMEOUT = 5400 if MODE == "full" else 2400
RUN = (ALLOW_NANO_DOWNLOAD and not framework_problems
       and DEVICE.startswith("cuda"))

CALIB_PATH = cc.OUTPUT_ROOT / "06" / "calibration.json"
CALIB = json.loads(CALIB_PATH.read_text()) if CALIB_PATH.exists() else {}
log = MeasurementLog(OUTPUT_DIR / "measurements.jsonl")
RUNS = {}


def predict_seconds(resolution, num_frames, num_steps, aspect_ratio="16,9"):
    ups = CALIB.get("units_per_second")
    if not ups:
        return None
    units = cc.estimate_generation_cost(resolution=resolution, num_frames=num_frames,
                                        num_steps=num_steps,
                                        aspect_ratio=aspect_ratio)["cost_units"]
    return (CALIB.get("fixed_overhead_s") or 0.0) + units / ups


print(f"model  : {MODEL} (Edge cannot do transfer — MODEL_TIERS says "
      f"supports_transfer={cc.MODEL_TIERS['Cosmos3-Edge']['supports_transfer']})")
print(f"RUN    : {RUN}")
print(f"ffmpeg : {'yes' if shutil.which('ffmpeg') else 'NO — control building needs it'}")
print(f"ffprobe: {'yes' if shutil.which('ffprobe') else 'no (frame counts fall back to decoding)'}")
''')

nb.code('''
class GpuSampler:
    """Poll device-wide VRAM on a thread; report the peak, in GB."""

    def __init__(self, interval=1.0, index=0):
        self.interval, self.index = interval, index
        self.samples = []
        self._stop = threading.Event()
        self._thread = None

    def _read_gb(self):
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except Exception:
            return None

    def _loop(self):
        while not self._stop.wait(self.interval):
            value = self._read_gb()
            if value is not None:
                self.samples.append(value)

    def __enter__(self):
        self.samples = [self._read_gb() or 0.0]
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        return False

    @property
    def peak_gb(self):
        return max(self.samples) if self.samples else None


def compact(obj):
    if isinstance(obj, (str, Path)):
        obj = json.loads(Path(obj).read_text())
    return json.dumps(obj, ensure_ascii=True, separators=(",", ":"))


def run_and_verify(spec, subdir, *, label=None, timeout=None):
    """Predict, run, sample VRAM, verify by content, record."""
    label = label or (spec.get("name") if isinstance(spec, dict) else spec.name)
    if not RUN:
        print(f"skipped {label!r}: generation is disabled "
              f"(ALLOW_NANO_DOWNLOAD is False, or no GPU)")
        return None
    body = spec if isinstance(spec, dict) else spec.to_dict()
    for problem in cc.validate_spec(body, strict=False):
        print("  spec warning:", problem)
    predicted = predict_seconds(body.get("resolution", RES),
                                body.get("num_frames") or 33,
                                body.get("num_steps") or N_STEPS,
                                body.get("aspect_ratio", "16,9"))
    with GpuSampler() as sampler:
        with cc.timer(label, track_memory=False) as timing:
            result = generator.run(spec, OUTPUT_DIR / subdir,
                                   seed=int(body.get("seed") or 0),
                                   timeout=timeout or RUN_TIMEOUT)
    RUNS[label] = {"seconds": timing.seconds, "peak_gb": sampler.peak_gb,
                   "predicted_s": predicted, "result": result}
    log.record(label=label, model=MODEL, mode=MODE,
               **{k: v for k, v in RUNS[label].items() if k != "result"})
    cc.verify_result(result)
    return result


print("harness ready")
''')

nb.code('''
def probe_video(path):
    """Frames, fps and pixel geometry of a video file, however we can get them."""
    path = Path(path)
    out = {"file": path.name, "frames": None, "fps": None, "width": None, "height": None}
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        try:
            raw = subprocess.run(
                [ffprobe, "-v", "error", "-select_streams", "v:0", "-count_frames",
                 "-show_entries", "stream=width,height,nb_read_frames,r_frame_rate",
                 "-of", "json", str(path)],
                capture_output=True, text=True, timeout=300, check=True).stdout
            stream = json.loads(raw)["streams"][0]
            num, _, den = stream.get("r_frame_rate", "0/1").partition("/")
            out.update(frames=int(stream.get("nb_read_frames", 0)),
                       width=stream.get("width"), height=stream.get("height"),
                       fps=round(float(num) / float(den or 1), 3))
            return out
        except Exception:
            pass
    try:
        import imageio.v3 as iio
        frames = sum(1 for _ in iio.imiter(path))
        first = next(iter(iio.imiter(path)))
        out.update(frames=frames, height=first.shape[0], width=first.shape[1])
    except Exception as exc:
        out["error"] = f"{type(exc).__name__}: {exc}"
    return out


def read_frames(path, count=8):
    """Sample up to `count` grayscale frames, evenly spaced, as float arrays."""
    frames = []
    try:
        import imageio.v3 as iio
        allf = []
        for i, frame in enumerate(iio.imiter(path)):
            allf.append(frame)
            if i > 400:
                break
        if allf:
            step = max(1, len(allf) // count)
            frames = [np.asarray(f).astype(np.float64) for f in allf[::step][:count]]
    except Exception:
        pass
    return [(f.mean(axis=2) if f.ndim == 3 else f) for f in frames]


def resize_to(a, shape=(90, 160)):
    from PIL import Image
    return np.asarray(Image.fromarray(a.astype(np.uint8)).resize((shape[1], shape[0])),
                      dtype=np.float64)


def correlate(a, b):
    x, y = a.ravel(), b.ravel()
    if x.std() < 1e-6 or y.std() < 1e-6:
        return float("nan")
    return float(((x - x.mean()) * (y - y.mean())).mean() / (x.std() * y.std()))


def gradient_magnitude(a):
    gy, gx = np.gradient(a)
    return np.hypot(gx, gy)


def structure_retention(video_path, control_path, count=6):
    """Gradient-map correlation, output against control. Biased toward `edge`."""
    v = [resize_to(f) for f in read_frames(video_path, count)]
    c = [resize_to(f) for f in read_frames(control_path, count)]
    n = min(len(v), len(c))
    values = [correlate(gradient_magnitude(v[i]), gradient_magnitude(c[i]))
              for i in range(n)]
    values = [x for x in values if x == x]
    return float(np.mean(values)) if values else float("nan")


def motion_profile(path, count=12):
    frames = [resize_to(f) for f in read_frames(path, count)]
    return (np.array([np.abs(frames[i + 1] - frames[i]).mean()
                      for i in range(len(frames) - 1)])
            if len(frames) > 1 else np.array([]))


def motion_agreement(video_path, control_path):
    a, b = motion_profile(video_path), motion_profile(control_path)
    n = min(len(a), len(b))
    return correlate(a[:n], b[:n]) if n >= 3 else float("nan")


print("metrics ready")
''')

nb.code('''
CONTROL_ASSETS = ["control_edge", "control_blur", "control_depth", "control_seg",
                  "control_wsm"]
controls = {}
for name in CONTROL_ASSETS:
    path = cc.asset_or_none(name)
    if path is not None:
        controls[name] = {"path": path, **probe_video(path)}
print(f"{len(controls)} control video(s) on disk: "
      f"{sorted(k.replace('control_', '') for k in controls) or 'none'}")


def trim_control(src, n_frames, out_dir=None):
    """Return a shortened copy of a control video. Cached; needs ffmpeg."""
    src = Path(src)
    if not n_frames:
        return src
    out_dir = Path(out_dir or OUTPUT_DIR / "controls")
    out_dir.mkdir(parents=True, exist_ok=True)
    dst = out_dir / f"{src.stem}_{n_frames}f.mp4"
    if dst.exists() and dst.stat().st_size > 0:
        return dst
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg is None:
        return src
    subprocess.run(
        [ffmpeg, "-y", "-loglevel", "error", "-i", str(src),
         "-frames:v", str(n_frames),
         # crf 10, not the usual 20-23: thin lines smear at ordinary quality.
         "-c:v", "libx264", "-crf", "10", "-preset", "veryfast",
         "-pix_fmt", "yuv420p", str(dst)],
        check=True, capture_output=True, text=True, timeout=900)
    return dst


def transfer_spec(hint, *, name, prompt_obj, num_frames_request, seed=2026,
                  weight=1.0, control_override=None):
    """A transfer spec: video2video plus ONE control-hint block. Nothing else."""
    key = f"control_{hint}"
    if control_override is None and key not in controls:
        raise FileNotFoundError(
            f"the {hint!r} control video is not on disk. Run "
            f"`python scripts/fetch_assets.py`.")
    control = control_override or trim_control(controls[key]["path"], CONTROL_FRAMES)
    negative = cc.asset_or_none("transfer_negative_prompt")
    return cc.InferenceSpec(
        model_mode="video2video",                 # <- the mode. Not "transfer".
        name=name, prompt=compact(prompt_obj),
        negative_prompt=compact(negative) if negative else None,
        vision_path=str(control), resolution=RES, aspect_ratio="16,9",
        num_frames=num_frames_request, fps=24, num_steps=N_STEPS,
        guidance=7.0, shift=10.0, seed=seed,
        controls={hint: {"control_path": str(control), "weight": weight}},
    )


def assert_control_matches(control_path, num_frames=None, fps=None):
    """Precondition for a transfer run. Raises BEFORE anything expensive."""
    info = probe_video(control_path)
    problems = []
    if num_frames is not None and info["frames"] not in (None, num_frames):
        problems.append(f"control has {info['frames']} frames, spec asks for "
                        f"{num_frames}. The output will follow the control.")
    if fps is not None and info["fps"] and abs(info["fps"] - fps) > 0.51:
        problems.append(f"control is {info['fps']} fps, spec asks for {fps}")
    if problems:
        raise ValueError("control/spec mismatch:\\n  - " + "\\n  - ".join(problems))
    return info
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Two controls, one clip, one table",
    goal="Tabulate concretely what changes between two control hints on the same source.",
    success="A table with at least five columns and two rows, both runs verified, the "
            "shared prompt shown, and a written note on a disagreement between your eyes "
            "and a metric.",
    approach="Score the subjective column **before** printing the metrics — hint 1 is "
             "right that a number you have seen contaminates a judgement — and derive "
             "`num_frames` from each control rather than typing it.",
)

nb.code('''
PAIR = ["blur", "depth"]
SHARED_PROMPT = {
    "description": "The same scene under warm low evening sun with long shadows.",
    "lighting": "warm low sun from the left, long shadows, golden cast",
    "style": "documentary realism, natural colour",
}

# STEP 5, DONE FIRST. The scale is written down before any output exists, which
# is the only way it can be applied honestly (hint 1). It is filled in by
# looking at the videos, before the metric table below is printed.
IDENTITY_SCALE = {
    3: ("objects keep their identity: a car is the same car, in the same place, "
        "with the same number of wheels, through the whole clip"),
    2: ("objects keep their category but not their identity: still a car, but its "
        "shape, colour or trim changes between frames"),
    1: ("objects lose identity: a car becomes a smear, merges with the background, "
        "or a new object appears that was not in the control"),
}
MY_SCORES = {}     # filled in by watching, BEFORE the table below is printed
for level, meaning in sorted(IDENTITY_SCALE.items(), reverse=True):
    print(f"  {level}: {meaning}")
''')

nb.code('''
comparison = []
for hint in PAIR:
    key = f"control_{hint}"
    if key not in controls:
        print(f"{hint}: control missing — run scripts/fetch_assets.py")
        continue
    control = trim_control(controls[key]["path"], CONTROL_FRAMES)
    # Step 3: DERIVE the frame count. Typing 61 here is the exact bug the
    # lesson's debugging lab is built around — the output follows the control,
    # not the spec, so a mismatch produces a silently different-length clip.
    derived = probe_video(control)["frames"]
    spec = transfer_spec(hint, name=f"cmp_{hint}", prompt_obj=SHARED_PROMPT,
                         num_frames_request=derived, control_override=control)
    assert_control_matches(control, num_frames=spec.num_frames)
    res = run_and_verify(spec, "compare", label=f"cmp_{hint}")
    if res is None or not res.video_path:
        continue
    out_info = probe_video(res.video_path)
    comparison.append({
        "hint": hint,
        "structure_retention": structure_retention(res.video_path, control),
        "motion_agreement": motion_agreement(res.video_path, control),
        "geometry": f"{out_info['width']}x{out_info['height']}",
        "frames": out_info["frames"],
        "seconds": RUNS[f"cmp_{hint}"]["seconds"],
        "peak_gb": RUNS[f"cmp_{hint}"]["peak_gb"],
        "my_identity_score": MY_SCORES.get(hint),
    })

print(f"{len(comparison)} row(s)")
''')

nb.code('''
# PLACEHOLDER ROWS — invented, used only so the table and the disagreement
# analysis run without a 35 GB download and two Nano transfers. NOT
# measurements. The subjective scores are what a viewer might plausibly give;
# they are here to make the disagreement between eye and metric concrete.
PLACEHOLDER_COMPARISON = [
    {"hint": "blur", "structure_retention": 0.41, "motion_agreement": 0.78,
     "geometry": "832x480", "frames": 33, "seconds": 412.0, "peak_gb": 41.2,
     "my_identity_score": 3, "placeholder": True},
    {"hint": "depth", "structure_retention": 0.63, "motion_agreement": 0.55,
     "geometry": "832x480", "frames": 33, "seconds": 418.0, "peak_gb": 41.4,
     "my_identity_score": 2, "placeholder": True},
]

using_placeholder = not comparison
rows = comparison or PLACEHOLDER_COMPARISON
if using_placeholder:
    print("PLACEHOLDER TABLE — invented numbers, not measurements.\\n")

cols = ["hint", "structure_retention", "motion_agreement", "geometry", "frames",
        "seconds", "peak_gb", "my_identity_score"]
print("".join(f"{c:<21}" if c != "hint" else f"{c:<8}" for c in cols))
print("-" * 148)
for r in rows:
    line = f"{r['hint']:<8}"
    for c in cols[1:]:
        v = r.get(c)
        line += (f"{v:<21.4f}" if isinstance(v, float) else f"{str(v):<21}")
    print(line)

assert len(rows) >= 2 and len(cols) >= 5, "the table needs 2 rows and 5 columns"
print(f"\\nshared prompt: {json.dumps(SHARED_PROMPT)}")
''')

nb.model_answer(
    "**Where my judgement and the numbers disagreed.**\n\n"
    "The depth control scores materially higher on `structure_retention` and I scored it "
    "*lower* on object identity. Both readings are correct, and the gap between them is "
    "the most useful thing in the table.\n\n"
    "`structure_retention` correlates gradient magnitude between output and control. A "
    "depth map is smooth within objects and has strong gradients at their boundaries, so "
    "an output that respects the depth map inherits sharp, well-placed silhouettes — and "
    "that is what the metric rewards. Object *identity*, which is what I was scoring, is "
    "about what happens **inside** the silhouette: does the car stay the same car, or "
    "does its colour and trim drift while its outline holds? Depth carries no information "
    "inside a surface, so the model is free there and it uses that freedom. The blur "
    "control, conversely, preserves colour and overall look while giving up fine "
    "boundaries — which scores badly on a gradient metric and looks stable to a viewer.\n\n"
    "This maps exactly onto `COSMOS3_FACTS.md` §2's table: `depth` preserves \"3D "
    "structure, spatial scale\"; `blur` preserves \"colour, lighting, overall look\". "
    "The exercise's real content is that a single scalar cannot represent both, and "
    "`structure_retention` is a *structure* metric wearing a general name.\n\n"
    "**What follows.** Do not use one retention number to choose a hint. Choose the hint "
    "from what you need preserved, then use the metric that measures that thing: gradient "
    "correlation for `edge` and `depth`, a colour-histogram distance for `blur`, and a "
    "region-consistency measure for `seg`. A metric chosen independently of the hint will "
    "rank hints by how much they resemble `edge`.\n\n"
    "**And the methodological point from hint 1**, which is worth more than the finding: "
    "the subjective column was scored before the metric table was printed. Had I read "
    "\"structure retention 0.63\" first, my identity score for depth would very likely "
    "have been a 3. There is no way to un-see a number, so the only defence is ordering.\n\n"
    "*If the table above is the placeholder set, the disagreement is constructed to be "
    "the one you should expect, not one that was observed here.*"
)

nb.extend(
    "The comparison holds the prompt fixed and varies the hint. The other half of the "
    "design is to hold the hint fixed and vary the **weight** — `TransferArgs.weight`, "
    "exposed as `weight` in `transfer_spec`. Sweeping it from 0.25 to 1.5 on one hint "
    "turns \"which hint\" into \"how much control\", and the two questions interact: a "
    "depth control at weight 0.5 may behave more like blur at 1.0 than like depth at 1.0. "
    "It is also the cheapest way to find out whether a disappointing transfer was the "
    "wrong hint or the right hint applied too weakly."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "Make your own control map",
    goal="Generate an edge control from an arbitrary video and drive a transfer with it.",
    success="A control video passing `assert_control_matches`, driving a verified "
            "transfer, with `structure_retention` reported alongside the cookbook "
            "control's figure and a diagnosis of any gap.",
    approach="Read and write with **one** library (hint 1), encode near-lossless, and "
             "verify the frame count with `probe_video` rather than trusting the writer.",
)

nb.code('''
def make_edge_control(src, dst, *, low=100, high=200, fps=None):
    """Turn a video into a Canny edge map with the same length and frame rate.

    Two silent failure modes guarded against here:

      * **Frame drift.** Reading with OpenCV and writing with imageio (or the
        reverse) reliably produces an off-by-one frame count, because the two
        disagree about whether a container's last frame exists. A one-frame
        offset is invisible in a still and obvious in motion, and it misaligns
        everything after it. So: ONE library end to end, and the count is
        verified after writing rather than assumed.
      * **Compression eating the lines.** H.264 at default quality treats
        one-pixel white lines on black as high-frequency noise and removes
        them. The control still plays, still has the right frame count, and
        conditions far more weakly than you think. Hence crf 0 (lossless) with
        a yuv444p pixel format — chroma subsampling alone visibly thickens and
        shifts thin edges.

    Returns the writer's own probe of the result so the caller can compare.
    """
    import cv2

    src, dst = Path(src), Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(str(src))
    if not cap.isOpened():
        raise RuntimeError(f"OpenCV cannot open {src}")
    src_fps = fps or cap.get(cv2.CAP_PROP_FPS) or 24.0

    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        grey = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(grey, low, high)
        frames.append(cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR))
    cap.release()
    if not frames:
        raise RuntimeError(f"no frames decoded from {src}")

    height, width = frames[0].shape[:2]
    # Write raw frames to a lossless intermediate, then let ffmpeg encode, so
    # the quality settings are ours rather than the OpenCV writer's defaults.
    raw = dst.with_suffix(".raw.avi")
    writer = cv2.VideoWriter(str(raw), cv2.VideoWriter_fourcc(*"FFV1"),
                             src_fps, (width, height))
    for frame in frames:
        writer.write(frame)
    writer.release()

    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg:
        subprocess.run(
            [ffmpeg, "-y", "-loglevel", "error", "-i", str(raw),
             "-c:v", "libx264", "-crf", "0", "-preset", "veryslow",
             "-pix_fmt", "yuv444p", "-r", str(src_fps), str(dst)],
            check=True, capture_output=True, text=True, timeout=1800)
        raw.unlink(missing_ok=True)
    else:
        raw.replace(dst.with_suffix(".avi"))
        dst = dst.with_suffix(".avi")
    return {"written_frames": len(frames), "path": dst, "fps": src_fps}
''')

nb.code('''
# Verify the extractor on a video built here, whose frame count is known
# exactly. This is the check the exercise is really asking for — "verify with
# probe_video rather than assuming" — done against a source whose answer is not
# in doubt.
def make_test_video(path, *, frames=24, size=(160, 96), fps=24):
    """A synthetic clip with a moving bar: known length, obvious edges."""
    import cv2

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    w, h = size
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"FFV1"), fps, (w, h))
    for i in range(frames):
        frame = np.zeros((h, w, 3), dtype=np.uint8)
        x = int((w - 20) * i / max(frames - 1, 1))
        frame[20:h - 20, x:x + 20] = 255
        writer.write(frame)
    writer.release()
    return path


HAVE_CV2 = True
try:
    import cv2  # noqa: F401
except ImportError:
    HAVE_CV2 = False
    print("OpenCV is not installed, so the extractor cannot be exercised here. "
          "`pip install opencv-python-headless`, or use ffmpeg's edgedetect filter:")
    print("  ffmpeg -i in.mp4 -vf edgedetect=low=0.1:high=0.4 -c:v libx264 -crf 0 "
          "-pix_fmt yuv444p out.mp4")

if HAVE_CV2:
    test_src = make_test_video(OUTPUT_DIR / "controls" / "synthetic_source.avi",
                               frames=24)
    test_dst = OUTPUT_DIR / "controls" / "synthetic_edge.mp4"
    info = make_edge_control(test_src, test_dst)
    src_probe = probe_video(test_src)
    dst_probe = probe_video(info["path"])
    print(f"source : {src_probe}")
    print(f"control: {dst_probe}")
    assert info["written_frames"] == 24, info
    if src_probe["frames"] and dst_probe["frames"]:
        assert src_probe["frames"] == dst_probe["frames"], (src_probe, dst_probe)
        print("\\nPASS the control has exactly as many frames as the source")
    assert (src_probe["width"], src_probe["height"]) == \\
           (dst_probe["width"], dst_probe["height"]), (src_probe, dst_probe)
    print("PASS geometry is preserved")
    assert_control_matches(info["path"], num_frames=dst_probe["frames"])
    print("PASS assert_control_matches accepts it")
''')

nb.code('''
# The compression point, demonstrated rather than asserted. Encode the same
# edge map at crf 0 and at a default-ish crf 23, and measure how much edge
# energy survives. This is the "too much compression" branch of step 5's
# diagnosis, made checkable.
if HAVE_CV2 and shutil.which("ffmpeg"):
    lossy = OUTPUT_DIR / "controls" / "synthetic_edge_crf23.mp4"
    subprocess.run(
        [shutil.which("ffmpeg"), "-y", "-loglevel", "error",
         "-i", str(test_src), "-c:v", "libx264", "-crf", "23",
         "-preset", "veryfast", "-pix_fmt", "yuv420p", str(lossy)],
        check=True, capture_output=True, text=True, timeout=900)

    def edge_energy(path):
        frames = [resize_to(f) for f in read_frames(path, 6)]
        return float(np.mean([gradient_magnitude(f).mean() for f in frames])) \\
            if frames else float("nan")

    good, bad = edge_energy(info["path"]), edge_energy(lossy)
    print(f"edge energy, crf 0  (yuv444p): {good:.3f}")
    print(f"edge energy, crf 23 (yuv420p): {bad:.3f}")
    print(f"retained: {bad / good:.1%}" if good else "")
    print("\\nBoth files play. Both have the right frame count. One conditions the "
          "model and one partly does not, and no error is raised either way — "
          "which is why the encode settings are part of the method rather than a "
          "detail.")
else:
    print("Skipped: needs OpenCV and ffmpeg. The claim being demonstrated is that "
          "default H.264 settings remove thin lines, so a control that looks fine "
          "conditions weakly.")
''')

nb.code('''
# Now drive a real transfer with the home-made control, and compare its
# structure retention against the cookbook control's.
SOURCE = cc.asset_or_none("video_car_driving_plain")
MY_CONTROL = OUTPUT_DIR / "controls" / "my_edge.mp4"
my_result = None
mine_retention = cookbook_retention = float("nan")

if HAVE_CV2 and SOURCE is not None:
    trimmed_source = trim_control(SOURCE, CONTROL_FRAMES)
    built = make_edge_control(trimmed_source, MY_CONTROL)
    src_info, ctl_info = probe_video(trimmed_source), probe_video(built["path"])
    print(f"source : {src_info}")
    print(f"control: {ctl_info}")
    assert_control_matches(built["path"], num_frames=ctl_info["frames"])
    print("precondition passes\\n")

    spec = transfer_spec("edge", name="my_edge_transfer",
                         prompt_obj=SHARED_PROMPT,
                         num_frames_request=ctl_info["frames"],
                         control_override=built["path"])
    my_result = run_and_verify(spec, "my_control", label="my_edge_transfer")
    if my_result is not None and my_result.video_path:
        mine_retention = structure_retention(my_result.video_path, built["path"])
elif SOURCE is None:
    print("video_car_driving_plain is not on disk — run scripts/fetch_assets.py")

for r in rows:
    if r["hint"] == "edge":
        cookbook_retention = r["structure_retention"]

print(f"\\nstructure_retention, my control      : {mine_retention}")
print(f"structure_retention, cookbook control: {cookbook_retention}")
if mine_retention == mine_retention and cookbook_retention == cookbook_retention:
    print(f"gap: {mine_retention - cookbook_retention:+.4f}")
else:
    print("One or both is unavailable on this machine, so the comparison is not "
          "made. The diagnosis below is the deliverable either way.")
''')

nb.model_answer(
    "**Diagnosing a low retention from a home-made control, in the order to check.**\n\n"
    "Four candidate causes, and they are distinguishable — which is the point, because "
    "\"my control is worse\" is not actionable and \"my Canny thresholds are too tight\" "
    "is.\n\n"
    "**1. Frame misalignment (check first, cheapest and worst).** If the control is one "
    "frame longer or shorter than the source, every subsequent frame conditions on the "
    "wrong moment. The signature: retention that is not merely low but *decreasing* "
    "across the clip. Test by computing `structure_retention` frame-by-frame instead of "
    "averaging, and by re-running with the control shifted one frame — if retention "
    "*improves*, you have found it. The guard is the `probe_video` equality assertion "
    "above, and it is an assertion rather than a print because this failure is silent.\n\n"
    "**2. Compression (check second, demonstrated above).** Default H.264 removes thin "
    "lines. The signature: the control's own edge energy is much lower than the raw "
    "frames', which the cell above measures directly. Fix: crf 0, `yuv444p`. Note that "
    "chroma subsampling matters independently of the quality setting — `yuv420p` shifts "
    "edges by half a pixel in chroma even at crf 0.\n\n"
    "**3. Threshold choice.** `cv2.Canny(grey, 100, 200)` is a reasonable default and it "
    "is wrong for low-contrast footage — a foggy or overexposed clip yields almost no "
    "edges, and the control conditions on nothing. The signature: the control video is "
    "mostly black. Diagnose by looking at it; fix by setting the thresholds from the "
    "image statistics (a common rule is `low = 0.66 * median`, `high = 1.33 * median` per "
    "frame) rather than fixing them globally.\n\n"
    "**4. A genuine difference in what the control contains.** The cookbook's edge maps "
    "were produced from clean source footage at 30 fps with a purpose-built extractor. "
    "Canny on compressed dashcam footage produces edges on *compression artefacts* as "
    "well as on objects, and the model conditions on both. This is the residual after "
    "the first three are excluded, and it is not a bug — it is the actual difference "
    "between a curated asset and your footage.\n\n"
    "**What I would change for a real augmentation run.** Stop using Canny. It is an "
    "intensity-gradient detector with two magic numbers, and it is unstable frame to "
    "frame — an edge that flickers on and off across frames conditions the model to "
    "produce flicker. A learned edge detector (HED, PiDiNet) is temporally far more "
    "stable and is what production control pipelines use. Failing that, at minimum: set "
    "thresholds per clip from the median, and apply a small temporal median filter across "
    "three frames to suppress single-frame edge flicker. Both are cheap and both attack "
    "the failure mode — temporal instability — that a per-frame quality check cannot see."
)

nb.extend(
    "Edge is the easiest control to build and the least informative. A depth control from "
    "the same footage — via a monocular depth model such as Depth Anything — is a few "
    "lines more and conditions on 3D structure rather than on intensity boundaries, which "
    "per `COSMOS3_FACTS.md` §2 is what you want for relighting and surface changes. It "
    "also has an interesting failure mode worth meeting: monocular depth is only "
    "consistent up to a per-frame scale, so a naive per-frame depth map *breathes*, and "
    "the control tells the model the scene is expanding and contracting. Normalising "
    "depth across the clip rather than per frame is the fix, and discovering why is "
    "worth the afternoon."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "An augmentation pipeline with a quality gate",
    goal="Produce N screened variants of one clip across controls and prompts, with an "
         "automated gate, and a report on which combinations failed and why.",
    success="At least 8 attempted variants, a gate that returns reasons, per-control and "
            "per-prompt yield tables, a stated threshold you would move with its "
            "consequence, and a limitations paragraph naming the shared-structure "
            "problem.",
    approach="Cost the design first, gate on three independent checks each returning its "
             "own reason string, and report failures grouped by reason so the *cause* is "
             "visible rather than the count.",
)

nb.code('''
CONTROLS = ["edge", "depth"]
PROMPT_VARIANTS = {
    "night": {"description": "The same road at night under sodium street lighting.",
              "lighting": "orange sodium street lamps, deep shadows between pools "
                          "of light",
              "style": "documentary realism, natural colour"},
    "rain": {"description": "The same road in heavy rain with standing water.",
             "lighting": "flat grey daylight, wet reflective tarmac",
             "style": "documentary realism, natural colour"},
    "snow": {"description": "The same road under fresh snow.",
             "lighting": "bright overcast, high-key, snow-covered surfaces",
             "style": "documentary realism, natural colour"},
    "dusk": {"description": "The same road at dusk with a low sun behind the camera.",
             "lighting": "warm low sun from behind, long shadows, golden cast",
             "style": "documentary realism, natural colour"},
}

n_combos = len(CONTROLS) * len(PROMPT_VARIANTS)
per_run = predict_seconds(RES, CONTROL_FRAMES or 121, N_STEPS)
print(f"variation space: {len(CONTROLS)} controls x {len(PROMPT_VARIANTS)} prompts "
      f"= {n_combos} runs")
if per_run:
    print(f"predicted per run: {per_run / 60:.1f} min -> total "
          f"{n_combos * per_run / 60:.0f} min")
    print("(from Lesson 06's calibration, on IMAGE runs — see the caveat below)")
else:
    print("No Lesson 06 calibration on this machine, so no time estimate is offered. "
          "Run Lesson 06's calibration section first; guessing here is how an "
          "overnight job becomes a three-day job.")
print()
print("WHAT WAS CUT, and why (step 1): the original plan had four controls "
      "(edge, blur, depth, seg) x six prompts = 24 runs. Hint 1 says cut prompts "
      "rather than controls, and that is right for the LESSON — the control axis "
      "carries the content. It is wrong for the DATASET: for augmentation, prompt "
      "diversity is the product and the control is machinery. Cutting to 2 x 4 "
      "splits the difference and keeps a per-control comparison possible, which a "
      "1 x 8 design would not.")
''')

nb.code('''
MOTION_FLOOR = 0.35
RETENTION_FLOOR = 0.20


def augment(hint, prompt_name, prompt_obj, seed=0):
    """One variant: precondition, run, verify, measure. Returns a record."""
    record = {"hint": hint, "prompt": prompt_name, "seed": seed, "video": None,
              "checks": [], "structure_retention": float("nan"),
              "motion_agreement": float("nan"), "geometry_ok": None,
              "error": None, "control": None}
    key = f"control_{hint}"
    if key not in controls:
        record["error"] = f"no {hint} control on disk"
        return record
    control = trim_control(controls[key]["path"], CONTROL_FRAMES)
    record["control"] = str(control)
    info = probe_video(control)
    spec = transfer_spec(hint, name=f"aug_{hint}_{prompt_name}",
                         prompt_obj=prompt_obj, num_frames_request=info["frames"],
                         seed=seed, control_override=control)
    try:
        assert_control_matches(control, num_frames=spec.num_frames)
    except ValueError as exc:
        record["error"] = f"precondition: {exc}"
        return record
    result = run_and_verify(spec, "augment", label=spec.name)
    if result is None:
        record["error"] = "generation disabled or skipped"
        return record
    if not result.ok:
        record["error"] = "generation: " + "; ".join(result.diagnose())
        return record
    record["video"] = str(result.video_path) if result.video_path else None
    record["checks"] = cc.verify_result(result, verbose=False)
    if record["video"]:
        record["structure_retention"] = structure_retention(record["video"], control)
        record["motion_agreement"] = motion_agreement(record["video"], control)
        out = probe_video(record["video"])
        record["geometry_ok"] = (out["frames"] == info["frames"])
        record["frames"] = out["frames"]
    return record


def gate(record):
    """Automated quality gate. Return (passed, reason).

    Three independent checks, each with its own reason string (hint 2): a gate
    returning bare False tells you a variant failed; a gate returning
    'motion_agreement 0.11 below floor 0.35' tells you WHICH control is
    responsible, which is the finding.
    """
    if record.get("error"):
        return False, f"did not produce output: {record['error'][:70]}"
    failed = [c.name for c in record["checks"] if not c.passed]
    if failed:
        return False, f"verify_result failed: {','.join(failed)}"
    if record["geometry_ok"] is False:
        return False, (f"geometry: output has {record.get('frames')} frames, control "
                       f"has a different count — the clip is not aligned to its control")
    ma = record["motion_agreement"]
    if ma != ma:
        return False, "motion_agreement undefined (too few decodable frames)"
    if ma < MOTION_FLOOR:
        return False, f"motion_agreement {ma:.2f} below floor {MOTION_FLOOR}"
    sr = record["structure_retention"]
    if sr == sr and sr < RETENTION_FLOOR:
        return False, f"structure_retention {sr:.2f} below floor {RETENTION_FLOOR}"
    return True, "passed"
''')

nb.code('''
def report(records):
    """Yield overall, per control, per prompt; plus the top failure reason."""
    gated = [(r, *gate(r)) for r in records]
    total = len(gated)
    passed = [g for g in gated if g[1]]
    print(f"overall yield: {len(passed)}/{total} "
          f"({len(passed) / total:.0%})" if total else "no records")

    print(f"\\n{'control':<10}{'pass':>6}{'of':>5}{'yield':>8}")
    for hint in sorted({r["hint"] for r in records}):
        subset = [g for g in gated if g[0]["hint"] == hint]
        ok = sum(1 for g in subset if g[1])
        print(f"{hint:<10}{ok:>6}{len(subset):>5}{ok / len(subset):>8.0%}")

    print(f"\\n{'prompt':<10}{'pass':>6}{'of':>5}{'yield':>8}")
    for name in sorted({r["prompt"] for r in records}):
        subset = [g for g in gated if g[0]["prompt"] == name]
        ok = sum(1 for g in subset if g[1])
        print(f"{name:<10}{ok:>6}{len(subset):>5}{ok / len(subset):>8.0%}")

    reasons = {}
    for _, ok, reason in gated:
        if not ok:
            # Group by CAUSE, not by the exact number: "motion_agreement 0.31"
            # and "motion_agreement 0.22" are one finding, not two.
            key = reason.split(":")[0]
            if any(ch.isdigit() for ch in key):
                key = key.split()[0]
            reasons[key] = reasons.get(key, 0) + 1
    print(f"\\n{'failure reason':<40}{'count':>6}")
    for key, n in sorted(reasons.items(), key=lambda kv: -kv[1]):
        print(f"{key:<40}{n:>6}")
    top = max(reasons, key=reasons.get) if reasons else None
    print(f"\\nmost common failure: {top!r}" if top else "\\nno failures")
    return {"total": total, "passed": len(passed), "reasons": reasons, "top": top,
            "gated": gated}


records = []
for hint in CONTROLS:
    for name, prompt_obj in PROMPT_VARIANTS.items():
        records.append(augment(hint, name, prompt_obj))

if not any(r["video"] for r in records):
    # PLACEHOLDER RECORDS — invented, so the gate and the report are exercised.
    # Chosen to reproduce the pattern this design is expected to show: the depth
    # control agrees less with the control's motion profile, so it fails the
    # motion floor more often. NOT measurements.
    print("PLACEHOLDER RECORDS — invented, not measurements.\\n")
    fake = [("edge", "night", 0.62, 0.81), ("edge", "rain", 0.58, 0.76),
            ("edge", "snow", 0.41, 0.69), ("edge", "dusk", 0.64, 0.83),
            ("depth", "night", 0.66, 0.44), ("depth", "rain", 0.61, 0.31),
            ("depth", "snow", 0.33, 0.22), ("depth", "dusk", 0.68, 0.51)]
    records = [{"hint": h, "prompt": p, "seed": 0, "video": f"placeholder_{h}_{p}.mp4",
                "checks": [], "structure_retention": sr, "motion_agreement": ma,
                "geometry_ok": True, "frames": CONTROL_FRAMES, "error": None,
                "control": f"control_{h}", "placeholder": True}
               for h, p, sr, ma in fake]

summary = report(records)
assert summary["total"] >= 8, "the exercise asks for at least eight variants"
for r, ok, reason in summary["gated"]:
    assert isinstance(reason, str) and reason, "the gate must return a reason"
print("\\nPASS at least 8 variants attempted and every gate verdict carries a reason")
''')

nb.model_answer(
    "**Which threshold I would move, in which direction, and what it costs.**\n\n"
    "**`MOTION_FLOOR`, from 0.35 down to about 0.25.** The reasoning, and the cost.\n\n"
    "`motion_agreement` correlates the frame-to-frame change profile of the output "
    "against the control's. It is a *temporal* alignment check: it asks whether the "
    "output moves when the control moves. On the placeholder pattern above it is "
    "responsible for most rejections, and every one of them is on the `depth` control — "
    "which should make you suspicious of the threshold before you suspect the control.\n\n"
    "The reason depth scores lower is structural, not qualitative. A depth map's "
    "frame-to-frame change is dominated by *parallax* — near objects move more than far "
    "ones — while an RGB output's frame-to-frame change is dominated by texture and "
    "lighting, which depth does not carry. The two profiles are genuinely less correlated "
    "even when the transfer is perfectly good. So a floor of 0.35 is not measuring "
    "quality on the depth control; it is measuring the modality gap, and it is throwing "
    "away usable clips.\n\n"
    "**The cost of moving it to 0.25**: false accepts. The failure the floor exists to "
    "catch is a transfer that ignored its control — the prompt won, the output is a "
    "plausible video of the right weather with the wrong motion, and it is *worse than "
    "useless* in an augmentation set because it is well-formed and wrong. Lowering the "
    "floor lets some of those through. Concretely, on the pattern above, moving 0.35 to "
    "0.25 admits `depth/snow` at 0.22... which it does not, since 0.22 < 0.25 — and that "
    "is the point of choosing 0.25 rather than 0.20: it recovers the depth clips in the "
    "0.25–0.35 band while still rejecting the one that is genuinely detached.\n\n"
    "**The better fix, which the threshold move is a stopgap for:** make the floor "
    "**per-control**. `MOTION_FLOOR = {\"edge\": 0.45, \"depth\": 0.25, \"blur\": 0.40}`, "
    "calibrated from a handful of runs per control that a human has judged good. A single "
    "global threshold across control types with different physics is the same error as "
    "Exercise 1's — one scalar standing in for several distinct properties.\n\n"
    "**`RETENTION_FLOOR` I would leave at 0.20 and not trust.** It is doing almost no "
    "work — nothing fails on it in the table above — which means either the generation is "
    "reliably structure-preserving or the floor is too low to bind. Those are different, "
    "and a check that never fires is a check you have not tested. Before shipping this "
    "gate I would deliberately feed it a known-bad transfer (the \"forbidden prompt\" run "
    "from the lesson, where the prompt contradicts the control) and confirm the floor "
    "catches it. A gate with an untested branch is a gate with an unknown false-negative "
    "rate."
)

nb.code('''
lines = [
    "# Augmentation set with a quality gate — Lesson 08, Exercise 3",
    "",
    ("**PLACEHOLDER NUMBERS.** No Nano transfer ran on this machine. The design, the "
     "gate, the reasons and the reporting are real; the metric values are invented."
     if any(r.get("placeholder") for r in records) else "Measured on this machine."),
    "",
    "## Design and what was cut",
    "",
    f"{len(CONTROLS)} controls x {len(PROMPT_VARIANTS)} prompts = {len(records)} runs. "
    f"Cut from 4 controls x 6 prompts (24 runs) after costing it with Lesson 06's "
    f"calibration. Prompts were cut before controls, so a per-control comparison "
    f"survives.",
    "",
    "## Yield",
    "",
    f"- overall: {summary['passed']}/{summary['total']} "
    f"({summary['passed'] / summary['total']:.0%})",
    f"- most common failure: `{summary['top']}`",
    "",
    "| failure reason | count |",
    "|---|---:|",
]
for key, n in sorted(summary["reasons"].items(), key=lambda kv: -kv[1]):
    lines.append(f"| {key} | {n} |")

lines += [
    "",
    "## Threshold I would move",
    "",
    f"`MOTION_FLOOR` from {MOTION_FLOOR} to 0.25, and better still make it "
    f"per-control. See the model answer in the notebook for the argument and the "
    f"false-accept cost.",
    "",
    "## Limitations",
    "",
    "**Every variant in this set shares one camera trajectory and one scene layout.** "
    "The control video fixes the path the camera takes, where the road goes, where the "
    "other vehicles are, and when each of them appears. Only the appearance varies. A "
    "model trained on this set sees eight lighting conditions over one piece of "
    "geometry, and it can satisfy the training objective by learning that geometry "
    "rather than by learning to be robust to weather. Worse, a random train/test split "
    "of this set puts the same trajectory on both sides, so validation accuracy will "
    "look excellent and will not transfer.",
    "",
    "Concretely, what is still needed from real data:",
    "",
    "- **More trajectories.** Different roads, junctions, camera heights and mount "
    "positions. This is the single largest gap and no amount of prompt variation "
    "closes it.",
    "- **Real sensor characteristics.** Rolling shutter, real motion blur, real "
    "low-light noise. Generated night footage is clean in a way real night footage "
    "never is, and a detector trained on it will meet its first real night frame as "
    "out-of-distribution.",
    "- **Correlated failure cases.** Real rain arrives with spray, wipers and lens "
    "beading together. The prompt axis varies them as if independent.",
    "",
    "Split this set by SOURCE CONTROL, never at random.",
]
report_path = OUTPUT_DIR / "augmentation_gate_report.md"
report_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {report_path}")
print("\\n".join(lines[-14:]))
''')

nb.why(
    "**Why the gate returns reasons rather than booleans.** Hint 2 states the benefit and "
    "the report cell shows it: grouping failures by reason turns eight rejections into "
    "one sentence — *the depth control fails the motion floor* — which is a finding you "
    "can act on. A boolean gate produces \"yield 50%\" and no next step. The general "
    "principle is that an automated check should record *why* at the moment it knows, "
    "because reconstructing it afterwards from the artefacts is usually impossible.\n\n"
    "**Why three independent checks rather than one composite score.** `verify_result` "
    "asks whether the file is a live video; `geometry_ok` asks whether it is aligned to "
    "its control; the two metric floors ask whether the control was honoured. These fail "
    "for unrelated reasons and have unrelated fixes — a decode failure is a bug, a "
    "geometry mismatch is a spec error, and a low motion agreement is a modelling "
    "outcome. Combining them into a weighted score would let a strong structure "
    "retention mask a broken frame count.\n\n"
    "**Why costing the design comes before writing `augment`.** Hint 1 is blunt about it "
    "and the reason is that the cut is a *design* decision, not a scheduling one. 24 runs "
    "versus 8 changes which questions the set can answer, and discovering the budget "
    "after eleven runs means the cut gets made by whatever happened to finish. Note the "
    "commentary above disagrees with the hint on *what* to cut: for a lesson, cut prompts; "
    "for a dataset, prompt diversity is the product. Saying so explicitly is better than "
    "silently following advice given for a different purpose.\n\n"
    "**On the time estimate.** `predict_seconds` is calibrated in Lesson 06 on "
    "single-frame image runs at 256p or 480p with Edge. These are 33-frame video runs "
    "with Nano. The prediction is a factor-of-two guide at best, and the cell says so "
    "rather than printing a confident minute count. Both differences push in the same "
    "direction — attention is quadratic in sequence length and Nano is four times Edge's "
    "active size — so the estimate is an *under*-estimate, which is the dangerous "
    "direction for an overnight job."
)

nb.extend(
    "The gate currently judges each clip against its control. It cannot see set-level "
    "problems, and those are the ones that ruin a dataset: two prompts that produce "
    "near-identical output, or a control whose eight variants are all more similar to "
    "each other than to anything else. Adding a pairwise distance matrix across the whole "
    "accepted set — the same measurement Lesson 07's augmentation exercise built — turns "
    "the gate from a filter into a portfolio check, and it is where you would find out "
    "that `night` and `dusk` are the same variant wearing two labels."
)

nb.finish()
