"""Build solutions/16_solutions.ipynb — reference answers for Lesson 16."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("16", "Post-training concepts",
                      lesson_file="16_posttraining_concepts.ipynb")

nb.header(
    "Lesson 16 is arithmetic, and the arithmetic is what decides whether Module 5 is "
    "possible at all. The foundation exercise computes three memory bills by hand and "
    "checks them against the estimator — the point being that you should be able to "
    "reproduce the number without the library at three in the morning. The applied one "
    "builds a real JSONL dataset that survives two silent loader filters. The challenge "
    "one turns the arithmetic into a planner and then runs it across a hardware matrix "
    "until it says something you disagree with."
)

nb.callout(
    "note",
    "**This lesson does not need a GPU** — it is arithmetic and file handling — and "
    "neither does this notebook. The dataset exercise degrades where it needs a reasoner "
    "or real video, and says so; everything else runs and is checked here.",
)

nb.prelude("The lesson's configuration, the per-parameter byte table, and the record "
           "builders.")
nb.code(setup_cell("16"))

nb.code('''
import json
import math
import shutil
import subprocess
from datetime import datetime, timezone

from cosmos_course import finetune

print("finetune module   : ok")
print("known model tiers :", ", ".join(sorted(cc.MODEL_TIERS)))
print("BYTES_PER_PARAM   :", dict(finetune.BYTES_PER_PARAM))
print()
print(f"DEVICE is {DEVICE!r}. This lesson does not care — it is all arithmetic.")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Three memory bills, by hand",
    goal="Compute state memory for three configurations without using "
         "`estimate_sft_memory`, then check each against it and explain any difference.",
    success="Configurations 1 and 2 agree with the estimator to within 0.2 GB; "
            "configuration 3 has a written justification for the discrepancy; and you "
            "can say which single row dominates each bill.",
    approach="One expression, exactly as hint 1 suggests — then print the rows "
             "individually anyway, because the dominating row is the answer to the last "
             "part of the question.",
)

nb.code('''
def by_hand(total_b, trainable_b, *, grad_bytes=4, ema=True):
    """Return total state memory in decimal GB.

    Rows, from the derivation earlier in the lesson:
      bf16 weights   2 bytes x EVERY parameter
      fp32 master    4 bytes x trainable
      AdamW m        4 bytes x trainable
      AdamW v        4 bytes x trainable
      gradients      grad_bytes x trainable
      EMA copy       4 bytes x trainable, only when ema is True

    Parameters are in BILLIONS, and the units cancel: a billion parameters at
    one byte each is exactly 1 decimal GB, so `total_b * 2` IS the bf16 row in
    GB with no conversion. That is why hint 1 says two lines is plenty.
    """
    per_trainable = 4 + 4 + 4 + grad_bytes + (4 if ema else 0)
    return total_b * 2 + trainable_b * per_trainable


def rows(total_b, trainable_b, *, grad_bytes=4, ema=True):
    """The same bill, itemised — because the DOMINANT row is the finding."""
    out = {"bf16 weights (all params)": total_b * 2,
           "fp32 master (trainable)": trainable_b * 4,
           "AdamW m (trainable)": trainable_b * 4,
           "AdamW v (trainable)": trainable_b * 4,
           "gradients (trainable)": trainable_b * grad_bytes}
    if ema:
        out["EMA fp32 copy"] = trainable_b * 4
    return out


# Check the shape of the arithmetic against a case you can do in your head:
# 1B params, all trainable, fp32 grads, EMA on -> 2 + 4+4+4+4+4 = 22 GB.
assert by_hand(1, 1, grad_bytes=4, ema=True) == 22
assert by_hand(1, 0, grad_bytes=4, ema=True) == 2      # frozen: weights only
assert sum(finetune.BYTES_PER_PARAM.values()) == 22
print("PASS 22 bytes per trainable parameter with EMA on and fp32 grads; "
      "2 bytes per frozen parameter; the course module agrees")
''')

nb.code('''
CARD_GB, RESERVE_GB = 80.0, 4.0
CONFIGS = [
    # (label, total_b, trainable_b, grad_bytes, ema)
    ("Nano full SFT, optimistic", 16, 16,          2, False),
    ("Edge gen-only, shipped",     4,  2,          4, True),
    ("Super LoRA r=32",           64, 64 * 0.002,  4, False),
]

bills = {}
for label, total_b, trainable_b, grad_bytes, ema in CONFIGS:
    state = by_hand(total_b, trainable_b, grad_bytes=grad_bytes, ema=ema)
    itemised = rows(total_b, trainable_b, grad_bytes=grad_bytes, ema=ema)
    budget = CARD_GB - RESERVE_GB - state
    dominant = max(itemised, key=itemised.get)
    bills[label] = {"state_gb": state, "budget_gb": budget, "rows": itemised,
                    "dominant": dominant}

    print(f"{label}")
    print(f"  total {total_b}B, trainable {trainable_b:g}B, "
          f"grads {grad_bytes} bytes, EMA {'on' if ema else 'off'}")
    for name, value in itemised.items():
        marker = "  <- dominates" if name == dominant else ""
        print(f"    {name:<28}{value:>9.1f} GB{marker}")
    print(f"    {'STATE TOTAL':<28}{state:>9.1f} GB")
    print(f"    {'activation budget on 80 GB':<28}{budget:>9.1f} GB")
    verdict = ("fits with room to work" if budget > 10 else
               "state fits, activations will not — no usable headroom"
               if budget > 0 else
               f"impossible: state alone is {state - (CARD_GB - RESERVE_GB):.0f} GB "
               f"over the card")
    print(f"    VERDICT: {verdict}\\n")
''')

nb.code('''
# Check 1 and 2 against the estimator, to within 0.2 GB.
checks = [
    ("Nano full SFT, optimistic",
     dict(model="Cosmos3-Nano", trainable_fraction=1.0, ema=False,
          card_gb=CARD_GB, reserve_gb=RESERVE_GB)),
    ("Edge gen-only, shipped",
     dict(model="Cosmos3-Edge", trainable_fraction=0.5, ema=True,
          card_gb=CARD_GB, reserve_gb=RESERVE_GB)),
]
for label, kwargs in checks:
    est = finetune.estimate_sft_memory(**kwargs)
    mine = bills[label]["state_gb"]
    print(f"{label:<28} mine {mine:>7.1f} GB   estimator {est.state_gb:>7.1f} GB   "
          f"diff {abs(mine - est.state_gb):>5.2f} GB")
    if label.startswith("Nano"):
        # The estimator's `grads` byte count is fp32 (4), and configuration 1
        # specifies bf16 gradients (2). Recompute at the estimator's assumption
        # so the comparison is like for like, and state the difference rather
        # than hiding it.
        like_for_like = by_hand(16, 16, grad_bytes=4, ema=False)
        print(f"{'':<28} at the estimator's fp32-gradient assumption: "
              f"{like_for_like:.1f} GB, diff "
              f"{abs(like_for_like - est.state_gb):.2f} GB")
        assert abs(like_for_like - est.state_gb) < 0.2, (like_for_like, est.state_gb)
    else:
        assert abs(mine - est.state_gb) < 0.2, (mine, est.state_gb)
print()
print("PASS configurations 1 and 2 agree with finetune.estimate_sft_memory to "
      "within 0.2 GB, once configuration 1's bf16-gradient assumption is "
      "reconciled with the estimator's fp32 one")
''')

nb.code('''
# Configuration 3: the estimator's LoRA model WILL disagree with the 0.2%
# assumption. Quantify the disagreement, then show it does not matter.
est_lora = finetune.estimate_sft_memory(model="Cosmos3-Super", lora=True,
                                        lora_rank=32, ema=False,
                                        card_gb=CARD_GB, reserve_gb=RESERVE_GB)
mine_lora = bills["Super LoRA r=32"]["state_gb"]
print(f"my assumption : adapters are 0.2% of 64B = "
      f"{64 * 0.002:.3f}B trainable -> {mine_lora:.1f} GB state")
print(f"the estimator : {est_lora.trainable_params_b:.3f}B trainable -> "
      f"{est_lora.state_gb:.1f} GB state")
print(f"disagreement  : {abs(mine_lora - est_lora.state_gb):.2f} GB "
      f"({abs(mine_lora - est_lora.state_gb) / max(mine_lora, 1e-9):.1%})")
print()
weights_only = 64 * 2
print(f"bf16 weights alone            : {weights_only:.0f} GB")
print(f"card minus reserve            : {CARD_GB - RESERVE_GB:.0f} GB")
print(f"over the card before ANY optimizer state: "
      f"{weights_only - (CARD_GB - RESERVE_GB):.0f} GB")
assert weights_only > CARD_GB - RESERVE_GB
print()
print("PASS the verdict is unchanged by the disagreement: the weights row alone "
      "exceeds the card, so no adapter size can rescue it")
''')

nb.model_answer(
    "**Which number I would defend for configuration 3, and which row dominates each "
    "bill.**\n\n"
    "**Configuration 3: I would defend neither number, and that is the answer.** My 0.2% "
    "assumption and the estimator's rank-proportional heuristic disagree by a fraction of "
    "a gigabyte, and the verdict is *unchanged* either way, because the bf16 weights row "
    "alone is 64 x 2 = **128 GB** against a card that has 80. Super does not fit on one "
    "H100 for training, with or without adapters, and no LoRA rank changes that. Spending "
    "effort on which adapter estimate is more accurate would be optimising a term that "
    "does not affect the decision — which is a mistake worth being able to recognise, "
    "because it is what most of the LoRA discussion online is doing.\n\n"
    "If forced to pick: the estimator's, because it at least scales with rank and its "
    "docstring says explicitly that the true count depends on which modules are targeted, "
    "so it is honest about being an order of magnitude. My 0.2% is a number I made up "
    "and did not scale with anything.\n\n"
    "**The dominant row in each bill, without looking:**\n\n"
    "1. **Nano full SFT** — the optimizer state, and specifically **AdamW's `m` and `v` "
    "together**. At 16B trainable they are 64 GB and 64 GB against a 32 GB weights row. "
    "This is why `COSMOS3_FACTS.md` §5 says activation checkpointing does not help: the "
    "blocker is optimizer state, not activations, and checkpointing trades compute for "
    "activation memory only.\n"
    "2. **Edge gen-only** — still the optimizer state (`m` + `v` = 16 GB against 8 GB of "
    "weights), but by a much smaller margin, which is exactly why this configuration is "
    "the course's lab recipe and the others are not.\n"
    "3. **Super LoRA** — the **bf16 weights**, overwhelmingly. Adapters make the "
    "optimizer state negligible and leave a 128 GB floor that no software setting can "
    "move.\n\n"
    "**The generalisation worth taking away.** LoRA attacks the optimizer-state rows and "
    "does nothing to the weights row. So LoRA turns a model that *nearly* fits into one "
    "that fits, and does nothing at all for a model whose weights already exceed the "
    "card. When someone proposes LoRA as the answer to an out-of-memory problem, the "
    "first question is which row is the blocker.\n\n"
    "**And one line item that is easy to miss.** EMA is a second fp32 copy of every "
    "trainable parameter, `model.ema.enabled` defaults to **True**, and it buys nothing "
    "you will observe in a 500-iteration lab run. In configuration 2 it is 8 of the 42 GB "
    "of state — a fifth of the bill, for free, by setting one flag. That is the largest "
    "single saving available on the Edge path and it costs nothing to take."
)

nb.extend(
    "The bills above are state only, and the exercise is explicit that activations are "
    "not in them. The number that would complete the picture is "
    "`max_num_tokens_after_packing`, which is the knob that sets activation memory and "
    "which `COSMOS3_FACTS.md` §5 says must be cut from its 8-GPU value of 45,056 for a "
    "single-GPU attempt. Activation memory is roughly linear in it, so one measured "
    "point — run at 12,288 tokens, record the peak — calibrates a line you can then use "
    "to answer \"what token cap fits my remaining budget\" without another run. That is "
    "Lesson 17's first experiment, and doing this arithmetic first is what makes it a "
    "prediction rather than a fishing trip."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "Build and validate a real JSONL dataset",
    goal="Turn video you actually have into a generator SFT dataset that survives both "
         "silent filters, with captions produced by the reasoner rather than typed.",
    success="`check_dataset` reports `ok: True`, `clips_over_61s: 0`, "
            "`windows_under_61_frames: 0`, at least six records, predicted drop counts "
            "matching the reported ones, and an `excluded.json` accounting for every "
            "clip.",
    approach="Probe every clip's real geometry, compute frames two ways and refuse to "
             "trust either when they disagree, cut **several** windows from each long "
             "clip, and predict the filter counts before running the validator.",
)

nb.code('''
DATASET_DIR = OUTPUT_DIR / "sft_dataset"
VIDEO_DIR = DATASET_DIR / "videos"
JSONL_PATH = DATASET_DIR / "video_dataset_file.jsonl"
EXCLUDED_PATH = DATASET_DIR / "excluded.json"
WINDOW_FRAMES = 61          # the loader's floor; a window shorter than this is dropped
MAX_CLIP_SECONDS = 61       # the loader's ceiling; a longer clip is dropped


def probe(path):
    """Real duration, dimensions and frame rate. Never guess these."""
    if shutil.which("ffprobe") is None:
        return None
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "v:0",
             "-show_entries", "stream=width,height,r_frame_rate,nb_frames",
             "-show_entries", "format=duration", "-of", "json", str(path)],
            capture_output=True, text=True, check=True, timeout=120).stdout
    except Exception:
        return None
    info = json.loads(out)
    stream = (info.get("streams") or [{}])[0]
    num, _, den = (stream.get("r_frame_rate") or "0/1").partition("/")
    fps = float(num) / float(den or 1) if float(den or 0) else 0.0
    duration = float((info.get("format") or {}).get("duration") or 0.0)
    declared = int(stream.get("nb_frames") or 0)
    # Hint 1: nb_frames is missing or wrong for a surprising number of MP4s.
    # Compute it a second way and cross-check; when the two disagree by more
    # than one, trust NEITHER — an off-by-N frame count silently produces
    # windows that run past the end of the file.
    derived = round(duration * fps) if fps else 0
    trustworthy = declared > 0 and abs(declared - derived) <= 1
    return {"width": int(stream.get("width") or 0),
            "height": int(stream.get("height") or 0),
            "fps": fps, "duration": duration,
            "frames_declared": declared, "frames_derived": derived,
            "frames": declared if trustworthy else derived,
            "frames_trustworthy": trustworthy}


# Verify the cross-check logic on synthetic metadata, since a machine without
# ffprobe or video cannot exercise the real path.
def _cross_check(declared, derived):
    return declared > 0 and abs(declared - derived) <= 1


assert _cross_check(180, 180) and _cross_check(180, 181)
assert not _cross_check(0, 180) and not _cross_check(180, 200)
print("PASS the frame-count cross-check accepts agreement within one frame and "
      "rejects a missing or disagreeing nb_frames")
''')

nb.code('''
def make_caption_json(subject, action, setting, narrative, *, w, h, fps, seconds):
    """The structured caption the SFT loader prefers, per docs/dataset_jsonl.md."""
    return {
        "subjects": [{"description": subject, "action": action}],
        "background_setting": setting,
        "cinematography": {"camera_motion": "static", "framing": "medium shot",
                           "camera_angle": "slightly angled top-down"},
        "actions": [{"time": f"0:00-0:{int(seconds):02d}", "description": action}],
        "temporal_caption": narrative,
        "resolution": {"H": h, "W": w},
        # Aspect ratio is a COMMA string here, exactly as at inference. "1:1"
        # and 1.0 are both rejected — the same trap as Lesson 06.
        "aspect_ratio": "16,9",
        "duration": f"{int(seconds)}s",
        "fps": fps,
    }


def windows_for(frames, *, window=WINDOW_FRAMES, stride=None):
    """Non-overlapping windows of at least `window` frames.

    Hint 1's second point: windows do not have to start at frame 0, and one
    clip can carry several. A 200-frame clip yields three 61-frame windows,
    which triples the record count from the same footage. The final partial
    window is DISCARDED rather than shortened — a 40-frame window is silently
    dropped by the loader, so emitting it would inflate the record count with
    records that never train on anything.
    """
    stride = stride or window
    out = []
    start = 0
    while start + window <= frames:
        out.append((start, start + window))
        start += stride
    return out


assert windows_for(200) == [(0, 61), (61, 122), (122, 183)]
assert windows_for(60) == []
assert windows_for(61) == [(0, 61)]
print("PASS window cutting: 200 frames -> 3 windows, 61 -> 1, 60 -> 0 "
      "(a short clip yields nothing, which is the honest answer)")


def make_record(uuid, *, seconds, w, h, fps, windows, subject, action,
                setting, narrative):
    return {
        "uuid": uuid,
        "duration": float(seconds),
        "width": w, "height": h,
        "vision_path": f"videos/{uuid}.mp4",
        "t2w_windows": [
            {"start_frame": start, "end_frame": end, "temporal_interval": 1,
             "caption_json": make_caption_json(subject, action, setting, narrative,
                                               w=w, h=h, fps=fps, seconds=seconds),
             "caption": narrative}
            for start, end in windows],
    }
''')

nb.code('''
# Step 2: captions. The reasoner if a NIM is up; the Lesson 03 scene records if
# one is not; a stated placeholder only as a last resort — and the source of
# every caption is recorded per clip, because a dataset whose captions came
# from three different places and does not say so is a dataset you cannot debug.
from cosmos_course.models import Reasoner
from cosmos_course.nim import NimConfig, nim_status

NIM = NimConfig()
NIM_READY = bool(nim_status(NIM).get("ready")) if shutil.which("docker") else False
reasoner = Reasoner(base_url=NIM.base_url) if NIM_READY else None

SCENE_RECORDS = {}
_l3 = cc.OUTPUT_ROOT / "03" / "scene_records.jsonl"
if _l3.exists():
    for line in _l3.read_text(encoding="utf-8").splitlines():
        if line.strip():
            row = json.loads(line)
            SCENE_RECORDS[row.get("source_file") or row.get("clip")] = row.get("record")

CAPTION_PROMPT = (
    "Describe this video as a structured scene record.\\n"
    "Reply with JSON only — no prose, no code fence.\\n"
    'Keys: {"subjects": ["..."], "setting": "...", "actions": ["..."], '
    '"lighting": "...", "camera": "..."}')


def caption_for(path):
    """Return (fields, source). Never raises."""
    if reasoner is not None:
        try:
            text = reasoner.ask(CAPTION_PROMPT, videos=path, fps=4,
                                max_tokens=1024, seed=0, temperature=0.0)
            rec = reasoner.parse_json(text)
            if isinstance(rec, dict):
                return rec, "reasoner NIM"
        except Exception as exc:
            print(f"  reasoner failed on {Path(path).name}: {type(exc).__name__}")
    rec = SCENE_RECORDS.get(Path(path).name)
    if rec:
        return rec, "outputs/03 scene record"
    return ({"subjects": ["PLACEHOLDER — no caption source available"],
             "setting": "PLACEHOLDER", "actions": ["PLACEHOLDER"],
             "lighting": "PLACEHOLDER", "camera": "static"},
            "PLACEHOLDER (no NIM, no Lesson 03 records)")


print(f"NIM ready: {NIM_READY}   Lesson 03 records: {len(SCENE_RECORDS)}")
''')

nb.code('''
# Step 1: collect clips. Real ones from Modules 2 if they exist; otherwise
# build synthetic ones with ffmpeg so the pipeline and the validator are
# exercised end to end. Synthetic clips are marked, and their captions are
# marked, so nothing here can be mistaken for a real dataset.
CLIPS = sorted(list((cc.OUTPUT_ROOT / "07").rglob("*.mp4"))
               + list((cc.OUTPUT_ROOT / "08").rglob("*.mp4")))
SYNTHETIC = False
if len(CLIPS) < 6 and shutil.which("ffmpeg"):
    SYNTHETIC = True
    synth_dir = OUTPUT_DIR / "synthetic_clips"
    synth_dir.mkdir(parents=True, exist_ok=True)
    CLIPS = []
    # Durations chosen to exercise BOTH filters: two clips are too short to
    # yield a 61-frame window, and one is over the 61-second ceiling.
    plan = [("ok_a", 4.0), ("ok_b", 5.0), ("ok_c", 6.0), ("ok_d", 9.0),
            ("ok_e", 4.0), ("ok_f", 5.0), ("too_short", 1.5), ("too_long", 62.0)]
    for name, seconds in plan:
        path = synth_dir / f"{name}.mp4"
        if not path.exists():
            subprocess.run(
                ["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi",
                 "-i", f"testsrc=size=256x144:rate=24:duration={seconds}",
                 "-c:v", "libx264", "-crf", "28", "-pix_fmt", "yuv420p", str(path)],
                check=True, capture_output=True, text=True, timeout=600)
        CLIPS.append(path)
    print(f"SYNTHETIC CLIPS: {len(CLIPS)} generated with ffmpeg testsrc, because "
          f"fewer than six real clips were found in outputs/07 and outputs/08. "
          f"They exercise the pipeline; they are not training data.")

print(f"{len(CLIPS)} clip(s)")
for path in CLIPS[:10]:
    info = probe(path)
    print(f"  {path.name:<16} " + (f"{info['duration']:>6.2f}s "
          f"{info['fps']:>5.1f} fps {info['frames']:>5} frames "
          f"{info['width']}x{info['height']}"
          f"{'' if info['frames_trustworthy'] else '  (nb_frames untrustworthy)'}"
          if info else "ffprobe unavailable"))
''')

nb.code('''
# Step 4: PREDICT the drop counts BEFORE validating. Written down here so the
# comparison afterwards is a test rather than a description.
predictions = {"clips_dropped_too_long": 0, "clips_dropped_no_window": 0,
               "records_expected": 0, "windows_expected": 0}
probed = {}
for path in CLIPS:
    info = probe(path)
    probed[path] = info
    if info is None:
        continue
    if info["duration"] > MAX_CLIP_SECONDS:
        predictions["clips_dropped_too_long"] += 1
        continue
    wins = windows_for(info["frames"])
    if not wins:
        predictions["clips_dropped_no_window"] += 1
        continue
    predictions["records_expected"] += 1
    predictions["windows_expected"] += len(wins)

print("PREDICTED BEFORE VALIDATION:")
for key, value in predictions.items():
    print(f"  {key:<28}{value:>4}")
''')

nb.code('''
DATASET_DIR.mkdir(parents=True, exist_ok=True)
VIDEO_DIR.mkdir(parents=True, exist_ok=True)

records, excluded = [], []
for path in CLIPS:
    info = probed.get(path)
    if info is None:
        excluded.append({"clip": str(path), "reason": "ffprobe unavailable or failed"})
        continue
    if info["duration"] > MAX_CLIP_SECONDS:
        excluded.append({"clip": str(path),
                         "reason": f"duration {info['duration']:.1f}s exceeds the "
                                   f"loader's {MAX_CLIP_SECONDS}s ceiling; the "
                                   f"record would load and yield nothing"})
        continue
    wins = windows_for(info["frames"])
    if not wins:
        excluded.append({"clip": str(path),
                         "reason": f"{info['frames']} frames yields no window of "
                                   f"{WINDOW_FRAMES}; every window would be "
                                   f"silently dropped"})
        continue
    if not info["frames_trustworthy"]:
        excluded.append({"clip": str(path),
                         "reason": f"nb_frames ({info['frames_declared']}) and "
                                   f"duration x fps ({info['frames_derived']}) "
                                   f"disagree by more than one frame; windows "
                                   f"derived from either could run past the end"})
        continue

    uuid = path.stem
    fields, source = caption_for(path)
    subjects = fields.get("subjects") or ["unspecified subject"]
    actions = fields.get("actions") or ["unspecified action"]
    narrative = (f"{subjects[0]} in {fields.get('setting', 'an unspecified setting')}; "
                 f"{'; then '.join(str(a) for a in actions[:3])}. "
                 f"Lighting: {fields.get('lighting', 'unspecified')}.")
    record = make_record(uuid, seconds=info["duration"], w=info["width"],
                         h=info["height"], fps=info["fps"], windows=wins,
                         subject=str(subjects[0]),
                         action=str(actions[0]),
                         setting=str(fields.get("setting", "unspecified")),
                         narrative=narrative)
    record["caption_source"] = source
    record["synthetic_clip"] = SYNTHETIC
    records.append(record)
    target = VIDEO_DIR / f"{uuid}.mp4"
    if not target.exists():
        shutil.copy2(path, target)

with JSONL_PATH.open("w", encoding="utf-8") as fh:
    for rec in records:
        fh.write(json.dumps(rec, ensure_ascii=False) + "\\n")
EXCLUDED_PATH.write_text(json.dumps(
    {"started_with": len(CLIPS), "kept": len(records), "excluded": excluded},
    indent=2) + "\\n", encoding="utf-8")

print(f"wrote {JSONL_PATH}  ({len(records)} records, "
      f"{sum(len(r['t2w_windows']) for r in records)} windows)")
print(f"wrote {EXCLUDED_PATH} ({len(excluded)} excluded)")
for item in excluded:
    print(f"  {Path(item['clip']).name}: {item['reason'][:78]}")
assert len(records) + len(excluded) == len(CLIPS), "a clip vanished"
print("\\nPASS excluded.json accounts for every clip we started with")
''')

nb.code('''
report = finetune.check_dataset(DATASET_DIR, kind="jsonl")
print(json.dumps(report, indent=2))
print()

stats = report["stats"]
print(f"{'':<32}{'predicted':>10}{'reported':>10}")
comparisons = [
    ("records", predictions["records_expected"], stats.get("records")),
    ("clips_over_61s", 0, stats.get("clips_over_61s")),
    ("windows_under_61_frames", 0, stats.get("windows_under_61_frames")),
]
for name, predicted, reported in comparisons:
    mark = "ok" if predicted == reported else "MISMATCH"
    print(f"{name:<32}{predicted:>10}{str(reported):>10}   {mark}")
    assert predicted == reported, (name, predicted, reported)

assert report["ok"], report["problems"] + report["warnings"]
assert stats["clips_over_61s"] == 0 and stats["windows_under_61_frames"] == 0
assert stats["records"] >= 6, f"only {stats['records']} records"
print("\\nPASS ok=True, both filters report zero, at least six records, and the "
      "predicted drop counts match the reported ones")
print()
print("Caption provenance, recorded per record so a mixed dataset is debuggable:")
for source in sorted({r["caption_source"] for r in records}):
    n = sum(1 for r in records if r["caption_source"] == source)
    print(f"  {n:>3} record(s): {source}")
''')

nb.why(
    "**Why the drop counts are predicted before the validator runs.** Step 4 asks for it "
    "and the value is that it converts `check_dataset` from a *description* into a "
    "*test*. If your prediction is 6 records and the validator says 4, you have "
    "misunderstood one of the two filters — and finding that out now costs a minute, "
    "whereas finding it out from a training run that consumed nothing costs an hour and "
    "looks like a model problem. The assertions above make the mismatch stop the "
    "notebook.\n\n"
    "**Why the frame count is computed twice.** Hint 1 warns that `nb_frames` is missing "
    "or wrong for a surprising number of MP4 files, and the consequence is specific: a "
    "window cut against a wrong frame count runs past the end of the file, and the loader "
    "drops it *silently*. Cross-checking against `duration x fps` and **excluding the "
    "clip when the two disagree by more than one frame** is stricter than necessary — a "
    "decode would settle it — and it is the right default for an unattended pipeline, "
    "because the alternative failure is invisible. The exclusion reason says so, so a "
    "human can override it.\n\n"
    "**Why several windows per clip, and why the last partial one is discarded.** A "
    "200-frame clip carries three 61-frame windows, which triples the record count from "
    "the same footage — that is free data. The temptation is to keep the 17-frame "
    "remainder; the loader will drop it, so keeping it inflates your record count with "
    "records that train on nothing. A dataset that reports 40 windows and trains on 30 is "
    "worse than one that reports 30, because the first number is the one you will use "
    "when reasoning about your learning rate schedule.\n\n"
    "**Why caption provenance is stored per record.** The exercise allows three caption "
    "sources — the live reasoner, Lesson 03's saved records, or nothing — and a dataset "
    "silently mixing them is one you cannot debug. If half your captions came from a "
    "model and half are placeholders, the model will learn the difference, and the only "
    "way to find out afterwards is to have recorded it. This is the same principle as "
    "Lesson 05's marks carrying the name that produced them: **provenance is what makes "
    "a mixed artefact debuggable.**\n\n"
    "**On the aspect ratio in `caption_json`.** It is `\"16,9\"` — a comma string. `16:9` "
    "and `1.777` are both rejected, and this is the same trap the Lesson 06 debugging lab "
    "is built around, appearing again in a different file format. Traps that recur in two "
    "places are worth encoding in a helper, which is what `make_caption_json` is."
)

nb.extend(
    "The dataset here is built from clips that already exist. The step that makes it "
    "genuinely useful is a **round-trip check**: fine-tune on it, generate from one of "
    "the training captions, and caption the generated clip with the same reasoner and "
    "schema. Fields that survive that loop are fields the model actually learned to "
    "condition on; fields that do not are labels with no signal behind them — the same "
    "diagnosis Lesson 06's ablation exercise reached by a different route, and the same "
    "consequence: stop emitting them."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "A fine-tuning feasibility planner",
    goal="Write `plan_finetune(model, gpus, vram_gb)` returning a configuration that will "
         "fit or an explanation of why none exists, and test it across a hardware matrix.",
    success="Every matrix cell returns a verdict with reasoning; Nano on 1x80 recommends "
            "LoRA or refuses; Super on 1x80 refuses naming the bf16 weights; Nano on "
            "16x80 recommends full SFT; and one disagreement with your own planner is "
            "written down.",
    approach="Check the immovable floor first and label it a *hardware* problem, then try "
             "the three strategies in order, and require a stated activation floor rather "
             "than merely a non-negative remainder.",
)

nb.code('''
def plan_finetune(model, gpus, vram_gb, *, reserve_gb=4.0, min_activation_gb=10.0):
    """Return a feasible SFT configuration, or explain why none exists."""
    tier = cc.MODEL_TIERS[model]
    total_b = float(tier["params_total_b"])
    reasoning = []
    usable_gb = vram_gb - reserve_gb

    # The floor no software setting can move: bf16 weights must be resident.
    # FSDP shards them across ranks, so more GPUs DO help here — but on a fixed
    # GPU count nothing else does.
    weights_gb = total_b * 2 / gpus
    reasoning.append(
        f"bf16 weights: {total_b:.0f}B x 2 bytes / {gpus} rank(s) = "
        f"{weights_gb:.1f} GB against {usable_gb:.1f} GB usable")
    if weights_gb > usable_gb:
        return {"feasible": False, "strategy": "none", "settings": {},
                "state_gb": weights_gb, "activation_budget_gb": 0.0,
                "blocker": "bf16 weights",
                "reasoning": reasoning + [
                    f"REFUSED. The weights alone are {weights_gb:.1f} GB per rank, "
                    f"which exceeds the {usable_gb:.1f} GB usable. This is a "
                    f"WRONG-HARDWARE problem, not a tuning problem: LoRA, "
                    f"activation checkpointing, a smaller batch and a lower token "
                    f"cap all attack optimizer state or activations, and none of "
                    f"them touches this row. The only fixes are more GPUs "
                    f"({math.ceil(total_b * 2 / usable_gb)} would hold the weights) "
                    f"or a smaller checkpoint."]}

    attempts = [
        ("full", dict(trainable_fraction=1.0, ema=False),
         {"optimizer.keys_to_select": "[] (everything trains)",
          "model.ema.enabled": False}),
        ("frozen", dict(trainable_fraction=0.5, ema=False),
         {"optimizer.keys_to_select": '["moe_gen","time_embedder","vae2llm",'
                                      '"llm2vae","k_norm_und_for_gen"]',
          "model.ema.enabled": False}),
    ] + [
        (f"lora", dict(lora=True, lora_rank=rank, ema=False),
         {"model.lora_enabled": True, "model.lora_rank": rank,
          "model.lora_alpha": rank * 2,
          "optimizer.keys_to_select": '["lora_"]',
          "model.ema.enabled": False})
        for rank in (16, 8, 4)
    ]

    for strategy, kwargs, settings in attempts:
        est = finetune.estimate_sft_memory(model=model, card_gb=vram_gb,
                                           reserve_gb=reserve_gb,
                                           world_size=gpus, **kwargs)
        label = strategy + (f" r={kwargs['lora_rank']}" if kwargs.get("lora") else "")
        reasoning.append(f"{label}: state {est.state_gb:.1f} GB, leaves "
                         f"{est.activation_budget_gb:.1f} GB for activations")
        if est.activation_budget_gb >= min_activation_gb:
            return {"feasible": True, "strategy": strategy, "settings": settings,
                    "state_gb": round(est.state_gb, 1),
                    "activation_budget_gb": round(est.activation_budget_gb, 1),
                    "blocker": None,
                    "reasoning": reasoning + [
                        f"ACCEPTED {label}: {est.activation_budget_gb:.1f} GB of "
                        f"activation headroom clears the {min_activation_gb:.0f} GB "
                        f"floor. NOTE: this says the STATE fits. It says nothing "
                        f"about whether the resulting run learns anything."]}
        if est.activation_budget_gb > 0:
            reasoning.append(f"  rejected: {est.activation_budget_gb:.1f} GB is "
                             f"below the {min_activation_gb:.0f} GB activation floor")

    return {"feasible": False, "strategy": "none", "settings": {},
            "state_gb": round(est.state_gb, 1),
            "activation_budget_gb": round(est.activation_budget_gb, 1),
            "blocker": "optimizer state",
            "reasoning": reasoning + [
                "REFUSED. The weights fit but no strategy leaves "
                f"{min_activation_gb:.0f} GB for activations. Unlike the weights "
                "case this IS a tuning problem in principle — a lower token cap "
                "would need less activation memory — but the planner will not "
                "recommend a configuration whose headroom it cannot defend."]}
''')

nb.code('''
MATRIX = [(m, g, v)
          for m in ("Cosmos3-Edge", "Cosmos3-Nano", "Cosmos3-Super")
          for g, v in ((1, 24), (1, 80), (4, 80), (8, 80), (16, 80), (8, 141))]

print(f"{'model':<15}{'gpus':>5}{'vram':>6}{'feasible':>10}{'strategy':>10}"
      f"{'state GB':>10}{'act GB':>9}  blocker")
print("-" * 88)
results = {}
for model, gpus, vram in MATRIX:
    plan = plan_finetune(model, gpus, vram)
    results[(model, gpus, vram)] = plan
    print(f"{model:<15}{gpus:>5}{vram:>6}{str(plan['feasible']):>10}"
          f"{plan['strategy']:>10}{plan['state_gb']:>10.1f}"
          f"{plan['activation_budget_gb']:>9.1f}  {plan['blocker'] or ''}")

# The three verdicts the success criteria name.
nano_1x80 = results[("Cosmos3-Nano", 1, 80)]
assert (not nano_1x80["feasible"]) or nano_1x80["strategy"] == "lora", nano_1x80
print(f"\\nPASS Nano on 1x80: {nano_1x80['strategy']} "
      f"(feasible={nano_1x80['feasible']})")

super_1x80 = results[("Cosmos3-Super", 1, 80)]
assert not super_1x80["feasible"] and super_1x80["blocker"] == "bf16 weights", super_1x80
print(f"PASS Super on 1x80: refused, blocker = {super_1x80['blocker']!r} "
      f"(not the optimizer state)")

nano_16x80 = results[("Cosmos3-Nano", 16, 80)]
assert nano_16x80["feasible"] and nano_16x80["strategy"] == "full", nano_16x80
print(f"PASS Nano on 16x80: {nano_16x80['strategy']} SFT — which is exactly the "
      f"shape of the shipped HSDP 2x8 recipe")
''')

nb.code('''
# Every row deserves reading. Print the reasoning for the three rows that carry
# the most information, and for the one that should make you uncomfortable.
for key in [("Cosmos3-Super", 1, 80), ("Cosmos3-Edge", 1, 24),
            ("Cosmos3-Nano", 4, 80)]:
    model, gpus, vram = key
    plan = results[key]
    print(f"=== {model} on {gpus}x{vram} GB ===")
    for line in plan["reasoning"]:
        print(f"  {line}")
    print()
''')

nb.model_answer(
    "**One case where I disagree with my own planner, and why.**\n\n"
    "**`plan_finetune(\"Cosmos3-Nano\", 4, 80)` returns feasible, and I would not run "
    "it.** The planner is arithmetically right and answering the wrong question.\n\n"
    "Hint 1 points at exactly this row, and the disagreement is worth being precise "
    "about. What the planner computes is whether the *state* fits: weights, master "
    "copy, optimizer moments, gradients, EMA. On four ranks with a restricted trainable "
    "set that arithmetic comes out positive with headroom to spare, so it says yes. What "
    "it cannot compute is whether the resulting run **learns anything**, and that depends "
    "on things nowhere in its inputs:\n\n"
    "- **Global batch size.** Four ranks at a token cap low enough to fit gives a much "
    "smaller global batch than the shipped 8- or 16-rank recipe. The shipped learning "
    "rate was chosen for that batch. Keeping the LR and shrinking the batch is a "
    "different optimisation problem, and the usual outcome is a noisier trajectory that "
    "needs more iterations to reach the same loss — or does not reach it.\n"
    "- **Iteration budget.** `COSMOS3_FACTS.md` §5 records the LIBERO action recipe at "
    "2000 iterations on 16 GPUs. The same 2000 iterations on 4 GPUs is a quarter of the "
    "samples. Whether that is enough is an empirical question about the task, and the "
    "planner has never seen the task.\n"
    "- **Whether the restricted trainable set contains what needs to change.** "
    "`keys_to_select` freezes the reasoner tower. If your adaptation needs the reasoner "
    "to change, a configuration that fits beautifully will train the wrong parameters "
    "and converge to a model that is no better than the one you started with.\n\n"
    "**So the planner should not be changed to say no here — it should say what it "
    "means.** Every accepted plan's reasoning ends with *\"this says the STATE fits. It "
    "says nothing about whether the resulting run learns anything.\"* That is the honest "
    "boundary of a memory calculator, and hint 1 makes the same point: it should say so "
    "rather than imply otherwise. A planner that quietly extended its authority from "
    "\"fits\" to \"works\" would be more useful-sounding and less useful.\n\n"
    "**The second uncomfortable row: `Cosmos3-Edge` on `1x24`.** The planner refuses or "
    "recommends LoRA, and my intuition says a 4B model should fine-tune on a 24 GB card. "
    "The intuition is wrong, and working out why is instructive: 4B in bf16 is 8 GB of "
    "weights before anything else, and full SFT adds 4B x 18 = 72 GB of state. The "
    "intuition was formed on *inference*, where 4B at bf16 is comfortable, and it does "
    "not transfer to training, where every trainable parameter costs 22 bytes instead of "
    "2. The eleven-fold ratio between those two numbers is the single most useful fact "
    "in this lesson.\n\n"
    "**Why the bf16-weights refusal is a different kind of refusal.** The exercise "
    "insists on this and it deserves the emphasis. \"State is too big\" is a tuning "
    "problem: lower the token cap, disable EMA, freeze more, use LoRA. \"The weights "
    "alone exceed the card\" is a hardware problem, and every one of those levers does "
    "nothing — they all attack optimizer state or activations. Telling a user to try "
    "LoRA when their weights do not fit sends them to spend an afternoon on something "
    "that cannot work, which is worse than saying no. The planner therefore returns the "
    "number of GPUs that *would* hold the weights, because that is the only actionable "
    "thing left to say."
)

nb.extend(
    "The planner's `min_activation_gb=10.0` is the one number in it that is asserted "
    "rather than derived, and it is doing a lot of work — it is what turns \"state fits\" "
    "into \"a run is plausible\". Replacing it with a *model* would be the real "
    "improvement: activation memory is roughly linear in "
    "`max_num_tokens_after_packing`, so one measured point from Lesson 17 gives you a "
    "line, and the planner could then return the token cap that fits the remaining "
    "budget instead of a pass/fail against a guess. That converts the output from "
    "\"feasible: true\" into \"feasible at token_cap <= 12288\", which is a "
    "configuration rather than an opinion."
)

nb.finish()
