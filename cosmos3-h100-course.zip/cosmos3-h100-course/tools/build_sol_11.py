"""Build solutions/11_solutions.ipynb — reference answers for Lesson 11."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("11", "Action: inverse dynamics",
                      lesson_file="11_action_inverse_dynamics.ipynb")

nb.header(
    "Inverse dynamics recovers actions from video, and the hard part is not running it — "
    "it is knowing whether the answer is right. The foundation exercise gets a real "
    "error number by comparing against a trajectory **you commanded**, which the cookbook "
    "clips cannot give you. The applied one builds a metric that treats rotation "
    "properly, and discovers that one of its two components is comparable across "
    "datasets and the other is not. The challenge one turns the round trip into a "
    "harness and then names the failure a round trip is structurally unable to see."
)

nb.callout(
    "warning",
    "**Needs Cosmos3-Nano and the cookbook action assets**, gated behind "
    "`ALLOW_NANO_DOWNLOAD` exactly as the lesson gates it. The pose composition, the "
    "alignment logic, the geodesic metric and its self-tests, and the harness's "
    "statistics are all pure numpy and run and are verified here. Where a model run is "
    "needed, the cell reports what it would have done.",
)

nb.prelude("The lesson's configuration, pose helpers and spec builders.")
nb.code(setup_cell("11"))

nb.code('''
import json
import math
import subprocess
import time

import numpy as np

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

from cosmos_course.models import Generator

ACTION_MODEL = "Cosmos3-Nano"
ALLOW_NANO_DOWNLOAD = os.environ.get("COSMOS_COURSE_ALLOW_NANO", "0") == "1"
gen = cc.Generator(checkpoint=ACTION_MODEL)
framework_problems = gen.check(verbose=False)

MODE_CHUNK = 30 if MODE == "reduced" else 60
TIMEOUT_S = 1800 if MODE == "reduced" else 3600
AV_PROMPT = "You are an autonomous vehicle planning system."
RUN = ALLOW_NANO_DOWNLOAD and not framework_problems and DEVICE.startswith("cuda")

print(f"RUN = {RUN}   action_chunk_size = {MODE_CHUNK} (MODE={MODE})")
for p in framework_problems:
    print(f"  ! {p}")

assets = {n: cc.asset_or_none(n) for n in
          ("av_video", "av_video_2", "av_traj_forward", "av_start_frame")}
print("assets:", {k: (v.name if v else None) for k, v in assets.items()})
''')

nb.code('''
def rot6d_to_matrix_gram_schmidt(vec6):
    """The textbook 6-D decode: two columns, orthonormalised, third by cross."""
    a = np.asarray(vec6[:3], dtype=np.float64)
    b = np.asarray(vec6[3:6], dtype=np.float64)
    c0 = a / (np.linalg.norm(a) or 1.0)
    b_perp = b - (c0 @ b) * c0
    c1 = b_perp / (np.linalg.norm(b_perp) or 1.0)
    c2 = np.cross(c0, c1)
    return np.stack([c0, c1, c2], axis=-1)         # COLUMNS, not rows


def my_pose_rel_to_abs(poses_rel, *, translation_scale=1.0, initial_pose=None):
    """Compose relative deltas into absolute poses. Returns [T+1, 4, 4]."""
    poses_rel = np.asarray(poses_rel, dtype=np.float64)
    current = np.eye(4) if initial_pose is None else np.asarray(initial_pose, float)
    out = [current]
    for row in poses_rel:
        delta = np.eye(4)
        delta[:3, :3] = rot6d_to_matrix_gram_schmidt(row[3:9])
        delta[:3, 3] = row[:3] / translation_scale
        current = current @ delta
        out.append(current)
    return np.asarray(out)


def inverse_spec(clip, *, name, chunk=None, seed=0, fps=10, image_size=480,
                 domain_name="av"):
    """An inverse_dynamics spec. No action_path: the action is the OUTPUT."""
    return cc.InferenceSpec(
        model_mode="inverse_dynamics", name=name, prompt=AV_PROMPT,
        vision_path=str(clip), domain_name=domain_name, view_point="ego_view",
        action_chunk_size=chunk or MODE_CHUNK, fps=fps, image_size=image_size,
        seed=seed)


def forward_spec(start_frame, action_path, *, name, chunk=None, seed=0, fps=10,
                 image_size=480, domain_name="av"):
    return cc.InferenceSpec(
        model_mode="forward_dynamics", name=name, prompt=AV_PROMPT,
        vision_path=str(start_frame), action_path=str(action_path),
        domain_name=domain_name, view_point="ego_view",
        action_chunk_size=chunk or MODE_CHUNK, fps=fps, image_size=image_size,
        seed=seed)


def run_spec(spec, subdir, *, label=None):
    label = label or spec.name
    if not RUN:
        print(f"skipped {label!r}: generation is disabled")
        return None, None
    with cc.timer(label, track_memory=False, quiet=True) as t:
        result = gen.run(spec, OUTPUT_DIR / subdir, seed=spec.seed or 0,
                         timeout=TIMEOUT_S)
    cc.verify_result(result)
    return result, t.seconds


def read_predicted_actions(result):
    """Pull the predicted action array out of a RunResult, or None."""
    if result is None:
        return None
    for path in result.jsons:
        try:
            arr = np.asarray(json.loads(Path(path).read_text()), dtype=np.float64)
        except Exception:
            continue
        if arr.ndim == 2 and arr.shape[1] in (9, 10, 29):
            return arr
    return None


# Check the pose composition against a hand calculation before using it.
def yaw_rot6d(degrees):
    th = np.radians(degrees)
    R = np.array([[np.cos(th), 0.0, np.sin(th)],
                  [0.0, 1.0, 0.0],
                  [-np.sin(th), 0.0, np.cos(th)]])
    return np.concatenate([R[:, 0], R[:, 1]])


toy = np.array([np.concatenate([[0.0, 0.0, 1.0], yaw_rot6d(0)]),
                np.concatenate([[0.0, 0.0, 0.0], yaw_rot6d(90)]),
                np.concatenate([[0.0, 0.0, 1.0], yaw_rot6d(0)])])
assert np.allclose(my_pose_rel_to_abs(toy)[-1][:3, 3], [1.0, 0.0, 1.0], atol=1e-9)
print("PASS pose composition matches the hand calculation "
      "(forward 1, turn 90, forward 1 -> [1, 0, 1])")
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Recovered against commanded, step by step",
    goal="Get a real error number by comparing a recovered trajectory against a "
         "trajectory you know, because you commanded it.",
    success="A per-step error plot, both trajectories on one bird's-eye view, and a "
            "written answer distinguishing per-step noise from accumulating drift.",
    approach="Truncate to the shorter length, never pad; and report **both** per-step "
             "error and integrated position error, because the pair is what "
             "distinguishes noise from drift.",
)

nb.code('''
LESSON_10_VIDEO = cc.OUTPUT_ROOT / "10" / "av_forward" / "av_forward" / "vision.mp4"
COMMANDED = (np.asarray(json.loads(assets["av_traj_forward"].read_text()),
                        dtype=np.float64)
             if assets["av_traj_forward"] else None)
print("commanded:", None if COMMANDED is None else COMMANDED.shape)
print("lesson 10 video present:", LESSON_10_VIDEO.exists())
if not LESSON_10_VIDEO.exists():
    print("  -> run Lesson 10 first, or point this at any forward-dynamics output")


def align(commanded, recovered):
    """Truncate both to the shorter length. Returns (a, b, note).

    Hint 2's rule, and the reason it is a rule rather than a preference:
    padding the shorter array with zero rows would insert steps that say 'did
    not move'. Those are not missing data, they are INVENTED data, and they
    drag the mean error towards whatever the other array does at those steps —
    usually downwards, because a stationary step is easy to match. Truncation
    discards real information; padding manufactures fake information. Discarding
    is the honest loss.

    The length mismatch is itself informative: `action_chunk_size` decides how
    many steps come back and the video has however many frames it has, so a
    mismatch tells you those two disagree, which is worth knowing.
    """
    a = np.asarray(commanded, dtype=np.float64)
    b = np.asarray(recovered, dtype=np.float64)
    n = min(a.shape[0], b.shape[0])
    note = (f"aligned by truncation to {n} steps "
            f"(commanded {a.shape[0]}, recovered {b.shape[0]})")
    return a[:n], b[:n], note


def per_step_translation_error(commanded, recovered):
    """Euclidean distance between commanded and recovered translation, per step."""
    a, b, note = align(commanded, recovered)
    return np.linalg.norm(a[:, :3] - b[:, :3], axis=1), note


# Verify the alignment and the error function on arrays whose answer is known.
_a = np.zeros((5, 9)); _a[:, 2] = 1.0
_b = _a.copy(); _b[:, 2] = 1.5
err, note = per_step_translation_error(_a, _b[:3])
assert err.shape == (3,) and np.allclose(err, 0.5), (err, note)
print("PASS per-step error is exact and alignment truncates to the shorter array")
print("    ", note)
''')

nb.code('''
recovered = None
if LESSON_10_VIDEO.exists():
    # Same domain_name, fps and image_size as the run that MADE the video.
    # Changing any of them here would introduce a second variable and the
    # error would no longer be attributable to the model.
    result, seconds = run_spec(
        inverse_spec(LESSON_10_VIDEO, name="inv_of_lesson10",
                     chunk=min(MODE_CHUNK, len(COMMANDED) if COMMANDED is not None
                               else MODE_CHUNK)),
        "inverse_l10", label="inv_of_lesson10")
    recovered = read_predicted_actions(result)

if recovered is None:
    # PLACEHOLDER RECOVERY — invented. Built as the commanded trajectory plus a
    # small zero-mean per-step perturbation AND a small constant bias, because
    # that combination is what makes the noise-versus-drift question in step 6
    # non-trivial. NOT a measurement of Cosmos 3.
    if COMMANDED is None:
        COMMANDED = np.zeros((30, 9))
        COMMANDED[:, 2] = 0.04
        COMMANDED[:, 3] = COMMANDED[:, 7] = 1.0
    rng = np.random.default_rng(11)
    recovered = COMMANDED.copy()
    recovered[:, :3] += rng.normal(0, 0.0035, (COMMANDED.shape[0], 3))
    recovered[:, 2] += 0.0015                     # a small systematic bias
    print("PLACEHOLDER RECOVERED TRAJECTORY — invented, not a model output.\\n")

errors, note = per_step_translation_error(COMMANDED, recovered)
print(note)
print(f"per-step translation error: mean {errors.mean():.5f}  "
      f"median {np.median(errors):.5f}  max {errors.max():.5f}")

# Hint 1: per-step error and accumulated error are different measurements.
a, b, _ = align(COMMANDED, recovered)
pos_cmd = my_pose_rel_to_abs(a)[:, :3, 3]
pos_rec = my_pose_rel_to_abs(b)[:, :3, 3]
accumulated = np.linalg.norm(pos_cmd - pos_rec, axis=1)
print(f"accumulated position error: first {accumulated[1]:.5f}  "
      f"final {accumulated[-1]:.5f}")

# The diagnostic that separates the two answers to step 6: does accumulated
# error grow like sqrt(n) (random walk from unbiased noise) or like n (drift
# from a systematic bias)? Fit both and compare.
n = np.arange(1, len(accumulated))
obs = accumulated[1:]
k_sqrt = float((obs @ np.sqrt(n)) / (np.sqrt(n) @ np.sqrt(n)))
k_lin = float((obs @ n) / (n @ n))
res_sqrt = float(np.sum((obs - k_sqrt * np.sqrt(n)) ** 2))
res_lin = float(np.sum((obs - k_lin * n) ** 2))
print(f"\\nfit residual, sqrt(n) model (unbiased noise): {res_sqrt:.6f}")
print(f"fit residual, linear   model (systematic bias): {res_lin:.6f}")
print(f"better fit: {'LINEAR — a bias is accumulating' if res_lin < res_sqrt else 'SQRT — the error looks like unbiased noise'}")
''')

nb.code('''
if plt is not None:
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    axes[0].plot(errors, "o-", ms=3, color="#1971c2")
    axes[0].axhline(errors.mean(), ls="--", lw=1, color="#c92a2a",
                    label=f"mean {errors.mean():.4f}")
    axes[0].set_xlabel("step")
    axes[0].set_ylabel("|commanded - recovered| translation")
    axes[0].set_title("per-step error", fontsize=10)
    axes[0].legend(fontsize=8)

    axes[1].plot(accumulated, "o-", ms=3, color="#2b8a3e", label="observed")
    axes[1].plot(np.arange(len(accumulated)),
                 np.concatenate([[0], k_sqrt * np.sqrt(n)]), "--", lw=1,
                 label="sqrt(n) fit")
    axes[1].plot(np.arange(len(accumulated)),
                 np.concatenate([[0], k_lin * n]), ":", lw=1.5, label="linear fit")
    axes[1].set_xlabel("step")
    axes[1].set_ylabel("|position difference|")
    axes[1].set_title("accumulated error, with both models", fontsize=10)
    axes[1].legend(fontsize=8)

    # Bird's-eye: X across, Z forward. Both trajectories, same axes.
    axes[2].plot(pos_cmd[:, 0], pos_cmd[:, 2], "o-", ms=3, label="commanded")
    axes[2].plot(pos_rec[:, 0], pos_rec[:, 2], "s-", ms=3, label="recovered")
    axes[2].set_xlabel("X (lateral)")
    axes[2].set_ylabel("Z (forward)")
    axes[2].set_title("bird's-eye view", fontsize=10)
    axes[2].axis("equal")
    axes[2].legend(fontsize=8)
    fig.suptitle("PLACEHOLDER DATA — not a measurement" if recovered is None else "",
                 fontsize=9)
    plt.tight_layout()
    plt.show()
else:
    print("matplotlib not installed; the numbers above are the plots.")
''')

nb.model_answer(
    "**Is the error roughly constant per step, or growing? What does each answer "
    "imply?**\n\n"
    "These are two different questions and the exercise is asking you to notice that the "
    "*per-step* plot and the *accumulated* plot answer different ones. The per-step error "
    "will look roughly constant almost regardless of what is happening, because each row "
    "is estimated from a short window of frames and those estimates are near-independent. "
    "Constant per-step error is the null result, not a finding.\n\n"
    "The informative question is what the **accumulated** error does, and there are two "
    "shapes with completely different meanings:\n\n"
    "**Growing like sqrt(n): unbiased per-step noise.** Independent zero-mean errors "
    "compose into a random walk, whose expected displacement grows as the square root of "
    "the number of steps. This is the benign case. It says the estimator is *unbiased* — "
    "it is as likely to over-estimate as under-estimate each step — and the accumulated "
    "error is the unavoidable consequence of integrating noise. Practical implication: "
    "the recovered trajectory is usable over short horizons and degrades gracefully. "
    "Halving the per-step noise halves the drift at any horizon.\n\n"
    "**Growing linearly: a systematic bias.** A constant offset in every step — the "
    "estimator consistently reports 3% more forward motion than was commanded — "
    "accumulates linearly and dominates the random walk after a handful of steps. This is "
    "the serious case, and it is serious because *it does not average out*. More data "
    "does not help. Practical implication: the trajectory is unusable for anything "
    "requiring absolute position, and — crucially — the bias is a *fixable* problem, "
    "because a constant offset can be calibrated out once you have measured it. That is "
    "the argument for doing this experiment at all.\n\n"
    "The cell above fits both models and reports which residual is smaller, which turns "
    "\"is it growing\" into a comparison rather than an impression. At thirty steps the "
    "two shapes are not enormously different (sqrt(30) ≈ 5.5 versus 30), so this "
    "discrimination is weak on a short clip and gets much stronger on a long one — which "
    "is itself a reason to run the experiment on the longest trajectory you have.\n\n"
    "**The third possibility, which both models miss:** a *scale* error. If the estimator "
    "recovers the right direction and a consistently wrong magnitude, accumulated error "
    "grows linearly and looks exactly like a bias, but the fix is different — it is "
    "`translation_scale`, not a calibration offset. The way to tell them apart is to "
    "regress recovered against commanded per-step magnitude: a scale error gives a slope "
    "away from 1 with a near-zero intercept; a bias gives a slope near 1 with a non-zero "
    "intercept. Exercise 2 makes exactly this distinction load-bearing.\n\n"
    "**Why this exercise needs a video you generated.** The cookbook clips have no "
    "ground truth. Any error you compute on them is a comparison between the model and "
    "itself. A clip generated in Lesson 10 from a trajectory you wrote is the only "
    "ground truth available on a single machine, and it is the entire reason the "
    "exercises are ordered this way."
)

nb.extend(
    "The comparison here is one trajectory against one recovery. The version worth "
    "running is the same commanded trajectory recovered at three `action_chunk_size` "
    "values. Chunk size sets how many frames the estimator sees per action, so it trades "
    "temporal resolution against per-step noise, and there should be a minimum in "
    "accumulated error somewhere in the middle. Finding it costs three runs and gives "
    "you a defensible default for every later experiment — which is more valuable than "
    "another error number at the chunk size you happened to pick."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "An action-space metric",
    goal="Build a metric that compares two action sequences properly, including the "
         "rotation part, and use it on two different clips.",
    success="The metric passes both self-tests, is reported for two clips, and you have "
            "written down which component is scale-dependent and what that means for "
            "comparing across datasets.",
    approach="Clip the arccos argument (it is load-bearing, not defensive), self-test "
             "against a rotation of known angle, and report translation error both "
             "absolutely and as a *ratio*, because the ratio is the scale-free part.",
)

nb.code('''
def geodesic_degrees(R1, R2):
    """Angle of the rotation taking R1 to R2, in degrees.

    The clip on the arccos argument is LOAD-BEARING, not defensive tidiness.
    For R1 == R2 the trace of R1^T R2 is exactly 3 in exact arithmetic and
    comes back as 3.0000000004 in float64. (3.0000000004 - 1) / 2 = 1.0000000002,
    and np.arccos of anything above 1 is NaN. That NaN then propagates through
    the mean and turns a PERFECT match into a missing number — the failure mode
    is that your metric silently reports nothing precisely when the answer is
    zero, which is the case you are most likely to be testing.
    """
    R1 = np.asarray(R1, dtype=np.float64)
    R2 = np.asarray(R2, dtype=np.float64)
    cos_theta = (np.trace(R1.T @ R2) - 1.0) / 2.0
    return float(np.degrees(np.arccos(np.clip(cos_theta, -1.0, 1.0))))


def action_error(a, b, *, rotation_slice=slice(3, 9)):
    """Compare two action sequences. Translation and rotation, separately."""
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    n = min(a.shape[0], b.shape[0])
    a, b = a[:n], b[:n]

    trans = np.linalg.norm(a[:, :3] - b[:, :3], axis=1)
    rots = [geodesic_degrees(rot6d_to_matrix_gram_schmidt(a[i, rotation_slice]),
                             rot6d_to_matrix_gram_schmidt(b[i, rotation_slice]))
            for i in range(n)]

    # The scale-free companion to the absolute translation error. A ratio of
    # per-step magnitudes is invariant to translation_scale, so it CAN be
    # compared across datasets while `translation_mean` cannot. See step 5.
    mag_a = np.linalg.norm(a[:, :3], axis=1)
    mag_b = np.linalg.norm(b[:, :3], axis=1)
    usable = mag_a > 1e-12
    ratio = float(np.median(mag_b[usable] / mag_a[usable])) if usable.any() else float("nan")

    return {"steps": int(n),
            "translation_mean": float(trans.mean()),
            "translation_max": float(trans.max()) if n else float("nan"),
            "rotation_deg_mean": float(np.mean(rots)) if rots else float("nan"),
            "rotation_deg_max": float(np.max(rots)) if rots else float("nan"),
            "magnitude_ratio": ratio}
''')

nb.code('''
# Step 3: self-tests. A metric you have not tested is a number, not a measurement.
sample_a = (np.asarray(json.loads(assets["av_traj_forward"].read_text()),
                       dtype=np.float64)
            if assets["av_traj_forward"] else COMMANDED)

identity = action_error(sample_a, sample_a)
print("identity:", {k: round(v, 12) if isinstance(v, float) else v
                    for k, v in identity.items()})
assert identity["translation_mean"] == 0.0, identity
assert identity["rotation_deg_mean"] == 0.0, identity
assert not math.isnan(identity["rotation_deg_mean"]), (
    "NaN here means the arccos clip is missing — see the docstring")
print("PASS action_error(a, a) is exactly zero on BOTH components, and not NaN")

# A sequence rotated by a known angle must come back with that angle.
for angle in (0.0, 5.0, 30.0, 90.0, 179.0):
    R_extra = rot6d_to_matrix_gram_schmidt(yaw_rot6d(angle))
    rotated = sample_a.copy()
    for i in range(rotated.shape[0]):
        R = rot6d_to_matrix_gram_schmidt(sample_a[i, 3:9])
        M = R_extra @ R
        rotated[i, 3:9] = np.concatenate([M[:, 0], M[:, 1]])
    got = action_error(sample_a, rotated)["rotation_deg_mean"]
    assert abs(got - angle) < 1e-6, (angle, got)
    print(f"PASS a known {angle:>5.1f} degree rotation is recovered as {got:.6f}")

# And the clip's necessity, demonstrated rather than asserted.
raw_cos = (np.trace(np.eye(3).T @ np.eye(3)) - 1.0) / 2.0
print(f"\\nunclipped cos for identical rotations: {raw_cos!r}")
print(f"arccos without a clip on 1.0000000002: "
      f"{np.arccos(np.float64(1.0000000002))!r}  <- this is the NaN")
''')

nb.code('''
# Step 4: run inverse dynamics on two clips, and compare each clip's prediction
# against a round-trip re-estimate of the same clip.
clip_metrics = {}
for key in ("av_video", "av_video_2"):
    clip = assets.get(key)
    if clip is None:
        continue
    first, _ = run_spec(inverse_spec(clip, name=f"inv_{key}_a", seed=0),
                        "metric", label=f"inv_{key}_a")
    second, _ = run_spec(inverse_spec(clip, name=f"inv_{key}_b", seed=1),
                         "metric", label=f"inv_{key}_b")
    pa, pb = read_predicted_actions(first), read_predicted_actions(second)
    if pa is not None and pb is not None:
        clip_metrics[key] = action_error(pa, pb)

if not clip_metrics:
    # PLACEHOLDER — invented re-estimates so the table and step 5's argument
    # have numbers to point at. NOT measurements.
    rng = np.random.default_rng(3)
    for key, noise in (("av_video", 0.004), ("av_video_2", 0.011)):
        b = sample_a.copy()
        b[:, :3] += rng.normal(0, noise, (b.shape[0], 3))
        for i in range(b.shape[0]):
            R = rot6d_to_matrix_gram_schmidt(sample_a[i, 3:9])
            M = rot6d_to_matrix_gram_schmidt(yaw_rot6d(rng.normal(0, 0.4))) @ R
            b[i, 3:9] = np.concatenate([M[:, 0], M[:, 1]])
        clip_metrics[key] = action_error(sample_a, b)
    print("PLACEHOLDER RE-ESTIMATES — invented, not measurements.\\n")

print(f"{'clip':<14}{'steps':>7}{'trans mean':>13}{'rot deg mean':>15}"
      f"{'mag ratio':>12}")
print("-" * 62)
for key, m in clip_metrics.items():
    print(f"{key:<14}{m['steps']:>7}{m['translation_mean']:>13.5f}"
          f"{m['rotation_deg_mean']:>15.4f}{m['magnitude_ratio']:>12.4f}")
''')

nb.model_answer(
    "**Which number do I trust more, and what does `translation_scale` do to the "
    "comparison?**\n\n"
    "**The rotation number, without much hesitation** — and the reason is not that it is "
    "more accurate. It is that it *means the same thing everywhere*.\n\n"
    "Rotation geodesic distance is an angle. Two rotations differ by 2.3 degrees whether "
    "the data came from a car, a drone, a wrist camera, or a simulator, and whatever "
    "constants were used to prepare it. You can compare it across clips, across domains, "
    "across model versions and against a published number, and the comparison is valid.\n\n"
    "Translation error is measured in whatever units the action file happens to be in, "
    "and `COSMOS3_FACTS.md` §5 records that `pose_rel_to_abs` **divides** translation by "
    "`translation_scale`. That constant is a preprocessing choice, not a property of the "
    "world. So `translation_mean = 0.004` is not a fact about the model — it is a fact "
    "about the model *and* the scale constant *and* the dataset's units, and the three "
    "are not separable from the number. Halve `translation_scale` and every translation "
    "error in your table halves, while nothing about the model has changed.\n\n"
    "**The concrete consequence:** you cannot compare `translation_mean` across "
    "datasets, across values of `translation_scale`, or against anyone else's reported "
    "figure — and the failure is silent, because the numbers are all plausible. This is "
    "the mechanism behind a specific and common mistake: reporting that a model does "
    "better on domain A than domain B when the only difference is the units the two "
    "domains were prepared in.\n\n"
    "**What to do about it, which is why `magnitude_ratio` is in the metric.** The ratio "
    "of recovered to commanded per-step magnitude is dimensionless: multiply both by any "
    "constant and it is unchanged. A ratio of 1.0 means the scale is right; 0.85 means "
    "the estimator systematically under-reports motion by 15%, and that statement "
    "transfers across datasets. So the honest report is three numbers: rotation in "
    "degrees (comparable), magnitude ratio (comparable), and absolute translation error "
    "(comparable only within one dataset at one scale, and labelled as such).\n\n"
    "**One caveat against my own preference.** Rotation geodesic distance has a failure "
    "of its own: it is bounded above at 180 degrees, so it saturates. Two estimators, one "
    "off by 170 degrees and one off by 190, score 170 and 170. On AV data where per-step "
    "yaws are small this never binds. On a wrist camera doing large reorientations it "
    "can, and then a small mean geodesic error can hide a few catastrophically wrong "
    "steps. Report the max alongside the mean — which `action_error` does — and look at "
    "it."
)

nb.extend(
    "The metric compares sequences step-for-step, which assumes they are aligned. They "
    "often are not: an estimator that lags by one frame produces a large per-step error "
    "on a trajectory it has essentially got right. Adding a small alignment search — "
    "compute the metric at offsets of -2..+2 steps and report the best, along with the "
    "offset that achieved it — separates \"wrong\" from \"late\", and the offset itself "
    "is diagnostic: a consistent non-zero best offset means a systematic frame-indexing "
    "bug somewhere in the pipeline, which is a much better thing to discover than a "
    "slightly elevated error."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "A round-trip evaluation harness",
    goal="Turn the one-off round trip into a harness that runs over several clips, "
         "reports a distribution, and supports an argument about failure modes.",
    success="At least four clips through the harness, a reported distribution with a "
            "variance estimate from a deliberate control, and a report attributing error "
            "to specific mechanisms and naming what the method cannot see.",
    approach="Run the seed control **first** so the between-clip spread has something to "
             "be compared against, and structure the report around which of the four "
             "error mechanisms the harness can and cannot separate.",
)

nb.code('''
def roundtrip(clip_path, *, chunk=None, seed=0, tag="rt", start_frame=None,
              fps=10, image_size=480):
    """Inverse then forward on one clip. Return a full record."""
    clip_path = Path(clip_path)
    record = {"clip": clip_path.name, "tag": tag, "seed": seed,
              "chunk": chunk or MODE_CHUNK, "fps": fps, "image_size": image_size,
              "actions": None, "curve": None, "inverse_s": None, "forward_s": None,
              "error": None}

    inv_spec = inverse_spec(clip_path, name=f"{tag}_inv", chunk=chunk, seed=seed,
                            fps=fps, image_size=image_size)
    record["inverse_spec"] = inv_spec.to_dict()
    inv_result, record["inverse_s"] = run_spec(inv_spec, f"roundtrip/{tag}",
                                               label=f"{tag}_inv")
    actions = read_predicted_actions(inv_result)
    if actions is None:
        record["error"] = "inverse dynamics produced no usable action array"
        return record
    record["actions"] = actions

    action_path = OUTPUT_DIR / "roundtrip" / f"{tag}_actions.json"
    action_path.parent.mkdir(parents=True, exist_ok=True)
    action_path.write_text(json.dumps([[float(v) for v in r] for r in actions]))

    # Forward dynamics from the SAME clip's first frame, so the only thing that
    # differs from the source is the action array.
    fwd_spec = forward_spec(start_frame or clip_path, action_path,
                            name=f"{tag}_fwd", chunk=chunk, seed=seed, fps=fps,
                            image_size=image_size)
    record["forward_spec"] = fwd_spec.to_dict()
    fwd_result, record["forward_s"] = run_spec(fwd_spec, f"roundtrip/{tag}",
                                               label=f"{tag}_fwd")
    if fwd_result is None or not fwd_result.video_path:
        record["error"] = "forward dynamics produced no video"
        return record
    record["curve"] = compare_clips(clip_path, fwd_result.video_path)
    return record


def read_frames_gray(path, count=24):
    """Decode up to `count` evenly spaced frames as float grayscale arrays."""
    frames = []
    try:
        import imageio.v3 as iio
        frames = [np.asarray(f) for f in iio.imiter(str(path))]
    except Exception:
        return None
    if not frames:
        return None
    step = max(1, len(frames) // count)
    picked = frames[::step][:count]
    return [f.astype(np.float64).mean(axis=2) if f.ndim == 3 else f.astype(np.float64)
            for f in picked]


def compare_clips(a_path, b_path, count=24):
    """Per-frame mean absolute difference between two clips, on 0-255 grayscale."""
    a, b = read_frames_gray(a_path, count), read_frames_gray(b_path, count)
    if a is None or b is None:
        return None
    n = min(len(a), len(b))
    out = []
    for i in range(n):
        fa, fb = a[i], b[i]
        if fa.shape != fb.shape:
            h, w = min(fa.shape[0], fb.shape[0]), min(fa.shape[1], fb.shape[1])
            fa, fb = fa[:h, :w], fb[:h, :w]
        out.append(float(np.abs(fa - fb).mean()))
    return out
''')

nb.code('''
CLIPS = [p for p in (assets["av_video"], assets["av_video_2"]) if p is not None]
MY_CLIPS = [p for p in [LESSON_10_VIDEO,
                        cc.OUTPUT_ROOT / "10" / "av" / "av_right" / "vision.mp4"]
            if p.exists()]
ALL_CLIPS = CLIPS + MY_CLIPS
print("cookbook clips :", [p.name for p in CLIPS])
print("my Lesson 10   :", [str(p.relative_to(cc.OUTPUT_ROOT)) for p in MY_CLIPS]
      or "(none — run Lesson 10; they are the ONLY clips with ground truth)")
print(f"total          : {len(ALL_CLIPS)} (the exercise asks for at least four)")

# STEP 4, RUN FIRST: the seed control. Three runs of ONE clip at three seeds,
# so the between-clip spread below has something to be judged against. Hint 1
# is explicit that this comes first, and the reason is that without it every
# between-clip difference is uninterpretable.
seed_records = []
if ALL_CLIPS:
    for seed in (0, 1, 2):
        seed_records.append(roundtrip(ALL_CLIPS[0], seed=seed,
                                      tag=f"seedctl_{seed}"))
clip_records = [roundtrip(p, seed=0, tag=f"clip{i}")
                for i, p in enumerate(ALL_CLIPS)]
''')

nb.code('''
def curve_mean(record):
    curve = record.get("curve")
    return float(np.mean(curve)) if curve else None


seed_means = [m for m in map(curve_mean, seed_records) if m is not None]
clip_means = [m for m in map(curve_mean, clip_records) if m is not None]

if not seed_means or not clip_means:
    # PLACEHOLDER DISTRIBUTIONS — invented. Chosen so the seed spread is
    # NON-TRIVIAL relative to the clip spread, because that is the situation the
    # exercise is teaching you to detect. NOT measurements.
    print("PLACEHOLDER DISTRIBUTIONS — invented, not measurements.\\n")
    seed_means = [18.4, 19.9, 17.8]
    clip_means = [18.7, 21.2, 19.4, 26.8]
    clip_labels = ["av_0.mp4", "av_1.mp4", "my_forward.mp4", "my_right.mp4"]
    mean_curve = [8.0 + 0.9 * i + 0.05 * i * i for i in range(24)]
else:
    clip_labels = [r["clip"] for r in clip_records if curve_mean(r) is not None]
    curves = [r["curve"] for r in clip_records if r.get("curve")]
    width = min(len(c) for c in curves)
    mean_curve = [float(np.mean([c[i] for c in curves])) for i in range(width)]

seed_spread = max(seed_means) - min(seed_means)
clip_spread = max(clip_means) - min(clip_means)
print(f"seed control (one clip, 3 seeds): {[round(v, 2) for v in seed_means]}")
print(f"  spread {seed_spread:.2f}")
print(f"across clips                    : {[round(v, 2) for v in clip_means]}")
print(f"  spread {clip_spread:.2f}")
print()
ratio = clip_spread / seed_spread if seed_spread else float("inf")
print(f"clip spread / seed spread = {ratio:.2f}")
if ratio < 2.0:
    print("The between-clip differences are NOT clearly larger than run-to-run "
          "variance. Any ranking of clips from this data is a ranking of noise, "
          "and the report must say so.")
else:
    print("Between-clip spread clearly exceeds the seed control, so clip-to-clip "
          "differences are interpretable — at least for the largest of them.")

print()
print("mean difference curve vs frame index (averaged over clips):")
for i in range(0, len(mean_curve), max(1, len(mean_curve) // 8)):
    bar = "#" * int(mean_curve[i] / max(mean_curve) * 40)
    print(f"  frame {i:>3}  {mean_curve[i]:>7.2f}  {bar}")
print()
print("A curve that RISES with frame index is compounding divergence; a flat one "
      "is a constant offset. This one "
      + ("rises" if mean_curve[-1] > 1.3 * mean_curve[0] else "is roughly flat")
      + ".")
''')

nb.code('''
lines = [
    "# Round-trip evaluation — Lesson 11, Exercise 3",
    "",
    ("**PLACEHOLDER NUMBERS.** No Nano run happened here; the distributions are "
     "invented to exercise the analysis. The harness, the seed control and the "
     "attribution argument are real."
     if not any(r.get("curve") for r in clip_records) else "Measured on this machine."),
    "",
    "## Design",
    "",
    f"- clips: {len(ALL_CLIPS)} ({len(CLIPS)} cookbook, {len(MY_CLIPS)} generated in "
    f"Lesson 10 from trajectories I wrote)",
    f"- control: the same clip round-tripped at seeds 0, 1, 2, everything else fixed",
    f"- metric: per-frame mean absolute difference between the source clip and the "
    f"round-tripped clip",
    "",
    "## Distribution",
    "",
    f"- seed control: {[round(v, 2) for v in seed_means]}, spread **{seed_spread:.2f}**",
    f"- across clips: {[round(v, 2) for v in clip_means]}, spread **{clip_spread:.2f}**",
    f"- ratio: **{ratio:.2f}x**. "
    + ("Below 2, so clip-to-clip differences are within run-to-run variance and must "
       "not be interpreted." if ratio < 2.0 else
       "Above 2, so the larger clip-to-clip differences are interpretable."),
    "",
    "## Attributing the error",
    "",
    "Four mechanisms can produce a difference between the source clip and its "
    "round trip. Which ones this harness can separate:",
    "",
    "| mechanism | what it is | can the harness see it? |",
    "|---|---|---|",
    "| inverse-dynamics estimation error | the recovered actions differ from the "
    "true ones | **only on the clips I generated**, where the true actions are known. "
    "Not on the cookbook clips. |",
    "| forward-dynamics generative divergence | correct actions, but the generated "
    "video differs from the source anyway | partly: it is what remains after the "
    "estimation error is accounted for, so it is inferred rather than measured |",
    "| compounding drift | small errors accumulating over frames | **yes**, from the "
    "shape of the difference-versus-frame curve: rising means compounding, flat means "
    "a constant offset |",
    "| scale ambiguity | the right motion at the wrong magnitude | **no**, not from "
    "pixels. It needs `magnitude_ratio` from Exercise 2 against a known trajectory |",
    "",
    "So the harness separates *compounding from constant* directly, separates "
    "estimation error from generative divergence **only where ground truth exists**, "
    "and cannot see scale at all.",
    "",
    "## The structural blind spot",
    "",
    "**A round trip compares the model against itself, so correlated errors are "
    "invisible by construction.** If inverse dynamics systematically under-estimates "
    "turning by 20% and forward dynamics systematically under-turns by the same 20%, "
    "the two errors cancel: the round-tripped clip matches the source almost perfectly "
    "and the metric reports an excellent score for a model that is wrong in both "
    "directions.",
    "",
    "This is not a hypothetical. The two heads share a checkpoint, share a training "
    "distribution, and were trained on the same data — which is precisely the "
    "condition under which their errors are correlated rather than independent. A "
    "round trip is therefore a **consistency** check, not an accuracy check, and the "
    "distinction is the whole point.",
    "",
    "The only cure is external ground truth: a trajectory I commanded (Lesson 10), or "
    "real vehicle odometry. That is why two of the four clips in this harness are ones "
    "I generated, and why Exercise 1 exists.",
    "",
    "## A second blind spot, less often mentioned",
    "",
    "The metric is a per-frame pixel difference, so it is dominated by global "
    "appearance. A round trip that reproduces the scene's colour and layout while "
    "getting the *motion* wrong scores well; a round trip with correct motion and a "
    "slight colour shift scores badly. Pixel difference is a proxy for 'did this end "
    "up in the same place', and it is a poor one.",
]
report_path = OUTPUT_DIR / "roundtrip_report.md"
report_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {report_path}")
print("\\n".join(lines[-18:]))
''')

nb.why(
    "**Why the seed control runs before the clip comparison.** Hint 1 says to do it "
    "first, and the reason is that the order changes what you are able to conclude. Run "
    "the clips first and you will have four numbers, they will differ, and you will "
    "interpret the differences — because that is what people do with numbers that "
    "differ. Run the control first and you have a threshold in hand before you see the "
    "data, so \"these clips differ by less than the seed does\" is a conclusion you can "
    "actually reach. The ratio is printed and interpreted automatically for the same "
    "reason: it removes the opportunity to be generous with yourself.\n\n"
    "**Why the harness records every spec field.** `roundtrip` stores "
    "`inverse_spec` and `forward_spec` as dicts in the record. It looks like "
    "bookkeeping and it is the thing that makes step 4 possible at all: to \"vary one "
    "thing deliberately and hold everything else fixed\" you must be able to *prove* "
    "everything else was fixed, and that means diffing the specs rather than trusting "
    "your memory of what the loop did. It is also the only way to reconstruct, three "
    "weeks later, what a surprising record was actually run with.\n\n"
    "**Why the four mechanisms are separated in the report rather than lumped as "
    "\"error\".** They have different fixes. Estimation error is fixed by a better "
    "estimator or a different chunk size; generative divergence is fixed by the "
    "generator; compounding drift is fixed by shortening the horizon or re-anchoring; "
    "scale ambiguity is fixed by a constant. A report that says \"mean difference 19.4\" "
    "supports none of those decisions. Being explicit about which ones the harness "
    "*cannot* separate is the part that stops the number being over-read.\n\n"
    "**Why the blind spot is the most important paragraph in the report.** Hint 2 names "
    "it and it deserves to be restated in the strongest form: **a round trip cannot "
    "detect correlated error, and the two heads are maximally likely to have correlated "
    "error, because they are the same checkpoint trained on the same data.** A perfect "
    "round-trip score is consistent with a model that is confidently and identically "
    "wrong at both ends. This is the same structural problem as Lesson 04's "
    "\"self-consistency measures stability, not correctness\", and as Lesson 10's "
    "objection to grading forward dynamics with inverse dynamics. It is worth noticing "
    "that the same shape of mistake has now appeared three times in this course: "
    "**whenever a system evaluates itself, it measures agreement and reports it as "
    "accuracy.**"
)

nb.extend(
    "The strongest cheap addition is a **cross-model** round trip: recover actions with "
    "one checkpoint and regenerate with another (Edge's action variant against Nano's, "
    "say). Errors that survive a change of model are much more likely to be real than "
    "errors measured within one. It does not fully break the correlation — the two "
    "checkpoints share a training corpus — but it is a genuine step towards independence "
    "and it costs nothing but a second download you may already have. The honest framing "
    "is that it *reduces* the correlation rather than removing it, and the report should "
    "say so."
)

nb.finish()
