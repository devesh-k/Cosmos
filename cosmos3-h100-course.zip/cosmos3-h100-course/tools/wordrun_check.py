#!/usr/bin/env python3
"""Measure contiguous markdown runs — stretches of theory with nothing to run.

`tools/AUTHORING_GUIDE.md` says: "Do not write more than about 400 words before
the learner does something." That rule is invisible to every other validator,
because each individual markdown cell is usually short. The problem is the
*run*: five 200-word cells in a row is a thousand words of unbroken prose, and a
learner in flow hits it as a wall.

A **run** is a maximal sequence of consecutive markdown cells with no code cell
between them. This script counts the words in each run and reports the ones over
the limit.

Words are counted on the rendered-ish text: fenced code blocks inside markdown
are excluded (they are illustrative, not prose), HTML tags are stripped, and
markdown table pipes/rules are dropped, so a big table is not scored as if every
cell delimiter were a word.

Usage:
    python3 tools/wordrun_check.py                  # summary + offenders
    python3 tools/wordrun_check.py --limit 400      # change the threshold
    python3 tools/wordrun_check.py --json           # machine-readable
    python3 tools/wordrun_check.py --top 20         # worst N only
    python3 tools/wordrun_check.py --baseline b.json  # compare against a saved run

Exit code is 0 always by default; pass --strict to exit 1 when any run exceeds
the limit. It is a reporting tool, not a gate — the course has a long tail of
mildly-over runs that are not worth churning.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

FENCE = re.compile(r"```.*?```", re.S)
INLINE_CODE = re.compile(r"`[^`]*`")
HTML_TAG = re.compile(r"<[^>]+>")
TABLE_PUNCT = re.compile(r"[|]|^[\s:\-]+$", re.M)
MD_PUNCT = re.compile(r"[#*_>\[\]()]")


def source(cell: dict) -> str:
    src = cell.get("source", "")
    return "".join(src) if isinstance(src, list) else str(src)


def word_count(text: str) -> int:
    """Prose words only: no fenced code, no HTML, no table scaffolding."""
    t = FENCE.sub(" ", text)
    t = INLINE_CODE.sub(" code ", t)
    t = HTML_TAG.sub(" ", t)
    t = TABLE_PUNCT.sub(" ", t)
    t = MD_PUNCT.sub(" ", t)
    return len([w for w in t.split() if any(ch.isalnum() for ch in w)])


def runs_for(path: Path) -> list[dict]:
    """Every maximal markdown run in one notebook."""
    nb = json.loads(path.read_text(encoding="utf-8"))
    cells = nb["cells"]
    out: list[dict] = []
    start: int | None = None
    words = 0
    per_cell: list[int] = []

    def flush(end: int) -> None:
        nonlocal start, words, per_cell
        if start is not None:
            out.append(
                {
                    "notebook": path.name,
                    "start": start,
                    "end": end,
                    "cells": end - start + 1,
                    "words": words,
                    "max_cell": max(per_cell) if per_cell else 0,
                    "max_cell_index": start + per_cell.index(max(per_cell)) if per_cell else start,
                    "front_matter": start == 0,
                }
            )
        start, words, per_cell = None, 0, []

    for i, cell in enumerate(cells):
        if cell.get("cell_type") == "markdown":
            if start is None:
                start = i
            n = word_count(source(cell))
            words += n
            per_cell.append(n)
        else:
            flush(i - 1)
    flush(len(cells) - 1)
    return out


def collect(paths: list[Path]) -> list[dict]:
    allruns: list[dict] = []
    for p in paths:
        allruns.extend(runs_for(p))
    return allruns


def classify(run: dict, n_cells: int) -> str:
    if run["front_matter"]:
        return "front"
    if run["end"] >= n_cells - 2:
        return "closing"
    return "mid-lesson"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=400)
    ap.add_argument("--top", type=int, default=0, help="show only the worst N")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--baseline", type=Path, help="a --json dump to compare against")
    ap.add_argument("--save", type=Path, help="write a --json dump here")
    ap.add_argument("--glob", default="[0-9][0-9]_*.ipynb")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    paths = sorted(ROOT.glob(args.glob))
    if not paths:
        print(f"no notebooks matched {args.glob}", file=sys.stderr)
        return 2

    sizes = {p.name: len(json.loads(p.read_text(encoding="utf-8"))["cells"]) for p in paths}
    allruns = collect(paths)
    for r in allruns:
        r["kind"] = classify(r, sizes[r["notebook"]])

    over = sorted((r for r in allruns if r["words"] > args.limit),
                  key=lambda r: -r["words"])

    payload = {
        "limit": args.limit,
        "notebooks": len(paths),
        "runs": len(allruns),
        "over": len(over),
        "total_words_over_limit": sum(r["words"] - args.limit for r in over),
        "worst": over[0]["words"] if over else 0,
        "by_kind": {
            k: sum(1 for r in over if r["kind"] == k)
            for k in ("front", "mid-lesson", "closing")
        },
        "detail": over,
    }

    if args.save:
        args.save.write_text(json.dumps(payload, indent=1), encoding="utf-8")

    if args.json:
        print(json.dumps(payload, indent=1))
        return 1 if (args.strict and over) else 0

    print(f"markdown-run audit — limit {args.limit} words, {len(paths)} notebooks")
    print(f"  {len(allruns)} contiguous markdown runs")
    print(f"  {len(over)} exceed the limit "
          f"(front {payload['by_kind']['front']}, "
          f"mid-lesson {payload['by_kind']['mid-lesson']}, "
          f"closing {payload['by_kind']['closing']})")
    print(f"  worst run: {payload['worst']} words")
    print(f"  total excess: {payload['total_words_over_limit']} words\n")

    shown = over[: args.top] if args.top else over
    print(f"{'words':>6}  {'cell(max)':>9}  {'kind':<11}  location")
    for r in shown:
        stem = r["notebook"].replace(".ipynb", "")
        span = f"c{r['start']}" if r["cells"] == 1 else f"c{r['start']}-c{r['end']}"
        print(f"{r['words']:>6}  {r['max_cell']:>9}  {r['kind']:<11}  {stem} {span}")

    if args.baseline and args.baseline.exists():
        base = json.loads(args.baseline.read_text(encoding="utf-8"))
        print("\nvs baseline:")
        print(f"  runs over limit : {base['over']} -> {payload['over']} "
              f"({payload['over'] - base['over']:+d})")
        print(f"  worst run       : {base['worst']} -> {payload['worst']} "
              f"({payload['worst'] - base['worst']:+d})")
        print(f"  total excess    : {base['total_words_over_limit']} -> "
              f"{payload['total_words_over_limit']} "
              f"({payload['total_words_over_limit'] - base['total_words_over_limit']:+d})")

    return 1 if (args.strict and over) else 0


if __name__ == "__main__":
    raise SystemExit(main())
