"""Build solutions/13_solutions.ipynb — reference answers for Lesson 13."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from solbuild import SolutionNotebook, setup_cell  # noqa: E402

nb = SolutionNotebook("13", "Action: closed-loop control",
                      lesson_file="13_action_closed_loop.ipynb")

nb.header(
    "Closed-loop control is where a policy stops being a function and becomes a system "
    "with a deadline. All three exercises are about the client half — the half you own. "
    "The foundation exercise documents the server's contract **from the wire** rather "
    "than from its docstring, and finds the behaviours the prose does not mention. The "
    "applied one builds the loop and measures its latency properly. The challenge one "
    "designs an evaluation you could hand to someone with the hardware, including the "
    "sample-size derivation most designs skip."
)

nb.callout(
    "note",
    "**This is the one lesson in Module 4 that runs end to end with no GPU.** The mock "
    "policy server is a local `http.server` implementing the documented contract, so "
    "every cell below actually executes — the probes, the driver, the latency "
    "distribution, the Wilson intervals and the broken-policy controls are all real "
    "measurements of real code. What they are *not* is measurements of Cosmos 3: the "
    "mock sleeps 50 ms in place of denoising, and every latency figure says so.",
)

nb.prelude("The lesson's mock server, its HTTP client and its response checker.")
nb.code(setup_cell("13"))

nb.code('''
import base64
import json
import statistics
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np

ACTION_DIM = 10          # bridge/DROID/LIBERO end-effector width
CHUNK = 16


class MockPolicyHandler(BaseHTTPRequestHandler):
    """The documented LIBERO policy-server contract, exactly — including the
    parts that are easy to get wrong: 415 on a bad content type, 404 on an
    unknown path, and HTTP 200 with an empty action list when inference fails."""

    def log_message(self, fmt, *args):
        pass

    def _send(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/info":
            self._send(200, {"run_name": "mock", "checkpoint": "none (synthetic)",
                             "action_chunk_size": CHUNK, "raw_action_dim": ACTION_DIM,
                             "fps": 20, "action_normalization": "quantile_rot"})
        elif self.path == "/":
            self._send(200, {"status": "ok"})
        else:
            self._send(404, {"error": "Not found"})

    def do_POST(self):
        if self.path not in ("/", "/predict", "/predict_batch"):
            self._send(404, {"error": "Not found"})
            return
        content_type = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if content_type != "application/json":
            self._send(415, {"error": "Content-Type must be application/json"})
            return
        length = int(self.headers.get("Content-Length") or 0)
        try:
            req = json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError as exc:
            self._send(200, {"action": [], "error": f"bad json: {exc}"})
            return
        if "image" not in req or "prompt" not in req:
            self._send(200, {"action": [], "error": "missing 'image' or 'prompt'"})
            return
        rng = np.random.default_rng(abs(hash(req["prompt"])) % (2 ** 32))
        act = np.zeros((CHUNK, ACTION_DIM))
        act[:, :3] = rng.normal(0, 0.01, size=(CHUNK, 3))
        act[:, 3:9] = np.tile([1, 0, 0, 0, 1, 0], (CHUNK, 1))
        act[:, 9] = (np.arange(CHUNK) >= CHUNK // 2).astype(float)
        time.sleep(0.05)                       # stands in for denoising
        if self.path == "/predict_batch":
            self._send(200, {"actions": [act.tolist()]})
        else:
            self._send(200, {"action": act.tolist(), "video": []})


def start_mock_server():
    """Bind an OS-assigned port and serve in a daemon thread."""
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), MockPolicyHandler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    return httpd, f"http://127.0.0.1:{httpd.server_address[1]}"
''')

nb.code('''
def call(url, path="/", method="GET", payload=None, content_type="application/json",
         timeout=30, raw_body=None):
    """One hand-made HTTP request. Returns (status, parsed_body_or_text, seconds)."""
    if raw_body is not None:
        data = raw_body if isinstance(raw_body, bytes) else raw_body.encode("utf-8")
    else:
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url + path, data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", content_type)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status, raw = resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        status, raw = exc.code, exc.read().decode("utf-8", "replace")
    elapsed = time.perf_counter() - started
    try:
        return status, json.loads(raw), elapsed
    except json.JSONDecodeError:
        return status, raw, elapsed


TINY_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmM"
    "IQAAAABJRU5ErkJggg==")
GOOD_REQUEST = {"image": TINY_PNG_B64,
                "prompt": "Put the pot to the left of the purple item.",
                "domain_name": "bridge_orig_lerobot", "image_size": 256}


def check_prediction(status, body, *, expected_dim=ACTION_DIM, expected_chunk=None,
                     action_key="action"):
    """Decide whether a policy response is usable. Returns a list of problems."""
    problems = []
    if status != 200:
        problems.append(f"HTTP {status}")
    if not isinstance(body, dict):
        return problems + ["body is not a JSON object"]
    if body.get("error"):
        problems.append(f"server reported: {body['error']}")
    action = body.get(action_key)
    if action is None:
        problems.append(f"no {action_key!r} key "
                        f"(/predict uses 'action', /predict_batch uses 'actions')")
    elif not action:
        problems.append("empty action list - inference failed behind a 200")
    else:
        arr = np.asarray(action, dtype=float)
        if arr.ndim not in (2, 3):
            problems.append(f"expected [chunk, dims], got shape {arr.shape}")
        else:
            flat = arr if arr.ndim == 2 else arr[0]
            if flat.shape[1] != expected_dim:
                problems.append(f"width {flat.shape[1]}, expected {expected_dim}")
            if expected_chunk and flat.shape[0] != expected_chunk:
                problems.append(f"chunk {flat.shape[0]}, expected {expected_chunk}")
            if not np.isfinite(flat).all():
                problems.append("non-finite values in the action")
    return problems


mock_server, MOCK_URL = start_mock_server()
print("mock policy server at", MOCK_URL)
''')

# ---------------------------------------------------------------------------
nb.solution(
    "foundation",
    "Document the policy-server schema from the wire",
    goal="Produce a schema document you could hand to someone writing a client, derived "
         "from observed behaviour rather than from prose.",
    success="A schema document covering all three POST paths and both GET paths, with at "
            "least four error cases and at least one behaviour not stated in the module "
            "docstring.",
    approach="Probe first, write second — and record for every probe whether a naive "
             "client checking only the status code would have noticed, because that "
             "column is the document's whole point.",
)

nb.code('''
ENDPOINTS = [("GET", "/"), ("GET", "/info"), ("POST", "/predict"),
             ("POST", "/predict_batch"), ("POST", "/")]


def probe_all(url, endpoints, payload):
    """Return a table of (method, path, status, keys-in-response, naive-client-ok)."""
    rows = []
    for method, path in endpoints:
        status, body, seconds = call(url, path, method,
                                     payload if method == "POST" else None)
        keys = sorted(body) if isinstance(body, dict) else ["<not JSON>"]
        # The column that matters: would a client that only looks at the status
        # code have believed this response?
        action_key = "actions" if path.endswith("_batch") else "action"
        problems = check_prediction(status, body, action_key=action_key) \\
            if method == "POST" else []
        rows.append({"method": method, "path": path, "status": status, "keys": keys,
                     "seconds": round(seconds, 4), "problems": problems,
                     "naive_client_fooled": bool(problems) and status == 200})
    return rows


rows = probe_all(MOCK_URL, ENDPOINTS, GOOD_REQUEST)
print(f"{'method':<7}{'path':<17}{'status':>7}{'seconds':>9}  keys")
print("-" * 78)
for r in rows:
    print(f"{r['method']:<7}{r['path']:<17}{r['status']:>7}{r['seconds']:>9.4f}  "
          f"{r['keys']}")

# The key difference hint 1 warns about, asserted rather than noticed.
predict_keys = next(r["keys"] for r in rows if r["path"] == "/predict")
batch_keys = next(r["keys"] for r in rows if r["path"] == "/predict_batch")
assert "action" in predict_keys and "actions" not in predict_keys, predict_keys
assert "actions" in batch_keys and "action" not in batch_keys, batch_keys
print("\\nPASS /predict returns 'action' (singular); /predict_batch returns "
      "'actions' (plural). A client written for one and pointed at the other "
      "gets a 200 and a None.")
''')

nb.code('''
# Step 3: malformed requests. Six, not four, because the interesting ones are
# the ones that succeed.
MALFORMED = [
    ("wrong content type", dict(path="/predict", method="POST",
                                payload=GOOD_REQUEST, content_type="text/plain")),
    ("unknown path", dict(path="/nowhere", method="POST", payload=GOOD_REQUEST)),
    ("body is not JSON", dict(path="/predict", method="POST",
                              raw_body="this is not json")),
    ("missing image", dict(path="/predict", method="POST",
                           payload={k: v for k, v in GOOD_REQUEST.items()
                                    if k != "image"})),
    ("empty JSON object", dict(path="/predict", method="POST", payload={})),
    ("extra unexpected field", dict(path="/predict", method="POST",
                                    payload={**GOOD_REQUEST, "nonsense": [1, 2, 3]})),
    ("absurd image_size", dict(path="/predict", method="POST",
                               payload={**GOOD_REQUEST, "image_size": 99999})),
]

error_rows = []
print(f"{'case':<26}{'status':>7}  naive client fooled?  body")
print("-" * 100)
for label, kwargs in MALFORMED:
    status, body, _ = call(MOCK_URL, **kwargs)
    problems = check_prediction(status, body)
    fooled = status == 200 and bool(problems)
    error_rows.append({"case": label, "status": status, "problems": problems,
                       "fooled": fooled,
                       "body": json.dumps(body)[:60] if isinstance(body, dict)
                               else str(body)[:60]})
    print(f"{label:<26}{status:>7}  {'YES' if fooled else 'no ':<20}  "
          f"{error_rows[-1]['body']}")

fooling = [r for r in error_rows if r["fooled"]]
assert len(error_rows) >= 4, "the exercise asks for at least four error cases"
print(f"\\n{len(fooling)} of {len(error_rows)} malformed requests returned HTTP 200. "
      f"A client checking only the status code would have accepted every one of "
      f"them: {[r['case'] for r in fooling]}")
''')

nb.code('''
# Step 5: something the documentation does not mention. Hint 2 suggests three
# probes; each is checked here and the finding recorded either way.
undocumented = []

# (a) An extra, unexpected field.
status, body, _ = call(MOCK_URL, "/predict", "POST",
                       {**GOOD_REQUEST, "nonsense": [1, 2, 3]})
if status == 200 and not check_prediction(status, body):
    undocumented.append(
        "Unknown request fields are IGNORED, not rejected. A client that "
        "misspells 'prompt' as 'promt' gets a 200 with an empty action list and "
        "no mention of the misspelling — the same response as a genuine "
        "inference failure. The two are indistinguishable from the wire.")

# (b) An absurd image_size.
status, body, _ = call(MOCK_URL, "/predict", "POST",
                       {**GOOD_REQUEST, "image_size": 99999})
if status == 200 and not check_prediction(status, body):
    undocumented.append(
        "`image_size` is not validated. A value of 99999 is accepted and the "
        "response is indistinguishable from a correct one, so a client with a "
        "units bug (pixels vs. fraction) gets plausible actions for a "
        "resolution the model never saw.")

# (c) POST / — the documented alias — behaves exactly like /predict.
s1, b1, _ = call(MOCK_URL, "/predict", "POST", GOOD_REQUEST)
s2, b2, _ = call(MOCK_URL, "/", "POST", GOOD_REQUEST)
if s1 == s2 == 200 and sorted(b1) == sorted(b2):
    undocumented.append(
        "`POST /` and `POST /predict` return identical response SHAPES, so a "
        "client pointed at the wrong one still works — which means a "
        "configuration error in the URL is invisible until you change server "
        "implementations.")

# (d) Determinism: the same prompt twice.
_, b3, _ = call(MOCK_URL, "/predict", "POST", GOOD_REQUEST)
_, b4, _ = call(MOCK_URL, "/predict", "POST", GOOD_REQUEST)
same = np.allclose(np.asarray(b3["action"]), np.asarray(b4["action"]))
undocumented.append(
    f"Repeated identical requests return {'IDENTICAL' if same else 'DIFFERENT'} "
    f"actions. Nothing in the contract says which, and it matters: an evaluation "
    f"harness that assumes determinism will under-estimate variance if the server "
    f"is stochastic, and one that assumes stochasticity will waste trials if it "
    f"is not.")

for item in undocumented:
    print(f"- {item}\\n")
assert undocumented, "the exercise asks for at least one undocumented behaviour"
''')

nb.code('''
lines = [
    "# Policy-server schema, observed from the wire",
    "",
    "Derived by probing a server, not by reading its docstring. Every status code "
    "below was observed. **Measured against the mock server in Lesson 13**; the real "
    "`action_policy_server_libero` implements the same documented contract, and the "
    "first thing to do on a real server is re-run these probes against it.",
    "",
    "## Endpoints",
    "",
    "| method | path | status | response keys |",
    "|---|---|---:|---|",
]
for r in rows:
    lines.append(f"| {r['method']} | `{r['path']}` | {r['status']} | "
                 f"{', '.join('`' + k + '`' for k in r['keys'])} |")

lines += [
    "",
    "### The key that changes",
    "",
    "`/predict` returns **`action`** (singular): a `[chunk, dims]` array.  ",
    "`/predict_batch` returns **`actions`** (plural): a list of such arrays.",
    "",
    "A client written for one and pointed at the other receives HTTP 200 and "
    "`body.get('action') is None`. If it uses `.get()` it proceeds with `None`; if it "
    "uses `[...]` it raises a `KeyError` several frames from the cause. Neither is a "
    "network error and neither is visible in a status code.",
    "",
    "## Field types (request)",
    "",
    "| field | type | required | notes |",
    "|---|---|---|---|",
    "| `image` | base64 PNG string | **yes** | absence gives 200 + empty action |",
    "| `prompt` | string | **yes** | absence gives 200 + empty action |",
    "| `domain_name` | string | no | not validated by the mock |",
    "| `image_size` | int | no | **not validated** — see below |",
    "",
    "## Error cases observed",
    "",
    "| case | status | would a status-only client notice? |",
    "|---|---:|---|",
]
for r in error_rows:
    lines.append(f"| {r['case']} | {r['status']} | "
                 f"{'**NO**' if r['fooled'] else 'yes'} |")

lines += [
    "",
    "## How to tell a real failure from a real success",
    "",
    "**A 200 is not success.** The server's own flag for this is "
    "`--http-400-on-error`, and it defaults to **off** — a flag that exists to make "
    "errors visible, defaulting to invisible. So:",
    "",
    "1. Status must be 200. Necessary, nowhere near sufficient.",
    "2. `body['error']` must be absent or empty.",
    "3. The action key must be present — and it is `action` or `actions` depending on "
    "the path.",
    "4. The action list must be **non-empty**. An empty list is the documented "
    "representation of an inference failure.",
    "5. The array must be `[chunk, dims]` with `dims` equal to the embodiment's raw "
    "action width (`COSMOS3_FACTS.md` §5: 10 for bridge/DROID, 9 for AV, 29 for "
    "agibotworld) and `chunk` equal to what you asked for.",
    "6. Every value must be finite.",
    "",
    "`check_prediction` in this notebook implements all six. Steps 4 and 6 are the "
    "ones that catch failures no status code reports.",
    "",
    "## Behaviours not stated in the documentation",
    "",
]
for item in undocumented:
    lines.append(f"- {item}")
    lines.append("")

report_path = OUTPUT_DIR / "policy_server_schema.md"
report_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {report_path}")
print("\\n".join(lines[:30]))
''')

nb.why(
    "**Why probe before writing.** A schema written from a docstring documents what "
    "someone intended. The failure that costs a day is the gap between that and what the "
    "server does, and the only way to find it is to send requests. `COSMOS3_FACTS.md` §5 "
    "records the specific gap that matters here — *inference errors return HTTP 200 with "
    "an empty action list by default, so a 200 is not proof of success* — and everything "
    "in the document above is organised around making that visible to a client author.\n\n"
    "**Why the `naive_client_fooled` column is the point of the document.** Listing "
    "status codes is easy and nearly useless: a reader will assume 200 means success "
    "because that is what 200 means everywhere else. Explicitly recording, for each error "
    "case, whether a status-only client would have noticed turns the table from reference "
    "material into a warning. On this server, most of the malformed requests return 200.\n\n"
    "**Why the undocumented findings are the ones about *silence*.** The three probes "
    "hint 2 suggests — an extra field, an absurd `image_size`, an empty object — all "
    "share a shape: the server accepts input nobody planned for and says nothing. Each "
    "produces a client-side bug that is invisible at the boundary. A misspelled `prompt` "
    "key looks exactly like an inference failure; an `image_size` in the wrong units "
    "looks exactly like a correct request. Those are the behaviours to write down, "
    "because they are the ones that will cost you an afternoon and cannot be found by "
    "reading.\n\n"
    "**The determinism probe is included even though its answer is uninteresting on the "
    "mock**, because the *question* has to be asked before Exercise 3. An evaluation "
    "harness that assumes a deterministic server will under-estimate its own variance, "
    "and one that assumes a stochastic server will spend trials measuring noise that is "
    "not there. Neither assumption is stated in the contract, so it must be measured."
)

nb.extend(
    "The document describes the contract at one moment. What you want in a repository is "
    "the probe suite itself, run as a test against whatever server the harness is about "
    "to talk to. `probe_all` plus the malformed cases is about forty lines and it turns "
    "\"the server changed its response key\" from a mystery into a failing test — which "
    "matters because the LIBERO server and the RoboLab server have *different* protocols "
    "(HTTP versus WebSocket, per `COSMOS3_FACTS.md` §5), and pointing a client at the "
    "wrong one is a mistake the schema document can warn about but only a test can catch."
)

# ---------------------------------------------------------------------------
nb.solution(
    "applied",
    "A mock closed-loop driver",
    goal="Build the client half of a closed-loop system — the part that owns the loop — "
         "and measure what it costs per chunk.",
    success="A driver completing at least 20 chunks, a JSONL action stream, a "
            "median-and-spread latency figure, a computed maximum control frequency "
            "compared against the server's `fps`, and a count of unusable responses.",
    approach="Report the latency as a median with percentiles rather than a mean (the "
             "tail is the thing that misses deadlines), and derive the control frequency "
             "from the **p95**, not the median, because a controller has to meet its "
             "deadline every time.",
)

nb.code('''
class ClosedLoopDriver:
    """The client half of the loop: observe, request, verify, advance.

    It owns the loop, which means it owns the deadline. Every chunk of `chunk`
    actions buys `chunk / fps` seconds of execution time, and the next request
    must complete inside that window or the robot runs out of commands.
    """

    def __init__(self, server_url, chunk=CHUNK, fps=20, observations=None,
                 log_path=None):
        self.url, self.chunk, self.fps = server_url, chunk, fps
        self.observations = list(observations or [])
        self.log = []
        self.log_path = Path(log_path) if log_path else None

    def observe(self, index):
        """Return a base64 PNG for step `index`. Recorded, not simulated.

        Recorded frames cycle rather than run out: a driver that stops because
        it reached the end of its recording is measuring the recording, not the
        loop. Cycling is honest as long as it is stated, and it is stated in the
        report — the observations are open-loop, so this measures the CLIENT,
        not the policy's ability to recover.
        """
        if not self.observations:
            return TINY_PNG_B64
        return self.observations[index % len(self.observations)]

    def step(self, index, prompt):
        """One iteration: observe, request, verify, return the action chunk."""
        image = self.observe(index)
        payload = {"image": image, "prompt": prompt,
                   "domain_name": "bridge_orig_lerobot", "image_size": 256}
        started = time.time()
        status, body, latency = call(self.url, "/predict", "POST", payload)
        problems = check_prediction(status, body, expected_dim=ACTION_DIM,
                                    expected_chunk=self.chunk)
        action = body.get("action") if isinstance(body, dict) else None
        record = {"index": index, "requested_at": started,
                  "latency_s": round(latency, 6), "status": status,
                  "problems": problems, "usable": not problems,
                  "n_actions": len(action) if action else 0,
                  "action": action if action else []}
        self.log.append(record)
        return record

    def run(self, n_steps, prompt):
        """Execute until `n_steps` actions have been consumed."""
        executed, index = 0, 0
        while executed < n_steps:
            record = self.step(index, prompt)
            if not record["usable"]:
                # A chunk we cannot use buys no execution time. Advancing the
                # index anyway is what a real driver must do — it cannot stop
                # the robot's clock — and it is why unusable chunks are counted
                # separately rather than retried silently.
                index += 1
                executed += 0
                if len(self.log) > n_steps * 4:
                    break
                continue
            executed += record["n_actions"]
            index += record["n_actions"]
        if self.log_path:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            with self.log_path.open("w", encoding="utf-8") as fh:
                for rec in self.log:
                    fh.write(json.dumps(rec) + "\\n")
        return self.log
''')

nb.code('''
# Step 2: feed it recorded observations. Frames from a Lesson 12 rollout if they
# exist; otherwise the tiny PNG, which the mock does not look at anyway.
frames_dir = cc.OUTPUT_ROOT / "12" / "robot_wam"
recorded = []
for path in sorted(frames_dir.rglob("*.png"))[:32]:
    recorded.append(base64.b64encode(path.read_bytes()).decode("ascii"))
print(f"recorded observations: {len(recorded)} "
      f"{'(from Lesson 12)' if recorded else '(none found; using the 1x1 PNG)'}")

PROMPT = "Put the pot to the left of the purple item."
driver = ClosedLoopDriver(MOCK_URL, chunk=CHUNK, fps=20, observations=recorded,
                          log_path=OUTPUT_DIR / "action_stream.jsonl")
log = driver.run(n_steps=24 * CHUNK, prompt=PROMPT)     # >= 20 chunks
print(f"chunks completed: {len(log)}")
print(f"wrote {driver.log_path}")
assert len(log) >= 20, "the exercise asks for at least 20 chunks"
''')

nb.code('''
latencies = [r["latency_s"] for r in log]
unusable = [r for r in log if not r["usable"]]

median = statistics.median(latencies)
p95 = float(np.percentile(latencies, 95))
p99 = float(np.percentile(latencies, 99))
spread = max(latencies) - min(latencies)

print(f"chunks            : {len(latencies)}")
print(f"median latency    : {median * 1000:.1f} ms")
print(f"p95 / p99         : {p95 * 1000:.1f} / {p99 * 1000:.1f} ms")
print(f"min / max         : {min(latencies) * 1000:.1f} / {max(latencies) * 1000:.1f} ms")
print(f"spread            : {spread * 1000:.1f} ms  "
      f"({spread / median:.0%} of the median)")
print(f"mean (for contrast): {statistics.mean(latencies) * 1000:.1f} ms")
print()
print("Hint 2's point, visible in these numbers: the mean sits below the p95, so a "
      "mean-only report hides the slow tail — and the slow tail is the only part "
      "that misses deadlines.")
print()
print(f"unusable responses: {len(unusable)} of {len(log)}")
for r in unusable[:3]:
    print(f"  chunk {r['index']}: {r['problems']}")
''')

nb.code('''
# Step 5: maximum sustainable control frequency, and the comparison that matters.
status, info, _ = call(MOCK_URL, "/info")
server_fps = info.get("fps") if isinstance(info, dict) else None
server_chunk = info.get("action_chunk_size", CHUNK) if isinstance(info, dict) else CHUNK

# A chunk of `chunk` actions at `fps` buys chunk/fps seconds of execution.
budget_s = server_chunk / server_fps if server_fps else float("nan")

# Two answers, and the difference between them is the whole point.
max_hz_median = 1.0 / median
max_hz_p95 = 1.0 / p95

print(f"server advertises : {server_fps} fps, chunk {server_chunk}")
print(f"execution budget per chunk : {budget_s * 1000:.0f} ms")
print()
print(f"max request rate from the MEDIAN latency : {max_hz_median:.1f} Hz")
print(f"max request rate from the P95    latency : {max_hz_p95:.1f} Hz  <- use this")
print()
headroom_median = budget_s / median
headroom_p95 = budget_s / p95
print(f"headroom (budget / median latency) : {headroom_median:.1f}x")
print(f"headroom (budget / p95    latency) : {headroom_p95:.1f}x")
print()
if headroom_p95 < 1.0:
    print("THE LOOP IS SLOWER THAN THE CONTROL RATE. Physically: the robot "
          "finishes the chunk it was given before the next one arrives, so it "
          "either freezes mid-motion or continues executing stale commands into "
          "a world that has moved on. Both are dangerous; the second is worse, "
          "because it looks like the robot is working.")
else:
    print(f"The loop keeps up with {headroom_p95:.1f}x headroom at the p95. "
          f"Note that this is the CLIENT and the TRANSPORT only — see below.")
print()
print("WHAT THESE NUMBERS ARE NOT. The mock sleeps 50 ms in place of denoising, "
      "so everything above measures this notebook's HTTP client, the loopback "
      "interface and json.loads. Real per-chunk latency on a diffusion policy is "
      "dominated by denoising steps, which is exactly why the RoboLab Edge "
      "command in outputs/13/commands.txt uses `--guidance-interval 960 1001` — "
      "applying guidance on only part of the schedule is a latency optimisation. "
      "Re-run this against a real server to get a number that means anything.")
''')

nb.model_answer(
    "**Why the control-frequency answer uses the p95 and not the median.**\n\n"
    "A controller has a deadline, and a deadline is not an average. The chunk currently "
    "executing buys `chunk / fps` seconds — 800 ms for 16 actions at 20 fps — and the "
    "next request must complete inside that window **every time**, not on average. A loop "
    "whose median latency is comfortably inside the budget and whose p99 is outside it "
    "will miss its deadline once every hundred chunks. At 1.25 chunks per second that is "
    "roughly once every eighty seconds, which is often enough to matter and rare enough "
    "to be invisible in any summary that reports a mean.\n\n"
    "Hint 2 makes this point about reporting and it is really a point about *which "
    "statistic corresponds to the physical requirement*. Throughput questions take the "
    "median. Deadline questions take a high percentile. Using the wrong one is not a "
    "presentational choice; it produces a number that answers a question nobody asked.\n\n"
    "**What a missed deadline means physically.** Two failure modes, and the second is "
    "worse:\n\n"
    "1. **The robot stalls.** It exhausts its action chunk and stops until the next one "
    "arrives. Visible, ugly, usually safe.\n"
    "2. **The robot continues on stale commands.** Many controllers hold the last "
    "command rather than stopping. The arm keeps moving according to a plan computed "
    "from an observation that is now 200 ms old. Nothing errors, the motion looks "
    "smooth, and the policy is acting on a world that has moved. In a contact-rich task "
    "this is how you break something, and it is *invisible to every metric in this "
    "notebook* — the request succeeded, the action was well-formed, the loop kept "
    "running.\n\n"
    "**Why unusable chunks are counted rather than retried.** The driver advances the "
    "index on an unusable response instead of retrying silently. That mirrors reality: "
    "the robot's clock does not stop while your client retries. A retry is not free, it "
    "spends the execution budget of the chunk that is currently running, so a driver that "
    "retries transparently converts a visible failure into a deadline miss. Counting "
    "unusable chunks separately — as the success criterion asks — keeps the two "
    "distinguishable.\n\n"
    "**A limitation of this measurement worth stating.** The observations are *recorded* "
    "and cycle. That means the loop is open — the policy's output does not affect the "
    "next observation — so this measures the client, the transport and the server's "
    "response time, and says nothing about whether the policy can recover from its own "
    "mistakes. That is the thing closed-loop evaluation exists to measure, and it needs a "
    "simulator, which needs a second virtualenv (`COSMOS3_FACTS.md` §5: `robosuite "
    "1.4.1`, `mujoco 2.3.7`, `torch<2.6` will not coexist with the training "
    "environment). Exercise 3 designs that."
)

nb.extend(
    "The driver requests a chunk, waits, then executes it. A real controller "
    "**pipelines**: it issues the next request as soon as the current chunk starts "
    "executing, so the request latency is hidden inside the execution window rather than "
    "added to it. That changes the deadline from `latency < chunk/fps` to `latency < "
    "chunk/fps + execution_time_already_elapsed`, which is a much easier target, and it "
    "is why real systems tolerate latencies that look impossible from these numbers. It "
    "also introduces a new failure — the observation the request was made from is one "
    "chunk stale by the time the actions are used — which is a genuine trade rather than "
    "a free win, and worth measuring rather than assuming."
)

# ---------------------------------------------------------------------------
nb.solution(
    "challenge",
    "Design a closed-loop evaluation you could actually run",
    goal="Produce a design document and a harness skeleton for a real closed-loop "
         "evaluation on a second machine.",
    success="`outputs/13/closed_loop_design.md` covering all six points, plus a harness "
            "that runs against the mock and emits a report with confidence intervals. "
            "The sample-size section must contain a derivation, not a number.",
    approach="Derive the sample size from the interval width you are willing to publish, "
             "run the harness against **three** policies — the real one, a zero policy "
             "and a random policy — and state in advance which results would indict the "
             "policy versus the harness.",
)

nb.code('''
@dataclass
class TrialRecord:
    task: str
    trial: int
    success: bool
    steps: int
    seconds: float
    failure_mode: str = ""
    notes: dict = field(default_factory=dict)


def wilson_interval(successes, n, z=1.96):
    """Confidence interval for a binomial proportion.

    Hint 1: the normal approximation breaks exactly where policy evaluation
    lives. At 0 successes in 10 it gives [0, 0] — a claim of certainty from ten
    trials — and at 1 in 20 it gives a lower bound BELOW ZERO. Wilson does
    neither: it is the interval you get by inverting the score test rather than
    by pretending the proportion is normally distributed.
    """
    if n <= 0:
        return 0.0, 1.0
    p = successes / n
    denom = 1 + z ** 2 / n
    centre = (p + z ** 2 / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / denom
    return max(0.0, centre - half), min(1.0, centre + half)


import math  # noqa: E402  (used by wilson_interval above)

# Check against cases verifiable by hand, as hint 1 asks.
lo, hi = wilson_interval(0, 10)
assert lo == 0.0 and 0.25 < hi < 0.35, (lo, hi)
print(f"0 successes in 10  -> [{lo:.3f}, {hi:.3f}]  "
      f"(the normal approximation gives [0.000, 0.000], a false certainty)")
lo, hi = wilson_interval(10, 10)
assert hi == 1.0 and 0.65 < lo < 0.75, (lo, hi)
print(f"10 successes in 10 -> [{lo:.3f}, {hi:.3f}]")
lo, hi = wilson_interval(25, 50)
assert abs((lo + hi) / 2 - 0.5) < 1e-9, (lo, hi)
print(f"25 successes in 50 -> [{lo:.3f}, {hi:.3f}]  (width {hi - lo:.3f})")
print("PASS the Wilson interval behaves correctly at both extremes and at 50%")
''')

nb.code('''
# ---- STEP 3: the sample-size DERIVATION, not a number -------------------
#
# Success rate is a binomial proportion. The Wilson interval is widest at
# p = 0.5, so sizing there is conservative and the width is approximately
#
#     w  ~=  2 * z * sqrt(p(1-p)/n)  =  z / sqrt(n)   at p = 0.5, z = 1.96
#
# so   n  ~=  (z / w)^2  =  (1.96 / w)^2.
def n_for_width(target_width, z=1.96, p=0.5):
    """Trials needed for a Wilson interval no wider than `target_width` at `p`."""
    n = 1
    while n < 100000:
        lo, hi = wilson_interval(round(p * n), n, z)
        if hi - lo <= target_width:
            return n
        n += 1
    return None


print(f"{'target width':>14}{'trials needed':>16}   what it buys")
print("-" * 78)
for width, buys in [(0.30, "distinguishes 'works' from 'does not' and little else"),
                    (0.20, "distinguishes a 40% policy from a 70% one"),
                    (0.10, "distinguishes a 55% policy from a 70% one"),
                    (0.05, "distinguishes a 60% policy from a 67% one")]:
    print(f"{width:>14.2f}{n_for_width(width):>16}   {buys}")

# What upstream's own design buys, worked out rather than assumed.
UPSTREAM_TRIALS_PER_TASK, UPSTREAM_TASKS = 50, 10
lo, hi = wilson_interval(25, UPSTREAM_TRIALS_PER_TASK)
lo_all, hi_all = wilson_interval(250, UPSTREAM_TRIALS_PER_TASK * UPSTREAM_TASKS)
print()
print(f"upstream's LIBERO eval: {UPSTREAM_TRIALS_PER_TASK} trials/task x "
      f"{UPSTREAM_TASKS} tasks")
print(f"  PER TASK   at 50%: [{lo:.3f}, {hi:.3f}]  width {hi - lo:.3f}")
print(f"  POOLED     at 50%: [{lo_all:.3f}, {hi_all:.3f}]  width {hi_all - lo_all:.3f}")
print()
print("So a per-task rate from 50 trials is worth about +/-14 points, which cannot")
print("separate a 45% task from a 60% one. The POOLED rate over 500 trials is worth")
print("about +/-4 points, which can. That is the design decision hiding in those two")
print("numbers: upstream's setup is sized to compare CHECKPOINTS on the whole suite,")
print("not to rank tasks within it. Reporting per-task rates from it and drawing")
print("conclusions about which tasks are hard is reading noise.")
print()
CHOSEN_WIDTH = 0.10
TRIALS_PER_TASK = 50
TASKS = 10
print(f"CHOSEN: {TRIALS_PER_TASK} trials/task over {TASKS} tasks = "
      f"{TRIALS_PER_TASK * TASKS} trials, pooled width ~{hi_all - lo_all:.2f}. "
      f"Chosen because the comparison I want to make is between two checkpoints on "
      f"the whole suite, and a {CHOSEN_WIDTH:.0%} pooled interval separates the "
      f"differences worth acting on.")
''')

nb.code('''
# ---- STEP 5: the harness. Real, with the environment stubbed. ------------
def stub_environment(action_chunk, *, rng, difficulty=0.45):
    """Stand in for a simulator. Returns (success, steps, failure_mode).

    Deliberately crude and deliberately SENSITIVE to the action: a chunk of
    zeros can never succeed, and a chunk whose translations are pure noise
    succeeds only by luck. That sensitivity is what makes the broken-policy
    controls in step 6 meaningful — an environment stub that ignores the action
    would score all three policies identically and prove nothing.
    """
    arr = np.asarray(action_chunk, dtype=float) if len(action_chunk) else np.zeros((1, ACTION_DIM))
    motion = float(np.linalg.norm(arr[:, :3], axis=1).mean())
    grips = float(np.abs(np.diff(arr[:, 9])).sum()) if arr.shape[0] > 1 else 0.0
    if motion < 1e-6:
        return False, 0, "no motion commanded"
    if motion > 0.5:
        return False, len(arr), "commanded motion out of range"
    if grips < 0.5:
        return False, len(arr), "gripper never actuated"
    success = bool(rng.random() < difficulty)
    # Even the residual failures get a named mode. "unattributed" in a taxonomy
    # is a signal that the harness cannot see why trials fail, and a taxonomy
    # dominated by it is one of the harness-is-broken conditions in step 6.
    return success, len(arr), "" if success else "task not completed within horizon"


def run_trials(server_url, tasks, trials_per_task, *, policy="server", seed=0,
               chunk=CHUNK):
    """Trial loop. Stub the environment; keep the harness real."""
    rng = np.random.default_rng(seed)
    records = []
    for task in tasks:
        for trial in range(trials_per_task):
            started = time.perf_counter()
            if policy == "server":
                _, body, _ = call(server_url, "/predict", "POST",
                                  {**GOOD_REQUEST, "prompt": task})
                action = body.get("action") or [] if isinstance(body, dict) else []
            elif policy == "zero":
                action = np.zeros((chunk, ACTION_DIM)).tolist()
            elif policy == "random":
                a = rng.normal(0, 0.01, (chunk, ACTION_DIM))
                a[:, 9] = rng.integers(0, 2, chunk)
                action = a.tolist()
            else:
                raise ValueError(policy)
            success, steps, mode = stub_environment(action, rng=rng)
            records.append(TrialRecord(task=task, trial=trial, success=success,
                                       steps=steps,
                                       seconds=time.perf_counter() - started,
                                       failure_mode=mode,
                                       notes={"policy": policy,
                                              "n_actions": len(action)}))
    return records


def aggregate(records):
    """Pooled and per-task rates with Wilson intervals, plus a failure taxonomy."""
    n = len(records)
    ok = sum(r.success for r in records)
    lo, hi = wilson_interval(ok, n)
    per_task = {}
    for r in records:
        bucket = per_task.setdefault(r.task, [0, 0])
        bucket[0] += int(r.success)
        bucket[1] += 1
    taxonomy = {}
    for r in records:
        if not r.success:
            key = r.failure_mode or "unattributed"
            taxonomy[key] = taxonomy.get(key, 0) + 1
    return {"n": n, "successes": ok, "rate": ok / n if n else 0.0,
            "ci": (lo, hi), "width": hi - lo,
            "per_task": {t: (s, m, *wilson_interval(s, m))
                         for t, (s, m) in per_task.items()},
            "median_seconds": statistics.median([r.seconds for r in records])
                              if records else 0.0,
            "failure_taxonomy": taxonomy}
''')

nb.code('''
TASKS = [f"libero_10 task {i}" for i in range(1, 11)]
TRIALS = 20          # reduced from the designed 50 so this notebook stays quick

# Step 6's controls, run BEFORE the result is interpreted.
runs_by_policy = {}
for policy in ("server", "zero", "random"):
    records = run_trials(MOCK_URL, TASKS[:4], TRIALS, policy=policy, seed=0)
    runs_by_policy[policy] = aggregate(records)

print(f"{'policy':<10}{'n':>5}{'rate':>8}{'95% CI':>20}{'width':>8}  top failure")
print("-" * 76)
for policy, agg in runs_by_policy.items():
    top = max(agg["failure_taxonomy"], key=agg["failure_taxonomy"].get) \\
        if agg["failure_taxonomy"] else "-"
    print(f"{policy:<10}{agg['n']:>5}{agg['rate']:>8.2f}"
          f"   [{agg['ci'][0]:.3f}, {agg['ci'][1]:.3f}]{agg['width']:>8.3f}  {top}")

# The harness must separate the real policy from both broken controls, or it is
# not measuring what it claims to.
assert runs_by_policy["zero"]["rate"] == 0.0, runs_by_policy["zero"]
assert runs_by_policy["server"]["rate"] > runs_by_policy["zero"]["ci"][1], (
    "the harness cannot distinguish the policy from a zero policy")
print()
print("PASS the zero policy scores 0 and the server policy is above its upper "
      "confidence bound — the harness can tell them apart")
print(f"     random policy: {runs_by_policy['random']['rate']:.2f} "
      f"[{runs_by_policy['random']['ci'][0]:.3f}, "
      f"{runs_by_policy['random']['ci'][1]:.3f}]")
if runs_by_policy["random"]["ci"][1] >= runs_by_policy["server"]["ci"][0]:
    print("     NOTE: the random policy's interval OVERLAPS the server's. On this "
          "stub environment that is expected — see the falsifiability section.")
''')

nb.code('''
CONFOUNDS = [
    ("Camera concat layout",
     "COSMOS3_FACTS.md section 5, parity gotcha 1: the eval client must pass "
     "`--camera agentview,wrist --image_size 256`. A different order or a "
     "different size feeds the policy an observation it never trained on.",
     "Pin the exact flags in the run script; assert on `/info`'s reported "
     "`image_size` before the first trial."),
    ("Gripper sign",
     "Parity gotcha 2: the simulator's gripper convention is flipped relative to "
     "training; apply `1 - 2g`.",
     "Apply the transform in one place in the client, and unit-test it against a "
     "recorded training episode."),
    ("Frame rotation",
     "Parity gotcha 3: simulator frames are rotated 180 degrees relative to "
     "training frames.",
     "Rotate in the observation adapter, and eyeball the first frame of the "
     "first trial against a training frame every run."),
    ("Action normalisation",
     "Parity gotcha 4: `--action-normalization quantile_rot` is mandatory or "
     "actions come out at the wrong scale.",
     "Pin it in the server command; log the value the server reports on `/info` "
     "into every trial record."),
    ("Seed and task ordering",
     "Success rate depends on initial states. Running tasks in a fixed order "
     "with a fixed seed makes two checkpoints comparable; not doing so makes "
     "the difference between them partly a difference in initial states.",
     "Seed per (task, trial) deterministically, and record the seed in the "
     "TrialRecord so any trial can be replayed."),
    ("Server warm-up",
     "The first request after a cold start pays weight loading and CUDA graph "
     "capture, so trial 0 is systematically slower and can time out.",
     "Discard a fixed number of warm-up requests before the first recorded "
     "trial, and record how many were discarded."),
    ("Wall-clock timeouts",
     "A trial that hangs must be recorded as a failure with a distinct mode, "
     "not silently retried — otherwise a policy that hangs on hard tasks looks "
     "better than one that fails on them.",
     "A per-trial deadline; on expiry record success=False, "
     "failure_mode='timeout'."),
]
for name, why, control in CONFOUNDS:
    print(f"- {name}\\n    risk   : {why}\\n    control: {control}\\n")
print(f"{len(CONFOUNDS)} confounds (the exercise asks for at least five)")
''')

nb.code('''
agg = runs_by_policy["server"]
lines = [
    "# Closed-loop evaluation — design document",
    "",
    "For a real evaluation on a second machine. The harness below was executed "
    "against the mock server in this notebook, so the RESULTS are fabricated and the "
    "MACHINERY is real: swapping `MOCK_URL` for a real policy-server URL and "
    "`stub_environment` for the LIBERO simulator is the only change.",
    "",
    "## 1. Environment",
    "",
    "**Machine A — the policy server.** One H100 80GB. The training/inference "
    "virtualenv (`uv sync --all-extras --group=cu130-train`, CUDA >= 12.8, Python "
    ">= 3.10). Runs:",
    "",
    "```",
    (cc.OUTPUT_ROOT / "13" / "commands.txt").read_text().split("\\n\\n")[0]
    if (cc.OUTPUT_ROOT / "13" / "commands.txt").exists()
    else "python -m cosmos_framework.scripts.action_policy_server_libero ...",
    "```",
    "",
    "**Machine B — the simulator and eval client.** A SEPARATE virtualenv, because "
    "`COSMOS3_FACTS.md` §5 records that `robosuite==1.4.1`, `mujoco==2.3.7` and "
    "`torch<2.6` will not coexist with the training environment. `MUJOCO_GL=egl`, "
    "LIBERO on `PYTHONPATH`.",
    "",
    "**Network.** Same host or same LAN. The client's per-chunk deadline is "
    f"`chunk/fps` = {CHUNK}/{20} = {CHUNK / 20 * 1000:.0f} ms, so a link whose p95 "
    "RTT is a material fraction of that will produce deadline misses that look like "
    "policy failures.",
    "",
    "**Checkpoint.** A POST-TRAINED DCP directory. `COSMOS3_FACTS.md` §5: **the base "
    "checkpoint has no action heads**, so it cannot be served by the policy server at "
    "all. This is the practical argument for Module 5.",
    "",
    "## 2. Metrics",
    "",
    "**Primary — task success rate.** Success is decided by the SIMULATOR's own "
    "task-completion predicate, not by a human and not by the policy. Horizon: the "
    "task's own step limit; a trial that reaches it without the predicate firing is a "
    "failure, not a timeout.",
    "",
    "**Secondary 1 — time to completion**, in simulator steps, over successful trials "
    "only. Reported as a median; a policy that succeeds slowly is different from one "
    "that succeeds quickly and the primary metric cannot see it.",
    "",
    "**Secondary 2 — per-chunk latency**, p50 and p95, from the client. This is what "
    "Exercise 2 measures, and it belongs here because a deadline miss degrades the "
    "primary metric through a mechanism that has nothing to do with the policy.",
    "",
    "**Secondary 3 — failure taxonomy.** Every failed trial gets a mode. Observed "
    "here: " + ", ".join(f"`{k}`" for k in agg["failure_taxonomy"]) + ".",
    "",
    "## 3. Sample size (derived)",
    "",
    "Success rate is a binomial proportion, so the Wilson interval half-width at "
    "p = 0.5 is approximately `z / (2*sqrt(n))`, giving `n ~= (z/w)^2` for a target "
    "width `w`:",
    "",
    "| target width | trials |",
    "|---:|---:|",
] + [f"| {w:.2f} | {n_for_width(w)} |" for w in (0.30, 0.20, 0.10, 0.05)] + [
    "",
    f"Upstream's own design is 50 trials/task over 10 tasks. That buys a PER-TASK "
    f"interval of about +/-{(wilson_interval(25, 50)[1] - wilson_interval(25, 50)[0]) / 2:.2f} "
    f"— too wide to rank tasks — and a POOLED interval of about "
    f"+/-{(wilson_interval(250, 500)[1] - wilson_interval(250, 500)[0]) / 2:.2f}, which "
    f"is enough to compare two checkpoints on the whole suite. **Chosen: the same 500 "
    f"trials, reported POOLED**, with per-task rates shown but explicitly labelled as "
    f"too noisy to rank.",
    "",
    "## 4. Confounds and controls",
    "",
    "| confound | control |",
    "|---|---|",
] + [f"| {name} | {control} |" for name, _why, control in CONFOUNDS] + [
    "",
    "## 5. Harness",
    "",
    "`run_trials` / `aggregate` / `wilson_interval` in this notebook, executed against "
    "the mock. Per-trial records carry task, trial index, success, steps, seconds, "
    "failure mode and notes. Aggregation emits pooled and per-task rates with Wilson "
    "intervals and a failure taxonomy.",
    "",
    "| policy | n | rate | 95% CI |",
    "|---|---:|---:|---|",
] + [f"| {p} | {a['n']} | {a['rate']:.2f} | [{a['ci'][0]:.3f}, {a['ci'][1]:.3f}] |"
     for p, a in runs_by_policy.items()] + [
    "",
    "## 6. Falsifiability",
    "",
    "**What would make me conclude the POLICY is not working:** the pooled success "
    "rate's upper confidence bound falls below the zero-policy's upper bound, or below "
    "a pre-registered floor (say 20% on libero_10), while the harness passes its own "
    "controls — the zero policy scores 0, the random policy scores near the "
    "environment's chance rate, and per-chunk p95 latency is inside the deadline.",
    "",
    "**What would make me conclude the HARNESS is not working:** any of these, and each "
    "is checkable before looking at the real result —",
    "",
    "- the zero policy scores above 0 (the environment is not reading the action);",
    "- the random policy's interval overlaps the real policy's (the environment "
    "cannot discriminate, so neither can the metric);",
    "- per-chunk p95 latency exceeds the deadline (deadline misses are contaminating "
    "the success rate through a mechanism unrelated to the policy);",
    "- the failure taxonomy is dominated by `unattributed` (failures are happening "
    "for reasons the harness cannot see, so the rate is uninterpretable).",
    "",
    "**Being unable to distinguish those two is the most common way an evaluation "
    "wastes a week**, and the reason the broken-policy controls run FIRST. A zero "
    "policy and a random policy cost nothing, need no checkpoint, and answer 'is my "
    "measuring instrument working' before the expensive question is asked.",
]
design_path = OUTPUT_DIR / "closed_loop_design.md"
design_path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
print(f"wrote {design_path}  ({len(lines)} lines)")

mock_server.shutdown()
print("mock server shut down")
''')

nb.why(
    "**Why the sample size is derived rather than copied.** The exercise insists on a "
    "derivation and the reason shows up immediately: working out what upstream's 50 "
    "trials per task actually buys reveals that a per-task rate from it is worth about "
    "+/-14 points. That cannot separate a 45% task from a 60% one. So a paper reporting "
    "per-task rates from that design and drawing conclusions about which tasks are hard "
    "is reading noise — and you can only see that by doing the arithmetic. Copying the "
    "number would have carried the design's *intent* (compare checkpoints on the whole "
    "suite) without carrying its *limits*.\n\n"
    "**Why Wilson and not the normal approximation.** Hint 1 gives the reason and the "
    "assertions above make it concrete: at 0 successes in 10, the normal approximation "
    "gives the interval [0, 0] — a claim of certainty from ten trials — and near the "
    "extremes it produces lower bounds below zero. Policy success rates live near the "
    "extremes, especially early in a project, so this is not a corner case, it is the "
    "common case.\n\n"
    "**Why the broken-policy controls run before the result is read.** Hint 2 calls this "
    "the sharpest tool available and it is. A zero policy and a random policy cost "
    "nothing, need no checkpoint, and answer the question that must be settled first: "
    "*can this harness tell a working policy from a non-working one at all?* If it "
    "cannot, the real number is uninterpretable no matter what it is. Running the "
    "controls afterwards is much worse, because by then you have seen the result and you "
    "will be looking for reasons to believe it.\n\n"
    "The assertion that the server policy beats the zero policy's upper bound is the "
    "harness's own pass/fail, and it is deliberately an `assert` rather than a print: a "
    "harness that has silently stopped discriminating should stop the notebook.\n\n"
    "**Why `stub_environment` is sensitive to the action.** A stub that ignores the "
    "action and flips a coin would let every policy score the same, and every control "
    "above would pass vacuously. Making it reject zero motion, out-of-range motion and a "
    "never-actuated gripper means the controls actually exercise something — and it "
    "models three real failure modes, which is where the failure taxonomy comes from.\n\n"
    "**On the six-point structure.** Points 1–5 are the parts most designs contain. "
    "Point 6 is the one most designs omit, and it is the one that decides whether a "
    "surprising result is informative. Writing down in advance what would indict the "
    "policy *and* what would indict the harness is what stops a week being spent "
    "discovering that the answer is \"one of those two\"."
)

nb.extend(
    "The design evaluates one checkpoint. The comparison you will actually want is "
    "between two — before and after post-training — and that is a **paired** comparison, "
    "which is statistically much cheaper than two independent ones. Running both "
    "checkpoints on the *same* seeds and the same initial states removes the "
    "initial-state variance from the difference, so the interval on the difference is "
    "narrower than the intervals on either rate. Concretely: two 500-trial evaluations "
    "give you two +/-4-point rates and a difference you can barely resolve; the same "
    "1000 trials run as pairs give you a difference with an interval perhaps half that. "
    "The change is one line in the trial loop — seed by `(task, trial)` rather than "
    "globally — and it is the single highest-leverage thing in this design."
)

nb.finish()
