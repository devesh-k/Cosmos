---
lesson: "12"
title: "The World Action Model"
slug: "12_action_wam"
duration_estimate: "13 min"
words: 1900
---

# Lesson 12 — The World Action Model

The last two lessons ran Cosmos 3 as a dynamics model. A dynamics model is a thing that knows how the world changes. This lesson runs the same checkpoint as a policy. A policy is a thing that decides what to do. Those are different kinds of object with different failure surfaces, and the difference is worth being precise about before you run anything.

By the end of this lesson you will be able to state what a policy is in terms of what it maps from and what it maps to. You will know the live name of the world action mode in Cosmos 3, and more importantly you will know how to check that name yourself instead of trusting a document. You will be able to take a ten-number robot action apart into its pieces, integrate it into a path through space, and pull a grasp out of the gripper channel. And you will understand why everything you do in this lesson is a weak form of control, which is the problem the next lesson takes on.

There is one more thing. This is the lesson where the older course material this was adapted from stops working, because a mode was renamed upstream. Fixing that is the first thing you do. The technique you use to fix it is worth considerably more than the fix.

## What makes a policy different

Start with type signatures, because that is the whole distinction. Forward dynamics maps a state and an action to the next state. It answers, what happens if I do this. Inverse dynamics maps two states to the action between them. It answers, what did I do. A policy maps a state and a goal to an action. It answers, what should I do.

The first two describe the world. The third makes a choice. Two consequences follow, and both of them matter.

The first consequence is that a policy needs a goal and a dynamics model does not. What happens if I do this is a complete question. What should I do is not a complete question until you say what you are trying to achieve. In Cosmos 3 the goal arrives as a natural language instruction in the prompt field. That means the same observation under a different instruction is a genuinely different query, and you can test whether the model agrees.

The second consequence is that a policy can be wrong in a way a dynamics model cannot. A dynamics model that predicts implausible physics is inaccurate, and you can see the inaccuracy. A policy that predicts a smooth, physically perfect motion towards the wrong object is completely accurate and completely useless. Verifying a policy therefore means checking that it did what you asked, not only that its output is well formed. That is harder, and it is what most of this lesson is about.

Now the part that makes the Cosmos 3 version unusual. One forward pass produces two things. It produces a predicted video of the next few seconds, and it produces a predicted action chunk. The model imagines what happens next, and it reads the action off its own imagination. Those two outputs are predictions of the same future in two different languages, which means they can be checked against each other. If the rollout video shows the gripper closing halfway through, and the action sequence keeps the gripper open the whole way, something is wrong even though neither output is malformed. That cross-check costs nothing and needs no ground truth.

## The mode that was renamed

The older spec sets the model mode field to policy. That value is dead. Upstream renamed the mode to wam, spelled w, a, m, for World Action Model, and removed the old name from the enum entirely. A run with the old value fails validation before it touches the GPU.

What makes this worth a section rather than a footnote is where the old name still lives. There are three independent confirmations that wam is the live name. The frozen set of action model modes in the framework contains the wam member alongside forward dynamics and inverse dynamics. The defaults directory contains a folder for wam and no folder for policy. And the two shipped example input files, whose filenames still say policy, both contain a model mode of wam inside. The filenames lagged the rename. The contents did not.

Meanwhile the framework's own inference documentation still says policy. So does its FAQ. So does the action cookbook readme. All three are wrong. Trust the enum, not the prose.

There is a trap waiting if you go and verify this yourself by fetching raw files from GitHub. The plain main branch address serves a stale cached copy that still shows the old name. The address form that spells out refs, then heads, then main serves the current file. That is a real trap, and it cost time to find. It is worth knowing because a stale cache is the one failure mode that makes you doubt a conclusion you had already got right.

The habit underneath all of this generalises well past one field. When a framework rejects a value, the authoritative list is in the code, usually one search away. Documentation describes what was true when somebody wrote it. An enum describes what is true now. The notebook gives you a small helper that dumps any enum out of the framework's own environment, and it is worth keeping in your own toolbox.

## Reading the action, and the gripper

The observation you give the model is a local recording that ships with the cookbook. It is a robot arm working in a kitchen, stored in the LeRobot version three layout, with video in shards and numeric data in Parquet. One thing to check before handing it to anything. The codec. Those shards are frequently AV1, which several decoders in this stack cannot open, and a video that fails to decode reaches the model as zero frames rather than as an error. The notebook transcodes it first.

The spec you write differs from the old one in exactly one field. Everything else is the cookbook's, unchanged. Note that there is no action path in it. The world action model predicts the actions. Supplying them would be answering its question for it.

Run it, and you get both outputs. Now take the action apart. A driving action in the earlier lessons was nine numbers wide. A Bridge robot action is ten, and the extra number is the one that does the work. The first three numbers are a translation delta for the end effector, which is the gripper at the end of the arm. The next six are a rotation in the six-number form you already met, which is the first two columns of a rotation matrix. The tenth is a single scalar for the gripper. None of this is guesswork. The framework has a table mapping each embodiment to its raw action width, and it gives Bridge ten, DROID ten, and driving nine.

Integrate the translation deltas and you get the path the gripper traces through space. Because the deltas accumulate, a small systematic bias shows up as visible drift by the end. That is the same compounding you measured with inverse dynamics.

Then the gripper channel, and here is where you must be careful. Which end of that channel means closed is a per-dataset convention, not a universal truth. Upstream's own evaluation client applies one minus two times g to the model's gripper output before handing it to the simulator, precisely because the model's range and the environment's range disagree. Their documentation adds, flip the sign if the gripper never opens, which tells you how often this bites people.

So do not assume the polarity. Determine it. Find where the channel changes substantially. Convert each transition's step index into a time using the frame rate. Watch the rollout at those times and see whether the jaws are opening or closing. A grasp has a characteristic shape. Approach with the gripper at one extreme, one transition to the other extreme, a period of holding, and often a transition back at release. Write down the polarity you observed, because the next lesson compares against it directly.

The last experiment holds the observation and the seed fixed and changes only the instruction. If the goal is doing any work, the action must change. If it does not, the model is ignoring your instruction and predicting the most likely continuation of the video. Run it with a control: the same instruction twice at different seeds, which gives you a noise floor. A difference smaller than the noise floor is not a difference.

All of this has been open loop. One observation in, sixteen actions out, execute all sixteen blind. Three things break, and none of them is a quality problem you can train your way out of. Error compounds, because relative predictions accumulate. There is no recovery from disturbance, because if somebody moves the pot the plan carries on regardless. And there is no recovery from the policy's own mistakes, because actions four through sixteen were computed for the position the plan assumed, not the position the arm is actually in.

## The lab: running with a dead mode name

Here is the debugging lab, and it is short because the point is the method.

The symptom. You follow a tutorial written before the rename, or you follow the current inference documentation, which is stale in exactly the same way. The run dies before producing anything. The error mentions a value that is not permitted and lists a set of names, and the name you used is not among them.

The notebook has you reproduce this deliberately, which takes some doing, because the course helpers are forgiving. They quietly normalise the dead name to the live one. To see the real failure you have to bypass them and hand the framework raw configuration, which is what a tutorial would have done.

The hypothesis. The model mode field is validated against an enum, and your value is not a member of it.

The one diagnostic that settles it. Read the enum in your own checkout. Not the docs, not this course, not a blog post. Ask the framework's own interpreter what the members are, and check both that wam is present and that policy is absent. That single question answers everything and takes a second.

The repair is one word. Set the model mode field to wam.

The verification is where people stop too early. It ran is not verification. Three things, in order. The mode you used is a member of the enum in your checkout. The run produced both outputs, a rollout video and an action file, because a run that produces only one of them has not done what the mode promises. And the action array is ten wide, which is what the Bridge embodiment requires.

Three things to take away. A policy needs a goal, and that is what separates it from a dynamics model. The mode is wam, and the way you know that is the enum rather than the prose. And the gripper polarity is a convention you measure, never a constant you assume.

The next lesson closes the loop, and is honest about which half of it fits on one machine.
