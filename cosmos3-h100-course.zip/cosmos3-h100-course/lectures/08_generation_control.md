---
lesson: "08"
title: "Control-conditioned generation and augmentation"
slug: "08_generation_control"
duration_estimate: "13 min"
words: 1791
---

# Lesson 08 — Control-conditioned generation and augmentation

Here is the problem this lesson solves. You have one real recording. A rig, a driver, a permit, a day of shooting. It shows one lighting condition, one weather, one set of surfaces. A perception model trained on that recording will fail the first time the sun comes from a different angle. Collecting more real footage is slow and expensive. Generating a thousand unrelated clips does not help either, because none of them carry labels.

Control-conditioned generation is the middle path. You take the recording, extract a structural summary of it, and regenerate the video under that constraint. The geometry, the motion and the timing survive. The light, the materials and the weather do not. So every variant is a recording of the same event. If you had a bounding box on frame forty of the source, it is still correct on frame forty of every variant, because the constraint pinned the geometry. That property is worth more than the pixels.

By the end of this lesson you will be able to write a transfer spec from scratch, name the four control hints and say what each one preserves and what it discards, predict which one suits a given edit, and diagnose the most common failure in this whole workflow. That failure is a clip which comes out the wrong length while every check you ran said it was fine.

One decision first, and the notebook makes you take it deliberately. This lesson needs the Nano checkpoint, which is about thirty-five gigabytes on disk. That is not a preference. Edge cannot do transfer at all. Edge is four billion parameters, capped at 480p, about nine gigabytes, with no audio and no transfer pathway. Super cannot do transfer either, and in any case it needs about a hundred and twenty-eight gigabytes of VRAM for framework inference, which does not fit an eighty gigabyte card. Nano is sixteen billion parameters in total with eight billion active, and it is the only tier that can do this. The download is opt-in. Everything that does not need a GPU still runs without it.

## Transfer is not a mode

Three things matter here, and this is the first. Transfer is not one of the model modes. There is no mode called transfer and there never was. If you go looking for one you will waste an afternoon and then find a stale documentation page that agrees with you.

What transfer actually is: you set the model mode to video-to-video, and you add a control hint block to the same spec. The framework sees that block, and takes the transfer path. The block names one hint, gives it the path to a control video, and gives it a weight. That is the entire mechanism. Change the name of the block from edge to depth and you get depth-conditioned transfer with the same model, the same mode and the same launch command.

The notebook settles this from your own installation before you download anything. It imports the course package, prints the mode list, and shows you that transfer is absent from it and video-to-video is present. That cell needs no GPU. The habit is the point. When the prose and the enum disagree, the enum wins.

There is one more piece of path handling worth knowing before you write a spec. The framework resolves conditioning paths relative to the spec file. The source course dealt with that by changing directory into the cookbook before launching. This course runs the generator with its working directory inside the framework checkout instead, so it rewrites every conditioning path to an absolute path when it writes the spec. Read the shipped spec first anyway. It is the authoritative example, and the paths in it are still relative, which is exactly the thing to notice.

## Four hints and what each one discards

That is the first idea. Here is the second. The control hint enum has exactly four members, and the right way to hold them in your head is as a trade.

Edge preserves shape, layout and fine detail. It is good for material and texture changes. Blur preserves colour, lighting and overall look, and is good for subtle appearance edits. Depth preserves 3D structure and spatial scale, and is good for relighting. Segmentation preserves object and region identity, and is good for replacing objects or backgrounds.

Now the trade. Every hint is a lossy summary of the source video, and what it throws away is exactly what you are free to change. An edge map has no colour, so colour is yours. A depth map has no texture, so texture is yours. A segmentation map has no geometry inside a region, so the inside of each region is yours. Once you see that, you can predict a hint's behaviour without running it.

There is a fifth thing that is not a hint. The cookbook ships an asset family called the world scenario map. It uses the same mechanism and it is not a member of the enum. The course keeps two lists on purpose. One list accepts it so that specs containing it validate, the other documents only the four that are really in the enum. If you find those lists disagreeing, that disagreement is deliberate.

And a naming collision worth defusing now. Edge is a model tier. Edge is also a control hint. They have nothing to do with each other, and the Edge tier is the one tier that cannot run the edge hint. Say the Edge checkpoint and the edge control out loud a few times, because otherwise you will meet this confusion in your own notes.

Measuring what survived comes next. The notebook gives you two crude, transparent metrics, and asks you to state their bias out loud. Structure retention correlates the gradient map of the output against the gradient map of the control. It is biased in favour of edge, because an edge control map essentially is a gradient map, so do not use it to rank hints against each other. Motion agreement correlates the per-frame change profile of the output against the control's, and it is control-agnostic, so it is the fairer cross-hint comparison. Neither is a quality metric. Both answer one question: did the conditioning have any effect at all.

## The control video decides the geometry

Here is the third idea, and it is the one that costs people mornings. The output's frame count, frame rate and pixel geometry come from the control video, not from your spec.

That is not a quirk. The control is a per-frame conditioning signal. There is one control frame per output frame, by construction. Asking for sixty-one output frames while supplying a hundred and twenty-one control frames is not a request the pipeline can honour. It does not fail. It follows the control.

So the first thing to do with any control video is measure it. The shipped controls are a hundred and twenty-one frames at thirty frames per second, except the world scenario map, which is a hundred and one frames at ten. Check that on your own disk rather than believing me. In reduced mode the notebook trims the control to a third of its length, and that trim is more than a convenience. It is the demonstration, because the output will follow the trimmed length rather than anything in your spec.

Multi-control deserves an honest note here. More than one hint can be supplied at once, and each block carries a weight, so the framework aggregates their attention contributions accordingly. Two controls at weight one are not the same as one control at weight two. The weights are relative influence, not gain. The honest part is that the cookbook's own documentation refers to a multi-control asset directory which does not exist in the checkout. There is no shipped example to copy. The course builds a multi-control spec, validates it, and stops there. Reporting the gap is more useful than inventing a replacement and presenting it as documented.

## The clip that came out the wrong length

Now the lab, and it is worth your attention because this failure has no symptom until it is expensive.

The symptom. You built an augmentation set. Every spec asked for sixty-one frames. Every run exited zero. Every output passed the video check. Then you loaded the set into a training pipeline and it rejected half of it for having the wrong sequence length. You looked, and your clips were not sixty-one frames. Some were a hundred and twenty-one. One was seventeen. Nothing in your generation pipeline reported a problem, because from its point of view there was not one.

The hypothesis. The output frame count equals the control's frame count, not the spec's.

The one diagnostic that settles it is three numbers side by side. What you asked for, what the control contains, and what came out. Two of the three will agree, and which two is the whole answer. Notice what this diagnostic does not need. No GPU, no model, no download. It is a probe on files you already have. That tells you where it belongs: at the front of your pipeline as a precondition, not at the back as a post-mortem.

The lab reproduces this on purpose with a seventeen-frame control against a spec asking for sixty-one, so it costs minutes rather than an afternoon. The repair is not to fix the number. The repair is to stop specifying the frame count at all and derive it from the control. A number you derived cannot disagree with the thing you derived it from. Then wrap that in an assertion that runs before the launch. On a forty-minute transfer, the difference between checking before and checking after is the difference between a nuisance and a lost morning.

Three things to carry away. Transfer is video-to-video plus a control hint block, and the enum in your own installation is the authority. Each hint is a lossy summary, and what it discards is what you are free to change. The control video decides the geometry, so derive the frame count from it and never type it. And keep the honest caveat close: a hundred variants of one clip is not a hundred clips. It is one clip with a hundred appearances, sharing one camera trajectory and one scene layout. Say so in any report you write.

Lesson 09 adds sound, and then introduces the component that has been quietly running inside every generation you have done so far. It is the only gated repository in the entire stack, it is on by default, and when it rejects your work it does so with a return code of zero.
