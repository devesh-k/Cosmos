---
lesson: "13"
title: "Closed-loop control"
slug: "13_action_closed_loop"
duration_estimate: "13 min"
words: 1945
---

# Lesson 13 — Closed-loop control

The last lesson ended on an unsatisfying note. One observation goes in, sixteen actions come out, you execute all sixteen, and you hope. This lesson explains the fix, shows you the real architecture that implements it, and is honest about which parts of that architecture fit on one machine.

By the end you will be able to derive, rather than recite, why feedback bounds an error that open loop lets grow. You will know the two-process shape of a closed-loop evaluation and the dependency pin that forces it. You will be able to talk to a policy server by hand over HTTP and write the check that catches a failure the status code hides. And you will know four documented ways a policy that evaluated fine falls apart in simulation. Some of this you read rather than run, and the notebook says why each time.

## Why feedback bounds the error

Open loop is what you did last lesson. Observe once, predict a chunk, execute the whole chunk, stop. Closed loop is one change. Observe, predict, execute one step or a few steps, then observe again. Every few steps the controller throws away whatever remained of its plan, looks at the world as it actually is, and asks again.

Here is the argument, and it is worth following rather than accepting. Suppose each predicted action carries a small systematic bias. The model consistently under-reaches by a fixed amount. Under open loop those biases accumulate across the whole horizon, so error grows in proportion to the number of steps. Under closed loop, each re-observation resets the accumulation, because the new observation reflects where the system actually is rather than where the plan assumed it would be. Error accumulates only within one chunk, and that stays true however long you run.

Notice what the argument is not. It is not that closed loop is more accurate. It is that open-loop error grows without bound in the horizon while closed-loop error is bounded by the chunk length. A model with zero bias needs no feedback. Every real model has some.

Random error behaves differently and is worth separating out. Zero-mean noise accumulates like a random walk, growing like the square root of the number of steps rather than in proportion to it. Slower, still unbounded. The notebook has you simulate both and find the horizon where bias overtakes noise, because below that crossover an open-loop policy looks perfectly fine.

Now the two things feedback fixes that a constant bias does not explain. The first is unmodelled disturbance. Somebody moves the pot. An open-loop plan carries on executing a sequence computed for a world that no longer exists, and no amount of model quality helps, because the model was never wrong. The second is the compounding of the policy's own small errors. If action three lands the gripper two centimetres off, every later action is applied from the wrong starting point. Closed loop notices at the next observation. Open loop cannot notice, because noticing requires looking.

## Two processes, and the pin that forces them

Closed-loop evaluation is two processes, and the split is not an aesthetic choice.

On one side there is a policy server. It holds the Cosmos 3 weights on the GPU and answers one question. Given this observation and this instruction, what should I do. On the other side there is a simulator client. It owns the world. It steps the simulator, renders observations, sends them over, receives an action chunk, applies it, and repeats. The loop lives in the client, not the server.

Upstream ships two servers. One serves the LIBERO benchmark, which runs on robosuite and the mujoco physics engine, and it speaks ordinary JSON over HTTP. The other serves the DROID setup on Isaac Sim, and it is a WebSocket server carrying msgpack, with a plain HTTP health endpoint alongside. That difference decides what you can do by hand. A hand-made JSON request works against the LIBERO server only. Against the other one, the health endpoint proves the process is alive and holding weights, and no more than that.

Now the reason you cannot simply run this. The eval client needs robosuite one point four point one, mujoco two point three point seven, and a torch older than two point six. The framework needs a recent torch built against a recent CUDA, with a matching flash attention build. Those two sets have no common solution.

Be precise about why, because dependency conflict is usually said as though it were an inconvenience. A Python environment holds exactly one version of any package, and torch is a compiled extension linked against a specific runtime, so one version is not a formality. Robosuite pins an old torch because its compiled dependencies were built against one. The framework pins a new torch because flash attention three for Hopper exists only for a new one. No resolver can satisfy both, because no such version exists.

So the choice is not which pins to relax. It is architectural. Either two virtual environments, two processes and a socket between them, or one environment and a rewrite of one side. Upstream chose the first, which means the HTTP boundary is a direct consequence of a dependency conflict. An unresolvable pin is sometimes telling you where a process boundary belongs. One caution. Do not test this by forcing the client pins into the framework environment. You end up with a framework that imports cleanly and dies at the first attention call.

There is a second hard constraint. The base checkpoint has no action heads. Those heads only exist after post-training for a specific embodiment. You can run the world action mode through ordinary inference on the base model, because that path uses the generator towers, but you cannot serve the base model from a policy server. Two post-trained DROID checkpoints ship publicly and neither is gated, so that path is open to you. There is no public LIBERO post-trained checkpoint, which means the server with the schema you can hand-write requests against needs a checkpoint you produced yourself. That is not an accident of packaging. It is the practical argument for the post-training module.

## Talking to the server by hand

The hands-on core of this lesson is the HTTP contract, worked against a faithful mock so you get the client right before spending thirty gigabytes finding out you got a field name wrong.

The documented contract is small. You post to the predict endpoint with a JSON body carrying a base sixty-four encoded image, a prompt, a domain name and an image size. You get back an action array and a video. There is one endpoint for model and runtime information and one that reports status.

Reading the handler rather than the docstring adds four things, and each will bite somebody. A post is accepted on the root, on the predict path and on a batch path, and any other path is a four oh four. A content type that is not JSON gets a four one five, not a four hundred. The batch endpoint returns a field called actions, plural, a different key from the singular one. And the one that matters most, an inference error returns HTTP 200 with an empty action list. The server can be told to raise a four hundred instead, and that defaults to off because a legacy client expected two hundred.

Sit with that. A two hundred is not proof of success. A client that checks the status code and moves on will send an empty action chunk to a robot. So write the check the status code cannot do for you. Confirm the status, confirm the body is an object, confirm there is no error field, confirm the action key exists and is not empty, and confirm the width is what the domain expects.

Then there are the four eval-parity gotchas, and the reason to teach them together is that they are all the same bug. Camera concatenation layout must be the third-person view and then the wrist view, each at two hundred and fifty-six pixels, because the model learned to read the left half as one camera and the right half as the other. The gripper sign is flipped between the simulator and training, so the client applies one minus two times g. Simulator frames are rotated a hundred and eighty degrees relative to training frames. And quantile rotation action normalisation is mandatory on the server, or the actions come out at the wrong scale.

Every one of those is train-serve skew. Whatever transformation was applied to build the training data must be applied identically at serving time, and its inverse applied to the output. None of the four raises an exception. All four produce a policy that runs, returns well-formed numbers, and performs badly.

## The lab: fine offline, useless in simulation

A colleague post-trained a policy. Their offline numbers look right. Predicted actions match held-out data closely and the round-trip check from the inverse dynamics lesson is clean. They stand up the server, point the simulator client at it, and the success rate is close to zero. The robot moves smoothly and purposefully to the wrong places. Nothing errors. Every request returns two hundred.

The hypothesis follows from what differs. Offline, observations come from the same pipeline that produced the training data. In simulation, they come from the simulator through the client. So the model is probably fine and something between the simulator and the model's input is not. That is train-serve skew, and there are four documented candidates.

The discipline in the diagnostic is to work them in order of how cheaply they can be ruled out, not in the order they are listed. The cheapest by far is normalisation, because the server will tell you. One request to the information endpoint reports which normalisation it started with. If that does not say quantile rotation, you have your bug, and the symptom matches. Motions of the right shape at the wrong scale. The task traced in miniature.

Gripper sign is next, settled by arithmetic with no simulator involved. Map the model's range through one minus two times g and check it against the polarity you recorded last lesson. Model zero becomes plus one, which the environment reads as closed. Model one becomes minus one, which it reads as open. The last two candidates need you to look at the observation the client actually sends.

The repair is one line each. The right normalisation on the server, the gripper transform in the client, a rotation in the client, and the right camera arguments so the concatenation matches training. Upstream's shipped client and server already do all four. You check anyway, because already handled is a claim about a version, and you are running some version.

Verification is the honest part. Real verification is a success rate in simulation, which needs the second machine. What you can check without one is that the server reports the expected normalisation, that the gripper mapping agrees with the polarity you measured, that the observation geometry matches the contract, and that the whole loop has run end to end at least once against the mock. That last one is why the mock exists. A failure in simulation is then a policy problem, not a plumbing problem.

Three things to carry out of this lesson. Feedback bounds error because each fresh observation resets the accumulation. An unresolvable dependency pin can be telling you where a process boundary belongs. And a two hundred is not a success signal, so verify the payload.

The next lesson stops driving the model and starts measuring it, properly.
