---
lesson: "06"
title: "Generation fundamentals"
slug: "06_generation_fundamentals"
duration_estimate: "13 min"
words: 1924
---

# Lesson 06 — Generation fundamentals

Module one turned footage into words and coordinates. Module two turns words back into footage, and this is the lesson where you learn how that actually works rather than which arguments to type.

You do it in two halves. In the first half you build a diffusion model from scratch, in one dimension, with no Cosmos involved. It trains on your CPU in under a minute, and it is the whole mechanism stripped of the photography. In the second half you run Cosmos 3, measure what it costs on your machine, and then run out of memory on purpose.

By the end you will be able to say what the number of steps, the guidance setting, the shift setting and the seed each do, and which are free. You will compute a job's latent token count by hand. And you will produce a calibration file holding one measured number that turns the course's cost estimator into a real time prediction for your H100. This lesson uses the Edge tier: four billion parameters, dense, about nine gigabytes on disk, capped at 480p. Nothing else may hold the card, so stop the Reasoner NIM first.

One setup note that saves an afternoon. All nine Cosmos 3 repositories are ungated. The only thing needing a licence click is the Cosmos Guardrail repository, which the generator turns on by default, so you will hit it on your first run. One click, not five.

## The first idea: destroy the data, then learn to undo it

Forget images. You have a pile of numbers drawn from some distribution you care about, and you want a machine that produces fresh numbers from that same distribution.

Step one is to destroy the data on purpose. Take a data point and mix it with random noise, a little at first and then more and more, until every trace of the original is gone and what you hold is indistinguishable from pure Gaussian noise. That is the forward process. Nothing is learned and it has no parameters. It is a fixed recipe for ruining data. The endpoint is the useful bit, because pure Gaussian noise is something you can generate for free, anywhere, at any time.

Step two is to learn to undo one step of it. Train a network that, given a noisy value and the noise level, predicts which noise was added. That is plain supervised regression, because you made the noise yourself, so you already have the label.

Step three is sampling. Start from pure noise. Ask the network what noise it thinks is in there. Remove some of it. Ask again at a slightly lower noise level. Repeat. After enough iterations you hold something that looks as though it came from the data distribution, and it did not. You built it out of noise, by a long sequence of small nudges toward something the model finds plausible. That loop, run on a compressed video latent instead of one number, is Cosmos 3.

The toy uses two tight bumps, one at minus two and one at plus two, so success is obvious. Its inputs are the noisy value, the noise level, and a class label, with a third label value meaning no label was given.

That third value is the trick that makes guidance possible. During training, the label is randomly replaced by the no-label token fifteen percent of the time, so one set of weights learns two jobs at once: denoising when it knows the class, and denoising when it does not. That is the free in classifier-free guidance. You get an unconditional model for nothing, without training a separate classifier, because you dropped the label sometimes.

## Three knobs, and what each one costs

Read the sampling loop once and every knob in Cosmos 3 has a home. The seed decides the starting noise, and therefore the whole sample. It costs nothing. The number of steps decides how many nudges you take, and since each step needs the output of the one before it, they cannot be parallelised and wall clock is close to linear in step count. Guidance is a weight in a blend. On each step the model makes two predictions, one with the prompt and one with the prompt withheld, and guidance decides how far past the unconditional prediction you travel in the direction that distinguishes them.

Notice what that costs. Two predictions means two forward passes per step. Free refers to not needing a separate classifier at training time. Guidance is not free at inference, and every diffusion sampler you run does roughly twice the compute per step that the arithmetic suggests.

Now turn each knob. The steps sweep produces the finding most people get wrong. Few steps do not scatter your samples. They collapse them onto the mode. At two steps the mean is nearly correct and the spread is a fraction of the truth, because a deterministic sampler taking enormous strides is strongly mode-seeking. In images, that is why very-low-step output looks smooth, generic and interchangeable rather than obviously broken. It is a diversity failure before it is an accuracy failure, and a metric that only asks whether a sample looks plausible will not see it. Plot quality against steps and the curve falls steeply and then flattens. Past that knee you pay linearly for nothing.

Guidance next. At a weight of zero you ignore the class and sample the whole data distribution, so roughly half your samples land on the wrong mode. That is the clearest evidence that an unconditional model lives inside the same weights. At a weight of one you get the plain conditional prediction. Above one you extrapolate, and nothing guarantees the extrapolated point is still on the data distribution. In the toy the mean overshoots and the spread collapses. In images that same failure looks like over-saturated colour, crushed contrast and a burnt, plasticky finish. One mechanism, two symptoms.

Shift moves where the steps land along the noise schedule. Spacing a fixed budget of steps evenly is almost certainly wrong. Early in sampling, at high noise, the model decides coarse structure: kitchen or road, horizon high or low. Late in sampling it decides texture. Coarse decisions are worth more steps, so shift bunches the timesteps toward the noisy end, and the cookbook's prompts use a shift of ten. Then the toy does something better than confirm that heuristic. A strong shift at a small budget makes the toy worse, which is correct, because the argument was about coarse spatial structure and a one-dimensional distribution has none. A small model tells you what a knob does mechanically. Only measurement on the real model tells you what value to use.

## Cosmos 3 does not denoise pixels

A hundred-and-twenty-one-frame clip at eight hundred and thirty-two by four hundred and eighty is about a hundred and forty-five million numbers. Running thirty-five sequential denoising steps over that, each a full transformer pass with attention across all of it, is not something an H100 will do this afternoon.

So it does not. Cosmos 3 is a latent diffusion model, and three compressions sit between your pixels and what the transformer sees. The video autoencoder compresses eight times spatially and four times temporally. Then patchification folds each two by two block of latent cells into one token. Net effect: divide each spatial dimension by sixteen, and divide time by four. The transformer denoises around forty-eight thousand tokens instead of a hundred and forty-five million numbers, and a decoder turns the finished latent back into frames once, at the very end.

Two consequences follow. Cost scales with pixel area, not with width, so going from 480p to 720p is one and a half times in each dimension and about two and a quarter times the tokens. That is why dropping a resolution tier is the biggest lever you have. And frames are comparatively cheap, because four extra frames cost one extra latent slice.

Two more things before the machine runs. Cosmos 3 does not want a loose sentence. It wants a structured, attribute-by-attribute scene description, serialised as JSON and passed in as a single string. A robot in a kitchen underdetermines the camera, the lighting, the surfaces and the motion. The structured form makes each of those a field you can hold fixed while varying exactly one other, which is what making training data requires. And a negative prompt is the conditioning fed to the unconditional branch, so it is a direction rather than a filter, with force only in proportion to guidance. At a guidance of one it does nothing. None ships for text to image, because the shipped ones are about flicker and warping between frames, and a single frame has neither.

Then you measure, and the notebook is fussy about how. Generation runs as a separate process, so this notebook's allocator cannot see a byte of it. You sample the driver instead, on a background thread, noting that the number is device-wide and that the real peak is at least what you measured. Then you run one job at two step counts and solve for two unknowns: a fixed cost per run, and a marginal cost per step. Divide cost units by compute time rather than total time and you have your calibration.

## The debugging lab: running out of memory

You asked for something ambitious. High resolution, a long clip, fifty steps. Forty seconds in, the process died with a wall of red text.

The important part is almost never at the bottom. Read the numbers in order. It tried to allocate about nine and a half gigabytes in one go, which points at a single activation tensor sized by your geometry, not at a slow leak. Around six and a half gigabytes were free of about seventy-nine, so the card is genuinely nearly full. But roughly nine gigabytes were reserved and unallocated, meaning the caching allocator is holding memory that serves no tensor, so there is a fragmentation component too. And the frame stack ends inside attention, whose cost is quadratic in sequence length, and sequence length here is the latent token count. That is geometry, not weights.

The diagnostic is to feed the traceback to the course's pattern matcher and print the escalation ladder next to your measured peak. Pay attention to the rungs marked unavailable. NVIDIA's ladder has six rungs, and two of them work by splitting state across additional ranks: raising the sharding degree and raising the context-parallel degree. With one device there is nothing to split onto.

The repair is to walk down the available rungs cheapest first, using the estimator so you know what each buys. Drop a resolution tier first, because tokens go as area. Then cut frames. Cut steps last, and understand why: cutting steps cuts wall clock but barely touches peak memory.

And the repair is not finished when the process exits zero. A run can complete tidily, return zero, write a well-formed video file and hand you a blank frame, because the guardrail rejected the prompt or the latent went to not-a-number. Verify by content.

Three things to carry forward. Diffusion is a fixed process that destroys data, a learned network that predicts the noise, and a sampling loop that runs it backwards. Cosmos denoises latents, so cost is tokens times steps and tokens go as area. And your calibration is one constant for one machine, which is why this course never quotes someone else's.

Lesson seven stops asking the model to invent a scene and starts giving it one.
