---
lesson: "01"
title: "What Cosmos 3 is, and your first generated image"
slug: "01_cosmos3_mental_model"
duration_estimate: "13 min"
words: 1927
---

# Lesson 01 — What Cosmos 3 is, and your first generated image

By the end of this lesson you will be able to explain what Cosmos 3 actually is, in mechanical terms rather than marketing ones, and you will have generated, timed and verified one real image on your own H100. Along the way you pick up three corrections to the documentation that save you an afternoon each.

Start from zero, because the phrase world foundation model is doing a lot of work. A language model predicts what text comes next. A world model predicts what the world does next. Given some frames of video, some sense of what is happening, and possibly an action, it produces the frames that plausibly follow. A world foundation model is trained broadly enough that you can point it at a new scene without training it again.

Physical AI is the term for systems that act in the physical world. Robot arms, humanoids, autonomous vehicles. Those systems need three capabilities. Perceive, which asks what is in front of me. Reason, which asks what should happen next. And act, which asks what I do about it. Until recently you built those from three separate models, and the expensive part was that they held three different internal representations of the same scene, glued together at their boundaries. Cosmos 3 is one checkpoint that does all three.

The obvious use of a world model is generating video. The less obvious use, and the reason this course exists, is data. Robot learning is starved of training data. Collecting a thousand demonstrations of a robot pouring water takes a thousand pourings, with a real robot. A world model that has seen enough pouring can produce on distribution variants of one real clip, and the downstream policy trains on those.

## Two towers, one active at a time

A transformer is a stack of layers. Each layer mixes information between positions, which is attention, then transforms each position on its own. Text tokens, image patches and audio frames can all be turned into positions, which is why one architecture serves several modalities.

A Mixture of Transformers keeps that stack but gives it more than one set of weights, and routes each token to the set that matches its job. Cosmos 3 has two such sets. Call them towers. There is a reasoner tower, which is vision language. Pixels and text go in, text comes out. And there is a generator tower, a diffusion transformer. Noise and a condition go in, pixels come out. They share the tokenizer, the encoder and the embeddings.

Here is the sentence that explains everything downstream. Only one tower is active in any single forward pass. Ask a question, the reasoner runs. Ask for a video, the generator runs. The other tower's parameters sit in memory doing nothing.

That also explains the number that confuses everyone. Hugging Face reports Nano at just under sixteen billion parameters, and Super at just under sixty-five billion. NVIDIA's documentation and the serving container call the same two models Nano eight billion and Super thirty-two billion. Both are right. Sixteen billion is what is on disk, both towers. Eight billion is what flows through one forward pass.

So here is the rule, and it is easy to get backwards under pressure. For inference, budget against the active count. For training, budget against the total. Inference runs one tower, so the compute bill follows the active number. Training gives every parameter an optimizer state, a thirty-two bit master copy, two Adam moments and a gradient, whether or not it was active in the step. That gap is why the model you can run on one H100 is nowhere near the model you can train on one H100.

Three tiers ship. Edge is four billion parameters, dense rather than mixture of transformers, roughly nine gigabytes on disk, up to the four eighty tier, no audio and no transfer. Nano is sixteen billion total and eight billion active, about thirty-five gigabytes, up to seven sixty-eight, with audio and transfer. Super is sixty-four billion total and thirty-two billion active, about a hundred and thirty gigabytes. Today you use Edge.

## The names that upstream gets wrong

Three corrections, and each one is a real trap rather than a typo.

The first is gating. The source course this material is adapted from spends an entire notebook accepting gated licences for the Cosmos 3 checkpoints. That is obsolete. All nine Cosmos 3 repositories are ungated. The only repository in this whole stack that still needs a licence click is the Cosmos Guardrail repository, which the generator turns on by default. One click, not five. The notebook has you verify that yourself over plain HTTPS rather than believing the prose.

The second is a rename, and it will fail your run if you miss it. What used to be the mode named policy is now called wam. That is spelled w, a, m, and it stands for World Action Model. The old name is not in the enum, and a run using it fails with a validation error that never mentions the rename. Three independent confirmations sit in your own checkout. The frozen set of action model modes contains the new name. The defaults directory has a folder for the new name and none for the old one. And the shipped example inputs contain the new value inside them, even though the filenames still say policy. Meanwhile the inference documentation, the questions page and the action cookbook all still print the old name. Trust the enum, not the prose.

The third correction. Transfer is not a model mode at all, although the cookbook writes it as though it were. Video to video transfer runs as the video to video mode plus a control hint block in the spec, and the framework detects transfer from the presence of that block. There are exactly four hints. Edge preserves shape and layout. Blur preserves colour and lighting. Depth preserves three dimensional structure. And segmentation preserves object identity.

One smaller correction. The licence is OpenMDW one point one, not the NVIDIA Open Model License the source course cites.

## How a picture comes out of noise

Start from pure random noise. Ask the model, given this noisy thing and given the prompt, what would a slightly less noisy version look like. Apply the answer. Repeat. After enough repetitions the noise has become an image the model considers plausible for that prompt. That is the whole loop. Nothing is retrieved and nothing is pasted.

Two knobs matter today. The number of steps is how many nudges you take. Cost is close to linear in steps, because they are sequential and each one is a full forward pass through the generator tower. It is the cheapest knob to turn and the first to cut when you are impatient. Guidance is how hard each nudge is pushed toward the prompt rather than toward any plausible image. Low guidance drifts off prompt. High guidance obeys the prompt and starts producing over saturated artefacts. Two more you will meet. The seed fixes the starting noise, which is what makes a run reproducible. And shift re-spaces the steps so more of them land where the image structure is decided.

Between the generator and every file it writes sits the guardrail, a set of models that screen the prompt going in and the frames coming out. It is on by default, and it is the one licence click. Accept it, and make sure your Hugging Face token is exported in the shell that started Jupyter. Without it your first generation fails with an authorisation error that names Hugging Face and not the guardrail, which reads like an account problem.

The second consequence matters more. The guardrail can silently blank your output. A rejected prompt or frame does not raise. The run completes, the exit code is zero, and the file it wrote is blank, blurred or a flat colour. That is the best reason in this course to check output content rather than exit codes. There is a no-guardrails flag. Understand what you are switching off first.

Then you generate. The first run downloads Edge, then lazily pulls about eight gigabytes of auxiliaries on first inference, which is why a run can appear to hang after the checkpoint finishes. The generator runs as a separate process, so your kernel cannot see its memory. The notebook samples the driver on a background thread.

Verify before you look. A non-zero exit is conclusive evidence of failure. A zero exit is not evidence of success. For an image the substantive check is spatial autocorrelation. In a real picture a pixel predicts its neighbour with correlation above about zero point nine five, while in noise that number sits near zero. Unlike standard deviation it does not care about contrast, and the nastiest failures produce mid grey noise that looks healthy by every other statistic.

## Two failures, one loud and one silent

The loud one first. You write the aspect ratio as sixteen colon nine, as you would anywhere else in computing. The framework wants a comma, not a colon, and there is a fixed set of accepted values. Depending on where you put it, the run either rejects it or quietly gives you the default geometry.

The diagnostic is the interesting part. Do not launch anything. The spec validator checks locally, in milliseconds, against the list of accepted values, which turns a twenty minute round trip through model loading into an instant error. Fix the separator, re-run the validator, and confirm the problem list is empty. Skipping that confirmation is how you fix the same field twice. Note too that the resolution tier is a name, not a pixel height.

Now the silent one, which is worse, because nothing complains. A prompt arrives empty, lost to a JSON escaping mistake, or read from a field that was never set. The spec validates, because an empty string is a present field. The run exits zero. A file appears. The pipeline reports success and you move on.

The hypothesis is not about a bug. It is that meaningful is not a property a schema can check. The only thing that catches it is looking at what came out, and even then three outcomes are possible. The image check might fail on flatness, meaning the guardrail blanked the frame or the model had nothing to condition on. It might pass while the picture is generic, which is the honest case, because an unconditional sample is a healthy image of nothing in particular. Or nothing was produced at all.

The repair is upstream of the model. Assert your prompt is non-empty, with a minimum word count, before you spend a GPU minute on it. And generalise the lesson rather than the fix, because every stage of this course can exit zero and be wrong.

Three things to carry away. One checkpoint, two towers, one active per forward pass, which is why the parameter count has two correct answers. The mode is wam, spelled w, a, m, transfer is not a mode, and only the guardrail is gated. And never conclude a run worked from its exit code.

When you are back at the machine, the notebook has you extract the mode list from your own checkout, generate at full steps and again at half, and compare the two images numerically rather than by eye. Next, lesson two, where you pull the Reasoner container and confront the constraint you costed in lesson zero.
