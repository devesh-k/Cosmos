---
lesson: "07"
title: "Image-conditioned generation"
slug: "07_generation_conditioned"
duration_estimate: "13 min"
words: 1919
---

# Lesson 07 — Image-conditioned generation

Lesson six asked the model to invent a scene. This lesson gives it one and asks what happens next.

That difference is most of what makes generation useful for data work. You rarely want a video. You want a video of this particular thing, varied in a way you chose. A text prompt gives the model enormous freedom about what to draw. A conditioning image takes almost all of that freedom away and leaves exactly one degree of it: the future.

By the end of this lesson you will be able to explain precisely what happens to your image between the file on disk and the first denoising step. You will measure what a run kept from its conditioning frame and what it invented, with a number rather than an impression. You will demonstrate two failure modes on purpose. And you will hit the aspect ratio trap, which is small, silly and expensive, and learn to diagnose it from geometry. Every run prints a predicted time before it starts, using the calibration you measured in lesson six, so this lesson is also a running test of that number. Budget about ninety minutes and eight short runs. Nothing new is downloaded, and the card must be yours alone, so the Reasoner NIM stays stopped.

## The first idea: the first frame is pinned

Here is the mechanism, and it is worth being precise, because the vague version, that the model looks at the image, predicts the wrong failures.

A video latent has four dimensions: channels, compressed time, compressed height, compressed width. Your conditioning image is a single frame, so it goes through the same autoencoder that produced that latent space in the first place, and it comes out as one temporal slice. That slice is written into the latent at time index zero and held fixed.

Now watch the loop. Every denoising step updates the whole latent, including slice zero. And then slice zero is put back. Re-imposed, every step, so it cannot drift. The rest of the tensor is being denoised in the presence of a slice that never moves, and because the transformer attends across time, that fixed slice constrains everything else in the clip.

Two consequences follow directly. The first is why image-conditioned generation is usually far more controllable than text-conditioned generation. A structured prompt is a description, and the model has enormous latitude in how to realise it. A conditioning frame is not a description. It is an answer. Composition, palette, lens, the objects and where they sit are all already decided. The model is no longer choosing the scene, only its future.

The second is where it fails, and there are two distinct ways. The model must invent plausible motion, and if the frame does not imply any, it has to guess. A parked car on an empty road might drive off, or the camera might pan, or nothing might happen, and all three are consistent with that frame. Ambiguous scenes drift, and drift here is not random noise. It is the model committing to some interpretation and then following it faithfully. The other failure is contradiction. If your prompt disagrees with your image, something has to give, and which one gives is a question you settle by measurement.

One mechanical detail before the runs. The path to your conditioning image gets resolved to an absolute path before the specification file is written, because the framework resolves conditioning paths relative to that file. Relative path confusion here produces a confusing failure a long way from its cause.

## Measuring what survived

The first frame is preserved is a claim, and claims get measured.

The method is deliberately simple. Take the conditioning image and the generated video. Convert both to grayscale at a common size. Then correlate the conditioning image against frames sampled at several points through the clip, and look at the curve.

You should see a very high correlation at frame zero, because that slice was pinned. And you should see the correlation fall as the clip progresses. The rate at which it falls is the model's invention, quantified. A clip whose correlation stays at one throughout has not animated anything. A clip whose correlation collapses immediately has thrown your conditioning away. Neither extreme is what you want.

Say what this does not measure, every time you report it. Correlation of grayscale intensity is very sensitive to a camera pan and almost blind to an object changing colour. It is a crude instrument. It was chosen because it is transparent, meaning you can predict in advance what it will do, which is a real virtue in a measurement you are going to trust.

Then two experiments, and predict before each one. The first conditions on a still of a humanoid robot standing in a room, with a prompt that says the robot stays still and the camera does not move. Commit to an answer. Does the output contain motion? And will the aliveness check pass or fail, given that it fails any clip whose average change from frame to frame is below a small threshold? The interesting part is the explanation, and it is about the training distribution. This model was trained on video, and video mostly moves. Asking for a clip in which nothing happens is asking for a sample from a nearly empty region of that distribution. Whether it obeys, and what it does instead if it cannot, is the whole question.

The second experiment contradicts the image outright. The conditioning frame is a car on a road. The prompt describes a kitchen, with a robot chopping vegetables at a worktop. Which one wins? Decide before you run, and decide what number would settle it, because you already have the correlation profile. If frame zero is still near one and the later frames fall much faster than in the honest run, then the conditioning held and the prompt pulled the future away from it. That is the answer, and the pinned slice explains it. No prompt can change slice zero. Everything the prompt can affect is downstream of a frame it disagrees with, and the transformer has to reconcile the two through temporal attention.

## A comma, not a colon

The framework wants the aspect ratio written with a comma. Sixteen comma nine. Not a colon, not a slash, not a decimal. Five values are accepted: sixteen by nine, nine by sixteen, one to one, four by three, and three by four.

This looks like pedantry and it is not, because of what resolution means here. Resolution is a tier name, which is to say a pixel budget. The aspect ratio decides how that budget is spent between width and height. The 480 tier at sixteen by nine gives you eight hundred and thirty-two pixels wide by four hundred and eighty tall. The same tier at one to one gives you roughly six hundred and forty pixels square. Same budget, very different picture. So the aspect ratio changes the shape of the latent, which changes the token count, which changes both the cost of the run and whether it fits at all.

The course's validator checks the format explicitly, and when it sees a colon it tells you to use a comma. That check exists because the framework's own error for this case is not clear. But notice what the validator cannot do. A ratio that is legal and wrong sails straight through, and that is the lab at the end of this lesson.

This lesson is also where the course closes its through-line. Back in lesson three the reasoner watched clips and wrote structured scene records with five fields: subjects, setting, actions, lighting and camera. Those five were chosen because they are exactly what module two knows how to condition on, which is only useful if somebody connects the two ends. So you read a record the reasoner wrote, turn it into a generation prompt, and animate a frame with it. If you took module two first, a canned record stands in, marked as canned so nobody mistakes it for their own output.

## The debugging lab: the run that succeeded and was wrong

Here is the symptom. You conditioned on a wide photograph, you asked for a square output because you wanted it for a square display, and the run finished. Exit code zero. A file was written. The aliveness check passed, because the frames decode, they have spatial structure, and they move.

And the video is wrong. The car is squashed, or there are black bars, or the composition you chose has been cropped away. Nothing in the exit code, nothing in the log, and nothing in the aliveness check will tell you, because from every one of those points of view the run succeeded.

This is the general shape of the most expensive class of bug in generative pipelines. The machine did exactly what you asked, and what you asked was wrong. The only instrument that catches that is one which compares the output against your intent, and your intent is not in the specification file.

The hypothesis is straightforward. The output geometry follows the specification, not the conditioning image, and the conditioning image has been squeezed or cropped to fit.

The one diagnostic that settles it is geometry. Read the width and height of the output video. Compute its aspect. Compare that against the conditioning image's aspect. If the two differ by more than the rounding to multiples of sixteen can explain, the image was reshaped, and you now know it rather than suspecting it.

Two details in how that check is built are worth carrying into your own work. First, read the geometry from a proper media probe, not from the aliveness checker's metrics. That checker returns early on a tiny file or one it cannot decode, before it ever records a width, so reaching into it for metadata fails on exactly the degenerate files you most want geometry for. Second, have the check return the verdict and the numbers behind it. A checker that only says failed trains people to ignore it.

The repair is to derive the aspect ratio from the image rather than typing it. A small helper picks the accepted string closest to the image's actual shape, and then you verify the output honoured it. And if you genuinely do want a square video from a wide source, that is a legitimate choice. But it is a crop, so do the crop yourself, on the conditioning image, before it reaches the model. Then the model is conditioned on exactly the frame you intended and the geometry agrees all the way through.

Three things to take away. The conditioning image is encoded by the same autoencoder and pinned as the first temporal slice, re-imposed after every step, so nothing overrides it and everything else is denoised in its presence. Preservation is something you measure with a correlation profile, not something you assert. And an aspect mismatch is a clean-exit failure, which means only geometry catches it, so derive the aspect from the image and never type it.

Lesson eight stops conditioning on one frame and starts conditioning on a whole video, through a control hint. Read its opening warning first. Transfer is not a model mode, whatever the documentation says. It runs as video to video plus a control hint block, with exactly four hints: edge, blur, depth and segmentation. And it needs the Nano checkpoint, which is about thirty-five gigabytes to download.
