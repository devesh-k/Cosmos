---
lesson: "10"
title: "Action as a modality, and forward dynamics"
slug: "10_action_forward_dynamics"
duration_estimate: "13 min"
words: 1939
---

# Lesson 10 — Action as a modality, and forward dynamics

The first module taught Cosmos 3 to describe a scene. The second taught it to imagine one. This module teaches it to act in one, and behind that is a single idea which takes about ninety seconds to state and the rest of the module to use properly.

Start from what an ordinary video model does. It learns the distribution of what frame comes next. Nothing in that setup knows why the next frame differs from this one. A car turns left in the training data, the model learns that turning-left-shaped pixel sequences happen, and there is no handle you can pull to make it turn left on demand. Cosmos 3 adds that handle.

By the end of this lesson you will be able to say what an action token represents and why one checkpoint answers three different questions, explain why the rotation part of an action is six numbers, write a forward dynamics spec and justify every field, measure what doubling the action chunk size costs, and diagnose the failure that gives you a plausible video built on a wrong reading of your data.

## Action as a modality

Alongside the token streams for text, image and video there is a token stream for action. One action token stands for the transition between two consecutive visual states. Not the car's steering angle, and not the robot's joint torques. The change from one frame to the next, in whatever units that embodiment uses.

Pause there, because that is what lets one model answer three separate questions. If actions and frames live in the same sequence, predicting some of the sequence given the rest is one operation with three useful special cases.

Give it a start frame and a set of actions, and it predicts future video. That is forward dynamics: if I do this, what will I see. Give it a video and it predicts the actions. That is inverse dynamics: what did I do to produce this. Give it a start observation and an instruction and it predicts video and actions together. That is the world action model: what should I do to achieve this. Three questions, one checkpoint, one entry point, three values of the model mode field. That economy is the argument for treating action as a modality rather than bolting a policy network onto a video model.

This lesson does the first. Lesson 11 does the second, lesson 12 the third. One naming correction to plant now. The third mode used to be called policy and is not any more. The value is wam, spelled w, a, m, short for world action model. The old name is gone from the enum and several upstream documents still print it. Lesson 12 makes you prove which is live.

Now make it concrete. For the autonomous-vehicle domain, one action step is nine floating-point numbers. The first three are a translation delta: how far the camera moved between this frame and the next, along each axis, in the camera's own coordinate frame. The remaining six are a rotation delta. There is no absolute position anywhere in that vector. Every step is relative to the one before, so a trajectory is a chain of small relative moves and you get an absolute path only by composing them. That is lesson eleven's job.

## Why the rotation is six numbers

This is the part almost nobody has met before, and it is a genuinely good idea, so it deserves the time.

A 3D rotation has three degrees of freedom, so the obvious encodings are three Euler angles, a four-number quaternion with a unit-length constraint, or the full three by three matrix.

Euler angles are the obvious choice and they are a trap. They have gimbal lock: at certain orientations two axes line up and a degree of freedom vanishes. They are also discontinuous, because yaw wraps from three hundred and fifty-nine degrees to zero, so two nearly identical rotations can be numerically far apart. Quaternions fix gimbal lock and keep a discontinuity of their own, because a quaternion and its negation are the same rotation, so a network regressing one has to pick between two equally correct answers.

Why does that matter. Because a neural network is a continuous function. Ask it for a representation in which nearby rotations are sometimes numerically far apart, and you are asking it to approximate a discontinuous map with a continuous one. It cannot, so it produces garbage near the discontinuity. That is topology, not hyperparameters. A 2019 result by Zhou and colleagues settles it: for 3D rotations there is no continuous, singularity-free representation in three or four dimensions. Five is also impossible. Six is the smallest that works.

So what are the six numbers. Take the three by three rotation matrix and keep its first two columns. You lose nothing, because the columns are mutually perpendicular unit vectors, so the third is the cross product of the first two. To decode, take that cross product to rebuild the third column, assemble the matrix, then snap it back onto the rotation group, because nothing constrains a network's raw output to be orthonormal. The textbook recipe for that is Gram-Schmidt. Cosmos 3 does something slightly different, and lesson eleven has you look at what. Six numbers for three degrees of freedom is over-parameterised, and that is the price of continuity.

And here is the trap that follows. The domain name field selects an embodiment, and each embodiment has a fixed raw action width. Nine for the autonomous-vehicle domain and for camera pose. Ten for the Bridge, DROID and UMI robot domains. Twenty-nine for AgiBot World. Pass a robot domain with vehicle data and it does not necessarily fail.

## The fields, the launch shape and the cost

A forward dynamics spec formally needs a domain name, a vision path and an action path. Four other fields are not required and get you nowhere if they are wrong.

The domain name selects the embodiment, and with it the action encoder and decoder weights trained for that robot or vehicle. Get it wrong and you get well-formed numbers that mean something else. The view point is a short viewpoint description injected into the action prompt, something like ego view; wrong, it quietly degrades the output. The action chunk size is how many action steps are in the chunk, and the media loader reads at most one more observation frame than that. The frame rate is what rate the actions are assumed to be sampled at and written at: ten for the vehicle domain, five for the Bridge robot, thirty for camera moves. The image size is the resize bucket for the action media. The domain name deserves the most suspicion. It is a free string, looked up in a registry, and a valid-but-wrong value is accepted without complaint.

The tier here is Nano, about thirty-five gigabytes, opt-in. Edge is four billion dense parameters and the action pathway is not where its capacity went. Super does not fit this machine at all.

The launch shape also changes. Generation in the first two modules went through the standard distributed launcher. Action modes do not. They run as a plain single process with the latency parallelism preset and with the rank, world size and local rank variables set by hand. At one worker the launcher is pure overhead, and worse, it insists on setting those variables itself, so a stale world size in your environment makes launcher and worker disagree about the topology, and the run hangs at the rendezvous rather than failing.

The trajectory files carry no schema. Each is a bare list of rows: no header, no metadata, no units. That is precisely why the domain name has to be right, and why the notebook has you decode the rotation block and check its two columns are unit length and perpendicular first.

Then comes the comparison that is the actual lesson. Same start frame, same prompt, same seed, same everything except the nine numbers per step. Run the forward trajectory, then the left one, and watch the commanded steering appear. Watch also for the case where the steering is right and the buildings quietly change, because holding the scene consistent and following the command are separate jobs that can fail independently. Then measure the chunk sweep at fifteen steps and again at thirty. The output duration roughly doubles. The wall clock does not, because process start, checkpoint load, decoder construction and guardrail setup are paid once regardless.

## The domain name that was quietly wrong

Now the lab, and this is the one to remember, because it produces no symptom at all.

A colleague runs forward dynamics on vehicle footage and gets a video. It looks like driving. Right length, right frame rate. It passes the video check. The run exited zero. But the steering does not respond to the trajectory they edited, and when they push the numbers around, the output barely changes. They ask you to look.

The hypothesis. Each embodiment has a fixed raw action width, and if the width the domain expects does not match the width of the file, then either the framework refuses the job, which is the good outcome, or it reinterprets the columns, which is the bad one. Remember that the ninth column of a ten-number robot action is the gripper, while the vehicle file has no ninth column at all.

The one diagnostic that settles it takes two seconds and no GPU. Ask the framework what width each domain expects. That table lives inside the framework's own virtual environment, not in your notebook kernel, so you run a one-line program in that interpreter and read the answer back as structured output. Keep that technique. When you need a fact from a package in another environment, ask that environment. It is more reliable than documentation, because it is the code that will actually run.

You can reproduce this with no GPU at all. Take the nine-number vehicle trajectory, pad it with a column of zeros so it has the shape a robot domain wants, and run the course's action check against it. It passes. Every number is finite, sensibly scaled and correctly shaped. The gripper channel is fiction and columns three through eight are a camera rotation being read as something else. Well-formed is not correct.

The repair is not another generation. It is a preflight: before every action job, compare the domain's expected width against the file's width, and check the action passes the shape test for that width. Both are cheap and both run before the model loads.

Then know the limit of your own check. The camera pose trajectory in the cookbook is also nine numbers wide, so the width test passes for the vehicle domain even though it is not vehicle data. The distinguishing information is not in the file at all. It is in your head, and the domain name field is where you put it.

Three things to carry away. An action token is a transition between consecutive states, and that one definition generates all three modes. The rotation is six numbers because no continuous representation of 3D rotations exists in three or four, and the six are the first two columns of the matrix. And a wrong domain name gives you well-formed nonsense and a clean exit, so check the width before you spend the compute.

Lesson 11 runs the model backwards. Given a video, what actions produced it. It also confronts the pose mathematics this lesson has been carefully standing next to.
