---
lesson: "00"
title: "What machine am I actually on?"
slug: "00_environment_check"
duration_estimate: "13 min"
words: 1898
---

# Lesson 00 — What machine am I actually on?

Before you touch Cosmos 3 at all, you are going to spend about forty minutes writing down what this computer actually is. That sounds like a detour. It is the opposite. The most expensive failures in this field are not bugs in your code. They are the moment, an hour into a download, when you find out that a package was built for a different CPU architecture, or that the CUDA version your PyTorch was compiled against is newer than the driver on the box, or that the eighty gigabyte GPU you rented already has sixty gigabytes held by a container you forgot about.

What makes those failures expensive is that each one announces itself as something else. A wheel built for the wrong architecture says there is no matching distribution. A driver older than the runtime says no kernel image is available for execution on the device. A GPU that is already full says out of memory, then invites you to reduce your batch size, which will not help, because the memory was never yours to begin with.

By the end of this lesson you will have built a seven layer probe of this machine by hand, and saved the result as a machine readable record that every later lesson can read. Nothing here loads a model. The GPU is only asked to identify itself.

The seven layers run in a fixed order, because each makes the next meaningful. The host layer is the operating system, the CPU architecture, the C library version and the Python version. Those four facts alone decide whether the Cosmos Framework installs here at all. The framework is Linux only, and the wheels want C library version two point three five or newer. Then the two CUDA versions. Then GPU identity and compute capability. Then VRAM. Then the budget for sharing one card between two workloads. Then free disk. Then Docker, GPU passthrough and registry login, which decide whether lessons two through five can start.

One design rule runs through all of it. Every probe returns nothing rather than raising when a tool is missing. A diagnostic that dies on the first thing it cannot find tells you about that one thing and nothing else. A diagnostic that degrades tells you about all seven layers and marks the gaps.

## The two CUDA numbers

This confuses everyone once, permanently, so let us settle it. There are two CUDA version numbers on your machine and they mean different things.

The first is what the driver reports. It is not the version of CUDA you have installed. It is the highest CUDA runtime version this driver can support. A driver announcing thirteen point zero will happily run a program compiled against twelve point eight.

The second is the runtime version, the CUDA toolkit your PyTorch build was compiled against, baked into the wheel you installed. There is a third number, from whichever CUDA compiler is on your path, and it is almost never the one you want, because PyTorch ships precompiled kernels and never invokes that compiler at run time.

The rule is one line. The driver version must be greater than or equal to the runtime version. If it is, you are fine, even when the two differ. If it is not, you are broken, and broken looks like a message about kernel images, or an import that crashes, rather than anything mentioning versions. The fix is to update the driver, or install a PyTorch built against an older CUDA. It is never to install a second CUDA toolkit alongside the first.

The third layer is compute capability, a version number for the GPU instruction set. It is not a performance rating and not a memory size. It tells you which instructions exist. Eight point zero, Ampere, brought BF16 tensor cores. Eight point nine, Ada, added FP8. Nine point zero is Hopper, which is your H100. The framework picks its attention backend by architecture, and the Hopper one was written around Hopper specific instructions, so it is not simply the newest thing that runs anywhere. And the Reasoner needs capability eight point zero for BF16, eight point nine for FP8. On an H100, both exist.

## One gigabyte seen four ways

Here is the conceptual core of the lesson. Four numbers describe GPU memory, and they are routinely mistaken for one another. An H100 is a discrete GPU, with its own high bandwidth memory, physically separate from host RAM.

Total is the size of that framebuffer. Free is what the driver could still hand out, device wide. Reserved is what PyTorch has taken from the driver and is holding. Allocated is what your live tensors are using. Allocated is always less than or equal to reserved, which is less than or equal to what the driver reports for your process, which is less than or equal to total.

The two gaps are where the confusion lives. Reserved minus allocated is PyTorch's caching allocator. When you free a tensor, PyTorch does not hand the memory back to the driver, because the driver's allocate and free calls are slow and synchronising. It keeps the block for reuse. So reserved ratchets upward and does not come down on its own. That gap is cache. It is not a leak.

The driver's figure minus reserved is mostly the CUDA context. Call it three tenths to six tenths of a gigabyte of bookkeeping and kernel images that appear the moment a process touches the GPU. It is real memory, you cannot avoid it, and you did not allocate it.

The notebook makes you commit to three predictions before it allocates a single one gibibyte tensor, then shows you all three numbers. The habit worth building is this. When a run dies out of memory, read allocated to learn how big your tensors got, read reserved to learn how much your process holds, and read the device wide figure to find out whether something else on the card is the real problem. Reading only one of the three is how people spend an afternoon optimising a model that was never filling the card.

## One card and two workloads

Now the constraint that shapes this entire course. You have one card. Two things want it.

The generator is one. NVIDIA documents Nano inference at thirty-two gigabytes. Edge is not documented, and about twelve gigabytes is a working estimate that lesson six measures properly. The Reasoner, served as a container, is the other. Its FP8 weights are about eight gigabytes, but a serving stack pre-allocates a cache pool against whatever VRAM is free the moment it starts, and holds that pool for the life of the container. Left alone, it takes most of the card.

Eight plus thirty-two is forty, comfortably under eighty, and that sum is wrong. Both fit individually. Together, by default, they do not. There are two honest plans. Take turns, stopping the container before you generate and restarting it after, which costs wall clock time on every switch. Or cap the container's memory claim so both fit at once, which costs you cache, and cache is the same thing as maximum context length.

One asymmetry here is easy to state backwards, so state it carefully. Super generation needs about a hundred and twenty-eight gigabytes and will never fit one H100. Super reasoning fits on one H100 at FP8. The generator is the expensive tower, not the reasoner.

Disk is the layer people forget until a download dies at ninety-four percent, leaving a partial checkpoint that then fails as checkpoint not found, a different looking error with the same cause. Budget about a hundred and fifty gigabytes. Edge is roughly nine gigabytes on disk, Nano about thirty-five, and the Reasoner image with its FP8 profile adds close to thirty more.

The last layer is Docker, where four separate things can be wrong. No Docker at all. Docker with no daemon responding. A daemon that cannot pass the GPU through. And a daemon that can, but has no registry login. Check them in that order, because each makes the next meaningless.

## The GPU that disappeared

Now the debugging lab, which is the part worth hearing twice.

The symptom. You inherit a notebook whose first cell sets some environment variables. Later, model loading fails with a CUDA error about an invalid device ordinal. Or, worse because it is silent, there is no error at all. The code runs on CPU, takes forty minutes per image, and you conclude the model is slow. Meanwhile the driver's own reporting tool, in a terminal, shows a healthy idle H100. The card is fine.

The hypothesis. The card is healthy but this process cannot see it. That points at something process scoped, and there are three candidates. An environment variable is hiding the device. The container was started without GPU passthrough. Or the driver is older than the runtime.

The one diagnostic that settles it. Compare two sources of truth. The driver's own tool talks to the driver directly and ignores the visible devices environment variable. PyTorch honours it. So when the driver reports one GPU and PyTorch reports zero, you have your answer, and it is close to conclusive. If instead the driver tool itself fails inside that environment, you are looking at passthrough. If the device count is right but kernels will not load, you are looking at the version mismatch.

The cause here. The source course this material comes from was written on a two GPU machine, and it pins the visible devices variable to the string one so its work stays off device zero. Those lines still ship. On your single GPU machine, index one names a device that does not exist. There is no error when the variable is set, and none when CUDA initialises, because from the driver's point of view you asked for the set of devices whose index is one, that set is empty, and an empty set is a legal answer.

The repair. Either remove the variable, so the process sees every GPU the driver offers, or set it to the string zero, which is identical here and states an intent rather than relying on a default. What does not work is setting it after CUDA has initialised, because CUDA reads it once per process, at driver init. In a notebook that has already touched the GPU, restart the kernel. That is also why the experiment runs in a child process. Then verify. Re-run the fixed version, re-run the diagnostic, and confirm the two sources now agree. A repair you have not verified is a guess.

Three things to carry away. The driver CUDA version must be greater than or equal to the runtime one, and the reverse is the broken direction. Allocated, reserved and the device wide figure answer three different questions, and out of memory is diagnosed by reading all three. And one card cannot host a serving container and a generation job at once without a decision, so make that decision on purpose.

When you are back at the machine, the notebook walks you through building each layer by hand before it shows you the helper that wraps them. Next, lesson one. What Cosmos 3 actually is, why its parameter count has two correct answers, and your first generated image.
