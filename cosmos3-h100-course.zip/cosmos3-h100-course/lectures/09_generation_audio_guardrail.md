---
lesson: "09"
title: "Audio-visual generation and the guardrail"
slug: "09_generation_audio_guardrail"
duration_estimate: "13 min"
words: 1932
---

# Lesson 09 — Audio-visual generation and the guardrail

This lesson teaches two things the source course never covered, and one of them has been running inside every generation you have done since lesson one without ever being mentioned.

The first is sound. Cosmos 3 can generate video that carries an audio stream, and it can also take an audio track as an input and synchronise the picture to it. The second is the guardrail. It is a safety component that screens your prompt on the way in and your frames on the way out. It is enabled by default. And when it rejects something, it does not raise an exception, it does not return a non-zero exit code, and it may not say anything useful in the log at all. It writes a file and the process ends cleanly.

By the end of this lesson you will be able to generate a clip with sound and confirm the audio stream mechanically rather than by listening, explain the architectural reason Edge cannot do this, accept the single gated licence in the whole course and diagnose the error you get when you have not, and classify any run as blocked, failed or succeeded from evidence rather than from its exit code. You will also write down what each failure looks like on your machine, so that in three weeks you recognise the shape without re-deriving it.

## Two routes to sound

Two of the model modes involve audio, and they do opposite things.

The first route generates a soundtrack. You use the text-to-video mode and turn the sound option on. There is no audio input at all: the model produces picture and sound together. The cookbook ships a prompt for exactly this, a robot pouring water into a sink. It works whenever Nano works and needs nothing external.

The second route conditions on audio. This is the audio-image-to-video mode, and it needs three things: a prompt, an image and a sound path. The image pins the first frame exactly as it did in lesson seven. The audio is turned into tokens by a sound tokenizer and conditions the whole sequence across time. What you get is video whose motion is synchronised to the sound. Footsteps that land on the beats. Water that splashes when you hear it splash.

The interesting question is what the audio actually buys you, and the honest answer is timing. The prompt says what the scene is. The image says what it looks like. The audio says when things happen. That is a temporal signal no amount of prompt engineering supplies, and it is why this mode exists rather than being folded into image-to-video.

Neither route works on Edge, and the reason is architectural rather than a licensing or packaging decision. Edge has no sound tokenizer. There is no component in that checkpoint that turns a waveform into tokens the transformer can attend to, and none that turns tokens back into a waveform. It is not a switch you can flip. Only Nano and Super have audio, and Super needs about a hundred and twenty-eight gigabytes of VRAM for framework inference, so on one eighty gigabyte card Nano is the only option. The notebook checks that capability claim against your own installed package before it downloads anything.

There is an honest gap here too, and the notebook handles it by looking rather than guessing. The cookbook ships a prompt and an image for the audio-conditioned example, and no audio file to go with them. So the notebook searches the asset tree for anything with an audio extension and reports what it finds. If nothing is there, the lesson takes the generate-a-soundtrack route instead. Reporting a gap and routing around it beats inventing a filename and hitting a missing-file error two cells later.

One more thing on verification. Check the audio stream with a media probe, not with your ears. I think I heard something is not a test you can put in a pipeline, and a present but silent audio stream is a different failure from no stream at all.

## Where the guardrail sits

That is sound. Here is the second half of the lesson, and it is the more important one.

The guardrail has two screens at two ends of the pipeline. The prompt screen is a text classifier that runs before your prompt reaches the text encoder. It is one of the small auxiliary downloads you saw arrive back in lesson six. The frame screen inspects the generated pixels after the decoder, and it does face blurring as well as content classification.

Now follow what happens on a rejection. The run does not raise. It does not set a non-zero exit code. It produces a blanked or empty output and the pipeline carries on. The file gets written and the process exits zero. That single fact is the entire reason this course has a separate checking layer, and everything it has said about exit codes being insufficient evidence has been building toward this moment.

The guardrail is also the one piece of gating left in the whole stack. All nine Cosmos 3 model repositories are ungated. The source course spends an entire notebook on accepting five licences for the checkpoints, and that notebook is now obsolete. The guardrail repository still requires one licence click, it is roughly three and a half gigabytes, and the generator enables it by default. So unless you disable guardrails entirely, that click is unavoidable. It takes under a minute and access is granted immediately, with no review queue.

There is also a naming split. The cookbook points at one guardrail repository and the framework at a differently named one. Both exist, both are gated, and accepting one does not grant the other, so check your cache rather than assuming which your run pulled.

## A clean exit with no picture

Before spending GPU minutes trying to trip a filter, the notebook builds the failure signature deterministically, so it works on every machine every time. It synthesises a flat grey video, wraps it in a real run record with return code zero and one output file, and runs the standard verification over it.

Watch what happens. The run record reports itself as fine, because the exit code is zero and a file exists, which is all that claim ever meant. The content verification disagrees, because it opened the file.

Watch the reason it gives, too, because this is subtler than it looks. A flat grey video compresses to almost nothing, so the checker is likely to reject it for being a few kilobytes before it ever gets far enough to notice that the frames are uniform. Both verdicts mean the same thing. There is no picture in this file. A classifier that only looks for the word flat will miss half of them.

Then comes the classifier, and the reason it needs three outcomes rather than two. A blocked run should be logged and skipped. A failed run should be retried or escalated. A succeeded run should be kept. Treating all three as not fine throws away the information that decides what to do next. The one in the notebook is deliberately conservative: return code first, because a non-zero code is conclusive evidence of failure, then whether output exists, then whether the content passes. Only then does it reach for the log text, because messages change between releases, so text explains a verdict rather than reaching one. And a blocked prompt is never retried, because the prompt screen does not depend on the seed.

There is a measurement here too, with a satisfying answer. The guardrail offload flag keeps the guardrail's weights on the host and moves them to the GPU only when a screen is needed. Predict the change in peak VRAM and in wall clock, then measure both. One of them barely moves. The peak of a diffusion run happens inside the denoising loop, and the guardrail is idle at that moment: it screened the prompt before the loop and it will screen the frames afterwards. Its weights being resident contributes to the baseline, not the peak. So this flag would not have saved you from the out-of-memory failure in lesson six.

## The one licence click you cannot avoid

Now the lab, and it is the only gating error in this course.

The symptom. A run dies in the first minute, before any progress bar appears, with a wall of traceback ending in an HTTP 401 or 403 about a gated repository. The confusing part is that you did not ask for a guardrail, you asked for a video, and every Cosmos 3 checkpoint is ungated. So the error appears to be about a model you never mentioned.

The hypothesis. The guardrail is enabled by default, it is gated, and this process cannot authenticate for it.

Now the part that makes this a real diagnosis rather than a guess. There are two independent causes and they look identical from the traceback. Either the licence was never accepted, in which case even a perfectly valid token gets refused because the account has no grant. Or the licence was accepted and no token reached the subprocess. The generator runs as a child process with a cleaned environment, so a token you exported in a terminal after Jupyter started is not in Jupyter's environment and therefore not in the child's.

The one diagnostic that settles it reports two things independently: whether a token is present in this process, and what status the server returned. No token with a refusal means go and set a token. A token present with a refusal means go and accept the licence. Those need different fixes, and without that separation both appear as the same error.

The repair is four steps. Open the guardrail model page while signed in. Read the licence and accept it. Make a token visible to this process, not to some other terminal. Then restart the kernel so it inherits the new environment. That last step is the one people skip, and it is the single most common reason this looks done and is not.

The verification is not that the error went away. It is a positive check that the repository is reachable from this process, run at the top of the pipeline before you spend a minute of GPU time. Gating failures are cheap to check and expensive to hit.

A closing word on the no-guardrails flag. It exists and it works. It is not a workaround for a download you did not want, and it is not a performance optimisation, because you have just measured what offloading costs. It might legitimately be a considered decision in a closed research pipeline generating content the screen would reject for reasons that do not apply to you. Collision footage for a vehicle safety dataset is the real case. But then every output is unscreened, including ones in a batch you never looked at and later handed to someone else, and face blurring goes too.

Three things to remember. Only Nano and Super have audio, and Edge's inability is a missing tokenizer rather than a missing flag. The guardrail is the only gated repository left, it is on by default, and one licence click is unavoidable. And a blocked generation is a clean exit with no picture, so never trust the exit code, open the output.

Lesson 10 starts a new module and a new idea: Cosmos 3 treats action as a modality, in the same sense that text, image and video are modalities.
