---
lesson: "18"
title: "Evaluating a post-trained model"
slug: "18_evaluation"
duration_estimate: "13 min"
words: 1939
---

# Lesson 18 — Evaluating a post-trained model

You have a checkpoint now, or at least an attempt at one. The obvious next question is whether it is any good. This lesson answers that, and it opens with an inconvenient fact.

The framework's evaluation directory does not exist in this release. The code structure document lists it, along with several other subpackages, tagged as planned, and states plainly that those directories are intentionally absent on disk. There is no offline metric harness. There is no action MSE script. There is no validation loss loop, and the shipped configs have a training dataloader section and no validation one at all. The Bridge dataset even ships a validation split with fifty-one clips, and nothing in the training loop consumes it.

What does exist is closed-loop simulation evaluation for action policies, and that needs a separate virtual environment whose pins cannot coexist with the training environment. So this lesson builds the missing thing instead. By the end you will have an offline evaluator with a fixed prompt set, fixed seeds, two models and automatic verification. More importantly, you will have calibrated it against an effect you planted yourself, measured how much the seed alone moves your metric, worked out how many samples a real difference would need, and caught a flattering result that came entirely from leakage. It all runs on a laptop.

## Three ideas that replace the missing harness

None of these is complicated and all three are routinely skipped.

The first. A held-out set is data the model has never trained on, chosen before you look at any results. Both halves matter. Never trained on is obvious. Chosen before you look is the half people violate. Run the evaluation, dislike the answer, swap in different prompts, and you have turned your held-out set into a training set for your own judgement. The prompt list is part of the experiment and it gets fixed at the start.

The second. Training loss falling is not the model getting better. It measures how well the model fits the examples it is being shown while it is being shown them, and it falls for memorisation, for schedule effects and for easier batches as readily as it falls for learning. It is a necessary condition and evidence of almost nothing on its own. After lesson seventeen's smoke run the honest claim is that gradients flowed.

The third. One before-and-after comparison on one prompt is not evidence. Generation is stochastic, so change the seed and you get a different video from the same model. If the seed-to-seed difference is larger than the base-to-fine-tuned difference, and after twenty iterations it certainly is, then a single comparison is telling you about the seed. Run several seeds and look at the spread before you look at the means.

Those three give the shape of the harness. A fixed prompt set that is genuinely held out, run at multiple seeds on both models, with every output verified rather than assumed. And one design rule that matters more than it looks. A record gets written even when the sample failed, because a harness that drops failures reports the mean of the successes, which flatters whichever model fails more often.

## A model pair with a known answer

Here is the step almost every evaluation write-up skips, and it is the reason so many of them are wrong. An evaluator you have never validated is not evidence. You cannot validate it against a real fine-tune, because you do not know the truth there. That is what you are trying to find out. So validate it against something whose truth is a constant in your own code. The lesson gives you a pair of synthetic models, a few lines of NumPy each, differing in exactly one planted number, plus seed noise of a known size. If your harness cannot recover an effect you planted yourself, it will not recover a real one either.

Be clear about what that fixture is not. It is not a model of Cosmos 3, it does not generate video, and its numbers say nothing about any checkpoint. The moment the harness is calibrated you point it at real outputs and the fixture goes away.

Calibration means checking three properties before you trust the metric on anything unknown. Monotonicity, does the metric move in the right direction as you move the planted parameter. Scale, how many metric units is one unit of planted effect, because without that a difference of nought point nought three means nothing to you. And sign on out-of-domain content, because the fixture's out-of-domain effect is deliberately negative, so a metric that reports an improvement there is not measuring what you think.

The lesson uses three cheap proxies and states the blind spot of each, which is a habit worth stealing. Structure measures spatial autocorrelation, how much a pixel predicts its neighbours, and is blind to what the structure is, so coherent noise scores well. Aliveness measures the mean difference between consecutive frames, and is blind to direction, so a shaking camera and a moving robot look identical. Stability measures the variance of that difference, and is blind to slow drift, so a scene dissolving over eight frames scores as stable. None of them measures whether the video shows what you asked for. That is a property of every automated proxy of this kind, and it is why the honest workflow is to screen automatically and then look at what survives.

## Matched seeds, and how many samples you need

Now the two statistical ideas that decide whether your result means anything. The first is pairing. Use the same seed for both models on a given prompt, so the two runs differ only by the model, and the prompt's contribution and the seed's contribution cancel in the difference. Run the identical data through an unpaired comparison and the interval blows out several times wider. Nothing about the models changed, only how you looked at them. So the seed has two jobs. Fixed across the models you are comparing it is a control. Varied across repeats it is the source of the variance you are measuring. Doing both is not a contradiction, it is the design.

The second is composition. Your pooled mean is a composition-weighted average over your prompt list. If a suite is a third in-domain, a third near-domain and a third out-of-domain, and the true effects there are strongly positive, mildly positive and slightly negative, then the pooled number is about a third of the in-domain effect and may not clear zero, even though the fine-tune genuinely helps in domain. Change the suite and you change the headline without touching either model. Report per category, always.

Then measure how much the seed alone moves the metric with the model held fixed. Given a per-sample standard deviation and an effect you care about, the paired samples you need is roughly the square of two point eight times that standard deviation over the effect. Treat it as a floor. Precision improves as one over the square root of the sample count, so you quadruple the samples to halve the interval, which is why run a few more is rarely the answer.

One more design question, and it is the one worth internalising. Sixteen seeds on five prompts and four seeds on twenty prompts give the same sample count and different claims. More seeds on the same prompts shrinks seed variance and leaves prompt variance untouched, so it makes you very confident about five prompts. More prompts samples the population you wanted to generalise over. If you can afford only one, buy prompts, and say which you bought.

## The debugging lab, the flattering result

The symptom is unusual, because nothing is broken. A colleague hands you an evaluation. Same harness, same metric, same code. Their fine-tuned model beats the base model by a wide margin with a tight interval, across ten prompts and four seeds. Their result looks better than yours in every respect.

Four hypotheses. They trained longer or on more data, which is checkable, so ask. They used a different metric or threshold, also checkable. They dropped failures, in which case their sample count is less than prompts times seeds, so count. Or their evaluation set leaks. Check the fourth first, because it costs nothing and because it invalidates the result rather than merely explaining it.

The diagnostic is a trigram overlap between every evaluation prompt and every training caption. Run it, and their suite lights up. Several prompts sit above a third overlap with the nearest training caption, and at least one scores a perfect one, meaning that prompt is a training caption word for word. The model is being asked to reproduce something it was trained to reproduce.

Leakage in a video fine-tune arrives three ways, in increasing order of how easy it is to miss. The same clip in both splits, which is obvious once you look and happens constantly when a script splits a directory listing. Near-duplicate frames, meaning two clips from the same episode a few seconds apart, different files, nearly the same content, which no filename split will catch. And the same caption text, which is specific to Cosmos 3, because the generator trains on the structured caption object, and that is the same kind of object you prompt with. Convenient for alignment, hazardous for evaluation.

The repair is not to remove the leaked prompts and re-run. That is wrong twice, because you would be choosing your evaluation set after seeing results, and because the survivors are the ones worded differently rather than the ones genuinely held out. Fix the split at the source. Hold out clips, chosen before training and excluded from the manifest, and note that the Bridge dataset ships a validation split for exactly this. Deduplicate by content rather than filename. Write evaluation prompts independently, because if the same captioner produced both they are not independent. And run the leakage check as a gate before every evaluation.

Verify in three steps. The clean result should land near the true effect, which you only know because you calibrated on a fixture. The out-of-domain prompt should not improve, because a robot manipulation fine-tune that also improves lighthouse footage is telling you your metric measures something other than what you think. And the gate should now be part of the harness. The uncomfortable lesson is that the leaked result was not a bug in the evaluation code. Every line of their harness was correct. The fault was in the split, days earlier, invisible from inside the evaluation. Most bad results look like this.

Two more things. Reasoner-as-judge is tempting and circular here, because the reasoner and the generator are two towers of one checkpoint, so a generator fine-tune shifts the distribution the judge was trained on. Use a different model family, or restrict the judge to nearly mechanical questions. And for an action policy the number that matters is closed-loop success rate in simulation, which this machine cannot produce and which has four documented parity traps that each silently destroy a policy.

Write it up in four sections. Method, results with intervals, threats to validity, and an explicit list of what the evidence does not show. That fourth section makes the other three trustworthy. And a null result with a bound is a real result. We could not detect a difference at twenty paired samples, so any real effect is smaller than about twice our standard error, is a useful sentence. It did not seem to help is not.

Lesson nineteen is the capstone, and it puts every module of this course into one pipeline.
