---
lesson: "11"
title: "Inverse dynamics and pose mathematics"
slug: "11_action_inverse_dynamics"
duration_estimate: "13 min"
words: 1946
---

# Lesson 11 — Inverse dynamics and pose mathematics

Lesson 10 gave the model actions and asked what would happen. This lesson asks the opposite. Given this video, what actions produced it. And in answering it you confront the pose mathematics lesson 10 stood carefully next to.

Almost all of this lesson is arithmetic you can check by hand, and that is deliberate. Pose bugs are silent. A wrong convention produces a trajectory that plots without error, looks smooth and plausible, and is completely wrong. No exception, no warning, no failed check. The only defence is verifying small cases yourself, which is why the notebook makes you implement the integration from scratch first.

By the end you will be able to read every slice of a four by four pose, implement relative-to-absolute integration from first principles and reconcile it with the framework's, explain the calibration constant everyone passes and nobody questions, quantify a round trip, and diagnose a plotted trajectory that appears to show a car flying.

## The inverse question and the four by four pose

Forward dynamics: frame plus actions in, video out. Inverse dynamics: video in, actions out. Same checkpoint, same entry point, one field changed.

The spec loses its action path, because the action is now being predicted rather than supplied. Everything else stays. You still declare the domain, because the model needs to know which embodiment's action space to answer in, and the frame rate and image size, because the meaning of one step depends on the frame rate.

The output is not a video. It lands in the structured output record the run writes, under the first output's action entry, as an array of relative pose deltas: nine numbers per row for the vehicle domain, one fewer rows than frames, because there are one fewer gaps than frames. An array of deltas is not a trajectory yet, and turning it into one is the rest of the lesson.

So, the four by four homogeneous transform, from zero. A pose is a position and an orientation together, and writing them as two objects is a nuisance, because composing two poses then needs two rules. The four by four packs both into one object with one rule. Its top left is a three by three rotation block, its top right a three-element translation column, and its bottom row is always zero, zero, zero, one.

Three slices, and you will use all three constantly. The rotation block is the orientation. The translation column is the position, where the camera is. The third column of the rotation block is the heading, where the camera is looking. That last one is worth a sentence: the columns of a rotation matrix are the images of the coordinate axes, so the third column is where the camera's own Z axis points in world coordinates, and Cosmos 3 uses the Z-forward convention, meaning the camera looks down that axis.

## Composition and the backward framewise convention

Here is the rule that makes all of this worth the trouble. Composition of poses is matrix multiplication.

If T is a pose and D is a small movement expressed in the moving frame's own coordinates, the new pose is T times D. Multiplying on the right means relative to where I am now. On the left would mean relative to the world origin, a different and usually wrong thing.

Write out that product and the parts fall into place. The new orientation is the old one composed with the turn. The new position is the old position plus the step rotated into world coordinates. That second term is the whole story: driving forward one metre moves you in a different world direction depending on which way you were facing, and it is the reason poses cannot be added.

Two gotchas while we are here. The inverse of a pose is not its transpose: the rotation block does invert by transposing, but the translation becomes minus the transposed rotation applied to the translation. A plain transpose gives you a matrix whose bottom row is no longer zero, zero, zero, one, which is the fastest way to notice. And know which direction you have. Camera-to-world takes a point in camera coordinates to world coordinates, and its translation column is the camera's position. World-to-camera is its inverse, and reading its translation column as a position gives you a mirrored, rotated path that looks fine. Everything here is camera-to-world.

Now the convention, which has to travel with the data. The model predicts relative deltas, and converting them to absolute poses is a choice. The one used throughout the action stack is called backward framewise. To encode, the delta at step i is the inverse of transform i, times transform i plus one. To decode, transform i plus one equals transform i times the delta. Compose them back up one at a time, starting from the identity, because there is no absolute information in the data at all. Only differences.

Other conventions exist: one measures every delta from the first pose, others re-anchor every eight or sixteen steps. Decode with the wrong one and you get a trajectory that is smooth, plausible and wrong.

Why predict relatively at all. Relative deltas are small numbers near zero, a far easier regression target than absolute positions that grow without bound, and they are translation-invariant, so the same manoeuvre looks the same wherever it happens. The cost is that errors compound: each pose is built on the previous one, so a small bias becomes a growing drift. You see it in the round trip at the end of this lesson, and it is what breaks open-loop control in lesson 13.

One practical note. The pose utility module moved upstream. The source course imports it from a path that no longer exists, so the notebook probes both locations and tells you which your checkout has. An import path is a fact about your checkout, not about the documentation.

Verify your own integration on three steps before trusting a hundred. Drive one unit forward, turn ninety degrees about the vertical axis, drive one unit forward again. Starting at the origin looking along Z, you end up one unit along X and one unit along Z. Work that out on paper first. If your code returns anything else, the bug is in the composition order or the column convention, and finding it there costs a minute.

Then compare against the framework, because there is one real difference. Your version orthonormalises by Gram-Schmidt. The framework takes the cross product for the third column, then projects the whole matrix back onto the rotation group with a singular value decomposition and a determinant fix. On clean input the two agree to about sixteen decimal places. On skewed input they separate, because Gram-Schmidt privileges the first column and fixes up the second, while the projection treats both even-handedly.

## The scale constant, told honestly

The source course passes a translation scale of one point three five and says nothing about it. Here is what it is.

Mechanically it is a divisor. On decode, the translation part of each delta is the first three numbers divided by it. It exists because the values a model emits are in whatever units the dataset normaliser used during training, and turning those back into metres needs a constant.

The honest answer to where one point three five comes from is that it is a calibration constant. The framework's own docstring says to prefer denormalising with the dataset's action normaliser rather than passing a scalar at all. A single number cannot be right for every dataset. Treat it as the number that made the cookbook's vehicle example come out at a plausible size.

Here is the useful consequence, and you can prove it rather than believe it. The constant divides only the translations. The rotations never see it. So every position in the integrated path is the same sum of rotated steps, uniformly divided by one number. The shape of a recovered trajectory is therefore meaningful: the turns, the curvature, the ratio of lateral to forward motion all survive. The absolute size in metres does not, unless you know the constant is right for your data. Never report that a vehicle travelled forty-seven metres without saying where the scale came from.

The lesson finishes with a round trip. You have a video and a set of actions the model believes produced it. Feed those back into forward dynamics from the same starting clip, and if the two directions are consistent, the regenerated video should resemble the original. It is the closest thing to an offline metric here, because the framework's evaluation package is listed upstream as planned and absent from this release. Be clear what it measures. A good round trip is evidence the two directions agree with each other, not that either is right about the world. Two models can be consistently wrong together, and this metric cannot see it.

## The car that drove into the sky

Now the lab. A colleague plots a recovered vehicle trajectory in 3D and sends you the picture. The path climbs steadily away from the ground for the whole clip. Their message says the model thinks the car is flying. Nothing errored. The plot rendered. The numbers are all finite.

The hypothesis. Two coordinate conventions are in play and they disagree about which axis is vertical. In most robotics and simulation stacks, Z is up: X and Y span the ground plane and Z is altitude. In graphics, and in most camera frames including this one, Y is up and Z is forward, out of the lens. The plotting library is neutral: whatever you hand it as the vertical is drawn upwards. Hand it the forward axis and forward motion becomes altitude. A car driving in a straight line becomes a car ascending in a straight line, which is exactly the picture that arrived.

The one diagnostic that settles it does not involve squinting at the plot. Ask the data which axis is which. A road vehicle travels a long way forward, wanders a bit sideways, and changes altitude hardly at all. So rank the three world axes by how far the path extends along each. The largest is forward, the smallest is up. If the axis you drew upwards is not the smallest, you have your answer in one line of arithmetic.

The repair is a remap before plotting. World X across, world Z into the page, world Y up. That is precisely the remap already sitting inside the course's plotting helper, which is why the earlier plot looked sane.

The verification is not that it looks flatter now. Two checks a program can run. First, the extent along the axis you drew upwards is the smallest of the three. Second, the heading vectors, projected onto the plane you called the ground, have non-trivial length. The second matters because a path can be flat by accident. A car stopped at traffic lights has small extent on every axis and passes the first check for entirely the wrong reason.

Three things to remember. A pose is a four by four transform: translation column for position, third rotation column for heading, composition by multiplication on the right. Backward framewise means the delta is the inverse of one transform times the next, and decoding composes them back up with the translation divided by the scale constant. And that constant makes trajectory shape trustworthy and absolute size meaningless.

Lesson 12 runs the third mode: observation plus instruction in, video and actions out. It is also where the source course is broken, and where you fix it.
