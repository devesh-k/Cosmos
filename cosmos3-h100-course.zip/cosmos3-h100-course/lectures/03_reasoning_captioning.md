---
lesson: "03"
title: "Captioning and structured scene records"
slug: "03_reasoning_captioning"
duration_estimate: "13 min"
words: 1936
---

# Lesson 03 — Captioning and structured scene records

Captioning is the cheapest thing you can ask a reasoner to do, and its output feeds everything downstream. That makes it the right place to establish prompt discipline, because a sloppy caption format costs you nothing today and costs you the whole pipeline in module six. By the end of this lesson you will have one structured, validated record per clip, produced reproducibly, at a cost you measured yourself.

Start with the most important idea in the lesson, and it is easy to miss, because the API takes a video file and hands you back a paragraph. The model never sees a video. What actually happens is that the server decodes the video, samples still frames from it at a rate you choose, and feeds those frames to a vision language model as a sequence of images. There is no temporal convolution, no optical flow, no video encoder. There is a list of pictures and a language model.

Two consequences follow, and both are practical. The first is cost. Every sampled frame becomes a few hundred tokens in the context window, so frame count is the dominant cost lever in video reasoning, bigger than prompt length or answer length by an order of magnitude. The second is what the model can notice. An event shorter than the gap between samples is invisible. At one frame per second, a gripper that closes over three hundred milliseconds either lands on a sampled frame or it does not exist. At eight you catch it, and you pay eight times the frame budget.

## Sampling rate is a claim about timescale

So the frames per second argument is not a quality knob you turn up. It is a statement about the timescale of the thing you are asking about. Choose it for the question, not for the picture.

One clarification, because two numbers share a name. The rate you pass is the sampling rate for the model, not the clip's own frame rate. A clip recorded at thirty, sampled at four, gives the model four frames per second and discards twenty-six. Asking for sixty on a clip recorded at thirty does not conjure frames that were never recorded. Do not guess the clip's length or native rate either. Ask the media probe that ships with FFmpeg.

Now a piece of honesty from the course. The wire format for that sampling rate is not verified against a live container of this NIM version. Every serving stack spells it differently, so the client implements three shapes. One puts the rate inside the video content part, one puts it as a top level key in the extra body, one does not send it at all. The source course used a fourth shape, the vLLM convention, which may be what this NIM wants.

You do not have to take anyone's word for it, because one measurement settles it. Send the same clip at two different rates and compare the prompt token counts. If the count moves, the server honoured the field. If it does not move, the field is being ignored, and every result in this lesson about sampling rate is measuring nothing. That check costs two requests. Run it before you conclude anything. If no shape moves the count, the server samples at a fixed rate you cannot control, which is itself a reportable finding.

Once the check passes, sweep. The notebook captions the same robot clip at one, two, four and eight frames per second, holding everything else fixed. Predict first. Name one detail you expect the caption at eight to mention that the caption at one will miss, and predict whether the low rate caption will be shorter, longer or the same length.

Length is the trap in that prediction. People assume fewer frames means a shorter caption. Output length is governed by the prompt and the maximum token setting, not by how much the model saw. A model with less evidence often writes just as much, with more of it invented.

Then read the token numbers and work out the relationship yourself. Going from one to eight multiplies the frame count by eight. By what factor did the prompt tokens multiply? Did latency scale the same way, and if not, which part of the request is not proportional to frame count?

Clip length is the other axis, and it trades against the rate exactly. A thirty second clip at two is the same budget as a fifteen second clip at four. Two ways to buy the same budget, and they are not equally good, because sampling densely over a short window and sparsely over a long one answer different questions.

## From a paragraph to a record

A paragraph is a fine thing for a human to read and a poor thing for a pipeline to consume. Lesson seven needs to take a caption and vary one attribute of it, change the lighting and keep the subject, and you cannot vary an attribute of a paragraph.

So ask for a structured caption. Name the exact keys you want, give the model an example of the shape, and tell it to reply with JSON and nothing else. The schema is the through line of the whole course. Subjects, setting, actions, lighting and camera. Those five are the axes module two knows how to condition on.

Three things in that prompt do real work. Saying reply with JSON only suppresses the model's habit of writing here is the JSON you asked for first, and that preamble is the most common reason a naive parse fails. The example object pins key names and types, and without it you get a singular key sometimes and a plural other times. And instructing it to write the word unknown rather than omit a key stops it silently dropping a field, because a missing key breaks a downstream lookup and the word unknown does not.

Then parse it. The parser handles the four ways a model wraps JSON in practice. Markdown fences, prose before, prose after, and a preceding thinking block. It scans for the first balanced brace pair rather than using a greedy pattern, and it raises rather than returning nothing, because a silent empty result hides a prompt problem.

One distinction to hold on to. What you have built is a validator, not a constraint. The server generated free text and you checked it afterwards. Some serving stacks support genuine constrained decoding, a grammar the sampler cannot leave, which makes malformed output impossible rather than detectable. Whether this NIM version exposes that is not verified here, so validate every record. A pipeline that trusts unvalidated model JSON fails at three in the morning on record four thousand.

## Why the same request gives different answers

Language models sample. At each step the model produces a probability distribution over the next token, and the sampler draws from it. Three parameters govern that draw. Temperature scales the logits before the softmax, and zero collapses it to always taking the most likely token. Top p considers only the smallest set of tokens whose probabilities sum to that value. And the seed initialises the random number generator.

The client sends none of these unless you pass them, and that is deliberate. Quietly substituting a default makes results irreproducible against the server's documented behaviour. So the notebook asks the same question three times with nothing set, and the answers differ. Then three times with temperature at zero, top p at one and a fixed seed, and they should be identical.

If the controlled runs still differ, you have learned something real about your server rather than hit a bug. Batched inference on a GPU is not bitwise deterministic. Which other requests share a batch changes the reduction order in the matrix multiplies, which changes the last bits of the logits, which occasionally flips which token is most likely. Temperature at zero removes sampling randomness and not that. So store the caption you actually used alongside the record.

Which setting do you want? Not always zero, and that surprises people. For a scene record that feeds generation, yes, you want it reproducible. For exploring what a model can see, no. Three samples at a higher temperature tell you about the model's uncertainty, and a single greedy sample tells you nothing about it. Fix the sampling when you are measuring something else, and vary it when the variation is the measurement.

## The error that says nothing about video

Now the debugging lab. The symptom. A video request that has worked all afternoon suddenly returns HTTP 422, unprocessable. The message says nothing about video and nothing about codecs. The same clip plays fine in your browser. Images still work. Short videos still work.

The hypothesis. The NIM decodes video with OpenCV, whose bundled build has no AV1 decoder. Handed an AV1 file, OpenCV does not raise. It opens the container, reads the metadata, and returns zero frames. The server then has a request with a video part containing no frames, and rejects it. That is why the error mentions no codec. Nothing in the stack knew a codec was the problem.

This is not an edge case. The robot dataset format that all the Cosmos 3 action data ships in stores its video shards as AV1, and so does much of what a modern phone produces.

The one diagnostic that settles it. Run the FFmpeg probe on the file and read the codec. One command, and it is the difference between a five minute fix and a lost afternoon. The notebook re-encodes a working clip to AV1 on purpose, then sends it with the transcoding bypassed, so the failure arrives for real rather than being described.

The repair. Transcode to H two six four before sending. The client does this automatically for every local video, caching the result and returning the original untouched if it is already fine. It also forces a standard eight bit pixel format, not just the codec, because a ten bit stream is perfectly valid H two six four and this decoder still cannot open it, producing the identical symptom for a file whose codec name looks correct.

The verification, and both steps are necessary. Confirm the codec changed. Then confirm the model actually saw frames, by checking the prompt token count, because a request that returns a success code having seen one frame is not a fix.

One gotcha. The transcoder needs the probe to know the codec, so on a machine without FFmpeg it passes the file through unchanged and the protection is silently inactive.

Then build the artefact. One record per clip, with enough provenance to reproduce it. The prompt, the sampling settings, the model identity and the measured cost. In lesson seven you will want to know which caption produced a given video, and at what rate. A record without that is an anecdote.

Three things to carry away. The model sees sampled frames, not video, frame count is duration times rate, and frame count dominates cost. Structured records are for pipelines and free text is for humans, so name the keys, give an example, forbid prose and forbid omission, then validate every record anyway. And an HTTP 422 on a video request means zero decoded frames until proven otherwise. Probe first, transcode second, check the token count third.

Back at the machine, the notebook has you verify the rate is honoured, run the sweep, and build a batch captioner with caching and a manifest. Leave the container running. Next, lesson four, and embodied reasoning.
