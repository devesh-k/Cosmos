---
lesson: "15"
title: "Optimisation, with the receipts"
slug: "15_optimisation"
duration_estimate: "13 min"
words: 1940
---

# Lesson 15 — Optimisation, with the receipts

The last lesson taught you to tell a real speedup from an artefact. This one goes looking for real ones, and the same discipline holds throughout. Not one number in this notebook is asserted by the course. Every ranking and every ratio comes out of a cell you run on your own machine.

That matters more here than anywhere else, because optimisation advice ages badly. A blog post from two years ago about which precision is fastest was probably right, about a different GPU, a different PyTorch and a different kernel library. The method survives. The numbers do not.

By the end you will be able to explain the floating-point formats that matter at the bit level, and derive why one of them needs a whole subsystem to make training work and another does not. You will be able to say what FlashAttention does and why it is a memory result before it is a speed result. And you will be able to compute, rather than guess, whether compiling your model pays for itself.

## Optimisation is a search problem

Most optimisation writing is a list of things to turn on. That is not what this is, because on one GPU with one workload the list is short and most of it is already on by default. What is left is a search problem. You have a time budget, which is the seconds you are willing to wait. You have a memory budget, which is eighty gigabytes minus anything else resident on the card. And you have a quality bar. You choose a step count, a resolution tier, a frame count, whether guidance is on, and a model tier. What you get out is one configuration and an argument for why it is the one.

The knobs are not equal, and they are unequal in a way you can predict from first principles and then check against measurement. Latent tokens go as pixel area, so halving each linear dimension is roughly a quarter of the tokens, not half. Steps are sequential passes over the same latent, so they hit wall clock almost linearly and peak memory hardly at all. Frames enter the token count linearly. Guidance is a step function, because classifier-free guidance evaluates the network twice per step.

## What is actually inside a floating-point number

Start from zero, because b-float sixteen is more robust than float sixteen is a sentence you cannot evaluate without knowing what is in a float.

A floating-point number is three fields packed into a fixed number of bits. A sign bit. An exponent field. And a mantissa field, also called the significand. The exponent sets the range, which is how large and how small a number can be before it becomes infinity or zero. The mantissa sets the precision, which is how many distinct values fit between one power of two and the next.

Float thirty-two spends one bit on sign, eight on exponent and twenty-three on mantissa. A sixteen-bit format has to split sixteen bits between those two jobs, and the two common ones split them differently. Float sixteen spends its bits on precision, taking fewer exponent bits and more mantissa. B-float sixteen spends its bits on range. It keeps float thirty-two's entire exponent field and throws away mantissa instead, so it is literally the top sixteen bits of a float thirty-two number.

That single choice is why b-float sixteen is the default for training. Gradients in a large network are small, many of them between ten to the minus seven and ten to the minus nine. Float sixteen's smallest normal number is around six times ten to the minus five. Below that it has subnormals for a few orders of magnitude, then zero. A gradient that becomes exactly zero does not make training slightly worse. It makes that parameter stop learning, silently.

Loss scaling is the fix. Multiply the loss by a large constant before the backward pass so every gradient is scaled up into representable range, then divide by that same constant before the optimiser step. It works, and it is an entire subsystem. Dynamic scale selection, overflow detection, skipped steps. All of it exists because of those missing exponent bits. B-float sixteen keeps float thirty-two's exponent, so no scaling subsystem is needed. You pay in mantissa bits, which for gradient accumulation matters much less than you would expect.

Float eight on Hopper is the next step down, and there are two formats because eight bits is not many. One has four exponent bits and three mantissa bits, more precision and less range, used for weights and activations. The other has five exponent bits and two mantissa bits, more range and less precision, used for gradients. What float eight buys is bandwidth and tensor core throughput. What it costs is that you cannot cast to it and hope. Values must be scaled into range per tensor, which is why the PyTorch entry point takes explicit scale factors rather than being a data type you pass to a multiply. Float eight is a numerics project, not a data type swap.

One warning before you generalise any of these numbers. If your two float thirty-two rows differ from each other, that is TF32, a nineteen-bit internal format the tensor cores use for float thirty-two multiplies, on by default in many builds. It is a precision change wearing a float thirty-two label. And a three times faster matrix multiply is not a three times faster generation, because only some of a diffusion transformer sits on the tensor core path.

## Attention, and the memory it never uses

Attention takes queries, keys and values, computes a softmax over the scaled product of queries and keys, then multiplies by values. The obvious implementation builds that score matrix explicitly, and it is square in the sequence length. For a video latent with tens of thousands of tokens, per head, per layer, that is the largest tensor in the model, and it exists for microseconds before being reduced away.

FlashAttention never builds it. It walks the keys and values in tiles that fit in the GPU's on-chip memory, accumulating the softmax with a running maximum and a running sum. The score matrix is never written to high-bandwidth memory at all. Memory goes from quadratic in the sequence length to linear in it.

Say that first, because the ordering is the insight. FlashAttention is a memory result, and the speed follows from the memory traffic it saves. Attention at these sizes is bound by memory bandwidth, not arithmetic, so not writing the big matrix means not reading it back, and the kernel goes faster for the same reason it uses less memory. The memory half often decides whether a configuration fits at all. The notebook measures both implementations across a range of sequence lengths, and you watch the naive one quadruple its peak memory at every doubling while the fused one merely doubles.

Then the parallelism presets, where the honest answer is a null result. The framework takes a latency preset or a throughput preset. Latency optimises for finishing one sample as fast as possible, which is what an action model in a control loop needs. Throughput optimises for total samples per unit time and will make any single sample slower to get it. But these presets configure how work splits across ranks, and the product of the parallelism degrees has to equal the world size. On one GPU that world size is one, so there is nothing to split. No measurable difference is a good finding, and reporting it beats repeating a claim.

Two more things before the lab. The cheapest optimisation available is not a setting at all. It is never loading the same model twice. Every generation run pays process start, library import, context creation, weight load and text encoding before it denoises anything. Ten separate runs pay that ten times. One batched run pays it once, so if the fixed cost is a meaningful fraction of a run, batching is the largest win available and it costs nothing in quality.

And compilation. Compiling a model traces it into a graph, fuses operations that would each otherwise read and write memory, and generates specialised kernels. For a model dominated by small elementwise operations that fusion can be a large win. It costs a long first call, which is a compiler running rather than a warm-up. It costs extra memory. And it recompiles on shape change, so a model with variable resolution can spend its life compiling. This course turns compilation off, and the reason is arithmetic rather than taste. Payback is the compile cost divided by the per-run saving, and at course-sized workloads that number of runs is never reached.

## The lab: an optimisation that made things slower

This lab differs from the last one in a way that makes it good. The measurement is fine. The conclusion is wrong.

Here is the symptom. A colleague was running a batch of thirty-two items and it used more memory than they liked, so they dropped the batch size to two. Per-batch wall clock fell by a large factor. They wrote it up as a speedup and reduced the default. The pipeline now takes longer on the same dataset and nobody can see why. Run the cell and the reported speedup is real.

The hypothesis. The mistake is the unit. Milliseconds per batch is not a cost anybody pays. What you pay is milliseconds per item, and a batch of two does one sixteenth of the work.

Underneath the unit error there is a hardware fact worth naming. An H100 has a very large number of streaming multiprocessors. A small batch does not produce enough independent work to fill them, so most of the device idles while a few units do the job. Time per batch falls. Time per item does not, and below some batch size it rises. That is saturation, and every GPU workload has one. Below it you are paying for silicon you are not using.

The one diagnostic that settles it is normalisation. Sweep the batch size and plot items per second rather than seconds per batch. The curve rises steeply, flattens at the knee, then falls back as memory pressure takes over. The colleague's setting sits far down the left-hand side.

The repair is to pick the batch size at or just below the throughput knee, subject to your memory ceiling, and to report the decision in items per second and in peak gigabytes, so the next person can see both constraints. Verification is the end-to-end time for a realistic job at the colleague's batch size and at the knee. That is the number the pipeline actually pays.

The general lesson is the one to keep. A ratio without a named denominator is not a result. Twice as fast, per what.

One note about quality, because every optimisation trades against it. Cost you can measure exactly. Quality you cannot. The automatic proxies are blind to prompt adherence and to whether rising edge density means sharper detail or more noise. Use a proxy to pick two or three candidates, then look at the outputs yourself.

Three things to remember. Range and precision are a trade, and b-float sixteen buys range with mantissa bits, which is why it needs no loss scaling. FlashAttention is a memory result first and the speed follows. And a correctly measured speedup can still be the wrong conclusion.

The next module uses all of this. The single-GPU post-training argument is a memory argument, and it only lands for somebody who has measured memory rather than read about it.
