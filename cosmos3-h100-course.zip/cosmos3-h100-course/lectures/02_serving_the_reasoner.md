---
lesson: "02"
title: "Serving the reasoner on one GPU"
slug: "02_serving_the_reasoner"
duration_estimate: "13 min"
words: 1924
---

# Lesson 02 — Serving the reasoner on one GPU

This lesson is the bridge between Cosmos 3 exists and Cosmos 3 answers my questions. By the end you will have a Reasoner container running on your own H100, a measured VRAM budget for sharing that card, and a written plan the next four lessons depend on. It is also where you meet the constraint that shapes everything after it. A served model and a generating model both want the whole card, and you have one.

Start with what a NIM is, because the acronym hides something simple. It is a Docker container with three things inside. A model, here the reasoner tower of a Cosmos 3 checkpoint. An optimised inference server, doing batching, paged attention and FP8 kernels. And an HTTP API in front of both, which is the same shape as OpenAI's chat API.

That third point is what matters today. OpenAI compatible means the server accepts the same JSON body that OpenAI's service accepts and answers with the same JSON shape, so the standard OpenAI Python client talks to it unmodified. No request leaves your machine. That library is a client for a wire protocol, not a connection to a company. Your code is decoupled from whatever serves the model.

The convenience has a price. The server is a separate process, in a separate container, with its own filesystem and its own claim on your GPU. All three will bite you within the hour. One warning before we start. Two containers exist for Cosmos 3 and people mix them up. This course uses the Reasoner, which reads pixels and writes text. There is also a Generator container, whose VRAM floor for Nano is about seventy-nine gibibytes, your whole H100.

## Two credentials that fail differently

There are two credentials in play, consumed at different moments by different processes.

The first belongs to the Docker daemon on your host and is used at pull time. It proves you may download the image layers from the NVIDIA registry. You establish it once with a Docker login, and Docker stores the result in its config or your keychain.

The second belongs to the process inside the running container and is used at container start. It proves the NIM may download model profiles from NGC. It is a live environment variable that must be visible inside the container.

Getting only the first right produces a container that pulls fine and then sits there failing to fetch weights. Getting only the second right produces an authorisation failure at pull time, before the container exists. They fail at different moments, which is how you tell them apart.

Never print, echo, log or paste the key. The helper passes it to Docker by name, with no value attached, so Docker copies it from the current environment. The key never appears in this process's arguments, so it is not in the process table, your shell history or a traceback.

## Why eight plus thirty-two is the wrong sum

You have one eighty gigabyte card. The Reasoner's FP8 Nano weights are roughly eight gigabytes. Nano generation is documented at thirty-two. Eight plus thirty-two is forty, comfortably under eighty, so there is no problem. Except there is, and the reason is the most useful thing in this lesson.

A modern inference server does not allocate memory per request. At startup it takes a large block of whatever VRAM is free and keeps it for the life of the process, as a pool for the key value cache. That cache holds the attention keys and values for every token in every in-flight request. A vision language model turns each sampled frame into hundreds of image tokens, so one request over a ten second clip can be tens of thousands of tokens. The server reserves that space up front so it can promise to admit a long request later.

The consequence is blunt. The container's resting footprint is not its weight footprint. On an idle eighty gigabyte card it settles far above eight gigabytes. Nothing is leaking. That is the design.

Before you measure it, check the card is actually empty. If several gigabytes are in use and no container is running, you have a leftover process, usually a Python kernel from an earlier lesson. Kill it now, or every VRAM number for the rest of the lesson is wrong.

The notebook has you predict two numbers before anything starts. How many gigabytes will be in use once the container is ready and idle, and how many will be free. Commit to actual numbers, not a range. Then it measures, attributing memory per container by matching host process identifiers against the driver's list of compute applications. Then it runs a cheap admission check, doing the arithmetic the CUDA allocator would do. Free VRAM exceeding the documented requirement does not promise a run completes, but it reliably tells you when a run cannot start. It is a veto, not a green light.

So, two strategies. Take turns, which is the course default. Stop the container, generate, start it again. Neither side is compromised, because each gets the whole card in turn. The cost is a cold start on every switch, which after the first pull is a model load, not a download. Or cap the container, so both stay resident. What capping costs you is exactly one thing, and it is cache. A capped container has less room for long contexts.

Now the honest part. The environment variable that caps a NIM's VRAM claim has had several names across NIM families and releases, and this course was written without a live container of this version to interrogate. The helper holds a plausible guess, not a verified fact, and says so. That is tolerable rather than sloppy, because the output is directly observable. Set the flag, start the container, read the held VRAM. If the number did not move, the name is wrong.

## Sending pixels over HTTP

Ask the model's identity rather than assuming it. The served name depends on which profile the container started with, and sending the wrong one gives a not found error that reads like a server fault.

Two details of the request are worth stopping on. The chat schema lets message content be either a plain string or a list of content parts, and multimodal requests use the list form. The media part comes before the text part, because that is what the chat templates in this model family expect. Putting the question first works often enough to hide the problem, then fails on the one prompt where ordering matters. And the media is inlined as a base64 data URL, not a path. The container cannot open a file on your filesystem, and worse than failing, a path that resolves inside it gives you a confident answer about a different file.

A word on precision. BF16 gives each parameter sixteen bits, so eight billion parameters is sixteen gigabytes. FP8 gives each eight bits, so the same model is eight gigabytes, and Hopper executes FP8 matrix multiplies natively.

For your machine the numbers are these. The image is tagged one point seven, about eight gigabytes compressed, and it needs an NGC API key. On one H100 you serve the eight billion active Nano reasoner at FP8 using about twenty gigabytes of disk, and you can serve the thirty-two billion active Super reasoner at FP8 too. Minimum compute capability is eight point zero for BF16 and eight point nine for FP8, and your H100 is nine point zero. Carry the asymmetry forward, because people state it backwards. What does not fit on one H100 is Super generation, at about a hundred and twenty-eight gigabytes. Not Super reasoning.

## When the container will not start

Four failures, and one instrument that matters more than any theory. Read the container logs first. A container that failed almost always said why, and the message is in its logs and nowhere else. The notebook prints the logs of a healthy container while nothing is wrong, so you know what normal looks like.

The first cause is a bad or absent registry credential. The symptom arrives in seconds, before any container exists, as pull access denied. That is credential number one, and since the container never started, this is not about the key being invisible inside it. Reproduce it in a terminal with a plain pull, log in again, then verify.

The second is no GPU passthrough. Either Docker fails instantly, saying it could not select a device driver with GPU capabilities, or, in the nastier variant, the container starts, runs for a minute, and dies with a CUDA initialisation error whose logs mention CUDA and not Docker, so people go looking for a driver problem. Passthrough needs the NVIDIA Container Toolkit, a separate package from the driver, and the driver working on the host tells you nothing about it. The diagnostic is one line, a throwaway container that lists GPUs. If it errors, the toolkit is the problem and the NIM is innocent. Install it, configure the Docker runtime, then restart the Docker daemon. The restart is not optional.

The third is a port already bound. On a machine that has run this course before, the likely culprit is a previous container that was stopped but not removed, because a stopped container keeps its name and its port reservation. That is why the helper removes rather than stops.

The fourth arrives late, wearing a disguise. You run out of disk part way through the profile download. The container runs for twenty minutes and either exits saying no space left on device, or, worse, exits with a loading error about a truncated checkpoint. On the next start it finds a file of the right name and the wrong size and reports a model failure rather than a disk failure. So free space, and then delete the partial cache entry. Skipping that second step turns a disk problem into a model problem.

There is a fifth case that is not a start failure at all. The container is up but never becomes ready. Two health endpoints exist and they answer different questions. Live asks whether the process is alive, and becomes true in seconds. Ready asks whether it will answer a request, and becomes true only once the weights are loaded, which is minutes, or tens of minutes on a first run. Poll the wrong one and you send a request into a server that is still loading, get a reset connection, and conclude it is broken rather than busy. When ready never arrives, look for one of three things. Still downloading, which pairs with zero GPU utilisation. Out of memory at load. Or a rising restart count.

Three things to carry away. A NIM is a model, a server and an OpenAI compatible HTTP API in one container, and the third part is why your code does not care what is running. The server reserves its cache pool from free VRAM at startup and holds it for the life of the container, so take turns or cap it. And when it will not start, read the logs, then check credentials, passthrough, port and disk, in that order.

Back at the machine, the notebook has you measure the resting footprint yourself and write the plan file with a justification in your own words. Leave the container running, because lessons three, four and five need it. Next, lesson three, captioning video and turning free text into structured records.
