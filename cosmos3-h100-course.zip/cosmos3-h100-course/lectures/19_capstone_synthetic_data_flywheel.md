---
lesson: "19"
title: "Capstone: the synthetic data flywheel"
slug: "19_capstone_synthetic_data_flywheel"
duration_estimate: "13 min"
words: 1950
---

# Lesson 19 — Capstone: the synthetic data flywheel

Here is the situation the capstone puts you in. A robotics team has a handful of real recordings. Call it a dozen clips of one manipulator doing one task in one kitchen. They want to train on ten times that, across more lighting conditions, camera placements and object arrangements than they can physically stage. Collecting the extra footage means weeks of robot time. They would like a model to do it instead.

That is a reasonable thing to want and an easy thing to do badly. The failure mode is not that the videos look wrong. It is a training set full of physically impossible clips that nobody looked at, because a generation script exited zero four hundred times and everybody assumed. Cosmos 3 can close this loop, because one checkpoint holds both a reasoner that can describe and judge a clip and a generator that can produce one. So the pipeline has six stages, each with a contract. Reason over the source clips, plan variations, generate them, gate them automatically, judge the survivors for plausibility, then measure and report.

Every one of those steps is something you have done once already. The capstone is those steps holding while you are not watching. And running it is not enough to pass. A pipeline that produced twenty clips with no measurement scores below one that produced four with a measured cost and a defended threshold. It runs in two profiles. A small one, three source clips and around nine variants on Edge, sized for about an hour. And a full one, six clips and twenty-four variants on Nano, about thirty-five gigabytes of download. The small profile is where you find every bug.

## What makes a variation useful

This is the part with no correct answer, and the part weighted most heavily after measurement. Generating something different is trivial. Change the seed and you get a different clip. Change the prompt to a spaceship and you get something very different indeed. Neither helps. The first varies nothing the deployed model must generalise over. The second varies so much that the clip is no longer about the task.

So here is the working definition. A variation is useful when it changes something the downstream model should be invariant to, while preserving everything the model must still get right. Lighting at six in the morning versus noon. A cluttered bench versus a clear one. The manipulator is still doing the thing, because if the variation changes what is happening then it is a different dataset rather than an augmentation of this one. It has to be physically possible, which is what screening checks. And it must not be a near-duplicate of something you already have, because ten clips at slightly warmer light are one clip with nine copies.

Your job is to turn that into something a machine can compute, defend the choice, and then say how a lazy generator could satisfy your criterion without doing anything useful. That last part is the difference between good and excellent. The criterion also has to be computable from the plans alone, before any pixels exist.

## Six contracts and one ledger

Three constraints shape the engineering, and none is about model quality. The two models cannot both hold the card, because the reasoner container pre-allocates its cache against whatever memory is free when it starts, which on an idle eighty gigabyte H100 is most of it. Process startup is not free and does not scale with job size, so at the small profile the checkpoint load is most of the cost. And a screening stage that costs more than the thing it screens is a bad screening stage.

That first constraint decides the stage order, and it is not the order the data flow suggests. Reason every clip, then generate every batch, then validate every clip. Clip by clip would be more natural and would let you abandon a bad clip early. It is rejected because it would mean starting and stopping the container once per clip. You are trading control flow for a memory schedule, and saying so is one of the decisions you defend.

Each stage is one function with a documented signature, and the contract is the interface, not the implementation. Two rules apply to all six. A stage must not catch its own exceptions, because the runner catches, times and classifies them, and that classification is graded. And a stage must be deterministic, so two runs produce the same variant identifiers.

That second rule is what makes the run survivable. The ledger is an append-only JSONL keyed on a field you choose, and every append is flushed and synced to disk before the call returns, so an abrupt kill cannot lose a completed item. Resume needs no special code path. The pipeline loops over the work it wants, asks the ledger what it already has, and does the difference. The bar is that killing the kernel mid-run loses at most one completed variant. All of that collapses if your identifiers are unstable. Build one from a random value or from the clock and a resumed run matches nothing, and you silently redo everything you already paid for.

The manifest is a ledger and also a deliverable. One record per attempted variant, with provenance, the exact prompt, the seed and a verdict, written the moment the variant's fate is known, including when its fate is that the generator ran out of memory. The most common way people lose marks is merging rejected and failed into one bucket. Nine of twenty did not work is unactionable. It could mean your threshold is strict, which is intentional, or your generator is crashing.

## Predict the cost, then measure it

Before you trust the judge on generated footage, ask it about the real footage. If it calls genuine video of a real robot implausible, your threshold or your question is wrong, and every acceptance rate you report afterwards measures your prompt rather than your generator. Use the same question in the reasoning stage and the screening stage, or the baseline calibrates nothing.

Then predict the cost per accepted clip before the run and reconcile it afterwards. A prediction you committed to is the only way to find out that your model of where the time goes is wrong. Seconds per variant is a fixed launch overhead divided by batch size, plus sampling work divided by your measured throughput. Seconds per accepted clip is that, plus the judge's time, divided by the acceptance rate. That rate is the interesting term, because you cannot measure it beforehand and it sits in the denominator. Guessing zero point six when the truth is zero point four inflates the real cost by half again. The prediction is committed to the ledger once, with a timestamp, and re-running the cell does not overwrite it.

Four things get measured. Wall clock per stage, from a clock that refuses to nest, because nested timing double-counts seconds until the totals exceed the wall clock. Peak VRAM, device-wide, which is the one people get wrong. Generation runs in a separate process and the reasoner in a container, so this kernel's allocator counters see nothing that matters. Ask the driver. The bar is seventy-five gigabytes rather than eighty, because a run peaking at seventy-nine has not succeeded, it has simply not failed yet. Third, switching overhead, as an absolute number and a fraction. Fourth, cost per accepted clip.

Batching is the one knob whose effect you can predict and then check. One generation call costs a fixed amount, spawning a process and loading the checkpoint, plus per-sample sampling, so batching amortises the fixed part and most of the benefit is in the first doubling. But a crash takes the whole batch, and expected loss per crash grows linearly with batch size. At the small profile batching is transformative. At full resolution the launch is a few percent of the cost, so it buys almost nothing and still costs you the batch.

## The four failures you must survive

The idea underneath all four is that an error class is a routing decision. Retrying an out-of-memory failure unchanged gets you a second one and a wasted checkpoint load. Retrying a malformed reply usually works, because sampling is stochastic. Restarting a dead container and retrying works. Retrying a bug in your own code gets you the same bug at a slower rate.

Failure one, a rejected clip that is actually fine. The video checker rejects something, you watch it, and it looks like a video. It is not asking whether the clip is good. It asks whether consecutive frames differ enough, because a freeze looks like a still image, and not too much, because noise looks like maximum change. A slow, static-camera clip of a manipulator sits near that lower bound. Look at the metrics before you argue with the verdict, then either raise the threshold with a stated argument or accept a true rejection. Quietly loosening it makes your acceptance rate a function of an undocumented constant.

Failure two, an out-of-memory error in the generator. Either the job is too big for the tier, or the container was still resident when generation started, or a previous process never exited. Look at the card directly rather than at this kernel. And note which rungs of the ladder do not exist for you. Raising the shard degree and raising the context-parallel degree both need more GPUs. On one card you have expandable segments, activation checkpointing, a smaller job, and, for training only, LoRA.

Failure three, the container died mid-run and every clip now raises a connection error. The status helper reports from four independent sources, docker's view, the health endpoint, the model list and the driver. Container running but not ready means loading. Container gone but memory still high means something else. This is a service failure, so it is retryable, but only after you fix the service. That is what the retry hook is for, because it is where the state of the world changes.

Failure four, a malformed model response. The parser scans for the first balanced brace pair rather than using a greedy regular expression, so it already handles code fences, leading prose, trailing prose and thinking blocks. The one case it cannot handle is a reply containing no JSON at all, which is a prompt failure wearing a parser's clothing. Print the raw text, always. There is also a fifth failure, the one not on the list, and you will hit it. Work it the same way and classify it. That one is worth more than the four supplied, because you had to notice it.

Three things to carry away. The stage order is a memory schedule, not a data-flow diagram, and switching between models is a cost you measure rather than absorb. Rejections and failures are different numbers, one being your policy working and the other your pipeline broken. And a prediction is only a prediction if you wrote it down first, then reconciled it by naming the dominant error term.

That is the course. You can serve a reasoner and a generator on one H100 without them fighting. You can condition generation on images, control videos and actions. You can measure any of it honestly, attempt a fine-tune on hardware nobody documented it for, evaluate the result without a harness, and assemble all of it into a pipeline that survives a long unattended run. The last skill is the one that transfers furthest, and it is not about Cosmos at all. An artefact you produced is not evidence until you have measured it, screened it, and written down what it does not show.
