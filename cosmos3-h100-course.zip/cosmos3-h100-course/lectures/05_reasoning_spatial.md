---
lesson: "05"
title: "Spatial grounding"
slug: "05_reasoning_spatial"
duration_estimate: "13 min"
words: 1902
---

# Lesson 05 — Spatial grounding

Lesson three asked what is there. Lesson four asked what to do. This one asks where, and it is the question everything downstream depends on, because an action without coordinates is not an action. A plan that says pick up the red bottle is a sentence. A plan that says the red bottle is in this rectangle is something a gripper can use.

By the end of this lesson you will be able to ask Cosmos 3 for a bounding box, parse what comes back, and convert it to pixels at the correct scale. You will be able to look at a wrong overlay and name the bug from the shape of the error, without reading any code. You will build an image with numbered regions drawn on it, get captions keyed to those numbers, and verify that the keying is actually correct rather than assuming it. You will ask for a gripper trajectory and overlay it.

Budget about ninety minutes. There are no downloads. One warning before we start: this is the last lesson that uses the Reasoner NIM, and it shuts the NIM down at the end so module two can have the whole card. If you skip that step, the first cell of lesson six will run out of memory with an error message that says nothing whatsoever about containers.

## The first idea: the numbers are not pixels

Ask Cosmos 3 where something is and you get back a small piece of JSON with four numbers and a label. The four numbers are left, top, right, bottom. The origin is the top left corner. X increases to the right and y increases downwards, which is the image convention and the opposite of the maths convention on the vertical axis.

Now the part that costs people an afternoon. Those numbers are not pixels. They are normalised to a fixed grid that runs from zero to one thousand. And they are normalised per axis, independently. X is divided by the image width, y is divided by the image height, and each result is then scaled onto that zero to one thousand range.

Why normalise at all? Because the model does not know your image's dimensions and should not have to. A vision encoder resizes and tiles its input long before the transformer sees anything, so whatever pixel grid you started with is already gone. A fixed, dimensionless range means the same output is meaningful for a small frame and for a 4K still, and the client, which does know the dimensions, multiplies back.

To get pixels you multiply by the image width and divide by one thousand for the horizontal numbers, and multiply by the image height and divide by one thousand for the vertical ones. Two different divisors. There is no single scale factor. That catches people who already know about normalised coordinates, because a box that is square on the normalised grid is not square in pixels unless the image itself is square. The course's helper takes the extent as an argument for exactly that reason.

The notebook has you write the conversion out by hand once, before you use the library function, so the arithmetic is yours. Then it has you do something more interesting. Resize the image to half its width and half its height, send the smaller copy with an identical prompt and seed, and compare. Predict first. Do the numbers halve, stay roughly the same, or change unpredictably? They should stay roughly the same, because that is the entire point of normalising. But they will not be identical. The smaller image genuinely carries less information, the vision encoder tiles it differently, and the model's estimate shifts. Quantify that shift and ask whether it would matter for a grasp. And if the numbers actually halved, you have found something reportable, because that would mean your server is returning pixels.

## The debugging lab: every box in the corner

Here is the symptom. The model's JSON looks entirely reasonable. The drawing code runs without an error. And every box sits crushed into the upper left corner of the picture, roughly the right shape but plainly not on the objects.

The hypothesis is the obvious one. Someone treated the zero to one thousand numbers as pixels. But it is worth being precise about what that looks like, because the shape of the error identifies the cause faster than reading the code does.

Take an image one thousand two hundred and eighty pixels wide and seven hundred and twenty tall. One thousand over twelve hundred and eighty is about seventy-eight percent, so every box appears at roughly seventy-eight percent of its correct horizontal extent. One thousand over seven hundred and twenty is about one hundred and thirty-nine percent, so every box is stretched vertically by that much. The result is squashed sideways, stretched downwards, and clipped at the bottom. On a small square image most boxes land partly or wholly off the right and bottom edges, so you see fragments or nothing at all. And on an image that happens to be one thousand pixels square, the bug produces exactly correct output. That is how it reaches production.

The diagnostic is not squinting at the picture. It is arithmetic, and two questions settle it. First, is every returned coordinate at or below one thousand on an image that is wider than one thousand pixels? If so, the coordinates are normalised and something downstream is failing to convert them. Second, does the ratio of a drawn box's width to the image width equal the ratio of the raw number to one thousand? If so, the drawing code used the raw number directly. The notebook answers both mechanically, and that check belongs in a test suite, not in your head.

The repair is one line of arithmetic. Divide by one thousand and multiply by the extent of the matching axis. Width for the horizontal numbers, height for the vertical ones.

The verification is the part I want you to remember, because it is not the obvious one. Two checks that a program can run without any ground truth. The first is that every drawn box lies inside the image bounds. The second is that the box centres land on distinguishably different parts of the image. That second check is the one that catches this bug, because a pile of boxes all crammed into one corner passes the bounds check quite happily. Verify that overlays are inside the image, non-degenerate, and spread out. Spread is the signal.

## Marking the image and asking about the numbers

Grounding asks the model where something is. Set-of-Mark prompting inverts that. You draw numbered regions on the image yourself, then ask the model to describe each marked subject, and it returns a subject identifier for each caption that refers back to your number.

Why bother, when you could just ask about the robot arm on the left? Because a referring expression is ambiguous and a number is not. With two arms in frame, the left arm depends on whose left. Region two does not. Marking makes the output addressable. Every caption is bound to a region whose coordinates you already have, so you can join the model's description to your own data.

In a full pipeline the regions would come from a segmentation model. Here you place them by hand, which keeps the numbering stable. There is an upstream trap that the course fixes for you. The source material hard-coded the marks as pixel boxes tuned to one asset at one size. Point the same code at any other image and every mark lands somewhere wrong, silently, because a rectangle drawn in the wrong place still draws. The course converts those pixel boxes onto the zero to one thousand grid once, the same conversion you just did for the model's output but running in the opposite direction, and then the marks follow the image at any size.

The last step is the one that makes Set-of-Mark trustworthy rather than decorative. Check the keying. If the model returns four captions numbered one to four but in a different order from your marks, or invents a fifth region, the binding is broken and every join you make afterwards is silently wrong. Same count, wrong keys, and nothing complains.

## A trajectory is not yet an action

The last probe goes beyond what and where to how to move. You give the model a manipulation task and ask it for the two-dimensional path the end effector should follow, returned as ordered waypoints. Same zero to one thousand grid, one point per waypoint, with a label.

The drawing helper numbers each waypoint and ramps the colour from green at the start to red at the end, so direction is legible without reading numbers. That matters more than it sounds, because a path that looks wrong is very often a right path traversed backwards, and you cannot tell that from an undirected line.

There is a parsing trap here worth the whole section. The response contains a think block, and the reasoning inside it very often contains a draft of the JSON. Parse the first JSON blob in the raw text and you get the draft. It is plausible, it is wrong, and no error is raised. So split on the closing think tag before you parse anything. The course's parser does that by default, and it also strips code fences, tolerates prose on either side of the value, and scans for the first balanced bracket pair rather than using a greedy regular expression, which would swallow everything between two separate arrays.

Then the notebook sweeps temperature and measures two things that are easy to conflate. Temperature changes the path the model proposes, and it changes the reliability of the output format. A rise in parse failures is not a statement about trajectory quality. The source material claimed a moderate temperature encourages a smooth exploratory path. Measure it rather than inheriting it.

And read the overlays, not only the numbers, because smoothness is a property and not a score. A straight line from one corner of the image to the other is perfectly smooth and touches nothing. Ask the harder questions instead. Does the path start near the gripper, pass through the object, and end where the task said to put it.

One closing distinction. This is a pixel-space plan. It says where the gripper should appear to be in this camera's image. It says nothing about depth, nothing about gripper orientation, and nothing in metres. Much later, the mode named wam, spelled w, a, m, predicts a ten-dimensional action in the robot's own frame: three translation deltas, a six-dimensional rotation, and one gripper channel. Both get called trajectories. They are different objects, and converting between them needs camera intrinsics, extrinsics and a depth estimate, none of which is in this JSON.

Three things to keep. Coordinates come back on a normalised grid from zero to one thousand, per axis, with two different divisors. The classic bug looks correct on a square image and survives review, so verify overlays for spread and not only for bounds. And split on the closing think tag before parsing, because the draft in the reasoning will parse perfectly and be wrong.

Module one is finished. Lesson six turns descriptions back into footage, and it needs the whole card, which you have just handed back.
