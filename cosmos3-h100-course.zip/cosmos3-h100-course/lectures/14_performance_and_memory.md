---
lesson: "14"
title: "Measuring properly"
slug: "14_performance_and_memory"
duration_estimate: "13 min"
words: 1945
---

# Lesson 14 — Measuring properly

Here is the claim this lesson exists to make good on. Most reported speedups in machine learning notebooks are measurement artefacts. Not fraud, not even carelessness. Three specific mistakes that everyone makes the first time, and that produce numbers which are confidently and spectacularly wrong.

You are going to make all three deliberately, watch the absurd results they produce, and then never make them again by accident. By the end you will be able to produce a timing figure you would defend in a design review, with a median, a spread and a stated methodology. You will be able to account for the gap between three different memory readings for the same workload. And you will be able to profile a process you are not inside, which matters because the Cosmos 3 generator runs out of process.

Almost everything runs on synthetic workloads that finish in seconds. What transfers is how to measure. What does not transfer is how long anything takes.

## Three ways a benchmark lies

Start from zero, because this is the root of nearly everything that follows. When you multiply two matrices on a CPU, Python does the multiplication and then returns. The work is finished by the time the next line runs. Time either side of it and you have timed the work.

A GPU does not work like that. Your Python process, called the host, and the GPU, called the device, are separate processors connected by a queue. A matrix multiply on CUDA tensors does not multiply anything. It writes a kernel launch into the queue and returns in a few microseconds. The GPU picks the work up whenever it gets to it, and it may still be running long after your Python code has moved on.

So if you start a timer, launch the work and stop the timer, you have measured the cost of asking, not the cost of doing. The difference is often three orders of magnitude. That is the first lie, and the fix is one line. Synchronise before you start the clock and again before you stop it. Synchronising blocks the host until the queue is empty. It costs microseconds, and it is the difference between a number and a fiction.

What makes this lie dangerous is that it is directional. A benchmark with no synchronisation systematically favours whichever side queues more work before something forces a sync. And plenty of ordinary calls force a sync without announcing it. Reading a scalar out of a tensor does. Copying to the host does. Printing a tensor does, because printing has to read the values. If your candidate avoids a scalar read that your baseline has, you will measure a large speedup that is entirely the missing scalar read. That is how a change which made nothing faster gets merged.

The second lie is the first call. The first time a process touches CUDA it pays for a pile of one-off setup that never happens again. The driver builds a CUDA context, which also permanently costs a few hundred megabytes of VRAM, and is why the card shows a process using memory before it has allocated a single tensor. The linear algebra and convolution libraries pick between many kernels for the same operation, sometimes by running several and keeping the fastest, which is a real autotune with a real cost. And the allocator grows its pool by calling into the driver, which is slow and synchronising.

So warm up outside the timed region. One warm-up call is usually enough for a fixed shape. It is not enough if your workload has several shapes, because each shape autotunes separately. The notebook measures the fresh-process cost in a subprocess, because your kernel created its context long ago and cannot un-create it.

The third lie is subtler and it is the one that survives review. You warm up, you synchronise, you run it once, and you report a single number. But an H100 in a warm rack under sustained load throttles. Your machine has other processes. What you have is one sample from a distribution, presented as a constant.

Report a median and an inter-quartile range. Use the median rather than the mean because the noise here is one-sided. Nothing makes a run finish faster than the hardware allows, but plenty of things make one run slow. A clock excursion, another process waking up, a page fault. A mean absorbs all of those. A median ignores them unless they happen to more than half your samples.

There is a fourth mistake that is not statistical at all. Reading thirty-five gigabytes of weights off disk is not inference. Loading the Nano checkpoint means reading those bytes from storage, deserialising them and copying them to the device, and none of that scales with your prompt, your resolution or your step count. Report the sum as inference time and every conclusion is wrong. A second generation looks as expensive as the first. Doubling the step count looks sublinear, because the fixed cost dilutes it. A model that loads faster looks like a model that generates faster.

## Asking the device what time it is

Wall clock timing with synchronisation works, but it measures a host-side interval that contains the device work. It includes launch overhead, the synchronisation itself, and any host hiccup in between. For a run of seconds that is irrelevant. For a kernel of two hundred microseconds it is most of your measurement.

CUDA events are markers you push into the stream. The device timestamps them as it reaches them, and you ask for the device-side interval between two of them. Two properties matter. You still need one synchronise before reading the result, but only one per measurement batch rather than one per iteration. And events measure device time only. If your host is the bottleneck, events will look fast while your wall clock crawls, and the events are not lying. They are answering a different question.

That is the rule. Wall clock answers how long did my user wait. Events answer how long did the device spend on this kernel. Report wall clock for a generation run, events when comparing two kernels. And note that heavy instrumentation changes the thing you are measuring, because a host synchronise per step serialises the host and the device.

## What the memory numbers actually mean

Three tools report three different numbers for the same workload, and all three are correct. The allocated figure is bytes held by live tensors right now. The reserved figure is bytes PyTorch has taken from the driver and is keeping in its own pool. And the device-level tool reports what the whole card is holding, which is every process's reserved pool plus each process's CUDA context.

Nearly everyone meets the gap between the first two in a bug report titled, PyTorch is leaking memory. It is not a leak. It is cache. Allocating and freeing directly from the driver takes a driver lock and synchronises the device, and doing that for every intermediate tensor would cost more than the compute. So PyTorch reserves large segments and sub-allocates your tensors out of them. When you delete a tensor, the block is marked free inside the pool and kept for reuse. The reserved figure ratchets up and does not come back down on its own. That is the design working.

Two consequences follow. The gap becomes a problem only when it is fragmented, meaning many small free blocks and none large enough for the next request. That is the error saying it tried to allocate two gigabytes while several gigabytes are free. Emptying the cache hands the pool back, but throws away the cache you paid for, so use it to make a measurement readable, not as a fix. And memory held by this process is not available to another, whatever counter it shows up in.

Peak memory needs its own discipline. The peak figure is a high-water mark since the process started, or since you last reset it. Reading it without resetting tells you about the largest thing your kernel ever did, which is almost never the question. Reset, run the region you care about, read.

One more allocator fact. The setting that switches it to expandable segments is the first rung of the out-of-memory ladder, it is free, and it must be set before the first CUDA allocation, because the allocator reads it exactly once. Setting it partway through a session does nothing at all, silently.

Finally, out-of-process measurement. The Cosmos 3 generator runs as a separate process, so every counter you just learned is blind to it. What you can still see is the card. Poll it on a background thread while the child runs, record a baseline, take the peak. Be clear about the limitation. That measures the device, not the process, and anything else resident is in your number.

## The lab: a speedup that was not there

The lab is a cell a colleague sends you. It compares a baseline matrix multiply in float thirty-two against an optimised one in b-float sixteen, and reports a speedup so large it would be a research result if it were real. They are pleased. You are suspicious. Your job is not to be suspicious in general. It is to find the three specific bugs, one at a time, and report the real number, which may still be a speedup worth having.

Bug one. The clock stops before the work does. The b-float sixteen branch has no synchronise before the timer stops. The float thirty-two branch does. So one side is timing execution and the other is timing launches, and the comparison is meaningless before anything else is considered.

Bug two. One side is cold. That float thirty-two multiply is the first at that shape in this process, so it pays algorithm selection and an allocator segment. The b-float sixteen side has been warm since the top of the notebook. Even with the synchronisation fixed, this puts a first call against a steady state.

Bug three. The two sides do different amounts of work. The candidate runs many multiplies, the baseline runs one, and the totals are divided as though they were comparable.

Three bugs, all pointing the same way. Multiply them together and a difference that is real but modest becomes a headline.

The one diagnostic that settles it is to fix them one at a time and watch the reported speedup fall. Changing all three at once tells you the answer but not which bug was worth how much, and the second thing is what stops you repeating the mistake.

The repair is to rebuild the comparison properly. Warm up, synchronise, repeat, report a median and a spread. Whatever ratio survives is real and worth knowing, because reduced precision on Hopper uses different tensor core paths. The honest ratio and the claimed one are not in the same league, and the gap was three bugs, not dishonesty.

The general rule that falls out of it is the thing to keep. A benchmark comparing two things must differ in exactly one respect. Not one setting. One respect. Same warm-up, same iteration count, same synchronisation, same shapes, same allocator state. Every additional difference is a place for a factor to hide.

Three things to carry forward. Synchronise, warm up, and report a distribution. Reserved is not allocated, and neither is what the card reports. And a subprocess is invisible to your counters, so sample the device and say so.

The next lesson spends this. Now that you can tell a real speedup from an artefact, you get to go looking for real ones.
