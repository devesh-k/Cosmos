# Audio lectures

Twenty narration scripts, one per lesson notebook. They are written to be
**heard**, not read: no bullet lists, no tables, no code, no "as you can see".
Numbers are spelled the way a person says them, so a speech engine reads
"about thirty-five gigabytes" rather than "34.9 GB".

The idea is that you listen to a lecture away from the machine — walking,
commuting, on a plane — and arrive at the notebook already knowing what it is
for and where the traps are. The lecture teaches the *ideas*. The notebook is
where you do the work. Neither replaces the other, and the lecture never asks
you to type anything.

## Start here: listen with no install

Open **[`read-aloud/index.html`](read-aloud/index.html)** in Microsoft Edge,
click a lecture, and press **Ctrl + Shift + U**. Edge narrates it with its
neural voices. Under *Voice options* pick one marked **Natural** — Andrew,
Aria, Guy or Jenny — and Edge remembers.

Those pages are generated from the scripts in this folder and are built
specifically for narration: no preamble before the first sentence, navigation
placed after a spoken end marker, and the text rewritten so the narrator says
"H one hundred" rather than spelling out "H100". Each ends with a spoken recap
of its key terms, and the index remembers which you have finished.
[`read-aloud/all.html`](read-aloud/all.html) plays all twenty in one go.

**If you want MP3 files** rather than streaming — for a plane or a phone —
`pip install edge-tts` then `python scripts/make_lecture_audio.py`, about ten
minutes. Full walkthrough of both routes, with the tradeoffs stated plainly, in
[WINDOWS_AUDIO.md](WINDOWS_AUDIO.md).

---

## Total listening time

**4 hours 22 minutes** across twenty lectures, at a normal 150 words per
minute. Most people end up at 1.25x or 1.5x for material like this, which
brings it to **3 hours 30 minutes** or **2 hours 55 minutes**. The browser
player written next to the audio has a speed control.

| # | Lecture | Words | Time |
|---|---|---:|---:|
| 00 | What machine am I actually on? | 1,892 | 12:56 |
| 01 | What Cosmos 3 is, and your first generated image | 1,921 | 13:07 |
| 02 | Serving the reasoner on one GPU | 1,918 | 13:06 |
| 03 | Captioning and structured scene records | 1,930 | 13:12 |
| 04 | Embodied reasoning | 1,871 | 12:46 |
| 05 | Spatial grounding | 1,902 | 12:59 |
| 06 | Generation fundamentals | 1,924 | 13:08 |
| 07 | Image-conditioned generation | 1,919 | 13:07 |
| 08 | Control-conditioned generation and augmentation | 1,785 | 12:12 |
| 09 | Audio-visual generation and the guardrail | 1,926 | 13:10 |
| 10 | Action as a modality, and forward dynamics | 1,933 | 13:13 |
| 11 | Inverse dynamics and pose mathematics | 1,940 | 13:16 |
| 12 | The World Action Model | 1,901 | 13:00 |
| 13 | Closed-loop control | 1,943 | 13:16 |
| 14 | Measuring properly | 1,941 | 13:17 |
| 15 | Optimisation, with the receipts | 1,942 | 13:16 |
| 16 | What post-training actually changes | 1,925 | 13:07 |
| 17 | Shrinking an 8-GPU recipe to one | 1,921 | 13:09 |
| 18 | Evaluating a post-trained model | 1,941 | 13:14 |
| 19 | Capstone: the synthetic data flywheel | 1,953 | 13:17 |
| | **Total** | **38,328** | **4:21:58** |

---

## Suggested order

**Straight through, 00 to 19.** Each lecture ends by saying what the next one
does, and several of them depend on a mental model built earlier. That is the
default and it is the right choice for a first pass.

If you want to interleave listening with lab work, these are the natural
groupings.

**Module 0 — the machine (00, 01).** Listen to both before you touch the
notebooks. Lesson 00 is about knowing what hardware you actually have, and 01
gives you the whole Cosmos 3 mental model in one sitting. Everything later
assumes both.

**Module 1 — reasoning (02, 03, 04, 05).** Lesson 02 is the one to hear before
you run anything, because it explains why a NIM and a generation job fight over
the same 80 GB card. 03 through 05 are each self-contained enough to listen to
on the way to running them.

**Module 2 — generation (06, 07, 08, 09).** Lesson 06 is the important one.
It builds diffusion from nothing, and if you understand it, 07 through 09 are
mostly consequences. Listen to 06 twice if the first pass goes by too fast.

**Module 3 — action (10, 11, 12, 13).** These build on each other tightly.
Lesson 11 does real mathematics out loud, four-by-four transforms and the
six-number rotation representation, and it is the one lecture where you might
want a pen afterwards. 13 is the payoff.

**Module 4 — performance (14, 15).** Both are about not lying to yourself with
a benchmark. They pair well and can be listened to back to back.

**Module 5 — post-training and evaluation (16, 17, 18).** Lesson 16 derives the
memory bill for fine-tuning from first principles, which is the single most
useful thing in the module and works perfectly as audio.

**Capstone (19).** Listen to this before you start the capstone, not during.
It is the brief.

### If you only have an hour

01, 06, 12, 16. That is the mental model, diffusion, the world action model,
and the memory arithmetic. Those four carry most of the conceptual weight of
the course.

---

## What is in a script

Each file has a small YAML header (lesson number, title, slug, duration, word
count) which the audio pipeline strips and does not speak. Then an H1 title,
then prose. There are at most four `##` section headings per script, and each
one is written as a speakable sentence because the pipeline reads them aloud
with a longer pause in front.

Every lecture:

- opens with why the lesson matters and what you will be able to do
- signposts constantly, because a listener cannot scroll back
- tells the notebook's debugging lab as a story: symptom, hypothesis, the one
  diagnostic that settles it, then the repair
- points at the notebook for the doing, and never dictates code
- closes with the two or three things to remember, and what comes next

The corrections that matter are baked into every relevant script: `policy` is
now `wam`; only the guardrail repository is gated; transfer is `video2video`
plus a control-hint block, not a mode of its own; Edge is four billion
parameters, not two. `../assets/reference/COSMOS3_FACTS.md` is the authority
and the scripts do not contradict it.

---

## Generating the audio

Full walkthrough, including the no-install path and the offline path:
**[WINDOWS_AUDIO.md](WINDOWS_AUDIO.md)**.

The short version, from the course root:

```bash
pip install edge-tts
python scripts/make_lecture_audio.py
```

That writes `lectures/audio/NN_<slug>.mp3` for all twenty, plus a
`playlist.m3u` in course order and an `index.html` you can open in a browser.
About ten minutes, about 200 MB.

Useful flags:

```bash
python scripts/make_lecture_audio.py --self-test    # prove it works first
python scripts/make_lecture_audio.py --dry-run      # show the plan, write nothing
python scripts/make_lecture_audio.py --lesson 06    # rebuild one
python scripts/make_lecture_audio.py --list-voices  # pick a different narrator
python scripts/make_lecture_audio.py --backend kokoro   # fully offline, no network
```

It is resumable. A lesson whose audio is newer than its script is skipped, so
if a run is interrupted you re-run the same command and it picks up where it
stopped. `--force` rebuilds anyway.

**One thing to know about the default.** `edge-tts` uses Microsoft's neural
voices, which are free and sound close to a person reading. They are a network
service: the text of each chunk is sent to a Microsoft speech endpoint. These
scripts are not sensitive, but if you would rather nothing left the machine,
`--backend kokoro` runs an 82-million-parameter model locally and is fully
offline after a one-time download of about 350 MB.

On Windows with nothing installed at all:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\make_lecture_audio.ps1
```

That uses the SAPI voices already in Windows. It works, and it is robotic.
Read WINDOWS_AUDIO.md before spending four hours listening to it.

---

## Editing a script

Edit the markdown and re-run the generator. The changed lesson rebuilds and
the others are skipped. Keep to prose: the pipeline drops code blocks and
tables and warns you by name if it has to, and `--dry-run` shows you every one
of those warnings before you spend time on synthesis.
