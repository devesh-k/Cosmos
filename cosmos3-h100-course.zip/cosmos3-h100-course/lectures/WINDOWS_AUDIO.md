# Listening to the lectures on Windows

There are twenty lectures, about four and a half hours of narration. Two ways to
listen, and the first one needs nothing installed.

---

## Option A — Edge Read Aloud (recommended, zero install)

The pages are already built. Open this file:

```
lectures\read-aloud\index.html
```

Double-click it, or right-click → *Open with* → *Microsoft Edge*. Then:

1. Click any lecture.
2. Press **Ctrl + Shift + U**, or right-click the page and choose **Read aloud**.
3. In the toolbar that appears, open **Voice options** and pick a voice marked
   **Natural** — Andrew, Aria, Guy or Jenny. These are neural voices and they
   sound markedly better than the ones Edge selects by default. You only have to
   do this once; Edge remembers.

That is the whole setup. The toolbar gives you play, pause, skip and a speed
slider. Most people settle around 1.25x for this kind of material.

**Why these pages rather than the markdown.** Read Aloud narrates every word it
can see on a page, so anything decorative gets read to you in the same voice as
the lecture. These pages are built for that: they open on the first sentence of
the lecture with no preamble, and navigation sits after a spoken end marker, so
you hear the lecture and then "That is the end of lecture 03" and can stop.

The text has also been rewritten for the ear. "H100" is written "H one hundred",
"bf16" is "B F sixteen", "35 GB" is "35 gigabytes", and links are not read out
character by character. The markdown in this folder stays readable for the eye;
the rewriting happens only on the way to HTML.

### Listening straight through

`lectures\read-aloud\all.html` holds all twenty lectures on one page. Start Read
Aloud at the top and it plays the entire course unattended, which is the closest
thing to a podcast. To begin partway through, click a paragraph first — Edge
starts from wherever you clicked.

### What the index page tracks

Each lecture page has a **Mark as listened** button at the bottom. The index
shows a progress bar and marks what you have finished, so you can tell at a
glance where you stopped. This is stored in your browser only, and nothing is
sent anywhere. If your browser blocks storage for local files the pages still
work; they just will not remember.

### Rebuilding the pages

Only needed if you edit a lecture script.

```powershell
python scripts\make_read_aloud.py
```

`--check` reports any word the narrator would probably mangle, without writing
anything. It currently reports zero.

---

## Option B — real MP3 files

Read Aloud streams; it does not save. If you want files for a plane, a phone or
a car, generate them.

```powershell
pip install edge-tts
python scripts\make_lecture_audio.py
```

About ten minutes, roughly 125 MB, into `lectures\audio\` — twenty MP3s plus a
`playlist.m3u` and an `index.html` player. It uses the same Microsoft neural
voices as Read Aloud, so it sounds the same.

Two caveats worth knowing. `edge-tts` needs an internet connection and sends the
lecture text to a Microsoft endpoint, which is unremarkable for course material
but you should know it happens. And MP3 output wants `ffmpeg` on your PATH
(`winget install Gyan.FFmpeg`, then open a new terminal); without it you get WAV,
which is larger but works fine.

Try one lecture first:

```powershell
python scripts\make_lecture_audio.py --lesson 00
```

Because this folder sits inside OneDrive, anything you generate syncs to your
phone on its own.

### If you would rather install nothing at all

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\make_lecture_audio.ps1
```

Uses the speech engine already in Windows. It produces real files and needs no
install, but the stock voices (David, Zira, Mark) are dated — satnav rather than
podcast. Perfectly intelligible; try one lecture before committing to twenty.

### Offline, on the H100

```bash
python scripts/make_lecture_audio.py --backend kokoro
```

Runs an 82M-parameter neural TTS model locally. About a 350 MB download, then
fully offline, and nothing leaves the machine.

---

## Which to use

| | Read Aloud | edge-tts MP3s |
|---|---|---|
| Install needed | none | `pip install edge-tts` |
| Voice quality | neural | neural (same voices) |
| Produces files | no | yes |
| Works offline | yes, once open | yes, after generating |
| Sends text to Microsoft | yes, while playing | yes, while generating |
| Best for | at a desk, following along | commuting, walking, no signal |

Start with Read Aloud. Add the MP3s only if you find yourself wanting to listen
somewhere a browser is inconvenient.

---

## Troubleshooting

**Read aloud is greyed out or missing.** It only appears on rendered pages. If
you opened the `.md` file rather than the `.html`, Edge is showing you plain
text — open `lectures\read-aloud\index.html` instead.

**Only robotic voices are offered.** Open *Voice options* in the Read Aloud
toolbar and scroll; the Natural voices are usually below the legacy ones. If
none appear, Windows may need the voice pack: *Settings* → *Time & language* →
*Language & region* → English → *Language options* → *Speech*.

**It reads the navigation at the end.** That is expected and it is where the
lecture has finished. The spoken "That is the end of lecture NN" is your cue to
stop.

**Progress is not remembered.** Some Windows policies block storage for
`file://` pages. The pages still work. Nothing else depends on it.

**The pages open in a different browser.** Right-click → *Open with* →
*Microsoft Edge*. Read Aloud is an Edge feature; Chrome and Firefox have
extensions but not this one.
