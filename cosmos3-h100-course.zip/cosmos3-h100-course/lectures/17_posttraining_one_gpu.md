---
lesson: "17"
title: "Shrinking an 8-GPU recipe to one"
slug: "17_posttraining_one_gpu"
duration_estimate: "13 min"
words: 1917
---

# Lesson 17 — Shrinking an 8-GPU recipe to one

Lesson sixteen gave you the arithmetic. This lesson spends it. You are going to take the one shipped recipe whose memory bill plausibly fits on a single H100, work out every change it needs, write a prediction down, launch it, and report what actually happened.

Read this part before anything else, because it changes how you should hold the rest of the lesson. NVIDIA documents no single-GPU training path for Cosmos 3. Every shipped recipe is an eight-GPU configuration, tested on eight H100s. The smallest claim published anywhere is that Edge, being small, also fits a four-GPU node. So what follows is an experiment with a predicted outcome, not a promise. The course's position is that the arithmetic makes one card plausible for this specific recipe with these specific overrides, that plausible is not proven, and that the honest thing to do is predict, attempt and report. If your run runs out of memory at iteration three and you can say exactly which setting caused it, you have completed this lesson.

By the end you will be able to read the shipped vision recipe for Edge field by field and say what each setting costs. You will derive every single-GPU override from NVIDIA's own out-of-memory ladder and name the two rungs that need hardware you do not have. You will assemble the launch command and find the two things the course helper leaves out of it. And you will be able to classify a memory failure as a state problem or an activation problem from where in the run it happened.

## What an eight-GPU recipe assumes

A shipped recipe is not a list of preferences. It is a set of numbers chosen together on a particular machine, and several of them encode that machine.

Four settings matter most. The first is the tokens-after-packing cap, which ships at forty-five thousand and fifty-six. Sequence packing fills a buffer of that many tokens with as many training samples as fit. It is the activation driver, and it was sized so that one rank's share of the activations fits, given that sharding had already divided the state by eight. On one GPU the state is not divided, and the token cap is the only thing left to cut.

The second is gradient accumulation, which ships at two. Global batch size is accumulation times per-rank batch times world size. Drop world size from eight to one and change nothing else, and you have divided your global batch by eight. That is a different optimisation problem, not a slower version of the same one.

Third, the EMA setting is on, which is affordable when that extra float thirty-two copy is sharded eight ways and a whole extra copy when it is not. Fourth, compilation is on, which is the surprise in the file, because the schema default is off and the Super recipe turns it off explicitly. Compilation trades memory for speed on shapes somebody has compiled before, and you are about to feed it shapes nobody has.

Two more things deserve attention before you touch anything. Activation checkpointing is already set to full, so if this run runs out of memory and you reach for the standard advice to turn on activation checkpointing, you will discover it has been on the whole time. And the warmup schedule runs fifty steps out of five hundred, starting from a learning rate of exactly zero. At iteration twenty you are at forty percent of peak learning rate and still climbing, so a flat loss over a twenty-iteration smoke test tells you almost nothing.

There is also a prose-versus-config conflict worth resolving once. The training document calls this a full fine-tune of a two-billion-parameter backbone. The model card reports just under three point nine billion parameters. The config restricts the optimizer to five substrings, which is not a full fine-tune of anything. For memory arithmetic, cost the config. About four billion resident in b-float sixteen, roughly half of it trainable. When prose and a config disagree, cost the config.

## The overrides, derived one rung at a time

NVIDIA's FAQ gives an out-of-memory ladder with six rungs. Take it seriously, and then take it apart.

Rung one is expandable memory segments, an allocator setting. It is free, and it has to be set in the child process's environment, because that is the only place it can work.

Rung two is full activation checkpointing. Already on in this recipe. Set it explicitly anyway so the intent is visible in the command line, and expect zero saving.

Rungs three and four are raising the shard degree and raising the context-parallel degree. Both are unavailable to you. With one rank there is nothing to divide onto. Setting a shard degree of eight on a single GPU does not shard anything, it fails the world-size invariant, and the run dies before training starts.

Rung five is fewer samples per batch, which here means cutting the token cap. Take it from forty-five thousand down to about twelve thousand, and cut the dataloader's maximum sequence length to match, because leaving those two inconsistent gives the packer a budget the model will not honour. That is the number you will bisect later.

Rung six is LoRA, which is available, generator only, and changes what you are training rather than merely how.

Then two savings the ladder does not mention. Turn the EMA setting off, which buys back eight gigabytes for a quality effect you could not observe over a hundred iterations. And turn compilation off, which removes a memory cost during tracing and several minutes of startup from every debugging cycle. Finally, raise gradient accumulation from two to eight to recover the global batch. Two times eight ranks becomes eight times one rank. Mathematically the same gradient, four times the wall-clock.

And know what is simply not there. No CPU offload of parameters, optimizer state or activations exists anywhere in the training config schema. No eight-bit optimizer exists. Only fused AdamW. If you find advice online that starts with just raise the shard degree, it was written for a node.

## The command, and the two things it is missing

Before you launch, write a prediction down and put it on disk. Three numbers. State memory with your overrides, which the estimator gives you. Peak memory, which is state plus activations, which nothing gives you. And a yes or no on whether twenty iterations will complete, plus the setting you think most likely to kill it. The gap between your first two numbers is your activation estimate, and later you will measure it. Writing it to a file is the whole point, because then you cannot quietly revise it afterwards.

There is real setup underneath. The dataset is the Bridge Data 2 synthetic captions subset, zero point six five gigabytes and about twelve hundred training clips, by a wide margin the smallest thing NVIDIA ships for this. For contrast, the Cosmos 3 DROID dataset is seven hundred and seven gigabytes, which is disqualifying for a lab on any machine. You also need the Wan two point two VAE at two point eight two gigabytes and Edge itself at nine point one gigabytes, which then gets converted into a distributed checkpoint, because training does not read Hugging Face safetensors. Budget for both copies.

Now the two omissions, and both produce a confusing failure. The first is a bare double dash separator. The real launcher appends its trailing overrides after a bare double dash. Without it, the argument parser treats your overrides as positional arguments and either errors unhelpfully or, far worse, ignores them. Your run then silently uses the shipped forty-five thousand token cap and runs out of memory for a reason you will misdiagnose.

The second is three environment variables, the dataset path, the base checkpoint path and the VAE path. The training document is explicit that raw launching does not resolve them. Only the launch shell does. The config reads two of them by interpolation and the third is consumed inside the experiment code. Miss one and you get an interpolation error naming a variable you have never heard of.

Fix both visibly in your notebook rather than by editing the helper, and assert both are present before you launch. And check the GPU is genuinely empty. A reasoner container holding forty gigabytes will turn a run that would have fitted into a failure you then misdiagnose as an activation problem.

## The debugging lab, it died at iteration three

The symptom. The run loads, logs two iterations cleanly, and dies on the third, out of memory while trying to allocate four point six two gigabytes. Most people read that and start at the top of the ladder. Read the traceback instead, because it contains three facts and each one narrows the problem.

Fact one, it reached iteration three. So the checkpoint loaded, the optimizer was constructed, and two complete forward, backward and step cycles ran. State fits. Every rung that reduces state, meaning LoRA, the allowlist, the EMA setting, addresses a problem you do not have. That single observation eliminates half the ladder.

Fact two, it died inside the training step, in the forward pass. The allocation that failed is an activation.

Fact three, the allocator reported about sixty-nine gigabytes allocated, under three gigabytes reserved but unallocated, and about three gigabytes free. That reserved-but-unallocated figure being small means this is not a fragmentation failure, so expandable segments will not save you. The memory is genuinely in use.

So why iteration three rather than one? Because packed batches vary. The packer fills a token budget with whatever samples fit, so the third batch may hold more samples, or longer ones, than the first two. Your peak is set by the worst batch in the dataset, not the first. A configuration that survives ten iterations can still die at four hundred.

The repair is rung five, sized from the evidence rather than by reflex. You were short by roughly one and a half gigabytes out of a working set of about sixty-nine. That is a two percent overshoot, not a fifty percent one. Halving the token cap would work and would also double your wall-clock for no reason. Cut it by a third instead, and raise gradient accumulation in inverse proportion, which means multiplying by three halves rather than by two.

Then verify properly, because re-running and not crashing is weak evidence. Run at least twice the iterations that reached the failure, ideally past one full pass over the data, so the worst batch gets a chance to appear. Record peak memory and treat anything under about five gigabytes of headroom as none. Check the loss is still finite and still moving, because the force-finite setting will happily convert a NaN into a zero gradient and carry on looking healthy. And read the resolved config the trainer writes out, looking for your token cap. If the separator was missing it will say forty-five thousand, and you will have fixed nothing.

Three things to remember. The shipped recipe encodes its machine in four settings, and one of them changes the optimisation problem rather than the memory. Diagnose a memory failure by where it happened, because before iteration one is state and inside the forward pass is activations. And a falling loss over twenty iterations establishes that gradients flow, not that the model got better at anything.

Lesson eighteen asks whether it actually got better, in a repository that ships no way to ask.
