---
lesson: "16"
title: "What post-training actually changes"
slug: "16_posttraining_concepts"
duration_estimate: "13 min"
words: 1923
---

# Lesson 16 — What post-training actually changes

This is the cheapest lesson in the course and one of the most important. There is no GPU in it and nothing to download. Everything is arithmetic you could do on paper while you walk. And yet the two lessons after it are close to meaningless without it, because lesson seventeen attempts a fine-tune that NVIDIA does not document anywhere, and lesson eighteen has to work out whether that fine-tune did anything at all.

Here is the headline, stated once so the rest of the lesson can earn it. NVIDIA documents no single-GPU training path for Cosmos 3. Every shipped recipe is an eight-GPU configuration. The framework's training document says, in as many words, tested on eight H100s. The LIBERO action recipes use sixteen GPUs across two nodes. The DROID reproduction uses two hundred and fifty-six ranks. The smallest claim anyone has published is that the Edge vision recipe also fits a four-GPU node. Four is the published floor, and four is four times what you have.

By the end you will be able to derive why a full fine-tune of the sixteen-billion-parameter Nano checkpoint needs three to four H100s worth of memory before it touches a single frame of video. You will know which levers reduce that number, which of them quietly require hardware you do not own, and which single recipe is arithmetically plausible on one card.

## The four words people use as if they were one

Pre-training starts from random weights and shows the model an enormous, weakly curated corpus, which for Cosmos 3 is video with text. The problem it solves is that the model knows nothing. It has no prior over what a video is, what objects persist, what gravity looks like. Essentially all the capability comes from here, it costs thousands of GPU-months, and you are never going to do it. Post-training is the umbrella term for everything done to that checkpoint afterwards. It is a phase, not a technique.

Supervised fine-tuning, SFT, continues gradient descent with the same loss the model was pre-trained on, over a small curated set of input and desired-output pairs. The problem it solves is that the model is general and your domain is specific. It makes plausible video. You want video that looks like your robot in your kitchen. SFT is the only post-training technique this course runs.

RLHF, and the direct preference optimisation family, collects human comparisons instead of targets, because you can rank outputs when you cannot write them. Nobody can hand-author the correct video, but anyone can say which of two is better. Worth knowing about, and worth knowing that none of it ships. The framework's algorithm directory, which would hold reward models and RL, is listed in the code structure document as planned and is not present on disk.

LoRA, low-rank adaptation, is not a training objective. It is a parameterisation. Instead of updating a weight matrix directly you learn a low-rank correction and add it. That matters because optimizer state is proportional to trainable parameters, and you have one GPU.

## The memory bill you can derive by hand

Why do the shipped recipes need eight GPUs? The intuitive answer, that the model is big, is wrong. Nano's weights in b-float sixteen are thirty-two gigabytes, which fits on one H100 with room to spare. Training does not fail because the weights are large. It fails because of everything else that has to exist per parameter while you train.

Walk through what one parameter costs during a mixed-precision AdamW update. The b-float sixteen weight itself is two bytes, and every parameter pays it whether or not it is being trained. A float thirty-two master copy is four more bytes, and only trainable parameters need it. That copy exists because b-float sixteen has about eight bits of mantissa, so a typical update is far below one representable step at the weight's magnitude. Add it to a b-float sixteen weight and it rounds straight back. The parameter never moves. AdamW's first moment is four bytes and its second moment another four, and those two buffers are why Adam costs eight bytes per parameter that plain gradient descent does not. Gradients are two to four bytes depending on where accumulation happens. And then the exponential moving average copy, four more bytes in float thirty-two, used for inference while the live weights keep training. That last one is the most commonly missed line in the whole bill, and it defaults to on.

So a trainable parameter costs sixteen to twenty-two bytes. A frozen parameter costs two. Hold on to that ratio, because it is the whole economics of this.

Now run it for Nano. Sixteen billion parameters in b-float sixteen is thirty-two gigabytes. Float thirty-two master weights, sixty-four. The two AdamW moments together, a hundred and twenty-eight. Gradients, another thirty-two to sixty-four. The moving average copy, sixty-four more. Total, roughly two hundred and fifty to three hundred and fifty gigabytes, before one byte of activations exists. Three to four H100s. And the gap between the low end and the high end is not measurement error. It is two config lines, gradient precision and whether that moving average is enabled.

## Why freezing helps and checkpointing does not

Here is the most counter-intuitive claim in the module, and the internet will tell you the opposite. Activation checkpointing does not rescue that run. It throws away the intermediate outputs the backward pass would keep and recomputes them, costing about thirty percent more compute. It is a good tool. But Nano's state is three hundred and fifty gigabytes on an eighty gigabyte card, so even if checkpointing reduced activations to zero you would still need three hundred and fifty gigabytes before the first forward pass ran. You cannot checkpoint your way out of optimizer state. Ask the questions in order. Does state fit? If not, no activation knob helps, and you must reduce trainable parameters or shard.

Reducing trainable parameters is what the shipped vision recipe for Edge does. It hands the optimizer a substring allowlist, the keys-to-select setting, naming five parts of the architecture. The generation expert, the timestep embedder, the two projections between the video latent space and the language model's hidden space, and one normalisation piece of the understanding path that must move with the generation path. Everything else is frozen. Two bytes instead of eighteen.

Edge is four billion parameters, not two, whatever the prose says, so roughly two billion end up trainable. All four billion stay resident in b-float sixteen for the forward pass, eight gigabytes. Master weights for the trainable half, eight more. The moments for that half, sixteen. Gradients, four to eight. That is about forty-five to fifty gigabytes of state, leaving roughly thirty for activations. That is the one plausible single-card recipe in the repository, and it is undocumented.

LoRA is the other way to cut trainable parameters. A full update to a square weight matrix has as many free parameters as the matrix has entries. Write it instead as the product of a tall matrix and a wide one with a small inner dimension, and you train two times the rank times the side length. Cosmos 3 defaults to rank sixteen and alpha thirty-two. But note where it applies. LoRA here is first class and generator only, explicitly skipped on the reasoner path, because its default targets are the generation expert's attention projections.

Then there is sharding, which is what the shipped recipes rely on. Fully sharded data parallelism splits the parameters rather than the batch, so each rank owns one share of every row in your table. Two hundred and fifty-six gigabytes across sixteen ranks is about sixteen gigabytes a rank, which is comfortable rather than heroic. That is the resolution of the arithmetic, not a coincidence. It is also the lever you do not have. Raising the shard degree and raising the context-parallel degree are rungs three and four of the FAQ's out-of-memory ladder, and both need more GPUs. Of six rungs you get expandable memory segments, full activation checkpointing, fewer samples per batch, and LoRA. There is no eight-bit optimizer in Cosmos 3 and no CPU offload of any kind for training. Only fused AdamW.

One last thing about those sixteen ranks. Your pure memory floor says five would do. The reason for sixteen sits in a comment in the config. It is the minimum for a global batch of two thousand and forty-eight at a gradient accumulation of one. So it was a statistics decision that memory merely had to accommodate, and gradient accumulation is how you trade wall-clock for rank count at constant global batch. That is the substitution lesson seventeen makes.

## The dataset that loads fine and teaches nothing

Now the debugging lab, and it is a good one, because nothing goes wrong. You launch a fine-tune. Nothing errors. The process runs its full iteration count, writes checkpoints on schedule, and exits zero. Then you read the log, and every line says loss zero point zero zero zero zero, gradient norm zero point zero zero zero zero.

Four things produce a flat loss. The schedule might never have left warmup. The allowlist might match nothing, leaving the optimizer with an empty parameter list. Gradients might be getting zeroed, because the gradient clipping callback replaces non-finite values with zero, turning a numerical explosion into a silent no-op. Or the dataset is empty.

The discriminator is sitting in plain sight. A model training on real data and failing to improve has a non-zero constant loss, something like three point nine repeated. A loss of exactly zero with a gradient norm of exactly zero means no data reached the loss function. That points hard at the fourth hypothesis, and the diagnostic takes a second rather than an hour. Run the course dataset checker before you check anything expensive.

Here is what it finds. Generator training data is a JSONL manifest, one object per clip, carrying a duration in seconds, the video dimensions, a relative path, and one or more training windows cut from the clip. Each window has a start frame, an end frame and a structured caption object, which is the model's native prompt format. And the loader applies two filters that neither raise nor warn. A clip longer than sixty-one seconds is dropped whole. A window shorter than sixty-one frames is dropped. Note the asymmetry in that second one. Sixty-one frames at five frames a second is twelve seconds of footage, so if you built your dataset out of three-second clips, every record is invalid and nothing will tell you.

The repair is two repairs, and neither is deleting the bad records. The long clip must be split, and seventy-five seconds at five frames a second is six perfectly good windows. The short clip cannot be repaired at all. Either re-encode it at a higher frame rate, which invents no information but satisfies the filter, or exclude it honestly and record that you did. Validate before you launch.

Three things to carry away. A trainable parameter costs sixteen to twenty-two bytes and a frozen one costs two, and that ratio is the entire economics of single-GPU fine-tuning. Activation checkpointing cannot fix a state problem, so diagnose where the memory ran out before you pick a lever. And two dataset filters drop records silently, so a loss of exactly zero is a data problem until proven otherwise.

Lesson seventeen takes the one recipe this lesson called plausible and attempts it for real. Write your prediction down before you start.
