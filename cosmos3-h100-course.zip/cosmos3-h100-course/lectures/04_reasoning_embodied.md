---
lesson: "04"
title: "Embodied reasoning"
slug: "04_reasoning_embodied"
duration_estimate: "13 min"
words: 1871
---

# Lesson 04 — Embodied reasoning

Lesson three asked the model what is in front of it. This lesson asks it what to do about it. That sounds like one more step along the same road. It is a much larger claim, and the size of that gap is the whole subject.

Here is the difference in one sentence. A captioner that gets a detail wrong produces a slightly wrong sentence. A policy that gets a detail wrong moves a robot arm. Once a model's output drives an actuator, you need more than the output. You need enough of its reasoning to decide whether to trust it, and you need that in a form a program can inspect, not only a form a human can read over coffee.

So this lesson is really about auditability. By the end you will be able to pull a chain of thought out of the reasoner and split it cleanly from the answer. You will build three different prompt shapes and say what each one buys. You will measure what thinking costs, in tokens and in seconds, on your own machine. And you will make the model be fluent, confident and completely wrong on purpose, then catch it with a check that needs no human in the loop. Budget about seventy-five minutes. There are no downloads. It runs against the Reasoner NIM from lesson two, which you leave running at the end, because lesson five needs it.

## The first idea: the trace is a convention, not a mode

Cosmos 3 has no reasoning switch. There is no setting you turn on to make it think. If you have used other models where reasoning is a flag on the request, unlearn that here.

What actually happens is that you ask for a shape and the model fills it. You tell it to write its reasoning inside a think tag, close the tag, and then write the final answer immediately afterwards. Everything before the closing tag is the trace. Everything after it is the answer. That is the entire protocol.

Because it is a convention rather than a mode, the model can decline. It can open a think tag and never close it. It can emit both tags and then put the real answer inside them. So the course's splitting helper does not raise when the closing tag is missing. It hands you back an empty reasoning string and the whole text as the answer. That empty string is information, not an error. It tells you your prompt was not forceful enough, which is a thing you can go and fix.

Now the part that matters most, and the part people get wrong. A chain of thought is an artefact you can audit. It is not a guarantee of correctness. The trace comes out of exactly the same sampling process as the answer, and nothing in the architecture forces the answer to follow from the trace. The model can reason its way to a correct conclusion and then state the opposite. It does this often enough that checking whether the answer contradicts its own reasoning is a genuinely useful automatic test, and you will write that test later in the lesson. Treat the trace as evidence about the model's process. Never as proof about the world.

The notebook also has you run the same question twice at the same seed and temperature, once bare and once wrapped in the think instruction, and print both answers next to each other with their token costs. Commit to a prediction first. Will the answers be identical, differ only in wording, or sometimes disagree in substance? Whatever you get, the mechanism is the thing to explain. At temperature zero the only difference between the runs is the text sitting in the context window. The think instruction adds tokens, the generated trace adds many more, and every one of those tokens is part of what the final answer is conditioned on. That is a different claim from saying the model thought about it.

## Three prompt shapes, three different answers

The lesson runs four probes. The first three are the same underlying question asked with different amounts of scaffolding, and comparing them is where the skill lives.

Probe one is next-action prediction. You show the model a clip of a robot mid-task and ask what the next immediate action could be. No goal is stated. No history is given. The model has to infer the intent from the pixels alone. This is the core query of a reactive policy, and you will notice the answers come back generic, and often describe the scene rather than command an action.

Probe two adds a goal. The task is to put a flower into a red bottle, and you ask for a plan of subtasks over a still image. The first version returns prose, which is readable and unusable. So you name the shape you want, forbid the prose, and validate the result, exactly as in lesson three. The schema asks for a step number, a short imperative action, the single object the step acts on, and a gripper state of open or closed. Those last two fields are there for a reason that only pays off next lesson. Lesson five can ground an object name to a bounding box, and a step naming an object the model cannot localise is a step you can reject before it reaches hardware. Designing a schema around what you can check is the actual skill.

Then you hold the image fixed and change only the goal, three times. Same pixels, same seed. Everything that differs came out of six words of goal text. Watch particularly for a plan that names an object which is not in the picture. That is the failure this whole lesson is building towards.

Probe three supplies both the overall goal and the current step, and asks what comes next. Compare it against probe one. There, the model had to guess the intent. Here it is told the intent and told where in the procedure it sits, so it only has to work out what follows. The scope narrows sharply and the answers get specific.

There is a fourth element worth calling out, and it is the one people underestimate. A format constraint is not cosmetic. It changes content, not only shape. Asking for a field called object forces a commitment to a specific thing where prose could have said the item. Asking for a gripper state makes the model commit to open or closed when it might otherwise have stayed vague. Sometimes that commitment is the useful part. Sometimes it manufactures false precision, because a model will fill a required field whether or not it knows.

## Probing for failure instead of confirmation

The fourth probe is about physical common sense, and it starts by showing you a bad question.

The source course asks whether a countertop can support the weight of a toaster. The right answer is yes, the model says yes, and everyone nods. That is a confirmation-seeking probe and it teaches almost nothing, because a model that answered yes to everything would pass it. So you run it, and then you run its adversarial twin. Four questions whose correct answer is no. Could the robot lift the whole table by grasping a single sheet of paper resting on it. Can you pour liquid from a container that is upside down and empty. Would releasing an unsupported object leave it hanging in mid air. A model that agrees with any of those has told you something real about its failure surface. One question whose right answer is no is worth ten whose right answer is yes.

## The debugging lab: fluent, confident and wrong

Now the hardest failure in the course, and the most listenable part of this lesson.

The symptom is that there is no symptom. No error. No warning. The request returns two hundred. The JSON is well formed. The chain of thought reads like careful deliberation. The plan even has correctly numbered steps. And the answer is simply not true about the image in front of it. Every instrument you own at this point reports success. Your text check passes, because it is fluent language. Your JSON parser passes, because it is valid JSON. The exit code is zero.

The hypothesis is that the model completes the shape of the request regardless of whether the evidence supports it. Ask where a blue mug is in a scene with no blue mug, and a strong prior takes over. Questions have answers. Mugs sit on tables. That prior overwhelms the weak visual evidence for there being no such thing here. So you reproduce it deliberately. You pick an object that is definitely absent, you ask where it is, and you ask the model to state its confidence.

Three diagnostics settle it, in increasing cost, and none of them needs a human to read the output. The first is to ask the model to verify its own claim against the image, phrased so that no is an easy answer to give. That is cheap and works surprisingly often for existence questions, because verifying is easier than localising. It is also partly circular, same weights and same blind spots, so a pass is weak evidence while a failure is strong evidence. The second is to sample across seeds above greedy temperature. If five samples give five different positions for the mug, the model has no information and is drawing from a prior. Consistency does not prove correctness, but inconsistency reliably indicates absence of evidence. The third is the cheapest and the most satisfying. Look for the trace contradicting the answer. The reasoning sometimes says it cannot see a blue mug, and then the answer places one on the left. A string check over the pair catches that for free.

The repair is not a magic prompt. Nothing makes a model incapable of being wrong. What you can do is give the model an exit, by saying explicitly that no is an acceptable answer, because the default framing of any question implies its premise. You can ask for a confidence number and actually use it, treating a low value differently from a high one, while remembering it is poorly calibrated. You can ground before you plan, which is next lesson. And you never let a single sample drive hardware, because cross-seed agreement is cheap next to a collision.

Then you verify the repair, which is the step people skip. The notebook folds all three checks into one screening function and runs it over a claim you know is false and a claim you know is true. A screen that flags both, or flags neither, is not a screen.

Three things to carry out of this lesson. The think structure is a prompt convention, so parse it defensively. A trace is evidence about the model's process and never evidence about the world. And fluent, confident and wrong passes every instrument you had before today, so you need checks that a program can run.

Lesson five asks the third question: where. It gives you bounding boxes, numbered image regions, and trajectories, all on a normalised grid that is not pixels.
