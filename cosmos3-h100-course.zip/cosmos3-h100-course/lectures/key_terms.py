"""Key-terms recaps, spoken at the end of each read-aloud lecture.

These are written to be HEARD, not read. Microsoft Edge's Read Aloud speaks
both the term and the definition, so everything in this file obeys a few rules:

* No digits, no symbols, no markdown, no code, no paths, no addresses.
  Numbers are spelled the way a person says them: "about thirty-five
  gigabytes", "zero to one thousand", "sixteen comma nine".
* Acronyms and model names are written phonetically: "H one hundred",
  "B F sixteen", "F P eight", "V RAM", "rot six D", "S M ninety",
  "Cosmos three Nano", "F S D P, fully sharded data parallel".
* The term itself is spoken, so it is a spoken phrase, not an identifier.
  Where the written spelling matters for finding something later, the
  definition says so ("written W A M in a spec file").
* Six to nine terms per lecture, each recap under about ninety seconds at
  a hundred and forty-five words per minute, which is roughly two hundred
  and fifteen words in total.
* Continuity is deliberate. A term defined in one lecture is not redefined
  identically in a later one; later lectures add the next layer instead.

Keys are the lecture's two-digit number as a string, "00" through "19".
Values are ordered lists of (term, definition) pairs, in the order the
lecture taught them.
"""

KEY_TERMS: dict[str, list[tuple[str, str]]] = {
    "00": [
        ("compute capability",
         "A version number for the card's instruction set. Eight point zero "
         "brought B F sixteen, eight point nine added F P eight, and your "
         "H one hundred is nine point zero."),
        ("driver CUDA version",
         "The highest CUDA runtime your driver can support, not what you "
         "installed. It must be at least the runtime version, and the broken "
         "direction reports a missing kernel image."),
        ("runtime CUDA version",
         "The toolkit your PyTorch wheel was compiled against. A compiler on "
         "your path reports a third number that almost never matters."),
        ("allocated, reserved and device wide",
         "Allocated is what live tensors hold, reserved is what PyTorch took "
         "from the driver, device wide is the whole card. Read all three when "
         "a run dies."),
        ("the caching allocator",
         "PyTorch keeps freed blocks rather than returning them, because "
         "driver frees are slow, so reserved ratchets up and never falls. "
         "That gap is cache, not a leak."),
        ("CUDA context",
         "A few hundred megabytes of bookkeeping that appear the moment a "
         "process touches the card. Real memory you never allocated and "
         "cannot avoid."),
        ("the visible devices variable",
         "Hides cards from a process. CUDA reads it once at initialisation, "
         "so setting it later does nothing. Pinned to one on a single card "
         "machine it silently yields none."),
    ],
    "01": [
        ("world foundation model",
         "A model that predicts what the world does next rather than what "
         "text comes next, trained broadly enough to point at a new scene "
         "without retraining it."),
        ("mixture of transformers",
         "One stack of layers with two sets of weights. The reasoner tower "
         "turns pixels into text, the generator tower turns noise into "
         "pixels, and only one runs per forward pass."),
        ("active versus total parameters",
         "Nano is sixteen billion on disk and eight billion through one "
         "forward pass. Budget inference against the active count and "
         "training against the total."),
        ("the three tiers",
         "Edge is four billion and dense, capped at four eighty, no audio. "
         "Nano is sixteen billion total, eight billion active. Super will not "
         "generate on one card."),
        ("world action model, or wam",
         "The action mode once called policy, written W A M in a spec. The "
         "old name is gone from the enum, so a run using it fails validation."),
        ("transfer",
         "Not a model mode, whatever the documentation says. It is the video "
         "to video mode plus a control hint block in the same spec."),
        ("the guardrail",
         "Screens the prompt going in and the frames coming out. The only "
         "gated repository left, on by default, and a rejection exits zero "
         "with a blank file."),
    ],
    "02": [
        ("N I M",
         "NVIDIA's inference microservice: a container holding a model, an "
         "optimised server and an H T T P interface. Your code does not care "
         "what is behind it."),
        ("OpenAI compatible",
         "The server takes and returns the same JSON shapes as OpenAI's "
         "service, so the standard client library talks to it unmodified. No "
         "request leaves your machine."),
        ("the two credentials",
         "A registry login lets Docker pull the image. An N G C key inside "
         "the container lets it fetch model profiles. They fail at different "
         "moments."),
        ("the key value cache pool",
         "At startup the server claims most of the free memory as a pool for "
         "attention keys and values, and keeps it for the container's life. "
         "Not a leak, the design."),
        ("resting footprint",
         "What an idle container holds. F P eight Nano weights are about "
         "eight gigabytes, but uncapped it settles near the whole card."),
        ("take turns or cap",
         "The two honest plans for one card. Taking turns costs a model load "
         "per switch. Capping costs cache, which is the same thing as maximum "
         "context length."),
        ("live and ready",
         "Live says the process is alive, within seconds. Ready says the "
         "weights are loaded, which takes minutes. Poll the wrong one and you "
         "call it broken."),
    ],
    "03": [
        ("frame sampling",
         "The model never sees video. The server decodes the clip, samples "
         "still frames, and feeds them as a sequence of images to a vision "
         "language model."),
        ("frames per second",
         "The rate you sample at, not the clip's own rate. It is a claim "
         "about timescale: an event shorter than the gap between samples is "
         "invisible."),
        ("frame count as the cost lever",
         "Every sampled frame becomes a few hundred tokens, so frame count "
         "dominates cost. Comparing token counts at two rates proves whether "
         "the server honoured your rate."),
        ("structured scene record",
         "Subjects, setting, actions, lighting and camera, returned as JSON. "
         "Those five fields are exactly what the generation module knows how "
         "to condition on."),
        ("validator, not constraint",
         "You checked free text after the fact. Constrained decoding makes "
         "malformed output impossible instead. Until you know which you have, "
         "validate every record."),
        ("temperature, top p and seed",
         "Temperature at zero, top p at one and a fixed seed give near "
         "reproducibility. Batched inference on a card is still not bitwise "
         "deterministic."),
        ("the four two two error",
         "On a video request it means zero decoded frames until proven "
         "otherwise. A missing A V one decoder returns an empty frame list "
         "rather than raising, so probe and transcode."),
    ],
    "04": [
        ("the think tag",
         "A prompt convention, not a mode. There is no reasoning switch; you "
         "ask for reasoning inside a tag, and everything after the closing "
         "tag is the answer."),
        ("chain of thought",
         "Evidence about the model's process, never proof about the world. "
         "Trace and answer come from the same sampling, and nothing forces "
         "one to follow from the other."),
        ("next action prediction",
         "Show a clip mid task and ask what comes next, with no goal stated. "
         "The core query of a reactive policy, and the answers come back "
         "generic."),
        ("a schema you can check",
         "Ask for a step number, an action, one named object and a gripper "
         "state, so a step naming an object you cannot localise can be "
         "rejected."),
        ("the adversarial probe",
         "A question whose correct answer is no. One of those is worth ten "
         "whose answer is yes, since a model that agrees with everything "
         "passes the rest."),
        ("fluent, confident and wrong",
         "Valid JSON, careful-sounding reasoning, exit code zero, and untrue "
         "about the image. Asked where an absent object is, a strong prior "
         "beats weak visual evidence."),
        ("cross seed consistency",
         "Sample the same question at several seeds. Five different answers "
         "means the model is drawing from a prior, not from evidence. "
         "Consistency proves nothing."),
    ],
    "05": [
        ("normalised coordinates",
         "Boxes come back on a fixed grid from zero to one thousand, "
         "normalised per axis. They are not pixels."),
        ("left, top, right, bottom",
         "The order of the four numbers. The origin is the top left, x "
         "increases to the right and y increases downwards, which is the "
         "opposite of the maths convention."),
        ("the two divisors",
         "To get pixels, multiply the horizontal numbers by width and the "
         "vertical ones by height, then divide by one thousand. There is no "
         "single scale factor."),
        ("Set of Mark prompting",
         "You draw numbered regions yourself and ask for a caption per "
         "number. A number is unambiguous where a phrase like the left arm is "
         "not."),
        ("the keying check",
         "Confirm the returned identifiers match your marks in count and in "
         "order. Same count with wrong keys breaks every join afterwards, and "
         "nothing complains."),
        ("waypoint trajectory",
         "An ordered path for the end effector on the same grid. It is a "
         "pixel space plan: no depth, no orientation, nothing in metres."),
        ("split before you parse",
         "The reasoning block usually contains a draft of the JSON. Parse the "
         "raw text and you get the draft, which is plausible and wrong. Split "
         "on the closing tag first."),
    ],
    "06": [
        ("the forward process",
         "A fixed recipe for destroying data: mix a data point with more and "
         "more noise until nothing of the original remains. Nothing is "
         "learned here."),
        ("noise prediction",
         "The network predicts which noise was added at a given level. Plain "
         "supervised regression, because you made the noise and already have "
         "the label."),
        ("classifier free guidance",
         "The label is dropped during training some of the time, so one set "
         "of weights learns conditional and unconditional denoising. It still "
         "costs two forward passes per step."),
        ("steps",
         "Sequential nudges, so wall clock is close to linear in them and "
         "peak memory barely moves. Too few does not scatter samples, it "
         "collapses them onto the mode."),
        ("shift",
         "Re-spaces the timesteps along the noise schedule. Coarse structure "
         "is decided at high noise, so bunching steps there usually beats "
         "spending them on texture."),
        ("latent diffusion",
         "The transformer denoises a compressed latent, not pixels: divide "
         "each spatial dimension by sixteen and time by four. Cost scales "
         "with pixel area, which is why a resolution tier is your biggest "
         "lever."),
        ("negative prompt",
         "The conditioning fed to the unconditional branch. A direction, not "
         "a filter, with force proportional to guidance, so at a guidance of "
         "one it does nothing."),
    ],
    "07": [
        ("the pinned first slice",
         "Your conditioning image is encoded to one temporal slice, written "
         "at time zero, and re-imposed after every denoising step. Everything "
         "else is denoised in its presence."),
        ("drift",
         "When the frame implies no particular motion the model must commit "
         "to some interpretation and follow it. Not random noise: a confident "
         "guess about the future."),
        ("contradiction",
         "Prompt and image disagree. Nothing can change slice zero, so the "
         "conditioning holds and the prompt pulls the later frames away from "
         "it."),
        ("the correlation profile",
         "Correlate the conditioning image against frames through the clip. "
         "Flat means nothing animated; a collapse means your conditioning was "
         "thrown away."),
        ("resolution tier",
         "A name for a pixel budget, not a pixel height. The aspect ratio "
         "decides how that budget splits between width and height, which "
         "changes the token count."),
        ("sixteen comma nine",
         "The framework wants a comma, not a colon, and only five values are "
         "accepted. Derive the ratio from your image rather than typing it."),
        ("a clean exit failure",
         "The run did exactly what you asked and what you asked was wrong. "
         "Only a check comparing output geometry against your intent will "
         "catch it."),
    ],
    "08": [
        ("the control hint block",
         "Transfer is video to video plus this block. It names one hint, a "
         "control video and a weight, and the framework takes the transfer "
         "path when it sees one."),
        ("the four hints",
         "Edge keeps shape and layout; blur keeps colour and lighting. Depth "
         "keeps three dimensional structure; segmentation keeps object "
         "identity."),
        ("a lossy summary",
         "Each hint discards something, and what it discards is what you are "
         "free to change. An edge map has no colour, so colour is yours."),
        ("world scenario map",
         "A fifth shipped asset family using the same mechanism, but not a "
         "member of the enum. Accept it in specs; do not call it a hint."),
        ("the Edge collision",
         "Edge is a model tier and edge is a control hint. Unrelated, and the "
         "Edge tier is the one tier that cannot run the edge hint."),
        ("the control decides the geometry",
         "Frame count, frame rate and geometry come from the control video, "
         "not your spec. One control frame per output frame, so derive the "
         "count and never type it."),
        ("one clip with a hundred appearances",
         "A hundred variants of one recording share one camera trajectory and "
         "one scene layout. Not a hundred clips, and your report should say "
         "so."),
    ],
    "09": [
        ("audio image to video",
         "A mode taking a prompt, an image and a sound file. The image pins "
         "the first frame; the audio conditions timing, so motion lands on "
         "the sounds."),
        ("the sound tokenizer",
         "The component that turns a waveform into tokens and back. Edge does "
         "not have one, which makes its lack of audio architectural rather "
         "than a flag."),
        ("the two screens",
         "A text classifier before the prompt reaches the encoder, and a "
         "frame classifier after the decoder that also blurs faces. Every "
         "Cosmos three checkpoint is ungated; this is the one thing that is "
         "not."),
        ("blocked, failed, succeeded",
         "Three outcomes, not two. Blocked is logged and never retried, since "
         "the prompt screen ignores the seed, while failed is retried. "
         "Merging them loses what to do next."),
        ("guardrail offload",
         "Keeps guardrail weights on the host until a screen runs. It moves "
         "the baseline, not the peak, because the peak happens inside the "
         "denoising loop."),
        ("the gating error",
         "A four oh one naming a repository you never asked for. Two causes "
         "look identical: licence not accepted, or no token reached the child "
         "process."),
        ("the no guardrails flag",
         "It works, and it is not a performance fix. It unscreens every "
         "output in the batch and drops face blurring."),
    ],
    "10": [
        ("action as a modality",
         "A token stream for action alongside text, image and video. One "
         "action token is the transition between two consecutive visual "
         "states."),
        ("the three action modes",
         "Frame plus actions gives future video, which is forward dynamics. "
         "Video alone gives actions, which is inverse dynamics. Observation "
         "plus instruction gives both, which is wam."),
        ("forward dynamics",
         "If I do this, what will I see. Supply a start frame and a "
         "trajectory, and the model predicts the video that follows."),
        ("the six number rotation",
         "Written rot six D: the first two columns of the rotation matrix. "
         "Six is the smallest continuous, singularity free encoding of a "
         "three dimensional rotation, so Euler angles and quaternions are "
         "out."),
        ("domain name",
         "A free string selecting the embodiment, and with it the raw action "
         "width. Nine for vehicles, ten for Bridge, DROID and UMI, "
         "twenty-nine for AgiBot World."),
        ("action chunk size",
         "How many action steps in one chunk. Doubling it roughly doubles "
         "output duration but not wall clock, because process start and "
         "checkpoint load are paid once."),
        ("well formed is not correct",
         "A vehicle trajectory padded to robot width passes every shape "
         "check. The numbers are finite and correctly shaped, and the columns "
         "mean something else."),
    ],
    "11": [
        ("inverse dynamics",
         "Video in, actions out. Same checkpoint, one field changed, and the "
         "spec loses its action path because the action is being predicted "
         "rather than supplied."),
        ("the four by four pose",
         "Position and orientation in one object. The rotation block is "
         "orientation, the translation column is position, and the third "
         "rotation column is heading."),
        ("composition on the right",
         "New pose equals old pose times the delta. On the right means "
         "relative to where I am now; on the left would mean relative to the "
         "world origin."),
        ("backward framewise",
         "The convention the action stack uses. Each delta is the inverse of "
         "one transform times the next, and decoding composes them back up "
         "from the identity."),
        ("translation scale",
         "A calibration constant, one point three five in the cookbook, that "
         "divides only the translations. Trajectory shape survives it; "
         "absolute size in metres does not."),
        ("compounding drift",
         "Relative deltas are an easy regression target, but each pose is "
         "built on the last, so a small bias becomes visible drift by the end "
         "of a clip."),
        ("the round trip",
         "Feed predicted actions back through forward dynamics and compare. "
         "It shows the two directions agree with each other, not that either "
         "is right about the world."),
    ],
    "12": [
        ("policy",
         "Maps a state and a goal to an action. A dynamics model describes "
         "the world; a policy chooses, so it can be smooth, accurate and "
         "useless."),
        ("the enum is the authority",
         "The way you know the mode is wam. Documentation says what was true "
         "when it was written; an enum says what is true now."),
        ("the two outputs",
         "One forward pass gives a rollout video and an action chunk: the "
         "same future in two languages. If they disagree, something is wrong "
         "even though neither is malformed."),
        ("the ten number Bridge action",
         "Three translation deltas for the end effector, six for rotation, "
         "one for the gripper. Driving actions are nine wide; the tenth "
         "number is the one that grips."),
        ("gripper polarity",
         "Which end of the channel means closed is a per dataset convention. "
         "Measure it from the rollout at the transition times, and never "
         "assume it."),
        ("the noise floor",
         "Run the same instruction twice at different seeds before claiming "
         "an instruction changed the actions. A difference smaller than seed "
         "noise is not a difference."),
        ("open loop",
         "One observation in, sixteen actions out, all executed blind. Error "
         "compounds, disturbances are ignored, and later actions assume a "
         "position the arm is not in."),
    ],
    "13": [
        ("closed loop",
         "Observe, predict, execute a few steps, observe again. Each fresh "
         "observation resets the accumulation, so error is bounded by the "
         "chunk rather than the horizon."),
        ("bias versus noise",
         "A systematic bias grows in proportion to the steps. Zero mean noise "
         "grows like the square root. Both unbounded open loop; only one is "
         "obvious early."),
        ("server and client",
         "The server holds the weights and answers one question. The client "
         "owns the simulator and runs the loop. The loop lives in the "
         "client."),
        ("the dependency pin",
         "Robosuite needs an old torch, the framework needs a new one, and no "
         "environment holds both. An unresolvable pin can be telling you "
         "where a process boundary belongs."),
        ("action heads",
         "The base checkpoint has none. You can run wam through ordinary "
         "inference, but only a post-trained checkpoint can be served from a "
         "policy server."),
        ("two hundred is not success",
         "Inference errors return two hundred with an empty action list. "
         "Check the body: no error field, an action key present, and the "
         "width the domain expects."),
        ("train serve skew",
         "Four documented parity traps: camera concatenation order, a flipped "
         "gripper sign, frames rotated a hundred and eighty degrees, and "
         "quantile rotation normalisation. None of them raises."),
    ],
    "14": [
        ("asynchronous execution",
         "A launch writes work into a queue and returns in microseconds. Time "
         "either side of it and you measured the cost of asking, not the cost "
         "of doing."),
        ("synchronise",
         "Block the host until the queue drains, before starting the clock "
         "and again before stopping it. Microseconds of cost, and the "
         "difference between a number and a fiction."),
        ("warm up",
         "The first call pays for context creation, kernel selection and "
         "allocator growth. One warm-up per shape, outside the timed region, "
         "because each shape tunes separately."),
        ("median and spread",
         "Report a median and an inter-quartile range. The noise is one "
         "sided: nothing runs faster than the hardware allows, and a mean "
         "absorbs every slow outlier."),
        ("CUDA events",
         "Markers the device timestamps as it reaches them. They answer how "
         "long the device spent; wall clock answers how long the user waited. "
         "Different questions."),
        ("peak memory",
         "A high-water mark since the process started, or since you last "
         "reset it. Reset, run the region you care about, then read."),
        ("exactly one respect",
         "A comparison must differ in one respect, not one setting. Same "
         "warm-up, same iteration count, same shapes. Every extra difference "
         "hides a factor."),
    ],
    "15": [
        ("exponent and mantissa",
         "The exponent field sets range. The mantissa sets precision, how "
         "many values fit between one power of two and the next."),
        ("B F sixteen",
         "Keeps the full thirty-two bit exponent and pays in mantissa bits. "
         "Literally the top half of a thirty-two bit float, which is why it "
         "needs no loss scaling."),
        ("loss scaling",
         "Multiply the loss before the backward pass so small gradients stay "
         "representable, then divide it out. A whole subsystem that exists "
         "because F P sixteen has too few exponent bits."),
        ("F P eight",
         "Two formats on Hopper: more precision for weights, more range for "
         "gradients. Values must be scaled per tensor, so it is a numerics "
         "project, not a data type swap."),
        ("T F thirty-two",
         "A nineteen bit internal format the tensor cores use for thirty-two "
         "bit multiplies, on by default. A precision change wearing a full "
         "precision label."),
        ("FlashAttention",
         "Walks keys and values in tiles that fit on chip and never writes "
         "the score matrix. A memory result first; the speed follows from the "
         "traffic it avoids."),
        ("saturation",
         "Below some batch size the card is not full, so time per batch falls "
         "while time per item does not. A ratio needs a named denominator."),
    ],
    "16": [
        ("supervised fine tuning",
         "Continues gradient descent with the pre-training loss over a small "
         "curated set of input and output pairs."),
        ("the per parameter bill",
         "Sixteen to twenty-two bytes for a trainable parameter, two for a "
         "frozen one. That ratio is the whole economics of single card fine "
         "tuning."),
        ("the E M A copy",
         "A full precision moving average of the weights, kept for inference. "
         "On by default, and sixty-four gigabytes of it for Nano."),
        ("activation checkpointing",
         "Recomputes intermediates instead of storing them, for about thirty "
         "percent more compute. It cannot rescue a state problem, so ask "
         "whether state fits first."),
        ("keys to select",
         "A substring allowlist for the optimizer. The Edge vision recipe "
         "names five parts and freezes the rest, leaving about half of four "
         "billion trainable."),
        ("LoRA, low rank adaptation",
         "A parameterisation, not an objective: a low rank correction instead "
         "of the full matrix. Generator only, skipped on the reasoner path."),
        ("F S D P",
         "Fully sharded data parallel splits parameters rather than batches. "
         "It is how the shipped recipes fit, and it needs cards you do not "
         "have."),
        ("the two silent filters",
         "Clips over sixty-one seconds are dropped whole and windows under "
         "sixty-one frames are dropped, with no warning. Loss of exactly zero "
         "is a data problem."),
    ],
    "17": [
        ("sequence packing",
         "Fills a token buffer with as many samples as fit. The cap ships at "
         "forty-five thousand, sized for one rank's share, and it is the main "
         "activation driver."),
        ("gradient accumulation",
         "Global batch is accumulation times per rank batch times world size. "
         "Dropping from eight cards to one divides it by eight unless you "
         "raise accumulation."),
        ("the two unavailable rungs",
         "Raising the shard degree and raising the context parallel degree "
         "both need more cards. Of six rungs on the ladder you get four."),
        ("the bare double dash",
         "The separator before trailing overrides. Without it the parser may "
         "ignore them, so your run silently uses the shipped token cap."),
        ("the three path variables",
         "Dataset, base checkpoint and V A E paths. Only the launch shell "
         "resolves them, and a missing one errors on a variable name you have "
         "never seen."),
        ("state or activation",
         "Where the failure happened tells you which. Before iteration one is "
         "state. Inside the forward pass is an activation, and every state "
         "lever is then irrelevant."),
        ("the worst batch",
         "Packed batches vary, so peak is set by the worst batch in the "
         "dataset, not the first. Surviving ten iterations does not mean "
         "surviving four hundred."),
    ],
    "18": [
        ("held out set",
         "Data never trained on, chosen before you look at results. The "
         "second half is the one people violate, by swapping prompts after "
         "disliking an answer."),
        ("paired seeds",
         "Same seed for both models on a prompt, so prompt and seed cancel in "
         "the difference. Unpaired, the same data gives an interval several "
         "times wider."),
        ("the three proxies",
         "Structure is spatial autocorrelation, blind to what the structure "
         "is. Aliveness is frame to frame change, blind to direction. "
         "Stability is blind to slow drift."),
        ("calibrating on a planted effect",
         "Validate the harness against a synthetic pair whose true difference "
         "you set. If it cannot recover an effect you planted, it will not "
         "recover a real one."),
        ("composition weighting",
         "A pooled mean is weighted by your prompt mix, so a third out of "
         "domain can hide a real in domain gain. Report per category."),
        ("leakage",
         "Same clip in both splits, near duplicate frames from one episode, "
         "or the same caption text. Fix the split, not the prompt list, and "
         "gate before every evaluation."),
        ("a null result with a bound",
         "No difference at twenty paired samples, so any real effect is below "
         "about twice the standard error. That is a result; it did not seem "
         "to help is not."),
    ],
    "19": [
        ("the synthetic data flywheel",
         "Reason over real clips, plan variations, generate, gate them "
         "automatically, judge the survivors, then measure. One checkpoint "
         "supplies both the describer and the generator."),
        ("a useful variation",
         "Changes something the downstream model should be invariant to while "
         "preserving what it must still get right. Lighting, yes; a "
         "spaceship, no; a new seed, nothing."),
        ("the ledger",
         "Append only, flushed and synced before the call returns, so an "
         "abrupt kill loses at most one completed item. Resume is the "
         "difference between wanted and recorded."),
        ("stable identifiers",
         "Derive a variant identifier from its inputs, never from the clock "
         "or a random value. Unstable identifiers make a resumed run match "
         "nothing and redo everything."),
        ("stage order as a memory schedule",
         "Reason everything, then generate everything, then validate. Clip by "
         "clip would be more natural and would start and stop the container "
         "once per clip."),
        ("rejected versus failed",
         "A rejection is your policy working. A failure is your pipeline "
         "broken. Merging them gives you nine of twenty did not work, which "
         "tells nobody what to do."),
        ("cost per accepted clip",
         "Launch overhead divided by batch size, plus sampling and judging, "
         "divided by the acceptance rate. That rate sits in the denominator "
         "and cannot be known beforehand."),
    ],
}
