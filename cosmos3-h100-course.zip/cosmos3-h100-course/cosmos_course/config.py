"""Environment detection, paths, model facts and VRAM budgeting.

Nothing in this module is magic. It is course material: Lesson 00 reads it
line by line. The job it does is unglamorous but load-bearing — work out what
machine we are actually on, rather than assuming.

Design rules followed here:

* No hard-coded user directories. Everything resolves from environment
  variables with repo-relative fallbacks. The source DLI notebooks hard-coded
  ``/dli/task``; that assumption is exactly what we are removing.
* Every probe degrades gracefully. A missing tool returns ``None``, never
  raises, so a partial environment still produces a useful report.
* Facts carry a provenance note. Where a number came from an NVIDIA doc it
  says so, because these numbers move and you will need to recheck them.

The target machine for this course is **one H100 80 GB, x86_64, CUDA 12.8+**.
That is a *discrete* GPU: VRAM and host RAM are separate pools, ``nvidia-smi``
reports memory correctly, and ``torch.cuda.mem_get_info()`` tells the truth.
If you have met NVIDIA's Grace-based machines (GB10, GH200, GB200) note that
those are unified-memory parts where none of that holds; this module assumes
the discrete case and says so where it matters.
"""

from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "COURSE_ROOT",
    "OUTPUT_ROOT",
    "ASSET_ROOT",
    "COSMOS_ROOT",
    "COSMOS3_REPO",
    "MODEL_TIERS",
    "MODEL_MODES",
    "TRANSFER_HINTS",
    "RESOLUTION_TIERS",
    "ASPECT_RATIOS",
    "MAX_FRAMES_BY_TIER",
    "AUXILIARY_DOWNLOADS_GB",
    "RESOLUTION_TIERS",
    "PINNED",
    "EnvReport",
    "probe_environment",
    "select_device",
    "resolution_wh",
    "estimate_generation_cost",
    "vram_budget",
    "require",
]

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
# COURSE_ROOT is the directory containing this package's parent — i.e. the
# checkout root. Deriving it from __file__ means the notebooks work no matter
# where the course is cloned and no matter what Jupyter's working directory is.
COURSE_ROOT = Path(__file__).resolve().parent.parent

OUTPUT_ROOT = Path(os.environ.get("COSMOS_COURSE_OUTPUT", COURSE_ROOT / "outputs")).resolve()
ASSET_ROOT = Path(os.environ.get("COSMOS_COURSE_ASSETS", COURSE_ROOT / "assets")).resolve()

# The Cosmos cookbook checkout (sample media, prompts, control videos, action
# trajectories). scripts/fetch_assets.py puts it here by default.
COSMOS_ROOT = Path(os.environ.get("COSMOS_ROOT", COURSE_ROOT / "vendor" / "cosmos")).resolve()

# The Cosmos Framework checkout (the inference engine and its uv venv).
COSMOS3_REPO = Path(
    os.environ.get("COSMOS3_REPO", Path.home() / "cosmos3" / "cosmos-framework")
).resolve()

# Upstream commits this course was written against. Pinning is not pedantry:
# `model_mode: "policy"` was renamed to `"wam"` upstream between the source DLI
# course and today, and several upstream doc pages still describe the old name.
# An unpinned checkout is not reproducible.
PINNED = {
    "cosmos_framework": os.environ.get("COSMOS3_FRAMEWORK_REF", "v1.2.2"),
    "cosmos_cookbook": os.environ.get("COSMOS_COOKBOOK_REF", "main"),
    "reasoner_nim": os.environ.get("COSMOS3_NIM_TAG", "1.7"),
}

# --------------------------------------------------------------------------
# Model tiers
# --------------------------------------------------------------------------
# Parameter counts are the safetensors index totals from the Hugging Face model
# cards, checked August 2026. Note the naming trap: NVIDIA's docs and the NIM
# name the tiers by *active* (per-tower) parameters — "Nano (8B)" — while
# Hugging Face reports the *total*. Both are right. Nano is 16B on disk and 8B
# through any single forward pass, because it is a Mixture-of-Transformers with
# separate reasoner and generator towers.
#
# `gated` was TRUE for Nano and Super when the source DLI course was written.
# It is FALSE for all Cosmos3 checkpoints today; only the guardrail still gates.
# Verified via https://huggingface.co/api/models?author=nvidia&search=Cosmos3
MODEL_TIERS: dict[str, dict[str, Any]] = {
    "Cosmos3-Edge": {
        "hf_repo": "nvidia/Cosmos3-Edge",
        "params_total_b": 4,          # 3,858,999,728 exactly
        "params_active_b": 4,         # dense Nemotron-VL backbone, not MoT
        "download_gb": 9.1,
        "gated": False,
        "max_resolution_tier": "480",
        "fps_range": (12, 30),
        "frames_range": (50, 150),
        "supports_audio": False,
        "supports_transfer": False,   # no video2video control on Edge
        "inference_vram_gb": 12,      # measured guidance, not an NVIDIA figure
        "note": "Start here. Fits with room to spare; every mode except audio and transfer.",
    },
    "Cosmos3-Nano": {
        "hf_repo": "nvidia/Cosmos3-Nano",
        "params_total_b": 16,         # 15,750,057,456 exactly
        "params_active_b": 8,
        "download_gb": 34.9,
        "gated": False,
        "max_resolution_tier": "768",
        "fps_range": (10, 30),
        "frames_range": (1, 189),
        "supports_audio": True,
        "supports_transfer": True,
        "inference_vram_gb": 32,      # NVIDIA figure, cosmos-framework docs/faq.md
        "note": "Quality tier. Supports every model mode. Comfortable on one 80 GB H100.",
    },
    "Cosmos3-Super": {
        "hf_repo": "nvidia/Cosmos3-Super",
        "params_total_b": 64,
        "params_active_b": 32,
        "download_gb": 133.0,
        "gated": False,
        "max_resolution_tier": "768",
        "fps_range": (10, 30),
        "frames_range": (1, 189),
        "supports_audio": True,
        "supports_transfer": False,   # text2image / text2video / image2video only
        "inference_vram_gb": 128,     # NVIDIA figure, cosmos-framework docs/faq.md
        "note": (
            "Does NOT fit one H100 for framework inference (needs ~128 GB). "
            "The Reasoner NIM can still serve Super at FP8 on one H100 — the "
            "constraint is the generator, not the reasoner."
        ),
    },
}

# Extra downloads triggered on first inference, in decimal GB.
AUXILIARY_DOWNLOADS_GB = {
    "nvidia/Cosmos-Guardrail1": 3.63,   # the ONE repo that still needs a licence click
    "Wan2.2 VAE (single file from Wan-AI/Wan2.2-TI2V-5B)": 2.82,
    "Qwen/Qwen3Guard-Gen-0.6B": 1.52,
}

# --------------------------------------------------------------------------
# Model modes
# --------------------------------------------------------------------------
# Mirrors `ModelMode` in cosmos_framework/inference/args.py at v1.2.2.
# THIS IS THE AUTHORITATIVE LIST. Upstream docs/inference.md still documents a
# `policy` mode that no longer exists in the enum, and omits three that do.
# Lesson 01 has learners verify this against their own checkout rather than
# trusting either the docs or this dictionary.
MODEL_MODES: dict[str, str] = {
    "text2image": "Text prompt in, single image out.",
    "text2video": "Text prompt in, video out.",
    "image2image": "Image in, edited image out.",
    "image2video": "Image in (first frame), video out.",
    "video2video": "Video in, restyled video out. This is how transfer/control runs.",
    "audio_image2video": "Image plus audio conditioning in, video out. Nano and Super only.",
    "forward_dynamics": "Start frame plus action trajectory in, future video out.",
    "inverse_dynamics": "Video in, action trajectory out.",
    "wam": "World Action Model. Observation plus instruction in, video AND actions out. "
           "Renamed from `policy` upstream — the old name will fail.",
    "reasoner": "Vision-language question answering through the framework rather than a server.",
}

# Transfer is NOT a model mode. It is `video2video` plus one of these control
# hint blocks in the spec. Mirrors `TransferHintKey` in the same file.
TRANSFER_HINTS: dict[str, str] = {
    "edge": "Canny-style edge map. Preserves shape and layout. Best for material changes.",
    "blur": "Blurred colour field. Preserves palette and lighting. Subtle appearance edits.",
    "depth": "Depth map. Preserves 3D structure and scale. Best for relighting.",
    "seg": "Segmentation map. Preserves object identity. Best for swapping objects.",
}
# `wsm` (world scenario map) ships as a cookbook asset family and uses the same
# mechanism, but is not a member of the upstream TransferHintKey enum.

RESOLUTION_TIERS: dict[str, tuple[int, int]] = {
    "256": (256, 144),
    "480": (832, 480),
    "720": (1280, 720),
    "768": (1360, 768),
}

# Aspect ratios the framework accepts, as the comma-separated strings it wants.
# Note the format: "16,9" with a COMMA, not "16:9" and not a float. This trips
# people up constantly, so validate_spec() checks it explicitly.
ASPECT_RATIOS: tuple[str, ...] = ("16,9", "9,16", "1,1", "4,3", "3,4")

# Frame-count ceilings per resolution tier. These are practical single-H100
# limits derived from the documented per-model frame ranges combined with the
# 80 GB VRAM budget, NOT hard framework limits — the framework will happily
# accept a larger number and then run out of memory an hour in.
#
# Cost scales as (latent tokens) x (steps), and latent tokens scale with
# frames x width x height, so the ceiling drops roughly as the square of the
# resolution increase. Treat these as "will complete without drama"; Lesson 14
# has you find your own actual ceiling by measurement.
MAX_FRAMES_BY_TIER: dict[str, int] = {
    "256": 189,
    "480": 189,
    "720": 121,
    "768": 121,
}


def resolution_wh(tier: str, aspect_ratio: str = "16,9") -> tuple[int, int]:
    """Return (width, height) in pixels for a resolution tier string.

    The framework takes `resolution` as a string tier name plus a separate
    `aspect_ratio`, which surprises people who expect a pixel pair. Non-16:9
    ratios are derived from the tier's pixel budget so the area stays roughly
    constant — that is what actually drives cost.
    """
    base_w, base_h = RESOLUTION_TIERS.get(str(tier), RESOLUTION_TIERS["480"])
    if aspect_ratio in ("16,9", "16:9"):
        return base_w, base_h
    try:
        aw, ah = (float(x) for x in re.split(r"[,:]", aspect_ratio))
    except (ValueError, TypeError):
        return base_w, base_h
    pixels = base_w * base_h
    h = (pixels / (aw / ah)) ** 0.5
    w = h * (aw / ah)
    # Round to a multiple of 16; video encoders and patchifiers both want it.
    return (int(round(w / 16) * 16), int(round(h / 16) * 16))


# --------------------------------------------------------------------------
# Environment probing
# --------------------------------------------------------------------------
def _run(cmd: list[str], timeout: int = 20) -> str | None:
    """Run a command, return stdout stripped, or None if anything goes wrong.

    Deliberately swallows every failure mode. A probe that raises turns a
    diagnostic report into a traceback, which is the opposite of useful.
    """
    if not shutil.which(cmd[0]):
        return None
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=True)
        return out.stdout.strip()
    except (subprocess.SubprocessError, OSError):
        return None


@dataclass
class EnvReport:
    """Everything we could learn about this machine. Fields may be None."""

    # Host
    os_name: str = ""
    os_release: str = ""
    machine: str = ""
    libc: str = ""
    python_version: str = ""
    cpu_count: int | None = None
    ram_total_gb: float | None = None
    ram_available_gb: float | None = None
    disk_free_gb: float | None = None

    # GPU
    driver_version: str | None = None
    cuda_driver_version: str | None = None
    gpu_names: list[str] = field(default_factory=list)
    gpu_count: int = 0
    gpu_vram_total_gb: list[float] = field(default_factory=list)
    gpu_vram_free_gb: list[float] = field(default_factory=list)
    compute_capability: str | None = None
    visible_devices: str | None = None

    # Frameworks
    torch_version: str | None = None
    torch_cuda_version: str | None = None
    torch_cuda_available: bool = False
    bf16_supported: bool | None = None
    fp8_supported: bool | None = None
    flash_attn: str | None = None
    transformers_version: str | None = None

    # Tooling
    docker_available: bool = False
    docker_gpu_ok: bool | None = None
    nvcr_logged_in: bool | None = None
    uv_version: str | None = None
    git_lfs: bool = False
    ffmpeg: bool = False

    # Derived
    problems: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def save(self, path: Path | str) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2) + "\n")
        return path

    # -- readable summary --------------------------------------------------
    def summary(self) -> str:
        lines = ["Environment", "=" * 60]
        lines.append(f"  OS            {self.os_name} {self.os_release} ({self.machine})")
        lines.append(f"  Python        {self.python_version}")
        if self.cpu_count:
            lines.append(f"  CPUs          {self.cpu_count}")
        if self.ram_total_gb:
            lines.append(
                f"  Host RAM      {self.ram_total_gb:.0f} GB total, "
                f"{self.ram_available_gb:.0f} GB available"
            )
        if self.disk_free_gb is not None:
            lines.append(f"  Disk free     {self.disk_free_gb:.0f} GB")
        lines.append("")
        lines.append(f"  Driver        {self.driver_version or 'not detected'}")
        lines.append(f"  GPUs          {self.gpu_count}")
        for i, name in enumerate(self.gpu_names):
            vram = (
                f"{self.gpu_vram_total_gb[i]:.0f} GB"
                if i < len(self.gpu_vram_total_gb)
                else "unknown"
            )
            free = (
                f", {self.gpu_vram_free_gb[i]:.0f} GB free"
                if i < len(self.gpu_vram_free_gb)
                else ""
            )
            lines.append(f"    [{i}] {name} — {vram}{free}")
        if self.compute_capability:
            lines.append(f"  Compute cap.  {self.compute_capability}")
        lines.append("")
        lines.append(
            f"  torch         {self.torch_version or 'not installed'} "
            f"(CUDA {self.torch_cuda_version or '-'}), "
            f"available={self.torch_cuda_available}"
        )
        if self.flash_attn:
            lines.append(f"  flash-attn    {self.flash_attn}")
        lines.append(
            f"  docker        {'yes' if self.docker_available else 'no'}"
            + (f", GPU passthrough {'ok' if self.docker_gpu_ok else 'FAILED'}"
               if self.docker_available and self.docker_gpu_ok is not None else "")
        )
        lines.append(f"  uv            {self.uv_version or 'not installed'}")
        lines.append(
            f"  ffmpeg        {'yes' if self.ffmpeg else 'no'}   "
            f"git-lfs {'yes' if self.git_lfs else 'no'}"
        )

        if self.problems:
            lines += ["", "PROBLEMS (these will stop you)"]
            lines += [f"  ✗ {p}" for p in self.problems]
        if self.warnings:
            lines += ["", "Warnings (these will slow you down)"]
            lines += [f"  ! {w}" for w in self.warnings]
        if not self.problems and not self.warnings:
            lines += ["", "  No problems detected."]
        return "\n".join(lines)


def probe_environment(*, check_docker: bool = True) -> EnvReport:
    """Interrogate the machine and return a report. Never raises."""
    r = EnvReport()

    # -- host --------------------------------------------------------------
    r.os_name = platform.system()
    r.os_release = platform.release()
    r.machine = platform.machine()
    r.python_version = platform.python_version()
    try:
        r.libc = " ".join(platform.libc_ver())
    except Exception:
        r.libc = ""
    r.cpu_count = os.cpu_count()

    meminfo = Path("/proc/meminfo")
    if meminfo.exists():
        vals = {}
        for line in meminfo.read_text().splitlines():
            k, _, v = line.partition(":")
            m = re.search(r"(\d+)", v)
            if m:
                vals[k] = int(m.group(1)) / (1024**2)  # kB -> GiB
        r.ram_total_gb = vals.get("MemTotal")
        r.ram_available_gb = vals.get("MemAvailable")

    try:
        usage = shutil.disk_usage(COURSE_ROOT)
        r.disk_free_gb = usage.free / (1024**3)
    except OSError:
        pass

    # -- GPU via nvidia-smi ------------------------------------------------
    # On a discrete H100 these columns are all populated and truthful. (On
    # Grace-based unified-memory parts the memory columns read "Not Supported";
    # we handle that by falling through to torch rather than reporting zeros.)
    smi = _run([
        "nvidia-smi",
        "--query-gpu=name,driver_version,memory.total,memory.free,compute_cap",
        "--format=csv,noheader,nounits",
    ])
    if smi:
        for line in smi.splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) < 5:
                continue
            name, driver, total, free, cap = parts[:5]
            r.gpu_names.append(name)
            r.driver_version = driver
            for raw, target in ((total, r.gpu_vram_total_gb), (free, r.gpu_vram_free_gb)):
                try:
                    target.append(float(raw) / 1024)   # MiB -> GiB
                except ValueError:
                    pass                                # "Not Supported"
            r.compute_capability = cap
        r.gpu_count = len(r.gpu_names)

    ver = _run(["nvidia-smi", "--query", "--display=COMPUTE"])
    if ver:
        m = re.search(r"CUDA Version\s*:\s*([\d.]+)", ver)
        if m:
            r.cuda_driver_version = m.group(1)

    r.visible_devices = os.environ.get("CUDA_VISIBLE_DEVICES")

    # -- torch -------------------------------------------------------------
    try:
        import torch

        r.torch_version = torch.__version__
        r.torch_cuda_version = torch.version.cuda
        r.torch_cuda_available = bool(torch.cuda.is_available())
        if r.torch_cuda_available:
            if not r.gpu_names:
                r.gpu_count = torch.cuda.device_count()
                r.gpu_names = [
                    torch.cuda.get_device_name(i) for i in range(r.gpu_count)
                ]
            if not r.gpu_vram_total_gb:
                for i in range(torch.cuda.device_count()):
                    props = torch.cuda.get_device_properties(i)
                    r.gpu_vram_total_gb.append(props.total_memory / (1024**3))
            try:
                r.bf16_supported = torch.cuda.is_bf16_supported()
            except Exception:
                pass
            major, minor = torch.cuda.get_device_capability(0)
            r.compute_capability = r.compute_capability or f"{major}.{minor}"
            # FP8 tensor cores arrive with Hopper (sm_90) and Ada (sm_89).
            r.fp8_supported = (major, minor) >= (8, 9)
    except ImportError:
        pass
    except Exception as exc:                                  # pragma: no cover
        r.warnings.append(f"torch present but probing it failed: {exc}")

    for mod, attr in (("flash_attn", "flash_attn"), ("transformers", "transformers_version")):
        try:
            m = __import__(mod)
            setattr(r, attr, getattr(m, "__version__", "unknown"))
        except Exception:
            pass

    # -- tooling -----------------------------------------------------------
    r.uv_version = _run(["uv", "--version"])
    r.git_lfs = shutil.which("git-lfs") is not None
    r.ffmpeg = shutil.which("ffmpeg") is not None
    r.docker_available = shutil.which("docker") is not None

    if r.docker_available and check_docker:
        # Does the Docker daemon actually answer, and can a container see a GPU?
        info = _run(["docker", "info", "--format", "{{.ServerVersion}}"], timeout=30)
        if info is None:
            r.docker_available = False
            r.warnings.append(
                "the docker binary exists but the daemon did not respond — "
                "you may need to start it, or add yourself to the `docker` group"
            )
        else:
            gpu = _run(
                ["docker", "run", "--rm", "--gpus", "all",
                 "nvidia/cuda:12.8.0-base-ubuntu22.04", "nvidia-smi", "-L"],
                timeout=180,
            )
            r.docker_gpu_ok = gpu is not None and "GPU 0" in (gpu or "")

        cfg = Path.home() / ".docker" / "config.json"
        if cfg.exists():
            try:
                auths = json.loads(cfg.read_text()).get("auths", {})
                r.nvcr_logged_in = any("nvcr.io" in k for k in auths)
            except (json.JSONDecodeError, OSError):
                pass

    _assess(r)
    return r


def _assess(r: EnvReport) -> None:
    """Turn raw facts into problems and warnings a learner can act on.

    Kept separate from probing so the thresholds are readable and arguable,
    which is the point — Lesson 00 asks learners to argue with them.
    """
    P, W = r.problems, r.warnings

    if r.gpu_count == 0:
        P.append(
            "no NVIDIA GPU detected. Every lesson from 01 onward needs one. "
            "If you are on a cloud box, check that you rented a GPU instance "
            "and that the driver is installed (`nvidia-smi`)."
        )
    if r.machine not in ("x86_64", "AMD64"):
        W.append(
            f"CPU architecture is {r.machine}, not x86_64. This course was written "
            f"and validated for x86_64. Most things will work on aarch64, but the "
            f"Reasoner NIM image and some prebuilt wheels may not."
        )
    if not r.torch_cuda_available and r.gpu_count:
        P.append(
            "a GPU is present but torch cannot see it. Usually a CUDA/driver "
            "mismatch or a CPU-only torch build. Check `torch.version.cuda` "
            "against `nvidia-smi`'s CUDA version."
        )

    if r.gpu_vram_total_gb:
        vram = max(r.gpu_vram_total_gb)
        if vram < 20:
            P.append(
                f"largest GPU has {vram:.0f} GB of VRAM. Cosmos3-Edge inference "
                f"wants ~12 GB and Nano ~32 GB; below 20 GB you will not get far."
            )
        elif vram < 40:
            W.append(
                f"largest GPU has {vram:.0f} GB. Cosmos3-Edge will run; Nano "
                f"(needs ~32 GB) will be tight and Super is out of reach."
            )

    if r.compute_capability:
        try:
            cc = float(r.compute_capability)
            if cc < 8.0:
                P.append(
                    f"compute capability {cc} is below 8.0 (Ampere). Cosmos 3 needs "
                    f"Ampere or newer; bf16 is not available before it."
                )
            elif cc < 9.0:
                W.append(
                    f"compute capability {cc} — this is pre-Hopper. Everything runs, "
                    f"but FlashAttention-3 and FP8 paths that the H100 material "
                    f"assumes will fall back to slower kernels."
                )
        except ValueError:
            pass

    if r.disk_free_gb is not None and r.disk_free_gb < 60:
        (P if r.disk_free_gb < 25 else W).append(
            f"only {r.disk_free_gb:.0f} GB free. Budget ~25 GB for Edge alone, "
            f"~90 GB for the Hugging Face cache once Nano is pulled, plus ~20 GB "
            f"of uv cache and room for generated video."
        )

    if r.ram_total_gb is not None and r.ram_total_gb < 100:
        W.append(
            f"{r.ram_total_gb:.0f} GB of host RAM. Weight conversion and the "
            f"dataloader are host-memory hungry; below ~100 GB expect to reduce "
            f"dataloader workers."
        )

    if not r.docker_available:
        W.append(
            "docker not available. The Reasoner NIM (Lessons 02–05) needs it. "
            "The vLLM fallback documented in Lesson 02 does not."
        )
    elif r.docker_gpu_ok is False:
        P.append(
            "docker cannot reach the GPU. Install the NVIDIA Container Toolkit "
            "and restart the daemon, then re-run this probe."
        )
    if r.docker_available and r.nvcr_logged_in is False:
        W.append(
            "not logged in to nvcr.io. Run "
            "`echo $NGC_API_KEY | docker login nvcr.io -u '$oauthtoken' --password-stdin` "
            "before Lesson 02, or the NIM image pull will 401."
        )

    if not r.ffmpeg:
        W.append("ffmpeg not found. Video preview and transcoding cells will fail.")
    if r.uv_version is None:
        W.append("uv not found. scripts/setup.sh installs it; the framework venv needs it.")

    if r.visible_devices not in (None, ""):
        W.append(
            f"CUDA_VISIBLE_DEVICES is set to '{r.visible_devices}'. That is fine if "
            f"you meant it — but the source DLI notebooks pinned it to '1', which on "
            f"a single-GPU box hides your only GPU."
        )


# --------------------------------------------------------------------------
# Device selection
# --------------------------------------------------------------------------
def select_device(prefer: str | None = None) -> str:
    """Return a torch device string, explaining any fallback.

    Never silently falls back to CPU. A CPU fallback for a diffusion model is
    not a degraded experience, it is an unusable one, and a learner deserves to
    be told rather than left watching a progress bar for an hour.
    """
    if prefer:
        return prefer
    try:
        import torch
    except ImportError:
        print("torch is not installed — run scripts/setup.sh. Falling back to 'cpu'.")
        return "cpu"
    if torch.cuda.is_available():
        return "cuda"
    print(
        "No CUDA device visible, so this returns 'cpu'.\n"
        "  Cosmos 3 generation on CPU is not practical — a single 480p clip would\n"
        "  take hours. Fix the GPU before continuing:\n"
        "    1. `nvidia-smi` — does the driver see the card?\n"
        "    2. `python -c \"import torch; print(torch.version.cuda)\"` — CPU-only build?\n"
        "    3. `echo $CUDA_VISIBLE_DEVICES` — set to something that hides the GPU?"
    )
    return "cpu"


# --------------------------------------------------------------------------
# Budgeting
# --------------------------------------------------------------------------
def vram_budget(total_gb: float | None = None) -> dict[str, Any]:
    """Plan how to share one GPU between the Reasoner NIM and the generator.

    This is the central practical constraint of the course. On one 80 GB H100
    you cannot leave a NIM holding most of the card and also run Cosmos3-Nano
    generation, because the NIM's default behaviour is to reserve a large
    fraction of free VRAM for its KV cache at startup. Two workable strategies:

    * **Take turns** — stop the NIM before generation. Simplest, and what the
      course does by default.
    * **Cap the NIM** — start it with an explicit memory fraction so both fit.
      Cheaper in wall-clock time if you are alternating a lot; costs you KV
      cache, so long videos in a single reasoning request may not fit.

    Returns the numbers for both, so a learner can choose rather than be told.
    """
    if total_gb is None:
        try:
            import torch

            total_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
        except Exception:
            total_gb = 80.0

    nim_weights = 8.0     # nano reasoner at FP8, approximately
    reserve = 3.0         # CUDA context, fragmentation, cuDNN workspaces
    edge = MODEL_TIERS["Cosmos3-Edge"]["inference_vram_gb"]
    nano = MODEL_TIERS["Cosmos3-Nano"]["inference_vram_gb"]

    coexist_nano = total_gb - reserve - nano
    coexist_edge = total_gb - reserve - edge

    return {
        "total_gb": round(total_gb, 1),
        "reserve_gb": reserve,
        "nim_weights_fp8_gb": nim_weights,
        "generator": {"Cosmos3-Edge": edge, "Cosmos3-Nano": nano},
        "take_turns": {
            "nim_alone_fraction": round((total_gb - reserve) / total_gb, 2),
            "note": "Stop the NIM, then generate. No compromise on either side.",
        },
        "coexist_with_edge": {
            "nim_budget_gb": round(coexist_edge, 1),
            "nim_fraction": round(max(coexist_edge, 0) / total_gb, 2),
            "feasible": coexist_edge > nim_weights + 4,
        },
        "coexist_with_nano": {
            "nim_budget_gb": round(coexist_nano, 1),
            "nim_fraction": round(max(coexist_nano, 0) / total_gb, 2),
            "feasible": coexist_nano > nim_weights + 4,
        },
    }


def estimate_generation_cost(
    *,
    num_frames: int = 121,
    resolution: str = "480",
    num_steps: int = 35,
    aspect_ratio: str = "16,9",
    model: str = "Cosmos3-Edge",
) -> dict[str, Any]:
    """Relative cost of a generation job. Deliberately NOT a time prediction.

    Diffusion cost scales with (latent tokens) x (denoising steps). Both are
    knobs a learner controls, and the ratio between two configurations is
    stable across hardware even though the absolute seconds are not. So this
    returns a *unit count* and a ratio against a reference configuration.

    Lesson 06 calibrates units-per-second on the learner's own machine, after
    which this becomes a real time estimate for that machine only.
    """
    w, h = resolution_wh(resolution, aspect_ratio)
    # The Wan-family VAE used by Cosmos 3 compresses 8x spatially and 4x
    # temporally; the transformer then patchifies 2x2. Net: /16 in each spatial
    # dimension, /4 in time. Exact constants matter less than the scaling.
    latent_tokens = (w // 16) * (h // 16) * max(1, num_frames // 4)
    units = latent_tokens * num_steps

    ref_w, ref_h = resolution_wh("480", "16,9")
    ref_units = (ref_w // 16) * (ref_h // 16) * (121 // 4) * 35

    tier = MODEL_TIERS.get(model, MODEL_TIERS["Cosmos3-Edge"])
    max_tier = tier["max_resolution_tier"]
    warnings: list[str] = []
    if int(str(resolution)) > int(max_tier):
        warnings.append(
            f"{model} is documented up to {max_tier}p; you asked for {resolution}p."
        )
    lo, hi = tier["frames_range"]
    if not (lo <= num_frames <= hi):
        warnings.append(
            f"{model} is documented for {lo}–{hi} frames; you asked for {num_frames}."
        )

    return {
        "width": w,
        "height": h,
        "num_frames": num_frames,
        "num_steps": num_steps,
        "latent_tokens": latent_tokens,
        "cost_units": units,
        "relative_to_480p_121f_35s": round(units / ref_units, 2),
        "warnings": warnings,
    }


# --------------------------------------------------------------------------
# Guard rails for notebooks
# --------------------------------------------------------------------------
def require(condition: bool, message: str, *, fix: str | None = None) -> None:
    """Fail early and usefully.

    A notebook that dies twenty cells later with a KeyError has wasted the
    learner's afternoon. Assertions at the top of a lesson that say what is
    wrong AND what to do about it are worth the lines they cost.
    """
    if condition:
        return
    text = message if not fix else f"{message}\n\n  How to fix it: {fix}"
    raise RuntimeError(text)
