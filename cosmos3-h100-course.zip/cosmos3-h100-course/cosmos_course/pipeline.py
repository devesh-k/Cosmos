"""Plumbing for multi-stage pipelines that must survive being interrupted.

Lessons 00–18 each run one thing at a time, in a kernel you are watching. The
capstone runs six stages back to back, unattended, for the better part of an
hour, on a GPU that cannot hold both models at once. That changes what the code
has to do:

* **Work already done must not be redone.** A crash forty minutes in should cost
  you the current item, not the run.
* **A failure is a data point, not an exception.** A rejected clip, an OOM, a NIM
  that died and a model that returned prose where you asked for JSON are all
  *expected* and all different, and the pipeline should record which one happened
  and keep going.
* **Time has to be attributed.** "The run took 52 minutes" is useless. "Reason 4
  minutes, generate 31, validate 6, and 11 minutes of stopping and starting a
  container" is a decision.

None of that is Cosmos-specific, which is why it lives here rather than in a
notebook. Four things:

``Ledger``          append-only JSONL you can resume from
``StageClock``      wall-clock attribution across named stages
``DeviceSampler``   device-wide peak VRAM, including other processes
``run_stage``       run one unit of work, classify any failure, never raise

Everything is stdlib. Nothing here imports torch, so it works in a kernel that
has no GPU and in a cell that runs while the GPU is busy elsewhere.

    from cosmos_course import DeviceSampler, Ledger, StageClock, run_stage

    ledger = Ledger(OUTPUT_DIR / "manifest.jsonl", key_field="variant_id")
    clock = StageClock()

    for item in work:
        if ledger.has(item.id):          # resume: already done last time
            continue
        with clock.stage("generate"):
            outcome = run_stage("generate", lambda: make(item), key=item.id)
        ledger.append({"variant_id": item.id, "status": outcome.status_word(),
                       "reason": outcome.error or "ok"})
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator, Sequence

__all__ = [
    "Ledger",
    "StageClock",
    "DeviceSampler",
    "StageOutcome",
    "classify_error",
    "run_stage",
]


# ---------------------------------------------------------------------------
# Failure classification
# ---------------------------------------------------------------------------
# Four failure classes, because they need four different responses and a
# pipeline that lumps them together as "error" cannot choose between them:
#
#   oom        -> shrink the job and retry.  Retrying unchanged wastes the time.
#   service    -> the NIM or the subprocess is gone. Restart it, then retry.
#   malformed  -> the model answered, badly. Retry once with a stricter prompt;
#                 if it happens twice the prompt is wrong, not the model.
#   timeout    -> the job is too big for the budget. Shrink it, do not retry.
#   other      -> a bug in your code. Do not retry; you will just get it again.
#
# Matching is on the exception's *text* rather than its type, because the errors
# arrive from three different places (torch, an HTTP client, a subprocess whose
# traceback we only have as a string) and no common base class exists.
_ERROR_SIGNATURES: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("oom", re.compile(
        r"out of memory|CUDA out of memory|OutOfMemoryError|cuda(Malloc|Error)MemoryAllocation"
        r"|CUBLAS_STATUS_ALLOC_FAILED|no kernel image|not enough memory",
        re.IGNORECASE)),
    ("service", re.compile(
        r"connection (refused|reset|aborted|error)|failed to establish|max retries exceeded"
        r"|APIConnectionError|ConnectError|502 Bad Gateway|503 Service Unavailable"
        r"|remote end closed|container .* not running|Errno 111",
        re.IGNORECASE)),
    ("malformed", re.compile(
        r"JSONDecodeError|Expecting value|no JSON|could not parse|unterminated string"
        r"|is not valid JSON|missing key|422",
        re.IGNORECASE)),
    ("timeout", re.compile(
        r"\btimed? ?out\b|TimeoutError|ReadTimeout|timeout expired",
        re.IGNORECASE)),
)


def classify_error(exc: BaseException | str) -> str:
    """Bucket a failure into ``oom`` / ``service`` / ``malformed`` / ``timeout`` / ``other``.

    The bucket decides the response, so getting it roughly right matters more
    than getting it exactly right. When two patterns could match — a timeout
    while a container was dying, say — the first in ``_ERROR_SIGNATURES`` wins,
    and the order is deliberate: an OOM inside a request that then timed out is
    an OOM, and retrying it as a timeout would just OOM again.

    Never raises, and never returns None. An unrecognised failure is ``other``,
    which the pipeline treats as "do not retry" — the safe default, because the
    most common unrecognised failure is a bug in your own stage function.
    """
    text = exc if isinstance(exc, str) else f"{type(exc).__name__}: {exc}"
    for label, pattern in _ERROR_SIGNATURES:
        if pattern.search(text):
            return label
    return "other"


@dataclass
class StageOutcome:
    """What happened to one unit of work. Truthy when it succeeded."""

    name: str
    ok: bool
    seconds: float
    key: str | None = None
    value: Any = None
    error: str | None = None
    error_class: str | None = None
    peak_vram_gb: float | None = None

    def __bool__(self) -> bool:
        return self.ok

    def status_word(self) -> str:
        return "ok" if self.ok else (self.error_class or "error")

    def retryable(self) -> bool:
        """Is retrying this failure worth a second attempt?

        ``oom`` and ``timeout`` are excluded on purpose. Both mean the job did
        not fit in the resource you gave it, and re-running the identical job
        will not make it fit. Retry them only after *changing* something.
        """
        return (not self.ok) and self.error_class in {"service", "malformed"}

    def to_dict(self) -> dict[str, Any]:
        return {
            "stage": self.name,
            "key": self.key,
            "ok": self.ok,
            "seconds": round(self.seconds, 3),
            "error": self.error,
            "error_class": self.error_class,
            "peak_vram_gb": self.peak_vram_gb,
        }

    def __str__(self) -> str:
        if self.ok:
            return f"[ok]   {self.name}" + (f" {self.key}" if self.key else "") + \
                   f"  {self.seconds:.1f} s"
        return (f"[{self.error_class or 'error'}] {self.name}"
                + (f" {self.key}" if self.key else "")
                + f"  {self.seconds:.1f} s  {(self.error or '')[:120]}")


# ---------------------------------------------------------------------------
# Ledger
# ---------------------------------------------------------------------------
class Ledger:
    """An append-only JSONL file you can resume a pipeline from.

    Why append-only rather than "write the results dict at the end": because the
    end is exactly what you do not reach when something goes wrong. A file that
    is only correct once the process exits cleanly is not a checkpoint.

    Each record is one line of JSON carrying a unique key. ``has()`` answers "did
    I already do this?", which is the whole resume mechanism — the pipeline loops
    over the work it *wants*, skips what the ledger already holds, and does the
    rest. Killing the kernel mid-run therefore costs you the item in flight and
    nothing else.

    Two design choices worth knowing:

    * **Every append is flushed and fsynced.** That costs a millisecond or two
      per record and buys you the guarantee that a `kill -9` cannot lose a
      completed item. At the scale this course runs at, the trade is free.
    * **Re-recording a key appends a second line rather than rewriting.** The
      file stays append-only; ``get()`` and ``records()`` return the *last*
      record for a key. You keep the history of a retry, which is exactly what
      you want when writing up why something needed two attempts.
    """

    def __init__(self, path: Path | str, *, key_field: str = "key"):
        self.path = Path(path)
        self.key_field = key_field
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._index: dict[str, dict[str, Any]] = {}
        self._order: list[str] = []
        self._malformed: int = 0
        self.reload()

    # -- reading ------------------------------------------------------------
    def reload(self) -> "Ledger":
        """Re-read the file from disk. Tolerates a truncated final line.

        A truncated last line is the normal signature of a process killed
        mid-write. Dropping it and counting it is right; raising would make the
        ledger unreadable at exactly the moment you need to resume from it.
        """
        self._index.clear()
        self._order.clear()
        self._malformed = 0
        if not self.path.exists():
            return self
        for line in self.path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                self._malformed += 1
                continue
            key = str(record.get(self.key_field, ""))
            if not key:
                self._malformed += 1
                continue
            if key not in self._index:
                self._order.append(key)
            self._index[key] = record
        return self

    @property
    def malformed_lines(self) -> int:
        """Lines that could not be parsed. Non-zero after an unclean kill."""
        return self._malformed

    def has(self, key: str) -> bool:
        return str(key) in self._index

    def get(self, key: str) -> dict[str, Any] | None:
        return self._index.get(str(key))

    def records(self) -> list[dict[str, Any]]:
        """Latest record per key, in first-seen order."""
        return [self._index[k] for k in self._order]

    def __len__(self) -> int:
        return len(self._index)

    def __iter__(self) -> Iterator[dict[str, Any]]:
        return iter(self.records())

    def pending(self, keys: Iterable[str]) -> list[str]:
        """Which of ``keys`` this ledger has never seen. The resume list."""
        return [str(k) for k in keys if not self.has(k)]

    def counts(self, field_name: str = "status") -> dict[str, int]:
        """Tally one field across the latest record per key."""
        tally: dict[str, int] = {}
        for record in self.records():
            value = str(record.get(field_name, "unknown"))
            tally[value] = tally.get(value, 0) + 1
        return dict(sorted(tally.items()))

    def select(self, **equals: Any) -> list[dict[str, Any]]:
        """Records whose fields all equal the given values."""
        return [r for r in self.records()
                if all(r.get(k) == v for k, v in equals.items())]

    # -- writing ------------------------------------------------------------
    def append(self, record: dict[str, Any]) -> dict[str, Any]:
        """Append one record and make it durable before returning."""
        if self.key_field not in record:
            raise KeyError(
                f"every ledger record needs a {self.key_field!r} field; got "
                f"{sorted(record)}"
            )
        key = str(record[self.key_field])
        line = json.dumps(record, ensure_ascii=False, default=str)
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        if key not in self._index:
            self._order.append(key)
        self._index[key] = record
        return record

    def record_once(self, record: dict[str, Any]) -> bool:
        """Append only if the key is new. Returns True if it was written."""
        key = str(record.get(self.key_field, ""))
        if key and self.has(key):
            return False
        self.append(record)
        return True

    def rewrite(self) -> Path:
        """Compact the file to one line per key. Optional; call it at the end.

        Only ever do this when nothing is writing. It exists so the deliverable
        manifest is one record per clip rather than a retry history, and it keeps
        the pre-compaction file next to it as ``.jsonl.raw``.
        """
        if self.path.exists():
            shutil.copy2(self.path, self.path.with_suffix(self.path.suffix + ".raw"))
        body = "\n".join(
            json.dumps(r, ensure_ascii=False, default=str) for r in self.records()
        )
        self.path.write_text(body + ("\n" if body else ""), encoding="utf-8")
        return self.path

    def summary(self, field_name: str = "status") -> str:
        counts = self.counts(field_name)
        total = sum(counts.values())
        parts = ", ".join(f"{k} {v}" for k, v in counts.items()) or "empty"
        extra = f", {self._malformed} unreadable line(s)" if self._malformed else ""
        return f"{self.path.name}: {total} record(s) — {parts}{extra}"


# ---------------------------------------------------------------------------
# StageClock
# ---------------------------------------------------------------------------
class StageClock:
    """Wall-clock attribution across named stages.

    A single total tells you nothing you can act on. This accumulates seconds
    per named stage so the report can say which stage to attack, and — more
    importantly for a single-GPU pipeline — how much of the run was neither
    reasoning nor generating but *switching between them*.

    Nested stages are not supported on purpose. Attributing a second to two
    stages at once produces totals that do not add up to the wall clock, and a
    reader who notices spends their time on the arithmetic instead of the result.
    """

    def __init__(self) -> None:
        self._totals: dict[str, float] = {}
        self._counts: dict[str, int] = {}
        self._depth = 0
        self.started = time.perf_counter()

    @contextmanager
    def stage(self, name: str) -> Iterator[None]:
        if self._depth:
            raise RuntimeError(
                "StageClock.stage() is not re-entrant — nesting would double-count "
                "seconds and the totals would exceed the wall clock. Time the "
                "inner block with cosmos_course.timer() instead."
            )
        self._depth += 1
        start = time.perf_counter()
        try:
            yield
        finally:
            self._depth -= 1
            self.add(name, time.perf_counter() - start)

    def add(self, name: str, seconds: float) -> None:
        self._totals[name] = self._totals.get(name, 0.0) + float(seconds)
        self._counts[name] = self._counts.get(name, 0) + 1

    def totals(self) -> dict[str, float]:
        return {k: round(v, 3) for k, v in sorted(self._totals.items())}

    def counts(self) -> dict[str, int]:
        return dict(sorted(self._counts.items()))

    @property
    def accounted_seconds(self) -> float:
        """Seconds inside a named stage. Less than the wall clock."""
        return sum(self._totals.values())

    @property
    def wall_seconds(self) -> float:
        """Seconds since this clock was created, stages or not."""
        return time.perf_counter() - self.started

    def fraction(self, name: str) -> float | None:
        """One stage as a fraction of the accounted total."""
        total = self.accounted_seconds
        if total <= 0 or name not in self._totals:
            return None
        return self._totals[name] / total

    def to_dict(self) -> dict[str, Any]:
        return {
            "stage_seconds": self.totals(),
            "stage_calls": self.counts(),
            "accounted_seconds": round(self.accounted_seconds, 3),
            "wall_seconds": round(self.wall_seconds, 3),
            "unaccounted_seconds": round(
                max(0.0, self.wall_seconds - self.accounted_seconds), 3),
        }

    def table(self) -> str:
        total = self.accounted_seconds or 1.0
        rows = [f"{'stage':<16}{'seconds':>10}{'calls':>7}{'share':>8}"]
        for name, seconds in sorted(self._totals.items(), key=lambda kv: -kv[1]):
            rows.append(f"{name:<16}{seconds:>10.1f}{self._counts[name]:>7}"
                        f"{seconds / total:>7.0%}")
        rows.append(f"{'-' * 41}")
        rows.append(f"{'accounted':<16}{self.accounted_seconds:>10.1f}")
        rows.append(f"{'wall clock':<16}{self.wall_seconds:>10.1f}")
        return "\n".join(rows)


# ---------------------------------------------------------------------------
# DeviceSampler
# ---------------------------------------------------------------------------
class DeviceSampler:
    """Poll device-wide VRAM on a background thread. Peak and baseline in GB.

    ``torch.cuda.max_memory_allocated()`` only sees allocations made by *this*
    process. Two of the capstone's stages are not this process — generation is a
    ``torchrun`` subprocess and the reasoner is a container — so from the
    notebook's point of view they use no memory at all. This asks the driver
    instead, which sees everything on the card.

    Lessons 06 through 15 each define a private copy of this class inline,
    because at that point in the course seeing the sampler is part of the lesson.
    By the capstone it is plumbing, so here it is, once.

    Units are decimal GB (``nvidia-smi`` reports MiB; the conversion is
    ``MiB * 1024**2 / 1e9``), matching ``cosmos_course.measure``. Returns None
    rather than raising if ``nvidia-smi`` is missing, like every other probe in
    this package.
    """

    def __init__(self, interval: float = 1.0, index: int = 0):
        self.interval = float(interval)
        self.index = int(index)
        self.samples: list[float] = []
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def read_gb(self) -> float | None:
        if not shutil.which("nvidia-smi"):
            return None
        try:
            out = subprocess.run(
                ["nvidia-smi", f"--id={self.index}", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            return float(out.strip().splitlines()[0]) * (1024 ** 2) / 1e9
        except (subprocess.SubprocessError, OSError, ValueError, IndexError):
            return None

    def _loop(self) -> None:
        while not self._stop.wait(self.interval):
            value = self.read_gb()
            if value is not None:
                self.samples.append(value)

    def __enter__(self) -> "DeviceSampler":
        first = self.read_gb()
        self.samples = [first] if first is not None else []
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc: Any) -> bool:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
        return False

    @property
    def baseline_gb(self) -> float | None:
        """The reading taken before the work started."""
        return self.samples[0] if self.samples else None

    @property
    def peak_gb(self) -> float | None:
        return max(self.samples) if self.samples else None

    @property
    def delta_gb(self) -> float | None:
        """Peak minus baseline — what *this* work added to the card."""
        if not self.samples:
            return None
        return max(self.samples) - self.samples[0]


# ---------------------------------------------------------------------------
# run_stage
# ---------------------------------------------------------------------------
def run_stage(
    name: str,
    fn: Callable[[], Any],
    *,
    key: str | None = None,
    clock: StageClock | None = None,
    sample_vram: bool = False,
    retries: int = 0,
    on_retry: Callable[[StageOutcome], None] | None = None,
    quiet: bool = False,
) -> StageOutcome:
    """Run one unit of work and return a ``StageOutcome``. Never raises.

    This is the difference between a pipeline and a script. A script propagates
    the exception and you lose the loop; a pipeline records what went wrong,
    classifies it, and carries on with the next item. The caller decides what a
    failure means — that decision is not something a helper should make for you.

    ``retries`` only applies to failures ``StageOutcome.retryable()`` accepts,
    which is ``service`` and ``malformed``. An OOM or a timeout is retried zero
    times whatever you pass, because re-running an identical job that did not fit
    will not make it fit; ``on_retry`` is the hook where you *change* something
    (restart the NIM, shrink the batch) before the next attempt.

    ``KeyboardInterrupt`` and ``SystemExit`` are deliberately not caught. When
    you press stop, the pipeline should stop.
    """
    attempt = 0
    while True:
        sampler: DeviceSampler | None = None
        started = time.perf_counter()
        try:
            if sample_vram:
                with DeviceSampler() as sampler:
                    value = fn()
            else:
                value = fn()
        except (KeyboardInterrupt, SystemExit):
            raise
        except BaseException as exc:  # noqa: BLE001 — classification is the point
            outcome = StageOutcome(
                name=name, ok=False, seconds=time.perf_counter() - started, key=key,
                error=f"{type(exc).__name__}: {exc}"[:800],
                error_class=classify_error(exc),
                peak_vram_gb=sampler.peak_gb if sampler else None,
            )
        else:
            outcome = StageOutcome(
                name=name, ok=True, seconds=time.perf_counter() - started, key=key,
                value=value, peak_vram_gb=sampler.peak_gb if sampler else None,
            )

        if clock is not None:
            clock.add(name, outcome.seconds)
        if not quiet:
            print(outcome)

        if outcome.ok or attempt >= retries or not outcome.retryable():
            return outcome

        attempt += 1
        if not quiet:
            print(f"  retry {attempt}/{retries} after a {outcome.error_class} failure")
        if on_retry is not None:
            on_retry(outcome)


def stage_table(outcomes: Sequence[StageOutcome]) -> str:
    """A small summary of many outcomes, grouped by stage and failure class."""
    by_stage: dict[str, dict[str, int]] = {}
    seconds: dict[str, float] = {}
    for outcome in outcomes:
        bucket = by_stage.setdefault(outcome.name, {})
        word = outcome.status_word()
        bucket[word] = bucket.get(word, 0) + 1
        seconds[outcome.name] = seconds.get(outcome.name, 0.0) + outcome.seconds
    rows = [f"{'stage':<16}{'seconds':>10}  outcomes"]
    for stage_name, bucket in by_stage.items():
        detail = ", ".join(f"{k} {v}" for k, v in sorted(bucket.items()))
        rows.append(f"{stage_name:<16}{seconds[stage_name]:>10.1f}  {detail}")
    return "\n".join(rows)


__all__.append("stage_table")
