"""Post-training helpers, and the memory arithmetic that decides what is possible.

Read this module before Lesson 17. It is the honest core of the post-training
material, and the honesty is the point.

The situation, stated plainly
-----------------------------
**NVIDIA documents no single-GPU training path for Cosmos 3.** Every shipped
recipe in ``cosmos-framework/examples/`` is an 8-GPU configuration, tested on
8x H100 80 GB. The action-policy LIBERO recipes assume HSDP 2x8, i.e. sixteen
GPUs across two nodes. The DROID reproduction used 256 ranks. The smallest
claim NVIDIA makes anywhere is that the Cosmos3-Edge vision recipe "also fits
a 4-GPU node".

You have one GPU. So the question this module answers is not "how do I run the
recipe" but "what part of the recipe can I run, and how would I know?"

Why the recipes need so many GPUs
---------------------------------
Not activations. Optimizer state. For a full-parameter fine-tune with AdamW in
mixed precision, every parameter carries:

===================================  ==========
component                            bytes/param
===================================  ==========
bf16 weights (forward/backward)      2
fp32 master copy                     4
AdamW first moment ``m`` (fp32)      4
AdamW second moment ``v`` (fp32)     4
gradients (bf16 or fp32)             2-4
EMA copy, if enabled (fp32)          4
===================================  ==========

That is 16-22 bytes per trainable parameter *before a single activation*. For
Cosmos3-Nano's 16 billion parameters that is roughly 256-350 GB, which is why
the shipped recipe shards across sixteen ranks: 256/16 is about 16 GB each,
leaving room to actually compute something.

This matters more than it might seem, because it tells you which knobs work.
Activation checkpointing trades compute for activation memory — and activations
are not your problem. Turning it up will not save you. What saves you is
reducing the number of *trainable* parameters, which is what
``optimizer.keys_to_select`` and LoRA both do.

What can plausibly run on one H100
----------------------------------
``vision_sft_edge``. Cosmos3-Edge is 4B, and the shipped recipe already trains
only the generation pathway via
``keys_to_select = ["moe_gen","time_embedder","vae2llm","llm2vae","k_norm_und_for_gen"]``,
so roughly 2B parameters carry optimizer state. Estimated state is 45-50 GB,
leaving about 30 GB for activations on an 80 GB card — *provided* you disable
EMA, disable ``torch.compile``, and cut ``max_num_tokens_after_packing`` well
below its 8-GPU value of 45,056.

**This is undocumented and unvalidated by NVIDIA.** Lesson 17 treats it as an
experiment with a predicted outcome, not a promise. ``estimate_sft_memory()``
below is how you make the prediction before you spend an hour finding out.

Levers, and which ones you actually have
----------------------------------------
The framework FAQ gives an OOM ladder for SFT. Reproduced here with a note on
each, because two of the six are useless to you:

1. ``PYTORCH_ALLOC_CONF=expandable_segments:True`` — works, free, do it always.
2. Activation checkpointing ``full`` — works, costs ~30% throughput.
3. Raise FSDP shard degree — **needs more GPUs. Not available.**
4. Raise context-parallel degree — **needs more GPUs. Not available.**
5. Lower ``max_samples_per_batch`` — works; compensate with ``grad_accum_iter``.
6. Enable LoRA — works, and is the single biggest lever you have.

Not available at all: there is **no CPU offload** of parameters, optimizer state
or activations anywhere in ``SFTExperimentConfig``, and **no 8-bit optimizer**.
Only fused AdamW. If you have used DeepSpeed ZeRO-Offload or bitsandbytes to
squeeze a large model onto one card, neither trick is on the table here.

LoRA is generator-only
----------------------
``model.lora_enabled`` and friends are first-class, but the path-remapping table
explicitly skips ``model.lora_*`` on the VLM (reasoner) path. So you can LoRA the
generator and you cannot LoRA the reasoner. Default target modules are the
generator attention projections (``q_proj_moe_gen`` and siblings), which is also
why LoRA on the *action* path is untested: action heads initialise fresh and are
not covered by those defaults.

Sources
-------
``cosmos-framework`` ``docs/training.md``, ``docs/sft_config.md``, ``docs/faq.md``,
``docs/dataset_jsonl.md``, ``docs/action_policy_libero_posttrain.md``,
``examples/_sft_launcher_common.sh``, ``examples/toml/sft_config/*.toml``.
See ``assets/reference/COSMOS3_FACTS.md`` §5 for the full citation list.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from .config import COSMOS3_REPO, MODEL_TIERS

__all__ = [
    "BYTES_PER_PARAM",
    "SHIPPED_RECIPES",
    "DATASETS",
    "MemoryEstimate",
    "estimate_sft_memory",
    "single_gpu_overrides",
    "explain_recipe",
    "build_train_command",
    "check_dataset",
    "read_toml",
    "TrainingWatch",
]

# ---------------------------------------------------------------------------
# The arithmetic
# ---------------------------------------------------------------------------
# Bytes of state per TRAINABLE parameter, by component. Frozen parameters cost
# only their bf16 forward copy, which is why freezing is so much more effective
# than any activation trick.
BYTES_PER_PARAM: dict[str, int] = {
    "weights_bf16": 2,      # paid by every parameter, frozen or not
    "master_fp32": 4,       # trainable only
    "adam_m_fp32": 4,       # trainable only
    "adam_v_fp32": 4,       # trainable only
    "grads": 4,             # trainable only; conservative (fp32 accumulation)
    "ema_fp32": 4,          # trainable only, and only if ema.enabled
}


@dataclass
class MemoryEstimate:
    """A prediction, with its working shown, so you can argue with it."""

    model: str
    total_params_b: float
    trainable_params_b: float
    lora: bool
    ema: bool
    components_gb: dict[str, float] = field(default_factory=dict)
    state_gb: float = 0.0
    activation_budget_gb: float = 0.0
    card_gb: float = 80.0
    reserve_gb: float = 4.0
    verdict: str = ""
    notes: list[str] = field(default_factory=list)

    def __str__(self) -> str:
        lines = [
            f"SFT memory estimate — {self.model}",
            "=" * 62,
            f"  total parameters      {self.total_params_b:>6.1f} B",
            f"  trainable parameters  {self.trainable_params_b:>6.2f} B"
            + ("  (LoRA adapters only)" if self.lora else ""),
            "",
        ]
        for name, gb in self.components_gb.items():
            lines.append(f"    {name:<24s} {gb:>7.1f} GB")
        lines += [
            "    " + "-" * 32,
            f"    {'state subtotal':<24s} {self.state_gb:>7.1f} GB",
            "",
            f"  card                  {self.card_gb:>6.1f} GB",
            f"  reserve (ctx, frag)   {self.reserve_gb:>6.1f} GB",
            f"  left for activations  {self.activation_budget_gb:>6.1f} GB",
            "",
            f"  VERDICT: {self.verdict}",
        ]
        for n in self.notes:
            lines.append(f"    - {n}")
        return "\n".join(lines)

    @property
    def feasible(self) -> bool:
        return self.activation_budget_gb > 0


def estimate_sft_memory(
    model: str = "Cosmos3-Edge",
    *,
    trainable_fraction: float = 0.5,
    lora: bool = False,
    lora_rank: int = 16,
    ema: bool = True,
    card_gb: float | None = None,
    reserve_gb: float = 4.0,
    world_size: int = 1,
) -> MemoryEstimate:
    """Predict whether an SFT configuration fits, and show the working.

    Parameters
    ----------
    model
        A key of ``MODEL_TIERS``.
    trainable_fraction
        Fraction of total parameters that carry optimizer state. The shipped
        vision recipes restrict this with ``optimizer.keys_to_select``; for
        ``vision_sft_edge`` roughly half the model (the generation pathway)
        trains, hence the 0.5 default. Set 1.0 for a genuine full fine-tune —
        which is what the action-policy recipes do.
    lora
        If True, trainable parameters become the adapter parameters only. The
        estimate uses a rank-proportional approximation; the true count depends
        on which modules are targeted, so treat it as an order of magnitude.
    ema
        Whether ``model.ema.enabled`` is left at its default of True. This is
        the most commonly missed line item: it is a second fp32 copy of every
        trainable parameter, for no training benefit you will observe in a
        500-iteration lab run.
    world_size
        Number of GPUs to shard state across (FSDP). Default 1, because that is
        what you have. Set it to 8 or 16 to see why the shipped recipes are
        shaped the way they are.

    Notes
    -----
    This estimate covers *state*, not activations. Activation memory depends on
    ``max_num_tokens_after_packing``, batch size and checkpointing mode, and is
    far harder to predict than to measure. So the estimate tells you how much
    room is left, and the lesson has you measure whether that is enough.
    """
    tier = MODEL_TIERS.get(model)
    if tier is None:
        raise KeyError(
            f"unknown model {model!r}; expected one of {sorted(MODEL_TIERS)}"
        )
    if card_gb is None:
        try:
            import torch

            card_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
        except Exception:
            card_gb = 80.0

    total_b = float(tier["params_total_b"])

    if lora:
        # Rank-r adapters on the attention projections. The true parameter count
        # is 2 * r * d per targeted matrix; across a transformer this lands
        # within a small multiple of 0.1% of the base model per unit of rank/16.
        trainable_b = total_b * 0.001 * (lora_rank / 16)
    else:
        trainable_b = total_b * trainable_fraction

    GB = 1e9  # decimal GB, matching how Hugging Face reports repo sizes
    comp: dict[str, float] = {
        "bf16 weights (all params)": total_b * 1e9 * BYTES_PER_PARAM["weights_bf16"] / GB,
        "fp32 master (trainable)": trainable_b * 1e9 * BYTES_PER_PARAM["master_fp32"] / GB,
        "AdamW m (trainable)": trainable_b * 1e9 * BYTES_PER_PARAM["adam_m_fp32"] / GB,
        "AdamW v (trainable)": trainable_b * 1e9 * BYTES_PER_PARAM["adam_v_fp32"] / GB,
        "gradients (trainable)": trainable_b * 1e9 * BYTES_PER_PARAM["grads"] / GB,
    }
    if ema:
        comp["EMA fp32 copy"] = trainable_b * 1e9 * BYTES_PER_PARAM["ema_fp32"] / GB

    # FSDP shards everything except the transient full-parameter gather. This is
    # a simplification -- real FSDP holds one unsharded layer at a time -- but it
    # is the right first-order model for "why sixteen ranks".
    if world_size > 1:
        comp = {k: v / world_size for k, v in comp.items()}

    state = sum(comp.values())
    budget = card_gb - reserve_gb - state

    est = MemoryEstimate(
        model=model,
        total_params_b=total_b,
        trainable_params_b=trainable_b,
        lora=lora,
        ema=ema,
        components_gb={k: round(v, 1) for k, v in comp.items()},
        state_gb=round(state, 1),
        activation_budget_gb=round(budget, 1),
        card_gb=round(card_gb, 1),
        reserve_gb=reserve_gb,
    )

    if budget <= 0:
        est.verdict = (
            f"WILL NOT FIT. State alone needs {state:.0f} GB on a {card_gb:.0f} GB card."
        )
        # Ceiling division on state alone gives the ABSOLUTE floor. Real recipes
        # use more, because sharded state must still leave room for activations
        # -- the shipped LIBERO recipe uses 16 ranks where state alone would
        # suggest 5. Say both numbers, or the estimate teaches the wrong lesson.
        floor = int(-(-state / max(card_gb - reserve_gb, 1)))
        est.notes.append(
            f"Sharding state alone would need at least {floor} GPUs. Shipped recipes "
            f"use considerably more ({SHIPPED_RECIPES['action_policy_libero_10_nano']['documented_gpus']} "
            f"for the LIBERO action recipe) because each rank must also hold "
            f"activations, gradients in flight, and the dataloader."
        )
        if not lora:
            est.notes.append(
                "Try lora=True. It is the only lever that changes this number by "
                "an order of magnitude on a single card."
            )
        if ema:
            est.notes.append("Setting ema=False removes a whole fp32 copy for free.")
    elif budget < 10:
        est.verdict = (
            f"TIGHT. {budget:.0f} GB left for activations — expect to OOM unless you "
            f"cut max_num_tokens_after_packing hard."
        )
        est.notes.append("Set PYTORCH_ALLOC_CONF=expandable_segments:True before you start.")
        est.notes.append("Use activation_checkpointing.mode='full'.")
    else:
        est.verdict = f"PLAUSIBLE. {budget:.0f} GB left for activations."
        est.notes.append(
            "Plausible is not proven. Activation memory scales with the token cap; "
            "start low and raise it until it fails, then back off."
        )

    if ema and not lora:
        est.notes.append(
            "ema.enabled defaults to True in the shipped TOMLs. For a short lab run "
            "it buys nothing and costs a full fp32 copy."
        )
    return est


# ---------------------------------------------------------------------------
# The shipped recipes, described honestly
# ---------------------------------------------------------------------------
SHIPPED_RECIPES: dict[str, dict[str, Any]] = {
    "vision_sft_edge": {
        "toml": "examples/toml/sft_config/vision_sft_edge.toml",
        "launcher": "examples/launch_sft_vision_edge.sh",
        "base_model": "Cosmos3-Edge",
        "task": "vfm",
        "documented_gpus": 8,
        "smallest_documented": 4,
        "trainable": "generation pathway only (keys_to_select)",
        "dataset": "nvidia/BridgeData2-Subset-Synthetic-Captions",
        "dataset_gb": 0.65,
        "max_iter": 500,
        "save_iter": 100,
        "lr": 1.0e-4,
        "token_cap": 45056,
        "single_gpu": "plausible with overrides — this is the course's lab recipe",
    },
    "vision_sft_nano": {
        "toml": "examples/toml/sft_config/vision_sft_nano.toml",
        "launcher": "examples/launch_sft_vision_nano.sh",
        "base_model": "Cosmos3-Nano",
        "task": "vfm",
        "documented_gpus": 8,
        "smallest_documented": 8,
        "trainable": "generation pathway only (keys_to_select)",
        "dataset": "nvidia/BridgeData2-Subset-Synthetic-Captions",
        "dataset_gb": 0.65,
        "lr": 2.0e-5,
        "single_gpu": "no — ~8B trainable is 160-190 GB of state",
    },
    "vision_sft_super": {
        "toml": "examples/toml/sft_config/vision_sft_super.toml",
        "base_model": "Cosmos3-Super",
        "task": "vfm",
        "documented_gpus": 8,
        "trainable": "LoRA only",
        "lr": 5.0e-4,
        "single_gpu": "no — the 133 GB checkpoint does not fit, adapters or not",
    },
    "action_policy_libero_10_nano": {
        "toml": "examples/toml/sft_config/action_policy_libero_10_nano.toml",
        "base_model": "Cosmos3-Nano",
        "task": "vfm",
        "documented_gpus": 16,          # HSDP 2x8, two nodes
        "trainable": "EVERYTHING — keys_to_select is empty, so this is a full 16B SFT",
        "dataset": "nvidia/LIBERO_LeRobot_v3 (libero_10)",
        "dataset_gb": 0.5,
        "max_iter": 2000,
        "save_iter": 500,
        "lr": 5.0e-5,
        "token_cap": 74000,
        "single_gpu": "no — 256-350 GB of state. Read estimate_sft_memory() output.",
    },
    "sft_llava_ov": {
        "toml": "examples/toml/sft_config/sft_llava_ov.toml",
        "launcher": "examples/launch_sft_llava_ov.sh",
        "base_model": "Qwen/Qwen3-VL-8B-Instruct (reasoner backbone)",
        "task": "vlm",
        "documented_gpus": 8,
        "trainable": "full — LoRA is not available on the VLM path",
        "dataset": "lmms-lab/LLaVA-OneVision-Data (streamed)",
        "single_gpu": "no — 8B full fine-tune, and no LoRA escape hatch",
        "note": "Lowest-friction recipe: no DCP conversion, no required env vars.",
    },
}

DATASETS: dict[str, dict[str, Any]] = {
    "bridge": {
        "hf_repo": "nvidia/BridgeData2-Subset-Synthetic-Captions",
        "kind": "generator JSONL",
        "size_gb": 0.65,
        "items": "1,222 train clips + 51 val, 256x256 MP4 with synthetic captions",
        "verdict": "best lab choice — smallest shipped dataset by a wide margin",
    },
    "libero_10": {
        "hf_repo": "nvidia/LIBERO_LeRobot_v3",
        "subset": "libero_10",
        "kind": "LeRobotDataset v3.0",
        "size_gb": 0.5,
        "items": "379 episodes, 101,469 frames, 10 tasks, 20 FPS",
        "verdict": "good for action work; the whole repo is only 4.5 GB",
    },
    "libero_all": {
        "hf_repo": "nvidia/LIBERO_LeRobot_v3",
        "subset": "spatial+object+goal+10",
        "kind": "LeRobotDataset v3.0",
        "size_gb": 4.5,
        "items": "5,614 episodes across 113 tasks (note: libero_90 is NOT included)",
        "verdict": "fine to download whole; 5000 iterations to converge",
    },
    "droid": {
        "hf_repo": "nvidia/Cosmos3-DROID",
        "kind": "LeRobotDataset v3.0",
        "size_gb": 707.0,
        "items": "57,639 success episodes, 18.7M frames",
        "verdict": "disqualifying for a lab. No small subset is published.",
    },
}


def explain_recipe(name: str) -> str:
    """Describe a shipped recipe, including whether you can run it. Never lies."""
    r = SHIPPED_RECIPES.get(name)
    if r is None:
        return (
            f"Unknown recipe {name!r}. Known: {', '.join(sorted(SHIPPED_RECIPES))}\n"
            f"List what your checkout actually ships with:\n"
            f"  ls {COSMOS3_REPO}/examples/toml/sft_config/"
        )
    lines = [f"{name}", "=" * max(len(name), 62)]
    for key in ("base_model", "task", "trainable", "dataset", "dataset_gb",
                "documented_gpus", "max_iter", "lr", "token_cap", "toml", "launcher"):
        if key in r:
            lines.append(f"  {key:<20s} {r[key]}")
    lines += ["", f"  On ONE H100: {r['single_gpu']}"]
    if "note" in r:
        lines.append(f"  Note: {r['note']}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Shrinking an 8-GPU recipe to one GPU
# ---------------------------------------------------------------------------
def single_gpu_overrides(
    *,
    token_cap: int = 12288,
    grad_accum: int = 8,
    max_iter: int = 100,
    save_iter: int = 50,
    lora: bool = False,
    lora_rank: int = 16,
) -> dict[str, Any]:
    """Hydra-style overrides that make a shipped recipe attempt one GPU.

    These are **not documented by NVIDIA**. They are the course's reasoned
    starting point, derived from the FAQ's OOM ladder minus the two rungs that
    require more GPUs. Expect to tune ``token_cap``: start low, raise it until
    training OOMs, then back off by a third.

    Why each one:

    ``ema.enabled=false``
        A second fp32 copy of every trainable parameter, bought for nothing in a
        100-iteration run. This is the single largest free saving.
    ``compile.enabled=false``
        ``torch.compile`` on a shape configuration nobody has compiled before is
        a common first-run failure, and it trades memory for speed — the wrong
        direction here.
    ``max_num_tokens_after_packing``
        The activation driver. Sized for 8-way sharding in the shipped TOML.
    ``grad_accum_iter``
        Recovers the effective batch size you lose by shrinking the per-rank
        batch, at the cost of wall-clock time. The gradient is mathematically
        equivalent; the throughput is not.
    ``data_parallel_shard_degree=-1``
        Auto-fits ``WORLD_SIZE``, which is 1. Already the default in most
        shipped TOMLs, set explicitly here so the intent is visible.
    """
    ov: dict[str, Any] = {
        "model.config.ema.enabled": False,
        "model.config.compile.enabled": False,
        "model.config.activation_checkpointing.mode": "full",
        "model.config.max_num_tokens_after_packing": token_cap,
        "dataloader_train.max_sequence_length": token_cap,
        "model.config.parallelism.data_parallel_shard_degree": -1,
        "model.config.parallelism.data_parallel_replicate_degree": 1,
        "trainer.grad_accum_iter": grad_accum,
        "trainer.max_iter": max_iter,
        "checkpoint.save_iter": save_iter,
    }
    if lora:
        ov.update({
            "model.config.lora_enabled": True,
            "model.config.lora_rank": lora_rank,
            "optimizer.keys_to_select": ["lora_"],
            "checkpoint.keys_to_skip_loading": ["net_ema.", "lora_"],
        })
    return ov


def build_train_command(
    toml_path: str | Path,
    *,
    repo: Path | None = None,
    nproc: int = 1,
    overrides: dict[str, Any] | None = None,
    output_root: str | Path = "outputs/train",
    master_port: int | None = None,
    dataset_path: str | Path | None = None,
    base_checkpoint_path: str | Path | None = None,
    wan_vae_path: str | Path | None = None,
) -> tuple[list[str], dict[str, str]]:
    """Assemble the torchrun invocation and its environment.

    Returns ``(argv, env_additions)`` rather than running anything, so a lesson
    can print the command, discuss it, and only then execute it. Training runs
    are long; a learner should see exactly what is about to start.

    The canonical shipped form is::

        IMAGINAIRE_OUTPUT_ROOT=outputs/train PYTHONPATH=. \\
        torchrun --nproc_per_node=8 -m cosmos_framework.scripts.train \\
            --sft-toml=examples/toml/sft_config/vision_sft_edge.toml
    """
    repo = Path(repo or COSMOS3_REPO)
    venv_python = repo / ".venv" / "bin" / "python"
    torchrun = repo / ".venv" / "bin" / "torchrun"

    argv = [
        str(torchrun if torchrun.exists() else "torchrun"),
        f"--nproc_per_node={nproc}",
    ]
    if master_port:
        argv.append(f"--master_port={master_port}")
    argv += ["-m", "cosmos_framework.scripts.train", f"--sft-toml={toml_path}"]

    # Hydra-style key=value overrides must come AFTER a bare `--` separator.
    # `examples/_sft_launcher_common.sh` inserts it; if you drive torchrun
    # yourself and forget it, the overrides are parsed as arguments to the
    # launcher rather than the config and are SILENTLY IGNORED. A dropped
    # override looks exactly like an applied one until you OOM at the value you
    # thought you had changed. This is the single easiest way to waste an hour.
    ov = overrides or {}
    if ov:
        argv.append("--")
    for key, value in ov.items():
        if isinstance(value, bool):
            value = "true" if value else "false"
        elif isinstance(value, (list, tuple)):
            value = "[" + ",".join(f'"{v}"' for v in value) + "]"
        argv.append(f"{key}={value}")

    env = {
        "IMAGINAIRE_OUTPUT_ROOT": str(output_root),
        "PYTHONPATH": ".",
        # Reduces fragmentation-driven OOM. Free, and the FAQ's first rung.
        "PYTORCH_ALLOC_CONF": "expandable_segments:True",
        # The framework venv must not be shadowed by a container's libtorch.
        "LD_LIBRARY_PATH": "",
        "PYTHONNOUSERSITE": "1",
    }

    # The shipped TOMLs interpolate these with OmegaConf's ${oc.env:...}, so
    # they must exist in the environment or config construction fails with a
    # resolver error that does not name the missing variable helpfully. The
    # launcher scripts export them for you; raw torchrun does not.
    for name, value in (
        ("DATASET_PATH", dataset_path),
        ("BASE_CHECKPOINT_PATH", base_checkpoint_path),
        ("WAN_VAE_PATH", wan_vae_path),
    ):
        if value is not None:
            env[name] = str(value)

    missing = [
        n for n, v in (("DATASET_PATH", dataset_path),
                       ("BASE_CHECKPOINT_PATH", base_checkpoint_path),
                       ("WAN_VAE_PATH", wan_vae_path))
        if v is None and n not in os.environ
    ]
    warnings: list[str] = []
    if missing:
        warnings.append(
            "these ${oc.env:...} variables are unset and the shipped TOMLs need "
            f"them: {', '.join(missing)}"
        )
    if not venv_python.exists():
        warnings.append(f"no venv at {venv_python} — run scripts/setup.sh first")
    if warnings:
        env["_COSMOS_COURSE_WARNING"] = " | ".join(warnings)
    return argv, env


# ---------------------------------------------------------------------------
# Dataset checks
# ---------------------------------------------------------------------------
def check_dataset(root: str | Path, *, kind: str = "lerobot") -> dict[str, Any]:
    """Validate a dataset directory before you start a run that will take hours.

    ``kind="lerobot"`` expects LeRobotDataset **v3.0** layout — note v3, not the
    v2 you may have used with other robot-learning stacks. The launcher itself
    only checks that ``meta/info.json`` exists, which is a low bar; this checks
    a bit more so a malformed dataset fails in seconds rather than at iteration
    400.

    ``kind="jsonl"`` expects the generator format from ``docs/dataset_jsonl.md``.
    Two silent loader filters are worth knowing about and are reported here:
    clips longer than 61 seconds are dropped, and windows shorter than 61 frames
    are dropped. A dataset can therefore load "successfully" and yield nothing.
    """
    root = Path(root)
    out: dict[str, Any] = {"root": str(root), "kind": kind, "ok": False,
                           "problems": [], "warnings": [], "stats": {}}
    if not root.exists():
        out["problems"].append(f"{root} does not exist")
        return out

    if kind == "lerobot":
        info = root / "meta" / "info.json"
        if not info.exists():
            out["problems"].append(
                f"missing {info} — this is what the launcher checks for. "
                f"If you downloaded a subset, point at the subset directory, "
                f"not the repo root."
            )
            return out
        try:
            meta = json.loads(info.read_text())
        except json.JSONDecodeError as exc:
            out["problems"].append(f"meta/info.json is not valid JSON: {exc}")
            return out

        version = str(meta.get("codebase_version", "unknown"))
        out["stats"]["codebase_version"] = version
        if not version.startswith("v3"):
            out["problems"].append(
                f"codebase_version is {version!r}; Cosmos 3 action training needs "
                f"LeRobotDataset v3.0. A v2 dataset will not load."
            )
        for key in ("total_episodes", "total_frames", "fps"):
            if key in meta:
                out["stats"][key] = meta[key]
        for sub in ("meta/stats.json", "meta/tasks.parquet", "meta/episodes"):
            if not (root / sub).exists():
                out["warnings"].append(f"missing {sub}")

    elif kind == "jsonl":
        candidates = list(root.rglob("video_dataset_file.jsonl")) or list(root.rglob("*.jsonl"))
        if not candidates:
            out["problems"].append(
                "no .jsonl found. The generator format expects a "
                "video_dataset_file.jsonl produced by "
                "cosmos_framework.scripts.captions_to_sft_jsonl."
            )
            return out
        path = candidates[0]
        out["stats"]["jsonl"] = str(path)
        n, short_windows, long_clips = 0, 0, 0
        for line in path.read_text().splitlines():
            if not line.strip():
                continue
            n += 1
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                out["problems"].append(f"line {n} is not valid JSON")
                break
            if float(rec.get("duration", 0)) > 61:
                long_clips += 1
            for w in rec.get("t2w_windows", []):
                if int(w.get("end_frame", 0)) - int(w.get("start_frame", 0)) < 61:
                    short_windows += 1
        out["stats"].update({"records": n, "clips_over_61s": long_clips,
                             "windows_under_61_frames": short_windows})
        if long_clips:
            out["warnings"].append(
                f"{long_clips} clips exceed 61 s and will be SILENTLY DROPPED."
            )
        if short_windows:
            out["warnings"].append(
                f"{short_windows} windows are shorter than 61 frames and will be "
                f"SILENTLY DROPPED."
            )
        if long_clips + short_windows >= n:
            out["problems"].append(
                "every record would be filtered out. Training would run on an "
                "empty dataset without an obvious error."
            )
    else:
        out["problems"].append(f"unknown kind {kind!r}; expected 'lerobot' or 'jsonl'")
        return out

    out["ok"] = not out["problems"]
    return out


def read_toml(path: str | Path) -> dict[str, Any]:
    """Read a shipped SFT TOML. Uses stdlib tomllib on 3.11+, falls back to tomli."""
    path = Path(path)
    try:
        import tomllib  # Python 3.11+
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError as exc:
            raise ImportError(
                "reading TOML needs Python 3.11+ or `pip install tomli`"
            ) from exc
    return tomllib.loads(path.read_text())


# ---------------------------------------------------------------------------
# Watching a run
# ---------------------------------------------------------------------------
@dataclass
class TrainingWatch:
    """Parse a training log into something you can plot and reason about.

    Deliberately regex-based over the log rather than hooked into the trainer:
    a long training run is usually watched from a second terminal, and the log
    is the thing that is definitely there. Loss going down is necessary and not
    sufficient — Lesson 18 is about what else to check.
    """

    log_path: Path
    iters: list[int] = field(default_factory=list)
    losses: list[float] = field(default_factory=list)
    lrs: list[float] = field(default_factory=list)
    peak_mem_gb: float | None = None
    oom: bool = False
    finished: bool = False

    _ITER = re.compile(r"iter[:\s=]+(\d+)", re.I)
    _LOSS = re.compile(r"loss[:\s=]+([\d.eE+-]+)", re.I)
    _LR = re.compile(r"\blr[:\s=]+([\d.eE+-]+)", re.I)
    _MEM = re.compile(r"([\d.]+)\s*GB.*(?:peak|reserved|allocated)", re.I)

    def parse(self) -> "TrainingWatch":
        if not self.log_path.exists():
            return self
        text = self.log_path.read_text(errors="replace")
        self.oom = "CUDA out of memory" in text or "OutOfMemoryError" in text
        self.finished = "training complete" in text.lower() or "Done" in text[-500:]
        for line in text.splitlines():
            it = self._ITER.search(line)
            ls = self._LOSS.search(line)
            if it and ls:
                try:
                    self.iters.append(int(it.group(1)))
                    self.losses.append(float(ls.group(1)))
                except ValueError:
                    continue
                lr = self._LR.search(line)
                self.lrs.append(float(lr.group(1)) if lr else float("nan"))
            mm = self._MEM.search(line)
            if mm:
                try:
                    self.peak_mem_gb = max(self.peak_mem_gb or 0.0, float(mm.group(1)))
                except ValueError:
                    pass
        return self

    def summary(self) -> str:
        if self.oom:
            return (
                "Run hit CUDA OOM.\n"
                "  Ladder available to you on one GPU:\n"
                "    1. PYTORCH_ALLOC_CONF=expandable_segments:True\n"
                "    2. activation_checkpointing.mode='full'\n"
                "    3. halve max_num_tokens_after_packing, double grad_accum_iter\n"
                "    4. enable LoRA (generator path only)\n"
                "  NOT available: raising FSDP shard or context-parallel degree."
            )
        if not self.iters:
            return (
                f"No iterations parsed from {self.log_path}. Either the run has not "
                f"started logging yet, or the log format differs from what this "
                f"parser expects — open the log and adjust the regexes."
            )
        first, last = self.losses[0], self.losses[-1]
        trend = "falling" if last < first else "NOT falling"
        s = [
            f"iterations parsed : {len(self.iters)} (up to iter {self.iters[-1]})",
            f"loss              : {first:.4f} -> {last:.4f} ({trend})",
        ]
        if self.peak_mem_gb:
            s.append(f"peak memory       : {self.peak_mem_gb:.1f} GB")
        s.append(f"finished          : {self.finished}")
        if last >= first:
            s.append(
                "  Loss not falling. Check the learning rate, and check that "
                "keys_to_select is not excluding everything you meant to train."
            )
        return "\n".join(s)
