"""Shared utilities for *Physical AI with Cosmos 3 on a single H100*.

This package is course material, not a black box. Lesson 00 reads ``config.py``;
Lesson 02 reads ``nim.py`` and ``models.py``; Lesson 14 reads ``measure.py``. If
a helper here does something you do not understand, open it — that is the
intended workflow, and every module is commented for exactly that.

Layout
------
``config``    environment detection, paths, model facts, device selection,
              cost estimation and VRAM budgeting for one 80 GB card
``models``    Reasoner (in-process) and Generator (framework subprocess)
``nim``       Cosmos 3 Reasoner NIM lifecycle — pull, start, wait, query, stop
``specs``     building and validating inference specs
``measure``   correct GPU timing and memory measurement, plus the OOM ladder
``checks``    output verification — did it work, or did it merely exit zero
``pipeline``  resumable multi-stage runs: ledger, stage clock, device sampler
``finetune``  post-training helpers: SFT config surgery and single-GPU launch
``viz``       media display, spatial overlays, pose and trajectory plots
``assets``    locating cookbook assets and checking they are really there

Three of those — ``models``, ``nim`` and ``finetune`` — are imported defensively
below, so this package still imports when one of them is absent. Ask
``missing_modules()`` if something you expected is not here.

Quick start
-----------
>>> from cosmos_course import probe_environment
>>> print(probe_environment().summary())
"""

from __future__ import annotations

import importlib
from types import ModuleType

__version__ = "1.0.0"

# Upstream versions this course was written and validated against.
# Recorded here so a learner reporting a problem can say what they ran.
#
# Note on `cosmos_framework`: 1.2.2 is the version in pyproject.toml on `main`.
# The repository publishes no git tags or releases, so "v1.2.2" is a packaged
# version string, not something you can `git checkout` — pin the SHA instead.
UPSTREAM = {
    "cosmos_framework": "v1.2.2",
    "cosmos_cookbook": "main (see planning/05_VALIDATION_REPORT.md for the pinned SHA)",
    "reasoner_nim": "1.7",
    "written_against": "2026-08-29",
}

# --------------------------------------------------------------------------
# Core modules
# --------------------------------------------------------------------------
# These are imported plainly. If one of them fails to import that is a real
# bug and you want to see the traceback, not a helpful silence.
from .assets import (  # noqa: E402
    ASSETS,
    COOKBOOK,
    asset,
    asset_or_none,
    check_assets,
)
from .config import (  # noqa: E402
    ASPECT_RATIOS,
    ASSET_ROOT,
    AUXILIARY_DOWNLOADS_GB,
    COSMOS3_REPO,
    COSMOS_ROOT,
    COURSE_ROOT,
    MAX_FRAMES_BY_TIER,
    MODEL_MODES,
    MODEL_TIERS,
    OUTPUT_ROOT,
    PINNED,
    RESOLUTION_TIERS,
    TRANSFER_HINTS,
    EnvReport,
    estimate_generation_cost,
    probe_environment,
    require,
    resolution_wh,
    select_device,
    vram_budget,
)
from .checks import (  # noqa: E402
    CheckResult,
    check_action,
    check_image,
    check_text,
    check_video,
    verify_result,
)
from .pipeline import (  # noqa: E402
    DeviceSampler,
    Ledger,
    StageClock,
    StageOutcome,
    classify_error,
    run_stage,
    stage_table,
)
from .measure import (  # noqa: E402
    MeasurementLog,
    MemoryProbe,
    Timing,
    benchmark,
    describe_memory,
    memory_snapshot,
    oom_advice,
    peak_memory_gb,
    reset_peak_memory,
    timer,
)
# `specs` defines its own MODEL_MODES and TRANSFER_HINTS for validation, and we
# deliberately do NOT re-export those: the package-level names come from
# `config`, which carries a one-line explanation of every mode and hint. The two
# differ in one place — config's TRANSFER_HINTS holds the four members of the
# upstream TransferHintKey enum, while specs also accepts `wsm`, which ships as
# a cookbook asset family but is not in the enum.
from .specs import (  # noqa: E402
    InferenceSpec,
    build_inference_command,
    normalize_policy_mode,
    validate_spec,
    write_spec,
    write_specs_jsonl,
)
from .viz import (  # noqa: E402
    contact_sheet,
    draw_boxes,
    draw_trajectory,
    make_preview,
    mark_subjects,
    parse_model_json,
    plot_camera_trajectory,
    plot_end_effector_path,
    show_image,
    show_video,
    split_think,
)

__all__ = [
    "__version__",
    "UPSTREAM",
    "missing_modules",
    # config
    "COURSE_ROOT", "OUTPUT_ROOT", "ASSET_ROOT", "COSMOS_ROOT", "COSMOS3_REPO",
    "MODEL_TIERS", "MODEL_MODES", "TRANSFER_HINTS", "EnvReport", "probe_environment",
    "select_device", "resolution_wh", "estimate_generation_cost", "vram_budget", "require",
    # Tables the lessons budget against. These are in config.__all__ and the
    # notebooks reach for them as cc.<name>; re-exporting them here is what makes
    # that work. Lessons 06, 09 and 15 all depend on it.
    "RESOLUTION_TIERS", "ASPECT_RATIOS", "MAX_FRAMES_BY_TIER",
    "AUXILIARY_DOWNLOADS_GB", "PINNED",
    # assets
    "ASSETS", "COOKBOOK", "asset", "asset_or_none", "check_assets",
    # specs
    "InferenceSpec", "validate_spec", "write_spec", "write_specs_jsonl",
    "build_inference_command", "normalize_policy_mode",
    # measure
    "timer", "benchmark", "Timing", "MemoryProbe", "memory_snapshot",
    "reset_peak_memory", "peak_memory_gb", "describe_memory", "oom_advice",
    "MeasurementLog",
    # checks
    "CheckResult", "check_image", "check_video", "check_text", "check_action", "verify_result",
    # pipeline — the capstone's plumbing: resume, stage attribution, device VRAM
    "Ledger", "StageClock", "DeviceSampler", "StageOutcome", "classify_error",
    "run_stage", "stage_table",
    # viz
    "show_image", "show_video", "make_preview", "contact_sheet", "parse_model_json",
    "split_think", "draw_boxes", "draw_trajectory", "mark_subjects",
    "plot_camera_trajectory", "plot_end_effector_path",
]

# --------------------------------------------------------------------------
# Optional modules
# --------------------------------------------------------------------------
# `models`, `nim` and `finetune` may be absent from a partial checkout. Import
# them so that a missing file costs you those helpers and nothing else — a
# package that refuses to import at all because one lesson's module is not
# there is a bad trade.
#
# Note what is NOT caught: only ImportError. A module that exists but raises
# something else while importing is broken, and you should see that immediately
# rather than discover it as a mysterious missing name six cells later.
_UNAVAILABLE: dict[str, str] = {}


def _reexport(module: ModuleType) -> list[str]:
    """Copy a submodule's declared public names into this namespace.

    Done by lookup rather than a static ``from .nim import a, b, c`` because
    these modules are still moving; naming their symbols here would mean this
    file breaks every time one of them gains or renames a function. A module
    with no ``__all__`` contributes nothing but itself.
    """
    added: list[str] = []
    for name in getattr(module, "__all__", ()):
        value = getattr(module, name, None)
        if value is not None:
            globals()[name] = value
            added.append(name)
    return added


# importlib.import_module rather than `from . import models`, because when the
# file is simply absent the plain form reports "cannot import name 'models'
# from partially initialized module ... most likely due to a circular import",
# which sends you hunting for a circular import that does not exist. importlib
# says "No module named 'cosmos_course.models'", which is the truth.
try:
    models = importlib.import_module(".models", __name__)
except ImportError as exc:                                   # pragma: no cover
    _UNAVAILABLE["models"] = str(exc)
else:
    __all__ += ["models"] + _reexport(models)

try:
    nim = importlib.import_module(".nim", __name__)
except ImportError as exc:                                   # pragma: no cover
    _UNAVAILABLE["nim"] = str(exc)
else:
    __all__ += ["nim"] + _reexport(nim)

try:
    finetune = importlib.import_module(".finetune", __name__)
except ImportError as exc:                                   # pragma: no cover
    _UNAVAILABLE["finetune"] = str(exc)
else:
    __all__ += ["finetune"] + _reexport(finetune)


def missing_modules() -> dict[str, str]:
    """Which optional submodules failed to import, and why.

    Empty is the healthy answer. If ``cosmos_course.Reasoner`` is undefined,
    this tells you whether ``models.py`` is missing or whether one of its
    dependencies is, which are different problems with different fixes.
    """
    return dict(_UNAVAILABLE)
