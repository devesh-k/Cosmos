"""Building and validating Cosmos Framework inference specs.

The Cosmos Framework is driven by JSON (or JSONL, or YAML) *sample argument*
files. One file, one sample. The CLI reads them, merges them over built-in
per-mode defaults, and generates.

The source DLI notebooks built these by hand with a helper called
``create_payload`` that silently applied a fixed sampling dict. That works, but
it hides the two things that actually cost you time and memory — the resolution
tier and the frame count — behind a constant. Here they are explicit,
validated, and costed before you launch anything.

Field reference: NVIDIA/cosmos-framework ``docs/inference.md``.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Literal

from .config import (
    ASPECT_RATIOS,
    MAX_FRAMES_BY_TIER,
    RESOLUTION_TIERS,
    estimate_generation_cost,
    resolution_wh,
)

__all__ = [
    "MODEL_MODES",
    "TRANSFER_HINTS",
    "InferenceSpec",
    "write_spec",
    "write_specs_jsonl",
    "validate_spec",
    "build_inference_command",
    "normalize_policy_mode",
]

# Every model_mode the framework accepts, from the ModelMode enum.
#
# Naming note that will bite you: what the source course (and much of the
# public writing) calls "policy" is `wam` — world-action model — in current
# framework releases. The shipped example files are still named
# `action_policy_*.json`, so both names are in circulation. Use
# normalize_policy_mode() rather than hard-coding either.
MODEL_MODES = {
    "text2image",
    "text2video",
    "image2image",
    "image2video",
    "video2video",
    "audio_image2video",
    "forward_dynamics",
    "inverse_dynamics",
    "wam",
    "reasoner",
}

# Control modalities for video-to-video transfer. Transfer is not its own mode:
# it is `video2video` plus one or more of these hint blocks, and the framework
# auto-detects it from their presence.
TRANSFER_HINTS = {"edge", "blur", "depth", "seg", "wsm"}

# Which fields each mode requires. Checking this locally turns a twenty-minute
# round trip through model loading into an instant, readable error.
REQUIRED_FIELDS: dict[str, set[str]] = {
    "text2image": {"prompt"},
    "text2video": {"prompt"},
    "image2image": {"prompt", "vision_path"},
    "image2video": {"prompt", "vision_path"},
    "video2video": {"prompt", "vision_path"},
    "audio_image2video": {"prompt", "vision_path", "sound_path"},
    "forward_dynamics": {"domain_name", "vision_path", "action_path"},
    "inverse_dynamics": {"domain_name", "vision_path"},
    "wam": {"domain_name", "vision_path"},
    "reasoner": {"prompt"},
}


def normalize_policy_mode(mode: str) -> str:
    """Map the legacy name ``policy`` onto the current ``wam``.

    Kept as a named function rather than a dict lookup so the rename is
    discoverable when a learner greps for "policy" after reading the source
    course or the cookbook, both of which still use the old name in places.
    """
    return "wam" if mode == "policy" else mode


@dataclass
class InferenceSpec:
    """A single Cosmos Framework sample argument set.

    Only fields the course actually uses are modelled. Anything else can be
    passed through ``extra`` and will be merged into the emitted JSON, so this
    class never becomes a bottleneck when upstream adds a knob.
    """

    model_mode: str
    name: str

    # Text
    prompt: str | None = None
    negative_prompt: str | None = None

    # Vision conditioning
    vision_path: str | None = None
    sound_path: str | None = None

    # Geometry and sampling
    resolution: str | None = None          # tier name: "256" | "480" | "720" | "768"
    aspect_ratio: str | None = None        # "16,9" | "1,1" | "4,3" | "3,4" | "9,16"
    num_frames: int | None = None          # 1 = image, >=24 = video
    fps: int | float | None = None
    num_steps: int | None = None           # denoising steps
    guidance: float | None = None          # classifier-free guidance scale
    shift: float | None = None             # UniPC time-shift
    seed: int | None = 0

    # Action
    action_path: str | None = None
    domain_name: str | None = None
    view_point: str | None = None
    action_chunk_size: int | None = None
    image_size: int | None = None

    # Reasoner
    max_new_tokens: int | None = None
    temperature: float | None = None
    top_p: float | None = None
    top_k: int | None = None
    repetition_penalty: float | None = None
    video_fps: float | None = None

    # Transfer control hints: {"edge": {"control_path": ..., "weight": 1.0}}
    controls: dict[str, dict[str, Any]] = field(default_factory=dict)

    # Misc
    enable_sound: bool | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.model_mode = normalize_policy_mode(self.model_mode)

    # ---- serialisation ---------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Emit the JSON body, omitting anything left as None.

        Omission matters: the framework merges your file over per-mode defaults,
        so a key you did not set inherits a sensible default. Writing an
        explicit ``null`` would override that default with nothing.
        """
        skip = {"controls", "extra"}
        body: dict[str, Any] = {
            k: v for k, v in self.__dict__.items() if k not in skip and v is not None
        }
        body.update(self.controls)
        body.update(self.extra)
        return body

    def cost(self) -> dict[str, Any]:
        """Estimate the relative cost of this spec before running it."""
        if self.model_mode in {"reasoner", "inverse_dynamics"}:
            return {"note": "text/action output; generation-cost model does not apply"}
        return estimate_generation_cost(
            resolution=self.resolution or "720",
            aspect_ratio=self.aspect_ratio or "16,9",
            num_frames=self.num_frames if self.num_frames is not None else 189,
            num_steps=self.num_steps if self.num_steps is not None else 35,
        )

    def describe(self) -> str:
        """A one-screen human summary, including what the geometry really is."""
        lines = [f"model_mode : {self.model_mode}", f"name       : {self.name}"]
        if self.prompt:
            preview = self.prompt if len(self.prompt) <= 100 else self.prompt[:97] + "..."
            lines.append(f"prompt     : {preview}")
        if self.vision_path:
            lines.append(f"vision     : {self.vision_path}")
        if self.action_path:
            lines.append(f"action     : {self.action_path}")
        if self.controls:
            lines.append(f"controls   : {', '.join(sorted(self.controls))}")
        if self.resolution:
            w, h = resolution_wh(self.resolution, self.aspect_ratio or "16,9")
            lines.append(
                f"geometry   : tier {self.resolution} @ {self.aspect_ratio or '16,9'} "
                f"-> {w}x{h} px"
            )
        if self.num_frames is not None:
            kind = "image" if self.num_frames == 1 else "video"
            lines.append(f"frames     : {self.num_frames} ({kind})")
        if self.num_steps is not None:
            lines.append(f"steps      : {self.num_steps}")
        if self.guidance is not None:
            lines.append(f"guidance   : {self.guidance}")
        if self.seed is not None:
            lines.append(f"seed       : {self.seed}")
        return "\n".join(lines)


def validate_spec(spec: InferenceSpec | dict[str, Any], *, strict: bool = True) -> list[str]:
    """Check a spec locally and return a list of problems.

    Catches the mistakes that otherwise cost you a model load: an unknown mode,
    a missing required field, a frame count above the tier limit, a control hint
    on the wrong mode, an aspect ratio the model does not have a table for.

    With ``strict=True`` (the default) any problem raises. Set it to False when
    you want to show a learner the problem list without stopping the notebook.
    """
    body = spec.to_dict() if isinstance(spec, InferenceSpec) else dict(spec)
    problems: list[str] = []

    mode = normalize_policy_mode(str(body.get("model_mode", "")))
    if mode not in MODEL_MODES:
        problems.append(
            f"unknown model_mode {mode!r}. Valid modes: {', '.join(sorted(MODEL_MODES))}. "
            f"(If you meant 'policy', current releases call it 'wam'.)"
        )
    else:
        missing = REQUIRED_FIELDS.get(mode, set()) - set(body)
        if missing:
            problems.append(f"mode {mode!r} requires missing field(s): {', '.join(sorted(missing))}")

    if not body.get("name"):
        problems.append("'name' is required; it becomes the output subdirectory.")

    # Aspect ratio is a comma-separated string ("16,9"), NOT a colon-separated
    # one and NOT a float. Getting this wrong is a common first error, and the
    # framework's own message about it is not especially clear, so we say it here.
    aspect = str(body.get("aspect_ratio", "16,9"))
    if aspect not in ASPECT_RATIOS:
        hint = ""
        if ":" in aspect:
            hint = f" Did you mean {aspect.replace(':', ',')!r}? The separator is a comma."
        problems.append(
            f"aspect_ratio {aspect!r} is not one of {sorted(ASPECT_RATIOS)}.{hint}"
        )

    tier = body.get("resolution")
    if tier is not None:
        tier = str(tier)
        if tier not in MAX_FRAMES_BY_TIER:
            problems.append(
                f"resolution {tier!r} is not a valid tier. Tiers are "
                f"{sorted(MAX_FRAMES_BY_TIER)} — note these are tier NAMES, not pixel heights."
            )
        else:
            frames = body.get("num_frames")
            limit = MAX_FRAMES_BY_TIER[tier]
            if isinstance(frames, int) and frames > limit:
                problems.append(
                    f"num_frames={frames} exceeds the {tier} tier limit of {limit} frames."
                )

    control_keys = TRANSFER_HINTS & set(body)
    if control_keys and mode != "video2video":
        problems.append(
            f"control hint(s) {sorted(control_keys)} require model_mode 'video2video'; "
            f"got {mode!r}. Transfer is video2video plus a hint block, not its own mode."
        )

    if body.get("enable_sound") and mode not in {"text2video", "audio_image2video"}:
        problems.append(f"enable_sound is only meaningful for text2video / audio_image2video, not {mode!r}")

    frames = body.get("num_frames")
    if isinstance(frames, int) and 1 < frames < 24:
        problems.append(
            f"num_frames={frames} is between 1 and 24. Use 1 for an image or at least 24 for video."
        )

    if strict and problems:
        raise ValueError(
            "Inference spec is invalid:\n  - " + "\n  - ".join(problems)
        )
    return problems


def write_spec(
    spec: InferenceSpec,
    directory: Path | str,
    *,
    validate: bool = True,
    quiet: bool = False,
) -> Path:
    """Write one spec to ``<directory>/<name>.json`` and return the path.

    Note the framework resolves conditioning paths **relative to the spec
    file**, so this writes absolute paths for anything that exists on disk.
    Relative-path confusion is a common and confusing failure.
    """
    if validate:
        validate_spec(spec)

    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{spec.name}.json"

    body = spec.to_dict()
    for key in ("vision_path", "action_path", "sound_path"):
        value = body.get(key)
        if isinstance(value, str) and not value.startswith(("http://", "https://")):
            candidate = Path(value)
            if candidate.exists():
                body[key] = str(candidate.resolve())
    for hint in TRANSFER_HINTS & set(body):
        block = body[hint]
        cp = block.get("control_path") if isinstance(block, dict) else None
        if isinstance(cp, str) and Path(cp).exists():
            block["control_path"] = str(Path(cp).resolve())

    path.write_text(json.dumps(body, indent=2) + "\n")
    if not quiet:
        print(f"wrote spec: {path}")
    return path


def write_specs_jsonl(
    specs: Iterable[InferenceSpec],
    path: Path | str,
    *,
    validate: bool = True,
) -> Path:
    """Write several specs as JSONL — one sample per line, one batch job."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    for spec in specs:
        if validate:
            validate_spec(spec)
        lines.append(json.dumps(spec.to_dict()))
    path.write_text("\n".join(lines) + "\n")
    print(f"wrote {len(lines)} sample(s): {path}")
    return path


def build_inference_command(
    spec_path: Path | str,
    output_dir: Path | str,
    *,
    checkpoint: str = "Cosmos3-Edge",
    framework_repo: Path | str | None = None,
    parallelism_preset: Literal["latency", "throughput"] = "latency",
    seed: int | None = 0,
    no_guardrails: bool = False,
    offload_guardrails: bool = False,
    device_memory_utilization: float | None = None,
    extra_args: list[str] | None = None,
) -> tuple[list[str], dict[str, str]]:
    """Assemble the inference command and the environment it needs.

    Returns ``(argv, env_overrides)`` rather than a shell string, so the caller
    can run it with ``subprocess`` without quoting hazards.

    Two environment details are easy to miss and both cause confusing failures:

    * ``LD_LIBRARY_PATH`` must be cleared. Inside the NGC PyTorch container the
      bundled libtorch shadows the framework venv's, and you get an import error
      that looks like a missing symbol rather than a path problem. The framework
      FAQ documents this.
    * The framework expects ``MASTER_ADDR`` / ``MASTER_PORT`` / ``RANK`` /
      ``WORLD_SIZE`` / ``LOCAL_RANK`` even for a single-process run.
    """
    from .config import COSMOS3_REPO, select_device

    repo = Path(framework_repo) if framework_repo else COSMOS3_REPO
    python = repo / ".venv" / "bin" / "python"

    argv = [
        str(python),
        "-m",
        "cosmos_framework.scripts.inference",
        f"--parallelism-preset={parallelism_preset}",
        "-i",
        str(spec_path),
        "-o",
        str(output_dir),
        "--checkpoint-path",
        checkpoint,
    ]
    if seed is not None:
        argv += ["--seed", str(seed)]
    if no_guardrails:
        argv.append("--no-guardrails")
    if offload_guardrails:
        argv.append("--offload-guardrail-models")
    if device_memory_utilization is not None:
        argv += ["--device-memory-utilization", str(device_memory_utilization)]
    if extra_args:
        argv += list(extra_args)

    device = select_device()
    device_index = device.split(":")[-1] if device.startswith("cuda") else "0"

    env = {
        "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES", device_index),
        "LD_LIBRARY_PATH": "",
        "MASTER_ADDR": os.environ.get("MASTER_ADDR", "127.0.0.1"),
        "MASTER_PORT": os.environ.get("MASTER_PORT", "29501"),
        "RANK": "0",
        "WORLD_SIZE": "1",
        "LOCAL_RANK": "0",
        "PYTHONNOUSERSITE": "1",
        # Reduces allocator fragmentation, which matters near the ceiling of a
        # unified-memory pool.
        "PYTORCH_CUDA_ALLOC_CONF": os.environ.get(
            "PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True"
        ),
    }
    return argv, env
