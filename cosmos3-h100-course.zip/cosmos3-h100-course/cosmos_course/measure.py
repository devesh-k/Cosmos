"""Correct GPU timing and memory measurement.

Most reported "speedups" in ML notebooks are measurement artefacts. This
module exists so the course can make claims it can defend.

Three things go wrong when people time GPU work:

1. **No synchronisation.** CUDA kernel launches are asynchronous. If you call
   ``time.perf_counter()`` right after launching work, you have timed the
   *launch*, not the work. The result is a beautiful and completely fictional
   speedup. ``torch.cuda.synchronize()`` fixes it.

2. **No warm-up.** The first call into a fresh process pays for CUDA context
   creation, kernel JIT and autotuning, cuBLAS/cuDNN algorithm selection, and
   the allocator growing its pool. That cost is real on every CUDA GPU — it is
   not a property of any particular board — and on a short benchmark it can
   dominate the measurement completely. Pay it once, outside the timed region.

3. **Load time counted as compute time.** Reading 35 GB of weights from NVMe
   is not inference. Report them separately or the number means nothing.

Memory on a discrete GPU
------------------------
The target machine is one H100 80 GB. That is a *discrete* GPU with its own
HBM framebuffer, and the two obvious tools are both accurate here:

* ``nvidia-smi`` reports real per-process VRAM use.
* ``torch.cuda.mem_get_info()`` returns real free/total device memory.

So the measurement problem on this hardware is not broken tools. It is
PyTorch's **caching allocator**, and it catches nearly everyone:

* ``torch.cuda.memory_allocated()`` — bytes currently held by live tensors.
* ``torch.cuda.memory_reserved()`` — bytes PyTorch has taken from the CUDA
  driver and is keeping in its pool.

PyTorch does not hand freed blocks back to the driver. It keeps them, because
``cudaMalloc``/``cudaFree`` are slow and synchronising. So ``reserved`` ratchets
up and does not come back down on its own, and the gap ``reserved - allocated``
is memory your process owns but no tensor is using. **That gap is not a leak.**
It is cache, and it is why ``nvidia-smi`` will happily show 60 GB in use while
``memory_allocated()`` says 22 GB: nvidia-smi sees what the process holds from
the driver — the reserved pool, plus roughly 0.3–0.6 GB of CUDA context, plus
any cuBLAS/cuDNN workspaces — not what your tensors are using.

The gap becomes a real problem only when it is *fragmented* — many small free
blocks, none big enough for the next large allocation. That is the classic
"CUDA out of memory. Tried to allocate 2.00 GiB … 8.53 GiB free" message, and
the standard mitigation is::

    export PYTORCH_ALLOC_CONF=expandable_segments:True

which lets the allocator grow a single virtual segment rather than stitching
together fixed-size blocks. This is rung one of NVIDIA's own OOM ladder in the
Cosmos Framework FAQ, and it is free. (Older PyTorch spells the variable
``PYTORCH_CUDA_ALLOC_CONF``; recent versions accept either name.)
``torch.cuda.empty_cache()`` does return the unused pool to the driver, but it
costs you the cache you just paid for — use it to make a measurement readable,
not as a fix.

Not this machine: unified memory
--------------------------------
NVIDIA's Grace-based parts read differently, and differently from each other,
so be careful transplanting advice between them.

* **GB10** (DGX Spark) integrates the GPU into the SoC and shares one physical
  LPDDR pool with the CPU. There is no separate framebuffer, so ``nvidia-smi``'s
  memory columns can report ``Not Supported``, and ``mem_get_info()``
  under-reports what is really available because reclaimable host page cache is
  not counted as free. There, ``max_memory_allocated()`` plus ``free -h`` is the
  honest pair, and page cache genuinely competes with your allocations.
* **GH200 / GB200** keep dedicated HBM per GPU, so ``nvidia-smi`` reports memory
  normally. What changes is that CPU and GPU share a coherent address space, so
  a *managed* or system-allocated buffer can live in host memory and migrate
  over NVLink-C2C instead of failing. "It fits" and "it fits in HBM" stop being
  the same question.

**Neither applies to an H100.** This is written down so you recognise the
difference if you move between them, not because you need it today.
"""

from __future__ import annotations

import contextlib
import json
import shutil
import statistics
import subprocess
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterator

__all__ = [
    "Timing",
    "timer",
    "benchmark",
    "MemoryProbe",
    "memory_snapshot",
    "reset_peak_memory",
    "peak_memory_gb",
    "describe_memory",
    "oom_advice",
    "MeasurementLog",
]


def _sync() -> None:
    """Block until all queued GPU work has finished. No-op without CUDA."""
    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.synchronize()
    except Exception:
        pass


# --------------------------------------------------------------------------
# Timing
# --------------------------------------------------------------------------
@dataclass
class Timing:
    label: str
    seconds: float
    synchronized: bool = True
    peak_memory_gb: float | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        mem = f", peak {self.peak_memory_gb:.2f} GB" if self.peak_memory_gb is not None else ""
        return f"{self.label}: {self.seconds:.3f} s{mem}"


@contextlib.contextmanager
def timer(
    label: str = "block",
    *,
    synchronize: bool = True,
    track_memory: bool = True,
    quiet: bool = False,
) -> Iterator[Timing]:
    """Time a block of GPU or CPU work correctly.

    >>> with timer("denoise") as t:
    ...     run_inference()
    >>> t.seconds
    12.48

    ``synchronize=True`` is the default and should stay that way for anything
    touching the GPU. Set it to ``False`` only when you deliberately want to
    show a learner what an unsynchronised measurement looks like — Lesson 14
    does exactly that.
    """
    result = Timing(label=label, seconds=0.0, synchronized=synchronize)

    if track_memory:
        reset_peak_memory()
    if synchronize:
        _sync()

    start = time.perf_counter()
    try:
        yield result
    finally:
        if synchronize:
            _sync()
        result.seconds = time.perf_counter() - start
        if track_memory:
            result.peak_memory_gb = peak_memory_gb()
        if not quiet:
            print(str(result))


def benchmark(
    fn: Callable[[], Any],
    *,
    label: str = "benchmark",
    warmup: int = 1,
    repeats: int = 3,
    quiet: bool = False,
) -> dict[str, Any]:
    """Run ``fn`` with warm-up, then time it ``repeats`` times.

    Returns median rather than mean. A single slow run — a clock/power
    excursion, a background process, a page-cache miss on the weight files —
    skews a mean badly at these repeat counts. An H100 in a warm rack under
    sustained load will throttle, so expect this to matter.

    Keep ``repeats`` small for anything that takes minutes. The point is an
    honest number, not a tight confidence interval.
    """
    for _ in range(max(0, warmup)):
        fn()
        _sync()

    samples: list[float] = []
    reset_peak_memory()
    for _ in range(max(1, repeats)):
        _sync()
        t0 = time.perf_counter()
        fn()
        _sync()
        samples.append(time.perf_counter() - t0)

    out = {
        "label": label,
        "warmup_runs": warmup,
        "repeats": repeats,
        "median_s": round(statistics.median(samples), 4),
        "min_s": round(min(samples), 4),
        "max_s": round(max(samples), 4),
        "stdev_s": round(statistics.stdev(samples), 4) if len(samples) > 1 else 0.0,
        "samples_s": [round(s, 4) for s in samples],
        "peak_memory_gb": peak_memory_gb(),
    }
    if not quiet:
        spread = out["max_s"] - out["min_s"]
        print(
            f"{label}: median {out['median_s']:.3f} s "
            f"(min {out['min_s']:.3f}, max {out['max_s']:.3f}, spread {spread:.3f})"
        )
        if out["median_s"] > 0 and spread / out["median_s"] > 0.25:
            print(
                "  note: run-to-run spread exceeds 25% of the median. Something else is competing "
                "for the machine, or the GPU is thermally throttling. Treat this number as soft."
            )
    return out


# --------------------------------------------------------------------------
# Memory
# --------------------------------------------------------------------------
def _nvidia_smi_used_gb(index: int = 0) -> float | None:
    """What the driver says is in use on the device, in decimal GB.

    Worth reading even though PyTorch already tells us things, because this is
    the number learners will see in ``nvidia-smi`` and be alarmed by. Two
    caveats to carry with it: it is the whole *device*, so it includes every
    other process on the card, and for our process it tracks the allocator's
    **reserved** pool plus the CUDA context — not live tensors.

    Returns None if nvidia-smi is missing or unhappy, like every other probe in
    this course: a diagnostic that raises is worse than one that says nothing.
    """
    if not shutil.which("nvidia-smi"):
        return None
    try:
        out = subprocess.run(
            [
                "nvidia-smi",
                f"--id={index}",
                "--query-gpu=memory.used",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=10,
            check=True,
        ).stdout.strip()
    except (subprocess.SubprocessError, OSError):
        return None
    for line in out.splitlines():
        try:
            return float(line.strip()) * (1024**2) / 1e9   # MiB -> decimal GB
        except ValueError:
            return None                                     # e.g. "[N/A]"
    return None


@dataclass
class MemoryProbe:
    """One memory reading, device numbers first, host numbers as context.

    The device fields are the ones that decide whether your run fits. The host
    fields are here for weight loading and dataloader questions only — on a
    discrete GPU, host RAM is a *different pool* and does not compete with VRAM.
    """

    # -- device (this is what fits or does not fit) ------------------------
    torch_allocated_gb: float | None = None       # live tensors
    torch_reserved_gb: float | None = None        # pool held from the driver
    torch_max_allocated_gb: float | None = None   # peak live tensors
    torch_max_reserved_gb: float | None = None    # peak pool size
    reserved_unused_gb: float | None = None       # reserved - allocated
    torch_free_gb: float | None = None            # driver's view, whole device
    torch_total_gb: float | None = None
    smi_used_gb: float | None = None              # nvidia-smi, whole device

    # -- host (context, not a VRAM constraint) -----------------------------
    system_available_gb: float | None = None
    system_total_gb: float | None = None
    host_page_cache_gb: float | None = None

    @property
    def fragmentation_gb(self) -> float | None:
        """Same number as ``reserved_unused_gb``, under the name people use.

        Strictly it is *reserved but not currently allocated*, which is only
        fragmentation once the free blocks are too small to satisfy the next
        request. A large value on its own is healthy cache; a large value
        alongside an OOM is fragmentation.
        """
        return self.reserved_unused_gb

    def __str__(self) -> str:
        def fmt(v: float | None) -> str:
            return "n/a" if v is None else f"{v:.2f} GB"

        device = (
            f"device: allocated {fmt(self.torch_allocated_gb)} | "
            f"reserved {fmt(self.torch_reserved_gb)} "
            f"(unused {fmt(self.reserved_unused_gb)}) | "
            f"peak allocated {fmt(self.torch_max_allocated_gb)}"
        )
        if self.torch_free_gb is not None and self.torch_total_gb is not None:
            device += f" | free {self.torch_free_gb:.1f}/{self.torch_total_gb:.1f} GB"
        if self.smi_used_gb is not None:
            device += f" | nvidia-smi {self.smi_used_gb:.2f} GB"
        return device + f"  ||  host RAM available {fmt(self.system_available_gb)}"


def memory_snapshot(*, include_smi: bool = False) -> MemoryProbe:
    """Read VRAM from PyTorch (and optionally the driver), plus host RAM.

    ``include_smi`` shells out to ``nvidia-smi``, which costs tens of
    milliseconds — fine for a report, not fine inside a timing loop, so it is
    off by default.

    The pairing that matters is ``allocated`` against ``reserved``. Allocated is
    your tensors. Reserved is what PyTorch is holding from the driver on your
    behalf and will reuse rather than hand back. Reading only one of them is how
    people convince themselves they have a leak.

    Host figures come from ``/proc/meminfo`` where it exists. They are context:
    they tell you whether a 35 GB safetensors load will thrash, not whether the
    model fits on the card.
    """
    probe = MemoryProbe()

    try:
        import torch

        if torch.cuda.is_available():
            allocated = torch.cuda.memory_allocated()
            reserved = torch.cuda.memory_reserved()
            probe.torch_allocated_gb = allocated / 1e9
            probe.torch_reserved_gb = reserved / 1e9
            probe.reserved_unused_gb = max(reserved - allocated, 0) / 1e9
            probe.torch_max_allocated_gb = torch.cuda.max_memory_allocated() / 1e9
            probe.torch_max_reserved_gb = torch.cuda.max_memory_reserved() / 1e9
            try:
                # Accurate on a discrete GPU. (It is the call that misleads on
                # unified-memory parts; see the module docstring.)
                free_b, total_b = torch.cuda.mem_get_info()
                probe.torch_free_gb = free_b / 1e9
                probe.torch_total_gb = total_b / 1e9
            except Exception:
                pass
    except Exception:
        pass

    if include_smi:
        probe.smi_used_gb = _nvidia_smi_used_gb()

    try:
        info: dict[str, int] = {}
        for line in Path("/proc/meminfo").read_text().splitlines():
            key, _, rest = line.partition(":")
            info[key] = int(rest.strip().split()[0])
        probe.system_total_gb = info["MemTotal"] / 1e6
        probe.system_available_gb = info["MemAvailable"] / 1e6
        # Host page cache. Named `host_` because on this hardware that is the
        # whole story: it is RAM, it does not touch VRAM, and it is reclaimable.
        probe.host_page_cache_gb = info.get("Cached", 0) / 1e6
    except Exception:
        pass

    return probe


def reset_peak_memory() -> None:
    """Reset PyTorch's peak-memory counters (both allocated and reserved).

    Call this before the region you care about, otherwise the peak you read is
    the high-water mark since the process started, which is almost never what
    you meant to measure. Note it resets the *counters*, not the pool — the
    reserved memory stays where it is, which is the correct behaviour and the
    reason a fresh peak reading can still sit below what nvidia-smi shows.
    """
    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.reset_peak_memory_stats()
    except Exception:
        pass


def peak_memory_gb() -> float | None:
    """Peak *allocated* VRAM since the last reset, in decimal GB.

    Allocated, not reserved: this is the high-water mark of live tensors, which
    is the figure to compare against a model's documented VRAM requirement. The
    pool the allocator held to serve that peak was larger — use
    ``memory_snapshot().torch_max_reserved_gb`` when you want that instead.
    """
    try:
        import torch

        if torch.cuda.is_available():
            return round(torch.cuda.max_memory_allocated() / 1e9, 3)
    except Exception:
        pass
    return None


def describe_memory(label: str = "memory", *, include_smi: bool = True) -> MemoryProbe:
    """Print a memory reading and explain the parts that mislead people.

    The notes below fire only when the situation they describe is actually
    present. A note that always prints stops being read.
    """
    probe = memory_snapshot(include_smi=include_smi)
    print(f"{label}: {probe}")

    alloc = probe.torch_allocated_gb
    reserved = probe.torch_reserved_gb
    unused = probe.reserved_unused_gb

    # The big one: reserved vs allocated. This is the number one source of
    # "PyTorch is leaking memory" bug reports that are not bugs.
    if reserved is not None and alloc is not None and unused is not None and unused > 1.0:
        share = unused / reserved if reserved else 0.0
        print(
            f"  note: {unused:.1f} GB of the {reserved:.1f} GB reserved pool "
            f"({share:.0%}) is not holding any live tensor. That is PyTorch's "
            f"caching allocator keeping freed blocks for reuse — it is cache, not a "
            f"leak. It only becomes a problem if a large allocation fails while that "
            f"much appears free, which means the free blocks are too fragmented to "
            f"use. Then: PYTORCH_ALLOC_CONF=expandable_segments:True."
        )

    # nvidia-smi vs memory_allocated. Learners will have nvidia-smi open in
    # another terminal and will not believe the PyTorch number.
    if probe.smi_used_gb is not None and alloc is not None:
        gap = probe.smi_used_gb - alloc
        if gap > 1.0:
            print(
                f"  note: nvidia-smi says {probe.smi_used_gb:.1f} GB while "
                f"memory_allocated() says {alloc:.1f} GB. Both are right. nvidia-smi "
                f"reports what the process holds from the driver — the reserved pool "
                f"plus ~0.3-0.6 GB of CUDA context, plus any other process on the card "
                f"— and memory_allocated() reports live tensors only."
            )

    # Headroom, using the driver's own free figure (trustworthy here).
    if probe.torch_free_gb is not None and probe.torch_total_gb is not None:
        if probe.torch_free_gb < 0.08 * probe.torch_total_gb:
            print(
                f"  note: only {probe.torch_free_gb:.1f} GB of {probe.torch_total_gb:.1f} GB "
                f"is free on the device. The next big allocation is likely to fail; "
                f"call oom_advice() before you launch a longer or larger job."
            )

    # Host RAM, explicitly labelled as host so nobody reads it as VRAM.
    if probe.host_page_cache_gb and probe.system_total_gb:
        if probe.host_page_cache_gb > 0.5 * probe.system_total_gb:
            print(
                f"  note (host, not device): {probe.host_page_cache_gb:.1f} GB of host RAM "
                f"is page cache — mostly model weights you have already read. On a "
                f"discrete GPU this does not compete with VRAM and is reclaimable on "
                f"demand; it is good news for reload time, not a cause of CUDA OOM."
            )
    return probe


def oom_advice(
    peak_gb: float | None = None,
    model: str = "Cosmos3-Nano",
    *,
    total_gb: float | None = None,
    resolution: str | int | None = None,
    num_frames: int | None = None,
    num_steps: int | None = None,
    training: bool = False,
    quiet: bool = False,
) -> list[str]:
    """Print the OOM escalation ladder for **one** GPU, in the order to try it.

    Call it after a CUDA OOM, or pre-emptively with the peak from your last
    successful run to see how much headroom you have left::

        >>> oom_advice(peak_memory_gb(), model="Cosmos3-Nano")

    Ordering is deliberate: cheapest first, and each rung costs you something
    different. Rung 1 costs nothing. Rungs 2-4 cost output quality or length.
    Rung 5 costs model capability. Work down, not up.

    The ladder in NVIDIA's own FAQ has six rungs, two of which — raising the
    FSDP shard degree and raising the context-parallel degree — divide state
    across *more GPUs*. On a single H100 they are not available to you at any
    setting, so they are not on this list. If you find advice online that starts
    with "just increase the shard degree", it was written for a node.

    Returns the lines as a list so a notebook can assert on them.
    """
    lines: list[str] = []
    tiers: dict[str, Any] = {}
    try:
        from .config import MODEL_TIERS as tiers  # type: ignore[no-redef]
    except Exception:                                        # pragma: no cover
        tiers = {}

    if total_gb is None:
        try:
            import torch

            if torch.cuda.is_available():
                total_gb = torch.cuda.get_device_properties(0).total_memory / 1e9
        except Exception:
            pass

    header = "OOM ladder for a single GPU"
    if peak_gb is not None and total_gb:
        header += f" — last peak {peak_gb:.1f} GB of {total_gb:.1f} GB"
    elif peak_gb is not None:
        header += f" — last peak {peak_gb:.1f} GB"
    lines.append(header)
    lines.append("=" * len(header))

    tier = tiers.get(model, {})
    budget = tier.get("inference_vram_gb")
    if budget and total_gb and budget > total_gb:
        lines += [
            f"  STOP FIRST: {model} inference is documented at ~{budget} GB and this card",
            f"     has {total_gb:.0f} GB. No knob below closes a gap that size. Use a smaller",
            "     tier — this is a wrong-model problem, not a tuning problem.",
            "",
        ]

    lines += [
        "  1. expandable_segments — free, try it first",
        "       export PYTORCH_ALLOC_CONF=expandable_segments:True",
        "     Costs nothing and sometimes fixes the OOM outright, because most",
        "     single-GPU OOMs at high utilisation are fragmentation rather than a",
        "     genuine shortage. If the error said a few GB were free but the",
        "     allocation still failed, this is your rung. (Older PyTorch: the",
        "     variable is PYTORCH_CUDA_ALLOC_CONF.)",
        "",
        "  2. Lower the resolution tier — biggest single lever",
        "       768 -> 480 -> 256",
        "     Activation memory scales with latent token count, which scales with",
        "     pixel area: 768p to 480p is roughly a 2.5x cut in tokens, and attention",
        "     cost falls faster than that. Try this before touching anything else",
        "     about the job.",
        "",
        "  3. Fewer frames",
        "     Frames enter the token count linearly (after the VAE's 4x temporal",
        "     compression), so halving the clip roughly halves activation memory.",
        "     Two short clips are usually a better trade than one long failure.",
        "",
        "  4. Fewer denoising steps",
        "     Be honest about what this buys: steps are sequential, so cutting them",
        "     cuts wall-clock almost linearly but peak memory only a little — the",
        "     per-step activations are transient. Use it for throughput, and only",
        "     expect memory relief at the margin.",
        "",
        "  5. Smaller model tier — last, because it changes what you can do",
        "       Cosmos3-Super -> Cosmos3-Nano -> Cosmos3-Edge",
        "     Each step down loses capability (Edge has no audio and no transfer),",
        "     so spend the rungs above first.",
        "",
        "  NOT available on one GPU:",
        "     - raising the FSDP shard degree",
        "     - raising the context-parallel degree",
        "     Both work by splitting state across additional ranks. With one device",
        "     there is nothing to split onto, and setting them will not help.",
    ]

    if training:
        lines += [
            "",
            "  Training-only rungs that DO work on one GPU:",
            "     - activation checkpointing set to `full`",
            "     - lower max_samples_per_batch / max_num_tokens_after_packing",
            "     - LoRA (generator path only; the reasoner path skips it upstream)",
            "     - disable the EMA copy, which is on by default and costs a full",
            "       fp32 duplicate of the trainable parameters",
            "     Note there is no CPU offload and no 8-bit optimizer in the shipped",
            "     training config, so those are not options however often they are",
            "     suggested for other frameworks.",
        ]

    if total_gb and peak_gb is not None:
        headroom = total_gb - peak_gb
        lines += [
            "",
            f"  Headroom: {headroom:.1f} GB between your last peak and the card.",
            "     Peak *allocated* is not peak *reserved* — the allocator holds more than",
            "     your tensors do — so treat anything under about 5 GB as no headroom.",
        ]

    context = [
        f"resolution={resolution}" if resolution is not None else "",
        f"frames={num_frames}" if num_frames is not None else "",
        f"steps={num_steps}" if num_steps is not None else "",
    ]
    context = [c for c in context if c]
    if context:
        lines += ["", "  Current settings: " + ", ".join(context)]

    if not quiet:
        print("\n".join(lines))
    return lines


# --------------------------------------------------------------------------
# Persistent log
# --------------------------------------------------------------------------
class MeasurementLog:
    """Append-only JSONL log of measurements taken during the course.

    Lesson 14 and the capstone read this back to build a cost model for *your*
    machine, which is the only machine whose numbers are trustworthy for
    planning your runs.
    """

    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, **fields: Any) -> dict[str, Any]:
        entry = {"timestamp": time.time(), **fields}
        with self.path.open("a") as fh:
            fh.write(json.dumps(entry, default=str) + "\n")
        return entry

    def record_timing(self, timing: Timing, **extra: Any) -> dict[str, Any]:
        return self.record(**asdict(timing), **extra)

    def load(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        out = []
        for line in self.path.read_text().splitlines():
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return out

    def to_dataframe(self):
        """Return the log as a pandas DataFrame, if pandas is available."""
        try:
            import pandas as pd
        except ImportError as exc:  # pragma: no cover
            raise ImportError("pandas is required for to_dataframe(); use load() instead") from exc
        return pd.DataFrame(self.load())
