"""The two ways you talk to Cosmos 3, and why they look nothing alike.

Cosmos 3 is one family of checkpoints with two towers — a **reasoner** (a
vision-language model that reads pixels and writes text) and a **generator** (a
diffusion transformer that writes pixels). This course drives them through two
completely different mechanisms, and the asymmetry is not an accident of
convenience; it is forced by how each one is packaged.

``Reasoner`` — an HTTP client
-----------------------------
The reasoner runs in the Cosmos 3 Reasoner NIM, a container serving an
OpenAI-compatible API on port 8000. So ``Reasoner`` is a thin, boring HTTP
client: build a ``chat.completions`` request, send it, read the string back. All
the interesting engineering (batching, FP8, paged KV cache) happens on the other
side of the socket. Start and stop the container with ``cosmos_course.nim``.

Everything ``Reasoner`` adds is about the gap between "what you have on disk"
and "what the server can accept":

* **base64 inlining.** The NIM cannot read your filesystem. A path in a request
  is either a 404 or, worse, a path *the server* can resolve to something else.
  Local files therefore get inlined as ``data:`` URLs.
* **H.264 transcoding.** The NIM decodes video with OpenCV, which cannot read
  AV1. A large fraction of modern robotics data — including LeRobot v3 datasets,
  which is most of the action data in this course — ships as AV1. An AV1 video
  reaches the model as **zero frames**, and the server answers 422.
* **``<think>`` handling.** Cosmos 3 has no reasoning-mode switch. Structured
  reasoning appears because you asked for it in the prompt, which means it can
  also not appear. ``think()`` asks for it and parses it defensively.

``Generator`` — a subprocess
----------------------------
The generator runs through ``cosmos_framework.scripts.inference``, and this
module runs it as a **subprocess against the framework's own virtualenv** rather
than importing it. That is deliberate and worth understanding, because "why not
just import it?" is the first question everyone asks:

1. **The environments are genuinely incompatible.** The framework is installed
   with ``uv sync --all-extras --group=cu130-train`` into its own ``.venv``,
   pinned to a specific torch, a specific flash-attn build (``flash-attn-3-nv``
   on Hopper) and CUDA 12.8/13.0 wheels. Your Jupyter kernel is not that
   environment and should not become it — the framework's ``vllm`` extra is
   documented as *conflicting* with every ``cu*`` group, so a single venv that
   holds both a serving stack and the training stack does not exist.
2. **Memory hygiene.** Diffusion inference allocates tens of GB. When the
   process exits, the operating system returns every byte. When an in-process
   import fails halfway through, you get a kernel holding 40 GB of VRAM that
   only a restart will free — and on a single-GPU machine that stops everything
   else you were doing.
3. **It matches the documentation.** Upstream documents a command line. Errors
   you hit here are errors you can paste into an issue, and answers you find
   online apply directly.

The price is that failures arrive as text on stdout rather than as exceptions,
so ``RunResult.diagnose()`` pattern-matches the ones this course has actually
seen, and ``RunResult.ok`` refuses to call a run successful on the strength of
an exit code alone.
"""

from __future__ import annotations

import base64
import hashlib
import json
import mimetypes
import os
import queue
import re
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

from .config import COSMOS3_REPO

__all__ = [
    "Reasoner",
    "Generator",
    "RunResult",
    "GenerationResult",
    "THINK_TEMPLATE",
    "VIDEO_FPS_MODE",
    "ACTION_MODEL_MODES",
    "split_think",
    "diagnose",
    "check_hf_access",
]

# --------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------
DEFAULT_BASE_URL = "http://localhost:8000"

# Used when /v1/models cannot be reached. Taken from COSMOS3_FACTS.md §4; the
# NIM serves exactly two ids, `nvidia/cosmos3-nano-reasoner` and
# `nvidia/cosmos3-super-reasoner`. Guessing is a poor substitute for asking, so
# this only ever applies when the server is unreachable and the request is going
# to fail anyway — at which point a plausible id produces a clearer error than
# an empty string.
FALLBACK_MODEL_ID = "nvidia/cosmos3-nano-reasoner"

# The course's standard chain-of-thought wrapper.
#
# Cosmos 3 does not have a "reasoning mode" flag. This structure exists only
# because the prompt asks for it, which is exactly why think() cannot assume the
# tags are present and split_think() returns ("", text) rather than raising.
THINK_TEMPLATE = (
    "{prompt}\n\n"
    "Reason step by step inside <think> </think> tags. After the closing "
    "</think> tag, give your final answer directly, with no preamble and no "
    "restatement of the question."
)

# ~~~ UNVERIFIED — how to tell the NIM what frame rate to sample video at ~~~~
#
# Sampling rate matters enormously for video reasoning: it sets how many frames
# become image tokens, which sets both the cost and whether the model can see
# the event you are asking about. Every serving stack exposes it differently and
# this course could not verify NIM 1.7's spelling against a live container.
#
# Three plausible shapes are implemented; switch with the environment variable
# COSMOS_COURSE_VIDEO_FPS_MODE, or per-instance with Reasoner(fps_mode=...).
#
#   "video_url"  {"type": "video_url", "video_url": {"url": ..., "fps": 4.0}}
#                The vLLM/NIM VLM convention. Default because it is the most
#                commonly accepted.
#   "extra_body" fps sent as a top-level extra_body key alongside the request.
#   "off"        do not send it; take whatever the server's default is.
#
# How to find out which one your NIM wants, in one minute: send the same short
# video three times, once per mode, and compare `prompt_tokens` in
# ``Reasoner.last_usage``. The mode that changes the token count when you change
# fps is the one the server is honouring. If a mode returns HTTP 422 or 400
# complaining about an unknown field, it is not that one.
VIDEO_FPS_MODE = os.environ.get("COSMOS_COURSE_VIDEO_FPS_MODE", "video_url")

# Modes that produce or consume action trajectories. These take the
# single-process launch path (see Generator._build_command).
#
# `wam` is the name. The source DLI course and several still-live upstream doc
# pages say `policy`; that name was removed from the ModelMode enum and will
# fail. See COSMOS3_FACTS.md §2.
ACTION_MODEL_MODES = frozenset({"forward_dynamics", "inverse_dynamics", "wam"})

# File types the framework writes. Used to decide whether a run produced
# anything, which is a stricter and more useful test than the exit code.
_OUTPUT_SUFFIXES = (".mp4", ".jpg", ".jpeg", ".png", ".json", ".wav")


# --------------------------------------------------------------------------
# Text helpers (no dependencies, used by both classes)
# --------------------------------------------------------------------------
def split_think(text: str) -> tuple[str, str]:
    """Split a chain-of-thought response into ``(reasoning, answer)``.

    Returns ``("", text)`` when there is no ``</think>`` — an unterminated or
    absent think block is a normal thing for a model to do when the structure
    came from a prompt rather than a mode flag, and losing the answer to an
    exception over it would be absurd.

    (``cosmos_course.viz.split_think`` is the display-side twin of this. It is
    duplicated rather than imported so that ``models.py`` can be read start to
    finish in Lesson 02 without a detour, and so importing this module never
    drags in the plotting stack.)
    """
    if "</think>" in text:
        before, _, after = text.partition("</think>")
        return before.replace("<think>", "").strip(), after.strip()
    return "", text.strip()


def _extract_json_blob(body: str) -> str | None:
    """Find the first balanced ``[...]`` or ``{...}`` in ``body``.

    A greedy regex (``\\[.*\\]``) is the obvious approach and it is wrong: given
    "[1,2] and then [3,4]" it returns the whole span including the prose between
    them. Scanning for balanced delimiters, while skipping anything inside a
    string literal, gets the *first* complete value, which is what callers mean.
    """
    start = None
    for i, ch in enumerate(body):
        if ch in "[{":
            start = i
            break
    if start is None:
        return None

    opener = body[start]
    closer = "]" if opener == "[" else "}"
    depth = 0
    in_string = False
    escaped = False

    for i in range(start, len(body)):
        ch = body[i]
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == opener:
            depth += 1
        elif ch == closer:
            depth -= 1
            if depth == 0:
                return body[start : i + 1]
    return None


# --------------------------------------------------------------------------
# Reasoner
# --------------------------------------------------------------------------
class Reasoner:
    """Client for the Cosmos 3 Reasoner NIM's OpenAI-compatible API.

    >>> from cosmos_course.nim import NimConfig, start_nim
    >>> start_nim(NimConfig())
    >>> r = Reasoner()
    >>> r.ask("What is happening in this video?", videos="clip.mp4")

    The instance records timing and token counts for every call
    (``last_latency_s``, ``last_usage``, ``history``) so Lesson 14 can measure
    throughput without wrapping anything.
    """

    def __init__(
        self,
        base_url: str | None = None,
        *,
        model: str | None = None,
        api_key: str | None = None,
        timeout: float = 600.0,
        max_retries: int = 4,
        fps_mode: str | None = None,
    ) -> None:
        # Precedence: explicit argument, then NIM_BASE_URL, then localhost.
        # NIM_BASE_URL exists so a lesson can point at a NIM on another host
        # without editing any notebook.
        raw = base_url or os.environ.get("NIM_BASE_URL") or DEFAULT_BASE_URL
        self.base_url = self._normalise_base_url(raw)

        # The NIM does not check bearer tokens by default, but the OpenAI client
        # refuses to construct without *something*. "not-used" is a clearer
        # thing to see in a proxy log than a blank.
        self.api_key = api_key or os.environ.get("NIM_API_KEY") or "not-used"
        self.timeout = timeout
        self.max_retries = max_retries
        self.fps_mode = fps_mode or VIDEO_FPS_MODE

        self._model = model
        self._client: Any = None

        # -- measurement surface (Lesson 14) -------------------------------
        self.last_latency_s: float | None = None
        self.last_usage: dict[str, Any] = {}
        self.last_tokens_per_second: float | None = None
        self.last_response: Any = None
        self.history: list[dict[str, Any]] = []

        # Transcodes are cached across instances and across kernel restarts;
        # re-encoding a 200 MB robot video on every call is a good way to make
        # an inference lesson feel like a video-editing lesson.
        self._transcode_dir = Path(tempfile.gettempdir()) / "cosmos_course_h264"
        self._warned_no_ffprobe = False

    # -- setup ------------------------------------------------------------
    @staticmethod
    def _normalise_base_url(raw: str) -> str:
        """Strip a trailing slash and a trailing ``/v1``.

        People paste the URL they used with curl, which usually includes ``/v1``.
        Appending another one produces ``/v1/v1/models`` and a 404 that looks
        like the server is broken rather than the URL being wrong.
        """
        url = raw.strip().rstrip("/")
        if url.endswith("/v1"):
            url = url[: -len("/v1")]
        return url

    @property
    def model(self) -> str:
        """The model id the server is actually serving, resolved once and cached.

        Asked rather than assumed, because the id depends on ``NIM_MODEL_SIZE``
        at container start: a NIM left running from yesterday may be serving
        ``cosmos3-super-reasoner`` while today's notebook assumes nano. Sending
        the wrong id is a 404 with a message about model not found, which reads
        like a server problem and is not.
        """
        if self._model:
            return self._model
        ids = self.list_models()
        self._model = ids[0] if ids else FALLBACK_MODEL_ID
        if not ids:
            print(
                f"could not read {self.base_url}/v1/models — falling back to "
                f"{FALLBACK_MODEL_ID!r}. If the NIM is not running, start it with "
                f"cosmos_course.nim.start_nim()."
            )
        return self._model

    def list_models(self) -> list[str]:
        """GET /v1/models. Returns ``[]`` if the server is unreachable.

        Plain urllib: this is one small GET and it should work in an environment
        where ``requests`` was never installed.
        """
        req = urllib.request.Request(
            self.base_url + "/v1/models",
            headers={"Authorization": f"Bearer {self.api_key}", "Accept": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8", "replace"))
        except Exception:
            return []
        return [m["id"] for m in data.get("data", []) if isinstance(m, dict) and m.get("id")]

    def _openai(self) -> Any:
        """Build (once) and return the OpenAI client.

        ``openai`` is imported here rather than at module scope so that
        ``import cosmos_course`` works on a machine that has not installed it —
        ``Generator``, ``split_think`` and ``parse_json`` have no need of it, and
        a package that fails to import because of an optional dependency is a
        package nobody can debug.
        """
        if self._client is not None:
            return self._client
        try:
            from openai import OpenAI
        except ImportError as exc:                       # pragma: no cover
            raise ImportError(
                "the `openai` package is required to talk to the NIM.\n"
                "    pip install openai\n"
                "  (The NIM speaks the OpenAI wire protocol; this is a client "
                "library, not a connection to OpenAI, and no request leaves your "
                "machine.)"
            ) from exc
        self._client = OpenAI(
            base_url=f"{self.base_url}/v1",
            api_key=self.api_key,
            timeout=self.timeout,
            max_retries=0,   # we do our own, with a message — see _call_with_retry
        )
        return self._client

    # -- media ------------------------------------------------------------
    def _data_url(self, path: Path) -> str:
        """Read a local file and return it as a base64 ``data:`` URL.

        The NIM is a container with its own filesystem. It cannot open
        ``/home/you/clip.mp4``, and if a path *does* happen to resolve inside the
        container you get whatever file is there instead — a silent wrong answer,
        which is worse than an error. Inlining removes the ambiguity entirely.

        The cost is roughly 33% payload inflation from base64 plus the JSON
        encode, so a 300 MB video becomes a ~400 MB request body. Long clips
        should be trimmed or downsampled before they get here, not after.
        """
        mime, _ = mimetypes.guess_type(path.name)
        if mime is None:
            mime = "video/mp4" if path.suffix.lower() in {".mp4", ".mov", ".mkv"} else "image/jpeg"
        payload = base64.b64encode(path.read_bytes()).decode("ascii")
        return f"data:{mime};base64,{payload}"

    def _resolve_media(self, item: str | Path, *, is_video: bool) -> str:
        """Turn one user-supplied reference into a URL the NIM can fetch.

        http(s) and data URLs pass through untouched — if you already have a URL
        the server can reach, inlining it would only waste bandwidth.
        """
        text = str(item)
        if text.startswith(("http://", "https://", "data:")):
            return text
        path = Path(text).expanduser()
        if not path.exists():
            raise FileNotFoundError(
                f"{path} does not exist. Media paths are resolved on THIS machine "
                f"and inlined into the request; the NIM never sees the path itself."
            )
        if is_video:
            path = self.ensure_h264(path)
        return self._data_url(path)

    def ensure_h264(self, video: str | Path, *, crf: int = 20) -> Path:
        """Return an H.264/yuv420p copy of ``video``, transcoding only if needed.

        **Why this exists.** The NIM decodes video with OpenCV, whose bundled
        FFmpeg build has no AV1 decoder. Feed it AV1 and it does not raise: it
        reads zero frames, sends an empty frame list to the model, and the server
        answers **HTTP 422**. Nothing in that error mentions codecs.

        This is not a rare edge case. LeRobot v3 datasets — the format all the
        Cosmos 3 action data ships in, per COSMOS3_FACTS.md §5 — store their
        video shards as AV1. So does most of what a modern phone or screen
        recorder produces.

        ``yuv420p`` is forced alongside H.264 because 10-bit or 4:2:2 H.264 hits
        the same wall: a valid H.264 stream that this decoder still cannot open.

        Results are cached in a temp directory, keyed on the source's resolved
        path, mtime and size — so editing the source invalidates the cache, and
        re-running a cell does not re-encode.

        If ``ffprobe`` is not installed we cannot tell what the codec is, so the
        file passes through unchanged with a warning. That is the right call: a
        needless transcode of an already-fine H.264 file costs minutes and loses
        quality, and most video already is H.264.
        """
        src = Path(video).expanduser().resolve()
        if not src.exists():
            raise FileNotFoundError(src)

        codec = self._probe_codec(src)
        if codec is None:
            if not self._warned_no_ffprobe:
                self._warned_no_ffprobe = True
                print(
                    "ffprobe not found, so video codecs cannot be checked. Passing "
                    "files through unchanged.\n"
                    "  If a video request comes back HTTP 422 with no obvious cause, "
                    "this is the first thing to suspect: the NIM cannot decode AV1 and "
                    "silently sees zero frames.\n"
                    "  Install ffmpeg (`apt install ffmpeg`) to make this automatic."
                )
            return src
        if codec == "h264":
            return src

        stat = src.stat()
        key = hashlib.sha1(
            f"{src}:{stat.st_mtime_ns}:{stat.st_size}".encode()
        ).hexdigest()[:12]
        self._transcode_dir.mkdir(parents=True, exist_ok=True)
        dst = self._transcode_dir / f"{src.stem}_{key}_h264.mp4"
        if dst.exists() and dst.stat().st_size > 0:
            return dst

        ffmpeg = shutil.which("ffmpeg")
        if ffmpeg is None:
            print(
                f"{src.name} is {codec}, which the NIM cannot decode, but ffmpeg is "
                f"not installed so it cannot be converted. Expect HTTP 422."
            )
            return src

        print(f"transcoding {src.name} from {codec} to H.264 (one time; cached)...")
        cmd = [
            ffmpeg, "-y", "-loglevel", "error", "-i", str(src),
            "-c:v", "libx264", "-crf", str(crf), "-preset", "veryfast",
            # Chroma subsampling and bit depth, not just the codec name: 10-bit
            # and 4:2:2 H.264 fail to open in the same decoder for the same
            # practical reason.
            "-pix_fmt", "yuv420p",
            "-movflags", "+faststart",
            # Audio is dropped. The Reasoner NIM is vision-language; carrying an
            # audio track only inflates the base64 payload.
            "-an",
            str(dst),
        ]
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=3600)
        except subprocess.CalledProcessError as exc:
            dst.unlink(missing_ok=True)
            raise RuntimeError(
                f"ffmpeg could not transcode {src.name}:\n{(exc.stderr or '').strip()[-1500:]}"
            ) from None
        except subprocess.TimeoutExpired:
            dst.unlink(missing_ok=True)
            raise RuntimeError(
                f"transcoding {src.name} took over an hour and was abandoned. Trim the "
                f"clip first — a reasoner request over a video this long will not fit "
                f"in the KV cache anyway."
            ) from None
        return dst

    @staticmethod
    def _probe_codec(path: Path) -> str | None:
        """Video codec name via ffprobe, or None if ffprobe is unavailable."""
        ffprobe = shutil.which("ffprobe")
        if ffprobe is None:
            return None
        try:
            out = subprocess.run(
                [ffprobe, "-v", "error", "-select_streams", "v:0",
                 "-show_entries", "stream=codec_name",
                 "-of", "default=nw=1:nk=1", str(path)],
                capture_output=True, text=True, timeout=120, check=True,
            )
        except (subprocess.SubprocessError, OSError):
            return None
        return (out.stdout.strip().splitlines() or [""])[0].strip().lower() or None

    # -- request construction ---------------------------------------------
    def _build_content(
        self,
        prompt: str,
        images: Sequence[str | Path] | str | Path | None,
        videos: Sequence[str | Path] | str | Path | None,
        fps: float,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """Assemble the multimodal content list and any extra_body fps setting.

        Media parts come **before** the text part. That is the convention every
        VLM chat template in this family expects; putting the question first
        works often enough to hide the problem and then fails on the one prompt
        that depends on ordering.
        """
        content: list[dict[str, Any]] = []
        extra_body: dict[str, Any] = {}

        for item in _as_sequence(images):
            content.append({
                "type": "image_url",
                "image_url": {"url": self._resolve_media(item, is_video=False)},
            })

        video_items = _as_sequence(videos)
        for item in video_items:
            part: dict[str, Any] = {
                "type": "video_url",
                "video_url": {"url": self._resolve_media(item, is_video=True)},
            }
            if video_items and self.fps_mode == "video_url":
                part["video_url"]["fps"] = fps
            content.append(part)

        if video_items and self.fps_mode == "extra_body":
            extra_body["fps"] = fps

        content.append({"type": "text", "text": prompt})
        return content, extra_body

    # -- the call ---------------------------------------------------------
    def ask(
        self,
        prompt: str,
        *,
        images: Sequence[str | Path] | str | Path | None = None,
        videos: Sequence[str | Path] | str | Path | None = None,
        fps: float = 4.0,
        max_tokens: int = 4096,
        temperature: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        repetition_penalty: float | None = None,
        presence_penalty: float | None = None,
        seed: int | None = None,
        stream: bool = False,
        system: str | None = None,
    ) -> str:
        """Send one chat completion and return the assistant's text.

        Every sampling parameter defaults to ``None``, meaning "do not send it,
        use the server's default". That matters more than it looks: quietly
        substituting your own ``temperature=0.7`` makes a lesson's results
        irreproducible against the NIM's documented defaults and hides which
        knob is responsible when output changes.

        ``top_k`` and ``repetition_penalty`` are not part of the OpenAI schema.
        They go through ``extra_body``, which the client passes to the server
        verbatim — the NIM's vLLM backend accepts them there.
        """
        client = self._openai()
        content, extra_body = self._build_content(prompt, images, videos, fps)

        messages: list[dict[str, Any]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": content})

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "stream": stream,
        }
        for key, value in (
            ("temperature", temperature),
            ("top_p", top_p),
            ("presence_penalty", presence_penalty),
            ("seed", seed),
        ):
            if value is not None:
                payload[key] = value
        for key, value in (("top_k", top_k), ("repetition_penalty", repetition_penalty)):
            if value is not None:
                extra_body[key] = value
        if extra_body:
            payload["extra_body"] = extra_body

        started = time.perf_counter()
        if stream:
            text, usage = self._call_streaming(client, payload)
        else:
            text, usage = self._call_blocking(client, payload)
        elapsed = time.perf_counter() - started

        self._record(elapsed, usage, prompt, len(_as_sequence(images)), len(_as_sequence(videos)))
        return text

    def _call_blocking(self, client: Any, payload: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        response = self._call_with_retry(lambda: client.chat.completions.create(**payload))
        self.last_response = response
        text = response.choices[0].message.content or ""
        usage = _usage_dict(getattr(response, "usage", None))
        return text, usage

    def _call_streaming(self, client: Any, payload: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        """Stream tokens to stdout as they arrive, and return the whole string.

        ``stream_options={"include_usage": True}`` asks the server to append a
        final chunk carrying token counts, which a stream otherwise does not
        report. Not every server accepts the option, so a rejection falls back
        to streaming without it and estimating.
        """
        import openai  # already proven importable by _openai()

        payload = dict(payload)
        payload["stream_options"] = {"include_usage": True}

        def _open():
            return client.chat.completions.create(**payload)

        try:
            stream = self._call_with_retry(_open)
        except openai.BadRequestError:
            payload.pop("stream_options", None)
            stream = self._call_with_retry(lambda: client.chat.completions.create(**payload))

        chunks: list[str] = []
        usage: dict[str, Any] = {}
        for event in stream:
            if getattr(event, "usage", None):
                usage = _usage_dict(event.usage)
            if not event.choices:
                continue                       # the usage-only final chunk
            piece = event.choices[0].delta.content or ""
            if piece:
                chunks.append(piece)
                sys.stdout.write(piece)
                sys.stdout.flush()
        text = "".join(chunks)
        if not usage:
            # ~4 characters per token is a rough English average. Marked as an
            # estimate so Lesson 14 does not quietly report it as measured.
            usage = {"completion_tokens": max(1, len(text) // 4), "estimated": True}
        print()
        return text, usage

    def _call_with_retry(self, fn: Any) -> Any:
        """Call ``fn``, retrying transient failures with exponential backoff.

        Retries only on classes of failure that a retry can actually fix:
        connection refused (the NIM is still loading), timeouts, 429 and 5xx.
        A 400 or a 422 is a bad request; retrying it four times just makes you
        wait four times longer for the same error.
        """
        import openai

        transient = (
            openai.APIConnectionError,
            openai.APITimeoutError,
            openai.RateLimitError,
            openai.InternalServerError,
        )

        delay = 2.0
        last: Exception | None = None
        for attempt in range(1, max(1, self.max_retries) + 1):
            try:
                return fn()
            except openai.UnprocessableEntityError as exc:      # HTTP 422
                self._explain_422(exc)
                raise
            except transient as exc:
                last = exc
                if attempt >= self.max_retries:
                    break
                print(
                    f"  {type(exc).__name__} talking to {self.base_url} "
                    f"(attempt {attempt}/{self.max_retries}); retrying in {delay:.0f}s"
                )
                time.sleep(delay)
                delay *= 2

        raise RuntimeError(
            f"could not reach the Reasoner NIM at {self.base_url} after "
            f"{self.max_retries} attempts.\n"
            f"  Last error: {type(last).__name__}: {last}\n\n"
            f"  Check, in order:\n"
            f"    1. from cosmos_course.nim import print_status; print_status()\n"
            f"    2. print(nim_logs(cfg, tail=50))\n"
            f"    3. Is NIM_BASE_URL pointing where you think? Currently "
            f"{self.base_url!r}.\n"
            f"    4. If the NIM is still loading weights, this is expected — the "
            f"first start downloads 20 GB. Wait, then retry."
        ) from last

    def _explain_422(self, exc: Exception) -> None:
        """Print the diagnosis for the error that costs people the most time."""
        detail = str(exc)
        print(
            "\nHTTP 422 (Unprocessable Entity) from the NIM.\n"
            "\n"
            "  In this course that almost always means ONE thing: the server could\n"
            "  not decode your video and ended up with zero frames. The NIM decodes\n"
            "  with OpenCV, which has no AV1 decoder, and LeRobot v3 datasets ship\n"
            "  AV1. The error message will not mention codecs.\n"
            "\n"
            "  In order of likelihood:\n"
            "    1. Undecodable video -> 0 frames. Fix:\n"
            "         path = reasoner.ensure_h264('clip.mp4')\n"
            "       If ffprobe is missing, that is a no-op and this is still your\n"
            "       problem — install ffmpeg.\n"
            f"    2. The fps field is being sent in a shape this server rejects.\n"
            f"       Current mode: {self.fps_mode!r}. Try Reasoner(fps_mode='off').\n"
            "       See the VIDEO_FPS_MODE comment at the top of models.py.\n"
            "    3. The request is too large. A long base64-inlined video can\n"
            "       exceed the server's body limit. Trim the clip.\n"
            "    4. A content part is malformed (wrong 'type', or an image passed\n"
            "       in the videos= argument).\n"
            f"\n  Server said: {detail[:600]}\n"
        )

    def _record(
        self,
        elapsed: float,
        usage: dict[str, Any],
        prompt: str,
        n_images: int,
        n_videos: int,
    ) -> None:
        """Stash timing and token counts on the instance for Lesson 14.

        Kept as plain attributes plus an append-only ``history`` list rather than
        anything cleverer, because the lesson's job is to *look* at these numbers
        and a dataclass would only get in the way.
        """
        self.last_latency_s = round(elapsed, 3)
        self.last_usage = usage
        completion = usage.get("completion_tokens")
        self.last_tokens_per_second = (
            round(completion / elapsed, 2) if completion and elapsed > 0 else None
        )
        self.history.append({
            "timestamp": time.time(),
            "latency_s": self.last_latency_s,
            "tokens_per_second": self.last_tokens_per_second,
            "prompt_chars": len(prompt),
            "images": n_images,
            "videos": n_videos,
            **usage,
        })

    def stats(self) -> dict[str, Any]:
        """Aggregate what has been measured so far. Empty dict before any call."""
        if not self.history:
            return {}
        latencies = [h["latency_s"] for h in self.history if h.get("latency_s")]
        rates = [h["tokens_per_second"] for h in self.history if h.get("tokens_per_second")]
        prompt_tokens = [h["prompt_tokens"] for h in self.history if h.get("prompt_tokens")]
        out: dict[str, Any] = {"calls": len(self.history)}
        if latencies:
            out["median_latency_s"] = round(sorted(latencies)[len(latencies) // 2], 3)
            out["total_latency_s"] = round(sum(latencies), 2)
        if rates:
            out["median_tokens_per_second"] = round(sorted(rates)[len(rates) // 2], 2)
        if prompt_tokens:
            out["max_prompt_tokens"] = max(prompt_tokens)
        return out

    # -- higher-level conveniences ----------------------------------------
    def think(self, prompt: str, **kwargs: Any) -> tuple[str, str]:
        """Ask with the course's ``<think>`` wrapper. Returns ``(reasoning, answer)``.

        If the model ignores the instruction — which it sometimes does on short
        factual questions — you get ``("", answer)`` rather than an exception.
        An empty reasoning string is information, not a failure: it tells you
        the prompt was not forceful enough, which is a thing you can fix.
        """
        text = self.ask(THINK_TEMPLATE.format(prompt=prompt), **kwargs)
        return split_think(text)

    @staticmethod
    def parse_json(text: str, after_think: bool = False) -> Any:
        """Extract the first JSON array or object from model output.

        Handles the four ways models wrap JSON in practice: markdown fences,
        prose before it, prose after it, and a preceding ``<think>`` block.

        ``after_think=False`` by default because ``think()`` already returns the
        answer separately; set it to True when you are handing in raw output that
        still contains the reasoning. It matters — a reasoning block often
        contains a *draft* of the JSON, and parsing that instead of the final
        answer produces a plausible wrong result rather than an error.

        Raises ``ValueError`` with the offending text rather than returning
        ``None`` or ``[]``, because a silent empty result hides a prompt problem
        until it is much harder to attribute.
        """
        body = split_think(text)[1] if after_think else text
        # Strip fences before scanning: ``` inside a JSON string is not a thing,
        # so this is safe, and a fenced block otherwise defeats the scanner's
        # first-brace heuristic when there is prose containing a stray "{".
        body = re.sub(r"```[a-zA-Z0-9_+-]*", "", body).replace("```", "").strip()

        candidate = _extract_json_blob(body) or body
        try:
            return json.loads(candidate)
        except json.JSONDecodeError as exc:
            preview = text if len(text) <= 500 else text[:500] + " ..."
            raise ValueError(
                f"no valid JSON found in the model output ({exc}).\n"
                f"  This usually means the prompt did not pin the format tightly "
                f"enough. Naming the exact keys you want, and saying 'reply with "
                f"JSON only', fixes it most of the time.\n"
                f"---\n{preview}"
            ) from exc

    def health(self) -> bool:
        """True if /v1/health/ready answers 200. Cheap enough to call in a guard."""
        req = urllib.request.Request(self.base_url + "/v1/health/ready")
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.status == 200
        except Exception:
            return False


def _as_sequence(value: Sequence[str | Path] | str | Path | None) -> list[str | Path]:
    """Normalise ``None`` / one item / many items into a list.

    A bare string is iterable, so ``for x in videos`` on ``videos="clip.mp4"``
    would loop over eleven characters and try to inline each one. This exists to
    stop that.
    """
    if value is None:
        return []
    if isinstance(value, (str, Path)):
        return [value]
    return list(value)


def _usage_dict(usage: Any) -> dict[str, Any]:
    """Pull token counts off an OpenAI usage object, tolerating a missing one."""
    if usage is None:
        return {}
    out: dict[str, Any] = {}
    for name in ("prompt_tokens", "completion_tokens", "total_tokens"):
        value = getattr(usage, name, None)
        if value is not None:
            out[name] = value
    return out


# --------------------------------------------------------------------------
# RunResult
# --------------------------------------------------------------------------
@dataclass
class RunResult:
    """What came out of one ``Generator.run``, and whether to believe it.

    The important member is ``ok``. It requires **both** a zero exit code and at
    least one output file, because on this stack the two really do come apart:
    COSMOS3_FACTS-adjacent experience and the framework's own issue tracker both
    record runs that exit 0 having written nothing, or having written a valid
    file full of noise. ``cosmos_course.checks.verify_result`` goes further and
    inspects the content; use it after every run.
    """

    returncode: int
    seconds: float
    outputs: list[Path] = field(default_factory=list)
    stdout_tail: str = ""
    command: list[str] = field(default_factory=list)
    output_dir: Path | None = None
    spec_path: Path | None = None
    timed_out: bool = False

    # Lazily-loaded cache for sample_outputs; not a constructor argument.
    _sample_cache: Any = field(default=None, repr=False, compare=False)

    # -- success ----------------------------------------------------------
    @property
    def ok(self) -> bool:
        """Zero exit code AND at least one output file. Both, not either."""
        return self.returncode == 0 and bool(self.outputs)

    def __bool__(self) -> bool:
        return self.ok

    # -- typed views over the outputs -------------------------------------
    @property
    def videos(self) -> list[Path]:
        return [p for p in self.outputs if p.suffix.lower() == ".mp4"]

    @property
    def images(self) -> list[Path]:
        return [p for p in self.outputs if p.suffix.lower() in {".jpg", ".jpeg", ".png"}]

    @property
    def jsons(self) -> list[Path]:
        return [p for p in self.outputs if p.suffix.lower() == ".json"]

    # These four singular aliases exist so `checks.verify_result(result)` can
    # consume a RunResult without knowing anything about this module.
    @property
    def video_path(self) -> Path | None:
        return self.videos[0] if self.videos else None

    @property
    def image_path(self) -> Path | None:
        return self.images[0] if self.images else None

    @property
    def text_path(self) -> Path | None:
        """A .txt output, if the mode produced one (reasoner runs do)."""
        for p in self.outputs:
            if p.suffix.lower() == ".txt":
                return p
        return None

    @property
    def sample_outputs(self) -> Any:
        """The first JSON output, parsed. ``{}`` when there is none.

        Action modes write their predicted trajectory here, which is what
        ``checks.check_action`` reads.
        """
        if self._sample_cache is None:
            self._sample_cache = {}
            for path in self.jsons:
                try:
                    self._sample_cache = json.loads(path.read_text())
                    break
                except (json.JSONDecodeError, OSError):
                    continue
        return self._sample_cache

    # -- explaining a failure ---------------------------------------------
    def diagnose(self) -> list[str]:
        """Match the captured output against known failure modes."""
        return diagnose(self.stdout_tail, timed_out=self.timed_out, outputs=self.outputs,
                        returncode=self.returncode)

    def summary(self) -> str:
        lines = [
            f"exit code   : {self.returncode}" + ("  (TIMED OUT)" if self.timed_out else ""),
            f"wall clock  : {self.seconds:.1f} s",
            f"outputs     : {len(self.outputs)} file(s)",
        ]
        for path in self.outputs[:10]:
            size_mb = path.stat().st_size / 1e6 if path.exists() else 0.0
            lines.append(f"              {path.name}  ({size_mb:.2f} MB)")
        if len(self.outputs) > 10:
            lines.append(f"              ... and {len(self.outputs) - 10} more")
        lines.append(f"verdict     : {'OK' if self.ok else 'FAILED'}")
        if not self.ok:
            for hint in self.diagnose():
                lines.append("")
                lines.append(hint)
        return "\n".join(lines)


# Backwards-compatible alias. `cosmos_course/__init__.py` and the earlier
# notebooks import GenerationResult; RunResult is the name used from here on
# because these results are not always generations (inverse_dynamics returns
# actions, reasoner returns text).
GenerationResult = RunResult


# --------------------------------------------------------------------------
# Failure diagnosis
# --------------------------------------------------------------------------
def diagnose(
    text: str,
    *,
    timed_out: bool = False,
    outputs: Iterable[Path] = (),
    returncode: int = 1,
) -> list[str]:
    """Pattern-match framework output against failures this course has hit.

    Returns a list of explanations, most likely first. An empty list means "no
    known pattern matched" — read the tail yourself, it is not a claim that
    nothing is wrong.

    Every entry names a specific fix rather than a category, because "you ran out
    of memory" is not actionable and "drop resolution to 480 and num_frames to
    61, then re-run" is.
    """
    hints: list[str] = []
    low = text.lower()
    produced = list(outputs)

    if timed_out:
        hints.append(
            "TIMED OUT. The process was killed, so any partial output is garbage.\n"
            "  A 480p / 121-frame Edge run takes minutes, not hours; if you were\n"
            "  near the timeout, the run was probably stuck rather than slow.\n"
            "  Check `nvidia-smi` during the next attempt: 0% utilisation means\n"
            "  it is downloading weights, not computing."
        )

    # 1. CUDA out of memory ------------------------------------------------
    if "out of memory" in low or "outofmemoryerror" in low or "cuda oom" in low:
        hints.append(
            "CUDA OUT OF MEMORY.\n"
            "  First, check nothing else owns the card:\n"
            "      from cosmos_course.nim import print_status, stop_nim\n"
            "      print_status()          # is the Reasoner NIM still holding VRAM?\n"
            "      stop_nim()              # it reserves most of the card by default\n"
            "  Then reduce the job, in this order (cheapest quality loss first):\n"
            "      resolution='480'        # or '256'; cost scales with pixels\n"
            "      num_frames=61           # cost scales linearly with frames\n"
            "      num_steps=25            # cost scales linearly with steps\n"
            "      offload_guardrails=True # frees ~4 GB during denoising\n"
            "      checkpoint='Cosmos3-Edge'   # 4B instead of Nano's 8B active\n"
            "  And set the allocator hint, which this module already does:\n"
            "      PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True\n"
            "  Note Cosmos3-Super needs ~128 GB and will never fit one H100."
        )

    # 2. Gated repository --------------------------------------------------
    gated_markers = (
        "gatedrepoerror", "access to model", "is restricted", "awaiting a review",
        "cannot access gated repo", "you must be authenticated",
    )
    if any(m in low for m in gated_markers) or (
        ("401" in text or "403" in text) and "huggingface" in low
    ):
        hints.append(
            "GATED HUGGING FACE REPO (401/403).\n"
            "  There is exactly ONE gated repo in the whole Cosmos 3 stack:\n"
            "      nvidia/Cosmos-Guardrail1\n"
            "  It is not a Cosmos 3 checkpoint — all nine of those are ungated now,\n"
            "  despite what older course material says. The guardrail is enabled by\n"
            "  default, which is why an ungated generation run still hits this.\n"
            "  Fix, once:\n"
            "    1. Open https://huggingface.co/nvidia/Cosmos-Guardrail1 and accept\n"
            "       the licence (one click; access is granted immediately).\n"
            "    2. Make sure your token is visible to the subprocess:\n"
            "         export HF_TOKEN=hf_...      # or `huggingface-cli login`\n"
            "    3. Verify: check_hf_access('nvidia/Cosmos-Guardrail1')\n"
            "  You *can* pass --no-guardrails to skip it entirely. Understand what\n"
            "  you are turning off before you do: it is the safety filter, and\n"
            "  disabling it is a decision, not a workaround."
        )

    # 3. Missing / unresolvable checkpoint ---------------------------------
    checkpoint_markers = (
        "repositorynotfounderror", "localentrynotfounderror", "is not a local folder",
        "couldn't connect to", "could not connect to", "no such file or directory",
        "checkpoint not found", "entrynotfounderror",
    )
    if any(m in low for m in checkpoint_markers):
        hints.append(
            "CHECKPOINT NOT FOUND / NOT DOWNLOADED.\n"
            "  The framework resolves --checkpoint-path as a Hugging Face repo name\n"
            "  first and a local directory second.\n"
            "    - Spelling is exact and case-sensitive: 'Cosmos3-Edge', not\n"
            "      'cosmos3-edge' and not 'Cosmos-3-Edge'.\n"
            "    - Offline? Set HF_HUB_OFFLINE=0, or pre-download with\n"
            "        huggingface-cli download nvidia/Cosmos3-Edge\n"
            "    - Check the cache actually has it:  du -sh ~/.cache/huggingface/hub\n"
            "    - Edge is ~9.1 GB, Nano ~34.9 GB, Super ~133 GB. A partial download\n"
            "      from an interrupted run looks exactly like this."
        )

    # 4. model_mode not recognised (the policy -> wam rename) --------------
    mode_markers = (
        "is not a valid modelmode", "unexpected value", "permitted:",
        "invalid model_mode", "modelmode",
    )
    if "policy" in low and any(m in low for m in mode_markers):
        hints.append(
            "MODEL MODE 'policy' DOES NOT EXIST.\n"
            "  Upstream renamed it to 'wam' (World Action Model). The old name is\n"
            "  still in the source DLI course, in docs/inference.md, in docs/faq.md\n"
            "  and in the action cookbook README — all of which are stale. The enum\n"
            "  is the truth.\n"
            "  Fix:  spec['model_mode'] = 'wam'\n"
            "  or use cosmos_course.specs.normalize_policy_mode(), which does the\n"
            "  rename for you. Shipped inputs named action_policy_*.json already\n"
            "  contain \"model_mode\": \"wam\" inside; only the filenames still say\n"
            "  policy."
        )
    elif any(m in low for m in mode_markers) and "model_mode" in low:
        hints.append(
            "UNRECOGNISED model_mode.\n"
            "  Valid modes are: text2image, text2video, image2image, image2video,\n"
            "  video2video, audio_image2video, forward_dynamics, inverse_dynamics,\n"
            "  wam, reasoner.\n"
            "  Two things people expect to be modes and are not:\n"
            "    - 'policy' was renamed to 'wam'.\n"
            "    - 'transfer' is not a mode; it is video2video plus an edge/blur/\n"
            "      depth/seg control block in the spec."
        )

    # 5. Port already in use ----------------------------------------------
    if "address already in use" in low or "eaddrinuse" in low or "rendezvous" in low:
        hints.append(
            "DISTRIBUTED PORT ALREADY IN USE.\n"
            "  torchrun and the single-process launcher both need a free MASTER_PORT.\n"
            "  This module picks one by binding port 0 and asking the OS, so this\n"
            "  should not happen — unless a previous run is still alive and holding\n"
            "  it. Look for orphans:\n"
            "      ps aux | grep cosmos_framework\n"
            "      nvidia-smi                 # do they still hold VRAM?\n"
            "  Kill them before retrying; a zombie run will also cause the next\n"
            "  attempt to OOM."
        )

    # 6. Disk full ---------------------------------------------------------
    if "no space left on device" in low or "errno 28" in low:
        hints.append(
            "DISK FULL.\n"
            "  Budget ~150 GiB for a first full run: ~90 GiB Hugging Face cache,\n"
            "  ~20 GiB uv cache, ~30 GiB outputs.\n"
            "      df -h ~ ; du -sh ~/.cache/huggingface ~/.cache/uv\n"
            "      docker system prune        # the NIM image alone is 8.3 GB\n"
            "  A partially-written checkpoint left behind by a full disk will then\n"
            "  fail as 'checkpoint not found', so clear the cache entry too."
        )

    # 7. The libtorch shadowing problem -----------------------------------
    if "undefined symbol" in low or "libtorch" in low or "libc10" in low:
        hints.append(
            "LIBRARY SYMBOL MISMATCH (undefined symbol / libtorch).\n"
            "  Inside the NGC PyTorch container, the bundled libtorch on\n"
            "  LD_LIBRARY_PATH shadows the framework venv's own copy, and you get an\n"
            "  undefined-symbol error that reads like a broken install.\n"
            "  This module already sets LD_LIBRARY_PATH='' for the subprocess. If you\n"
            "  are seeing it anyway, something is re-adding it — check the venv's\n"
            "  activate script and any conda hooks."
        )

    # 8. Unknown key in the spec ------------------------------------------
    if "extra inputs are not permitted" in low or 'extra="forbid"' in low:
        hints.append(
            "UNKNOWN KEY IN THE SPEC.\n"
            "  The framework validates sample args with extra='forbid', so a typo in\n"
            "  a field name is a hard error rather than a silently ignored key —\n"
            "  which is a good design and an annoying five minutes. Check the field\n"
            "  named in the traceback against cosmos_course.specs.InferenceSpec,\n"
            "  and remember num_steps is not num_inference_steps."
        )

    # 9. Ran clean but produced nothing ------------------------------------
    if returncode == 0 and not produced and not hints:
        hints.append(
            "EXITED CLEANLY BUT WROTE NO OUTPUT FILES.\n"
            "  This is the failure mode that makes exit codes untrustworthy. Usual\n"
            "  causes:\n"
            "    - The guardrail rejected the prompt. It fails quietly; search the\n"
            "      full log for 'guardrail' or 'blocked'.\n"
            "    - Output went somewhere else. The framework writes under -o, but a\n"
            "      spec 'name' field with a path separator in it will nest deeper\n"
            "      than you expect. Check `find <output_dir> -newer <spec>`.\n"
            "    - IMAGINAIRE_OUTPUT_ROOT is set in your environment and is winning."
        )

    return hints


# --------------------------------------------------------------------------
# Generator
# --------------------------------------------------------------------------
class Generator:
    """Runs Cosmos Framework inference as a subprocess against its own venv.

    >>> from cosmos_course.specs import InferenceSpec
    >>> gen = Generator()
    >>> spec = InferenceSpec(model_mode="text2video", name="demo",
    ...                      prompt="a robot folding a towel",
    ...                      resolution="480", num_frames=61)
    >>> result = gen.run(spec, "outputs/demo")
    >>> print(result.summary())

    **Not in-process, and not by accident.** The framework lives in its own uv
    virtualenv (``<repo>/.venv``) with its own torch, its own flash-attn build
    and its own CUDA wheels. Your notebook kernel is a different interpreter with
    different pins, and the framework's own dependency groups conflict with each
    other (``vllm`` versus every ``cu*`` group), so no single environment holds
    both. Importing across that boundary would either fail immediately or, worse,
    half-work. Running the documented command line as a child process keeps the
    two environments genuinely separate, returns all VRAM when the process exits,
    and means an error you hit here is an error upstream will recognise.
    """

    def __init__(
        self,
        repo: Path | str | None = None,
        checkpoint: str = "Cosmos3-Edge",
        *,
        num_gpus: int = 1,
        parallelism_preset: str | None = None,
        python: Path | str | None = None,
    ) -> None:
        self.repo = Path(repo).expanduser().resolve() if repo else COSMOS3_REPO
        self.checkpoint = checkpoint
        self.num_gpus = max(1, num_gpus)
        # None means "choose per mode": throughput for generation, latency for
        # the action modes. Set it explicitly only when you are deliberately
        # comparing the two, as Lesson 06's exercise does.
        self.parallelism_preset = parallelism_preset
        self.python = Path(python) if python else self.repo / ".venv" / "bin" / "python"

    # -- preflight ---------------------------------------------------------
    def check(self, *, verbose: bool = True) -> list[str]:
        """Look for the things that make a run fail before it starts."""
        problems: list[str] = []
        if not self.repo.exists():
            problems.append(
                f"the framework checkout is not at {self.repo}. Clone it, or set "
                f"COSMOS3_REPO in your environment:\n"
                f"    git clone https://github.com/NVIDIA/cosmos-framework\n"
                f"  (note: NVIDIA/cosmos-framework, not nvidia-cosmos/...)"
            )
        elif not self.python.exists():
            problems.append(
                f"no interpreter at {self.python}. The framework's venv has not been "
                f"created. From {self.repo}:\n"
                f"    uv sync --all-extras --group=cu128-train    # or cu130-train"
            )
        if verbose:
            for p in problems:
                print(f"  ! {p}")
            if not problems:
                print(f"framework ok: {self.repo}  ({self.checkpoint})")
        return problems

    # -- command construction ---------------------------------------------
    @staticmethod
    def _free_port() -> int:
        """Ask the OS for an unused local port.

        Hard-coding 29500 works right up until you run two things at once, or a
        previous run left a socket in TIME_WAIT, and then it fails with
        'Address already in use' from inside torch.distributed — an error that
        looks like a distributed-training problem on a single-GPU machine.
        Binding port 0 and reading back what the kernel gave us is free.
        """
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))
            return int(sock.getsockname()[1])

    def _build_command(
        self,
        spec_path: Path,
        output_dir: Path,
        model_mode: str,
        *,
        seed: int = 0,
        extra_args: Sequence[str] | None = None,
    ) -> tuple[list[str], dict[str, str]]:
        """Return ``(argv, env)`` for this run.

        Two documented launch shapes, chosen by mode:

        **Generation** (text2video, image2video, video2video, ...) uses
        ``torchrun`` with ``--parallelism-preset=throughput``. torchrun sets up
        the process group itself, so RANK/WORLD_SIZE/LOCAL_RANK must NOT be
        pre-set in the environment — a stale WORLD_SIZE inherited from an earlier
        cell makes torchrun and its workers disagree about the topology and hang
        at the rendezvous.

        **Action modes** (wam, forward_dynamics, inverse_dynamics) use a plain
        single-process ``python -m`` with ``--parallelism-preset=latency``. There
        is no launcher in that shape, so the distributed variables the framework
        expects have to be provided by hand, even for a world size of one.
        """
        from .specs import build_inference_command  # local: see class docstring

        is_action = model_mode in ACTION_MODEL_MODES
        preset = self.parallelism_preset or ("latency" if is_action else "throughput")

        argv, env_overrides = build_inference_command(
            spec_path,
            output_dir,
            checkpoint=self.checkpoint,
            framework_repo=self.repo,
            parallelism_preset=preset,   # type: ignore[arg-type]
            seed=seed,
            extra_args=list(extra_args) if extra_args else None,
        )

        env = dict(os.environ)
        env.update({k: str(v) for k, v in env_overrides.items()})

        port = self._free_port()
        env["MASTER_ADDR"] = env.get("MASTER_ADDR", "127.0.0.1")
        env["MASTER_PORT"] = str(port)

        # Inside the NGC PyTorch container (nvcr.io/nvidia/pytorch:25.09-py3),
        # LD_LIBRARY_PATH points at the image's bundled libtorch. That shadows
        # the framework venv's own copy and the import fails with an
        # undefined-symbol error that reads like a corrupt install. Clearing it
        # is documented in the framework FAQ and costs nothing outside a
        # container, so it is unconditional.
        env["LD_LIBRARY_PATH"] = ""

        # Stops ~/.local/lib/pythonX.Y/site-packages leaking into the venv. A
        # stray user-site torch or transformers silently takes precedence over
        # the pinned one and produces version errors that make no sense given
        # what `uv pip list` reports.
        env["PYTHONNOUSERSITE"] = "1"

        env.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

        if is_action:
            # Single process, no launcher: supply the world ourselves.
            env.update({"RANK": "0", "WORLD_SIZE": "1", "LOCAL_RANK": "0"})
            return argv, env

        # torchrun path. build_inference_command returns
        #   [<venv python>, "-m", "cosmos_framework.scripts.inference", ...]
        # so swapping element 0 for the launcher gives the documented
        #   torchrun --nproc-per-node=N -m cosmos_framework.scripts.inference ...
        for name in ("RANK", "WORLD_SIZE", "LOCAL_RANK"):
            env.pop(name, None)

        torchrun = self.repo / ".venv" / "bin" / "torchrun"
        if torchrun.exists():
            launcher = [str(torchrun)]
        else:
            # Same program, invoked through the interpreter. Used when the venv
            # layout differs (Windows, or a --no-scripts install).
            launcher = [str(self.python), "-m", "torch.distributed.run"]

        argv = launcher + [
            f"--nproc-per-node={self.num_gpus}",
            f"--master-port={port}",
        ] + argv[1:]
        return argv, env

    # -- running -----------------------------------------------------------
    def run(
        self,
        spec: Any,
        output_dir: Path | str,
        *,
        seed: int = 0,
        extra_args: Sequence[str] | None = None,
        stream_logs: bool = True,
        timeout: float | None = None,
    ) -> RunResult:
        """Run one inference job and return a ``RunResult``.

        ``spec`` may be an ``InferenceSpec``, a plain dict, a list of either
        (written as JSONL for a batch), or a path to a spec file you already
        have. Anything not already on disk is written into
        ``<output_dir>/_specs/`` so that a failed run leaves behind the exact
        input that produced it.
        """
        problems = self.check(verbose=False)
        if problems:
            raise RuntimeError("cannot run inference:\n  - " + "\n  - ".join(problems))

        output_dir = Path(output_dir).expanduser()
        output_dir.mkdir(parents=True, exist_ok=True)

        spec_path, model_mode = self._materialise_spec(spec, output_dir)
        argv, env = self._build_command(
            spec_path, output_dir, model_mode, seed=seed, extra_args=extra_args
        )

        if stream_logs:
            print("$ " + " ".join(argv))
            print(f"  cwd={self.repo}  mode={model_mode}  seed={seed}")
            print("-" * 72)

        started = time.monotonic()
        # Recorded before launching so file-collection can distinguish this
        # run's outputs from anything already in the directory. The 2-second
        # slack absorbs filesystem timestamp granularity and clock skew on
        # network mounts.
        wall_start = time.time() - 2.0

        returncode, lines, timed_out = self._spawn(argv, env, stream_logs, timeout)
        seconds = time.monotonic() - started

        outputs = self._collect_outputs(output_dir, since=wall_start)
        tail = "\n".join(lines[-400:])          # generous: diagnose() greps it

        result = RunResult(
            returncode=returncode,
            seconds=round(seconds, 2),
            outputs=outputs,
            stdout_tail=tail,
            command=argv,
            output_dir=output_dir,
            spec_path=spec_path,
            timed_out=timed_out,
        )

        if not result.ok:
            print("\n" + "=" * 72)
            print(
                f"RUN FAILED  (exit {returncode}, {seconds:.1f}s, "
                f"{len(outputs)} output file(s))"
            )
            print("=" * 72)
            print("last 40 lines:\n")
            for line in lines[-40:]:
                print("  " + line)
            hints = result.diagnose()
            if hints:
                print("\n" + "-" * 72)
                for hint in hints:
                    print(hint)
                    print()
            else:
                print(
                    "\nNo known failure pattern matched. Read the full output above; "
                    "\nthe complete log is in RunResult.stdout_tail."
                )
        elif stream_logs:
            print("-" * 72)
            print(result.summary())

        return result

    def _spawn(
        self,
        argv: list[str],
        env: dict[str, str],
        stream_logs: bool,
        timeout: float | None,
    ) -> tuple[int, list[str], bool]:
        """Launch, stream, capture. Returns ``(returncode, lines, timed_out)``.

        stderr is merged into stdout so the log stays in causal order — torch
        warnings and the framework's progress output land on different streams
        and interleaving them after the fact is impossible.

        A reader thread feeds a queue rather than the main thread iterating
        ``proc.stdout`` directly. Iterating blocks until the next line arrives,
        which means a *hung* process — the case a timeout exists for — would
        never be noticed.
        """
        popen_kwargs: dict[str, Any] = {}
        if os.name == "posix":
            # Its own process group, so a timeout can kill torchrun *and* the
            # worker it spawned. Killing only the parent leaves a worker holding
            # 40 GB of VRAM and the next run OOMs for no visible reason.
            popen_kwargs["start_new_session"] = True

        proc = subprocess.Popen(
            argv,
            cwd=str(self.repo),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            errors="replace",
            **popen_kwargs,
        )

        lines: list[str] = []
        pipe: queue.Queue[str | None] = queue.Queue()

        def _pump() -> None:
            assert proc.stdout is not None
            for raw in proc.stdout:
                pipe.put(raw.rstrip("\n"))
            pipe.put(None)

        reader = threading.Thread(target=_pump, daemon=True)
        reader.start()

        started = time.monotonic()
        timed_out = False
        on_progress_line = False

        while True:
            try:
                line = pipe.get(timeout=1.0)
            except queue.Empty:
                if timeout is not None and time.monotonic() - started > timeout:
                    timed_out = True
                    self._kill(proc)
                    break
                continue

            if line is None:
                break
            lines.append(line)

            if not stream_logs:
                continue

            # tqdm-style progress redraws in place instead of scrolling 500
            # nearly-identical lines past the reader.
            if _looks_like_progress(line):
                sys.stdout.write("\r  " + line[:110].ljust(112))
                sys.stdout.flush()
                on_progress_line = True
            else:
                if on_progress_line:
                    sys.stdout.write("\n")
                    on_progress_line = False
                print("  " + line)

        if on_progress_line:
            sys.stdout.write("\n")
            sys.stdout.flush()

        if timed_out:
            returncode = -1
        else:
            try:
                returncode = proc.wait(timeout=60)
            except subprocess.TimeoutExpired:
                self._kill(proc)
                returncode = -1
        reader.join(timeout=5)
        return returncode, lines, timed_out

    @staticmethod
    def _kill(proc: subprocess.Popen[str]) -> None:
        """Terminate the whole process group, politely then not."""
        try:
            if os.name == "posix":
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            else:
                proc.terminate()
            time.sleep(5)
            if proc.poll() is None:
                if os.name == "posix":
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                else:
                    proc.kill()
        except (ProcessLookupError, PermissionError, OSError):
            pass

    # -- inputs and outputs ------------------------------------------------
    def _materialise_spec(self, spec: Any, output_dir: Path) -> tuple[Path, str]:
        """Get ``spec`` onto disk and report its model_mode.

        The mode decides the launch shape, so it has to be known before the
        command is built — which is why this returns it rather than letting the
        caller dig it out.
        """
        from .specs import (  # local import: see class docstring
            InferenceSpec,
            normalize_policy_mode,
            validate_spec,
            write_spec,
            write_specs_jsonl,
        )

        spec_dir = output_dir / "_specs"

        # Already a file on disk.
        if isinstance(spec, (str, Path)) and Path(spec).expanduser().exists():
            path = Path(spec).expanduser().resolve()
            body = _first_json_record(path)
            return path, normalize_policy_mode(str(body.get("model_mode", "text2video")))

        # A batch.
        if isinstance(spec, (list, tuple)):
            items = list(spec)
            if not items:
                raise ValueError("empty spec list")
            if isinstance(items[0], InferenceSpec):
                path = write_specs_jsonl(items, spec_dir / "batch.jsonl")
                return path, normalize_policy_mode(items[0].model_mode)
            bodies = [dict(item) for item in items]
            spec_dir.mkdir(parents=True, exist_ok=True)
            path = spec_dir / "batch.jsonl"
            path.write_text("\n".join(json.dumps(b) for b in bodies) + "\n")
            return path, normalize_policy_mode(str(bodies[0].get("model_mode", "text2video")))

        # One InferenceSpec.
        if isinstance(spec, InferenceSpec):
            path = write_spec(spec, spec_dir, quiet=True)
            return path, normalize_policy_mode(spec.model_mode)

        # A plain dict. Validated non-strictly so the learner sees the problems
        # and still gets to run it — sometimes the validator is the thing that
        # is wrong, and this course would rather be argued with than obeyed.
        if isinstance(spec, dict):
            body = dict(spec)
            body["model_mode"] = normalize_policy_mode(str(body.get("model_mode", "")))
            for problem in validate_spec(body, strict=False):
                print(f"  spec warning: {problem}")
            spec_dir.mkdir(parents=True, exist_ok=True)
            path = spec_dir / f"{body.get('name', 'sample')}.json"
            path.write_text(json.dumps(body, indent=2) + "\n")
            return path, body["model_mode"]

        raise TypeError(
            f"spec must be an InferenceSpec, a dict, a list of either, or a path to "
            f"a spec file — got {type(spec).__name__}"
        )

    @staticmethod
    def _collect_outputs(output_dir: Path, *, since: float) -> list[Path]:
        """Find files this run wrote, newest last.

        Filtered by mtime rather than just listing the directory, because
        learners reuse output directories and stale files from a previous run
        would otherwise make a failed run look successful — precisely the
        mistake ``RunResult.ok`` exists to prevent.

        ``_specs`` is skipped: this module wrote those, so counting them as
        output would mean every run "produced a file".
        """
        found: list[Path] = []
        for path in output_dir.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in _OUTPUT_SUFFIXES:
                continue
            if "_specs" in path.parts:
                continue
            try:
                if path.stat().st_mtime >= since and path.stat().st_size > 0:
                    found.append(path)
            except OSError:
                continue
        return sorted(found, key=lambda p: p.stat().st_mtime)


def _looks_like_progress(line: str) -> bool:
    """True for tqdm/step lines that should redraw rather than scroll."""
    return ("it/s" in line) or ("s/it" in line) or ("%|" in line)


def _first_json_record(path: Path) -> dict[str, Any]:
    """Read a spec file, tolerating both JSON and JSONL. ``{}`` on failure."""
    try:
        text = path.read_text()
    except OSError:
        return {}
    try:
        data = json.loads(text)
        if isinstance(data, list):
            return data[0] if data and isinstance(data[0], dict) else {}
        return data if isinstance(data, dict) else {}
    except json.JSONDecodeError:
        for line in text.splitlines():          # JSONL
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                return {}
            return record if isinstance(record, dict) else {}
    return {}


# --------------------------------------------------------------------------
# Hugging Face access
# --------------------------------------------------------------------------
def check_hf_access(
    repo_id: str = "nvidia/Cosmos-Guardrail1", *, quiet: bool = False
) -> dict[str, Any]:
    """Can this machine download ``repo_id``? Checks gating and token together.

    Defaults to the guardrail because it is the **only** gated repo in the Cosmos
    3 stack — all nine Cosmos3 checkpoints are ungated as of August 2026, despite
    older course material spending a whole notebook on accepting their licences.
    The guardrail is enabled by default during generation, so an ungated run
    still needs this one click.

    The token is read from the environment to send as a bearer header and is
    never printed, logged or returned.
    """
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    headers = {"Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    out: dict[str, Any] = {
        "repo_id": repo_id,
        "token_present": bool(token),   # presence only; the value stays put
        "status": 0,
        "accessible": False,
        "gated": None,
    }

    req = urllib.request.Request(f"https://huggingface.co/api/models/{repo_id}", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            out["status"] = resp.status
            out["accessible"] = resp.status == 200
            body = json.loads(resp.read().decode("utf-8", "replace"))
            out["gated"] = body.get("gated", False)
    except urllib.error.HTTPError as exc:
        out["status"] = exc.code
    except Exception as exc:
        out["error"] = type(exc).__name__

    if not quiet:
        if out["accessible"]:
            gated = out["gated"]
            suffix = f" (gated: {gated}, and you have access)" if gated else " (not gated)"
            print(f"{repo_id}: accessible{suffix}")
        elif out["status"] in (401, 403):
            print(
                f"{repo_id}: HTTP {out['status']} — you cannot download this repo yet.\n"
                f"  1. Open https://huggingface.co/{repo_id} and accept the licence.\n"
                f"  2. export HF_TOKEN=hf_...    (or run `huggingface-cli login`)\n"
                f"  3. If running from Jupyter, restart the kernel so it inherits the\n"
                f"     new environment, then re-run this check."
            )
            if not out["token_present"]:
                print("  Note: no HF_TOKEN is set in this environment.")
        elif out["status"] == 404:
            print(f"{repo_id}: HTTP 404 — no such repo. Check the spelling and the org.")
        else:
            print(
                f"{repo_id}: could not check (status {out['status']}"
                + (f", {out['error']}" if out.get("error") else "")
                + "). Offline?"
            )
    return out
