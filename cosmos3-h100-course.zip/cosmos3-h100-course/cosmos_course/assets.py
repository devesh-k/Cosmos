"""Named lookups for the Cosmos cookbook sample media.

The notebooks refer to assets by short name — ``asset("video_caption")`` — so
that a change in the cookbook's directory layout is a one-line fix here rather
than an edit in nine notebooks.

The source DLI course also read one clip (``toaster_6sec.mp4``) from a private
NVIDIA S3 bucket via a side-car container. That file is not available outside
DLI infrastructure, so this course substitutes the public cookbook clips that
teach the same points. Those substitutions are marked below.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .config import COSMOS_ROOT

__all__ = ["ASSETS", "asset", "asset_or_none", "check_assets", "COOKBOOK"]

COOKBOOK = COSMOS_ROOT / "cookbooks" / "cosmos3"

_REASONER = "reasoner/assets"
_AUDIOVISUAL = "generator/audiovisual"
_TRANSFER = "generator/transfer"
_ACTION = "generator/action/assets"

# name -> (path relative to cookbooks/cosmos3, what it is for)
ASSETS: dict[str, tuple[str, str]] = {
    # ---- reasoner: images -------------------------------------------------
    "robot_workspace": (f"{_REASONER}/robot_153.jpg",
                        "Robot manipulation workspace. Set-of-Mark and captioning."),
    "robot_planning": (f"{_REASONER}/robot_planning.png",
                       "Tabletop scene with cameras. Planning and 2D grounding."),
    "grounding_2d": (f"{_REASONER}/grounding_2d.png",
                     "Scene for bounding-box grounding."),
    "describe_anything": (f"{_REASONER}/describe_anything.png",
                          "Region-level description reference image."),
    "action_cot": (f"{_REASONER}/action_cot_trajectory.png",
                   "Tabletop scene for predicting a 2D gripper trajectory."),

    # ---- reasoner: video --------------------------------------------------
    "video_caption": (f"{_REASONER}/video_caption.mp4",
                      "General clip for detailed captioning."),
    "robotics_next_action": (f"{_REASONER}/robotics_next_action.mp4",
                             "Robot mid-task. Next-action prediction."),
    "assisted_task": (f"{_REASONER}/assisted_task_next_action.mp4",
                      "Multi-step assisted procedure. SUBSTITUTE for the source course's "
                      "toaster_6sec.mp4, which came from a private DLI S3 bucket."),
    "common_sense": (f"{_REASONER}/common_sense_reasoning.mp4",
                     "Physical common-sense reasoning. Also substitutes for toaster_6sec.mp4."),
    "situation_understanding": (f"{_REASONER}/situation_understanding.mp4",
                                "Scene requiring situational inference."),
    "physical_plausibility": (f"{_REASONER}/physical_plausibility.mp4",
                              "Clip for judging whether what happens is physically possible."),
    "temporal_localization": (f"{_REASONER}/temporal_localization_1.mp4",
                              "Locating an event in time within a clip."),
    "drive_scene_next_action": (f"{_REASONER}/drive_scene_next_action.mp4",
                                "Driving scene. Next-action prediction for AV."),
    "action_cot_driving": (f"{_REASONER}/action_cot_driving_scene.mp4",
                           "Driving scene for action chain-of-thought."),

    # ---- generation prompts ----------------------------------------------
    "prompt_robot_kitchen": (f"{_AUDIOVISUAL}/assets/prompts/text2video/robot_kitchen.json",
                             "Structured text2video prompt: robot working in a kitchen."),
    "prompt_car_colliding": (f"{_AUDIOVISUAL}/assets/prompts/text2video/car_colliding.json",
                             "Structured text2video prompt: vehicle collision scenario."),
    "prompt_robot_draping": (f"{_AUDIOVISUAL}/assets/prompts/text2image/robot_draping.json",
                             "Structured text2image prompt."),
    "prompt_car_driving": (f"{_AUDIOVISUAL}/assets/prompts/image2video/car_driving.json",
                           "Structured image2video prompt matching car_driving.jpg."),
    "prompt_car_driving_edge": (f"{_AUDIOVISUAL}/assets/prompts/image2video/car_driving_edge.json",
                                "Edge-tier variant of the car_driving image2video prompt."),
    "prompt_humanoid_robot": (f"{_AUDIOVISUAL}/assets/prompts/image2video/humanoid_robot.json",
                              "Structured image2video prompt matching humanoid_robot.jpg."),
    "prompt_robot_pouring_audio": (
        f"{_AUDIOVISUAL}/assets/prompts/text2video/robot_pouring_water_audio.json",
        "Structured text2video prompt written for sound generation (Lesson 09)."),
    "prompt_coastal_road_audio": (
        f"{_AUDIOVISUAL}/assets/prompts/image2video/coastal_road_audio.json",
        "Structured prompt for the audio_image2video coastal road example (Lesson 09)."),
    "neg_prompt_t2v": (f"{_AUDIOVISUAL}/assets/negative_prompts/text2video/neg_prompt.json",
                       "Default negative prompt for text2video."),
    "neg_prompt_i2v": (f"{_AUDIOVISUAL}/assets/negative_prompts/image2video/neg_prompt.json",
                       "Default negative prompt for image2video."),

    # ---- generation conditioning images ----------------------------------
    "image_car_driving": (f"{_AUDIOVISUAL}/assets/images/image2video/car_driving.jpg",
                          "Still of a car on a road. image2video start frame."),
    "image_humanoid_robot": (f"{_AUDIOVISUAL}/assets/images/image2video/humanoid_robot.jpg",
                             "Humanoid robot still. image2video start frame."),
    "image_coastal_road_audio": (
        f"{_AUDIOVISUAL}/assets/images/image2video/coastal_road_audio.jpg",
        "Coastal road still. First frame for the audio_image2video example (Lesson 09)."),
    "video_car_driving_plain": (f"{_AUDIOVISUAL}/assets/videos/car_driving_plain.mp4",
                                "Unmodified driving clip. Source for video2video."),

    # ---- transfer (video2video control) ----------------------------------
    "spec_edge": (f"{_TRANSFER}/specs/edge.json", "Ready-made edge-control transfer spec."),
    "spec_blur": (f"{_TRANSFER}/specs/blur.json", "Ready-made blur-control transfer spec."),
    "spec_depth": (f"{_TRANSFER}/specs/depth.json", "Ready-made depth-control transfer spec."),
    "spec_seg": (f"{_TRANSFER}/specs/seg.json", "Ready-made segmentation-control transfer spec."),
    "spec_wsm": (f"{_TRANSFER}/specs/wsm.json", "Ready-made world-scenario-map transfer spec."),
    "spec_multi_control": (f"{_TRANSFER}/specs/multi_control.json", "Multiple controls at once."),
    "control_edge": (f"{_TRANSFER}/assets/edge/control_edge.mp4", "Edge control video (121 frames @30fps)."),
    "control_blur": (f"{_TRANSFER}/assets/blur/control_blur.mp4", "Blur control video."),
    "control_depth": (f"{_TRANSFER}/assets/depth/control_depth.mp4", "Depth control video."),
    "control_seg": (f"{_TRANSFER}/assets/seg/control_seg.mp4", "Segmentation control video."),
    "control_wsm": (f"{_TRANSFER}/assets/wsm/control_wsm.mp4",
                    "World-scenario-map control video (101 frames @ 10 FPS). Not a TransferHintKey member."),
    "transfer_prompt_edge": (f"{_TRANSFER}/assets/edge/prompt.json", "Prompt paired with the edge control."),
    "transfer_prompt_blur": (f"{_TRANSFER}/assets/blur/prompt.json", "Prompt paired with the blur control."),
    "transfer_prompt_depth": (f"{_TRANSFER}/assets/depth/prompt.json", "Prompt paired with the depth control."),
    "transfer_prompt_seg": (f"{_TRANSFER}/assets/seg/prompt.json", "Prompt paired with the seg control."),
    "transfer_prompt_wsm": (f"{_TRANSFER}/assets/wsm/prompt.json", "Prompt paired with the wsm control."),
    "transfer_negative_prompt": (f"{_TRANSFER}/assets/negative_prompt.json",
                                 "Negative prompt shared by every transfer spec."),

    # ---- action -----------------------------------------------------------
    "av_start_frame": (f"{_ACTION}/images/av_0.jpg", "AV ego camera start frame."),
    "av_start_frame_2": (f"{_ACTION}/images/av_1.jpg", "Second AV start frame."),
    "av_video": (f"{_ACTION}/videos/av_0.mp4", "AV ego clip. Inverse-dynamics input."),
    "av_video_2": (f"{_ACTION}/videos/av_1.mp4", "Second AV clip."),
    "av_traj_forward": (f"{_ACTION}/actions/av_traj_forward.json", "AV ego trajectory: straight ahead."),
    "av_traj_left": (f"{_ACTION}/actions/av_traj_left.json", "AV ego trajectory: bearing left."),
    "av_traj_right": (f"{_ACTION}/actions/av_traj_right.json", "AV ego trajectory: bearing right."),
    "camera_action": (f"{_ACTION}/actions/camera_action.json", "Camera-pose action sequence."),
    "umi_action": (f"{_ACTION}/actions/umi.json", "UMI gripper action sequence."),
    "umi_image": (f"{_ACTION}/images/umi.png", "UMI start observation."),
    "umi_video": (f"{_ACTION}/videos/umi.mp4", "UMI manipulation clip."),
    "robolab_rollout": (f"{_ACTION}/videos/robolab_example_rollout.mp4",
                        "Example closed-loop RoboLab rollout. Illustration only — the closed-loop "
                        "setup itself is out of scope for this single-GPU course."),
    "bridge_episode": (f"{_ACTION}/bridge_lerobot_example",
                       "LeRobot v3 Bridge episode (WidowX kitchen robot) for wam/policy."),
    "droid_episode": (f"{_ACTION}/droid_lerobot_example", "LeRobot v3 DROID episode, three camera views."),
}


def asset(name: str) -> Path:
    """Resolve a named cookbook asset to an absolute path.

    Raises with something actionable rather than a bare KeyError or a
    FileNotFoundError twenty cells later.
    """
    if name not in ASSETS:
        close = [k for k in ASSETS if name.lower() in k.lower()]
        suggestion = f" Did you mean: {', '.join(close[:5])}?" if close else ""
        raise KeyError(
            f"unknown asset {name!r}.{suggestion}\n"
            f"Known names: {', '.join(sorted(ASSETS))}"
        )

    rel, purpose = ASSETS[name]
    path = COOKBOOK / rel
    if not path.exists():
        raise FileNotFoundError(
            f"asset {name!r} ({purpose}) is not on disk.\n"
            f"  expected: {path}\n"
            f"  Run `python scripts/fetch_assets.py` to clone the Cosmos cookbook, "
            f"or set COSMOS_ROOT to an existing checkout."
        )
    return path


def asset_or_none(name: str) -> Path | None:
    """Resolve an asset, returning None instead of raising if it is missing.

    Useful in optional cells so a partially fetched checkout does not stop a
    whole notebook.
    """
    try:
        return asset(name)
    except (KeyError, FileNotFoundError):
        return None


def check_assets(names: list[str] | None = None, *, verbose: bool = True) -> dict[str, Any]:
    """Report which named assets are present.

    Run this near the top of any notebook that needs media, so a missing
    checkout surfaces immediately rather than after a model load.
    """
    names = names or sorted(ASSETS)
    present, missing = [], []
    for name in names:
        rel, _ = ASSETS[name]
        (present if (COOKBOOK / rel).exists() else missing).append(name)

    result = {
        "cookbook_root": str(COOKBOOK),
        "cookbook_present": COOKBOOK.is_dir(),
        "checked": len(names),
        "present": present,
        "missing": missing,
    }

    if verbose:
        if not COOKBOOK.is_dir():
            print(
                f"Cosmos cookbook not found at {COOKBOOK}\n"
                f"  Run: python scripts/fetch_assets.py\n"
                f"  Or:  export COSMOS_ROOT=/path/to/your/cosmos/checkout"
            )
        else:
            print(f"cookbook: {COOKBOOK}")
            print(f"  {len(present)}/{len(names)} assets present")
            if missing:
                print(f"  missing: {', '.join(missing[:8])}" + (" ..." if len(missing) > 8 else ""))
                print("  (the cookbook uses git-LFS for media; check `git lfs pull` ran)")
    return result
