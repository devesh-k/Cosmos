"""Visualisation: media display, spatial overlays, and pose/trajectory plots.

Everything here is course material. The source notebooks presented equivalent
helpers as opaque blocks; these are commented so a learner can read them and
know what to change.

Two display problems are solved here that are specific to running this locally:

* Large videos base64-embedded into notebook output make the file enormous and
  the front-end sluggish. ``show_video`` writes a small H.264 preview and
  embeds that instead, and it says so.
* The source notebook's preview helper hard-coded ``/dli/task`` and a ``/lab``
  base URL. Here paths are resolved relative to the course root instead.
"""

from __future__ import annotations

import base64
import html
import json
import re
import subprocess
import shutil
from pathlib import Path
from typing import Any, Iterable, Sequence

from .config import OUTPUT_ROOT

__all__ = [
    "show_image",
    "show_video",
    "make_preview",
    "parse_model_json",
    "split_think",
    "draw_boxes",
    "draw_trajectory",
    "mark_subjects",
    "plot_camera_trajectory",
    "plot_end_effector_path",
    "contact_sheet",
]

PREVIEW_DIR = OUTPUT_ROOT / "_previews"

# Distinct, colour-blind-friendly palette for overlays.
MARK_COLORS: list[tuple[int, int, int]] = [
    (230, 25, 75), (0, 130, 200), (60, 180, 75), (245, 130, 48),
    (145, 30, 180), (70, 240, 240), (240, 50, 230), (128, 128, 0),
]


# --------------------------------------------------------------------------
# Media display
# --------------------------------------------------------------------------
def _ffmpeg() -> str | None:
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return shutil.which("ffmpeg")


def make_preview(src: Path | str, *, crf: int = 30, width: int = 512, fps: int | None = None) -> Path:
    """Transcode to a small H.264 preview, cached by modification time.

    ``-movflags +faststart`` moves the moov atom to the front of the file so
    playback can begin before the whole thing has buffered. Without it an
    embedded video often shows a black frame that never starts.
    """
    src = Path(src)
    if not src.exists():
        raise FileNotFoundError(src)

    PREVIEW_DIR.mkdir(parents=True, exist_ok=True)
    dst = PREVIEW_DIR / f"{src.stem}_preview.mp4"
    if dst.exists() and dst.stat().st_mtime >= src.stat().st_mtime:
        return dst

    ffmpeg = _ffmpeg()
    if ffmpeg is None:
        return src  # no transcoder; caller falls back to the original

    cmd = [ffmpeg, "-y", "-loglevel", "error", "-i", str(src)]
    if fps:
        cmd += ["-r", str(fps)]
    cmd += [
        "-vf", f"scale={width}:-2",
        "-c:v", "libx264", "-crf", str(crf), "-preset", "veryfast",
        "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-an",
        str(dst),
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        return dst
    except subprocess.CalledProcessError:
        return src


def show_image(path: Path | str, *, width: int = 512, caption: str | None = None) -> None:
    """Display an image inline with an optional caption."""
    from IPython.display import HTML, Image, display

    path = Path(path)
    if not path.exists():
        print(f"missing image: {path}")
        return
    display(Image(filename=str(path), width=width))
    if caption:
        display(HTML(f'<div style="font-size:12px;opacity:.75">{html.escape(caption)}</div>'))


def show_video(
    path: Path | str,
    *,
    width: int = 512,
    preview: bool = True,
    caption: str | None = None,
) -> None:
    """Display a video inline, transcoding to a small preview first by default.

    Set ``preview=False`` to embed the original — useful when you are judging
    output quality and the preview's compression would confuse the assessment.
    Expect a much larger notebook file if you do.
    """
    from IPython.display import HTML, display

    path = Path(path)
    if not path.exists():
        print(f"missing video: {path}")
        return

    src = make_preview(path, width=width) if preview else path
    size_mb = src.stat().st_size / 1e6
    if size_mb > 12:
        print(
            f"note: {src.name} is {size_mb:.1f} MB. Embedding it will bloat this notebook; "
            f"open it from the outputs folder instead."
        )
        return

    data = base64.b64encode(src.read_bytes()).decode("ascii")
    label = caption or f"{path.name} ({path.stat().st_size / 1e6:.1f} MB source)"
    display(
        HTML(
            f'<video controls playsinline loop width="{width}" style="background:#000;border-radius:6px">'
            f'<source src="data:video/mp4;base64,{data}" type="video/mp4"></video>'
            f'<div style="font-family:ui-monospace,monospace;font-size:11px;opacity:.75">'
            f"{html.escape(label)}</div>"
        )
    )


def contact_sheet(paths: Sequence[Path | str], *, cols: int = 3, width: int = 240,
                  labels: Sequence[str] | None = None) -> None:
    """Show several images side by side for comparison.

    Comparison is the whole point of most generation experiments, and comparing
    stacked full-width images does not work.
    """
    from IPython.display import HTML, display

    cells = []
    for i, p in enumerate(paths):
        p = Path(p)
        if not p.exists():
            continue
        data = base64.b64encode(p.read_bytes()).decode("ascii")
        suffix = p.suffix.lstrip(".") or "png"
        label = labels[i] if labels and i < len(labels) else p.stem
        cells.append(
            f'<figure style="margin:0 8px 12px 0;display:inline-block;vertical-align:top">'
            f'<img src="data:image/{suffix};base64,{data}" width="{width}" '
            f'style="border-radius:4px;display:block">'
            f'<figcaption style="font-family:ui-monospace,monospace;font-size:11px;'
            f'opacity:.75;max-width:{width}px">{html.escape(label)}</figcaption></figure>'
        )
    if not cells:
        print("nothing to show")
        return
    display(HTML(f'<div style="max-width:{cols * (width + 16)}px">' + "".join(cells) + "</div>"))


# --------------------------------------------------------------------------
# Parsing model output
# --------------------------------------------------------------------------
def split_think(text: str) -> tuple[str, str]:
    """Split a chain-of-thought response into (reasoning, answer).

    Cosmos 3 does not have a reasoning mode flag; the ``<think>…</think>``
    structure appears because you asked for it in the prompt. That means the
    model can and sometimes does deviate — an unterminated ``<think>``, or none
    at all. This returns ``("", text)`` in that case rather than raising.
    """
    if "</think>" in text:
        before, _, after = text.partition("</think>")
        reasoning = before.replace("<think>", "").strip()
        return reasoning, after.strip()
    return "", text.strip()


def parse_model_json(text: str, *, after_think: bool = True) -> list[dict[str, Any]]:
    """Extract JSON from model output, tolerating the ways models wrap it.

    Handles: markdown code fences, prose before or after, a bare object where
    a list was requested, and a reasoning block preceding the answer.

    Raises ``ValueError`` with the offending text when nothing parses — a silent
    empty list here would hide a prompt problem.
    """
    body = text
    if after_think:
        _, body = split_think(body)

    body = re.sub(r"```(?:json)?", "", body).strip().strip("`").strip()

    match = re.search(r"\[.*\]|\{.*\}", body, re.DOTALL)
    candidate = match.group(0) if match else body
    try:
        data = json.loads(candidate)
    except json.JSONDecodeError as exc:
        preview = text if len(text) < 400 else text[:400] + " ..."
        raise ValueError(
            f"no valid JSON found in the model output ({exc}).\n"
            f"This usually means the prompt did not pin the format tightly enough. "
            f"Try restating the exact keys you want.\n---\n{preview}"
        ) from exc

    return data if isinstance(data, list) else [data]


# --------------------------------------------------------------------------
# Spatial overlays
# --------------------------------------------------------------------------
def _denorm(value: float, extent: int) -> float:
    """Convert a 0-1000 normalised coordinate to pixels.

    Cosmos 3 emits spatial answers on a 0-1000 grid with the origin at the
    top-left, normalised **per axis and independently**. So x divides by the
    width and y by the height, and a square box in normalised space is not
    square in pixels unless the image is. Getting this wrong is the single most
    common grounding bug, and it has a distinctive look — Lesson 04 has you
    produce it deliberately.
    """
    return value / 1000.0 * extent


def draw_boxes(
    image_path: Path | str,
    boxes: str | Iterable[dict[str, Any]],
    *,
    width: int = 768,
    show: bool = True,
    save_to: Path | str | None = None,
):
    """Draw predicted bounding boxes on an image and return the annotated copy.

    ``boxes`` may be raw model text (parsed for you) or an already-parsed list.
    Accepts ``bbox_2d``, ``bbox`` or ``box`` as the coordinate key, because the
    model is not perfectly consistent about which it uses.
    """
    from PIL import Image as PILImage, ImageDraw, ImageFont

    image_path = Path(image_path)
    objects = parse_model_json(boxes) if isinstance(boxes, str) else list(boxes)

    img = PILImage.open(image_path).convert("RGB")
    W, H = img.size
    draw = ImageDraw.Draw(img)
    font = _load_font(max(14, W // 60))

    drawn = 0
    for i, obj in enumerate(objects):
        if not isinstance(obj, dict):
            continue
        box = obj.get("bbox_2d") or obj.get("bbox") or obj.get("box")
        if not box or len(box) != 4:
            continue
        colour = MARK_COLORS[i % len(MARK_COLORS)]
        x1, y1, x2, y2 = box
        x1, x2 = _denorm(x1, W), _denorm(x2, W)
        y1, y2 = _denorm(y1, H), _denorm(y2, H)
        draw.rectangle([x1, y1, x2, y2], outline=colour, width=max(2, W // 320))

        label = obj.get("label") or obj.get("name") or obj.get("category")
        if label:
            text = str(label)
            tb = draw.textbbox((0, 0), text, font=font)
            tw, th = tb[2] - tb[0], tb[3] - tb[1]
            ty = max(0, y1 - th - 6)
            draw.rectangle([x1, ty, x1 + tw + 8, ty + th + 6], fill=colour)
            draw.text((x1 + 4, ty + 3), text, fill=(255, 255, 255), font=font)
        drawn += 1

    if drawn == 0:
        print(
            "no boxes were drawn. The model returned JSON, but no object had a "
            "bbox_2d / bbox / box key with four numbers. Print the raw response."
        )

    if save_to:
        Path(save_to).parent.mkdir(parents=True, exist_ok=True)
        img.save(save_to)
    if show:
        preview = img.copy()
        preview.thumbnail((width, width))
        from IPython.display import display

        display(preview)
    return img


def draw_trajectory(
    image_path: Path | str,
    points: str | Iterable[dict[str, Any]],
    *,
    width: int = 800,
    show: bool = True,
    save_to: Path | str | None = None,
):
    """Draw a predicted 2-D end-effector trajectory over an image.

    Waypoints come back as ``{"point_2d": [x, y], ...}`` on the same 0-1000
    grid as bounding boxes. Points are numbered so you can see the ordering,
    which is often where a wrong-looking path turns out to be a right path
    traversed backwards.
    """
    from PIL import Image as PILImage, ImageDraw

    image_path = Path(image_path)
    objects = parse_model_json(points) if isinstance(points, str) else list(points)

    img = PILImage.open(image_path).convert("RGB")
    W, H = img.size
    draw = ImageDraw.Draw(img)
    font = _load_font(max(13, W // 70))

    pts = [
        (_denorm(o["point_2d"][0], W), _denorm(o["point_2d"][1], H))
        for o in objects
        if isinstance(o, dict) and isinstance(o.get("point_2d"), (list, tuple))
    ]
    if not pts:
        print("no waypoints found — expected objects with a 'point_2d' key.")
        return img

    if len(pts) > 1:
        draw.line(pts, fill=(60, 220, 60), width=max(3, W // 220), joint="curve")

    radius = max(6, W // 110)
    for i, (x, y) in enumerate(pts):
        # Colour ramps from green (start) to red (end) so direction is legible
        # without reading the numbers.
        t = i / max(len(pts) - 1, 1)
        colour = (int(40 + 200 * t), int(200 - 150 * t), 60)
        draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                     fill=colour, outline=(255, 255, 255), width=2)
        draw.text((x + radius + 3, y - radius), str(i), fill=(255, 235, 60), font=font)

    if save_to:
        Path(save_to).parent.mkdir(parents=True, exist_ok=True)
        img.save(save_to)
    if show:
        preview = img.copy()
        preview.thumbnail((width, width))
        from IPython.display import display

        display(preview)
    return img


def mark_subjects(
    image_path: Path | str,
    marks: Sequence[dict[str, Any]],
    out_path: Path | str,
    *,
    badge: int | None = None,
    normalized: bool = False,
):
    """Overlay numbered Set-of-Mark annotations and save the result.

    Set-of-Mark prompting means: draw numbered regions on the image, then ask
    the model to describe "each marked subject". The ``subject_id`` in its reply
    refers back to your numbers, so every caption is bound to a specific region.

    ``normalized=True`` interprets boxes on the 0-1000 grid; otherwise they are
    pixel coordinates. The source course used raw pixels tuned to one 1280x720
    asset, which silently mislocates every mark on any other image — hence the
    option and the assertion below.
    """
    from PIL import Image as PILImage, ImageDraw

    img = PILImage.open(image_path).convert("RGBA")
    W, H = img.size
    badge = badge or max(28, W // 32)
    overlay = PILImage.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    font = _load_font(int(badge * 0.6))

    for mark in marks:
        mid = mark["id"]
        colour = MARK_COLORS[(mid - 1) % len(MARK_COLORS)]
        x1, y1, x2, y2 = mark["bbox"]
        if normalized:
            x1, x2 = _denorm(x1, W), _denorm(x2, W)
            y1, y2 = _denorm(y1, H), _denorm(y2, H)
        else:
            if not (0 <= x2 <= W and 0 <= y2 <= H):
                raise ValueError(
                    f"mark {mid} box {mark['bbox']} falls outside the {W}x{H} image. "
                    f"These are pixel coordinates; pass normalized=True for the 0-1000 grid."
                )
        draw.rectangle([x1, y1, x2, y2], fill=colour + (55,), outline=colour + (255,), width=4)
        draw.ellipse([x1, y1, x1 + badge, y1 + badge], fill=colour + (255,),
                     outline=(255, 255, 255, 255), width=3)
        text = str(mid)
        tb = draw.textbbox((0, 0), text, font=font)
        draw.text(
            (x1 + (badge - (tb[2] - tb[0])) / 2 - tb[0], y1 + (badge - (tb[3] - tb[1])) / 2 - tb[1]),
            text, fill=(255, 255, 255, 255), font=font,
        )

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    PILImage.alpha_composite(img, overlay).convert("RGB").save(out_path)
    return out_path


def _load_font(size: int):
    from PIL import ImageFont

    for name in ("DejaVuSans-Bold.ttf", "DejaVuSans.ttf", "LiberationSans-Bold.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except Exception:
            continue
    return ImageFont.load_default()


# --------------------------------------------------------------------------
# Pose and trajectory plots
# --------------------------------------------------------------------------
# A camera frustum drawn as an apex plus the four corners of the image plane,
# with the camera looking down +Z.
_FRUSTUM = [(0, 0, 0), (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)]
_FRUSTUM_EDGES = [(0, 1), (0, 2), (0, 3), (0, 4), (1, 2), (2, 3), (3, 4), (4, 1)]


def plot_camera_trajectory(
    poses_abs,
    *,
    n_frustums: int = 18,
    scale_frac: float = 0.03,
    aspect: float = 16 / 9,
    fov_deg: float = 60.0,
    cmap: str = "viridis",
    title: str | None = None,
    figsize: tuple[float, float] = (13, 5.5),
):
    """Plot a camera path in 3-D with frustums, plus a top-down bird's-eye view.

    ``poses_abs`` is ``[T, 4, 4]`` absolute camera-to-world matrices. Column 3
    of the rotation block is the camera centre; column 2 is the heading (+Z).

    Two views because they answer different questions. The 3-D plot shows
    whether the path is plausible in space; the bird's-eye view shows the
    steering, which is what you actually want when comparing a left turn against
    a right turn.
    """
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.collections import LineCollection
    from mpl_toolkits.mplot3d.art3d import Line3DCollection

    poses_abs = np.asarray(poses_abs)
    if poses_abs.ndim != 3 or poses_abs.shape[1:] != (4, 4):
        raise ValueError(f"expected [T, 4, 4] poses, got {poses_abs.shape}")

    positions = poses_abs[:, :3, 3]
    heading = poses_abs[:, :3, 2]
    T = len(positions)
    colours = plt.get_cmap(cmap)(np.linspace(0, 1, T))
    scale = max(float(np.ptp(positions, axis=0).max()) * scale_frac, 1e-3)
    step = max(1, T // max(n_frustums, 1))

    # World (X, Y, Z) -> plot (X, Z, Y-up), so "forward" runs into the page.
    remap = [0, 2, 1]

    fig = plt.figure(figsize=figsize)
    ax = fig.add_subplot(1, 2, 1, projection="3d")
    path = positions[:, remap]
    ax.plot(*path.T, color="0.6", lw=1.0, alpha=0.7)

    lines, line_colours, all_points = [], [], [path]
    frustum = np.array(_FRUSTUM, dtype=float)
    half_fov = np.tan(np.radians(fov_deg) / 2)
    for i in range(0, T, step):
        corners = (
            (frustum * [aspect, 1, 1] * scale * half_fov) @ poses_abs[i, :3, :3].T
            + poses_abs[i, :3, 3]
        )[:, remap]
        all_points.append(corners)
        lines += [[corners[a], corners[b]] for a, b in _FRUSTUM_EDGES]
        line_colours += [colours[i]] * len(_FRUSTUM_EDGES)
    ax.add_collection3d(Line3DCollection(lines, colors=line_colours, linewidths=1.1))

    ax.scatter(*path[0], color="lime", s=70, edgecolor="k", label="first frame", zorder=5)
    ax.scatter(*path[-1], color="red", s=70, edgecolor="k", label="last frame", zorder=5)
    extents = np.clip(np.ptp(np.concatenate(all_points), axis=0), 1e-9, None)
    ax.set_box_aspect(tuple(extents))
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Z forward (m)")
    ax.set_zlabel("Y up (m)")
    ax.set_zticks([])
    ax.set_title(title or f"Camera trajectory ({T} frames)")
    ax.legend(loc="upper left", fontsize=8)
    ax.view_init(elev=22, azim=-70)

    ax2 = fig.add_subplot(1, 2, 2)
    if T > 1:
        segments = np.stack([positions[:-1][:, [0, 2]], positions[1:][:, [0, 2]]], axis=1)
        lc = LineCollection(segments, cmap=cmap, norm=plt.Normalize(0, T - 1), linewidth=2.5)
        lc.set_array(np.arange(T - 1))
        ax2.add_collection(lc)
        fig.colorbar(lc, ax=ax2, label="frame index")
    ax2.quiver(
        positions[::step, 0], positions[::step, 2],
        heading[::step, 0], heading[::step, 2],
        color=colours[::step], angles="xy", width=0.005, scale=22, zorder=3,
    )
    ax2.scatter(*positions[0, [0, 2]], color="lime", s=70, edgecolor="k", zorder=5)
    ax2.scatter(*positions[-1, [0, 2]], color="red", s=70, edgecolor="k", zorder=5)
    ax2.set_xlabel("X (m)")
    ax2.set_ylabel("Z forward (m)")
    ax2.set_title("Top-down (bird's-eye view)")
    ax2.set_aspect("equal", adjustable="datalim")
    ax2.autoscale_view()
    ax2.grid(alpha=0.25)

    plt.tight_layout(w_pad=4)
    plt.show()
    return fig


def plot_end_effector_path(
    action,
    *,
    translation_slice: slice = slice(0, 3),
    gripper_index: int | None = 9,
    cmap: str = "viridis",
    title: str | None = None,
    figsize: tuple[float, float] = (12.5, 5),
):
    """Integrate translation deltas into a 3-D gripper path, next to the gripper signal.

    A robot policy action step is typically ``[dx, dy, dz, r0..r5, gripper]`` —
    a translation delta, a 6-D rotation, and an open/close value. The *path* is
    the cumulative sum of the deltas, which is why a small systematic error in
    the deltas shows up as visible drift by the end.

    The gripper trace is plotted alongside because the interesting question is
    almost always *where along the path does it close*, and that is far easier
    to see with the two panels side by side.
    """
    import matplotlib.pyplot as plt
    import numpy as np
    from mpl_toolkits.mplot3d.art3d import Line3DCollection

    action = np.asarray(action, dtype=float)
    if action.ndim != 2:
        raise ValueError(f"expected [steps, dims], got {action.shape}")

    positions = np.cumsum(action[:, translation_slice], axis=0)
    T = len(positions)
    colours = plt.get_cmap(cmap)(np.linspace(0, 1, T))

    gripper = None
    if gripper_index is not None and action.shape[1] > gripper_index:
        gripper = action[:, gripper_index]

    fig = plt.figure(figsize=figsize)
    ax = fig.add_subplot(1, 2, 1, projection="3d")
    if T > 1:
        segments = np.stack([positions[:-1], positions[1:]], axis=1)
        ax.add_collection3d(Line3DCollection(segments, colors=colours[:-1], linewidths=2.5))
    ax.scatter(*positions[0], color="lime", s=80, edgecolor="k", label="start", zorder=5)
    ax.scatter(*positions[-1], color="red", s=80, edgecolor="k", label="end", zorder=5)
    ax.set_box_aspect(tuple(np.clip(np.ptp(positions, axis=0), 1e-6, None)))
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_zlabel("Z (m)")
    ax.set_title(title or f"Predicted end-effector path ({T} steps)")
    ax.legend(loc="upper left", fontsize=8)
    ax.view_init(elev=22, azim=-60)

    ax2 = fig.add_subplot(1, 2, 2)
    if gripper is not None:
        ax2.plot(gripper, color="tab:blue", lw=2)
        ax2.fill_between(range(T), gripper, alpha=0.15, color="tab:blue")
        ax2.set_xlabel("step")
        ax2.set_ylabel("gripper (open -> close)")
        ax2.set_title("Predicted gripper state")
        ax2.grid(alpha=0.25)
    else:
        ax2.text(0.5, 0.5, f"no gripper channel\n(action has {action.shape[1]} dims)",
                 ha="center", va="center", transform=ax2.transAxes)
        ax2.axis("off")

    plt.tight_layout(w_pad=3)
    plt.show()
    return fig
