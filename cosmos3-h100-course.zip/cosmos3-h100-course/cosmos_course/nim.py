"""Lifecycle management for the Cosmos 3 Reasoner NIM on **one** GPU.

The NIM (`nvcr.io/nim/nvidia/cosmos3-reasoner:1.7`) is a Docker container that
serves the Cosmos 3 reasoner tower behind an OpenAI-compatible HTTP API. Start
it, ask it questions, stop it. That is the whole surface area — and on a machine
with eight GPUs it genuinely is that simple.

You have one. So this module is really about VRAM arithmetic.

Sharing one H100 between the NIM and the generator
--------------------------------------------------
The single most surprising thing about running a NIM next to anything else is
that **the NIM's resting VRAM footprint is not its weight footprint**. Like
almost every modern LLM server, it allocates a large block of the *currently
free* VRAM at startup and keeps it as a KV cache pool for the whole life of the
process. The nano reasoner's FP8 weights are roughly 8 GB (see
``COSMOS3_FACTS.md`` §4), but on an idle 80 GB H100 the container will happily
settle at 60–75 GB resident. Nothing is leaking; that is by design, and it is
how the server guarantees it can admit a long request later.

The consequence is blunt: **start the NIM first and the generator will OOM, even
though the two models together fit on paper.** ``cosmos_course.config.vram_budget()``
does the arithmetic; ``print_vram_plan()`` below prints it.

Three strategies, in the order the course recommends them:

**(a) Take turns — the default, and what every lesson does unless it says
otherwise.** ``stop_nim(cfg)`` before you generate, ``start_nim(cfg)`` after.
The cost is a cold start each time (weights are already on disk after the first
pull, so this is tens of seconds, not the first-run download). The benefit is
that neither side is compromised: the NIM gets the whole card and can hold a
long video's worth of KV cache, and the generator gets the whole card and can
render at 768p. When you are unsure, take turns.

**(b) Cap the NIM so both coexist.** Set ``NimConfig.gpu_memory_fraction`` to a
value that leaves room for the generator, and both processes stay resident. This
is the right call when a lesson alternates rapidly between reasoning and
generation — Lesson 09's plan-then-render loop, for instance — because you stop
paying model-load latency on every switch.

**(c) Do not run the Generator NIM at all.** Worth stating because people find
it in the catalogue and try: `nvcr.io/nim/nvidia/cosmos3-generator` has a
per-device floor of **≥79 GiB** for nano at any precision. It will take the
entire H100 and there is no fraction you can set to change that. This course
uses the Cosmos Framework for generation instead.

**What capping costs you.** Exactly one thing: KV cache. Reasoning over a long
video is a long-context problem — every sampled frame becomes hundreds of image
tokens — so a capped NIM will refuse or truncate requests that an uncapped one
would have served. If you cap to coexist with Cosmos3-Nano generation (32 GB)
you are leaving the NIM roughly 45 GB, of which ~8 GB is weights; that is a
comfortable amount of cache. If you were trying to coexist with something that
needed 60 GB, you would be starving it. Measure, do not guess:
``nim_status(cfg)["vram_gb"]`` reports what the container is *actually* holding.

The unverified bit, stated plainly
----------------------------------
See ``NIM_MEMORY_ENV`` below. The knob that implements strategy (b) is an
environment variable whose exact name this course could not verify against a
running NIM 1.7 container at authoring time. Everything else in this module is
mechanical Docker plumbing that either works or throws. That one name is a
best-effort guess with a documented way to check it —
``discover_memory_env(cfg)`` runs ``docker run --rm <image> --help`` and greps
the output for you. Run it once on your machine, then trust
``nim_status()``'s observed VRAM number over any flag, including this one.

Prerequisites
-------------
* Docker with the NVIDIA Container Toolkit (``probe_environment()`` checks this)
* ``NGC_API_KEY`` exported, and ``docker login nvcr.io`` done once
  (``ensure_ngc_login()`` checks and tells you the command)
* ~20 GB of disk for the FP8 nano profile, ~40 GB for FP8 super
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from .config import PINNED, vram_budget

__all__ = [
    "NIM_IMAGE",
    "NIM_HEALTH_PATH",
    "NIM_MEMORY_ENV",
    "NIM_MEMORY_ENV_CANDIDATES",
    "NimConfig",
    "nim_status",
    "print_status",
    "start_nim",
    "stop_nim",
    "wait_for_nim",
    "nim_logs",
    "ensure_ngc_login",
    "discover_memory_env",
    "suggest_memory_fraction",
    "print_vram_plan",
]

# --------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------
# Repository without a tag. The tag lives in NimConfig.tag, defaulted from
# config.PINNED so that "which NIM version is this course written against?" has
# exactly one answer in the codebase.
NIM_IMAGE = "nvcr.io/nim/nvidia/cosmos3-reasoner"

# NIM containers expose two health endpoints: /v1/health/live (the process is
# up) and /v1/health/ready (the model is loaded and it will answer requests).
# Only the second one is useful to us — a NIM is "live" within a couple of
# seconds and "ready" only after it has loaded 8–40 GB of weights.
NIM_HEALTH_PATH = "/v1/health/ready"

# ~~~ UNVERIFIED — READ THIS BEFORE TRUSTING IT ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# The environment variable that caps how much VRAM the NIM will claim.
#
# This course was written without a live NIM 1.7 container to interrogate, and
# NVIDIA's NIM containers have used several different names for this knob across
# families and releases. The name below is the most plausible one for a
# vLLM-backed vision-language NIM, but it is a GUESS.
#
# Confirm it yourself, once, in about 60 seconds:
#
#     docker run --rm nvcr.io/nim/nvidia/cosmos3-reasoner:1.7 --help
#
# or, programmatically, ``discover_memory_env(cfg)`` in this module, which runs
# that command and greps for every NIM_* variable with MEM/GPU/KV/UTIL in its
# name. Cross-check against https://docs.nvidia.com/nim/cosmos/latest/ .
#
# If the real name differs, you do NOT need to edit this file — set
# ``COSMOS_COURSE_NIM_MEMORY_ENV`` in your shell, or pass the correct name
# through ``NimConfig.extra_env``.
#
# Why this is tolerable rather than sloppy: the flag is an *input* we are unsure
# of, but the *output* is directly observable. ``nim_status(cfg)["vram_gb"]``
# reads what the container is really holding out of nvidia-smi. Set the flag,
# start the NIM, read the number. If it did not move, the name is wrong. That is
# a better epistemic position than trusting a documented flag you never checked.
NIM_MEMORY_ENV: str = os.environ.get(
    "COSMOS_COURSE_NIM_MEMORY_ENV", "NIM_MAX_GPU_MEMORY_UTILIZATION"
)

# Names seen in the wild across NIM families. discover_memory_env() looks for
# these specifically and reports anything else NIM_*MEM*-shaped that it finds.
NIM_MEMORY_ENV_CANDIDATES: tuple[str, ...] = (
    "NIM_MAX_GPU_MEMORY_UTILIZATION",   # vLLM --gpu-memory-utilization, surfaced as an env var
    "NIM_GPU_MEMORY_UTILIZATION",
    "NIM_KVCACHE_PERCENT",              # used by several NIM LLM containers
    "NIM_RELAX_MEM_CONSTRAINTS",        # loosens the *floor* check, not the ceiling
    "VLLM_GPU_MEMORY_UTILIZATION",      # passthrough, if the NIM forwards it
)

# Matches the *scale* the value should be on. Some NIM variables want a fraction
# in (0, 1]; NIM_KVCACHE_PERCENT wants 0–100. _memory_env_value() converts.
_PERCENT_STYLE = re.compile(r"PERCENT|PCT", re.IGNORECASE)


# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------
@dataclass
class NimConfig:
    """Everything needed to start, find and stop one Reasoner NIM.

    Defaults are tuned for a single H100 80 GB running the nano reasoner at FP8,
    which is the configuration Lessons 02–05 assume.
    """

    image: str = NIM_IMAGE
    tag: str = PINNED["reasoner_nim"]

    # "nano" (8B active, FP8, ~20 GB on disk) or "super" (32B active, FP8,
    # ~40 GB). Both fit one H100 *for reasoning* — it is Super *generation*
    # that does not fit, which is a distinction people routinely get backwards.
    model_size: Literal["nano", "super"] = "nano"

    # Host port. The container always listens on 8000 internally; this is the
    # outside of the -p mapping, so changing it does not need any other change.
    port: int = 8000
    container_name: str = "cosmos3-reasoner"

    # Weight cache. Bind-mounting this is the difference between a 20 GB
    # download every time you restart and a 20 GB download once.
    cache_dir: Path = field(default_factory=lambda: Path.home() / ".cache" / "nim")

    # None  -> let the NIM take whatever it wants (correct for "take turns")
    # 0..1  -> cap it, so a generator process can coexist (see module docstring)
    gpu_memory_fraction: float | None = None

    # /dev/shm inside the container. NIM inference workers communicate through
    # shared memory; Docker's 64 MB default is far too small and produces a
    # "Bus error" or a torch shared-memory error that looks like a model bug.
    shm_size: str = "32gb"

    extra_env: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Accept a full reference in `image` too ("...:1.7"), because that is
        # what people copy out of the NGC catalogue page. Splitting on the last
        # colon only when it appears after the last slash avoids mangling a
        # registry host with a port in it (localhost:5000/foo).
        head, sep, maybe_tag = self.image.rpartition(":")
        if sep and "/" not in maybe_tag:
            self.image = head
            self.tag = maybe_tag
        self.cache_dir = Path(self.cache_dir).expanduser()
        if self.gpu_memory_fraction is not None:
            if not 0.0 < self.gpu_memory_fraction <= 1.0:
                raise ValueError(
                    f"gpu_memory_fraction must be a fraction in (0, 1], got "
                    f"{self.gpu_memory_fraction!r}. If you meant a percentage, "
                    f"divide by 100."
                )

    @property
    def reference(self) -> str:
        """The full image reference passed to ``docker run``."""
        return f"{self.image}:{self.tag}"

    @property
    def base_url(self) -> str:
        """Where the OpenAI-compatible API lives. Feed this to ``Reasoner``."""
        return f"http://localhost:{self.port}"

    def describe(self) -> str:
        lines = [
            f"image      : {self.reference}",
            f"model size : {self.model_size}",
            f"container  : {self.container_name}",
            f"base URL   : {self.base_url}",
            f"cache      : {self.cache_dir}",
            f"shm        : {self.shm_size}",
        ]
        if self.gpu_memory_fraction is None:
            lines.append("VRAM cap   : none — the NIM will claim most of the free card")
        else:
            lines.append(
                f"VRAM cap   : {self.gpu_memory_fraction:.2f} via {NIM_MEMORY_ENV} "
                f"(verify with discover_memory_env())"
            )
        if self.extra_env:
            lines.append(f"extra env  : {', '.join(sorted(self.extra_env))}")
        return "\n".join(lines)


# --------------------------------------------------------------------------
# Small process / HTTP helpers
# --------------------------------------------------------------------------
def _run(cmd: list[str], *, timeout: int = 60) -> subprocess.CompletedProcess[str] | None:
    """Run a command and return the CompletedProcess, or None if it could not run.

    Returns the process even on a non-zero exit, because ``docker``'s stderr is
    usually the most informative thing available when something fails. Only a
    missing binary, a timeout or an OS-level error produces None.
    """
    if not shutil.which(cmd[0]):
        return None
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except (subprocess.SubprocessError, OSError):
        return None


def _docker(args: list[str], *, timeout: int = 60) -> subprocess.CompletedProcess[str] | None:
    return _run(["docker", *args], timeout=timeout)


def _http_get(url: str, timeout: float = 3.0) -> tuple[int, str]:
    """GET a URL. Returns ``(status, body)``; status 0 means "did not connect".

    Uses ``urllib`` rather than ``requests`` deliberately: this module has to be
    importable and useful in a bare environment, and a health check is not worth
    a dependency. ``requests`` would also raise on a 4xx/5xx where here we want
    to see the code.
    """
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:            # server answered, unhappily
        try:
            body = exc.read().decode("utf-8", "replace")
        except Exception:
            body = ""
        return exc.code, body
    except Exception:                                 # refused, DNS, timeout, reset
        return 0, ""


def _gpu_used_mib() -> float | None:
    """Total VRAM currently in use on GPU 0, in MiB. None if unreadable."""
    proc = _run(
        ["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"],
        timeout=20,
    )
    if proc is None or proc.returncode != 0:
        return None
    first = proc.stdout.strip().splitlines()[:1]
    try:
        return float(first[0])
    except (IndexError, ValueError):
        return None                                   # "[Not Supported]" etc.


def _gpu_total_mib() -> float | None:
    proc = _run(
        ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
        timeout=20,
    )
    if proc is None or proc.returncode != 0:
        return None
    try:
        return float(proc.stdout.strip().splitlines()[0])
    except (IndexError, ValueError):
        return None


def _compute_apps() -> dict[int, float] | None:
    """Map host PID -> VRAM MiB for every process with a CUDA context.

    ``nvidia-smi --query-compute-apps`` reports **host** PIDs even for processes
    inside a container, which is exactly what we need to attribute memory. It
    returns nothing at all in a few environments (some vGPU and MIG setups, and
    inside an unprivileged container), which is why every caller treats None and
    {} as "unknown" rather than "zero".
    """
    proc = _run(
        ["nvidia-smi", "--query-compute-apps=pid,used_gpu_memory",
         "--format=csv,noheader,nounits"],
        timeout=20,
    )
    if proc is None or proc.returncode != 0:
        return None
    out: dict[int, float] = {}
    for line in proc.stdout.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 2:
            continue
        try:
            out[int(parts[0])] = float(parts[1])
        except ValueError:
            continue                                  # "[N/A]" on some drivers
    return out


def _container_pids(name: str) -> set[int]:
    """Host PIDs of every process inside the container. Empty if not running.

    ``docker top`` shells out to the host's ``ps``, so these are host PIDs and
    line up with what nvidia-smi reports. ``docker inspect .State.Pid`` gives
    only the entrypoint, which for a NIM is usually a shell whose python child
    owns the CUDA context — so inspect alone would attribute 0 MiB.
    """
    proc = _docker(["top", name, "-eo", "pid"], timeout=30)
    if proc is None or proc.returncode != 0:
        return set()
    pids: set[int] = set()
    for line in proc.stdout.splitlines():
        line = line.strip()
        if not line or not line.isdigit():
            continue                                  # skips the "PID" header
        pids.add(int(line))
    return pids


def _memory_env_value(fraction: float, var_name: str) -> str:
    """Render ``fraction`` for whichever variable name we ended up using.

    NIM_KVCACHE_PERCENT-style names want 0–100; utilisation-style names want a
    fraction. Guessing wrong by 100x is the kind of thing that silently does
    nothing, so we branch on the name.
    """
    if _PERCENT_STYLE.search(var_name):
        return f"{fraction * 100:.0f}"
    return f"{fraction:.3f}"


# --------------------------------------------------------------------------
# NGC login
# --------------------------------------------------------------------------
def ensure_ngc_login(*, quiet: bool = False) -> bool:
    """Check whether Docker holds credentials for ``nvcr.io``.

    Returns True if it looks logged in. Never reads, prints, logs or otherwise
    touches the value of ``NGC_API_KEY`` — the only thing this function knows
    about your key is whether the variable is set.

    Detection is best-effort by necessity. ``~/.docker/config.json`` stores an
    entry per registry, but when a credential helper is configured (``credsStore``
    / ``credHelpers``, which is the default on Docker Desktop and on many managed
    Linux images) the secret lives in the OS keychain and the JSON may contain
    an empty ``auths`` entry or none at all. So: a positive result is reliable,
    a negative result means "probably not, try logging in again — it is
    idempotent and costs you nothing".
    """
    cfg_path = Path.home() / ".docker" / "config.json"
    logged_in = False
    helper_in_use = False

    if cfg_path.exists():
        try:
            data = json.loads(cfg_path.read_text())
        except (json.JSONDecodeError, OSError):
            data = {}
        auths = data.get("auths", {}) or {}
        logged_in = any("nvcr.io" in key for key in auths)
        helpers = data.get("credHelpers", {}) or {}
        helper_in_use = bool(data.get("credsStore")) or any(
            "nvcr.io" in key for key in helpers
        )

    if logged_in:
        if not quiet:
            print("nvcr.io: docker credentials found")
        return True

    if not quiet:
        key_present = bool(os.environ.get("NGC_API_KEY"))
        print("nvcr.io: no docker credentials found for nvcr.io.")
        if helper_in_use:
            print(
                "  (A credential helper is configured, so they may be in your keychain\n"
                "   and simply not visible in ~/.docker/config.json. If the image pull\n"
                "   works, you are fine.)"
            )
        print("\n  Log in with:\n")
        # The username is the LITERAL STRING $oauthtoken -- it is not a variable
        # and it is not your key. Single quotes stop the shell expanding it to
        # the empty string, which is the single most common way this command
        # fails for people.
        print("    echo \"$NGC_API_KEY\" | docker login nvcr.io -u '$oauthtoken' --password-stdin")
        print()
        if key_present:
            # Confirming the variable exists is useful; its value is not.
            print("  NGC_API_KEY is set in this environment (value not shown).")
        else:
            print(
                "  NGC_API_KEY is NOT set. Get a key from https://ngc.nvidia.com/setup/api-key\n"
                "  (the free NVIDIA Developer Program tier is enough) and export it:\n"
                "    export NGC_API_KEY=...        # then re-run this check"
            )
    return False


# --------------------------------------------------------------------------
# Status
# --------------------------------------------------------------------------
def nim_status(cfg: NimConfig | None = None) -> dict[str, Any]:
    """Report, from four independent sources, what the NIM is actually doing.

    Returns a dict with (at least) these keys:

    ``docker``            docker binary present
    ``container_exists``  a container with this name exists (running or not)
    ``running``           it is running
    ``state``             docker's own status string, e.g. "Up 4 minutes"
    ``ready``             GET /v1/health/ready returned 200
    ``models``            list of model ids from /v1/models
    ``model_id``          the first one, or None
    ``vram_gb``           VRAM held by this container's processes, or None
    ``gpu_used_gb``       VRAM used on the whole GPU
    ``gpu_total_gb``      VRAM the GPU has

    The four sources disagree in informative ways, which is why they are all
    here rather than collapsed into a boolean. "Container running but not ready"
    means it is loading weights. "Ready but vram_gb is None" means nvidia-smi
    cannot attribute the memory on this machine, not that the memory is free.
    "Container gone but gpu_used_gb still high" means something else — very
    likely a stray generator process — owns the card.
    """
    cfg = cfg or NimConfig()
    status: dict[str, Any] = {
        "container_name": cfg.container_name,
        "base_url": cfg.base_url,
        "docker": shutil.which("docker") is not None,
        "container_exists": False,
        "running": False,
        "state": None,
        "image": None,
        "ready": False,
        "health_status": 0,
        "models": [],
        "model_id": None,
        "vram_gb": None,
        "gpu_used_gb": None,
        "gpu_total_gb": None,
        "notes": [],
    }

    # -- 1. Docker's view --------------------------------------------------
    # `-a` so a crashed/exited container is still visible; an exited container
    # with our name will block `docker run --name` with a confusing
    # "name is already in use" error, and start_nim() needs to know.
    if status["docker"]:
        proc = _docker([
            "ps", "-a",
            "--filter", f"name=^/{cfg.container_name}$",
            "--format", "{{.State}}|{{.Status}}|{{.Image}}",
        ], timeout=30)
        if proc is not None and proc.returncode == 0 and proc.stdout.strip():
            state, _, rest = proc.stdout.strip().splitlines()[0].partition("|")
            human, _, image = rest.partition("|")
            status["container_exists"] = True
            status["running"] = state.strip() == "running"
            status["state"] = human.strip()
            status["image"] = image.strip()
        elif proc is not None and proc.returncode != 0:
            status["notes"].append(
                "the docker daemon did not answer; is it running, and are you in "
                "the `docker` group?"
            )
    else:
        status["notes"].append("docker is not installed or not on PATH")

    # -- 2. HTTP readiness -------------------------------------------------
    # Checked regardless of what Docker said, because plenty of people start the
    # NIM some other way (docker compose, a systemd unit, another host) and this
    # function should still tell them the truth about the endpoint.
    code, _ = _http_get(cfg.base_url + NIM_HEALTH_PATH, timeout=3.0)
    status["health_status"] = code
    status["ready"] = code == 200

    # -- 3. Which model is actually being served ---------------------------
    # Worth asking rather than assuming: NIM_MODEL_SIZE is set at container
    # start, so a container you left running yesterday may not be serving what
    # today's cfg says. Reasoner also needs this id verbatim.
    if status["ready"]:
        code, body = _http_get(cfg.base_url + "/v1/models", timeout=5.0)
        if code == 200:
            try:
                data = json.loads(body).get("data", [])
                status["models"] = [m.get("id") for m in data if m.get("id")]
                status["model_id"] = status["models"][0] if status["models"] else None
            except (json.JSONDecodeError, AttributeError, TypeError):
                status["notes"].append("/v1/models returned something unparseable")
        expected = f"cosmos3-{cfg.model_size}-reasoner"
        if status["model_id"] and expected not in status["model_id"]:
            status["notes"].append(
                f"the running container serves {status['model_id']!r}, but this "
                f"config asks for {cfg.model_size!r}. It was started with a "
                f"different NIM_MODEL_SIZE — stop_nim() and start again if you "
                f"meant to switch."
            )

    # -- 4. Ground truth: what nvidia-smi says ------------------------------
    # This is the number that settles arguments about gpu_memory_fraction. It is
    # measured, not requested.
    total_mib = _gpu_total_mib()
    used_mib = _gpu_used_mib()
    if total_mib is not None:
        status["gpu_total_gb"] = round(total_mib / 1024, 2)
    if used_mib is not None:
        status["gpu_used_gb"] = round(used_mib / 1024, 2)

    if status["running"]:
        apps = _compute_apps()
        pids = _container_pids(cfg.container_name)
        if apps is None:
            status["notes"].append(
                "nvidia-smi did not report per-process memory on this machine, so "
                "the NIM's share cannot be attributed. Use gpu_used_gb with the "
                "NIM stopped vs running to get the difference."
            )
        elif pids:
            attributed = sum(mib for pid, mib in apps.items() if pid in pids)
            status["vram_gb"] = round(attributed / 1024, 2)
            if attributed == 0:
                status["notes"].append(
                    "the container is running but holds no CUDA memory yet — it is "
                    "still loading weights, or it failed to see the GPU. Check "
                    "nim_logs(cfg)."
                )
        else:
            status["notes"].append("could not list the container's processes (docker top failed)")

    return status


def print_status(cfg: NimConfig | None = None) -> dict[str, Any]:
    """``nim_status`` with a human-readable rendering. Returns the same dict."""
    st = nim_status(cfg)

    # Built as plain locals rather than nested f-string conditionals. Nesting
    # quotes inside an f-string expression is a syntax error before Python 3.12,
    # and the version that does compile is unreadable either way.
    state = st["state"] or "does not exist"
    if st["ready"]:
        health = "ready"
    elif st["health_status"]:
        health = f"not ready, HTTP {st['health_status']}"
    else:
        health = "not ready, connection refused"

    print(f"container : {st['container_name']}  ({state})")
    print(f"endpoint  : {st['base_url']}  ({health})")
    if st["model_id"]:
        print(f"serving   : {st['model_id']}")
    if st["gpu_total_gb"] is not None and st["gpu_used_gb"] is not None:
        if st["vram_gb"] is None:
            held = "NIM share not attributable on this machine"
        else:
            held = f"{st['vram_gb']:.1f} GB held by the NIM"
        print(f"VRAM      : {st['gpu_used_gb']:.1f} / {st['gpu_total_gb']:.1f} GB used - {held}")
    for note in st["notes"]:
        print(f"  note: {note}")
    return st


# --------------------------------------------------------------------------
# Waiting
# --------------------------------------------------------------------------
def wait_for_nim(
    base_url: str = "http://localhost:8000",
    timeout: float = 1800.0,
    *,
    poll: float = 5.0,
    quiet: bool = False,
    container_name: str | None = None,
) -> float:
    """Block until ``base_url`` answers /v1/health/ready with 200.

    Standalone on purpose: if you started the NIM with ``docker compose``, a
    systemd unit, or by hand in another terminal, this still works and
    ``start_nim`` is not involved.

    Returns the number of seconds waited. Raises ``RuntimeError`` on timeout
    with instructions rather than a bare "timed out".

    The default 1800 s looks absurd until the first run, when the container
    downloads 20 GB of FP8 weights before it will answer anything.
    """
    base_url = base_url.rstrip("/")
    start = time.monotonic()
    tick = 0
    last_code = 0

    while True:
        last_code, _ = _http_get(base_url + NIM_HEALTH_PATH, timeout=3.0)
        elapsed = time.monotonic() - start
        if last_code == 200:
            if not quiet:
                # Clear the progress line before printing the result, or the
                # tail of the last dots animation stays on screen.
                sys.stdout.write("\r" + " " * 78 + "\r")
                print(f"NIM ready after {elapsed:.0f}s")
                sys.stdout.flush()
            return elapsed

        if elapsed > timeout:
            break

        if not quiet:
            tick += 1
            dots = "." * (1 + tick % 3)
            sys.stdout.write(
                f"\r  waiting for {base_url}{NIM_HEALTH_PATH} {dots:<3}  "
                f"{elapsed:5.0f}s elapsed"
            )
            sys.stdout.flush()
        time.sleep(poll)

    if not quiet:
        sys.stdout.write("\r" + " " * 78 + "\r")
        sys.stdout.flush()

    name = container_name or "cosmos3-reasoner"
    hint_code = (
        "the endpoint refused the connection the whole time (nothing is listening "
        "on that port)"
        if last_code == 0
        else f"the endpoint answered HTTP {last_code} rather than 200"
    )
    raise RuntimeError(
        f"The NIM did not become ready within {timeout:.0f}s — {hint_code}.\n"
        f"\n"
        f"Do this, in order:\n"
        f"  1. Read the logs. This is not optional; the container almost always\n"
        f"     says exactly what is wrong:\n"
        f"         docker logs --tail 100 {name}\n"
        f"     (or, from Python: print(nim_logs(cfg, tail=100)))\n"
        f"  2. Is it still alive?   docker ps -a --filter name={name}\n"
        f"     If STATUS says 'Exited', the logs above are your answer.\n"
        f"  3. Common causes, in rough order of frequency:\n"
        f"     - First run, and it is still downloading weights (20 GB nano /\n"
        f"       40 GB super). Raise `timeout` and wait. `docker logs -f` shows\n"
        f"       download progress.\n"
        f"     - 401/403 on the pull -> you are not logged in to nvcr.io.\n"
        f"       Run ensure_ngc_login().\n"
        f"     - 'could not select device driver' -> the NVIDIA Container Toolkit\n"
        f"       is missing. `docker run --rm --gpus all nvidia/cuda:12.8.0-base-ubuntu22.04 nvidia-smi`\n"
        f"     - CUDA OOM at load -> something else already owns the GPU. Check\n"
        f"       `nvidia-smi`; a leftover generator process is the usual culprit.\n"
        f"     - Port {base_url.rsplit(':', 1)[-1]} already bound by another container.\n"
    )


# --------------------------------------------------------------------------
# Start / stop
# --------------------------------------------------------------------------
def start_nim(
    cfg: NimConfig | None = None,
    wait: bool = True,
    timeout: float = 1800.0,
    *,
    quiet: bool = False,
) -> dict[str, Any]:
    """Start the Reasoner NIM. Idempotent.

    If a healthy NIM is already answering on ``cfg.base_url`` this returns
    immediately and says so — re-running the start cell in a notebook is a
    normal thing to do and should not cost you a container restart.

    Returns a status dict (the same shape as ``nim_status``) plus
    ``already_running`` and ``startup_seconds``.
    """
    cfg = cfg or NimConfig()

    if shutil.which("docker") is None:
        raise RuntimeError(
            "docker is not installed or not on PATH, so the NIM cannot start.\n"
            "  Either install Docker + the NVIDIA Container Toolkit, or use the\n"
            "  vLLM fallback documented in Lesson 02 — the framework can serve the\n"
            "  reasoner tower directly with model_mode='reasoner' and no container."
        )

    # -- already up? -------------------------------------------------------
    st = nim_status(cfg)
    if st["ready"]:
        if not quiet:
            print(
                f"NIM is already up and ready at {cfg.base_url}"
                + (f" serving {st['model_id']}" if st["model_id"] else "")
                + "\n  Nothing to do. (start_nim is idempotent — re-running this cell is free.)"
            )
        st["already_running"] = True
        st["startup_seconds"] = 0.0
        return st

    # An existing-but-not-ready container is either mid-load or dead. Either
    # way `docker run --name` will fail with "name is already in use", so deal
    # with it explicitly rather than letting the learner meet that error.
    if st["container_exists"]:
        if st["running"]:
            if not quiet:
                print(
                    f"A container named {cfg.container_name!r} is already running but not "
                    f"ready yet ({st['state']}). Waiting for it rather than starting a "
                    f"second one."
                )
            waited = 0.0
            if wait:
                waited = wait_for_nim(
                    cfg.base_url, timeout, quiet=quiet, container_name=cfg.container_name
                )
            out = nim_status(cfg)
            out["already_running"] = True
            out["startup_seconds"] = waited
            return out
        if not quiet:
            print(
                f"Removing a stopped container named {cfg.container_name!r} "
                f"({st['state']}) so the name is free."
            )
        _docker(["rm", "-f", cfg.container_name], timeout=60)

    # -- credentials -------------------------------------------------------
    ensure_ngc_login(quiet=quiet)
    if not os.environ.get("NGC_API_KEY"):
        raise RuntimeError(
            "NGC_API_KEY is not set in this environment.\n"
            "  The Cosmos 3 Reasoner NIM requires an NGC subscription; the free\n"
            "  NVIDIA Developer Program tier is enough.\n"
            "    1. Get a key: https://ngc.nvidia.com/setup/api-key\n"
            "    2. export NGC_API_KEY=...        (put it in ~/.bashrc, not in a notebook)\n"
            "    3. echo \"$NGC_API_KEY\" | docker login nvcr.io -u '$oauthtoken' --password-stdin\n"
            "  If you are running this from Jupyter, restart the kernel after step 2 —\n"
            "  the kernel inherited its environment when it started."
        )

    cfg.cache_dir.mkdir(parents=True, exist_ok=True)

    # -- build the command -------------------------------------------------
    argv: list[str] = [
        "docker", "run", "-d",
        "--name", cfg.container_name,
        "--gpus", "all",
        "--shm-size", cfg.shm_size,
        # Deliberately NO --restart policy. On a teaching machine an
        # auto-restarting container that silently reclaims the GPU after you
        # stopped it to generate is a genuinely baffling failure.
        "-v", f"{cfg.cache_dir}:/opt/nim/.cache",
        "-p", f"{cfg.port}:8000",
        # `-e NAME` with no `=value` tells docker to copy the value from the
        # CURRENT process environment. The key therefore never appears in this
        # process's argv, so it never shows up in `ps`, in a shell history, in a
        # notebook's output, or in an exception traceback. Never write
        # `-e NGC_API_KEY=...` here.
        "-e", "NGC_API_KEY",
        "-e", f"NIM_MODEL_SIZE={cfg.model_size}",
    ]

    # Run as the invoking user so the cache directory does not fill up with
    # root-owned files that you then cannot delete without sudo. getuid is
    # POSIX-only; the course targets Linux but the module should still import
    # on a Windows laptop someone is reading it on.
    if hasattr(os, "getuid"):
        argv += ["-u", f"{os.getuid()}:{os.getgid()}"]  # type: ignore[attr-defined]

    if cfg.gpu_memory_fraction is not None:
        value = _memory_env_value(cfg.gpu_memory_fraction, NIM_MEMORY_ENV)
        argv += ["-e", f"{NIM_MEMORY_ENV}={value}"]

    for key, value in cfg.extra_env.items():
        argv += ["-e", f"{key}={value}"]

    argv.append(cfg.reference)

    if not quiet:
        # Safe to print in full: the only secret is passed by name, not value.
        print("$ " + " ".join(argv))
        print()
        if cfg.gpu_memory_fraction is not None:
            print(
                f"VRAM cap requested: {cfg.gpu_memory_fraction:.2f} via {NIM_MEMORY_ENV}.\n"
                f"  That variable name is UNVERIFIED (see the comment on NIM_MEMORY_ENV).\n"
                f"  Once the NIM is up, run nim_status(cfg)['vram_gb'] and compare it with\n"
                f"  the uncapped run. If the number did not move, the name is wrong —\n"
                f"  discover_memory_env(cfg) will tell you the right one.\n"
            )

    proc = _docker(argv[1:], timeout=300)
    if proc is None or proc.returncode != 0:
        stderr = (proc.stderr.strip() if proc else "") or "(no output from docker)"
        raise RuntimeError(_explain_docker_run_failure(stderr, cfg))

    container_id = proc.stdout.strip()[:12]
    if not quiet:
        print(f"started container {container_id}\n")
        print(
            "First run on this machine will pull the image (8.3 GB compressed) and\n"
            f"then download model weights into {cfg.cache_dir} — about 20 GB for the\n"
            "nano profile at FP8, 40 GB for super. That can take 10–30 minutes on a\n"
            "normal connection and there is no progress bar on this side of it.\n"
            "Subsequent starts reuse the cache and take roughly a minute.\n"
            "\n"
            f"  Watch it if you like:  docker logs -f {cfg.container_name}\n"
        )

    waited = 0.0
    if wait:
        try:
            waited = wait_for_nim(
                cfg.base_url, timeout, quiet=quiet, container_name=cfg.container_name
            )
        except RuntimeError as exc:
            # Attach the last few log lines to the timeout message. Making the
            # learner run a second command to see the actual error is a small
            # cruelty we can avoid.
            tail = nim_logs(cfg, tail=25)
            raise RuntimeError(
                f"{exc}\n\n--- last 25 lines of `docker logs {cfg.container_name}` ---\n{tail}"
            ) from None

    out = nim_status(cfg)
    out["already_running"] = False
    out["startup_seconds"] = round(waited, 1)
    out["container_id"] = container_id

    if not quiet and out["vram_gb"] is not None:
        print(
            f"\nThe NIM is holding {out['vram_gb']:.1f} GB of VRAM"
            + (f" of {out['gpu_total_gb']:.0f} GB total." if out["gpu_total_gb"] else ".")
        )
        if out["gpu_total_gb"] and out["vram_gb"] > 0.6 * out["gpu_total_gb"]:
            print(
                "  That is most of the card, and it is expected: the server has "
                "reserved\n  free VRAM as KV cache. Generation will OOM while this is "
                "running.\n  Call stop_nim(cfg) first, or restart with "
                "gpu_memory_fraction set — see\n  print_vram_plan()."
            )
    return out


def _explain_docker_run_failure(stderr: str, cfg: NimConfig) -> str:
    """Turn docker's stderr into something a learner can act on."""
    low = stderr.lower()
    hint = ""
    if "unauthorized" in low or "authentication required" in low or "401" in low:
        hint = (
            "\n  This is an authentication failure pulling from nvcr.io. Run:\n"
            "    echo \"$NGC_API_KEY\" | docker login nvcr.io -u '$oauthtoken' --password-stdin\n"
            "  The username is the literal text $oauthtoken; the single quotes matter."
        )
    elif "could not select device driver" in low or "nvidia-container-cli" in low:
        hint = (
            "\n  Docker cannot pass the GPU through. Install the NVIDIA Container\n"
            "  Toolkit and restart the daemon, then verify with:\n"
            "    docker run --rm --gpus all nvidia/cuda:12.8.0-base-ubuntu22.04 nvidia-smi"
        )
    elif "port is already allocated" in low or "address already in use" in low:
        hint = (
            f"\n  Host port {cfg.port} is already taken. Either stop whatever owns it,\n"
            f"  or start the NIM on another port: NimConfig(port=8001)."
        )
    elif "no space left" in low:
        hint = (
            "\n  The disk is full. The image is 8.3 GB compressed and the weights are\n"
            "  20–40 GB on top. Check `df -h` and `docker system df`."
        )
    elif "manifest unknown" in low or "not found" in low:
        hint = (
            f"\n  The registry does not have {cfg.reference}. Check the tag against\n"
            f"  https://catalog.ngc.nvidia.com/orgs/nim/teams/nvidia/containers/cosmos3-reasoner"
        )
    elif "is already in use by container" in low:
        hint = (
            f"\n  A container named {cfg.container_name!r} already exists. Remove it:\n"
            f"    docker rm -f {cfg.container_name}"
        )
    return f"`docker run` failed.\n\n{stderr}{hint}"


def stop_nim(cfg: NimConfig | None = None, *, quiet: bool = False) -> dict[str, Any]:
    """Stop and remove the NIM container. Idempotent, and reports VRAM freed.

    Removing rather than merely stopping is deliberate: a stopped container
    keeps its name, and the next ``start_nim`` would have to remove it anyway.
    Nothing of value is lost, because the weights live in the bind-mounted cache
    directory, not in the container's writable layer.

    The VRAM figure is measured before and after, because the point of stopping
    the NIM is almost always to get that memory back for generation, and "the
    driver has actually released it" is a different claim from "docker says the
    container is gone".
    """
    cfg = cfg or NimConfig()
    before = _gpu_used_mib()

    result: dict[str, Any] = {
        "stopped": False,
        "removed": False,
        "vram_before_gb": round(before / 1024, 2) if before is not None else None,
        "vram_after_gb": None,
        "vram_freed_gb": None,
    }

    if shutil.which("docker") is None:
        if not quiet:
            print("docker is not available; nothing to stop.")
        return result

    stop = _docker(["stop", "-t", "30", cfg.container_name], timeout=120)
    result["stopped"] = bool(stop and stop.returncode == 0)
    rm = _docker(["rm", "-f", cfg.container_name], timeout=60)
    result["removed"] = bool(rm and rm.returncode == 0)

    if not (result["stopped"] or result["removed"]):
        if not quiet:
            print(f"no container named {cfg.container_name!r} was running.")

    # The driver does not hand memory back the instant the process dies; there
    # is a short teardown while the CUDA context is destroyed. Polling for it is
    # the difference between a correct "freed 61 GB" and a confusing "freed 0 GB"
    # followed by an OOM two cells later that is actually just a race.
    after = before
    if before is not None:
        deadline = time.monotonic() + 45
        while time.monotonic() < deadline:
            after = _gpu_used_mib()
            if after is None or after <= before - 512:      # >0.5 GiB released
                break
            time.sleep(2.0)

    if after is not None:
        result["vram_after_gb"] = round(after / 1024, 2)
        if before is not None:
            result["vram_freed_gb"] = round(max(0.0, before - after) / 1024, 2)

    if not quiet:
        if result["vram_freed_gb"] is not None:
            print(
                f"NIM stopped. VRAM: {result['vram_before_gb']:.1f} GB -> "
                f"{result['vram_after_gb']:.1f} GB "
                f"(freed {result['vram_freed_gb']:.1f} GB)"
            )
            if result["vram_after_gb"] > 4.0:
                print(
                    f"  {result['vram_after_gb']:.1f} GB is still in use by something else.\n"
                    f"  Run `nvidia-smi` — a leftover python process from a previous\n"
                    f"  generation run is the usual explanation, and it will make your\n"
                    f"  next run OOM for no visible reason."
                )
        else:
            print("NIM stopped. (Could not read VRAM; nvidia-smi unavailable.)")
    return result


def nim_logs(cfg: NimConfig | None = None, tail: int = 50) -> str:
    """Return the last ``tail`` lines of the container's logs.

    stdout and stderr are merged, because NIM containers log their startup
    progress to one and their errors to the other and you want them in order.
    """
    cfg = cfg or NimConfig()
    proc = _docker(["logs", "--tail", str(tail), cfg.container_name], timeout=60)
    if proc is None:
        return "(docker unavailable)"
    if proc.returncode != 0:
        return (proc.stderr or "").strip() or f"(no container named {cfg.container_name!r})"
    merged = (proc.stdout or "") + (proc.stderr or "")
    return merged.strip() or "(the container has produced no output yet)"


# --------------------------------------------------------------------------
# The memory knob: discovery and planning
# --------------------------------------------------------------------------
def discover_memory_env(
    cfg: NimConfig | None = None, *, timeout: int = 600, quiet: bool = False
) -> dict[str, Any]:
    """Ask the NIM image itself which memory-related env vars it understands.

    This is the "do not take my word for it" escape hatch for ``NIM_MEMORY_ENV``.
    It runs ``docker run --rm <image> --help`` (which does not load the model and
    does not need a GPU) and scans the output for every ``NIM_*`` name containing
    MEM, GPU, KV, CACHE or UTIL.

    Returns ``{"available", "known_candidates_found", "other_matches", "help_text"}``.

    Note it may legitimately find nothing: not every NIM image documents its
    environment variables in ``--help``. In that case check
    https://docs.nvidia.com/nim/cosmos/latest/ , or start the container and run
    ``docker exec <name> env | grep NIM_`` to see what the entrypoint set.
    """
    cfg = cfg or NimConfig()
    out: dict[str, Any] = {
        "available": False,
        "known_candidates_found": [],
        "other_matches": [],
        "help_text": "",
    }
    if shutil.which("docker") is None:
        if not quiet:
            print("docker is not available, so the image cannot be interrogated.")
        return out

    proc = _docker(["run", "--rm", cfg.reference, "--help"], timeout=timeout)
    if proc is None:
        if not quiet:
            print("`docker run --help` on the image did not complete.")
        return out

    text = (proc.stdout or "") + (proc.stderr or "")
    out["help_text"] = text
    out["available"] = bool(text.strip())

    found = [name for name in NIM_MEMORY_ENV_CANDIDATES if name in text]
    others = sorted(
        set(re.findall(r"\bNIM_[A-Z0-9_]*(?:MEM|GPU|KV|CACHE|UTIL)[A-Z0-9_]*\b", text))
        - set(found)
    )
    out["known_candidates_found"] = found
    out["other_matches"] = others

    if not quiet:
        if not out["available"]:
            print("The image produced no --help output; nothing to scan.")
        elif found or others:
            print("Memory-related environment variables mentioned by the image:")
            for name in found:
                mark = "  <-- currently used by NIM_MEMORY_ENV" if name == NIM_MEMORY_ENV else ""
                print(f"  {name}{mark}")
            for name in others:
                print(f"  {name}   (not in this module's candidate list)")
            if NIM_MEMORY_ENV not in found:
                print(
                    f"\n{NIM_MEMORY_ENV!r} was NOT mentioned. Set the right one with:\n"
                    f"    export COSMOS_COURSE_NIM_MEMORY_ENV=<name>\n"
                    f"  and restart the kernel, or pass it through NimConfig.extra_env."
                )
        else:
            print(
                "No NIM_* memory variables appeared in --help. That does not mean none\n"
                "exist — check the NIM docs, or start the container and run:\n"
                f"    docker exec {cfg.container_name} env | grep NIM_"
            )
    return out


def suggest_memory_fraction(
    generator_model: str = "Cosmos3-Edge", *, total_gb: float | None = None
) -> float | None:
    """The largest VRAM fraction the NIM can take and still leave room to generate.

    Delegates the arithmetic to ``config.vram_budget()`` so there is one place
    where these numbers live. Returns None when coexistence is not feasible —
    which is the honest answer for Cosmos3-Super, and the reason strategy (a)
    (take turns) is the course default.
    """
    budget = vram_budget(total_gb)
    key = {
        "Cosmos3-Edge": "coexist_with_edge",
        "Cosmos3-Nano": "coexist_with_nano",
    }.get(generator_model)
    if key is None:
        return None
    entry = budget[key]
    return float(entry["nim_fraction"]) if entry["feasible"] else None


def print_vram_plan(total_gb: float | None = None) -> dict[str, Any]:
    """Print both single-GPU strategies with real numbers. Returns the budget.

    Lesson 02 runs this before starting anything, because the decision it
    describes — take turns, or cap — is the decision that determines whether the
    rest of the course fits on your machine.
    """
    b = vram_budget(total_gb)
    print(f"GPU total                    {b['total_gb']:.0f} GB")
    print(f"  reserve (context, frag.)   {b['reserve_gb']:.0f} GB")
    print(f"  NIM weights (nano, FP8)    ~{b['nim_weights_fp8_gb']:.0f} GB")
    print()
    print("(a) TAKE TURNS  — the default")
    print(f"    NIM alone can use up to   {b['take_turns']['nim_alone_fraction']:.2f} of the card")
    print(f"    {b['take_turns']['note']}")
    print()
    print("(b) COEXIST     — cap the NIM with NimConfig(gpu_memory_fraction=...)")
    for label, key in (("Cosmos3-Edge", "coexist_with_edge"), ("Cosmos3-Nano", "coexist_with_nano")):
        e = b[key]
        gen = b["generator"][label]
        if e["feasible"]:
            print(
                f"    generating with {label:<13} ({gen} GB) -> "
                f"gpu_memory_fraction={e['nim_fraction']:.2f}  "
                f"(~{e['nim_budget_gb']:.0f} GB for the NIM, of which ~"
                f"{b['nim_weights_fp8_gb']:.0f} GB is weights)"
            )
        else:
            print(
                f"    generating with {label:<13} ({gen} GB) -> NOT FEASIBLE; "
                f"only ~{e['nim_budget_gb']:.0f} GB would be left. Take turns."
            )
    print()
    print("    The cost of (b) is KV cache. A capped NIM has less room for long")
    print("    contexts, so a 20-second video at high fps in a single request may")
    print("    be refused where an uncapped NIM would have served it. Verify what")
    print("    you actually got with nim_status(cfg)['vram_gb'] — not with the flag.")
    return b
