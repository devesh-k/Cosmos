"""Output verification — did the model actually work, or just exit cleanly?

An exit code tells you a process finished. It does not tell you the process was
right. That distinction is the whole reason this module exists, and it is not a
property of any particular GPU: a generation pipeline has many ways to complete
tidily, return 0, write a well-formed file, and hand you something worthless.

The failure modes that actually do this, on any hardware, including yours:

* **Guardrail rejection.** The guardrail sits between the model and the file it
  writes. A rejected prompt or a rejected frame can leave you a blanked,
  blurred or blocked output while the run reports success. This is the most
  common one in practice, and it is a *policy* decision, not a crash.
* **A malformed or empty prompt.** An empty string, a prompt lost to a JSON
  escaping mistake, or a spec field spelled wrong so the default applies:
  the model conditions on almost nothing and emits a near-static frame.
* **Wrong control-video geometry in transfer.** ``video2video`` plus a control
  hint expects the control video to match the job's resolution, frame count and
  FPS. Mismatched geometry can be silently dropped, and you get a clean,
  plausible video that owes nothing to the control input you spent an hour
  preparing. Nothing in the exit code hints at this.
* **The wrong ``domain_name`` in an action spec.** The action head produces
  numbers of the right shape and the right dtype for the wrong embodiment.
  Perfectly well-formed, completely meaningless.
* **NaN in an fp16/bf16 path.** A single overflow propagates through the latent
  and decodes to flat or uniform output. The tensor is still a tensor; the
  writer still writes it.

*Historical example, on other hardware:* NVIDIA/cosmos-framework issue #42
describes an aarch64 Blackwell CUTLASS attention-backend failure that logs
``Last CUDA error is: no error``, exits 0, and writes a valid JPEG of pure gray
noise. **That bug is not your bug** — this course targets x86_64 Hopper — but it
remains the cleanest illustration of why a clean exit proves nothing.

So the course checks content, every time. None of these functions is a quality
metric. They are *aliveness* checks — cheap statistics that separate "the model
produced structure" from "the model produced noise, or nothing". A picture can
pass every check here and still be a bad picture; that judgement is yours.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "CheckResult",
    "check_image",
    "check_video",
    "check_text",
    "check_action",
    "verify_result",
]


@dataclass
class CheckResult:
    """Outcome of one verification, with the evidence attached."""

    name: str
    passed: bool
    reason: str
    metrics: dict[str, Any] = field(default_factory=dict)

    def __bool__(self) -> bool:
        return self.passed

    def __str__(self) -> str:
        mark = "PASS" if self.passed else "FAIL"
        bits = ", ".join(
            f"{k}={v:.4g}" if isinstance(v, float) else f"{k}={v}" for k, v in self.metrics.items()
        )
        return f"[{mark}] {self.name}: {self.reason}" + (f"  ({bits})" if bits else "")


# --------------------------------------------------------------------------
# Images
# --------------------------------------------------------------------------
def _spatial_autocorrelation(arr) -> float:
    """Mean lag-1 spatial autocorrelation of a 2-D array.

    This is the statistic that actually separates a picture from noise, and it
    is worth understanding rather than treating as a magic number.

    In a real image, a pixel is a very good predictor of the pixel next to it:
    surfaces are smooth, objects are contiguous, lighting varies slowly. The
    correlation between an image and itself shifted by one pixel is typically
    above 0.95.

    In white noise, every pixel is independent of its neighbours by
    construction, so that same correlation sits near 0.

    That is a huge separation, and unlike standard deviation or edge density it
    does not care about the *amplitude* of the noise. Low-contrast noise and
    high-contrast noise both score near zero, which is precisely what we need,
    because the nastiest failures produce mid-gray noise whose mean, standard
    deviation and histogram all look perfectly healthy. An amplitude test passes
    that image. This one does not.
    """
    import numpy as np

    a = np.asarray(arr, dtype=np.float64)
    scores = []
    for shifted, original in ((a[:, 1:], a[:, :-1]), (a[1:, :], a[:-1, :])):
        x = shifted.ravel()
        y = original.ravel()
        sx, sy = x.std(), y.std()
        if sx < 1e-6 or sy < 1e-6:
            # A perfectly flat image is degenerate: correlation is undefined,
            # but it is certainly not noise, so score it as fully correlated
            # and let the flatness check catch it instead.
            scores.append(1.0)
            continue
        scores.append(float(((x - x.mean()) * (y - y.mean())).mean() / (sx * sy)))
    return float(np.mean(scores))


def check_image(
    path: Path | str,
    *,
    min_std: float = 6.0,
    min_autocorrelation: float = 0.55,
    max_uniform_fraction: float = 0.92,
) -> CheckResult:
    """Verify an image contains structure rather than noise or a flat fill.

    Three independent statistics, because each catches a different failure:

    * **Standard deviation** of pixel intensity. Near zero means a flat fill —
      a NaN-poisoned latent, or a guardrail that blanked the frame, or a
      pipeline that produced nothing at all.
    * **Spatial autocorrelation** (see ``_spatial_autocorrelation``). Near zero
      means noise. *This is the check that catches the gray-noise failure*,
      which sails past every amplitude-based test because its standard
      deviation and histogram look entirely normal.
    * **Uniform fraction** — how much of the histogram sits in a single bin.
      Catches an image that is 95% one colour with a small artefact in a corner,
      which is what a blocked or heavily-degraded output usually looks like.

    Thresholds are deliberately loose. A false pass is recoverable, because you
    will look at the picture anyway; a false fail teaches learners to ignore the
    check, which is much worse.
    """
    path = Path(path)
    metrics: dict[str, Any] = {}

    if not path.exists():
        return CheckResult("image", False, f"file does not exist: {path}")
    size_kb = path.stat().st_size / 1024
    metrics["size_kb"] = round(size_kb, 2)
    # Only catch truly empty files here. A flat image compresses to almost
    # nothing in PNG, and we want the flatness check below to explain that
    # properly rather than a confusing "file too small".
    if size_kb < 0.2:
        return CheckResult("image", False, f"file is essentially empty ({size_kb:.2f} KB)", metrics)

    try:
        import numpy as np
        from PIL import Image
    except ImportError:
        return CheckResult(
            "image", True, "numpy/Pillow unavailable; only checked the file exists", metrics
        )

    try:
        img = Image.open(path).convert("L")
    except Exception as exc:
        return CheckResult("image", False, f"could not decode: {exc}", metrics)

    arr = np.asarray(img, dtype=np.float32)
    metrics["width"], metrics["height"] = img.size
    metrics["mean"] = float(arr.mean())
    metrics["std"] = float(arr.std())

    hist, _ = np.histogram(arr, bins=32, range=(0, 255))
    metrics["uniform_fraction"] = float(hist.max() / max(hist.sum(), 1))

    gy, gx = np.gradient(arr)
    grad = np.hypot(gx, gy)
    metrics["edge_density"] = float((grad > 25).mean())
    metrics["autocorrelation"] = round(_spatial_autocorrelation(arr), 4)

    if metrics["std"] < min_std:
        return CheckResult(
            "image", False,
            f"almost flat (std {metrics['std']:.1f} < {min_std}) — an empty or failed "
            f"render. Check the run log for a guardrail rejection, and check that the "
            f"prompt actually reached the model rather than arriving empty.",
            metrics,
        )
    if metrics["autocorrelation"] < min_autocorrelation:
        return CheckResult(
            "image", False,
            f"neighbouring pixels are nearly uncorrelated "
            f"(autocorrelation {metrics['autocorrelation']:.2f} < {min_autocorrelation}). "
            f"That is noise, not a scene: the decoder was handed something that is not a "
            f"picture. Usual causes are a NaN or Inf in the latent, a mismatched or "
            f"mis-selected attention backend, or a decoder fed the wrong tensor. Open the "
            f"file and look at it, then see Lesson 11's debugging lab.",
            metrics,
        )
    if metrics["uniform_fraction"] > max_uniform_fraction:
        return CheckResult(
            "image", False,
            f"{metrics['uniform_fraction']:.0%} of pixels sit in one histogram bin — "
            f"the image is nearly a single colour. A blocked or blanked frame looks "
            f"exactly like this, so read the log before assuming the model failed.",
            metrics,
        )

    return CheckResult("image", True, "contains spatial structure", metrics)


# --------------------------------------------------------------------------
# Video
# --------------------------------------------------------------------------
def check_video(
    path: Path | str,
    *,
    min_frames: int = 2,
    sample_frames: int = 5,
    min_temporal_change: float = 0.15,
    max_temporal_change: float = 60.0,
) -> CheckResult:
    """Verify a video decodes, has frames, and those frames both hold together
    and change over time.

    Two failure modes bracket the useful range:

    * **No change at all** — every frame identical. The generator collapsed, the
      prompt arrived empty, or you accidentally rendered a still.
    * **Change everywhere** — consecutive frames uncorrelated. That is temporal
      noise, not motion; it is what the gray-noise failure looks like when it
      happens to a video.

    Note what this cannot tell you. In transfer (``video2video`` plus a control
    hint) a video that ignored your control input entirely will pass every check
    below, because it is a perfectly healthy video — just not the one you asked
    for. Comparing against the control video is a separate job, and Lesson 11
    does it by eye.
    """
    path = Path(path)
    metrics: dict[str, Any] = {}

    if not path.exists():
        return CheckResult("video", False, f"file does not exist: {path}")
    metrics["size_kb"] = round(path.stat().st_size / 1024, 1)
    if metrics["size_kb"] < 5:
        return CheckResult("video", False, f"only {metrics['size_kb']} KB", metrics)

    frames = _read_frames(path, sample_frames)
    if frames is None:
        return CheckResult(
            "video", True,
            "no video decoder available (install imageio-ffmpeg or opencv); checked size only",
            metrics,
        )
    if len(frames) < min_frames:
        return CheckResult(
            "video", False, f"decoded only {len(frames)} frame(s), expected >= {min_frames}", metrics
        )

    import numpy as np

    metrics["frames_sampled"] = len(frames)
    metrics["height"], metrics["width"] = frames[0].shape[:2]

    # Per-frame spatial structure, using the same autocorrelation test as
    # check_image. A video whose individual frames are noise is the video form
    # of the gray-noise failure: the container is valid, the codec is happy,
    # the frame count is right, and there is no picture in it.
    mid = frames[len(frames) // 2].astype(np.float32)
    metrics["mid_frame_std"] = float(mid.std())
    metrics["mid_frame_autocorrelation"] = round(_spatial_autocorrelation(mid), 4)

    diffs = [float(np.abs(frames[i + 1].astype(np.float32) - frames[i].astype(np.float32)).mean())
             for i in range(len(frames) - 1)]
    metrics["mean_frame_difference"] = round(float(np.mean(diffs)), 4) if diffs else 0.0

    if metrics["mid_frame_std"] < 6:
        return CheckResult(
            "video", False,
            "frames are almost flat — check the log for a guardrail rejection and check "
            "that the prompt was non-empty",
            metrics,
        )
    if metrics["mid_frame_autocorrelation"] < 0.55:
        return CheckResult(
            "video", False,
            f"individual frames are spatially uncorrelated "
            f"(autocorrelation {metrics['mid_frame_autocorrelation']:.2f}) — the frames are noise, "
            f"not pictures. The container and codec are fine, so look upstream: NaN in the "
            f"latent, or a decoder handed the wrong tensor. See Lesson 11's debugging lab.",
            metrics,
        )
    if metrics["mean_frame_difference"] < min_temporal_change:
        return CheckResult(
            "video", False,
            f"frames barely change (mean difference {metrics['mean_frame_difference']:.3f}). "
            f"Either generation collapsed to a still, or you asked for one frame, or the "
            f"conditioning was so thin that the model had nothing to animate.",
            metrics,
        )
    if metrics["mean_frame_difference"] > max_temporal_change:
        return CheckResult(
            "video", False,
            f"consecutive frames differ enormously "
            f"(mean difference {metrics['mean_frame_difference']:.1f}). That is temporal noise or a "
            f"hard scene cut every frame, not continuous motion.",
            metrics,
        )

    return CheckResult("video", True, "decodes, has spatial structure, and moves", metrics)


def _read_frames(path: Path, count: int):
    """Sample up to ``count`` grayscale frames. Returns None if we cannot decode."""
    try:
        import numpy as np
    except ImportError:
        return None

    try:
        import imageio.v3 as iio

        frames = []
        for i, frame in enumerate(iio.imiter(path)):
            frames.append(frame)
            if len(frames) >= count * 4:
                break
        if not frames:
            return None
        step = max(1, len(frames) // count)
        picked = frames[::step][:count]
        return [np.asarray(f).mean(axis=2) if f.ndim == 3 else np.asarray(f) for f in picked]
    except Exception:
        pass

    try:
        import cv2

        cap = cv2.VideoCapture(str(path))
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
        if total <= 0:
            cap.release()
            return None
        idxs = [int(i * (total - 1) / max(count - 1, 1)) for i in range(count)]
        out = []
        for idx in idxs:
            cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ok, frame = cap.read()
            if ok:
                out.append(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
        cap.release()
        return out or None
    except Exception:
        return None


# --------------------------------------------------------------------------
# Text
# --------------------------------------------------------------------------
def check_text(
    text: str | Path,
    *,
    min_words: int = 5,
    max_repetition_ratio: float = 0.45,
) -> CheckResult:
    """Verify reasoner output is language rather than degenerate repetition.

    The reasoner's version of the gray-noise failure is fluent-looking output
    with no content — often the same phrase repeated, or a very small vocabulary
    stretched over many tokens. Type-token ratio catches both. The other thing
    it catches, and the more common one, is an empty response: a guardrail
    rejection and a request that never reached the model look identical from
    here, and both return HTTP 200.
    """
    if isinstance(text, Path) or (isinstance(text, str) and len(text) < 260 and Path(text).exists()):
        try:
            text = Path(text).read_text()
        except OSError:
            pass

    body = str(text).strip()
    metrics: dict[str, Any] = {"characters": len(body)}

    if not body:
        return CheckResult(
            "text", False,
            "empty output — a successful call that returned nothing. Check for a guardrail "
            "rejection, an empty prompt field, or a response parsed from the wrong key",
            metrics,
        )

    words = re.findall(r"[A-Za-z']+", body.lower())
    metrics["words"] = len(words)
    if len(words) < min_words:
        return CheckResult("text", False, f"only {len(words)} words", metrics)

    unique = len(set(words))
    metrics["unique_words"] = unique
    metrics["type_token_ratio"] = round(unique / len(words), 3)
    if metrics["type_token_ratio"] < (1 - max_repetition_ratio):
        return CheckResult(
            "text", False,
            f"highly repetitive (type-token ratio {metrics['type_token_ratio']:.2f}). "
            f"This is what a broken reasoner tower looks like — fluent shape, no content.",
            metrics,
        )

    # A single token repeated many times in a row is degenerate even if overall
    # vocabulary looks fine.
    longest_run = 1
    run = 1
    for a, b in zip(words, words[1:]):
        run = run + 1 if a == b else 1
        longest_run = max(longest_run, run)
    metrics["longest_repeat_run"] = longest_run
    if longest_run > 8:
        return CheckResult(
            "text", False, f"one word repeats {longest_run} times consecutively", metrics
        )

    return CheckResult("text", True, "looks like language", metrics)


# --------------------------------------------------------------------------
# Actions
# --------------------------------------------------------------------------
def check_action(
    action: Any,
    *,
    expected_dims: int | None = None,
    max_abs: float = 1e3,
) -> CheckResult:
    """Verify a predicted action array is well-formed and finite.

    Catches NaN/Inf (numerical instability), absurd magnitudes (a scale or
    convention error), an unexpected dimensionality, and an all-zero prediction
    (the model declining to move, which is usually a spec problem rather than a
    considered decision).

    Be clear about the limit of this check. Actions are the output where "well
    formed" and "correct" are furthest apart: a spec with the wrong
    ``domain_name`` selects the wrong embodiment, and the model will return
    finite, plausibly-scaled, correctly-shaped numbers that mean nothing for
    your robot. Nothing statistical can see that. Verify ``domain_name`` against
    the dataset you are actually using, and check the dimensionality matches
    that embodiment with ``expected_dims``.
    """
    metrics: dict[str, Any] = {}
    try:
        import numpy as np
    except ImportError:
        return CheckResult("action", True, "numpy unavailable; not checked", metrics)

    if isinstance(action, (str, Path)) and Path(action).exists():
        data = json.loads(Path(action).read_text())
        try:
            action = data["outputs"][0]["content"]["action"]
        except (KeyError, IndexError, TypeError):
            action = data

    arr = np.asarray(action, dtype=np.float64)
    metrics["shape"] = list(arr.shape)
    if arr.ndim != 2:
        return CheckResult("action", False, f"expected a 2-D [steps, dims] array, got {arr.shape}", metrics)

    steps, dims = arr.shape
    metrics["steps"], metrics["dims"] = steps, dims
    if steps < 1:
        return CheckResult("action", False, "no action steps", metrics)
    if expected_dims is not None and dims != expected_dims:
        return CheckResult(
            "action", False,
            f"expected {expected_dims} dimensions per step, got {dims} — the most likely "
            f"cause is a `domain_name` that does not match the embodiment you meant",
            metrics,
        )

    metrics["n_nonfinite"] = int((~np.isfinite(arr)).sum())
    if metrics["n_nonfinite"]:
        return CheckResult(
            "action", False,
            f"{metrics['n_nonfinite']} non-finite value(s) — numerical instability", metrics,
        )

    metrics["abs_max"] = float(np.abs(arr).max())
    metrics["abs_mean"] = float(np.abs(arr).mean())
    if metrics["abs_max"] > max_abs:
        return CheckResult(
            "action", False,
            f"largest magnitude {metrics['abs_max']:.3g} exceeds {max_abs:g}; "
            f"suspect a units or scale error",
            metrics,
        )
    if math.isclose(metrics["abs_max"], 0.0, abs_tol=1e-9):
        return CheckResult(
            "action", False,
            "every value is zero — the model predicted no motion. Check the observation "
            "actually loaded and that `domain_name` is right before concluding the model "
            "chose to stay still",
            metrics,
        )

    return CheckResult("action", True, "finite, non-trivial, correctly shaped", metrics)


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------
def verify_result(result: Any, *, verbose: bool = True) -> list[CheckResult]:
    """Run every applicable check on a GenerationResult and report.

    Use this after **every** generation. It is the habit the course is trying to
    build: never conclude a run worked because it exited zero.
    """
    checks: list[CheckResult] = []

    # The exit code is reported first and deliberately treated as one signal
    # among several. A non-zero code is conclusive evidence of failure; a zero
    # is not evidence of success, which is the asymmetry this module is about.
    rc = getattr(result, "returncode", 0)
    checks.append(
        CheckResult("process", rc == 0, f"exit code {rc}", {"returncode": rc})
    )

    if getattr(result, "image_path", None):
        checks.append(check_image(result.image_path))
    if getattr(result, "video_path", None):
        checks.append(check_video(result.video_path))
    if getattr(result, "text_path", None):
        checks.append(check_text(Path(result.text_path)))

    outputs = getattr(result, "sample_outputs", None) or {}
    try:
        action = outputs["outputs"][0]["content"]["action"]
        checks.append(check_action(action))
    except (KeyError, IndexError, TypeError):
        pass

    if verbose:
        for c in checks:
            print(c)
        failed = [c for c in checks if not c.passed]
        if failed:
            print(
                f"\n{len(failed)} check(s) failed. Open the output and look at it before doing "
                f"anything else — a clean exit code does not mean a correct result."
            )
        else:
            print("\nall checks passed")
    return checks
