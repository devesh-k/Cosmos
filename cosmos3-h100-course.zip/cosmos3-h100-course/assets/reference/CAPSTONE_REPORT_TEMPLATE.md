# Capstone report — synthetic data flywheel

> **How to use this file.** Copy it to `outputs/capstone/REPORT.md` and fill it
> in. It has **eight sections**, `## 0.` through `## 7.`, and `check_stage_6()`
> asserts that all eight are present — that is the same count the rubric and the
> notebook use. Do not delete a heading because you have nothing to put under it
> — write "not done, because …" instead. A missing section reads as an
> oversight; an empty section with a reason reads as a decision, and the rubric
> scores the two differently.
>
> Every `<…>` is a placeholder. Every `[FILL]` must be replaced by a number that
> came out of **your** run, copied from `outputs/capstone/metrics.json`. If you
> find yourself typing a number you did not measure, stop and measure it.
>
> Target length: 900–1,600 words plus tables. Longer is not better. The rubric
> rewards a claim with evidence attached, and penalises a paragraph of adjectives.

---

## 0. One-paragraph summary

<Three to five sentences. What you built, what it produced, what it cost, and the
single most important thing you learned. Somebody who reads only this paragraph
should be able to decide whether to read the rest.>

**Headline numbers.**

| | |
|---|---|
| Mode | `<reduced \| full>` |
| Generator checkpoint | `<Cosmos3-Edge \| Cosmos3-Nano \| your Lesson 17 checkpoint>` |
| Source clips | [FILL] |
| Variants attempted | [FILL] |
| Variants accepted | [FILL] |
| Acceptance rate | [FILL] % |
| Wall clock | [FILL] min |
| GPU-seconds per accepted clip | [FILL] |
| Peak device VRAM | [FILL] GB |

---

## 1. Method

### 1.1 The pipeline

<Describe the six stages in your own words, in the order they ran. One or two
sentences each. Name the `cosmos_course` API each stage used, so a reader can
find the code. If you deviated from the scaffolded interface, say where and why.>

| Stage | What it did | Key API | Input | Output |
|---|---|---|---|---|
| Reason | | `cc.Reasoner.ask` / `parse_json` | | |
| Vary | | — | | |
| Generate | | `cc.InferenceSpec`, `cc.Generator.run` | | |
| Validate | | `cc.verify_result`, `cc.Reasoner` | | |
| Measure | | `cc.StageClock`, `cc.DeviceSampler`, `cc.MeasurementLog` | | |
| Report | | — | | |

### 1.2 Configuration

<The exact settings. Copy them from your config cell rather than retyping — a
report whose configuration does not match the run it describes is worse than no
report.>

```
MODE            = <>
MODEL           = <>
RESOLUTION      = <>          # tier name, not pixels
NUM_FRAMES      = <>
NUM_STEPS       = <>
ASPECT_RATIO    = <>          # comma, not colon
SEEDS           = <>
N_SOURCES       = <>
VARIANTS/SOURCE = <>
GEN_BATCH_SIZE  = <>
JUDGE_THRESHOLD = <>
```

### 1.3 Source material

<Which real clips you started from and why those. If you used cookbook assets
rather than your own footage, say so — it matters for section 4, because
cookbook clips are in-distribution for a model that may well have seen them.>

### 1.4 Scheduling on one GPU

<How you shared the card between the reasoner and the generator. Which strategy
from Lesson 02 you chose — take turns, or cap the NIM — and what it cost. Give
the measured number of switches and the measured seconds spent switching.>

- Strategy: `<take turns \| cap the NIM at N%>`
- Switches: [FILL]
- Seconds spent starting/stopping: [FILL]
- Switching as a fraction of wall clock: [FILL] %

---

## 2. Design decisions

> Four decisions, each with the alternative you rejected. "I picked X" is not a
> justification. "I picked X over Y because <property of the problem>, and I
> would switch to Y if <observable condition>" is.

### 2.1 Conditioning modality

**Decision.** <image2video / video2video+hint / text2video / a mix, and which
kind of variation each was used for.>

**Why.** <Argue from what each mode preserves. `edge` preserves shape and layout;
`blur` preserves colour and lighting; `depth` preserves 3D structure; `seg`
preserves object identity — COSMOS3_FACTS.md §2. image2video preserves only the
first frame and invents the rest.>

**Rejected alternative.** <Which one, and the specific reason.>

**What would change my mind.** <An observation, not a feeling.>

### 2.2 Diversity criterion

**My definition of a *useful* variation.** <A variation is useful if …>

**How I measured it.** <The concrete, computable criterion. Examples: distinct
values on a named attribute axis; caption-embedding distance above a threshold;
a held-out attribute the source set does not cover. It must be something your
code computes, not something you eyeballed.>

**Measured diversity of the accepted set.** [FILL] — <with units and the axis>

**Why this criterion and not another.** <Say what it rewards and, more usefully,
what it can be gamed by.>

### 2.3 Accept/reject policy

**What I asked the reasoner.** <The exact prompt, or a pointer to where it lives
in the notebook.>

**The threshold, and what it is on.** <e.g. "accept if the judge returns
`plausible: true` AND `confidence >= 0.7` AND `check_video` passed">

**Where this sits on the precision/recall tradeoff.** <A loose threshold admits
implausible clips into training data; a tight one throws away usable clips and
raises your cost per accepted clip. Say which error you chose to make and why
that is the right error for a robotics training set.>

**Measured.** rejected [FILL] of [FILL]; of the rejections, [FILL] were automatic
(`check_video`) and [FILL] were the judge.

**Spot-check.** <You must look at some of them. How many accepted clips did you
watch, and how many did you disagree with? How many rejected clips did you watch,
and how many looked fine to you? Both numbers, or the section does not count.>

| | Judge accepted | Judge rejected |
|---|---|---|
| I agreed | [FILL] | [FILL] |
| I disagreed | [FILL] | [FILL] |

### 2.4 Where the budget went

**VRAM.** <What you gave to what, and what you gave up. Include the number you
measured, not the tier's documented figure.>

**Wall clock.** <Which stage you decided to let dominate, and why that was the
right stage to spend on.>

**Rejected alternative.** <e.g. "I could have run 480p and half as many variants.
I chose more variants at 256p because …">

---

## 3. Results

### 3.1 Yield

| | Count | Share |
|---|---:|---:|
| Variants attempted | [FILL] | 100% |
| Produced a file | [FILL] | [FILL]% |
| Passed `check_video` | [FILL] | [FILL]% |
| Accepted by the judge | [FILL] | [FILL]% |
| Rejected | [FILL] | [FILL]% |
| Failed (error, not rejection) | [FILL] | [FILL]% |

<Failures and rejections are different and must not be merged. A rejection is the
policy working. A failure is the pipeline breaking.>

### 3.2 Cost

**Predicted, before the run.** <From your Lesson 06 calibration and Lesson 14
measurements. Show the arithmetic.>

```
units per variant      = <>            # cc.estimate_generation_cost(...)["cost_units"]
units per second       = <>            # outputs/06/calibration.json
predicted seconds/variant = <>
predicted acceptance rate = <>         # and where that guess came from
predicted GPU-seconds per accepted clip = <>
```

**Measured, after the run.**

```
measured seconds/variant = [FILL]
measured acceptance rate = [FILL]
measured GPU-seconds per accepted clip = [FILL]
ratio measured/predicted = [FILL]
```

**Reconciliation.** <Where the prediction was wrong and why. Candidates: fixed
process-launch overhead you forgot to include; the acceptance rate; NIM start-up;
the judge's latency; batching amortising the model load. Name the dominant term.
"It was 3x off" is not a reconciliation. "It was 3x off, and 80% of the gap is
the two NIM restarts at [FILL] s each, which the cost model does not include" is.>

### 3.3 Where the time went

| Stage | Seconds | Share |
|---|---:|---:|
| reason | [FILL] | [FILL]% |
| vary | [FILL] | [FILL]% |
| generate | [FILL] | [FILL]% |
| validate | [FILL] | [FILL]% |
| switch (NIM up/down) | [FILL] | [FILL]% |
| measure + report | [FILL] | [FILL]% |
| **accounted** | [FILL] | |
| **wall clock** | [FILL] | |

**Bottleneck.** <Name it, with the number. Then say what you would do about it
and what that would cost elsewhere.>

**Unaccounted time.** [FILL] s. <If this is large, say what it was.>

### 3.4 Memory

| Stage | Peak device VRAM (GB) |
|---|---:|
| reasoner resident | [FILL] |
| generation | [FILL] |
| overall | [FILL] |

**Did the two models ever coexist?** <Yes/no, and how you know. The evidence is a
device-wide sample, not an absence of errors.>

### 3.5 Failure handling

<Each of the four required failures, what your pipeline did, and the evidence.>

| Injected failure | Classified as | Pipeline did | Work lost |
|---|---|---|---|
| A rejected clip | | | |
| An OOM | | | |
| A dead NIM | | | |
| A malformed model response | | | |

**Resume.** <You killed the kernel mid-run. How many completed items did you lose?
How do you know? Point at the ledger.>

---

## 4. Threats to validity

> At least four, specific to *your* run. Generic risk lists score as "adequate"
> at best. For each, say how you would test it if you had another day.

1. **<Threat>.** <Why it threatens the conclusion. How to test it.>
2. **<Threat>.** …
3. **<Threat>.** …
4. **<Threat>.** …

Candidates worth considering, if they apply to you:

- **Judge circularity.** The reasoner and generator are two towers of one
  checkpoint (COSMOS3_FACTS.md §1). A judge that shares a prior with the thing
  it judges is not independent. What would break if it is systematically blind to
  a failure mode the generator produces?
- **Source-set contamination.** Cookbook clips may be in the model's training
  distribution. Variants of them are then easier than variants of your own
  footage, and your acceptance rate is optimistic.
- **Small n.** With [FILL] accepted clips, what size of difference could you
  even have detected? (Lesson 18 has the arithmetic.)
- **One seed per variant.** How much of the accept/reject outcome is the seed
  rather than the prompt?
- **Reduced-mode settings.** 256p at [FILL] steps is not what you would ship. Does
  the acceptance rate transfer to 480p at 35 steps? You have not shown that.
- **Diversity criterion gaming.** Could a degenerate generator score well on your
  criterion? Show the counterexample if you can construct one.

---

## 5. What this evidence does **not** support

> The section the rubric weights most heavily per word. Be specific and be
> unhedged. Four or more items.

- This does **not** show that <…>.
- This does **not** show that <…>.
- This does **not** show that <…>.
- This does **not** show that <…>.

<In particular: unless you trained on this data and evaluated the result, you have
not shown that the synthetic clips improve anything. You have shown that you can
produce them, screen them, and account for the cost. Say so.>

---

## 6. Next steps

<Three, ordered, each with the cost and the decision it would settle. "Try more
prompts" is not a next step. "Generate 40 variants across 10 source clips at
480p — about [FILL] GPU-hours at my measured rate — and fine-tune Edge on the
accepted set to test whether acceptance rate predicts downstream benefit" is.>

1. **<Step>** — cost `<GPU-hours / GB / hours of your time>`; settles `<question>`.
2. **<Step>** — cost `<…>`; settles `<…>`.
3. **<Step>** — cost `<…>`; settles `<…>`.

---

## 7. Reproducing this

```bash
# The exact commands, from a clean checkout, that produce outputs/capstone/.
<>
```

| | |
|---|---|
| Notebook | `19_capstone_synthetic_data_flywheel.ipynb` |
| Manifest | `outputs/capstone/manifest.jsonl` ([FILL] records) |
| Metrics | `outputs/capstone/metrics.json` |
| Measurement log | `outputs/capstone/measurements.jsonl` |
| Generated clips | `outputs/capstone/generated/` |
| Framework version | `<from cc.UPSTREAM>` |
| NIM tag | `<>` |
| Date of run | `<>` |

---

*Self-assess against `assets/reference/CAPSTONE_RUBRIC.md` before you call this
finished. The checklist at the end of that file takes ten minutes and is the
difference between "adequate" and "good" more often than any amount of extra
compute.*
