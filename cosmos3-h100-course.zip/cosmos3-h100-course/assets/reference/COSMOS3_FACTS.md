# Cosmos 3 — verified reference facts

Every number and name here was checked against a primary source in **August 2026**.
This file is the single source of truth for the course. If a lesson, a lecture script
or a helper contradicts it, this file wins — and if upstream contradicts *this* file,
open an issue and fix it here first.

**Why this file exists.** Several NVIDIA doc pages are currently stale in ways that will
actively mislead you (details in §7). Course material that quietly inherits a stale doc
teaches a wrong thing confidently, which is worse than teaching nothing.

---

## 1. Model tiers

Parameter counts are safetensors index totals from the Hugging Face model cards.

| Checkpoint | Params (total) | Active | Download | Gated? | Max res | Audio | Transfer |
|---|---:|---:|---:|---|---|---|---|
| `nvidia/Cosmos3-Edge` | 3,858,999,728 (**4B**) | 4B (dense) | ~9.1 GB | **No** | 480p | No | **No** |
| `nvidia/Cosmos3-Nano` | 15,750,057,456 (**16B**) | **8B** (MoT) | ~34.9 GB | **No** | 768p | Yes | Yes |
| `nvidia/Cosmos3-Super` | 64,615,003,632 (**64B**) | **32B** (MoT) | ~133 GB | **No** | 768p | Yes | No |
| `nvidia/Cosmos3-Nano-Policy-DROID` | 16B | 8B | ~30 GB | **No** | — | — | — |
| `nvidia/Cosmos3-Edge-Policy-DROID` | 4B | 4B | ~9 GB | **No** | — | — | — |
| `nvidia/Cosmos-Guardrail1` | composite | — | ~3.6 GB | **YES** (`auto`) | — | — | — |

### Two traps in this table

**The naming trap.** NVIDIA's docs and the NIM call the tiers "Nano (8B)" and
"Super (32B)". Hugging Face reports 16B and 64B. Both are correct. These are
Mixture-of-Transformers models with separate reasoner and generator towers; the
smaller number is what flows through one forward pass, the larger is what sits on
disk and in VRAM. For **inference VRAM**, budget against the smaller number. For
**training memory**, budget against the larger, because every parameter needs an
optimizer state.

**The gating trap.** The source DLI course (`S-OV-57-V1`, notebook 01) spends an
entire notebook on accepting gated licences for `Cosmos3-Nano`. That is now
obsolete — all nine Cosmos3 repos return `gated: false`. The **only** repo that
still requires a licence click is `nvidia/Cosmos-Guardrail1`, which the generator
enables by default. One click, not five.

*Source:* `https://huggingface.co/api/models?author=nvidia&search=Cosmos3`

### Release dates
- **2026-05-31** — Nano (16B), Super (64B), Nano-Policy-DROID, Super-Image2Video, Super-Text2Image
- **2026-07-20** — Edge (4B), Edge-Policy-DROID, Super-\*-4Step distilled variants

### Licence
**OpenMDW 1.1** (`openmdw1.1-license`), not the NVIDIA Open Model License that the
source course cites.

---

## 2. Model modes — the authoritative list

From `ModelMode(StrEnum)` in `cosmos_framework/inference/args.py` on `main`:

```
text2image          image2image         forward_dynamics
text2video          image2video         inverse_dynamics
audio_image2video   video2video         wam
                                        reasoner
```

### `policy` is dead. It is now `wam`.

The source course's notebook 04 uses `"model_mode": "policy"`. **That will fail.**
Upstream renamed it to `wam` (World Action Model). Three independent confirmations:

1. `ACTION_MODEL_MODES = frozenset({FORWARD_DYNAMICS, INVERSE_DYNAMICS, ModelMode.WAM})`
2. The defaults directory contains `defaults/wam/` and no `defaults/policy/`
3. Shipped inputs `inputs/omni/action_policy_av.json` and `action_policy_robot.json`
   both contain `"model_mode": "wam"` — only the *filenames* still say policy

`docs/inference.md`, `docs/faq.md` and the action cookbook README all still say
`policy`. **Trust the enum, not the prose.**

> If you verify this yourself, fetch `raw.githubusercontent.com/.../refs/heads/main/...`
> rather than `.../main/...` — the latter serves a stale cached copy that still shows
> `POLICY = "policy"`. This is a real trap and it cost time to find.

### Transfer is not a model mode

Video-to-video transfer runs as `model_mode: "video2video"` **plus a control-hint
block** in the spec. `TransferHintKey` defines exactly four:

| Hint | Preserves | Good for |
|---|---|---|
| `edge` | shape, layout, fine detail | material and texture changes |
| `blur` | colour, lighting, overall look | subtle appearance edits |
| `depth` | 3D structure, spatial scale | relighting, surface changes |
| `seg` | object and region identity | replacing objects or backgrounds |

The cookbook ships a fifth asset family, `wsm` (world scenario map), which uses the
same mechanism but is not a member of the enum. Multi-control is supported through
weighted attention aggregation (`TransferArgs.weight`), but the cookbook's
`assets/multi_control/` directory is referenced in its README and **does not exist**
in the checkout.

### Per-tier mode support
- **Nano** — all modes
- **Super** — `text2image`, `text2video`, `image2video` only
- **Edge** — no audio, no transfer; 256p/480p, 12–30 FPS, 50–150 frames

---

## 3. Cosmos Framework

| Item | Value |
|---|---|
| Repo | `https://github.com/NVIDIA/cosmos-framework` (**not** `nvidia-cosmos/…`) |
| Version | `1.2.2` in `pyproject.toml` |
| Git tags / releases | **None.** "v1.2.2" exists only as the packaged version on `main` |
| Python | `>=3.10` |
| CUDA | `>=12.8`; **13.0 recommended** |
| Install | `uv sync --all-extras --group=cu130-train` (or `cu128-train`) |
| uv | `>=0.11.3` |
| Base image | `nvcr.io/nvidia/pytorch:25.09-py3` (CUDA 13) · `25.06-py3` (CUDA 12.8) |
| Platform | Linux x86-64 or aarch64, glibc ≥ 2.35 |

**H100 is explicitly supported.** setup.md: *"Ampere (RTX 30 Series, A100) or newer —
Hopper (H100) or Blackwell (B200) recommended for full training throughput."*

Attention backend is chosen per architecture: Blackwell → `natten`,
**Hopper → `flash-attn-3-nv`**, Ada/Ampere → `flash-attn`.

### Inference VRAM (NVIDIA figures, `docs/faq.md`)
| Model | VRAM |
|---|---|
| Cosmos3-Nano (8B active) | **32 GB** |
| Cosmos3-Super (32B active) | **128 GB** |

Edge is not listed; ~12 GB is a working figure to be measured in Lesson 06, not quoted.

### Disk
~150 GiB free recommended for a first full run: ~90 GiB HF cache, ~20 GiB uv cache,
~30 GiB outputs.

### Known conflict
The `vllm` dependency group (`vllm==0.19.1`) **conflicts** with all `cu*` groups.
You cannot have the framework training env and a vLLM server in one venv.

---

## 4. Cosmos 3 Reasoner NIM

| Item | Value |
|---|---|
| Image | `nvcr.io/nim/nvidia/cosmos3-reasoner` |
| Latest tag | **`1.7`** (updated 2026-05-30) |
| Compressed size | 8.28 GB |
| NGC API key | **Required** — subscription (free NVIDIA Developer Program tier is enough) |
| Served model names | `nvidia/cosmos3-nano-reasoner`, `nvidia/cosmos3-super-reasoner` |
| Selection | `NIM_MODEL_SIZE=nano` or `super` |
| Multi-node | No |

### H100 80GB support — both profiles

**Nano (8B) reasoner**

| GPU | Mem | Precision | GPUs | Disk |
|---|---|---|---|---|
| Any | > 56 GB | BF16 | 1 | 30 GB |
| **H100 SXM / PCIe** | **80** | **FP8** | **1** | **20 GB** |
| L40S | 48 | FP8 | 1 | 20 GB |
| H200 / GH200 | 141 | FP8 | 1 | 20 GB |

**Super (32B) reasoner**

| GPU | Mem | Precision | GPUs | Disk |
|---|---|---|---|---|
| **H100 SXM / PCIe** | **80** | **FP8** | **1** | **40 GB** |
| H100 SXM / PCIe | 80 | BF16 | 2 | 70 GB |

So on one H100 you *can* serve the 32B reasoner at FP8. The thing that does not
fit on one H100 is Super **generation**, not Super reasoning.

Minimum compute capability 7.0; 8.0 for BF16, 8.9 for FP8.

### Serving the reasoner without a NIM

There is **no separate reasoner checkpoint on Hugging Face**. You serve the same
omni checkpoint and select the reasoner tower.

1. **vLLM** with the `vllm-cosmos3` plugin:
   ```bash
   vllm serve nvidia/Cosmos3-Nano \
     --hf-overrides '{"architectures":["Cosmos3ReasonerForConditionalGeneration"]}' \
     --tensor-parallel-size 1 --mm-encoder-tp-mode data --async-scheduling \
     --media-io-kwargs '{"video":{"num_frames":-1}}' --port 8000
   ```
2. **Transformers** — `Cosmos3OmniForConditionalGeneration.from_pretrained(...)` loads
   only the reasoner tower and drops generator, audio and action parameters.
3. **Cosmos Framework** — `model_mode: "reasoner"`.

### Separately: the Generator NIM
`nvcr.io/nim/nvidia/cosmos3-generator`, `NIM_MODEL_SIZE=nano|super`,
`NIM_PRECISION=bf16|fp8|nvfp4`, Hopper+ only (CC ≥ 9.0). Per-device VRAM floor for
nano is **≥79 GiB** at any precision — i.e. it will occupy essentially your whole
H100. This course uses the framework for generation instead, and says why.

---

## 5. Post-training

### The honest headline
**NVIDIA documents no single-GPU training path.** Every shipped recipe assumes ≥8 GPUs.
The smallest documented claim is Edge *"also fits a 4-GPU node"*.

| Statement | Source |
|---|---|
| "Fine-tune … Tested on **8× H100 (80 GB)**" | `docs/training.md` |
| "shipped recipes … are **8-GPU configurations**" | repo README |
| LIBERO action recipes: **HSDP 2×8 = 16 GPUs, 2 nodes** | `docs/action_policy_libero_posttrain.md` |
| DROID reproduction: **256 ranks** (64× GB200 nodes) | cookbook |
| Edge vision recipe: *"at 2B it also fits a 4-GPU node"* | audiovisual cookbook |

### Entry point
```bash
IMAGINAIRE_OUTPUT_ROOT=outputs/train PYTHONPATH=. \
torchrun --nproc_per_node=8 -m cosmos_framework.scripts.train \
    --sft-toml=examples/toml/sft_config/vision_sft_edge.toml
```
`NPROC_PER_NODE` is a plain env override in `examples/_sft_launcher_common.sh`.
Configs are **TOML**, validated by `SFTExperimentConfig` with `extra="forbid"`.

### Why Nano full SFT cannot work on one H100
Full-parameter SFT of the 16B checkpoint, with the shipped settings:

| Component | Size |
|---|---:|
| bf16 params (16B × 2 B) | 32 GB |
| fp32 master weights (16B × 4 B) | 64 GB |
| AdamW `m` + `v` (16B × 8 B) | 128 GB |
| gradients | 32–64 GB |
| EMA fp32 copy (`ema.enabled` defaults **true**) | +64 GB |
| **Total before a single activation byte** | **≈256–350 GB** |

That is 3–4× an H100. Activation checkpointing does not help, because the blocker is
optimizer state, not activations. This is exactly why the shipped recipe is HSDP 2×8:
≈256 GB ÷ 16 ranks ≈ 16 GB per rank.

### What *can* plausibly run on one H100
`vision_sft_edge` — Edge (4B), generation pathway only via
`optimizer.keys_to_select = ["moe_gen","time_embedder","vae2llm","llm2vae","k_norm_und_for_gen"]`,
so ~2B trainable:

| Component | Size |
|---|---:|
| bf16 params (all 4B resident) | 8 GB |
| fp32 master (~2B trainable) | 8 GB |
| AdamW m+v (~2B) | 16 GB |
| gradients | 4–8 GB |
| EMA copy (must be disabled) | +8 GB |
| **State subtotal** | **≈45–50 GB** |

leaving ~30 GB for activations — provided you cut `max_num_tokens_after_packing`
from its 8-GPU value of 45,056 and turn off `torch.compile`.

**This is undocumented and must be empirically validated.** The course treats it as an
experiment with a predicted outcome, not a promise.

### Levers, and which ones help a single-GPU user
The FAQ's OOM ladder: (1) `PYTORCH_ALLOC_CONF=expandable_segments:True`,
(2) activation checkpointing `full`, (3) raise FSDP shard degree, (4) raise
context-parallel degree, (5) lower `max_samples_per_batch`, (6) enable LoRA.
**Levers 3 and 4 require more GPUs.** Only 1, 2, 5 and 6 are available to you.

### LoRA
First-class but **VFM (generator) only** — explicitly skipped on the VLM/reasoner path.
`model.lora_enabled`, `lora_rank` (default 16), `lora_alpha` (default 32),
`lora_target_modules` (default `q_proj_moe_gen,k_proj_moe_gen,v_proj_moe_gen,o_proj_moe_gen`).
Pair with `optimizer.keys_to_select=["lora_"]`.

### Not available
No 8-bit optimizer. **No CPU offload of any kind** for training — no parameter,
optimizer-state or activation offload exists in `SFTExperimentConfig`.
Only AdamW (fused).

### Datasets
| Dataset | Size | Episodes | Verdict |
|---|---:|---:|---|
| `nvidia/BridgeData2-Subset-Synthetic-Captions` | **0.65 GB** | 1,222 clips | **best lab choice** |
| `nvidia/LIBERO_LeRobot_v3` (`libero_10`) | ~0.5 GB | 379 | good for action work |
| `nvidia/LIBERO_LeRobot_v3` (all suites) | 4.5 GB | 5,614 | fine to download whole |
| `nvidia/Cosmos3-DROID` | **707 GB** | 57,639 | disqualifying for a lab |

Action data is **LeRobotDataset v3.0** (not v2): chunked Parquet + AV1 MP4 shards +
`meta/info.json`, `meta/stats.json`, `meta/tasks.parquet`, `meta/episodes/`.

Generator data is a simple JSONL — schema in `docs/dataset_jsonl.md`. Silent loader
filters worth knowing: clips longer than 61 s are dropped, and windows shorter than
61 frames are dropped.

### Action dimensionality by domain
From `EMBODIMENT_TO_RAW_ACTION_DIM` in `domain_utils.py` — verified against upstream
`main`. Getting `domain_name` wrong produces well-formed, meaningless actions and a
clean exit, so this table is a debugging asset:

| `domain_name` | raw action dim |
|---|---:|
| `av`, `camera_pose` | 9 |
| `bridge_orig_lerobot`, `droid_lerobot`, `umi` | 10 |
| `agibotworld` | 29 |

### Pose utilities — the module moved
The source DLI notebook imports `cosmos_framework.data.vfm.action.pose_utils`.
Upstream it is now `cosmos_framework.data.generator.action.utils.pose_utils`.
Probe for both rather than hard-coding either.

`pose_rel_to_abs` semantics, read from the source: `backward_framewise` means
`D_i = T_i⁻¹ T_{i+1}` and so `T_{i+1} = T_i D_i`. Translation is **divided** by
`translation_scale`. `rot6d` is the first two **columns** of the rotation matrix, and
decoding uses cross-product plus an **SVD projection onto SO(3)** — not the textbook
Gram–Schmidt you may expect. On clean input the two agree to ~1e-16; on skewed input
they differ materially.

### Closed-loop eval: the four parity gotchas
From `docs/action_policy_libero_posttrain.md`, "Eval parity". Every one of these is
train/serve skew, and each will silently degrade a policy that evaluated fine:

1. Camera concat layout must be `--camera agentview,wrist --image_size 256`.
2. Gripper sign is flipped between sim and training: apply `1 − 2·g`.
3. Simulator frames are rotated 180° relative to training frames.
4. `--action-normalization quantile_rot` is mandatory, or actions come out at the
   wrong scale.

Also: **the base DCP checkpoint has no action heads.** Only a post-trained checkpoint
can be served by the policy server — which is the practical argument for Module 5.

### Policy server HTTP contract
`action_policy_server_libero.py` — `POST /predict`, `/`, or `/predict_batch`; 415 on
non-JSON; 404 otherwise; `/predict_batch` returns `actions` (plural). Note that
**inference errors return HTTP 200 with an empty action list** by default, so a
200 is not proof of success. `action_policy_server_robolab.py` is a **WebSocket**
server with an HTTP `/healthz` endpoint — a hand-made JSON inference request works
against the LIBERO server only.

### Evaluation
`cosmos_framework/evaluation/` is listed in `docs/code_structure.md` as
**`[planned]` — not present in this release.** There is no offline metric harness,
no action-MSE script, no validation-loss loop. What exists is closed-loop simulation
eval (LIBERO via `action_policy_server_libero` + `closed_loop_eval.py`, DROID via
RoboLab), which needs a **separate venv** — `robosuite==1.4.1`, `mujoco==2.3.7`,
`torch<2.6` will not coexist with the training environment.

---

## 6. Cookbook assets

Repo: `https://github.com/NVIDIA/cosmos`, path `cookbooks/cosmos3/`.

**`reasoner/assets/`** (flat) — images `robot_153.jpg`, `robot_planning.png`,
`grounding_2d.png`, `describe_anything.png`, `action_cot_trajectory.png`; videos
`video_caption.mp4`, `robotics_next_action.mp4`, `drive_scene_next_action.mp4`,
`assisted_task_next_action.mp4`, `common_sense_reasoning.mp4`,
`action_cot_driving_scene.mp4`, `physical_plausibility.mp4`,
`situation_understanding.mp4`, `temporal_localization_{1,2}.mp4`

**`generator/audiovisual/assets/`**
```
prompts/text2image/robot_draping.json
prompts/text2video/{robot_kitchen,robot_pouring_water_audio}.json
prompts/image2video/{car_driving,car_driving_edge,coastal_road_audio}.json
negative_prompts/{text2video,image2video}/neg_prompt.json    (none for text2image)
images/image2video/{car_driving.jpg,coastal_road_audio.jpg,humanoid_robot.jpg}
videos/car_driving_plain.mp4
```

**`generator/transfer/`**
```
assets/negative_prompt.json                      (shared)
assets/{edge,blur,depth,seg}/control_*.mp4 + prompt.json   121 frames @ 30 FPS
assets/wsm/control_wsm.mp4 + prompt.json                   101 frames @ 10 FPS
specs/{edge,blur,depth,seg,wsm}.json
```

**`generator/action/assets/`**
```
actions/{av_traj_forward,av_traj_left,av_traj_right,camera_action,umi}.json
images/{av_0.jpg,lighthouse_720.png,solar_720.png,mountain_720.png,umi.png}
prompts/{lighthouse,solar,mountain}.txt
videos/{av_0.mp4,av_1.mp4}
```
Plus LeRobot episode directories: `droid_lerobot_example/`, `bridge_lerobot_example/`,
`human_hand_pose_lerobot_example/`, `agibotworld_beta_lerobot_example/`,
`robomind_lerobot_example/{franka,franka_dual,ur}`, `umi_lerobot_example/`,
`fractal_lerobot_example/`

---

## 7. Known-stale upstream documentation

Do not trust these without checking the code:

| Document | What it gets wrong |
|---|---|
| `cosmos-framework/docs/inference.md` | documents a `policy` mode that no longer exists; omits `image2image`, `audio_image2video`, `reasoner` |
| `cosmos-framework/docs/faq.md` | references `defaults/.../policy/sample_args.json` |
| cookbook `action/README.md` | still says "Policy (`policy`)" |
| cookbook `audiovisual/README.md` | backend table says "Transformers (coming soon)" while `reasoner/README.md` fully documents it |
| cookbook `action/finetune/README.md` | names `*_repro.toml` and non-`_nano` scripts that 404 |
| cookbook `transfer/README.md` | references `assets/multi_control/`, which does not exist |
| `raw.githubusercontent.com/.../main/...` | serves stale cached files — use `.../refs/heads/main/...` |

Guardrail naming is also split: the cookbook points at `nvidia/Cosmos-1.0-Guardrail`
while the framework uses `nvidia/Cosmos-Guardrail1`. Both exist, both are gated.

---

## 8. Source URLs

- https://huggingface.co/api/models?author=nvidia&search=Cosmos3
- https://huggingface.co/nvidia/Cosmos3-Edge · [Nano](https://huggingface.co/nvidia/Cosmos3-Nano) · [Super](https://huggingface.co/nvidia/Cosmos3-Super)
- https://huggingface.co/blog/nvidia/cosmos-3-for-physical-ai
- https://github.com/NVIDIA/cosmos-framework — `pyproject.toml`, `docs/setup.md`, `docs/inference.md`, `docs/faq.md`, `docs/training.md`, `docs/sft_config.md`, `docs/dataset_jsonl.md`, `docs/code_structure.md`, `docs/action_policy_libero_posttrain.md`, `cosmos_framework/inference/args.py`
- https://github.com/NVIDIA/cosmos/tree/main/cookbooks/cosmos3
- https://docs.nvidia.com/cosmos/latest/cosmos3/model_reference.html
- https://docs.nvidia.com/nim/vision-language-models/1.7.0/support-matrix.html
- https://docs.nvidia.com/nim/cosmos/latest/support-matrix.html
- https://catalog.ngc.nvidia.com/orgs/nim/teams/nvidia/containers/cosmos3-reasoner
- https://huggingface.co/datasets/nvidia/LIBERO_LeRobot_v3 · [Cosmos3-DROID](https://huggingface.co/datasets/nvidia/Cosmos3-DROID) · [BridgeData2 subset](https://huggingface.co/datasets/nvidia/BridgeData2-Subset-Synthetic-Captions)
