# Capstone rubric — synthetic data flywheel

Lesson 19, `19_capstone_synthetic_data_flywheel.ipynb`.

This rubric is the specification. Read it **before** you start building, not
after — every row describes something you have to design in, and three of the six
cannot be retrofitted once the run is over.

## How this is scored

Six criteria, weighted. Each is scored on four levels; the level is decided by the
**lowest** descriptor you fully satisfy, not the highest one you partly satisfy.
Points are `weight × level_value` where the level values are:

| Level | Value | Meaning |
|---|---:|---|
| Incomplete | 0.00 | Absent, or present but wrong in a way that invalidates it |
| Adequate | 0.60 | It is there and it is honest. A working baseline. |
| Good | 0.80 | Done properly. This is the target. |
| Excellent | 1.00 | Done properly *and* it taught the reader something |

| # | Criterion | Weight |
|---|---|---:|
| 1 | Pipeline correctness | 20% |
| 2 | Quality of the design justifications | 20% |
| 3 | Measurement rigour | 20% |
| 4 | Failure handling | 15% |
| 5 | Honesty of the evaluation | 15% |
| 6 | The report | 10% |

### What "done" means

**You have passed when all four of these hold:**

1. **Every criterion is at Adequate or above, and the weighted total is ≥ 0.70.**
   A zero on any single criterion is a fail regardless of the total. There is no
   trading measurement rigour against a nicer report.
2. **The three hard gates below are green.**
3. **The pipeline ran end to end unattended**, in reduced mode at minimum, and
   all seven checks — `check_stage_0()` through `check_stage_6()` — pass in a
   fresh kernel. Seven checks over six stages: `check_stage_0()` covers the
   source material and the ledgers, which nobody implements and which is wrong
   more often than any stage that does get implemented.
4. **The report exists at `outputs/capstone/REPORT.md`** with all eight sections
   (`## 0.` through `## 7.`), and every `[FILL]` replaced by a number traceable
   to `metrics.json`.

**The three hard gates.** These are pass/fail and they are not negotiable,
because each of them is the thing this course exists to teach.

| Gate | How it is checked |
|---|---|
| **G1 — Nothing is asserted that was not measured** | Every performance figure in the report appears in `outputs/capstone/metrics.json` or `measurements.jsonl`. A number in the prose that is in neither is a fail. |
| **G2 — Outputs were verified, not assumed** | Every manifest record has a `checks` field produced by `cc.verify_result` / `cc.check_video`. A record whose only evidence is an exit code is a fail. |
| **G3 — Completed work survives a crash** | Killing the kernel mid-run and re-running loses at most the item in flight. Demonstrated, with the ledger as evidence. |

Running successfully is **not** sufficient. A pipeline that produced twenty clips
with no measurement, no accept/reject reasoning and no limitations section scores
below one that produced four with all three.

---

## 1. Pipeline correctness — 20%

*Does the thing do what the interface says it does, and does the data actually
flow from stage to stage?*

| Incomplete | Adequate | Good | Excellent |
|---|---|---|---|
| A stage is missing, or a `check_stage_N()` fails. Stages do not share data — the generation prompts are hand-written rather than derived from the scene records. Output files exist but no manifest, or the manifest does not correspond to the files on disk. | All six stages implemented and all seven checks (`check_stage_0()`…`check_stage_6()`) pass. Reduced mode completes end to end on at least 3 source clips and 8 attempted variants. `manifest.jsonl` has one record per attempted variant with every required field populated. Prompts are derived from the reasoner's scene records, not typed by hand. | As Adequate, plus: the manifest is **traceable** — from any generated file you can reach the source clip, the exact spec, the seed and the judge's reason, and back again. Specs pass `cc.validate_spec(strict=True)` before any GPU time is spent. Batching is used deliberately, with the batch size justified. A second run with the same seeds reproduces the same manifest keys. | As Good, plus: the pipeline runs unattended from one cell with no manual intervention, resumes correctly from any interruption point, and the reduced/full switch changes only the config cell. The learner found and fixed at least one real defect in their own interface contract, and says what it was and how the check caught it. |

**Observable evidence.** `check_stage_0()`…`check_stage_6()` output; the manifest;
`ls outputs/capstone/generated/`; a re-run from a killed kernel.

---

## 2. Quality of the design justifications — 20%

*The four decisions are the intellectual content of the capstone. This criterion
is about the reasoning, not the choice — there is no correct answer to any of the
four, and picking the "obvious" option with a real argument beats picking the
clever one without.*

| Incomplete | Adequate | Good | Excellent |
|---|---|---|---|
| Fewer than four decisions recorded, or a "justification" that restates the choice ("I used image2video because it generates video from an image"). No alternative considered. The diversity criterion is not defined, or is defined but never computed. | All four decisions recorded in writing, each with a reason that refers to a property of the problem or the model. The diversity criterion is stated **and computed** over the accepted set. The accept/reject threshold is a stated number, not "it looked right". | As Adequate, plus each decision names the **specific alternative rejected and why**, referring to something checkable (a mode's documented behaviour, a measured cost, what a control hint preserves per COSMOS3_FACTS.md §2). The accept/reject section is argued explicitly as a precision/recall tradeoff, naming which error the learner chose to make and why that is the right error for a robotics training set. | As Good, plus each decision names **what would change it** — an observation that would flip the choice — and at least one decision is supported by a small experiment the learner ran (a two-way comparison, a threshold sweep, a spot-check disagreement rate). The diversity criterion comes with its own failure mode: how a degenerate generator could score well on it. |

**Observable evidence.** The `DECISIONS` dict in the notebook (`check_decisions()`
enforces length and non-placeholder text, but not quality); §2 of the report.

**Note on `check_decisions()`.** It verifies that you wrote something substantial
in each slot. It cannot tell whether the argument is any good. Passing it earns
Adequate at most.

---

## 3. Measurement rigour — 20%

*Can a hostile reader reconstruct every number you report, and would they get the
same one?*

| Incomplete | Adequate | Good | Excellent |
|---|---|---|---|
| No profiling, or timings taken without `torch.cuda.synchronize()` / without accounting for the generator being a subprocess. VRAM read only from this kernel's allocator, so the subprocess and the container appear to use nothing. A performance number appears in the report that is not in `metrics.json`. Cost per accepted clip not computed. | `metrics.json` contains per-stage wall clock, peak device VRAM, acceptance rate and cost per accepted clip. VRAM is sampled device-wide (`cc.DeviceSampler`), not from `torch.cuda.max_memory_allocated()`. A prediction was made before the run and a measurement after, and both appear. | As Adequate, plus: stage attribution accounts for the wall clock, with unaccounted time reported rather than hidden. **NIM/generator switching is measured separately** and reported as a fraction. The predicted and measured cost per accepted clip are **reconciled** — the dominant term in the discrepancy is named with a number. A bottleneck is identified from the numbers, not from intuition. | As Good, plus: the prediction is decomposed (fixed launch overhead vs. per-unit compute vs. acceptance rate) and the learner says which term their Lesson 06 calibration models badly and why. Measurement uncertainty is acknowledged — a repeat, a spread, or an explicit statement that n=1 and what that costs. At least one number is challenged and re-measured. |

**Observable evidence.** `metrics.json`; `measurements.jsonl`; §3 of the report.

**Automatic fail for this criterion.** Any performance claim in the report that
cannot be traced to a file in `outputs/capstone/`. This is gate G1.

---

## 4. Failure handling — 15%

*The pipeline must survive four specific failures without losing completed work.
This is graded, not optional.*

| Incomplete | Adequate | Good | Excellent |
|---|---|---|---|
| Any of the four failures kills the run. No checkpointing — an interruption at 80% costs the whole run. Failures and rejections are recorded in the same bucket, so "12 didn't work" cannot be decomposed. Exceptions swallowed with a bare `except: pass`, losing the reason. | All four failures (rejected clip, OOM, dead NIM, malformed model response) are survived: the pipeline records what happened and continues. A ledger provides resume. **Rejections and failures are separate categories** in the manifest. Every failure record carries its reason text. | As Adequate, plus: failures are **classified** (`cc.classify_error`) and the class drives the response — a `service` failure restarts the NIM and retries, an `oom` shrinks or abandons rather than retrying unchanged, a `malformed` response is retried once with a stricter prompt. Resume was demonstrated by an actual kill, and the loss measured. The debugging lab's four scenarios all produce the classification the learner predicted. | As Good, plus: the learner induced a failure the notebook did not supply, from their own run, and handled it. Retry policy is defended — including the case for *not* retrying — and the cost of the retry policy appears in the time budget. The pipeline distinguishes "this item failed" from "the pipeline is broken" and stops in the second case rather than grinding through 40 identical failures. |

**Observable evidence.** The debugging lab cells; `manifest.jsonl` status
distribution; the ledger before and after a kill; §3.5 of the report.

---

## 5. Honesty of the evaluation — 15%

*What you are willing to claim, and what you refuse to.*

| Incomplete | Adequate | Good | Excellent |
|---|---|---|---|
| Claims the synthetic data is "good", "diverse" or "useful" with no measurement behind it. No limitations section, or one that lists only generic risks. Failures excluded from the counts so the yield looks better. States or implies that the data would improve a downstream model, having trained nothing. | A limitations section exists with at least three specific items. Failure and rejection counts are reported alongside successes. The learner states plainly that producing screened clips is not evidence of downstream benefit. Judge circularity is at least named. | As Adequate, plus: a "what this does not show" section with four or more items, each specific to this run. The learner **spot-checked the judge against their own eyes** and reports the disagreement rate in both directions (accepted-but-wrong and rejected-but-fine). Judge circularity is explained mechanically — two towers of one checkpoint — and a mitigation is proposed. Threats to validity say how each would be tested. | As Good, plus: the learner reports a result that is inconvenient for their own design and does not hedge it — a criterion that did not work, a threshold that was wrong, a diversity axis the model ignored. Sample size is quantified: what effect could this run even have detected? A negative or null finding is stated as a headline rather than a footnote. |

**Observable evidence.** §4 and §5 of the report; the spot-check table in §2.3.

---

## 6. The report — 10%

*Could a colleague act on this without asking you anything?*

| Incomplete | Adequate | Good | Excellent |
|---|---|---|---|
| Missing sections. `[FILL]` placeholders left in. Numbers in the prose that contradict `metrics.json`. No reproduction instructions. Marketing adjectives in place of evidence. | All eight sections present, all placeholders replaced, numbers consistent with `metrics.json`. Method is specific enough that someone could rebuild the pipeline. Next steps are concrete. | As Adequate, plus: tables carry units and sample sizes. Each next step has a **cost** and the **question it would settle**. The reproduction section actually reproduces — paths, versions, seeds, commands. Written for a reader who was not there. | As Good, plus: the report makes a **recommendation** — build on this, change the design, or stop — and justifies it from the learner's own numbers, including the cost of being wrong. A skeptical reader is given what they need to check the central claim themselves. |

**Observable evidence.** `outputs/capstone/REPORT.md` against
`assets/reference/CAPSTONE_REPORT_TEMPLATE.md`.

---

## Tier mapping

The notebook's three graded tiers map onto this rubric as follows. You can stop
at any tier; the rubric ceiling rises with the tier.

| Tier | What it is | Rubric ceiling |
|---|---|---|
| **Foundation** | The reduced pipeline running end to end on **one** source clip, `check_stage_0()`…`check_stage_4()` passing — five of the seven. The last two have nothing to look at until there is a measured run and a report. | Adequate on 1 and 4. Not scored on 2, 3, 5, 6. Not a pass on its own. |
| **Applied** | The full reduced run — 3 sources, ~8 variants — with a defended accept/reject policy, complete measurement, and the report. | All six criteria available. **This is the pass condition.** |
| **Challenge** | An extension with an evaluated hypothesis: the Lesson 17 checkpoint in the generate stage, or a second control modality, with a measured effect and an honest verdict. | Excellent available on 2, 3 and 5. Required for a top score. |

A Challenge attempt that produces a **null result**, properly measured and
honestly reported, scores higher than an Applied run with a vague positive claim.
That is deliberate. Lesson 18 argued it; this is where it is worth marks.

---

## Common ways to lose marks

Ranked by how often they happen, from watching people do this.

1. **A number in the prose that is in no file.** Gate G1. It is almost always
   remembered from an earlier cell that has since been re-run.
2. **Merging failures into rejections.** "9 of 20 didn't work" hides whether the
   policy is strict or the pipeline is broken. They are different problems.
3. **No spot-check of the judge.** The whole accept/reject stage rests on the
   judge, and it is the one component that was never itself validated.
4. **VRAM read from the wrong place.** `torch.cuda.max_memory_allocated()` in the
   notebook kernel reports roughly nothing, because the generator is a subprocess
   and the reasoner is a container. It looks like a suspiciously good result.
5. **The prediction written after the run.** If the predicted cost matches the
   measured one to within 5%, a reader will assume this, and they are usually
   right. Commit the prediction to the ledger *before* you run.
6. **A limitations section made of generic risks.** "Small sample size, further
   work needed" applies to every project ever written and therefore says nothing.
7. **Excellent-sounding adjectives.** "Diverse", "high-quality", "realistic". If
   the word is not attached to a computed number it is costing you marks.
8. **Deleting a template section instead of answering it with "not done".**

---

## Self-assessment checklist

Run through this before you submit. Ten minutes, and it moves most people up a
level on at least two criteria.

### Pipeline
- [ ] `check_stage_0()` … `check_stage_6()` — all seven — pass **in a fresh
      kernel, top to bottom**.
- [ ] `manifest.jsonl` has exactly one line per attempted variant, no duplicates.
- [ ] Every manifest record has: `variant_id`, `source_clip`, `axis`, `modality`,
      `prompt`, `spec`, `seed`, `status`, `reason`, `checks`.
- [ ] From a random generated file I can find its source clip and its prompt in
      under thirty seconds.
- [ ] The prompts came from the scene records. None was typed by hand.
- [ ] Every spec passed `cc.validate_spec` before it cost me GPU time.

### Decisions
- [ ] Four decisions written, each naming the alternative I rejected.
- [ ] `check_decisions()` passes.
- [ ] My diversity criterion is computable, and I computed it.
- [ ] I can state, in one sentence, how a bad generator could game my criterion.
- [ ] My accept/reject threshold is a number, and I can say which error it favours.
- [ ] For each decision I have written what observation would change it.

### Measurement
- [ ] Every number in the report is in `metrics.json` or `measurements.jsonl`.
- [ ] I predicted the cost per accepted clip **before** running, and the
      prediction is timestamped in the ledger.
- [ ] I reconciled prediction against measurement and named the dominant error term.
- [ ] Peak VRAM came from `cc.DeviceSampler`, not from this kernel's allocator.
- [ ] Switching overhead is measured separately and reported as a fraction.
- [ ] Stage seconds plus unaccounted time equal the wall clock.
- [ ] I named a bottleneck and I can point at the number that identifies it.

### Failures
- [ ] All four injected failures were survived and correctly classified.
- [ ] I actually killed the kernel mid-run and measured what resume cost me.
- [ ] Failures and rejections are separate `status` values in the manifest.
- [ ] No bare `except: pass` anywhere in my pipeline.
- [ ] An OOM does not trigger an identical retry.

### Honesty
- [ ] I watched at least five accepted clips and at least three rejected ones.
- [ ] The spot-check disagreement table is filled in, both directions.
- [ ] "What this does not show" has four or more items specific to my run.
- [ ] I have not claimed or implied downstream benefit that I did not measure.
- [ ] Judge circularity is named and explained mechanically.
- [ ] There is at least one thing in the report that is inconvenient for me.

### Report
- [ ] No `[FILL]` or `<…>` left anywhere.
- [ ] Every table has units.
- [ ] Each next step has a cost and a question it settles.
- [ ] A colleague could reproduce the run from §7 alone.
- [ ] I read it once looking only for adjectives, and deleted the ones with no
      number attached.

---

*Reference implementation: `solutions/19_capstone_reference.ipynb`. It is one
defensible set of answers, not the answers — read it after you have your own run,
and where it disagrees with you, work out which of you is right before assuming
it is the notebook.*
