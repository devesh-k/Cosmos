# Curriculum map — source `S-OV-57-V1` to the H100 course

Every one of the 92 cells in the four source notebooks is accounted for below as
**carried**, **restructured**, **corrected**, **expanded** or **excluded**. Cell indices
are zero-based, as `nbformat` stores them.

Disposition definitions, used consistently:

| Disposition | Meaning |
|---|---|
| **Carried** | Substance survives largely intact; paths and names updated |
| **Restructured** | Same content, different shape — split, merged, reordered, or moved into `cosmos_course` |
| **Corrected** | Content survives but was factually wrong and has been fixed; the correction is itself taught |
| **Expanded** | Content survives as the seed of something substantially larger |
| **Excluded** | Deliberately dropped, with a stated reason |

Summary across all 92 cells:

| Disposition | Cells | Share |
|---|---:|---:|
| Carried | 22 | 24 % |
| Restructured | 18 | 20 % |
| Corrected | 25 | 27 % |
| Expanded | 15 | 16 % |
| Excluded | 12 | 13 % |

Per notebook:

| Notebook | Cells | Carried | Restructured | Corrected | Expanded | Excluded |
|---|---:|---:|---:|---:|---:|---:|
| 01 token setup | 9 | 0 | 3 | 3 | 0 | 3 |
| 02 world reasoning | 32 | 11 | 4 | 6 | 8 | 3 |
| 03 world generation | 23 | 4 | 5 | 8 | 4 | 2 |
| 04 action generation | 28 | 7 | 6 | 8 | 3 | 4 |
| **Total** | **92** | **22** | **18** | **25** | **15** | **12** |

Two cells are marked "Restructured + Corrected" in the tables below (notebook 02 cell 09
and notebook 03 cell 07); both are counted as Restructured.

That 27 % correction rate is the headline finding of the audit. Just over a quarter of the
source course's cells contain something factually wrong, obsolete, or environment-specific
in a way that will not survive contact with a single H100.

### Verification status

Every row below that claims content landed somewhere has been checked with a grep against
the repository, and the distinctive string is quoted in the row wherever the claim was
previously wrong or is easy to doubt. Rows that say "**Correction to an earlier version of
this map**" were false and are now accurate; §1.6 lists the four cases where content was
genuinely lost rather than merely misfiled, and says what happened to each.

Two habits made the original errors possible and are worth naming, because they will
recur. First, **writing the map from the plan rather than from the artefact** — several
destinations record where content was *intended* to go, not where it went. Second,
**"carried" used as a synonym for "not deliberately dropped"**, which quietly converts an
omission into a claim. The rule this map now follows: if a row names a destination, a grep
for a distinctive string must find it there.

---

## 1. Forward map

### 1.1 `01_creating_huggingface_token.ipynb` — 9 cells

| Cell | Type | Source content | Destination | Disposition | What changed and why |
|---|---|---|---|---|---|
| 00 | md | NVIDIA header logos | — | **Excluded** | DLI branding SOP, enforced by `validate_notebooks.py`. This course is not a DLI deliverable and has its own header convention |
| 01 | md | "An Introduction to Cosmos 3"; omni-model framing; "prepares access to the gated Cosmos 3 model weights" | L01 | **Corrected** | The omni-model framing survives and is expanded into the MoT explanation the source never gave. The gating premise is wrong: all nine Cosmos3 repos return `gated: false` (FACTS §1) |
| 02 | md | "create a HuggingFace account, generate an access token, accept model license agreements for gated models" | L01, L09; `README.md`, `docker/.env.example` | **Restructured** | Split. The account-and-token *prerequisite* becomes documentation — `README.md`'s credentials table and the `HF_TOKEN=` line in `docker/.env.example` — not a lesson step. The single remaining licence click moves to Lesson 01 and is revisited in Lesson 09. **Correction to an earlier version of this map:** this does not land in `scripts/setup.sh` or Lesson 00. `setup.sh` handles the *NGC* credential (`docker login nvcr.io`) and never mentions `HF_TOKEN`; `grep -c HF_TOKEN scripts/setup.sh` → 0 |
| 03 | md | HF account signup, 4 screenshots | — | **Excluded** | Teaching web-form navigation with screenshots is not a use of classroom time, and screenshots of a third-party signup flow rot within months. One sentence and a link replaces it |
| 04 | md | Access-token generation, 4 screenshots | L01 | **Restructured** | Replaced by `cc.check_hf_access()`, which reports whether the token works rather than explaining how to obtain one. The probe is called in **Lesson 01** (the tier/gating cell), **Lesson 09** (the guardrail) and **Lesson 13**. It is not in Lesson 00: `grep -c check_hf_access 00_environment_check.ipynb` → 0 |
| 05 | md | Gated-model licence acceptance; five repo links; NVIDIA Open Model License; "policy" named as an action mode | L01, L09 | **Corrected** | Two independent errors. Only `nvidia/Cosmos-Guardrail1` is still gated (FACTS §1), so four of five links are unnecessary. The licence is **OpenMDW 1.1**, not the NVIDIA Open Model License. Both corrections are now *in the notebook*: Lesson 01's upstream callout names all three source errors, and the cell after it reads `cardData.license` from the Hugging Face API so the learner sees `openmdw1.1-license` rather than being told about it. The cell also names "policy" as one of the three action modes — see §1.4 |
| 06 | md | "To login to HuggingFace, replace `YOUR_TOKEN`…" | L01 | **Restructured** | **No login is performed anywhere in this course.** `check_hf_access` in Lesson 01 reads `HF_TOKEN` from the environment, sends it as a bearer header, and never prints, logs or returns it. The learner sets the variable; nothing in the course sets it for them |
| 07 | code | `!hf auth login --token "{getpass(...)}"` | L01 | **Corrected** | The token is interpolated into a shell command and lands in the `hf` process's argv, visible in `/proc`. Replaced by reading `HF_TOKEN` from the environment. **Correction to an earlier version of this map:** the setup script does not set it. It is documented in `docker/.env.example` (line 150) and in `README.md`'s troubleshooting table, and the learner exports it themselves |
| 08 | md | NVIDIA footer logos | — | **Excluded** | As cell 00 |

**Net:** notebook 01 contributes one paragraph and one licence click to the new course.
Its nine cells and eleven screenshots collapse into a prerequisite step. The genuine
residual lesson — that the guardrail is gated, is enabled by default, and 403s in the
middle of a multi-gigabyte download — becomes part of Lesson 09.

Verify: `grep -c check_hf_access` gives `3` in `01_cosmos3_mental_model.ipynb`, `5` in
`09_generation_audio_guardrail.ipynb`, `1` in `13_action_closed_loop.ipynb` and **`0`** in
`00_environment_check.ipynb`; `grep -c HF_TOKEN scripts/setup.sh` → **`0`**.

### 1.2 `02_world_reasoning.ipynb` — 32 cells

| Cell | Type | Source content | Destination | Disposition | What changed and why |
|---|---|---|---|---|---|
| 00 | md | Header | — | **Excluded** | DLI branding |
| 01 | md | Part 2 intro; omni-model; NIM framing; six-capability table | L01 (omni-model), L03 (table), L04, L05 | **Carried** | The capability table is the best piece of framing in the package. It is carried near-verbatim — the six names, both source columns unchanged — as the opener of **Lesson 03**, which is Module 1's first reasoning lesson, with a fourth column added naming the lesson that covers each capability. Lessons 04 and 05 restate the rows that belong to them and point back. The omni-model framing goes to Lesson 01 and is expanded there into the MoT explanation the source never gave |
| 02 | md | "How this notebook fits the pipeline" — perceive → reason → act | M1 intro, L19 | **Expanded** | The claim is carried; the source never builds it. Lesson 19 constructs the loop the cell describes |
| 03 | md | "## Setup" | — | **Excluded** | Section marker only |
| 04 | code | Imports; `ASSETS_DIR = /opt/cosmos/...`; `ASSETS_DIR_2 = /dli/task/assets`; nine-entry `ASSETS` dict; `openai` pip-install fallback | `cosmos_course/assets.py` | **Restructured** | The asset-name indirection is a good idea and is kept. Paths now resolve through `COSMOS_ROOT` with a repo-relative fallback. `toaster_6sec.mp4` came from a private DLI S3 bucket and is substituted with public cookbook clips (§ audit 4.10). The runtime pip-install is removed — dependencies belong in the setup script |
| 05 | md | NIM connection prose; Compose service DNS; base64 media transport | L02 | **Corrected** | The base64 transport explanation is carried. The Compose DNS premise is replaced with a locally started container on `127.0.0.1`, and the "launched alongside this lab" convenience is replaced with the learner starting it themselves |
| 06 | code | `NIM_BASE_URL = os.environ.get("NIM_BASE_URL", "http://cosmos3-reasoner:8000")` | L02 | **Corrected** | Default becomes `http://127.0.0.1:8000` via `NimConfig.base_url()` |
| 07 | code | Readiness polling on `/v1/health/ready` with a 1200 s cap; timeout message pointing at `docker compose logs` | `cosmos_course/nim.py:wait_for_nim`, L02 | **Corrected** | The polling pattern is right and is kept. The error message is unusable from inside the container (§ audit 4.9) and is replaced with `nim_status()`, which reports from four sources and prints the log tail directly |
| 08 | md | `run_inference` documentation; the fps / max_tokens / sampling knobs; the `<think>` convention; the AV1 warning | L03, L04 | **Expanded** | Split across two lessons, not three. `fps` becomes **Lesson 03**'s central cost lever with measurement (77 occurrences of `fps` in L03, 0 in L02); `<think>` becomes **Lesson 04**'s subject (15 occurrences, 0 in L02); and the codec note becomes a diagnosed HTTP 422 failure in **Lesson 03**. **Correction to an earlier version of this map:** none of this lands in Lesson 02. `02_serving_the_reasoner.ipynb` has 0 occurrences of `ensure_h264`, `AV1`, `codec` and `422`; `03_reasoning_captioning.ipynb` has 9, 11, 10 and 11. The content survives intact — only the stated destination was wrong |
| 09 | code | 121 lines: `OpenAI` client, model-id resolution, `_video_codec`, `ensure_h264`, `_to_url`, `show_media`, `run_inference`, `display_video` | `cosmos_course/models.py:Reasoner`, `cosmos_course/viz.py`; taught in L02 (client, transport) and L03 (codec) | **Restructured + Corrected** | The most valuable code in the package. Becomes the `Reasoner` class with retry, streaming, `_explain_422()`, token accounting for Lesson 14, and `think()`. `ensure_h264` is carried almost verbatim into `cosmos_course/models.py` and is **taught in Lesson 03**, not Lesson 02 — it is used in L03, L09, L12 and L19. `display_video` here references `HTML` and `html`, neither imported anywhere in the notebook — a latent `NameError`, dead because it is never called (§ audit 4.6). It is deleted, and the defect becomes a worked example for `tools/nameflow_check.py` |
| 10 | md | Overlay-helper intro; 0–1000 normalised coordinates | L05 | **Carried** | The normalisation explanation is carried and extended with what breaks under resizing |
| 11 | code | `_parse_json`, `draw_boxes`, `draw_trajectory` | `cosmos_course/viz.py` | **Restructured** | Moves into the package. `_parse_json` becomes `parse_model_json` and is shared with `Reasoner.parse_json`, eliminating the duplicate parsing logic in notebook 04 |
| 12 | md | Video captioning intro; 4 FPS sampling; captions as pipeline records | L03 | **Expanded** | The "captions become the structured record" claim is the seed of Lesson 03's scene-record JSONL. **Lesson 07 genuinely consumes it** — `07_generation_conditioned.ipynb` reads `outputs/03/scene_records.jsonl` and falls back to a clearly-labelled canned record. **Lesson 19 does not read that file**; it runs the reasoner itself and writes its own `outputs/19/scenes.jsonl`, so the loop is built but the capstone is self-contained. An earlier version of this map said "Lessons 07 and 19 actually consume" it, which overstates the second half |
| 13 | code | `input_media = ASSETS["video_caption"]`; two commented-out URLs; `show_media` | L03 | **Carried** | Asset resolution now via `asset()`, and the clip is unchanged. **The commented-out remote URLs were dropped, not converted.** An earlier version of this map claimed they "become an explicit exercise in bringing your own footage" in Lesson 03; there is no such exercise. Lesson 03's three exercises are *Three clips, one schema*, *Caption to generation prompt* and *A batch captioner*. The nearest analogue anywhere in the course is Lesson 07's `MY_IMAGE` hook, which is a conditioning **image**, not a captioning clip. See §1.6 |
| 14 | code | `run_inference("Describe the video in detail.", fps=4)` | L03 | **Expanded** | One call becomes a three-rate fps comparison with token accounting, plus the free-text-to-schema conversion |
| 15 | md | Embodied reasoning intro; the `<think>` rationale | L04 | **Carried** | The auditability argument is carried and sharpened: chain of thought is evidence, not a correctness guarantee |
| 16 | md | "2a. Robotics next action" | L04 | **Carried** | — |
| 17 | code | Next-action prompt with `<think>`; `robotics_next_action.mp4` | L04 | **Expanded** | Becomes a with/without-`<think>` comparison so the learner can see whether reasoning changed the answer or only explained it |
| 18 | md | "2b. Robot planning" | L04 | **Carried** | — |
| 19 | code | Task-decomposition prompt; `robot_planning.png`; `seed=0` | L04 | **Expanded** | Adds an executability check on the returned ordering |
| 20 | md | "2c. Assisted-task next action" | L04 | **Carried** | — |
| 21 | code | Goal-plus-current-step prompt; `toaster_6sec.mp4` | L04 | **Corrected** | Asset substituted with the public `assisted_task_next_action.mp4` (§ audit 4.10). Adds an ablation — grep `planning_goal_ablation` in L04 — that holds the image fixed and varies the goal, then adds the current step, and tabulates how the answer's scope narrows |
| 22 | md | Common-sense reasoning intro | L04 | **Carried** | — |
| 23 | code | "Can the countertop support the weight of the toaster?"; `toaster_6sec.mp4` | L04 | **Corrected** | Asset substituted with `physical_plausibility.mp4` / `common_sense_reasoning.mp4`. Adds a probe whose correct answer is "no", because a screening filter that only ever confirms is not a filter |
| 24 | md | 2D grounding intro | L05 | **Carried** | — |
| 25 | code | Bounding-box request; `draw_boxes` | L05 | **Expanded** | Adds a deliberate grounding failure on an ambiguous referring expression |
| 26 | md | Describe Anything / Set-of-Mark explanation; "two robot arms, the person, the camera tripod, and the red ball" | L05 | **Corrected** | Prose promises five subjects; the code marks four, and the "red ball" is a "red apple" in the code comments (§ audit 4.11). Prose and code are reconciled, and the SAM-derived-masks aside is kept |
| 27 | code | 55 lines: hard-coded `MARKS` pixel boxes for a 1280×720 image; `mark_subjects`; the describe-anything prompt | `cosmos_course/viz.py:mark_subjects`, L05 | **Restructured** | `mark_subjects` moves into the package. Hard-coded boxes are replaced by marks derived from Lesson 05's own grounding output, which makes the section self-consistent and removes the image-size dependency |
| 28 | md | Action chain-of-thought intro; note on higher temperature | L05 | **Carried** | — |
| 29 | code | Trajectory prompt; `temperature=0.6, top_p=0.95, top_k=20, repetition_penalty=1.0`; `draw_trajectory` | L05 | **Expanded** | The one place the source varies sampling. Becomes a systematic sweep reporting both path smoothness and parse-failure rate |
| 30 | md | Wrap-up; three resource links | L02, L05 (M1 close) | **Carried** | All three links are retained, in two places. Lesson 02 carries them where they are useful *before* you start — `build.nvidia.com/nvidia/cosmos3-nano-reasoner` is named twice, once in the conceptual section as the zero-install way to answer "is it the model or is it my machine?", and once in a **Resources** list with the NGC container page and the reasoner cookbook subtree. Lesson 05 repeats the list as the Module 1 close, which is where the source cell sat. An earlier version of this map claimed the links were retained when in fact none of the three was anywhere in the course |
| 31 | md | Footer | — | **Excluded** | DLI branding |

### 1.3 `03_world_generation.ipynb` — 23 cells

| Cell | Type | Source content | Destination | Disposition | What changed and why |
|---|---|---|---|---|---|
| 00 | md | Header | — | **Excluded** | DLI branding |
| 01 | md | Part 3 intro; WFM framing; generation and augmentation; kernel-switch instruction | L06 | **Carried** | Framing carried. The kernel instruction becomes a real explanation of why generation runs in a separate venv and a separate process |
| 02 | md | "How this notebook fits the pipeline" | L19 | **Expanded** | The claim that Part 2's prompts drive Part 3 is never implemented in the source. Lesson 07 objective 5 and Lesson 19 implement it |
| 03 | md | Environment prose; `/opt/cosmos3-framework`; `CUDA_VISIBLE_DEVICES=1` rationale; two-GPU escape hatch | L02, L06 | **Corrected** | The two-GPU premise is the source's central portability defect (§ audit 4.4). Replaced by Lesson 02's take-turns / cap strategies, which are the actual single-GPU answer |
| 04 | code | `free_local_port`; `COSMOS_ROOT` default `/dli/task/cosmos`; `COSMOS3_REPO`; `CUDA_VISIBLE_DEVICES=1`; env export for `%%bash` | `cosmos_course/config.py`, `specs.py:build_inference_command` | **Corrected** | Every path resolves from `__file__` and environment variables. `free_local_port` is kept (as `Generator._free_port`) — it is the right fix for rendezvous collisions. The `/dli/task/cosmos` default is a leftover from the abandoned submodule layout and is dead *and* wrong |
| 05 | code | `torch` version and device-count print | L00 | **Restructured** | Absorbed into `probe_environment()`, which checks considerably more and never raises. Lesson 00 is the only lesson that calls it (Lesson 14 references it when discussing memory reporting). **Correction to an earlier version of this map:** it does not land in Lesson 06. Grepping `06_generation_fundamentals.ipynb` for `torch.__version__`, `device_count` and `probe_environment` returns nothing; Lesson 06 gets its device from the shared setup cell's `cc.select_device()` |
| 06 | md | Helper intro; "structured JSON prompt … rather than a single sentence" | L07 | **Expanded** | The single most useful sentence in the notebook, and the source never says *why* the model wants that shape. Lesson 07's section **"The structured prompt, against one sentence"** now builds the comparison: one intent stated in English, encoded as `SENTENCE_PROMPT` and `STRUCTURED_PROMPT`, generated at `COMPARISON_SEED = 0` on the same conditioning image with a cell that proves the two specs differ only in `name` and `prompt`. It is a predict–run–explain, and it separates the two questions the source's sentence conflates: whether the *output* differs (probably not much — there is no JSON parser in the text encoder) and whether the *prompt* is addressable (yes, and that is the whole argument). The addressability half runs with no GPU, so the logic stays visible when generation is off |
| 07 | code | 68 lines: `FIXED_SAMPLING`, `_compact`, `create_payload`, `display_video`, `view_run`, `view_t2v_prompt` | `cosmos_course/specs.py`, `viz.py` | **Restructured + Corrected** | `create_payload` hides resolution, frame count and step count behind a module constant while printing them back, which looks like control and is not (§ audit 4.8). Replaced by `InferenceSpec`, where the expensive fields are explicit constructor arguments, validated by `validate_spec()` and costed by `.cost()` before launch. `display_video` is replaced by the single `show_video` used course-wide. `enable_sound` is plumbed here and never set to `True` — Lesson 09 uses it |
| 08 | md | Text-to-video intro; "189-frame (~8 s) 720p video in 35 denoising steps"; "expect a few minutes"; the iterate-faster remark; the gating warning | L06 | **Corrected** | "A few minutes" is the only performance claim in the package and it has no measurement behind it. Lesson 06 has the learner measure it. The iterate-faster remark becomes a quantified cost curve. The gating warning is obsolete (FACTS §1) |
| 09 | code | `view_t2v_prompt`; `create_payload("t2v_robot_kitchen", "text2video", …)` | L06 | **Restructured** | Becomes a hand-built `InferenceSpec`, so the learner writes a spec before being given a helper |
| 10 | code | `%%bash` torchrun invocation, `--parallelism-preset=throughput` | `cosmos_course/models.py:Generator`, L06 | **Restructured** | The invocation is correct and is preserved inside `Generator._build_command`, which also captures output, streams progress, handles timeouts, and kills the process group. `--parallelism-preset` is explained in Lesson 15 rather than left as a mystery flag |
| 11 | code | `view_run(t2v_output)` | L06 | **Corrected** | Replaced with `verify_result()`. Looking at a video is not the same as checking it decoded, has frames, and is not a flat fill |
| 12 | md | Image-to-video intro | L07 | **Carried** | — |
| 13 | code | `create_payload("i2v_car_driving", "image2video", …, i2v_image_input)` | L07 | **Carried** | Same asset, explicit spec. The relative `vision_path` resolution is kept and explained |
| 14 | code | `%%bash` torchrun for i2v | L07 | **Restructured** | As cell 10 |
| 15 | code | `view_run(i2v_output)` | L07 | **Corrected** | As cell 11 |
| 16 | md | "## 4. Data augmentation"; the control table; "one of edge, blur, depth, segmentation, or world-scenario maps" | L08 | **Corrected** | Never names `video2video` — the word does not appear in any of the four notebooks (§ audit 4.3). Lists five controls where `TransferHintKey` has four; `wsm` uses the mechanism but is not a member (FACTS §2). Silent on tier support: Edge cannot do transfer at all. All three fixed, and the table itself is carried |
| 17 | code | Loads `specs/edge.json`; prints the prompt's first subject; previews `control_edge.mp4` | L08 | **Carried** | Spec inspection is a good pattern and is kept |
| 18 | md | "Transfer inference is selected automatically because the spec contains a control block"; "several minutes on one H100"; suggests trying depth or seg | L08 | **Expanded** | The mechanical statement is correct. Lesson 08 makes the suggestion mandatory — at least three hints on one source clip, with a written comparison — because the point of controls is the difference between them |
| 19 | code | `%%bash`, `cd "$TRANSFER_DIR"`, relative `-i specs/edge.json`, `--seed 2026` | L08 | **Corrected** | Only cell using a relative spec path and a different seed from the spec's own `"seed": 0`, with no statement of precedence. Normalised to absolute paths and one seed source |
| 20 | code | `view_run(OUTPUT_ROOT / "transfer_edge")` | L08 | **Corrected** | As cell 11 |
| 21 | md | Closing; suggests dramatic lighting shifts; three resource links | L08, L19 | **Expanded** | The augmentation suggestion becomes Lesson 08's designed augmentation pass and Lesson 19's pipeline |
| 22 | md | Footer | — | **Excluded** | DLI branding |

### 1.4 `04_action_generation.ipynb` — 28 cells

| Cell | Type | Source content | Destination | Disposition | What changed and why |
|---|---|---|---|---|---|
| 00 | md | Header | — | **Excluded** | DLI branding |
| 01 | md | Part 4 intro; "action as a modality"; the three-mode table naming **Policy** | M3 intro, L10, L12 | **Corrected** | The framing and the table are excellent and are carried. "Policy" is renamed `wam` throughout (FACTS §2) |
| 02 | md | "## 1. Environment" | — | **Excluded** | Section marker |
| 03 | code | Paths; `resolve_input`; `sys.path` insert; `CUDA_VISIBLE_DEVICES=1`; `COSMOS3_CHECKPOINT_PATH` | `cosmos_course/config.py`, `assets.py` | **Corrected** | As notebook 03 cell 04. The `sys.path.insert` hack for importing `cosmos_framework` from the wrong venv is replaced by running action visualisation in the framework kernel, where the import is real |
| 04 | code | `torch` device print | L00 | **Restructured** | Absorbed into `probe_environment()` |
| 05 | code | 32 lines: `preview()` — ffmpeg transcode to CRF 28, write under `/dli/task/assets/_previews`, serve via `/lab/files/…`; comment stating base64 embedding "yields a frame that won't play" | `cosmos_course/viz.py:show_video` | **Restructured** | The third incompatible preview helper in three notebooks, and its comment contradicts notebook 03's approach (§ audit 4.7). One `show_video` replaces all three: it always transcodes a small preview and says so. `/dli/task` and `/lab` hard-coding removed |
| 06 | md | Forward-dynamics intro; 9D pose deltas; three AV trajectories | L10 | **Carried** | — |
| 07 | code | `fd_record` with `action_chunk_size`, `action_path`, `domain_name`, `fps`, `image_size`, `view_point`, `model_mode`, `prompt`, `seed`, `vision_path`; written as JSONL | `cosmos_course/specs.py`, L10 | **Expanded** | The record schema is the most useful undocumented thing in the notebook. Every field gets an explanation in Lesson 10, and the learner authors a novel trajectory rather than running three shipped ones |
| 08 | md | "The first run downloads the `Cosmos3-Nano` weights (gated…)" | L10 | **Corrected** | Not gated (FACTS §1) |
| 09 | code | `%%bash` single-process launch with `MASTER_ADDR`/`RANK`/`WORLD_SIZE`/`LOCAL_RANK`; `--parallelism-preset=latency`; `--video-save-quality 8`; `--image_size 480` | `cosmos_course/models.py:Generator`, L10, L15 | **Restructured** | The single-process path is correct for action modes and is encoded in `ACTION_MODEL_MODES`, which selects the branch. The source never says why it differs from notebook 03's `torchrun` (§ audit 4.12). Lesson 10 explains it, Lesson 15 measures whether the preset matters at world size 1. **Two flags were dropped, and neither drop was stated before.** `--image_size 480` duplicates a value already in the record with unstated precedence. `--video-save-quality 8` is an undocumented encoder-quality integer with no stated scale and no effect on anything the course measures; `Generator._build_command` does not emit it, and the string appears nowhere in the course. See §1.6 |
| 10 | code | `preview(fd_output / "av_forward" / "vision.mp4")` | L10 | **Corrected** | Replaced with `verify_result()` plus `show_video` |
| 11 | md | Inverse-dynamics intro; "no `action_path`: the action is what the model predicts" | L11 | **Carried** | That sentence is the clearest explanation of the mode in the package |
| 12 | code | `id_record`; JSONL write; preview of the input clip | L11 | **Carried** | — |
| 13 | code | `%%bash` single-process launch for inverse dynamics | L11 | **Restructured** | As cell 09 |
| 14 | md | "stored under `outputs[0].content["action"]` as `[T-1, 9]` relative pose deltas" | L11, L12 | **Corrected** | The output location is carried. The `[T-1, 9]` shape is true for AV and false for manipulation, where it is 10-D — the source describes two layouts as one (§ audit 4.13). The correction is split across two lessons: **Lesson 11** carries `[T−1, 9]` but labels it, printing `(av is 9-D: 3 translation + 6 rotation)`; **Lesson 12** states the 10-D manipulation layout (7 occurrences of `10-D`) and contrasts it with the 9-D one explicitly. Lesson 11 alone does not mention the manipulation layout |
| 15 | code | 62 lines: `visualize_pose` with frustums and bird's-eye view; `pose_rel_to_abs(rotation_format="rot6d", pose_convention="backward_framewise", translation_scale=1.35)` | `cosmos_course/viz.py:plot_camera_trajectory`, L11 | **Expanded** | The plotting code moves into the package. The *mathematics* the source used without explaining becomes the substance of Lesson 11: why `rot6d`, what `[:, :3, 3]` and `[:, :3, 2]` are, what `backward_framewise` means, and where `translation_scale=1.35` comes from — a magic constant with no source, no units and no sensitivity discussion that affects every plotted number |
| 16 | md | "## 4. Policy mode"; "runs as a one-shot inference with `model_mode: policy`"; references a RoboLab rollout clip | L12 | **Corrected** | The mode is `wam` (FACTS §2). Lesson 12 has the learner reproduce the failure with the old name deliberately, so the error is familiar |
| 17 | code | `preview(robolab_example_rollout.mp4)` guarded by `if rollout.exists()` | — | **Excluded** | The asset is not in the cookbook's documented inventory (FACTS §6) and the guard means the cell silently prints "not found". Dead content; a real closed-loop discussion replaces it in Lesson 13 |
| 18 | md | "We drive `cosmos_framework.scripts.inference` with `model_mode: policy`"; describes the Bridge example; "this cell needs network access" | L12 | **Corrected** | Renamed to `wam`. The mid-lesson network fetch is replaced with a locally cached observation staged by `scripts/fetch_assets.py`, because a lesson that fails on a captive-portal network is a bad lesson |
| 19 | code | `policy_record` with `"model_mode": "policy"`; start observation from a pinned `github.com/nvidia-cosmos/cosmos-dependencies` raw URL | L12 | **Corrected** | **The single most important correction in the course.** `policy` was removed from `ModelMode`; the mode is `wam` (FACTS §2, three independent confirmations), and Lesson 12 reproduces the failure with the old name deliberately — `grep -c policy 12_action_wam.ipynb` → 57, including `model_mode": "policy"` in the debugging lab. The source's raw URL sits under the `nvidia-cosmos` org while the framework now lives under `NVIDIA/`; that org-rename fact is recorded in FACTS §3 and surfaces in Lesson 17, not in Lesson 12 — Lesson 12 simply stops fetching over the network and reads an observation staged by `scripts/fetch_assets.py` |
| 20 | code | `%%bash` single-process launch for policy | L12 | **Restructured** | As cell 09, with the corrected mode |
| 21 | md | "Policy predicts **both** outputs" | L12 | **Carried** | — |
| 22 | code | Preview the rollout; load `sample_outputs.json`; print action shape and first three steps | L12 | **Carried** | Output extraction carried; verification added |
| 23 | md | "per step: a 3D translation delta, a 6D rotation, and a gripper open/close value" | L12 | **Carried** | Correct for manipulation, and Lesson 12 contrasts it explicitly with the 9-D AV layout |
| 24 | code | 40 lines: integrate translation deltas into a 3D path; plot gripper channel; `gripper = action[:, 9] if action.shape[1] > 9 else None` | `cosmos_course/viz.py:plot_end_effector_path`, L12 | **Restructured** | The hedge in that conditional is the only hint in the source that two action layouts exist. Lesson 12 states both |
| 25 | md | Closed-loop RoboLab described as out-of-lab; names the policy server, `Cosmos3-Nano-Policy-DROID`, RoboLab, Isaac Sim 5.0, Isaac Lab 2.2.0, and `policies/cosmos3/run.py --task BananaInBowlTask` | L13 | **Expanded** | Five sentences become a lesson. The constraint that makes it hard is omitted from the source — `robosuite==1.4.1`, `mujoco==2.3.7` and `torch<2.6` will not coexist with the training environment, so it needs a second venv (FACTS §5). Lesson 13 has the learner build that venv and demonstrate the conflict. Of the components the source names, Lesson 13 carries the **policy server** (21 mentions), **`Cosmos3-Nano-Policy-DROID`** (4), **RoboLab** (9, now including the `NVlabs/RoboLab` URL), **Isaac Sim 5.0** and **Isaac Lab 2.2.0** (2 each) and **`policies/cosmos3/run.py`** (1). The one component **not** carried is the example task name `BananaInBowlTask`: it identifies a specific RoboLab task that this course never runs, and naming an unrunnable task would be decoration. See §1.6 |
| 26 | md | Wrap-up; four resource links | L12, L13 (M3 close) | **Carried** | All four links are retained. Lesson 13's **Module 3 resources** section carries the action cookbook subtree, the **Cosmos3 Action Viewer** Space, **`NVlabs/RoboLab`** and the Cosmos Framework repo. The Action Viewer is *also* placed in Lesson 12, in a callout next to the cell that writes `wam_action.json`, because that is the moment a learner has an action array and no way to look at it — with the standing caveats that looking is not checking and that uploading means uploading. An earlier version of this map claimed the links were retained when five of the seven links across nb02 c30 and nb04 c26 were absent course-wide |
| 27 | md | Footer | — | **Excluded** | DLI branding |

### 1.5 Supporting files

Not cells, but they carry substance and are mapped for completeness.

| Source file | Destination | Disposition | What changed and why |
|---|---|---|---|
| `task1/Dockerfile` | `docker/`, `scripts/setup.sh` | **Restructured** | Three decisions are carried because they fix real failures. Clearing `LD_LIBRARY_PATH` in the kernel spec (the NGC image's libtorch shadows the venv's) is in `scripts/setup.sh` lines 549–603 and again in `scripts/smoke_test.py`. Pinning upstream refs is in `setup.sh` via `PINNED.cosmos_framework` / `PINNED.cosmos_cookbook`. `HF_HUB_DISABLE_XET=1` (Xet stalls on large weight shards) is carried into **`docker/` only** — `docker/.env.example` line 159, plus a commented-out line in `docker/docker-compose.yml`. `grep -rc HF_HUB_DISABLE_XET scripts/` → nothing. An earlier version of this map said it was carried into `scripts/setup.sh`; it is not, and a learner who runs `setup.sh` outside the container does not get it. The base image and dependency group become a driver-dependent choice: `25.09-py3` + `cu130-train` on CUDA 13, `25.06-py3` + `cu128-train` on 12.8 (FACTS §3), auto-detected in `setup.sh` |
| `task1/nim/Dockerfile` | `cosmos_course/nim.py` | **Corrected** | Pins `cosmos3-reasoner:1.7.0`; FACTS §4 records the published tag as `1.7`. The course pulls at runtime rather than baking, because a learner needs to see the pull |
| `docker-compose*.yml` (3) | `docker/`, L02 | **Restructured** | Four services, an nginx proxy and service DNS collapse to one `docker run` the learner issues themselves. The `shm_size: 32gb` setting and `NIM_MODEL_SIZE` are carried |
| `entrypoint.sh`, `nginx.conf` | — | **Excluded** | DLI serving infrastructure. Their only leakage into course content is the `/lab` base URL in notebook 04 cell 05, which is removed |
| `tests/e2e/run_e2e.sh` | `scripts/run_all.sh` | **Restructured** | Retargeted from `docker exec` to local `jupyter nbconvert`. **Carried:** the GPU-idle gate between notebooks (`GPU_IDLE_MIB`, default 2048; `GPU_IDLE_TIMEOUT`, default 300) and the per-cell timeout (`CELL_TIMEOUT`, default 1800). **Not carried, and previously claimed as carried:** the three-phase structure — `run_all.sh` runs one flat ordered list and the word "phase" does not appear in it — and the `-e HF_TOKEN` passthrough, which is meaningless once execution is local rather than inside `docker exec`; the script inherits the caller's environment and `grep -c HF_TOKEN scripts/run_all.sh` → 0. The destination is `scripts/`, not `tools/` |
| `tests/e2e/lib/validate_notebooks.py` | `scripts/validate_notebooks.py` | **Expanded** | The five static checks are carried and joined by `tools/nameflow_check.py`, `tools/syntax_check.py`, `tools/api_check.py` and `tools/check_solutions.py`, which would have caught the notebook 02 `NameError` that this validator cannot see. **The file lives in `scripts/`, not `tools/`** — an earlier version of this map put it in `tools/` twice |
| `tests/e2e/lib/filter_notebook.py` | `scripts/run_all.sh` (inline) | **Restructured** | The *mechanism* is carried; the file is not. There is no `tools/filter_notebook.py`. `run_all.sh` strips tagged cells itself via `SKIP_TAG="skip-execution"`, and the tag was **renamed** from the source's `skip-e2e` — the string `skip-e2e` appears nowhere in the course, so anyone searching for it by the old name would find nothing. The tag is used in Lessons 02, 12 and 13. An earlier version of this map described this row as **Carried** and used the old tag name |
| `run_nocache_rebuild.sh` | `scripts/smoke_test.py` tier 2, `planning/05_VALIDATION_REPORT.md` §7 | **Restructured** | The upstream-drift *idea* is more valuable here than in the source, because this course pins refs across a rename — but it is carried as a **Python assertion**, not as the shell script. `smoke_test.py` tier 2 asserts against the learner's own checkout that `ModelMode` contains `wam` and does not contain `policy`. There is no `--no-cache --pull` rebuild wrapper in this course. The validation report records the honest limitation: that assertion has never run against a real `ModelMode`, because no framework checkout existed at authoring time |
| `README.md` (root) | — | **Excluded** as content, mined for facts | The credential architecture and the submodule post-mortem informed the setup design |
| `edX/*`, `.gitlab-ci.yml`, `secrets.env`, `configs/jupyter_configs/*`, `scripts/{cleanup,save_workspace}.sh`, ignore files | — | **Excluded** | DLI platform and CI plumbing with no analogue outside DLI |
| `images/model_download/step{1..12}.jpg` | — | **Excluded** | Screenshots of a third-party signup flow, for a gating step that is now obsolete. `step12.jpg` was already unreferenced |
| `images/{Cosmos-Transfer2-2B-Arch,cosmos_reason2_use_case_1,cosmos_reason2_use_case_2,jl_launcher,nvidia_header}.png` | — | **Excluded** | Unreferenced leftovers from a predecessor Cosmos 2 / Reason 2 course |
| `task1/video_sources` → `s3://dli-lms/data/s-ov-57-v1/videos/` | `cosmos_course/assets.py` | **Corrected** | Private bucket. `toaster_6sec.mp4` is substituted with public cookbook clips, and the substitution is marked in the asset table |

### 1.6 Excluded after being claimed as carried

An independent review grepped this map's claims against the repository and found eleven
rows asserting content that is not there. They fall into two kinds.

**Destination errors**, where the content survives but the row named the wrong home: the
codec material (L02 → **L03**), `check_hf_access` (L00 → **L01**), `HF_TOKEN` ("set by the
setup script" → **documented, learner-set**), `probe_environment` (L00 and L06 → **L00**),
and `validate_notebooks.py` (`tools/` → **`scripts/`**). Those are fixed in place above,
each with the grep that settles it.

**Genuine losses**, where the content was not anywhere. Three of them were worth having
and have been built or restored; the rest are recorded below as deliberate exclusions,
with reasons, because a map that quietly deletes an overclaim is no more honest than one
that keeps it.

| Source | Previously claimed | Actual disposition | Why |
|---|---|---|---|
| nb02 c01 — the six-capability table | carried "nearly verbatim as the Module 1 opener" | **Built** | Was absent course-wide. Now opens Lesson 03 with both source columns intact and a lesson-coverage column added, restated in Lessons 04 and 05 |
| nb03 c06 — structured versus sentence | "Lesson 07 compares structured against sentence prompts on the same intent" | **Built** | Was never built. Now a predict–run–explain in Lesson 07 at a fixed seed, with the addressability argument runnable without a GPU |
| nb02 c30, nb04 c26 — 5 of 7 resource links | "links retained" | **Restored** | The Action Viewer Space, `NVlabs/RoboLab`, both cookbook subtrees and the `build.nvidia.com` reasoner were all absent. Now in Lessons 02, 05, 12 and 13 |
| nb02 c13 — two commented-out remote clip URLs | "become an explicit exercise in bringing your own footage" in L03 | **Excluded** | Never built. Lesson 03 has no own-footage hook of any kind. Building one properly means handling arbitrary containers, codecs and durations against a NIM that returns HTTP 422 on anything it cannot decode — which is Lesson 03's debugging lab, arriving before the learner has the tools to survive it. Lesson 07's `MY_IMAGE` covers the same instinct on the cheaper artefact |
| nb04 c09 — `--video-save-quality 8` | implied carried into `Generator._build_command` | **Excluded** | An undocumented integer with no stated scale, no default recorded upstream, and no effect on anything the course measures. Preview encoding quality is not a variable this course teaches, and carrying a magic number forward is exactly the habit `COSMOS3_FACTS.md` exists to break |
| nb04 c25 — `BananaInBowlTask` | implied among "the components named are right" | **Excluded** | Names one specific RoboLab task the course never runs. `policies/cosmos3/run.py` and the `NVlabs/RoboLab` URL *are* carried in Lesson 13, because a reader can go and look at them; the task name adds nothing a reader can act on |
| `run_e2e.sh` — three-phase structure | "all carried" | **Excluded** | `scripts/run_all.sh` runs one flat ordered list. The source's phases separated container build, notebook execution and teardown, and only the middle one has an analogue outside DLI |
| `run_e2e.sh` — `-e HF_TOKEN` passthrough | "all carried" | **Excluded** | Meaningless once execution is local rather than `docker exec`. The script inherits the caller's environment |
| `Dockerfile` — `HF_HUB_DISABLE_XET=1` in `setup.sh` | carried to `docker/` **and** `scripts/setup.sh` | **Excluded from `setup.sh`** | Present in `docker/.env.example` only. A learner running `setup.sh` on bare metal does not get it, and should export it themselves if a weight pull stalls |
| `filter_notebook.py` — the file, and the `skip-e2e` tag name | "Carried" to `tools/` | **Excluded as a file; tag renamed** | The mechanism is carried inline in `run_all.sh`; the tag is `skip-execution`. Anyone searching the course for `skip-e2e` finds nothing |
| `run_nocache_rebuild.sh` — the script | "Carried" | **Excluded as a script** | The upstream-drift idea is carried as `smoke_test.py` tier 2. There is no `--no-cache --pull` rebuild wrapper |

---

## 2. Reverse map — where each lesson's content comes from

Percentages are the author's judgement of how much of the lesson's substance traces to
the source, not a line count.

| Lesson | Source-derived | Newly authored |
|---|---|---|
| **00** environment_check | ~3 %. Notebook 03 cell 05 and notebook 04 cell 04 print `torch.__version__` and a device count. **Not** notebook 01's HF-token cells — those land in Lesson 01, and Lesson 00 has no `check_hf_access` call | Everything else. The whole `EnvReport` probe surface, disk budgeting, Docker GPU verification, nvcr.io login checks, the assessment thresholds, and the requirement that a learner argue with them |
| **01** cosmos3_mental_model | ~20 %. The omni-model framing (nb02 c01, nb04 c01) and the tier names | MoT and the active-versus-total parameter rule; the full tier/capability matrix including Edge, which the source never mentions; the mode enum as the arbiter; the `policy`/`wam` correction; transfer as mode-plus-hint; the first-run download chain; OpenMDW 1.1 |
| **02** serving_the_reasoner | ~20 %. NIM readiness polling (nb02 c07), the OpenAI client and base64 transport (nb02 c05, c09), the three resource links (nb02 c30). **Not** `ensure_h264` — that is taught in Lesson 03 | **All VRAM-contention material.** KV cache pre-allocation, the deliberate OOM demonstration, take-turns versus cap, `discover_memory_env()`, `nim_status()`'s four-source reporting. **The entire vLLM fallback**, including why it needs its own venv |
| **03** reasoning_captioning | ~40 %. The captioning example and prompt (nb02 c12–c14), the `fps` knob (nb02 c08), `ensure_h264` and the AV1/422 warning (nb02 c08, c09), the six-capability table as the module opener (nb02 c01) | fps as a measured cost lever with token accounting; free-text-to-schema conversion; batch inference; the scene-record JSONL that Lesson 07 consumes; determinism comparison; `check_text()`; the lesson-coverage column on the capability table |
| **04** reasoning_embodied | ~55 %. Three prompt patterns and the `<think>` convention (nb02 c15–c23), with two of the three assets substituted | The with/without-`<think>` ablation; the goal-only ablation; deliberate failure-hunting including a probe whose answer should be "no"; latency and token cost of reasoning; the requirement to document a wrong answer |
| **05** reasoning_spatial | ~50 %. Grounding, Set-of-Mark and action chain-of-thought (nb02 c24–c29) and their overlay helpers | Marks derived from the lesson's own grounding output instead of hard-coded pixel boxes; the deliberate grounding failure; the sampling sweep with parse-failure rate; the 2D-versus-3D distinction that sets up Lesson 12 |
| **06** generation_fundamentals | ~25 %. text2video (nb03 c08–c11) and the `FIXED_SAMPLING` values as a starting point | The denoising explanation; hand-built specs before helpers; **all measurement** — correct timing, warm-up, synchronisation, peak memory; the cost curve; units-per-second calibration; Edge, which the source never uses; the aspect-ratio comma trap |
| **07** generation_conditioned | ~40 %. image2video (nb03 c12–c15), structured JSON prompts (nb03 c06), negative prompts (nb03 c07) | Structured-versus-sentence comparison; the guidance sweep at fixed seed; reproducibility and its limits; consuming a Lesson 03 scene record, which closes an arc the source only asserted |
| **08** generation_control | ~35 %. The control table and the edge example (nb03 c16–c20) | Naming `video2video`; correcting five controls to four plus `wsm`; the tier constraint; multi-hint comparison on one clip; the designed augmentation pass; the honest note that `assets/multi_control/` does not exist |
| **09** generation_audio_guardrail | ~5 %. `enable_sound` exists as an unused parameter (nb03 c07); the guardrail is named as a repo (nb01 c05) | **Essentially the whole lesson.** Audio generation, which the source never runs. The guardrail as a pipeline stage. Deliberate rejection and its signature. Distinguishing rejection from OOM from codec failure. The naming split. The argument about disabling it |
| **10** action_forward_dynamics | ~60 %. The mode framing, the record schema and the AV example (nb04 c06–c10) | Every field explained; a learner-authored trajectory; the single-process launch path explained rather than merely used; the distribution-boundary probe |
| **11** action_inverse_dynamics | ~45 %. The mode, the record and the plotting code (nb04 c11–c15) | The pose mathematics the source used without explaining — `rot6d`, homogeneous transforms, `backward_framewise`, `translation_scale` and its provenance; the forward/inverse round-trip consistency check; the error decomposition |
| **12** action_wam | ~50 %. The mode framing, output extraction and end-effector plotting (nb04 c16–c24) | The `policy`→`wam` correction and the deliberate reproduction of the failure; the two-layout contrast; instruction ablation; a locally cached observation instead of a mid-lesson network fetch |
| **13** action_closed_loop | ~10 %. Five sentences of prose (nb04 c25) naming the right components | The second-venv requirement and demonstrating the conflict; the policy-server run; LIBERO versus RoboLab feasibility on one GPU; the VRAM budget for server-plus-simulator; the honest statement of what was read rather than run |
| **14** performance_and_memory | **0 %** | Entirely new. The source contains no measurement of any kind in 41 code cells |
| **15** optimisation | **0 %**, apart from two unexplained `--parallelism-preset` values | Entirely new |
| **16** posttraining_concepts | **0 %** | Entirely new |
| **17** posttraining_one_gpu | **0 %** | Entirely new |
| **18** evaluation | **0 %** | Entirely new |
| **19** capstone | ~10 % as *intent*, 0 % as code. Three "how this fits the pipeline" sections (nb02 c02, nb03 c02, nb04 c26) assert the loop | The entire implementation. No source cell consumes another notebook's output. Note that Lesson 19 is deliberately **self-contained**: it runs the reasoner itself and writes its own `outputs/19/scenes.jsonl` rather than reading Lesson 03's `scene_records.jsonl`, so the capstone works for someone who took the modules out of order. Lesson 07 is the lesson that actually reads Lesson 03's file |

---

## 3. Content that is new, listed explicitly

Nothing below has any analogue in the source package.

**All of Module 4 — Systems (Lessons 14–15, 5 hours).** Correct GPU timing with
synchronisation and warm-up; the distinction between allocated, reserved and
driver-reported memory; fragmentation; the OOM escalation ladder and which of its rungs
exist on one GPU (FACTS §5: levers 3 and 4 need more GPUs); the measurement log; precision
tradeoffs; parallelism presets at world size 1; **the quality/cost frontier** over
resolution/frames/steps (Lesson 15's section of that name — the course does not use the
word "Pareto", so search for "frontier" or "knee"); attention-backend selection on Hopper;
the reasoner/generator memory asymmetry that lets Super reason but not generate on one
H100.

**All of Module 5 — Post-training (Lessons 16–18, 7 hours).** The JSONL generator schema
and its two silent loader filters; LeRobotDataset v3.0 structure; dataset selection with
sizes (BridgeData2 0.65 GB versus DROID 707 GB — the table is in `COSMOS3_FACTS.md` §
Datasets and in `cosmos_course/finetune.py`; Lesson 17 is where a learner meets it); the SFT memory arithmetic showing full
Nano SFT needs ≈256–350 GB; why activation checkpointing does not help when the blocker is
optimizer state; why the shipped recipe is HSDP 2×8; the `vision_sft_edge` reduction to
~2B trainable via `keys_to_select`; disabling EMA; cutting `max_num_tokens_after_packing`;
LoRA and its VFM-only scope; the absence of 8-bit optimizers and CPU offload; and the
entire evaluation lesson built on the fact that `cosmos_framework/evaluation/` is
`[planned]` and absent.

**The vLLM fallback (Lesson 02).** Serving the reasoner without a NIM, using the
`vllm-cosmos3` plugin with `--hf-overrides '{"architectures":
["Cosmos3ReasonerForConditionalGeneration"]}'`, plus the two alternatives (Transformers
loading only the reasoner tower, and `model_mode: "reasoner"` through the framework), and
the dependency conflict that forces a second venv.

**All VRAM-contention material (Lesson 02, used throughout).** The KV-cache
pre-allocation behaviour that makes the NIM's resting footprint several times its weight
footprint; the deliberate OOM demonstration; take-turns versus cap with the numbers for
both; `discover_memory_env()` and the honest admission that the memory environment
variable's name could not be verified against a running NIM 1.7 at authoring time; the
Generator NIM's ≥79 GiB floor and why this course does not use it. The source's answer to
this problem was a second GPU.

**Audio generation (Lesson 09).** `audio_image2video` on Nano, the Edge constraint, and
verifying an audio stream in the output.

**The guardrail lesson (Lesson 09).** Where it sits, that it screens prompt and frames,
the one remaining gated licence, deliberate rejection, distinguishing rejection from OOM
from codec failure by signature, the `Cosmos-1.0-Guardrail` versus `Cosmos-Guardrail1`
naming split, and the argument about disabling it.

**The evaluation lesson (Lesson 18).** Designing an evaluation where no harness ships;
controls and seed variance; round-trip action consistency as a free metric; reasoner-as-
judge and its circularity when reasoner and generator share a checkpoint; reporting a null
result.

**Also new, though smaller:**

- **Cosmos3-Edge as a first-class tier.** Absent from the source entirely, and the right
  default on one GPU. Used in Lessons 01, 06, 14, 15 and 17.
- **Output verification** (`cosmos_course/checks.py`). The source looks at outputs; this
  course checks them, because a generation run can exit zero and write a blanked file.
- **Failure diagnosis** (`RunResult.diagnose()`). A taxonomy the source does not have.
- **Cost estimation before launch** (`estimate_generation_cost()`, `InferenceSpec.cost()`).
- **The capstone itself.** The source asserts the flywheel three times and never builds it.
- **Exercises and completion criteria.** The source has none: all 41 code cells run to
  completion with no learner input, no question to answer and no criterion for having
  finished.
