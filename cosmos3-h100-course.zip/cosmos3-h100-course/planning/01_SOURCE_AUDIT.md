# Source audit — NVIDIA DLI `S-OV-57-V1`

*"From Perception to Prediction: Developing Physical AI with Cosmos 3"*

This document audits the supplied DLI course package against what a 35–40 hour,
single-H100 course needs. It is written for the person who has to build that course
and wants to know, before writing a line, exactly what they inherit and what they
must repair.

Two ground rules apply throughout. Every factual claim about Cosmos 3 itself is
checked against `assets/reference/COSMOS3_FACTS.md`; where that file and the source
course disagree, the source is wrong and this document says so with a section
reference. Every claim about the source is cited to a file and, for notebooks, to a
cell index (zero-based, as `nbformat` stores them, so *cell 09* is the tenth cell).

The package contains 92 notebook cells (41 code, 51 markdown) across four notebooks,
plus 50 supporting files.

---

## 1. Inventory

### 1.1 The four notebooks — 92 cells

These are the whole of the teaching content. Everything else in the package is
infrastructure.

#### `task1/task/01_creating_huggingface_token.ipynb` — 9 cells (1 code, 8 markdown)

A screenshot walkthrough of Hugging Face account creation, access-token generation,
and gated-licence acceptance. Cells 03–05 are 65 lines of markdown wrapping eleven
JPEG screenshots. Cell 07 is the only code in the notebook:

```python
from getpass import getpass
!hf auth login --token "{getpass(prompt='HF_TOKEN:')}"
```

Contribution to a rebuilt course: the *shape* of the credential story (you will need
a Hugging Face token and an NGC key, and one of them gates a download that happens
lazily during your first generation run). The specific content is obsolete — see
§4.2.

#### `task1/task/02_world_reasoning.ipynb` — 32 cells (14 code, 18 markdown)

The strongest notebook in the package, and the one with the most reusable material.
It talks to the Cosmos 3 Reasoner NIM over an OpenAI-compatible API and works
through six reasoning capabilities.

| Cells | Section | What it contributes |
|---|---|---|
| 00–03 | Header, framing, capability table | The perceive → reason → act narrative and a genuinely good capability table (cell 01) |
| 04 | Asset resolution and `openai` install | The asset-name indirection idea; also the `/dli/task` hard-coding (§4.5) |
| 05–07 | NIM connection and readiness polling | `/v1/health/ready` polling with a timeout — the right pattern, wrong error message (§4.9) |
| 08–09 | `run_inference`, `show_media`, `ensure_h264` | The single most valuable code block in the package. Base64 `data:` URL inlining, `media_io_kwargs` fps control, the AV1 → H.264 transcode workaround, and a sampling-parameter passthrough. Also contains the `display_video` defect (§4.6) |
| 10–11 | `draw_boxes`, `draw_trajectory` | Parsing 0–1000-normalised JSON coordinates back onto pixels; `_parse_json` handles code fences and `</think>` splitting |
| 12–14 | Video captioning | Captioning at 4 FPS sampling as the entry point to scene understanding |
| 15–21 | Embodied reasoning (next action, planning, assisted task) | Three prompt patterns and the `<think>` convention |
| 22–23 | Physical common sense | Load-bearing-surface feasibility question |
| 24–25 | 2D grounding | Bounding-box localisation with overlay |
| 26–27 | Describe Anything / Set-of-Mark | Hand-authored numbered marks, then region-keyed captioning. Prose and code disagree (§4.11) |
| 28–29 | Action chain-of-thought | Gripper trajectory in pixel space; the one place sampling parameters are varied deliberately |
| 30–31 | Wrap-up, resources, footer | Three upstream links worth carrying |

#### `task1/task/03_world_generation.ipynb` — 23 cells (12 code, 11 markdown)

Generation through the Cosmos Framework as a `%%bash` subprocess. Runs in a separate
Jupyter kernel (`cosmos3`) backed by the framework's `uv` venv.

| Cells | Section | What it contributes |
|---|---|---|
| 00–03 | Header, framing, environment prose | The kernel-switch instruction, and the two-GPU premise (§4.4) |
| 04–05 | Paths, GPU pinning, torch check | The environment-variable-to-`%%bash` bridge pattern |
| 06–07 | `create_payload`, `display_video`, `view_run`, `view_t2v_prompt` | Spec construction from a cookbook prompt asset. Hides sampling behind `FIXED_SAMPLING` (§4.8) |
| 08–11 | Text-to-video | The canonical `torchrun … cosmos_framework.scripts.inference` invocation |
| 12–15 | Image-to-video | First-frame conditioning; relative `vision_path` resolution |
| 16–20 | "Data augmentation" (transfer) | The four-control table, the edge spec, the control-video preview. Mis-framed (§4.3) |
| 21–22 | Closing, resources, footer | — |

#### `task1/task/04_action_generation.ipynb` — 28 cells (14 code, 14 markdown)

Action as a modality. Three modes, plus a pointer at closed-loop control.

| Cells | Section | What it contributes |
|---|---|---|
| 00–02 | Header, the three-mode table | A clear framing of forward/inverse/policy as three questions |
| 03–05 | Environment, torch check, `preview` | A third, incompatible video-preview helper (§4.7) |
| 06–10 | Forward dynamics (AV) | The action-record JSONL schema; `action_chunk_size`, `domain_name`, `view_point` |
| 11–15 | Inverse dynamics + `visualize_pose` | 62 lines of camera-frustum and bird's-eye plotting; `pose_rel_to_abs` with `rot6d` |
| 16–24 | Policy mode | The rename defect (§4.1); a network-fetched start observation; end-effector path integration |
| 25 | Closed-loop RoboLab (prose only) | Names the right components, omits every constraint (§5) |
| 26–27 | Wrap-up, resources, footer | — |

### 1.2 Container and build — 11 files

`task1/Dockerfile` is the substantive one. It builds on `nvcr.io/nvidia/pytorch:25.09-py3`,
installs graphics and media system libraries, clones `NVIDIA/cosmos-framework` pinned to
commit `469c102c19b6585dfe8c9bc7d5a9f54bb7571917` and builds its venv with
`uv sync --all-extras --group=cu130-train`, registers that venv as the `cosmos3` Jupyter
kernel, patches the kernel spec to clear `LD_LIBRARY_PATH` and set `PYTHONNOUSERSITE=1`,
then clones `NVIDIA/cosmos` (the cookbook) pinned to `444d86120a57c42e527e4938eadd476c64c58062`.
It sets `HF_HUB_DISABLE_XET=1` with a comment explaining that the Xet transfer backend
stalls mid-download on large Cosmos weight shards. Every one of those decisions is worth
carrying into a bare-metal setup script; two of them (the `LD_LIBRARY_PATH` clear and the
Xet disable) are non-obvious fixes for real failures.

`task1/nim/Dockerfile` is a one-line `FROM nvcr.io/nim/nvidia/cosmos3-reasoner:1.7.0`,
existing solely so CI ships the NIM as a build artefact.

`task1/docker-compose.yml` plus the `.override.yml` and `.deployment.yml` pair define four
services (`lab`, `cosmos3-reasoner`, `nginx`, `s3_video_loader`), three named volumes
(`video_assets`, `nim_cache`, `hf_cache`), `shm_size: 32gb` on the NIM, and
`NIM_MODEL_SIZE=nano`. The NIM is reachable only by Compose service DNS; no host port is
published. `entrypoint.sh` launches JupyterLab with `--NotebookApp.base_url="/lab"` and
`--notebook-dir="/dli/task"`; `nginx.conf` proxies `/lab` to `lab:8888`. Those two files
are the origin of the `_JUPYTER_BASE_URL = "/lab"` constant in notebook 04 cell 05.

`task1/.env` sets `COMPOSE_PROJECT_NAME` and `DEV_NGINX_PORT`. `secrets.env` holds a
GitLab secret *reference*, not a value. `task1/data_sources` is a zero-byte file.
`task1/video_sources` contains one line, `--recursive s3://dli-lms/data/s-ov-57-v1/videos/`,
which is how `toaster_6sec.mp4` reaches the lab — see §4.10.

### 1.3 Test harness — 5 files

`task1/tests/e2e/run_e2e.sh` executes notebooks 02–04 inside the running lab container in
three phases (static validation, pre-flight, execute) with a GPU-idle gate between
notebooks, a 3600-second per-cell timeout, and `HF_TOKEN` injected via `docker exec -e`
passthrough so the token never appears in argv. `run_nocache_rebuild.sh` wraps it with a
`--no-cache --pull` rebuild to catch upstream drift, and self-detaches via `setsid`.
`lib/validate_notebooks.py` is a sub-second static gate checking valid JSON, output-clean
cells, correct kernelspec per notebook, the NVIDIA header/footer, and that every `images/`
reference resolves. `lib/filter_notebook.py` drops cells tagged `skip-e2e` before execution.
`README.md` documents all of it and closes with an unusually candid status note quoted in
§4.16.

This harness is the best-engineered part of the package and its design should be carried
over almost intact, retargeted from `docker exec` to a local `jupyter nbconvert`.

### 1.4 Images — 19 files

`images/model_download/step{1..12}.jpg` are the Hugging Face signup screenshots.
`nvidia_header_black.png` and `nvidia_header_white.png` are the light/dark header logos
referenced by every notebook's first and last cell. Five files are dead weight:
`step12.jpg` is never referenced, and `Cosmos-Transfer2-2B-Arch.png`,
`cosmos_reason2_use_case_1.png`, `cosmos_reason2_use_case_2.png`, `jl_launcher.png` and
`nvidia_header.png` are unreferenced leftovers from a predecessor Cosmos 2 / Reason 2
course. That is 315 KB of a 4.8 MB image directory carried for no reason, and the
Cosmos 2 filenames are a small but real archaeological clue about how this course was
assembled.

### 1.5 Jupyter configuration — 5 files

`configs/jupyter_configs/custom/custom.css` implements the light/dark header-logo swap
using `[data-jp-theme-light]` selectors. The remaining four (a terminal-extension
settings file, two saved workspaces, `nbconfig/tree.json`) are captured UI state,
regenerated by `scripts/save_workspace.sh`. Nothing here is course content.

### 1.6 Repository boilerplate and metadata — 10 files

`README.md` (root) is genuinely informative: it documents the NGC and Hugging Face
credential paths, the devbox quickstart, and — usefully — records that the cookbook was
once a git submodule and that "submodule contents did not survive the Pebble build
packaging, so the notebook found an empty directory in production". `.gitlab-ci.yml`
includes NVIDIA's Pebble CI pipeline. `scripts/cleanup.sh` strips root-owned artefacts
that the container writes into the bind mount. `scripts/save_workspace.sh` round-trips
JupyterLab config out of the container. `.gitignore` (×2), `.dockerignore` and
`.launchignore` are standard; the last notably excludes `assessment/*`, a directory
that does not exist. `edX/README.md` and `edX/example_course_overview.html` are DLI
catalogue metadata; the former states the convention that Course Duration is "usually
02:00, or 08:00", which is the source's own estimate of its length and matters for §4.17.

---

## 2. Concepts the source covers, organised by theme

### The model

Cosmos 3 is presented as an *omni-model*: one model that reasons, generates and acts
(notebook 02 cell 01; notebook 04 cell 01). The source never explains the mechanism
behind that claim. It does not mention Mixture-of-Transformers, separate reasoner and
generator towers, or why the same checkpoint can serve both an HTTP chat API and a
diffusion sampler. It names Nano (8B) and Super (32B) without reconciling those against
the 16B and 64B figures on the model cards (`COSMOS3_FACTS.md` §1 calls this the naming
trap). Edge does not appear at all.

### Reasoning as a hosted service

The reasoner is reached through an OpenAI-compatible chat completions API. Media travels
inline as base64 `data:` URLs rather than as file paths, because the server cannot see the
client's filesystem. Video sampling density is controlled out-of-band through
`extra_body={"media_io_kwargs": {"video": {"fps": …}}}` rather than as a normal parameter.
Sampling controls (`temperature`, `top_p`, `top_k`, `repetition_penalty`, `presence_penalty`,
`seed`) are exposed but used only once, in cell 29. Video must be H.264: the NIM decodes
with OpenCV, which returns metadata but zero frames for AV1, which the server then rejects
with a 422.

### Prompt patterns for physical reasoning

Four recur. The `<think> … </think>` wrapper makes the chain of thought inspectable
before the answer (cells 17, 21, 23, 29). Explicit JSON output requests with coordinates
normalised to 0–1000 (cells 25, 27, 29). Set-of-Mark prompting, where numbered marks are
burned into the image and the model is asked to describe each by `subject_id` (cells
26–27). And task decomposition, where a goal plus a current step yields a next action
(cells 19, 21).

### Generation as a subprocess

Generation does not run in the notebook's kernel. It runs as
`cosmos_framework.scripts.inference` launched under `torchrun` (notebook 03) or as a bare
Python process with `MASTER_ADDR`/`RANK`/`WORLD_SIZE`/`LOCAL_RANK` set by hand (notebook
04), against a JSON or JSONL spec file. The spec carries `model_mode`, the prompt, a
negative prompt, and sampling geometry. `--parallelism-preset` takes `throughput` in
notebook 03 and `latency` in notebook 04, unexplained.

### Conditioning and control

Text-to-video, image-to-video, and control-conditioned video-to-video appear, in that
order. Prompts are structured JSON documents describing a scene attribute by attribute,
not sentences — the source shows this (cell 07's `view_t2v_prompt`, cell 09) but never
explains why the model wants that shape. Negative prompts are loaded per mode from
`assets/negative_prompts/{mode}/neg_prompt.json`, and the code silently handles the fact
that `text2image` has none. Control conditioning is presented as four modalities in a
table plus a fifth in prose.

### Action as a modality

The core claim is that action tokens represent the transition between consecutive visual
states (cell 01), which lets the same model run three ways: forward dynamics (image +
actions → video), inverse dynamics (video → actions), and policy (observation +
instruction → video *and* actions). Records carry `action_chunk_size`, `domain_name`,
`view_point`, `fps` and `image_size`. Predictions land in
`sample_outputs.json` under `outputs[0].content["action"]`. Two different action layouts
appear: a 9-D ego-pose delta for the AV domain and a 10-D end-effector vector
(3 translation + 6 rotation + 1 gripper) for manipulation.

### Pose mathematics

Notebook 04 cell 15 converts relative pose deltas to absolute 4×4 camera poses with
`pose_rel_to_abs(…, rotation_format="rot6d", pose_convention="backward_framewise",
translation_scale=1.35)`, then reads camera centres from `poses_abs[:, :3, 3]` and headings
from `poses_abs[:, :3, 2]`. None of `rot6d`, the pose convention, the scale constant, or
the homogeneous-transform layout is explained.

### The pipeline argument

Every notebook opens with a "how this fits" section arguing that reasoner outputs become
generator prompts, generated video becomes training data, and action models consume both.
The argument is never closed: no cell in notebook 03 consumes a caption produced in
notebook 02, and no cell in notebook 04 consumes a video produced in notebook 03. The
flywheel is asserted, not built.

### Operations

Gated weights and licence acceptance, an NGC key for the NIM, Hugging Face caching in a
Docker volume, codec constraints, and the mechanics of previewing large video in Jupyter.

---

## 3. Prerequisites the source implies but never states

The source is written as if a learner can start at notebook 01 with no stated background.
In practice the following are load-bearing.

**Linux and container fluency.** Notebook 02's timeout message (cell 07) instructs the
learner to run `docker compose … logs`, which requires a host shell, the compose file, and
Docker CLI access — none of which the learner has from inside the lab container.

**The Jupyter kernel model.** Notebooks 03 and 04 declare `kernelspec.name == "cosmos3"`.
Cell 01 of notebook 03 tells the learner to check the kernel selector. A learner who has
only ever used one kernel will not understand why `import torch` gives a different version
in two notebooks, or why `imageio_ffmpeg` exists in one and not the other.

**Distributed launch basics.** Notebook 03 uses `torchrun --nproc-per-node --master-addr
--master-port`; notebook 04 sets `RANK`, `WORLD_SIZE` and `LOCAL_RANK` by hand. Neither
is explained, and a learner who does not know what a rendezvous is cannot debug a port
collision.

**Diffusion sampling.** `num_steps`, `guidance` and `shift` appear as constants in
notebook 03 cell 07 with no definition. `shift=10.0` in particular is a flow-matching
timestep-shift parameter that most learners will never have encountered.

**Rigid-body transforms.** As above: `rot6d`, `[:, :3, 3]`, `[:, :3, 2]`, camera
conventions with +Z forward and Y up, and frustum geometry.

**NumPy and Matplotlib at intermediate level.** Cell 15 of notebook 04 uses
`Line3DCollection`, `LineCollection`, `set_box_aspect`, `np.ptp`, axis reordering via an
index list, and a quiver overlay, in 62 lines with three comments.

**Video and codec literacy.** `ffprobe`, `libx264`, `yuv420p`, `-movflags +faststart`,
the moov-atom-position problem, and why base64-embedding a large MP4 produces a player
that shows one frame and will not play.

**The Hugging Face auth model.** Token scopes, gated repositories, `HF_HOME`, and the
distinction between a token that is valid and a token whose account has accepted a
licence. The e2e README states this distinction correctly; the notebooks do not.

**Two GPUs.** Assumed everywhere (§4.4), stated nowhere.

**OpenAI Python SDK ≥ 1.0.** Cell 04 pip-installs `openai` unpinned. The multimodal
content-part schema and `extra_body` semantics used in cell 09 are version-sensitive.

**JSON spec schema for the framework.** No notebook links to `docs/inference.md` or lists
the valid fields. A learner who wants to change anything not in `FIXED_SAMPLING` has no
reference.

---

## 4. Gaps, ambiguities, outdated sections and duplication

This is the section that matters. Each item states the defect, the evidence, and the
consequence.

### 4.1 `policy` is no longer a model mode — notebook 04 will fail

Notebook 04 cell 19 writes:

```python
policy_record = {
    …
    "model_mode": "policy",
    …
}
```

and cell 20 runs it. `COSMOS3_FACTS.md` §2 records that upstream renamed this mode to
`wam` (World Action Model), with three independent confirmations: the
`ACTION_MODEL_MODES` frozenset, the existence of `defaults/wam/` and absence of
`defaults/policy/`, and the shipped input files `inputs/omni/action_policy_av.json` and
`action_policy_robot.json`, both of which now contain `"model_mode": "wam"` while only
their *filenames* still say policy.

The defect is not confined to one cell. Cell 01's three-mode table names the mode
**Policy**. Cell 16's heading is "## 4. Policy mode" and its prose says "policy runs as a
one-shot inference with `model_mode: policy`". Cell 18 repeats it. The root `README.md`
Special Notes repeats it twice. Notebook 01 cell 05 repeats it. So a rebuilt course must
rename in seven places across three files, not one.

Two aggravating factors. First, upstream's own prose is still wrong — `docs/inference.md`,
`docs/faq.md` and the action cookbook README all still say `policy` (FACTS §2, §7), so a
learner who checks the documentation will conclude the notebook is right. Second, FACTS
§2 warns that `raw.githubusercontent.com/.../main/...` serves a stale cached copy still
showing `POLICY = "policy"`, and that you must fetch `.../refs/heads/main/...` to see the
truth. Anyone verifying this independently will probably verify it wrongly on the first
attempt.

The rebuilt course should teach `wam`, mention `policy` once as the dead name, and provide
a `normalize_policy_mode()` shim (already present in `cosmos_course/specs.py`) so a learner
who copies old code from the internet gets a warning rather than a stack trace.

Because the source Dockerfile pins the framework to commit `469c102c…` rather than a tag,
it is likely — though not verifiable from the package alone — that the pinned commit
predates the rename and that notebook 04 passed its own e2e run at the time. That would
make the source internally consistent against a frozen commit and broken against anything
current. This is an inference, not a checked fact.

### 4.2 Notebook 01's entire premise is obsolete

Notebook 01 exists to walk a learner through accepting gated model licences. Cell 05
states that "These repositories are **gated** and subject to the *NVIDIA Open Model
License*" and links the learner to request access to `nvidia/Cosmos3-Nano`,
`nvidia/Cosmos-Guardrail1`, optionally `nvidia/Cosmos3-Super` and optionally
`nvidia/Cosmos3-Nano-Policy-DROID`.

Two things are wrong. First, all nine Cosmos3 repositories now return `gated: false`
(FACTS §1, verified against `https://huggingface.co/api/models?author=nvidia&search=Cosmos3`).
The only repository that still requires a licence click is `nvidia/Cosmos-Guardrail1`.
So four of the five links in cell 05 are unnecessary, and a learner who follows them
finds nothing to accept and reasonably concludes something is broken. Second, the licence
is **OpenMDW 1.1** (`openmdw1.1-license`), not the NVIDIA Open Model License the cell
cites and links.

The knock-on effects reach the whole package. Notebook 03 cell 08 warns "gated — make sure
you completed notebook 01". Notebook 04 cell 08 repeats it. The root README has a section
on it. The e2e README states that the tester's account must have accepted licences for
both `nvidia/Cosmos3-Nano` and `nvidia/Cosmos-Guardrail1` "or the weight download 403s
even with a valid token" — half true now.

There is a genuine residual lesson underneath. The guardrail *is* gated, the generator
enables it by default, and the failure it produces is a 403 in the middle of a
multi-gigabyte download that has already been running for some minutes. That is one click
and one paragraph, not a nine-cell notebook with eleven screenshots.

Cell 07 also has a small security smell: `!hf auth login --token "{getpass(...)}"` is an
IPython shell magic with the token interpolated into the command string, so the secret
lands in the `hf` process's argv and is visible in `/proc` for the life of the call.
`HF_TOKEN` as an environment variable avoids this.

### 4.3 Transfer is taught as if it were a model mode

Notebook 03 cell 16 introduces control-conditioned generation under the heading
"## 4. Data augmentation" and describes it as something Cosmos 3 "can also be used" for,
conditioned on "a **control video** (one of edge, blur, depth, segmentation, or
world-scenario maps) plus a prompt". Cell 18 says "Transfer inference is selected
automatically because the spec contains a control (`edge`) block."

The mechanical statement in cell 18 is correct. The framing is not. Nowhere does the
source tell the learner that this is `model_mode: "video2video"` — the words `video2video`
do not appear in any of the four notebooks. The learner finishes the section able to run
`specs/edge.json` and unable to write a transfer spec from scratch, because they have no
idea which mode to put in it.

Two further errors follow from the mis-framing. The prose lists five controls; FACTS §2
records that `TransferHintKey` defines exactly four (`edge`, `blur`, `depth`, `seg`), and
that `wsm` is a cookbook asset family using the same mechanism but not a member of the
enum. Presenting it as a co-equal fifth will send learners looking for an enum value that
does not exist. And the section is silent on tier support: FACTS §2 records that Edge
supports no transfer at all and Super supports only `text2image`, `text2video` and
`image2video`, so transfer is a Nano-only capability. A learner who drops to Edge to save
VRAM — the obvious move on one GPU — will find this section simply does not work, with no
warning anywhere in the source.

The rebuilt course teaches transfer as `video2video` plus a hint block, names all four
enum members, flags `wsm` as the exception it is, and states the tier constraint before
the learner spends twenty minutes on a run that cannot succeed.

### 4.4 `CUDA_VISIBLE_DEVICES=1` — the two-GPU assumption

Notebook 03 cell 04:

```python
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "1")
os.environ.setdefault("COSMOS3_NUM_GPUS", "1")
```

Notebook 04 cell 03 sets the same variable to `"1"`. Cell 03 of notebook 03 explains why:
"By default we use a **single H100** (`CUDA_VISIBLE_DEVICES=1`) so generation can run
while the Part 2 Reasoner NIM keeps GPU 0. To generate faster on both GPUs, stop the NIM
… and set `CUDA_VISIBLE_DEVICES=0,1` and `COSMOS3_NUM_GPUS=2`."

So the course is a two-GPU course that describes itself as single-GPU. On a machine with
one H100, `CUDA_VISIBLE_DEVICES=1` selects a device that does not exist. The symptom is
not an error at that line: it is notebook 03 cell 05 printing
`cuda available: False | device count: 0`, which a learner may well skim past, followed
some cells later by an opaque failure inside the framework subprocess. `os.environ.setdefault`
makes it worse by being silent when the variable happens to be set already.

The rebuilt course removes the pin entirely, has `cosmos_course.config.probe_environment()`
emit a warning if `CUDA_VISIBLE_DEVICES` is set to anything at all, and replaces the
two-GPU escape hatch with the real single-GPU strategy: take turns between the NIM and the
generator, or cap the NIM's memory fraction. That material does not exist in the source and
is the subject of new Lesson 02.

### 4.5 `/dli/task`, `/opt/…` and Compose service DNS are hard-coded throughout

| Location | Hard-coded value | Why it breaks |
|---|---|---|
| nb02 cell 04 | `ASSETS_DIR = Path("/opt/cosmos/cookbooks/cosmos3/reasoner/assets")` | Image-specific clone path |
| nb02 cell 04 | `ASSETS_DIR_2 = Path("/dli/task/assets")` | Jupyter notebook-dir, set in `entrypoint.sh` |
| nb02 cell 06 | `NIM_BASE_URL` default `http://cosmos3-reasoner:8000` | Compose service DNS; unresolvable outside the Compose network |
| nb02 cell 07 | `docker compose -f task1/docker-compose.yml logs …` | Path relative to a repo root the learner is not in, using a CLI the container lacks |
| nb03 cell 04 | `COSMOS_ROOT` default `/dli/task/cosmos` | Leftover from the abandoned submodule layout; the Dockerfile now sets `COSMOS_ROOT=/opt/cosmos`, so this default is dead *and* wrong |
| nb03 cell 04, nb04 cell 03 | `COSMOS3_REPO` default `/opt/cosmos3-framework` | Image-specific |
| nb04 cell 05 | `_NB_ROOT = Path("/dli/task")`, `_JUPYTER_BASE_URL = "/lab"` | Both derive from `entrypoint.sh` and `nginx.conf`; the preview URL is constructed as `/lab/files/…` and will 404 under any other Jupyter base URL |

None of these is a bug in the source's own environment. Together they mean the notebooks
are not portable at all — they are configuration files for one Docker image, wearing the
shape of a course. The rebuilt course resolves every path from `__file__` and environment
variables with repo-relative fallbacks, which is exactly what `cosmos_course/config.py`
already does.

### 4.6 `display_video` in notebook 02 references `HTML` and `html` without importing them

Notebook 02 cell 09 ends with:

```python
def display_video(path, width=640):
    data = base64.b64encode(Path(path).read_bytes()).decode("ascii")
    display(HTML(f'<video controls playsinline width="{width}" style="background:#000">'
                 f'<source src="data:video/mp4;base64,{data}" type="video/mp4"></video>'
                 f'<div style="font-family:monospace;font-size:12px">{html.escape(str(path))}</div>'))
```

I verified this directly by extracting every import statement and every `HTML`/`html`
reference from all fourteen code cells of the notebook. The only relevant import is cell
04's `from IPython.display import Image, Video, display` — `HTML` is not among them, and
`html` is never imported anywhere in the notebook. Both names are referenced only inside
this function body, at lines 119 and 121 of the cell.

Calling `display_video` in notebook 02 raises `NameError: name 'HTML' is not defined`.
It is a latent defect rather than an active one because the function is never called:
`display_video` appears exactly once in the notebook, in this definition. Every actual
preview in notebook 02 goes through `show_media`, defined in the same cell, which uses
`IPython.display.Video` and works.

The provenance is unambiguous. Notebook 03 cell 07 contains a byte-identical
`display_video`, and that cell opens with `import base64, html, json` and
`from IPython.display import HTML, Image, display, JSON`. The function was copied from
notebook 03 into notebook 02 without its imports and then never called.

The static validator (`lib/validate_notebooks.py`) cannot catch this — it checks JSON
validity, output cleanliness, kernelspec, header/footer and image links, none of which
involve executing or parsing Python. The e2e runner cannot catch it either, because dead
code does not run. This is a good worked example for the rebuilt course's own tooling:
`tools/nameflow_check.py` exists in the course repo precisely to catch names used before
definition across a notebook's cell sequence.

### 4.7 Three incompatible video-preview helpers, one of which contradicts another

| Notebook | Helper | Mechanism | Cell |
|---|---|---|---|
| 02 | `show_media(images=…, videos=…)` | `IPython.display.Video(path, embed=True)` | 09 |
| 03 | `display_video(path)` | Manual base64 `data:` URL in an `<video>` tag | 07 |
| 04 | `preview(src, crf=28)` | `ffmpeg` transcode to CRF-28 H.264 with `+faststart`, written under the Jupyter notebook root, served over HTTP as `/lab/files/…` | 05 |

Three implementations of one function, with different signatures, different keyword
arguments and different failure modes. A learner who reads the notebooks in order has to
relearn how to look at a video three times.

Worse, notebook 04's implementation carries a comment that directly contradicts notebook
03's approach:

> Model outputs live under `OUTPUT_ROOT` (`/opt/cosmos3-framework/outputs`), which is
> OUTSIDE the Jupyter notebook root, so the browser can't fetch them directly and
> **base64-embedding the whole clip yields a frame that won't play**. Instead we write the
> preview under the served notebook root and let Jupyter stream it over HTTP (with range
> requests), which is what makes play/seek work reliably.

Notebook 03's `display_video` does exactly the thing notebook 04 says does not work, and
`view_run` — the function every generation cell in notebook 03 calls — routes through it.
Either notebook 03's previews are broken at full 720p × 189 frames, or notebook 04's
comment overstates the problem. The package gives no way to tell, because the notebooks
are committed output-clean (§4.16). The rebuilt course has one `show_video` in
`cosmos_course/viz.py` that always transcodes a small preview first, and says so in its
output.

The overlay helpers duplicate less severely but still duplicate: notebook 02's
`_parse_json` (cell 11) and notebook 04's inline JSON handling solve the same problem of
extracting structured output from a model that may or may not wrap it in fences and may or
may not precede it with a `</think>` block.

### 4.8 `create_payload` hides the two settings that cost the most

Notebook 03 cell 07:

```python
FIXED_SAMPLING = {
    "num_steps": 35, "guidance": 6.0, "shift": 10.0, "fps": 24,
    "num_frames": 189, "resolution": "720", "aspect_ratio": "16,9", "seed": 0,
}

def create_payload(name, mode, prompt_rel, image_rel=None, enable_sound=False):
    …
    payload = {"model_mode": mode, "name": name, "prompt": _compact(prompt_path),
               "negative_prompt": negative, "enable_sound": enable_sound, **FIXED_SAMPLING}
```

The function's four parameters are name, mode, prompt and image. Resolution, frame count
and step count — the three numbers that determine how long the run takes and whether it
fits in memory — arrive through a module-level constant that the signature does not
mention. `create_payload` then prints those values back at the learner, which produces the
impression of control without any.

The only guidance is a passing remark in cell 08: "To iterate faster you can lower
`num_frames`, lower `num_steps`, or drop `resolution` to `"256"` in `FIXED_SAMPLING`."
That tells a learner *what* to edit but not what any of it costs. The relationship —
diffusion cost scales as latent tokens × denoising steps, and latent tokens scale with
frames × width × height, so the cost of a resolution bump goes roughly as its square —
is never stated. `cosmos_course/config.py:estimate_generation_cost()` already implements
this and returns a unit count and a ratio against a reference configuration rather than a
fake time prediction.

There is a second, quieter problem: `enable_sound` is a parameter of `create_payload` and
is never passed as `True` anywhere in the notebook. Audio generation is plumbed and
unused. See §4.14.

The defaults themselves are worth flagging. 720p × 189 frames × 35 steps on Cosmos3-Nano
is the single heaviest job anywhere in the source, and it is the *first* thing a learner
runs. On one H100 this is the most likely OOM in the whole package, and the source
provides no fallback, no memory reading and no way to tell an OOM from a guardrail
rejection.

### 4.9 Error messages that cannot be acted on

Notebook 02 cell 07 raises, after twenty minutes:

```python
raise TimeoutError("NIM did not become ready. Check it from a host terminal: "
                   "docker compose -f task1/docker-compose.yml logs cosmos3-reasoner")
```

The learner is inside the lab container. There is no `docker` binary there, no compose
file at that relative path, and the working directory is `/dli/task`, not the repository
root. The advice is correct for the course *author* on a devbox and useless for the
learner. The rebuilt course's `cosmos_course/nim.py` reports NIM state from four
independent sources (container status, HTTP health, driver-reported VRAM, and container
logs) and prints the log tail directly.

More broadly: the source has no failure taxonomy. A generation run can exit zero and
still produce nothing useful, most commonly because the guardrail blanked the output.
Nothing in the source distinguishes "worked", "guardrail rejected", "OOM", "wrong codec"
or "downloaded weights but 403'd on the guardrail". The rebuilt course's
`cosmos_course/checks.py` and `RunResult.diagnose()` exist for this.

### 4.10 Two of the seven reasoning examples depend on a private S3 bucket

Notebook 02 cell 04 maps `"assisted_task"` to `/dli/task/assets/toaster_6sec.mp4`, which
is staged into the `video_assets` volume by the `s3_video_loader` side-car reading
`--recursive s3://dli-lms/data/s-ov-57-v1/videos/` from `task1/video_sources`. That bucket
is DLI-internal. Cells 21 (assisted-task next action) and 23 (physical common sense) both
use it, and cell 04 raises `FileNotFoundError` on a missing asset, so *the notebook fails
at setup* outside DLI infrastructure — not at the cell that needs the clip.

`cosmos_course/assets.py` already substitutes public cookbook clips
(`assisted_task_next_action.mp4` and `physical_plausibility.mp4`, both listed in FACTS §6)
and marks the substitution in the asset table.

### 4.11 Notebook 02's Set-of-Mark section contradicts itself

Cell 26 prose: "Below we mark a curated set of salient subjects in a **robot manipulation
workspace** — the two robot arms, the person, the camera tripod, and the red ball".

Cell 27 code:

```python
MARKS = [
    {"id": 1, "bbox": [300, 430, 480, 700]},   # left robotic arm / gripper
    {"id": 2, "bbox": [820, 420, 990, 700]},   # right robotic arm
    {"id": 3, "bbox": [895,  35, 1010, 120]},   # red apple on the desk
    {"id": 4, "bbox": [270,   0, 465, 215]},   # person standing
]
```

Five subjects promised, four marked. No tripod. The "red ball" of the prose is a "red
apple" in the code. Boxes are hard-coded pixel coordinates valid only for
`robot_153.jpg` at 1280×720, which the code does not check.

This matters more than a typo, because the whole point of the section is that
`subject_id` in the response refers back to a specific mark. If the learner reads the
prose and the model's captions, they will be comparing a four-mark image against a
five-subject description and will not know which of the two is wrong.

### 4.12 Two launch styles for the same entry point, never reconciled

Notebook 03 cells 10, 14 and 19:

```bash
.venv/bin/torchrun --nproc-per-node="$COSMOS3_NUM_GPUS" \
  --master-addr=… --master-port=… -m cosmos_framework.scripts.inference \
  --parallelism-preset=throughput …
```

Notebook 04 cells 09, 13 and 20:

```bash
MASTER_ADDR=… MASTER_PORT=… RANK=0 WORLD_SIZE=1 LOCAL_RANK=0 \
.venv/bin/python -m cosmos_framework.scripts.inference \
  --parallelism-preset=latency …
```

Same module, two launchers, two presets, no explanation of either choice. The learner is
left to guess whether the action modes require the single-process path (they appear to, and
`cosmos_course/models.py` encodes exactly that with its `ACTION_MODEL_MODES` frozenset
selecting the single-process branch in `Generator._build_command`) or whether it is
arbitrary. Notebook 04 cell 09 also mixes flag styles in one invocation:
`--video-save-quality 8` alongside `--image_size 480`, and the latter duplicates a value
already present in the JSON record, with no statement of which wins.

Notebook 03 cell 19 adds a third inconsistency: it runs with `cd "$TRANSFER_DIR"` and a
*relative* `-i specs/edge.json` while every other cell uses absolute paths, and it passes
`--seed 2026` while the spec it reads carries `"seed": 0`. Which one takes effect is not
stated anywhere.

### 4.13 The action layout is described two incompatible ways

Notebook 04 cell 15 comment: the predicted action is `[T-1, 9]`.
Notebook 04 cell 24 comment: "dims 0:3 = end-effector translation deltas (m), 3:9 = 6D
rotation, 9 = gripper" — which is ten dimensions — and the code hedges with
`gripper = action[:, 9] if action.shape[1] > 9 else None`.

Both are right about their own domain: the AV ego-pose action is 9-D and the manipulation
end-effector action is 10-D. The source presents them as though there were one layout,
and the hedge in the code is the only hint that there is not. A learner debugging a
shape mismatch has nothing to work from. The rebuilt course states the two layouts
explicitly, in Lesson 11 for the AV case and Lesson 12 for the manipulation case.

`translation_scale=1.35` in cell 15 is a magic constant with no source, no units and no
sensitivity discussion. It affects every number on the plotted trajectory.

### 4.14 Whole capability areas are absent

**Audio.** `audio_image2video` is a first-class model mode (FACTS §2), Nano and Super
support it (FACTS §1), and the cookbook ships assets specifically for it —
`prompts/text2video/robot_pouring_water_audio.json`,
`prompts/image2video/coastal_road_audio.json`, `images/image2video/coastal_road_audio.jpg`
(FACTS §6). The source plumbs `enable_sound` through `create_payload` and never sets it.

**The guardrail as a subject.** It appears once, as a repository to accept a licence for.
Nothing about what it does, that it runs on both prompt and frames, that it can blank an
output while the run reports success, or that it pulls a further ~3.6 GB on first use
(FACTS §1). The source also never mentions the other two first-run downloads that
`cosmos_course/config.py` records: the Wan2.2 VAE (2.82 GB) and `Qwen/Qwen3Guard-Gen-0.6B`
(1.52 GB).

**Any measurement.** Not one timing, not one `nvidia-smi` reading, not one peak-memory
number in 41 code cells. The only quantitative statements are "expect a few minutes on a
single H100" (nb03 cell 08) and "several minutes" (nb03 cell 18), neither with a way to
check.

**Post-training.** Nothing. No SFT, no LoRA, no dataset format, no configuration.

**Evaluation.** Nothing. No before/after comparison, no metric, no acknowledgement that
`cosmos_framework/evaluation/` is marked `[planned]` and absent from the release
(FACTS §5).

**Model tier choice.** Edge does not appear anywhere in the package. Nano is used for
everything. Super is mentioned twice as an optional multi-GPU curiosity. A single-GPU
learner needs Edge more than either.

**Closed-loop control.** Notebook 04 cell 25 describes it in five sentences of prose and
names the right components. It omits every constraint that makes it hard: FACTS §5 records
that closed-loop simulation eval needs a **separate venv** because `robosuite==1.4.1`,
`mujoco==2.3.7` and `torch<2.6` will not coexist with the training environment. The source
says only that it "needs the framework's `policy-server` extras and a full Isaac Sim
install", which understates it.

### 4.15 Documentation drift the source inherited

The source cites the NVIDIA Open Model License (nb01 cell 05) where the actual licence is
OpenMDW 1.1 (FACTS §1). It uses the `policy` name that upstream prose still uses and the
upstream enum does not (§4.1). Notebook 04 cell 19 fetches from
`github.com/nvidia-cosmos/cosmos-dependencies`, and FACTS §3 notes the framework itself
lives under `NVIDIA/`, not `nvidia-cosmos/`. FACTS §7 lists six upstream documents that are
currently wrong; a rebuilt course should assume more drift by the time it is taught and
should teach learners to check the enum rather than the prose.

`task1/nim/Dockerfile` pins `nvcr.io/nim/nvidia/cosmos3-reasoner:1.7.0`; FACTS §4 records
the latest published tag as **`1.7`**. Whether `1.7.0` still resolves is worth checking
before the first class.

### 4.16 The source's own validation is unvalidated, and its notebooks carry no evidence

The e2e README's closing section says, in full:

> Initial scaffold (issue #2). Before relying on it in CI, do a first manual run against a
> fresh build and tune: which cells need `skip-e2e` tags, the idle thresholds, and whether
> notebook 01 should be included.

So the harness had not been run when the package was cut. That is honest and it is also
the reason nothing in this audit can be checked against a recorded run.

Compounding it: `validate_notebooks.py` enforces that every notebook is committed
output-clean, and all four are. There is not a single cell output, execution count, image,
error or timing anywhere in the package. Everything in §4 that concerns *runtime*
behaviour — whether notebook 03's base64 previews actually play, whether the 720p × 189
default OOMs on one H100, whether the pinned framework commit predates the `wam` rename —
is inference from reading code, not observation. The rebuilt course should keep the
output-clean discipline for the shipped notebooks and separately retain executed copies as
validation evidence.

### 4.17 The stated duration does not match the measured duration

`edX/README.md` records the DLI convention that Course Duration is "usually 02:00, or
08:00". The e2e README says the three-notebook run "takes ~2-3 hours (first-run gated
weight downloads dominate)". Those are the same notebooks a learner runs, on the same
hardware, and the download is not optional. A two-hour lab whose automated execution takes
two to three hours cannot be completed in its advertised time on first run. The rebuilt
course budgets download time explicitly and moves the largest pulls into a setup step that
runs before the teaching starts.

### 4.18 The source contains no exercises

Every one of the 41 code cells runs to completion with no learner input. There is no
question to answer, no parameter to choose, no failure to diagnose, no artefact to
produce, and no criterion for having finished. It is a well-written demonstration
walkthrough of about two hours. Turning it into 35–40 hours of hands-on work is
therefore mostly *authoring*, not *adaptation* — roughly a quarter of the new course can
derive from this material and the rest has to be written. §3 of `03_CURRICULUM_MAP.md`
quantifies that.

---

## 5. Code and dependencies likely to cause trouble on an H100

| Item | Where | Why it bites on one H100 |
|---|---|---|
| `CUDA_VISIBLE_DEVICES=1` | nb03 c04, nb04 c03 | Selects a device that does not exist; `device_count()` becomes 0 and the failure surfaces later, somewhere else |
| `http://cosmos3-reasoner:8000` | nb02 c06 | Compose service DNS. Outside Compose this is a `ConnectionError` after a 20-minute poll |
| NIM resting VRAM | design of the NIM, not the source | The NIM reserves a large fraction of *currently free* VRAM for KV cache at startup. `cosmos_course/nim.py` records that the nano reasoner's FP8 weights are ~8 GB (FACTS §4) but the container settles at 60–75 GB on an idle 80 GB card. Start the NIM first and the generator OOMs even though both "fit" on paper |
| Generator NIM | not used by the source, but learners find it | FACTS §4: `nvcr.io/nim/nvidia/cosmos3-generator` has a per-device floor of ≥79 GiB for nano at any precision. There is no fraction that makes it share |
| 720p × 189 frames × 35 steps on Nano | nb03 c07 `FIXED_SAMPLING` | Heaviest job in the package and the first one a learner runs. Nano inference is documented at 32 GB (FACTS §3), but that figure has no stated geometry attached, so it is not a budget you can plan against |
| `cu130-train` + `pytorch:25.09-py3` | Dockerfile | Requires a CUDA 13 driver. FACTS §3: CUDA ≥ 12.8 is the floor and 13.0 is recommended; on a 12.8 driver you need `cu128-train` and the `25.06-py3` base. Getting this pair wrong produces confusing runtime CUDA errors, not a clean install failure |
| `LD_LIBRARY_PATH=` cleared | every `%%bash` cell; the kernel spec | The NGC PyTorch image's bundled libtorch shadows the venv's. Real, load-bearing, and it will also bite a bare-metal learner who has an NGC image or a system CUDA in the path |
| `HF_HUB_DISABLE_XET=1` | Dockerfile, compose | The Xet transfer backend stalls mid-transfer on large Cosmos weight shards and leaves `*.incomplete` blobs. Symptom is a download that appears to hang at 60–90 % |
| flash-attn build | `uv sync --all-extras` | FACTS §3: Hopper selects `flash-attn-3-nv`. On a bare host this is the longest and most fragile step of setup and needs a matching toolchain |
| `vllm==0.19.1` conflict | FACTS §3 | The `vllm` dependency group conflicts with every `cu*` group. The vLLM reasoner fallback cannot live in the framework venv; it needs its own |
| `imageio_ffmpeg` | nb04 c05 | Installed by the Dockerfile only into the `cosmos3` venv. A bare-metal learner will hit `ModuleNotFoundError` in the preview helper |
| Unpinned `openai` | nb02 c04 | Content-part schema and `extra_body` handling are version-sensitive; pin it |
| OpenCV decode in the NIM | nb02 c09 | AV1 and some HEVC return metadata and zero frames; the server answers 422. The `ensure_h264` workaround is correct and should be carried verbatim |
| `robosuite` / `mujoco` / `torch<2.6` | nb04 c25 (implied) | FACTS §5: closed-loop eval needs a second venv. This is the single biggest hidden cost in Module 3 |
| Disk | not stated in the source | FACTS §3: ~150 GiB free for a first full run (~90 GiB HF cache, ~20 GiB uv cache, ~30 GiB outputs). Nano alone is 34.9 GB and Super is 133 GB (FACTS §1). The source hides all of this inside a Docker volume |
| Guardrail and companions | never mentioned | ~3.6 GB guardrail (gated), 2.82 GB Wan2.2 VAE, 1.52 GB Qwen3Guard-Gen-0.6B, all pulled on first generation |
| Root-owned outputs | `scripts/cleanup.sh` | The container runs as root and writes into a bind mount, so cleanup needs `sudo`. Bare metal avoids this; a learner using Docker locally will meet it |

---

## 6. Assumptions this audit makes

These are stated so a reader can disagree with them specifically.

The audit is a static read. Nothing in the package was executed, because the package
cannot run outside DLI infrastructure (§4.10) and the target hardware is a single H100
rather than the two the notebooks assume. Every runtime claim is labelled as inference
where it is one.

`COSMOS3_FACTS.md` is treated as correct, with its August 2026 verification date. Where
the source and that file disagree, the source is the one that has drifted. If the facts
file is itself out of date on some point, this audit inherits that error.

The notebooks are assumed to have worked at the time they were written, against the
framework commit and cookbook commit pinned in the Dockerfile. That assumption is what
makes §4.1 a *drift* problem rather than an authoring mistake, and it is unverifiable
from the package alone.

The target learner is assumed to be technically capable — comfortable with Python, the
command line and Git — but new to Cosmos 3, and to have exactly one H100 80 GB with root
or Docker access, x86-64, CUDA ≥ 12.8, and roughly 150 GiB of free disk.

The `cosmos_course` package in the rebuilt course repository is assumed to be the
intended home for every helper the source defines inline. Where this audit says "the
rebuilt course does X", X is either already implemented there (verified by reading
`config.py`, `nim.py`, `models.py`, `specs.py`, `checks.py`, `measure.py`, `viz.py`,
`assets.py`) or is scheduled in `02_PROPOSED_CURRICULUM.md`.

Time estimates in the companion documents are estimates. The only compute-time figure
anywhere in the supplied material is the e2e README's "~2-3 hours" for three notebooks,
and that figure is dominated by a first-run download whose speed depends entirely on the
learner's network.
