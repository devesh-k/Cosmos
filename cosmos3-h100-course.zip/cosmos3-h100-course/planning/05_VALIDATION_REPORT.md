# Validation report

*Physical AI with Cosmos 3 on a single H100 — what was verified, how, and what was not.*

---

## The headline, without hedging

**No notebook in this course has been executed on an H100. No notebook in this course has
been executed on any GPU at all.**

The course was built in an x86-64 Linux sandbox with:

- no GPU and no NVIDIA driver — `nvidia-smi` is not on `PATH`
- no CUDA
- no PyTorch — `import torch` raises `ModuleNotFoundError: No module named 'torch'`
- no Docker — `command -v docker` returns nothing
- no Cosmos Framework checkout and no model weights
- restricted network access

```
$ uname -srm
Linux 6.8.0-136-generic x86_64

$ python3 --version
Python 3.10.12

$ python3 -c "import torch"
ModuleNotFoundError: No module named 'torch'

$ command -v nvidia-smi || echo "not on PATH"
not on PATH

$ command -v docker || echo "not installed"
not installed
```

Everything that requires model weights, CUDA kernels, the Cosmos Framework, or the
Reasoner NIM was **not executed**. That means every generation run, every training run,
every NIM call, every VRAM measurement and every timing figure in this course is
**unverified by execution**. Where those appear in lesson text they are labelled as
predictions, estimates or things for the learner to measure — but the labels are the
author's discipline, not a substitute for a real run.

What follows is what *was* verified, with the method and the actual output. Nothing is
claimed as passing that was not run.

---

## 1. Static notebook validation

**Method.** `python3 scripts/validate_notebooks.py` over all 40 notebooks (20 lessons,
20 solutions). Sub-second, no GPU, no kernel, executes nothing.

**Checks applied.** From the script's own docstring, which is the authoritative list:

*Errors (exit 1):*
- valid JSON and valid nbformat 4
- kernelspec name is `cosmos3-h100`
- no committed cell outputs
- no non-null `execution_count`
- no credential-shaped strings — `hf_…`, `nvapi-…`, `sk-…`
- no `"model_mode": "policy"` — upstream renamed it to `wam`, and the source DLI course's
  notebook 04 uses the dead name (COSMOS3_FACTS.md §2)
- no `CUDA_VISIBLE_DEVICES=1` — this is a one-GPU course and that hides the only GPU.
  Allowed only in cells tagged `teaching-antipattern`, where the lesson is deliberately
  showing the mistake
- no absolute foreign paths — `/dli/task`, `C:\Users\`, `/home/<someone-else>`
- every relative asset reference resolves on disk

*Warnings (printed, exit 0; promoted to errors by `--strict`):*
- a lesson notebook with no learning objectives
- a lesson notebook with no exercise
- empty cells, `!pip install`, other smells

*Notes (printed, never counted):*
- observations about the machine running the script rather than about any notebook

**Actual output:**

```
========================================================================
Notebook validation — 40 notebook(s)
========================================================================
  note  nbformat schema: nbformat is not installed, so JSON-schema validation was skipped; every other check ran
        pip install nbformat   (or: python3 -m pip install -e .)

  ok    00_environment_check.ipynb
  ok    01_cosmos3_mental_model.ipynb
  …
  ok    19_capstone_synthetic_data_flywheel.ipynb
  ok    solutions/00_solutions.ipynb
  …
  ok    solutions/19_capstone_reference.ipynb

------------------------------------------------------------------------
  0 error(s), 0 warning(s)
  Clean.
```

Exit code `0`.

**Caveat, stated because the tool states it.** `nbformat` was not installed in the
sandbox, so the JSON-schema validation step was skipped. Every other check ran. The
structural properties that schema validation would have caught were checked directly
instead — `nbformat`/`nbformat_minor` are 4/5, and all 2,083 cells across the 40 notebooks
carry an `id` field (see §9). This is reported as a *note* rather than a warning
deliberately: a release gate that goes red because a CI image is missing a dependency
teaches people to ignore the gate.

---

## 2. Syntax

**Method.** `python3 tools/syntax_check.py` — extracts every code cell from every
notebook and runs `ast.parse` on it. Parsing only; nothing is imported or executed.

**Actual output (abridged; every line reads `ok`):**

```
[ok  ] 00_environment_check.ipynb  (24 code cells)
[ok  ] 01_cosmos3_mental_model.ipynb  (26 code cells)
…
[ok  ] 19_capstone_synthetic_data_flywheel.ipynb  (38 code cells)
[ok  ] 00_solutions.ipynb  (14 code cells)
…
[ok  ] 19_capstone_reference.ipynb  (34 code cells)

0 syntax error(s)
```

Exit code `0`. **876 code cells** parsed in total — 532 in the twenty lessons, 344 in the
twenty solution notebooks.

**What this does not prove.** That the code is correct, that the names it references
exist, or that it would run. It proves only that a Python parser accepts it.

---

## 3. Cross-cell name flow

**Method.** `python3 tools/nameflow_check.py` — walks each notebook top to bottom,
maintaining the set of names that would be bound at each point (imports, assignments,
function and class definitions, comprehension and `with`/`for` targets, function
parameters), and flags a load of a name that has not yet been bound. This is a static
approximation of "run all cells in order", which is how a learner will actually use the
notebook.

**Actual output (abridged):**

```
[ok  ] 00_environment_check.ipynb
[ok  ] 01_cosmos3_mental_model.ipynb
…
[ok  ] 19_capstone_reference.ipynb

0 potential undefined-name issue(s)
```

Exit code `0`.

**Why it matters.** Notebook authoring is exactly the workflow that produces
use-before-definition bugs invisible in review: a cell is edited, moved, or split, and the
name it depended on is now defined below it. The author's kernel still has the name in
memory, so the notebook works for the author and fails for everyone else. This check is
the only defence available without a GPU.

**What it does not prove.** That the *values* are right, that a function returns what the
next cell expects, or that anything imported from `cosmos_framework` exists.

---

## 4. Solutions cross-check

**Method.** `python3 tools/check_solutions.py` — for every lesson, resolves the
`solution_ref` recorded in the notebook and confirms the referenced solutions notebook
exists, is well-formed, and contains the expected number of worked solutions.

**Actual output:**

```
  ok    solutions/00_solutions.ipynb        30 cells (14 code)  3 solutions
  ok    solutions/01_solutions.ipynb        32 cells (16 code)  3 solutions
  ok    solutions/02_solutions.ipynb        33 cells (17 code)  3 solutions
  …
  ok    solutions/18_solutions.ipynb        32 cells (14 code)  3 solutions
  ok    solutions/19_capstone_reference.ipynb  71 cells (34 code)  [capstone reference — structure not checked here]

20 lesson(s), 20 referenced solutions notebook(s)

0 problem(s)
```

Exit code `0`. Every `solution_ref` resolves. Lessons 00–18 each have exactly **three**
worked solutions; Lesson 19's counterpart is a full reference implementation of the
capstone rather than three discrete exercise answers, and the tool says so rather than
pretending to check a structure that does not apply.

**What this does not prove.** That any solution is *correct*. A solution that calls the
generator and inspects its output cannot be checked without a GPU. Solutions were checked
for syntax and name flow (§2, §3) like every other notebook, and no further.

---

## 5. Package import and API

**Method.** Direct execution of the pure-Python parts of `cosmos_course` in the sandbox
interpreter (Python 3.10.12). These functions have no GPU, CUDA or network dependency by
design — that separation is why they can be tested here at all.

### Import and module inventory

```
$ python3 -c "import cosmos_course; print(cosmos_course.__version__)"
1.0.0

$ python3 -c "import cosmos_course as c; print(repr(c.missing_modules()))"
{}
```

`missing_modules()` returns empty — every submodule (`config`, `models`, `nim`, `specs`,
`measure`, `checks`, `viz`, `assets`, `finetune`, `pipeline`) imports cleanly. The
top-level `__all__` exports 107 names, and a programmatic sweep confirms every name in
every submodule's `__all__` is re-exported by `cosmos_course/__init__.py`:

```
submodule __all__ names NOT re-exported by cosmos_course/__init__.py: none
len(cosmos_course.__all__) = 107
```

`python3 -m py_compile scripts/*.py cosmos_course/*.py tools/*.py` also exits `0`.

### `estimate_sft_memory()` — executed

```
$ python3 -c "import cosmos_course as c; print(c.estimate_sft_memory('Cosmos3-Nano'))"
SFT memory estimate — Cosmos3-Nano
==============================================================
  total parameters        16.0 B
  trainable parameters    8.00 B

    bf16 weights (all params)    32.0 GB
    fp32 master (trainable)     32.0 GB
    AdamW m (trainable)         32.0 GB
    AdamW v (trainable)         32.0 GB
    gradients (trainable)       32.0 GB
    EMA fp32 copy               32.0 GB
    --------------------------------
    state subtotal             192.0 GB

  card                    80.0 GB
  reserve (ctx, frag)      4.0 GB
  left for activations  -116.0 GB

  VERDICT: WILL NOT FIT. State alone needs 192 GB on a 80 GB card.
```

and for Edge with the `keys_to_select` reduction to ~2B trainable:

```
  state subtotal              48.0 GB
  left for activations    28.0 GB

  VERDICT: PLAUSIBLE. 28 GB left for activations.
    - Plausible is not proven. Activation memory scales with the token cap; start low
      and raise it until it fails, then back off.
```

The arithmetic executes and is self-consistent with COSMOS3_FACTS.md §5. **The physical
claim it makes is unverified** — see §10.

### `estimate_generation_cost()` — executed

```
$ python3 -c "import cosmos_course as c, json; print(json.dumps(
      c.estimate_generation_cost(num_frames=61, resolution='256',
                                 num_steps=10, model='Cosmos3-Edge'), indent=2))"
{
  "width": 256,
  "height": 144,
  "num_frames": 61,
  "num_steps": 10,
  "latent_tokens": 2160,
  "cost_units": 21600,
  "relative_to_480p_121f_35s": 0.01,
  "warnings": []
}
```

Resolution-tier lookup, aspect-ratio decomposition and the relative-cost ratio all
compute. The units are **relative**, not seconds, and the function does not claim
otherwise.

### `vram_budget()` — executed

```
$ python3 -c "import cosmos_course as c, json; print(json.dumps(c.vram_budget(80.0), indent=2))"
{
  "total_gb": 80.0,
  "reserve_gb": 3.0,
  "nim_weights_fp8_gb": 8.0,
  "generator": { "Cosmos3-Edge": 12, "Cosmos3-Nano": 32 },
  "take_turns": {
    "nim_alone_fraction": 0.96,
    "note": "Stop the NIM, then generate. No compromise on either side."
  },
  "coexist_with_edge":  { "nim_budget_gb": 65.0, "nim_fraction": 0.81, "feasible": true },
  "coexist_with_nano":  { "nim_budget_gb": 45.0, "nim_fraction": 0.56, "feasible": true }
}
```

The Edge figure of 12 GB inside this output is **this course's working estimate, not an
NVIDIA figure** — Edge is not listed in the framework's VRAM table (FACTS §3). The Nano
figure of 32 GB is NVIDIA's.

### `build_train_command()` — executed

```
$ python3 -c "…build_train_command('examples/toml/sft_config/vision_sft_edge.toml',
      nproc=1, overrides={'model.ema.enabled': False,
                          'dataloader.max_num_tokens_after_packing': 8192},
      dataset_path='/data/bridge', base_checkpoint_path='/ckpt/edge',
      wan_vae_path='/ckpt/wan_vae')"

torchrun --nproc_per_node=1 -m cosmos_framework.scripts.train \
  --sft-toml=examples/toml/sft_config/vision_sft_edge.toml \
  -- model.ema.enabled=false dataloader.max_num_tokens_after_packing=8192

env: {
  "IMAGINAIRE_OUTPUT_ROOT": "outputs/train",
  "PYTHONPATH": ".",
  "PYTORCH_ALLOC_CONF": "expandable_segments:True",
  "LD_LIBRARY_PATH": "",
  "PYTHONNOUSERSITE": "1",
  "DATASET_PATH": "/data/bridge",
  "BASE_CHECKPOINT_PATH": "/ckpt/edge",
  "WAN_VAE_PATH": "/ckpt/wan_vae",
  "_COSMOS_COURSE_WARNING": "no venv at …/cosmos-framework/.venv — run scripts/setup.sh first"
}
```

The `--` separator is present, all three `${oc.env:…}` variables are set, booleans are
lowercased for Hydra, and the function detects and reports the missing framework venv
rather than silently producing a command that cannot run. **The command string was
constructed, not executed.**

### `validate_spec()` — executed

```
$ # a well-formed spec
> cc.validate_spec({"name":"pour_water","model_mode":"text2video",
                    "prompt":"a robot pours water into a glass","num_frames":61,
                    "resolution":"256","aspect_ratio":"16,9","num_steps":10})
[]

$ # the dead mode plus a colon in the aspect ratio, strict=False
> cc.validate_spec({"name":"x","model_mode":"policy","prompt":"x",
                    "aspect_ratio":"16:9","num_frames":61,"resolution":"256"},
                   strict=False)
- mode 'wam' requires missing field(s): domain_name, vision_path
- aspect_ratio '16:9' is not one of ['1,1', '16,9', '3,4', '4,3', '9,16'].
  Did you mean '16,9'? The separator is a comma.

$ # a missing required field raises, rather than returning a list, under strict=True
ValueError: Inference spec is invalid:
  - 'name' is required; it becomes the output subdirectory.
```

Two behaviours worth recording. First, `policy` is silently normalised to `wam` before
validation, which is why the first error message talks about `wam`'s required fields —
confirmed by constructing an `InferenceSpec` directly and reading back
`spec.model_mode == 'wam'`. Second, the aspect-ratio error is checked against
`config.ASPECT_RATIOS = ('16,9', '9,16', '1,1', '4,3', '3,4')` and suggests the correction,
because a colon there is the single most likely typo and the framework's own error for it
is unhelpful.

### `check_dataset()` — executed

```
$ python3 -c "import cosmos_course as c, json;
             print(json.dumps(c.check_dataset('/tmp/nope', kind='lerobot'), indent=2))"
{
  "root": "/tmp/nope",
  "kind": "lerobot",
  "ok": false,
  "problems": ["/tmp/nope does not exist"],
  "warnings": [],
  "stats": {}
}
```

The absent-path branch behaves correctly and returns a structured report rather than
raising. **The LeRobot v3.0 structural checks — chunked Parquet, AV1 MP4 shards,
`meta/info.json`, `meta/stats.json`, `meta/tasks.parquet`, `meta/episodes/` — were not
exercised, because no LeRobot dataset was available in the sandbox.**

---

## 6. Shell scripts

**Method.** `bash -n` (parse, do not execute) on every shell script, plus a real
invocation of `setup.sh --check-only`, which is designed to be side-effect free.

```
$ for f in scripts/*.sh; do bash -n "$f" && echo "  ok  $f"; done
  ok  scripts/cleanup.sh
  ok  scripts/run_all.sh
  ok  scripts/setup.sh
```

**`setup.sh --check-only` — actually run, actual output:**

```
=== Stage 0/5  preflight  (~5 s, 0 GB) ===
  -> Confirming this machine can run the course before anything is downloaded.
  ok   Linux
  ok   x86_64
  ok   glibc 2.35  (>= 2.35)
  ok   Python 3.10.12  (>= 3.10)
  FAIL nvidia-smi is not on PATH, so no NVIDIA driver is installed.
         Install the driver (>= 580 for CUDA 13, >= 525 for CUDA 12.8): …
  warn docker is not installed. Lessons 02-05 (the Reasoner NIM) need it. …
         Lesson 02 documents a no-Docker fallback (model_mode='reasoner' through
         the framework), so this is a warning, not a failure.
  FAIL only 7 GB free on the filesystem holding …/cosmos-framework; 100 GB is the minimum.
         Budget, from COSMOS3_FACTS.md section 3: …
  warn git-lfs not found. Cookbook media will arrive as pointer files: …

fatal: 2 preflight problem(s). Fix them and re-run — nothing has been
       downloaded or changed. Use --check-only to re-check without side effects.
```

This is the **expected and correct** result on a GPU-less sandbox with 7 GB free, and it is
the most useful evidence in this section: preflight correctly distinguished four platform
facts it could satisfy from two hard failures and two warnings, produced an actionable
remediation for each, reported the disk budget by line item, and exited without touching
anything. The severity split is also right — no driver and no disk are fatal; no Docker and
no git-lfs are warnings, because the course has documented fallbacks for both.

**Not verified.** Stages 1–5 of `setup.sh` (uv install, framework clone and `uv sync`,
kernel registration, cookbook clone, NGC login) were never run — every one of them needs
network, disk, or both. `run_all.sh` and `cleanup.sh` were parsed but never executed;
`run_all.sh --dry-run` needs a Jupyter kernel to enumerate against.

---

## 7. Upstream conformance

**Method.** Every fact in `assets/reference/COSMOS3_FACTS.md` was checked against a
primary NVIDIA source in August 2026 — the Hugging Face model API, the model cards, the
`cosmos-framework` repository source (not its prose documentation), the cookbook checkout,
the NGC catalogue and the NIM support matrices. The full source list is FACTS §8. That file
is the single source of truth for the course: where a lesson, a lecture script or a helper
contradicts it, the facts file wins.

The corrections applied to the source course, each traceable to a primary source:

**`policy` → `wam`.** The source's notebook 04 uses `"model_mode": "policy"`. Upstream
renamed it. Three independent confirmations were required before the change was made:
`ACTION_MODEL_MODES = frozenset({FORWARD_DYNAMICS, INVERSE_DYNAMICS, ModelMode.WAM})`; the
defaults directory contains `defaults/wam/` and no `defaults/policy/`; and the shipped
inputs `action_policy_av.json` and `action_policy_robot.json` both contain
`"model_mode": "wam"` — only the *filenames* still say policy. `docs/inference.md`,
`docs/faq.md` and the action cookbook README all still say `policy`. The rule adopted was:
trust the enum, not the prose.

**The gating premise.** The source spends an entire notebook and eleven screenshots on
accepting gated licences for five repositories. `https://huggingface.co/api/models?author=nvidia&search=Cosmos3`
returns `gated: false` for all nine Cosmos3 repos. The only remaining gated repository is
`nvidia/Cosmos-Guardrail1`, which the generator enables by default. One click, not five.
The source's licence claim was also wrong: it is **OpenMDW 1.1**, not the NVIDIA Open Model
License.

**Transfer is not a model mode.** It runs as `model_mode: "video2video"` plus a
control-hint block. `TransferHintKey` defines exactly four hints — `edge`, `blur`, `depth`,
`seg` — and the cookbook ships a fifth asset family, `wsm`, that uses the same mechanism
without being a member of the enum.

**Edge is 4B.** `nvidia/Cosmos3-Edge` is 3,858,999,728 parameters by the safetensors index,
dense (not MoT), ~9.1 GB, ungated, 480p maximum, no audio, no transfer. It is absent from
the source course entirely and is the correct default for one GPU. Along with it, the
naming trap was documented: NVIDIA calls the tiers "Nano (8B)" and "Super (32B)" while
Hugging Face reports 16B and 64B, and both are correct — budget inference against the
active count, training against the total, because every parameter needs optimizer state.

**The `pose_utils` module move.** The source imports
`cosmos_framework.data.vfm.action.pose_utils`. Upstream it is now
`cosmos_framework.data.generator.action.utils.pose_utils`. Lesson 11 probes for **both**
paths rather than hard-coding either, which is the only defensible response to a module
that has already moved once.

**The `raw.githubusercontent.com/…/main/…` stale-cache trap.** Verifying the mode enum by
fetching the plain `.../main/...` URL serves a stale cached copy that still shows
`POLICY = "policy"`. The `.../refs/heads/main/...` form serves the current file. This cost
real time to find and is called out in FACTS §2 and §7, in the README troubleshooting
table, and in the lecture script for Lesson 12.

**Standing regression check.** `scripts/smoke_test.py` tier 2 asserts against the learner's
own checkout that `ModelMode` contains `wam` and does **not** contain `policy`. If that
goes red, upstream drifted and the course needs updating. It was written but, having no
framework checkout, **has never actually run against a real `ModelMode`** — in the sandbox
it reports `[skip] ModelMode contains wam — no checkout at …/cosmos-framework`.

**Limitation.** All of the above is a *documentation* check, performed by reading upstream
source. None of it was confirmed by importing `cosmos_framework` and inspecting the enum
at runtime, because the framework was never installed.

---

## 8. Audio pipeline

The lecture-audio agent verified this pipeline by execution, which makes it the
best-evidenced component in the repository.

**Verified by running it.** `python3 scripts/make_lecture_audio.py --self-test` exits `0`
with every assertion passing across eight groups:

```
[1] markdown -> speech on a fixture containing every construct   16 PASS
[2] chunking                                                     14 PASS
[3] segments and pauses                                           3 PASS
[4] audio assembly (real ffmpeg, tones standing in for speech)    6 PASS
[5] pure-python WAV join (the no-ffmpeg path, e.g. bare Windows)  5 PASS
[6] playlist and index with stand-in audio                       10 PASS
[7] resume and skip logic                                         5 PASS
[8] argument normalisation                                        7 PASS

SELF-TEST PASSED: every check succeeded.
```

Group [4] is the load-bearing one: real `ffmpeg` (4.4.2) concatenated three generated tone
segments into an actual MP3, and the test then asserted on the **measured** result — the
file exists and is non-trivial, its duration is 4.50 s as predicted, and it is mono MP3 at
24 kHz. That is a real artefact with a measured duration, not a mocked return value.

**Verified across all twenty real scripts.** `--dry-run` processed every lecture and
reported:

```
  lesson                                  words  chunks  longest     est.  action
  00_environment_check                     1892      34      628  12m 57s  build
  …
  19_capstone_synthetic_data_flywheel      1953      27      723  13m 18s  build
  --------------------------------------------------------------------------------
  TOTAL                                   38328                 4h 21m 58s

  Text conversion: clean. No markdown survived into the spoken text.
```

Markdown stripping ran over all twenty scripts with zero residue, chunking produced 27–36
chunks per lecture with the longest at 1,005 characters against a 1,400-character limit,
and the word counts reconcile with the table in `lectures/README.md`.

**Not verified.** No real TTS voice was ever synthesised — `edge-tts` needs network access
the sandbox does not have, and `kokoro`/`piper` need model downloads. The audio assembly
test used generated tones as a stand-in for speech, which validates the concatenation, the
sample-rate handling and the container format, but not the speech itself. **The PowerShell
script `scripts/make_lecture_audio.ps1` was never executed** — the sandbox is Linux, and it
depends on the Windows SAPI voice stack. It was reviewed by reading, not by running. The
4 h 22 m total is computed from word counts at 150 wpm, not measured from rendered audio;
real TTS output will differ, probably by several minutes either way.

---

## 9. Bugs found and fixed during the build

These are real defects that existed in the tree and were corrected. They are recorded
because a validation report that only lists successes is not evidence of anything.

**Missing nbformat 4.5 cell `id` fields.** The notebook builder emitted cells without an
`id` key. In `nbformat` 4.5 `id` is required on every cell, so the notebooks were nominally
schema-invalid; JupyterLab tolerates it but round-trips them with generated ids, which
means the first save produces a diff touching every single cell and makes review
impossible. `tools/nbbuild.py` now assigns a deterministic `_cell_id(kind, text)` at
construction time. Verified: `nbformat` 4.5 declared, and **0 of 2,083 cells across all 40
notebooks are missing an `id`**.

**`specs.py` imported a constant `config.py` did not define.** A plain `ImportError` on
`import cosmos_course`, which would have broken the very first cell of Lesson 00 and taken
the whole course with it. It survived initial review because nothing imported the package
end-to-end until the smoke test was written. `specs.py` now imports exactly
`ASPECT_RATIOS`, `MAX_FRAMES_BY_TIER`, `RESOLUTION_TIERS`, `estimate_generation_cost` and
`resolution_wh`, all of which exist. This is the class of bug that `missing_modules()`
returning `{}` now guards against.

**`aspect_ratio` validated against the wrong constant.** `validate_spec()` checked the
aspect ratio against the resolution-tier list rather than `ASPECT_RATIOS`. The effect was
the worst kind: every valid aspect ratio was rejected, and — far more dangerous — the error
message named the wrong set of valid values, so a learner following the message would have
made the spec *more* wrong. Both constants are short string tuples, so the type checker had
nothing to say. Now fixed and confirmed by execution: `'16:9'` is rejected against
`['1,1', '16,9', '3,4', '4,3', '9,16']` with the suggestion "Did you mean '16,9'? The
separator is a comma."

**`build_train_command()` omitted the Hydra `--` separator and three `${oc.env:…}`
variables.** Two independent defects in one function. Without the bare `--`, `torchrun`
consumed the Hydra overrides as its own arguments and either errored obscurely or silently
dropped them — meaning `model.ema.enabled=false`, the single most important override for
fitting on one card, would have been ignored while appearing to be applied. Separately, the
shipped TOMLs interpolate `DATASET_PATH`, `BASE_CHECKPOINT_PATH` and `WAN_VAE_PATH` through
OmegaConf's `${oc.env:…}`; unset, OmegaConf fails at config-resolution time with an error
that points at the TOML rather than at the missing environment. Both fixed, and the
function now names any of the three that are still unset.

**`read_toml()` was broken on the declared Python 3.10 floor.** It used `import tomllib`,
which is standard library only from 3.11. Both `pyproject.toml` and the Cosmos Framework
declare `requires-python = ">=3.10"`, so the function would have raised `ModuleNotFoundError`
on a conforming interpreter — and the sandbox that built this course runs 3.10.12, which is
how it was caught. It now falls back to `tomli`, with `tomli>=2.0,<3; python_version <
"3.11"` added to both `requirements.txt` and `pyproject.toml`, and raises an actionable
`ImportError` if neither is available.

**Names in `config.__all__` were not re-exported by `__init__.py`.** The package's public
surface disagreed with itself: `from cosmos_course import X` failed for names the submodule
advertised as public, so notebook cells that followed the documented API raised
`ImportError`. Fixed, and now enforced by a sweep across every submodule's `__all__`, which
currently reports `none` missing against a top-level `__all__` of 107 names.

The common thread is worth stating: **five of these six were invisible to code review and
visible immediately on execution.** Every one was found by running something. That is the
strongest available argument for treating §10 as urgent rather than as a formality.

---

## 10. What has NOT been validated, ranked by risk

Ranked from "most likely to cost you a day" downward.

### 1. Every generation run and every training run — the whole point of the course

Not one `Generator.run()`, not one `torchrun`, not one NIM request. The subprocess
construction, argument marshalling and output-parsing paths in
`cosmos_course/models.py`, `specs.py` and `finetune.py` have been checked for syntax, names
and shape, and never once against a real framework process. Expect the first end-to-end run
to surface argument-name and output-path mismatches. This is the single largest gap and
everything below is a detail by comparison.

### 2. Whether the single-GPU `vision_sft_edge` fine-tune fits at all — Lesson 17

NVIDIA documents **no single-GPU training path**; the smallest documented claim is that Edge
"also fits a 4-GPU node". The arithmetic here — `optimizer.keys_to_select` reducing to ~2B
trainable, ≈45–50 GB of state, ~28 GB left for activations — is sound and is **entirely
this course's extrapolation**. It has never been demonstrated. It also depends on cutting
`max_num_tokens_after_packing` from its 8-GPU value of 45,056 to something much smaller,
disabling EMA (which defaults to `true` in the shipped TOMLs), and turning off
`torch.compile` — three changes whose combined effect on throughput is unknown. Teach it as
an experiment with a predicted outcome. If it OOMs, that is a result, and the lesson's
artefact is designed to capture the failure.

### 3. The NIM memory-capping environment variable name

`cosmos_course/nim.py` sets `NIM_MEMORY_ENV = "NIM_MAX_GPU_MEMORY_UTILIZATION"` and states
plainly that this **could not be verified against a running NIM 1.7 container**. It is a
best-effort guess for a vLLM-backed VLM NIM. `discover_memory_env()` exists precisely to
settle it: it runs `docker run --rm <image> --help` and greps the output against
`NIM_MEMORY_ENV_CANDIDATES = ('NIM_MAX_GPU_MEMORY_UTILIZATION',
'NIM_GPU_MEMORY_UTILIZATION', 'NIM_KVCACHE_PERCENT', 'NIM_RELAX_MEM_CONSTRAINTS',
'VLLM_GPU_MEMORY_UTILIZATION')`. Run it once on the H100 and correct the constant. Whatever
it finds, **trust the observed VRAM in `nim_status()` over any flag** — a cap that is
silently ignored looks exactly like a cap that works until you try to generate.

Related and equally unverified: the claim that the NIM settles at **60–75 GB** resident on
an idle 80 GB card. That is an estimate, not a published number. Lesson 02 has learners
measure it. If your measurement differs materially, your measurement wins.

### 4. Whether reduced-mode capstone really lands in 45–60 minutes

Lesson 19 advertises a 45–60 minute unattended run in reduced mode, with `budget_minutes`
set to 90 in the reduced profile. The profile is concrete — Cosmos3-Edge at the `256` tier,
61 frames, 10 steps, 3 sources × 3 variants, batch size 3, judge at 2 fps — but the
wall-clock figure is authorial judgement scaled from nothing, because no generation has
ever been timed.

**What happens on an overrun, precisely.** `BUDGET_MIN` is not enforced anywhere during the
run. `cosmos_course/pipeline.py` has no wall-clock check at all — `StageClock` accumulates
seconds and `run_stage` times a unit of work, and neither has a deadline. The only place
the budget appears at run time is at the end of `check_stage_5()`, after the pipeline has
finished:

```python
if BUDGET_MIN and wall > BUDGET_MIN * 60:
    print(f"  note: criterion S7 wanted {BUDGET_MIN} min, this took ...")
```

It prints a note and carries on; `check_stage_5` still returns True and criterion S7 is not
asserted. So an overrun costs you time and a line of output, not the run. There *is* a
budget that raises — `MAX_UNITS_BUDGET` in `check_stage_3()` — but it is a **cost-unit**
budget on the specs, checked before any GPU time is spent, and it exists to catch a spec
that is secretly bigger than the config cell says. It has nothing to do with the wall clock.

The practical advice is unchanged: time stage 1 before trusting the estimate for the whole.
The risk is a run that quietly takes three hours, not one that dies at ninety minutes.

### 5. The cookbook asset inventory

`scripts/fetch_assets.py` reads the expected inventory from `COSMOS3_FACTS.md` §6 at run
time and verifies it against the checkout. **The checkout was never made.** The inventory
was transcribed from a browse of `github.com/NVIDIA/cosmos`, and at least one upstream
inconsistency is already known — the transfer README references `assets/multi_control/`,
which does not exist. Others of the same kind are likely. Run `python3
scripts/fetch_assets.py --check` first; it will name the drift explicitly instead of a
lesson dying halfway through.

### 6. Whether the `audio_image2video` assets ship

Lesson 09 depends on `prompts/text2video/robot_pouring_water_audio.json`,
`prompts/image2video/coastal_road_audio.json` and
`images/image2video/coastal_road_audio.jpg`. These are listed in FACTS §6 from a browse of
the cookbook tree, not from a clone. If they are absent, or if they are git-lfs pointer
files, the audio half of Lesson 09 has nothing to run on. The lesson degrades to the
guardrail material, which is self-contained, but you will want to know before the session
rather than during it.

### 7. The framework's batch output filename convention

Several lessons — and the capstone's ledger in `cosmos_course/pipeline.py` — assume a
specific naming scheme for the files a batched `Generator.run()` writes, so that outputs can
be matched back to the specs that produced them. That convention was inferred from reading
upstream code, not observed. If it differs, the failure is quiet and nasty: files are
produced, the run exits zero, and the ledger associates the wrong output with the wrong
spec. Verify it with a two-spec batch before running anything larger. `cosmos_course/checks.py`
exists because a generation run can exit `0` and write a blanked file, and that is exactly
the shape of this risk.

### 8. Lesson 13, closed-loop control

The dependency conflict is verified from FACTS §5 and the policy server is documented
upstream, but no LIBERO closed-loop run has been demonstrated on a single H100, and the
RoboLab path needs an Isaac Sim installation this course does not provide. The four
train/serve parity gotchas — camera concat layout, the `1 − 2·g` gripper sign flip, the 180°
frame rotation, and mandatory `quantile_rot` normalisation — are transcribed from upstream
documentation and unverified in practice. Also unverified: that the policy server returns
HTTP 200 with an empty action list on inference error, which is documented upstream and
means a 200 is not proof of success. Expect to run the server and read about the rest.

### 9. Everything else with a number attached

Every hour figure in `02_PROPOSED_CURRICULUM.md` and every "Time" line in a notebook header
is authorial judgement. The only compute-duration figure anywhere in the supplied source
material is the DLI e2e harness's "~2–3 hours" for three notebooks, dominated by first-run
downloads. Edge's ~12 GB inference VRAM is this course's working estimate. Record your real
timings the first time through and correct the estimates in place.

---

## 11. How to produce the missing evidence

The sequence below is ordered so that each step's failure is cheap and localised. Do not
skip ahead; a failure at step 5 is much easier to diagnose if steps 1–4 passed.

```bash
# ── Step 1 ─ static gates. No GPU. Under 10 seconds. ──────────────────────
python3 -m pip install -e .            # brings in nbformat, enabling schema validation
python3 scripts/validate_notebooks.py  # expect: 0 error(s), 0 warning(s), Clean.
python3 tools/syntax_check.py          # expect: 0 syntax error(s)
python3 tools/nameflow_check.py        # expect: 0 potential undefined-name issue(s)
python3 tools/check_solutions.py       # expect: 0 problem(s)
python3 -c "import cosmos_course as c; print(c.missing_modules())"   # expect: {}

# ── Step 2 ─ preflight. ~5 seconds. Changes nothing. ─────────────────────
bash scripts/setup.sh --check-only     # expect: all ok, 0 preflight problems

# ── Step 3 ─ build the machine. 25–55 minutes, ~30 GB. ───────────────────
bash scripts/setup.sh
python3 scripts/smoke_test.py          # expect: tiers 0–2 pass, tier 3 SKIP

# ── Step 4 ─ first real generation. 5–20 minutes, ~9 GB download. ────────
python3 scripts/smoke_test.py --full   # tier 4: a real end-to-end generation

# ── Step 5 ─ assets. 2–10 minutes, ~3 GB. ────────────────────────────────
python3 scripts/fetch_assets.py --check   # inventory vs COSMOS3_FACTS.md §6

# ── Step 6 ─ the NIM. 10–25 minutes on a first pull, ~20 GB. ─────────────
echo "$NGC_API_KEY" | docker login nvcr.io -u '$oauthtoken' --password-stdin
cd docker && cp .env.example .env && $EDITOR .env && docker compose up -d && cd ..
python3 -c "from cosmos_course.nim import discover_memory_env; \
            print(discover_memory_env())"     # settle the variable name, once
python3 scripts/smoke_test.py          # expect: tier 3 now passes

# ── Step 7 ─ the full reduced pass. 6–10 hours unattended. ───────────────
REDUCED=1 ./scripts/run_all.sh --timeout 3600
```

**What a passing result looks like at each step.** Steps 1 and 2 print `0` errors and exit
`0` — these already pass here, minus the schema check, and step 1 should now include it.
Step 3's smoke test should show tiers 0–2 passing with tier 3 skipped, and crucially tier 2
must confirm `ModelMode contains wam` and `ModelMode does NOT contain policy` against your
real checkout — the first time that assertion has ever run for real. Step 4 writes a media
file that `cosmos_course.checks` confirms is not blank; a zero exit with a blank file is a
failure, not a pass. Step 5 lists any drift by name; `assets/multi_control/` being absent is
expected and is not a failure. Step 6's `discover_memory_env()` returns a dict naming which
candidate the container's `--help` actually mentions; if it names none, cap nothing and take
turns instead. Step 7 prints a per-notebook table; anything other than 20/20 identifies
exactly which lesson to fix.

Budget roughly **8–12 hours of wall clock** for steps 1–7, most of it unattended, plus
~150 GB of disk.

### Validation ledger — fill this in on the first real run

| Module | Lessons | Reduced pass | Full pass | Date | Wall clock | Peak VRAM | Notes / failures |
|---|---|---|---|---|---|---|---|
| 0 — Foundations | 00, 01 | ☐ | ☐ | | | | |
| 1 — Perceive | 02–05 | ☐ | ☐ | | | | |
| 2 — Imagine | 06–09 | ☐ | ☐ | | | | |
| 3 — Act | 10–13 | ☐ | ☐ | | | | |
| 4 — Systems | 14, 15 | ☐ | ☐ | | | | |
| 5 — Post-training | 16–18 | ☐ | ☐ | | | | |
| 6 — Capstone | 19 | ☐ | ☐ | | | | |

| Specific open question | Where | Resolved? | Answer found |
|---|---|---|---|
| NIM memory env var name | `nim.NIM_MEMORY_ENV` | ☐ | |
| NIM resting VRAM on an idle 80 GB card | Lesson 02 | ☐ | |
| Edge inference VRAM (measured, not quoted) | Lesson 06 | ☐ | |
| `vision_sft_edge` fits on one H100? | Lesson 17 | ☐ | |
| Reduced capstone wall clock vs 45–60 min | Lesson 19 | ☐ | |
| Cookbook inventory complete? | `fetch_assets.py --check` | ☐ | |
| `audio_image2video` assets present? | Lesson 09 | ☐ | |
| Batch output filename convention | Lesson 07 / `pipeline.py` | ☐ | |
| `ModelMode` still has `wam`, not `policy` | `smoke_test.py` tier 2 | ☐ | |

---

*Generated against the tree as of the final build. Every command output quoted above was
produced by running that command in the build sandbox; none is reconstructed from memory.
If you re-run them and get a different result, the tree has changed and this report is
stale — re-run it rather than trusting it.*
