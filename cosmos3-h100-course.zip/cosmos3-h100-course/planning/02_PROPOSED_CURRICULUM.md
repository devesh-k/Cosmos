# Proposed curriculum

**Physical AI with Cosmos 3 on a single H100 80 GB** — 20 lessons, six modules,
42 scheduled hours.

## How to read this

Each lesson below gives its purpose, its learning objectives, its prerequisites, the
concepts it introduces, the hands-on skills it builds, a time estimate, its resource
requirements, the artefact the learner produces, and the criterion for calling it
finished.

Objectives are written as things an instructor could watch someone do. "Understand
diffusion sampling" is not an objective; "measure the wall-clock and peak-VRAM cost of
doubling `num_steps` and explain which of the two scales linearly" is. Where a lesson
has an objective the course cannot currently guarantee — Lesson 17 in particular — it is
marked as such rather than dressed up.

**Time.** The 42 hours are scheduled hours, including everything optional. Roughly four
to six of those are unattended download or compute that a well-run delivery overlaps with
discussion, so attended time is closer to 35–38 hours. All per-lesson times are estimates.
The only compute-duration figure in any supplied material is the source e2e harness's
"~2-3 hours" for three notebooks, dominated by first-run downloads.

**Numbers.** Every VRAM, disk and parameter figure traces to
`assets/reference/COSMOS3_FACTS.md`. Where a number is a working estimate rather than a
published figure it says so inline.

---

## Learning path

```
                        ┌──────────────────────────────┐
   MODULE 0             │ 00 environment_check         │
   FOUNDATIONS          │ 01 cosmos3_mental_model      │
                        └──────────────┬───────────────┘
                                       │  (hard prerequisite for everything)
              ┌────────────────────────┼────────────────────────┐
              │                        │                        │
     ┌────────▼────────┐      ┌────────▼─────────┐              │
     │ MODULE 1        │      │ MODULE 2         │              │
     │ PERCEIVE        │      │ IMAGINE          │              │
     │                 │      │                  │              │
     │ 02 serving      │      │ 06 fundamentals  │              │
     │    ↓            │      │    ↓             │              │
     │ 03 captioning   │      │ 07 conditioned   │              │
     │    ↓            │      │    ↓             │              │
     │ 04 embodied     │      │ 08 control       │              │
     │    ↓            │      │    ↓             │              │
     │ 05 spatial      │      │ 09 audio+guard   │              │
     └────────┬────────┘      └────────┬─────────┘              │
              │                        │                        │
              │               ┌────────▼─────────┐              │
              │               │ MODULE 3  ACT    │              │
              │               │ 10 forward_dyn   │              │
              │               │    ↓             │              │
              │               │ 11 inverse_dyn   │              │
              │               │    ↓             │              │
              │               │ 12 wam           │              │
              │               │    ↓             │              │
              │               │ 13 closed_loop ⚠ │              │
              │               └────────┬─────────┘              │
              │                        │                        │
              └───────────┬────────────┴────────────────────────┘
                          │
                 ┌────────▼─────────┐
                 │ MODULE 4 SYSTEMS │   14 performance_and_memory
                 │                  │      ↓
                 │                  │   15 optimisation
                 └────────┬─────────┘
                          │
                 ┌────────▼─────────┐
                 │ MODULE 5         │   16 posttraining_concepts
                 │ POST-TRAINING    │      ↓
                 │                  │   17 posttraining_one_gpu ⚠
                 │                  │      ↓
                 │                  │   18 evaluation
                 └────────┬─────────┘
                          │
                 ┌────────▼─────────┐
                 │ MODULE 6         │   19 capstone_synthetic_data_flywheel
                 │ CAPSTONE         │   (needs 03, 05, 07, 08, 12, 14, 18)
                 └──────────────────┘

  ⚠ = least validated; see 04_INSTRUCTOR_GUIDE.md §"What is least validated"
```

**What is genuinely independent.** After Module 0, Module 1 (Perceive) and Module 2
(Imagine) share no code and no model download beyond the checkpoint itself. They can be
taught in either order or in parallel across two cohorts. Module 3 depends on Module 2 —
action modes reuse the generator's spec machinery, launch path and output conventions —
but not on Module 1.

**What is strictly ordered.** Within each module the lessons build. Module 4 measures
things produced in Modules 1–3, so it must come after at least one of them; placing it
after all three lets it compare reasoning, generation and action costs on one axis.
Module 5 depends on Module 4 because the single-GPU post-training argument is a memory
argument, and a learner who has not measured memory will take it on faith.

**The one long-range dependency worth planning for.** Lesson 18 (evaluation) evaluates
whatever Lesson 17 produced. If Lesson 17's fine-tune does not run — a real possibility,
see below — Lesson 18 still works, because it evaluates the *base* model against itself
across configurations. That fallback is designed in, not improvised.

---

# Module 0 — Foundations (3 h)

## Lesson 00 — `00_environment_check`

**Purpose.** Establish exactly what machine the learner is on, in writing, before
anything expensive happens. Most of the failures in the rest of the course are
environment failures wearing a Cosmos costume, and a learner who has a saved
`EnvReport` can tell the difference.

**Learning objectives.** By the end, the learner can:

1. Run `probe_environment()` and interpret every field it returns, including which fields
   are `None` and why a probe that returns `None` is better than one that raises.
2. Read the H100's identity from `nvidia-smi` — name, driver version, CUDA driver
   version, compute capability, total and free VRAM — and reconcile each against what
   `torch` reports.
3. Explain why `torch.version.cuda` and `nvidia-smi`'s CUDA version can differ without
   anything being wrong, and identify the case where the difference *is* the problem.
4. Compute a disk budget for the course from `COSMOS3_FACTS.md` §3 and compare it
   against actual free space, deciding whether Nano (34.9 GB) is affordable on this
   machine.
5. Verify Docker GPU passthrough with a container that runs `nvidia-smi -L`, and
   distinguish "no Docker", "Docker but no daemon", "daemon but no GPU" and "GPU but no
   nvcr.io login" from each other.
6. Argue with at least one threshold in `config._assess()` and justify the alternative.

**Prerequisites.** A Linux shell. Nothing Cosmos-specific.

**Concepts introduced.** Discrete versus unified memory and why this course assumes the
former; driver/runtime CUDA versioning; compute capability and what 9.0 buys (FP8 tensor
cores, FlashAttention-3); the NVIDIA Container Toolkit; the difference between an NGC
registry login and an NGC API key at runtime; graceful degradation in diagnostic code.

**Hands-on skills.** Reading `nvidia-smi` output precisely. Writing probes that never
raise. Producing a machine-readable environment record.

**Time.** 1.0 h.

**Resources.** GPU used only for identification; no model weights, no meaningful VRAM,
no meaningful disk. Docker required for one pull of `nvidia/cuda:12.8.0-base-ubuntu22.04`
(a few hundred MB).

**Artefact.** `outputs/env_report.json`, saved via `EnvReport.save()`, plus a short
written answer to the threshold-argument objective.

**Completion criterion.** `probe_environment()` reports zero entries in `problems`, and
the learner can state from memory the machine's VRAM, compute capability and free disk.

---

## Lesson 01 — `01_cosmos3_mental_model`

**Purpose.** Give the learner a model of what Cosmos 3 *is* before they use it, so the
rest of the course is a set of consequences rather than a set of recipes. The source
course asserts "omni-model" and moves on; this lesson makes the claim mechanical.

**Learning objectives.** By the end, the learner can:

1. Explain why one checkpoint serves both an HTTP chat API and a diffusion sampler, in
   terms of Mixture-of-Transformers reasoner and generator towers.
2. Reconcile "Nano (8B)" against Hugging Face's 15,750,057,456 parameters, and state the
   rule: budget inference against the active count, budget training against the total,
   because every parameter needs optimizer state (`COSMOS3_FACTS.md` §1).
3. Choose a tier for a stated task from the constraints in `MODEL_TIERS` — Edge 4B / 480p
   / no audio / no transfer, Nano 16B / 768p / all modes, Super 64B / 128 GB inference —
   and justify why Super generation is out of reach on this machine while Super
   *reasoning* is not.
4. Enumerate the ten members of `ModelMode` and verify the list against the enum in their
   own checkout rather than against `docs/inference.md`.
5. Demonstrate that `policy` is not a member and that `wam` is, and explain how upstream
   documentation still says otherwise.
6. Explain why `video2video` plus a hint block is the mechanism behind transfer, and name
   the four members of `TransferHintKey`.
7. Generate one 480p image with Cosmos3-Edge end to end and confirm it is not noise.

**Prerequisites.** Lesson 00.

**Concepts introduced.** Mixture-of-Transformers and active-versus-total parameters; the
mode enum as the single source of truth; transfer as mode-plus-hint; the tier/capability
matrix; the first-run download chain (checkpoint, then guardrail, then VAE, then the
text guardrail model); OpenMDW 1.1 as the actual licence.

**Hands-on skills.** Reading an upstream enum to settle a documentation dispute.
Launching the framework once and reading its output. Verifying an image rather than
assuming it.

**Time.** 2.0 h, of which ~30–50 min is the Edge download and first-run auxiliary pulls.

**Resources.** Cosmos3-Edge, 9.1 GB download, ~12 GB VRAM (working estimate, measured
properly in Lesson 06, not an NVIDIA figure). Plus first-run auxiliaries: guardrail
3.63 GB (the one gated repo — licence click required here), Wan2.2 VAE 2.82 GB,
Qwen3Guard-Gen-0.6B 1.52 GB. Disk ~20 GB. One HF token.

**Artefact.** `outputs/01/first_image.png` plus `outputs/01/mode_enum.json` — the mode
list the learner extracted from their own checkout, with a note on where it disagrees
with the docs.

**Completion criterion.** The image passes `check_image()`, and the learner's extracted
mode list contains `wam` and does not contain `policy`.

---

# Module 1 — Perceive (7 h)

## Lesson 02 — `02_serving_the_reasoner`

**Purpose.** Get a reasoner serving on the one GPU the learner has, and confront the
constraint that defines this entire course: the NIM and the generator both want the
whole card.

**Learning objectives.** By the end, the learner can:

1. Authenticate to `nvcr.io`, pull `nvcr.io/nim/nvidia/cosmos3-reasoner:1.7`, and start it
   with `NIM_MODEL_SIZE=nano` on device 0.
2. Measure the NIM's *resting* VRAM with `nim_status()` and explain why it exceeds the
   ~8 GB of FP8 weights — KV cache pre-allocation against currently free memory.
3. Predict, before running it, that starting the NIM first and then generating will OOM,
   and then demonstrate it deliberately.
4. Implement both single-GPU strategies — take turns (`stop_nim` / `start_nim`) and cap
   (`gpu_memory_fraction`) — and state what capping costs, in KV cache and therefore in
   maximum video length per request.
5. Use `discover_memory_env()` to find out what the memory-limit environment variable is
   actually called on their NIM image, and explain why the course could not pin that name
   in advance.
6. Send a chat completion through the OpenAI-compatible API and read the response,
   including token usage.
7. Stand up the vLLM fallback with the `vllm-cosmos3` plugin in a *separate* venv, and
   explain from `COSMOS3_FACTS.md` §3 why it cannot share the framework's venv.
8. Diagnose a 422 from a video request and fix it with `ensure_h264()`.

**Prerequisites.** Lesson 01. Docker with GPU passthrough (verified in Lesson 00).

**Concepts introduced.** NIM lifecycle; OpenAI-compatible serving; KV cache
pre-allocation and why every modern server does it; VRAM contention as a scheduling
problem rather than a capacity problem; the `vllm` dependency conflict; base64 `data:`
URL media transport; `media_io_kwargs` for frame sampling; the OpenCV decode constraint.

**Hands-on skills.** Container lifecycle management with observation rather than faith.
Reading VRAM from four independent sources and knowing which to trust. Building a second
Python environment on purpose.

**Time.** 2.0 h, of which ~20–40 min is the NIM image pull (8.28 GB compressed) and
first-run profile download (20 GB on disk for FP8 nano).

**Resources.** Reasoner NIM, ~20 GB disk for the FP8 nano profile. VRAM: up to the whole
card when uncapped. NGC API key required (free Developer Program tier is enough,
FACTS §4). Optional vLLM venv adds ~15 GB (estimate).

**Artefact.** `outputs/02/vram_plan.json` recording measured NIM resting VRAM, the
learner's chosen strategy, and the memory environment variable name discovered on their
image; plus a one-paragraph written justification of the choice.

**Completion criterion.** The learner can start the NIM, get a correct answer about an
image, stop it, generate with Edge, and restart the NIM — without an OOM — and can point
at the measurement that told them it would work.

---

## Lesson 03 — `03_reasoning_captioning`

**Purpose.** Turn video into structured records. Captioning is the cheapest reasoner task
and the one whose output feeds everything downstream, so it is where prompt discipline is
worth establishing.

**Learning objectives.** By the end, the learner can:

1. Caption a cookbook clip at three frame-sampling rates and describe how the caption
   changes with `fps`, in terms of what the model can and cannot see.
2. Measure tokens-in and tokens-out for each sampling rate and explain why frame count
   drives context length quadratically in cost terms.
3. Rewrite a free-text caption prompt as a schema request and get parseable JSON back
   reliably enough to run over a batch.
4. Use `Reasoner.parse_json()` to extract structured output and handle the three ways the
   model wraps it (code fences, `</think>` prefix, bare).
5. Run captioning over a batch of clips and write one JSONL scene record per clip.
6. Compare two captions of the same clip at `temperature=0` and at the server default,
   and state whether the difference matters for their downstream use.
7. Detect a degenerate caption with `check_text()` rather than by reading it.

**Prerequisites.** Lesson 02.

**Concepts introduced.** Frame sampling as the dominant cost lever in video VLM
inference; schema-constrained prompting; scene records as a data structure; determinism
via `seed` and `temperature`; degenerate-output detection.

**Hands-on skills.** Prompt-to-schema conversion. Batch inference against an HTTP
service. Writing JSONL that a later lesson will consume.

**Time.** 1.5 h.

**Resources.** Reasoner NIM running. No new downloads. Cookbook assets
(`video_caption.mp4`, `situation_understanding.mp4`, `temporal_localization_{1,2}.mp4`).

**Artefact.** `outputs/03/scene_records.jsonl` — at least six captioned clips with
structured fields, used again in Lessons 07 and 19.

**Completion criterion.** Every record in the JSONL parses, has the requested fields, and
passes `check_text()`.

---

## Lesson 04 — `04_reasoning_embodied`

**Purpose.** Move from description to decision. This is where a VLM stops being a
captioner and starts being the front half of a policy.

**Learning objectives.** By the end, the learner can:

1. Elicit a chain of thought with the `<think>` convention and split it from the answer
   with `split_think()`.
2. Compare next-action predictions with and without the `<think>` wrapper on the same
   clip and state whether the reasoning changed the answer or only explained it.
3. Write a task-decomposition prompt that returns an ordered subtask list, and evaluate
   whether the ordering is physically executable.
4. Construct an assisted-task prompt that carries an overall goal *and* the current step,
   and explain why supplying both changes the answer.
5. Pose a physical-common-sense question whose correct answer is "no" and check that the
   model gets it right — that is, deliberately probe for failure rather than for
   confirmation.
6. Identify at least one case where the chain of thought is plausible and the conclusion
   is wrong, and explain what that implies for using this output to drive hardware.
7. Measure the token and latency cost of chain-of-thought reasoning against direct
   answering.

**Prerequisites.** Lesson 03.

**Concepts introduced.** Chain of thought as an auditable artefact, not a quality
guarantee; goal-conditioned versus step-conditioned prompting; adversarial probing;
physical plausibility as a screening filter (used again in Lesson 19).

**Hands-on skills.** Prompt design for decisions. Structured failure-hunting. Reading a
reasoning trace critically.

**Time.** 1.75 h.

**Resources.** Reasoner NIM. Cookbook assets `robotics_next_action.mp4`,
`robot_planning.png`, `assisted_task_next_action.mp4`, `common_sense_reasoning.mp4`,
`physical_plausibility.mp4`. No new downloads.

**Artefact.** `outputs/04/reasoning_log.jsonl` containing, for each probe, the prompt,
the split reasoning, the answer, the learner's verdict, and token counts — including at
least one documented failure case.

**Completion criterion.** The log contains at least one case the learner judged wrong,
with a written explanation of what went wrong in the reasoning.

---

## Lesson 05 — `05_reasoning_spatial`

**Purpose.** Get coordinates out of the model. Everything in Module 3 needs the model to
say *where*, not only *what*.

**Learning objectives.** By the end, the learner can:

1. Request a 2D bounding box, parse the 0–1000-normalised JSON, and render it back onto
   the image at the correct pixel scale.
2. Explain why normalised coordinates are used and what breaks if the image is resized
   between prompt and overlay.
3. Build a Set-of-Mark image programmatically with `mark_subjects()` and get region-keyed
   captions back, verifying that each `subject_id` corresponds to the mark they drew.
4. Demonstrate a grounding failure — an ambiguous referring expression, or an object the
   model localises confidently and wrongly — and characterise it.
5. Elicit a 2D end-effector trajectory as an ordered list of `point_2d` waypoints and
   overlay it with `draw_trajectory()`.
6. Vary sampling (`temperature`, `top_p`, `top_k`) on the trajectory task and describe
   the effect on path smoothness and on parse failure rate.
7. Explain the relationship between a 2D pixel-space trajectory from Lesson 05 and a 3D
   end-effector action from Lesson 12, and why one is not the other.

**Prerequisites.** Lesson 04.

**Concepts introduced.** Normalised coordinate spaces; Set-of-Mark prompting and its
dependence on stable mark numbering; action chain-of-thought; the gap between pixel-space
plans and metric actions.

**Hands-on skills.** Coordinate transforms between normalised, pixel and display space.
Programmatic image annotation. Robust parsing of semi-structured model output.

**Time.** 1.75 h.

**Resources.** Reasoner NIM. Cookbook assets `grounding_2d.png`, `robot_153.jpg`,
`action_cot_trajectory.png`, `describe_anything.png`. No new downloads.

**Artefact.** `outputs/05/` containing an annotated bounding-box image, a Set-of-Mark
image with its region caption JSON, and an overlaid trajectory image, plus a written note
on the failure case from objective 4.

**Completion criterion.** All three overlays render with coordinates in the right place,
and the region captions key correctly to the marks the learner drew.

---

# Module 2 — Imagine (8 h)

## Lesson 06 — `06_generation_fundamentals`

**Purpose.** Establish what generation costs, in the only units that matter on one GPU:
seconds and gigabytes. Every later generation lesson spends against this budget.

**Learning objectives.** By the end, the learner can:

1. Describe the denoising loop well enough to predict the direction of every knob's effect
   before running it.
2. Build a valid `InferenceSpec` from scratch, without a helper, and validate it with
   `validate_spec()`.
3. Generate `text2image` and `text2video` on Edge and on Nano, and state the observed
   difference in quality and cost.
4. Measure wall-clock time correctly — with warm-up, with `torch.cuda.synchronize()`,
   with repeats — and explain why a naive `time.perf_counter()` around a CUDA call
   produces a fictional number.
5. Measure peak VRAM for a generation run and compare it against Nano's documented 32 GB
   (FACTS §3) and Edge's ~12 GB working estimate.
6. Produce a cost curve over `num_steps`, `num_frames` and `resolution`, and show that
   `estimate_generation_cost()`'s unit count predicts the ratios even though it predicts
   no absolute time.
7. Calibrate units-per-second on their own machine so that `estimate_generation_cost()`
   becomes a real time estimate for that machine.
8. Explain the aspect-ratio format trap: `"16,9"` with a comma, not `16:9` and not a
   float.

**Prerequisites.** Lesson 01. Independent of Module 1.

**Concepts introduced.** Flow-matching / diffusion sampling; `num_steps`, `guidance`,
`shift`, `seed`; resolution tiers as named strings rather than pixel pairs; latent tokens
and the VAE's 8× spatial / 4× temporal compression plus 2×2 patchification; correct GPU
timing; peak versus reserved versus allocated memory.

**Hands-on skills.** Writing specs by hand. Correct benchmarking. Plotting a cost curve.

**Time.** 2.5 h, of which ~40–70 min is the Nano download.

**Resources.** Cosmos3-Edge (already local) and Cosmos3-Nano — 34.9 GB download, 32 GB
inference VRAM (FACTS §1, §3). Disk grows to ~60 GB of HF cache. NIM must be stopped or
capped.

**Artefact.** `outputs/06/cost_curve.json` plus a plot, and the learner's calibrated
units-per-second constant recorded in `outputs/06/calibration.json`.

**Completion criterion.** The measured cost ratios agree with `estimate_generation_cost()`
to within a factor the learner states and defends, and they can explain any point that
does not fit.

---

## Lesson 07 — `07_generation_conditioned`

**Purpose.** Move from "make something" to "make *this*". Conditioning is where
generation becomes useful for data work.

**Learning objectives.** By the end, the learner can:

1. Run `image2video` from a first frame and describe what the model preserves from the
   frame and what it invents.
2. Read a cookbook structured JSON prompt, identify its fields, and write a new one for a
   scene of their choosing.
3. Compare a structured JSON prompt against a single-sentence prompt for the same intent,
   and state which parts of the scene each controls.
4. Apply a negative prompt from `assets/negative_prompts/{mode}/neg_prompt.json`, and
   explain why `text2image` has none.
5. Feed a scene record produced in Lesson 03 into a generation prompt, closing the first
   arc of the pipeline the source only asserted.
6. Vary `guidance` across at least four values on a fixed seed and characterise the
   prompt-adherence-versus-artefact tradeoff.
7. Demonstrate that a fixed seed plus a fixed spec reproduces a run, and find one setting
   that breaks reproducibility.

**Prerequisites.** Lesson 06. Lesson 03 for objective 5 (a canned scene record is
provided for learners taking Module 2 first).

**Concepts introduced.** First-frame conditioning; structured prompts as
attribute-by-attribute scene specification; negative prompting; guidance scale;
reproducibility and its limits.

**Hands-on skills.** Authoring structured prompts. Controlled comparison at fixed seed.
Wiring one lesson's output into another's input.

**Time.** 2.0 h.

**Resources.** Nano (local). Cookbook assets `car_driving.jpg`, `humanoid_robot.jpg`,
`robot_kitchen.json`, `robot_draping.json`, `car_driving.json`. No new downloads.
Outputs ~2–4 GB.

**Artefact.** `outputs/07/` containing a guidance sweep at fixed seed, one video generated
from a Lesson 03 scene record, and the learner's own structured prompt file.

**Completion criterion.** All outputs pass `check_video()`, and the guidance sweep shows a
visible, describable trend.

---

## Lesson 08 — `08_generation_control`

**Purpose.** Control-conditioned generation is the mechanism behind synthetic data
augmentation, and it is the mode most mis-taught by the source material.

**Learning objectives.** By the end, the learner can:

1. State that transfer is `model_mode: "video2video"` plus a control-hint block, and
   demonstrate it by writing a transfer spec from scratch.
2. Name the four members of `TransferHintKey` and match each to what it preserves —
   `edge` shape and layout, `blur` colour and lighting, `depth` 3D structure, `seg`
   object identity (FACTS §2).
3. Run the same source video through at least three hints with the same prompt, and
   explain the difference in what survived.
4. Explain the status of `wsm`: same mechanism, cookbook asset family, not a member of the
   enum.
5. Predict and then verify that Edge cannot run transfer at all, and state where in
   `MODEL_TIERS` that constraint lives.
6. Design a data-augmentation pass — one source clip, N on-distribution variants — and
   argue which hint suits their stated variation.
7. Explain why the output's frame count and geometry come from the control video rather
   than from the spec.
8. Report honestly on multi-control: `TransferArgs.weight` supports weighted attention
   aggregation, but the cookbook's `assets/multi_control/` directory is referenced in its
   README and does not exist in the checkout (FACTS §2).

**Prerequisites.** Lesson 07.

**Concepts introduced.** Control hints as structure-preserving conditioning; augmentation
as the core synthetic-data operation; the tier constraint on transfer; geometry inherited
from the control input.

**Hands-on skills.** Writing `video2video` specs by hand. Systematic comparison across a
control axis. Designing an augmentation set rather than running one example.

**Time.** 2.0 h. Transfer runs are among the longest in the course; expect several
minutes per clip at 121 frames and 30 FPS.

**Resources.** Nano only — Edge and Super cannot do this (FACTS §1). Cookbook transfer
assets: `assets/{edge,blur,depth,seg}/control_*.mp4` (121 frames @ 30 FPS),
`assets/wsm/control_wsm.mp4` (101 frames @ 10 FPS), `assets/negative_prompt.json`,
`specs/*.json`. Outputs ~3–6 GB.

**Artefact.** `outputs/08/augmentation_set/` — one source clip rendered through at least
three hints, with a written comparison, plus the learner's hand-written spec.

**Completion criterion.** Three hint variants exist, all pass `check_video()`, and the
learner can say which hint they would use for a stated augmentation goal and why.

---

## Lesson 09 — `09_generation_audio_guardrail`

**Purpose.** Two things the source never taught: the audio mode, and the safety component
that sits between the model and every file it writes.

**Learning objectives.** By the end, the learner can:

1. Run `audio_image2video` on Nano and confirm the output carries an audio stream.
2. Explain why Edge cannot do this and state the source of that constraint.
3. Describe where the guardrail sits in the pipeline and that it screens both the prompt
   and the generated frames.
4. Accept the one gated licence — `nvidia/Cosmos-Guardrail1` — and explain why it is the
   only one left, contrasting with the source course's five-repository premise.
5. Trigger a guardrail rejection deliberately and identify it from the output, not from
   the exit code, using `RunResult.diagnose()` and `check_video()`.
6. Distinguish a guardrail rejection from an OOM and from a codec failure by their
   signatures.
7. Explain the naming split — cookbook says `nvidia/Cosmos-1.0-Guardrail`, framework says
   `nvidia/Cosmos-Guardrail1`, both exist, both gated (FACTS §7) — and say which one their
   run actually pulled.
8. Make a defensible argument for or against disabling the guardrail in a research
   pipeline.

**Prerequisites.** Lesson 08. Lesson 04's plausibility screening is useful context.

**Concepts introduced.** Audio-conditioned generation; content guardrails as an inline
pipeline stage; silent failure and why exit codes are insufficient evidence; the licence
that is still gated and why.

**Hands-on skills.** Reading a run's evidence rather than its return code. Deliberate
failure induction. Distinguishing failure classes by signature.

**Time.** 1.5 h.

**Resources.** Nano. Guardrail 3.63 GB (already pulled in Lesson 01; re-verified here).
Cookbook assets `robot_pouring_water_audio.json`, `coastal_road_audio.jpg`,
`coastal_road_audio.json`. Outputs ~1–2 GB.

**Artefact.** `outputs/09/` with one audio-bearing video and a `failure_signatures.md`
recording what each of the three failure classes looks like on their machine.

**Completion criterion.** `ffprobe` confirms an audio stream in the generated file, and
the learner produced and correctly classified at least one deliberate guardrail rejection.

---

# Module 3 — Act (7 h)

## Lesson 10 — `10_action_forward_dynamics`

**Purpose.** Introduce action as a modality by using it in the direction that is easiest
to verify: give the model actions, watch what it thinks will happen.

**Learning objectives.** By the end, the learner can:

1. Explain the claim that action tokens represent the transition between consecutive
   visual states, and say what that predicts about the inverse direction.
2. Write a `forward_dynamics` record with the correct fields — `action_chunk_size`,
   `action_path`, `domain_name`, `fps`, `image_size`, `view_point`, `vision_path` — and
   explain each.
3. Run the same start frame with the `forward`, `left` and `right` AV trajectories and
   confirm the generated video follows the commanded motion.
4. Author a novel trajectory by editing the JSON and predict the resulting video before
   running it.
5. Explain why action modes take the single-process launch path rather than `torchrun`,
   and where that decision is encoded (`ACTION_MODEL_MODES` in `cosmos_course/models.py`).
6. Justify `--parallelism-preset=latency` for action work against `throughput` for batch
   generation.
7. Find the point where a hand-authored trajectory produces incoherent video, and say what
   that tells you about the training distribution.

**Prerequisites.** Lesson 07. (Module 1 is not required.)

**Concepts introduced.** Action as a token stream; action chunking; domain and viewpoint
conditioning; the single-process launch path; parallelism presets.

**Hands-on skills.** Authoring action JSON. Controlled comparison across trajectories.
Probing a distribution boundary.

**Time.** 1.75 h.

**Resources.** Nano. Cookbook action assets `images/av_0.jpg`,
`actions/av_traj_{forward,left,right}.json`, `actions/camera_action.json`. Outputs ~1 GB.

**Artefact.** `outputs/10/` with three commanded-trajectory videos, one learner-authored
trajectory and its video, and a written prediction-versus-outcome note.

**Completion criterion.** The three commanded videos are visually distinguishable in the
commanded direction, and the learner's own trajectory produced a video they can explain.

---

## Lesson 11 — `11_action_inverse_dynamics`

**Purpose.** Run the model backwards, and in doing so confront the pose mathematics the
source used without explaining.

**Learning objectives.** By the end, the learner can:

1. Write an `inverse_dynamics` record and explain why it omits `action_path`.
2. Locate the prediction at `outputs[0].content["action"]` in `sample_outputs.json` and
   state its shape and meaning.
3. Explain the 6D rotation representation: why a 3×3 matrix is over-parameterised, why
   Euler angles and quaternions are awkward to regress, and what `rot6d`
   Gram-Schmidts back into.
4. Convert relative pose deltas to absolute poses with `pose_rel_to_abs()` and explain
   `pose_convention="backward_framewise"` and `translation_scale`.
5. Read a 4×4 homogeneous transform: `[:, :3, 3]` is translation, `[:, :3, :3]` is
   rotation, `[:, :3, 2]` is the +Z heading column.
6. Plot the recovered camera trajectory in 3D with frustums and as a bird's-eye view using
   `plot_camera_trajectory()`.
7. Close the loop: run inverse dynamics on a video generated by Lesson 10's forward
   dynamics, and compare the recovered trajectory against the commanded one.
8. State how much of the discrepancy in objective 7 is model error and how much is
   `translation_scale` being an unexplained constant, and design a check that separates
   them.

**Prerequisites.** Lesson 10.

**Concepts introduced.** Inverse dynamics; 6D rotation parameterisation; homogeneous
transforms; relative-to-absolute pose integration; scale ambiguity in monocular motion
estimation; round-trip consistency as a free evaluation signal.

**Hands-on skills.** Rigid-body transform manipulation in NumPy. 3D trajectory plotting.
Designing a consistency check.

**Time.** 1.75 h.

**Resources.** Nano. Cookbook assets `videos/av_0.mp4`, `videos/av_1.mp4`, plus Lesson
10's outputs. Outputs small (JSON and plots).

**Artefact.** `outputs/11/roundtrip.json` and a plot comparing commanded against recovered
trajectory, with the learner's decomposition of the error.

**Completion criterion.** The recovered trajectory has the right qualitative shape for the
commanded motion, and the learner has a written, testable hypothesis for the residual.

---

## Lesson 12 — `12_action_wam`

**Purpose.** The World Action Model: observation plus instruction in, video *and* actions
out. This is also where the course pays off its most important correction.

**Learning objectives.** By the end, the learner can:

1. Write a `wam` spec and explain that the mode used to be called `policy`, that the old
   name will fail, and how to confirm which name is live in their checkout.
2. Reproduce the failure: run the spec with `"model_mode": "policy"`, read the error, and
   fix it — deliberately, so the error is familiar rather than alarming.
3. Explain why upstream `docs/inference.md`, `docs/faq.md` and the cookbook README all
   still say `policy`, and state the rule: trust the enum, not the prose.
4. Extract both outputs of a `wam` run — the rollout video and the action sequence — and
   describe how they relate.
5. Read the 10-D manipulation action layout (3 translation deltas, 6D rotation, 1 gripper)
   and contrast it with the 9-D AV ego-pose layout from Lesson 11.
6. Integrate the translation deltas into a 3D end-effector path with
   `plot_end_effector_path()` and interpret the gripper channel against the path.
7. Change the instruction while holding the observation fixed, and show that the predicted
   action changes accordingly.
8. Explain precisely what "open-loop" means here and what it cannot tell you.

**Prerequisites.** Lesson 11.

**Concepts introduced.** The world action model; joint video-and-action prediction;
instruction conditioning; the two action layouts; open-loop versus closed-loop.

**Hands-on skills.** Running a mode whose documentation is wrong. End-effector trajectory
reconstruction. Instruction ablation.

**Time.** 1.75 h.

**Resources.** Nano. Cookbook LeRobot example episodes
(`bridge_lerobot_example/`, `droid_lerobot_example/`) plus a locally cached start
observation — the course caches this rather than fetching mid-lesson from a pinned raw
GitHub URL as the source does. Outputs ~1 GB.

**Artefact.** `outputs/12/` with a `wam` rollout, its action array, an end-effector path
plot, and a second run under a changed instruction.

**Completion criterion.** Both outputs exist and pass their checks, and the
instruction-ablation pair shows a defensible difference.

---

## Lesson 13 — `13_action_closed_loop` ⚠

**Purpose.** Explain closed-loop control honestly: what it requires, why the course cannot
run all of it on one machine in a classroom, and what part it can run.

**Learning objectives.** By the end, the learner can:

1. Explain the difference between open-loop chunk prediction and closed-loop control that
   re-queries every chunk against a stepped simulator.
2. Explain from `COSMOS3_FACTS.md` §5 why this needs a **second venv**:
   `robosuite==1.4.1`, `mujoco==2.3.7` and `torch<2.6` will not coexist with the
   training environment.
3. Build that second environment and demonstrate the conflict by attempting the install in
   the framework venv first.
4. Start `cosmos_framework.scripts.action_policy_server_libero` and confirm it answers,
   using `Cosmos3-Nano-Policy-DROID` (16B, ~30 GB, not gated) or
   `Cosmos3-Edge-Policy-DROID` (4B, ~9 GB).
5. Describe the LIBERO closed-loop eval path (`closed_loop_eval.py`) and the DROID/RoboLab
   path (Isaac Sim 5.0 + Isaac Lab 2.2.0, headless), and state which is feasible on this
   machine.
6. Reason about the VRAM budget for a policy server plus a simulator on one card, and say
   what has to give.
7. State which parts of this lesson they ran and which they read, and why.

**Prerequisites.** Lesson 12. Lesson 02's second-venv experience transfers directly.

**Concepts introduced.** Closed-loop control; policy serving as a streaming service;
dependency conflicts as an architectural constraint rather than an annoyance; the honest
boundary of a single-GPU course.

**Hands-on skills.** Building a conflicting environment deliberately. Standing up a policy
server. Reading a system's requirements and deciding what is out of reach.

**Time.** 1.75 h.

**Resources.** `Cosmos3-Nano-Policy-DROID` ~30 GB or `Cosmos3-Edge-Policy-DROID` ~9 GB
(FACTS §1; prefer Edge here to save disk). Second venv ~10 GB (estimate).
`nvidia/LIBERO_LeRobot_v3` `libero_10` subset, ~0.5 GB, 379 episodes (FACTS §5). Isaac Sim
is **not** installed; the RoboLab path is documented, not run.

**Artefact.** `outputs/13/closed_loop_notes.md` — the learner's written account of what
ran, what did not, and the specific constraint that stopped each thing.

**Completion criterion.** The policy server starts and answers at least one request, and
the learner can state the dependency conflict from memory.

**Validation status.** This is the least-validated lesson in Module 3. The policy server
path is documented upstream and the dependency conflict is verified, but the full LIBERO
closed-loop run on a single H100 has not been demonstrated by this course.

---

# Module 4 — Systems (5 h)

*Everything in this module is new. The source course contains no measurement of any kind.*

## Lesson 14 — `14_performance_and_memory`

**Purpose.** Make the learner able to defend a performance claim. Most reported speedups
in ML notebooks are measurement artefacts, and a learner who cannot tell the difference
will optimise noise.

**Learning objectives.** By the end, the learner can:

1. Demonstrate the asynchrony error: time a CUDA operation without `synchronize()`,
   observe an impossible result, and fix it.
2. Demonstrate the warm-up error: show that the first call in a process is slower and
   attribute the difference to context creation, kernel JIT, algorithm selection and
   allocator growth.
3. Use `benchmark()` with warm-up and repeats, and report a median with a spread rather
   than a single number.
4. Distinguish allocated, reserved and driver-reported VRAM, and explain which one an OOM
   is about.
5. Quantify fragmentation as reserved-minus-allocated and say when it matters.
6. Reproduce an OOM deliberately and walk the escalation ladder from `oom_advice()`,
   stating which rungs exist on one GPU and which need more (FACTS §5: levers 3 and 4
   require more GPUs, so only `expandable_segments`, activation checkpointing, batch
   reduction and LoRA are available).
7. Build a measurement log across reasoning, generation and action, and identify which
   stage dominates.
8. Explain why `estimate_generation_cost()` deliberately returns a unit count rather than
   a time.

**Prerequisites.** At least one of Modules 1–3; best after all three.

**Concepts introduced.** CUDA asynchrony; warm-up; allocator behaviour and
`PYTORCH_ALLOC_CONF=expandable_segments:True`; the OOM ladder; measurement discipline.

**Hands-on skills.** Correct benchmarking. Memory profiling. Deliberate OOM induction and
recovery.

**Time.** 2.5 h.

**Resources.** Edge and Nano, both local. No new downloads.

**Artefact.** `outputs/14/measurements.jsonl` via `MeasurementLog`, covering at least six
configurations across at least two modalities.

**Completion criterion.** The learner can produce two timings of the same operation — one
correct, one wrong by construction — and explain the mechanism of the difference.

---

## Lesson 15 — `15_optimisation`

**Purpose.** Spend the measurement skill from Lesson 14 on decisions. This lesson is about
tradeoffs with numbers attached, not about a list of flags.

**Learning objectives.** By the end, the learner can:

1. Compare BF16 and FP8 where available, and state what each requires (compute capability
   8.0 for BF16, 8.9 for FP8 — FACTS §4) and what each costs in quality.
2. Compare `--parallelism-preset=throughput` against `latency` on the same job on one GPU
   and report whether the preset makes any difference at world size 1.
3. Build a Pareto front over resolution, frame count and step count for a fixed time
   budget, and choose a point defensibly.
4. Show that dropping from 768p to 480p costs roughly the square of the linear ratio in
   latent tokens, and verify against measurement.
5. Choose between Edge and Nano for a stated task using measured numbers rather than tier
   names.
6. Identify the attention backend in use and explain why Hopper selects `flash-attn-3-nv`
   (FACTS §3).
7. Explain why Super generation is unreachable here (128 GB inference VRAM, FACTS §3)
   while Super reasoning is reachable at FP8 on one H100 (FACTS §4), and say what that
   asymmetry tells you about where the memory goes.
8. Produce a one-page "how to fit it" reference for their own machine.

**Prerequisites.** Lesson 14.

**Concepts introduced.** Precision tradeoffs; parallelism presets and their irrelevance at
world size 1; Pareto reasoning under a fixed budget; attention backend selection; the
reasoner/generator memory asymmetry.

**Hands-on skills.** Sweeping a configuration space efficiently. Making and defending a
tradeoff.

**Time.** 2.5 h.

**Resources.** Edge and Nano. Optionally the Super *reasoner* at FP8 through the NIM
(40 GB disk, FACTS §4) to demonstrate objective 7 — this is the only place Super appears.

**Artefact.** `outputs/15/pareto.json` plus `outputs/15/how_to_fit_it.md`, the learner's
own reference sheet.

**Completion criterion.** The learner can state, with a measured number, the largest job
their machine will complete in ten minutes.

---

# Module 5 — Post-training (7 h)

*Also entirely new. The source course does not mention fine-tuning.*

## Lesson 16 — `16_posttraining_concepts`

**Purpose.** Establish what supervised fine-tuning changes and what data it needs, before
any attempt to run it. Most of this lesson is data engineering, which is where most of the
real work in post-training actually is.

**Learning objectives.** By the end, the learner can:

1. State what SFT changes in a Cosmos 3 checkpoint and which tower is affected by which
   recipe.
2. Read `docs/dataset_jsonl.md`'s generator schema and write a valid JSONL record.
3. Name the two silent loader filters and check for them: clips longer than 61 s are
   dropped, and windows shorter than 61 frames are dropped (FACTS §5). Verify a dataset
   against both before training rather than after.
4. Describe LeRobotDataset **v3.0** structure — chunked Parquet, AV1 MP4 shards,
   `meta/info.json`, `meta/stats.json`, `meta/tasks.parquet`, `meta/episodes/` — and say
   how it differs from v2.
5. Download and inspect `nvidia/BridgeData2-Subset-Synthetic-Captions` (0.65 GB,
   1,222 clips) and `nvidia/LIBERO_LeRobot_v3` `libero_10` (~0.5 GB, 379 episodes).
6. Explain why `nvidia/Cosmos3-DROID` (707 GB, 57,639 episodes) is disqualifying for a
   single-machine lab, with the number.
7. Read a shipped SFT TOML and locate `optimizer.keys_to_select`, `ema.enabled`,
   `max_num_tokens_after_packing`, and the LoRA block.
8. Explain that `SFTExperimentConfig` validates with `extra="forbid"`, and what that means
   for a typo in a config key.
9. Build a small SFT dataset from their own Module 2 outputs.

**Prerequisites.** Lesson 15.

**Concepts introduced.** SFT versus pretraining; JSONL generator datasets; LeRobot v3;
selective parameter training via `keys_to_select`; TOML configuration with strict
validation; dataset filters that fail silently.

**Hands-on skills.** Dataset inspection and validation. Reading a training config as a
memory budget rather than as a list of settings.

**Time.** 2.0 h, including ~1.2 GB of dataset downloads.

**Resources.** `nvidia/BridgeData2-Subset-Synthetic-Captions` 0.65 GB;
`nvidia/LIBERO_LeRobot_v3` `libero_10` ~0.5 GB (or all suites, 4.5 GB, 5,614 episodes).
No GPU required for most of the lesson.

**Artefact.** `outputs/16/my_dataset.jsonl` — a validated JSONL dataset built from the
learner's own generated clips, passing both loader filters.

**Completion criterion.** The dataset loads without silently dropping records, and the
learner can say how many records each filter would have removed.

---

## Lesson 17 — `17_posttraining_one_gpu` ⚠

**Purpose.** Do the memory arithmetic that determines whether a shipped 8-GPU recipe can
be shrunk to one, then attempt it. This lesson is framed as an experiment with a predicted
outcome, because that is what it is.

**Learning objectives.** By the end, the learner can:

1. State the honest headline: NVIDIA documents no single-GPU training path. Every shipped
   recipe assumes ≥8 GPUs; the smallest documented claim is Edge "also fits a 4-GPU node"
   (FACTS §5).
2. Compute the full-SFT memory bill for Nano from first principles — 32 GB bf16 params,
   64 GB fp32 master, 128 GB AdamW moments, 32–64 GB gradients, +64 GB EMA — reaching
   ≈256–350 GB before a single activation byte, and conclude that it is 3–4× an H100.
3. Explain why activation checkpointing does not rescue this: the blocker is optimizer
   state, not activations.
4. Explain the shipped HSDP 2×8 recipe as the resolution of exactly that arithmetic —
   ≈256 GB ÷ 16 ranks ≈ 16 GB per rank.
5. Redo the arithmetic for `vision_sft_edge`, where `optimizer.keys_to_select =
   ["moe_gen","time_embedder","vae2llm","llm2vae","k_norm_und_for_gen"]` leaves ~2B
   trainable, reaching ≈45–50 GB of state and ~30 GB for activations.
6. Modify the shipped 8-GPU TOML for one GPU: `NPROC_PER_NODE=1`, `ema.enabled=false`,
   `max_num_tokens_after_packing` cut down from its 8-GPU value of 45,056,
   `torch.compile` off, `PYTORCH_ALLOC_CONF=expandable_segments:True`.
7. Enable LoRA and explain its constraint: first-class but **VFM (generator) only**,
   explicitly skipped on the VLM/reasoner path; `lora_rank` 16, `lora_alpha` 32, default
   targets `q_proj_moe_gen,k_proj_moe_gen,v_proj_moe_gen,o_proj_moe_gen`, paired with
   `optimizer.keys_to_select=["lora_"]`.
8. State what is not available and stop looking for it: no 8-bit optimizer, no CPU offload
   of any kind, only fused AdamW (FACTS §5).
9. Attempt the run, and report the outcome — including the OOM step number and the setting
   that caused it — as a valid result either way.

**Prerequisites.** Lessons 14 and 16. Lesson 14's OOM ladder is used directly.

**Concepts introduced.** Optimizer-state memory as the binding constraint in training;
EMA as a hidden fp32 copy; selective parameter training; LoRA and its scope limit;
token packing as a memory knob; the difference between a documented path and an
extrapolation.

**Hands-on skills.** Memory arithmetic from parameter counts. Editing a strict TOML.
Running a training job that may not fit, and reporting that honestly.

**Time.** 3.0 h, and this is the lesson most likely to overrun. Budget the full three
hours and treat completion of the run as optional.

**Resources.** Cosmos3-Edge, 9.1 GB. Dataset from Lesson 16. Full 80 GB of the H100 —
nothing else may be resident, including the NIM. Disk for checkpoints, ~20 GB (estimate).

**Artefact.** `outputs/17/training_report.md` — the memory arithmetic, the modified TOML,
what happened, and either a LoRA adapter or a documented failure with the specific
blocking setting.

**Completion criterion.** The learner can defend, with their own numbers, why full Nano
SFT cannot work on this machine, and has either a running Edge fine-tune or a precise
account of why not.

**Validation status.** The Edge single-GPU path is **undocumented by NVIDIA** and is
treated by this course as an experiment with a predicted outcome, not a promise
(FACTS §5). A failed run that produces the report is a pass.

---

## Lesson 18 — `18_evaluation`

**Purpose.** Answer "did it get better?" in a repository that ships no way to ask.

**Learning objectives.** By the end, the learner can:

1. State the gap plainly: `cosmos_framework/evaluation/` is listed in
   `docs/code_structure.md` as `[planned]` and is not present in this release. There is no
   offline metric harness, no action-MSE script, and no validation-loss loop (FACTS §5).
2. Explain what *does* exist — closed-loop simulation eval via LIBERO and RoboLab — and
   why it needs the separate venv from Lesson 13.
3. Design an evaluation for a stated claim, specifying the metric, the control, the sample
   size and the failure mode the metric would miss.
4. Build a fixed prompt/seed suite and run it before and after a change, holding
   everything else constant.
5. Implement at least two automatic metrics — for example round-trip action consistency
   from Lesson 11, and reasoner-as-judge plausibility screening from Lesson 04 — and state
   each one's bias.
6. Explain why reasoner-as-judge is circular when the reasoner and generator share a
   checkpoint, and propose a mitigation.
7. Distinguish a real improvement from seed variance by running the control multiple
   times.
8. Report a negative or null result without hedging it.

**Prerequisites.** Lesson 17. Works with or without a successful fine-tune — with one, it
compares base against tuned; without one, it compares configurations of the base model.

**Concepts introduced.** Evaluation design under a missing harness; controls and seed
variance; automatic metrics and their biases; circularity in model-as-judge; the value of
a null result.

**Hands-on skills.** Designing an evaluation from scratch. Implementing metrics. Reporting
honestly.

**Time.** 2.0 h.

**Resources.** Whatever model the learner is evaluating. No new downloads.

**Artefact.** `outputs/18/eval_report.md` with a stated hypothesis, a method, results
including variance, and a conclusion the learner is willing to defend.

**Completion criterion.** The report contains a control condition and a variance estimate.
A report claiming an improvement without either does not pass.

---

# Module 6 — Capstone (5 h)

## Lesson 19 — `19_capstone_synthetic_data_flywheel`

**Purpose.** Build the loop the source course described in every introduction and never
constructed: reason about real footage, generate on-distribution variants, screen them,
and use them for something.

**Learning objectives.** By the end, the learner can:

1. Design a pipeline that takes real clips to screened synthetic training data, with a
   stated budget in GPU-hours and gigabytes.
2. Implement the reasoning stage: caption clips into structured scene records
   (Lesson 03) and extract the attributes worth varying (Lesson 05).
3. Implement the generation stage: turn records into prompts and produce variants through
   `image2video` (Lesson 07) and control-conditioned `video2video` (Lesson 08).
4. Implement the screening stage: automatic checks with `check_video()` plus
   reasoner-based physical-plausibility screening (Lesson 04), with a stated rejection
   rate.
5. Schedule the pipeline on one GPU, taking turns between the NIM and the generator
   (Lesson 02), and report the scheduling overhead as a fraction of total time.
6. Measure the whole pipeline (Lesson 14) and identify the bottleneck stage with numbers.
7. Evaluate the output set (Lesson 18) against a stated quality criterion, and report the
   yield.
8. Write an honest limitations section covering what they did not verify.

**Prerequisites.** Lessons 03, 05, 07, 08, 12, 14, 18. Effectively the whole course.

**Concepts introduced.** Nothing new. Integration is the point.

**Hands-on skills.** Pipeline design under a hard resource constraint. Scheduling
competing GPU workloads. End-to-end measurement. Technical writing about one's own work.

**Time.** 5.0 h.

**Resources.** Nano and Edge, both local. Reasoner NIM. Outputs 10–20 GB depending on
scope. Whole GPU, scheduled between stages.

**Artefact.** A working pipeline implemented against six published interface contracts,
plus `outputs/capstone/manifest.jsonl` (one record per *attempted* variant, with
provenance, prompt, accept/reject and reason), `outputs/capstone/metrics.json`, and
`outputs/capstone/REPORT.md` written against
`assets/reference/CAPSTONE_REPORT_TEMPLATE.md`.

**Graded against.** `assets/reference/CAPSTONE_RUBRIC.md` — six weighted criteria and
three pass/fail gates. Running successfully is not sufficient; profiling, evaluation and
interpretation are required to pass.

**Two modes, both first-class.** `reduced` — Cosmos3-Edge at the 256 tier, 3 source clips,
~9 variants, sized for 45–60 minutes so the whole pipeline can be validated end to end
before anything expensive. `full` — Cosmos3-Nano at 480p, 6 clips, 24 variants, hours, and
opt-in behind an explicit download flag. Note that Edge cannot run transfer at all
(FACTS §1), so in reduced mode the control-modality decision is *designed and
spec-validated* rather than executed; running it needs Nano.

**Completion criterion.** The pipeline runs end to end unattended, produces a screened
dataset with rejections and failures reported as *separate* numbers, survives four
injected failures (a rejected clip, an OOM, a dead NIM, a malformed model response)
without losing completed work, and the report names a bottleneck with a measured number
attached and states what the evidence does not support. Every performance figure in the
report must appear in a file under `outputs/capstone/`.

---

## Time and resources by module

| Module | Lessons | Hours | New downloads | Peak VRAM | Cumulative disk |
|---|---|---:|---|---|---:|
| 0 Foundations | 00, 01 | 3.0 | Edge 9.1 GB, guardrail 3.63 GB, VAE 2.82 GB, Qwen3Guard 1.52 GB | ~12 GB (est.) | ~20 GB |
| 1 Perceive | 02–05 | 7.0 | Reasoner NIM 8.28 GB image, 20 GB FP8 nano profile | up to 80 GB uncapped | ~50 GB |
| 2 Imagine | 06–09 | 8.0 | Nano 34.9 GB | 32 GB (FACTS §3) | ~95 GB |
| 3 Act | 10–13 | 7.0 | Edge-Policy-DROID 9 GB, LIBERO 0.5 GB, second venv ~10 GB (est.) | 32 GB | ~115 GB |
| 4 Systems | 14, 15 | 5.0 | optional Super reasoner FP8 profile 40 GB | 32 GB, or ~40 GB with Super reasoner | ~115 GB (155 GB with Super) |
| 5 Post-training | 16–18 | 7.0 | BridgeData2 0.65 GB, checkpoints ~20 GB (est.) | ~50 GB state + activations (FACTS §5) | ~140 GB |
| 6 Capstone | 19 | 5.0 | none | 32 GB | ~155 GB |
| **Total** | **20** | **42.0** | | | **~155 GB** |

Disk is cumulative and assumes nothing is deleted. `COSMOS3_FACTS.md` §3 recommends
~150 GiB free for a first full run; this course sits right at that figure, so a machine
with less needs the pruning plan in `04_INSTRUCTOR_GUIDE.md`.

Peak VRAM figures are the documented inference numbers where they exist (Nano 32 GB,
FACTS §3) and working estimates otherwise (Edge ~12 GB; the reasoner NIM's uncapped
resting footprint of 60–75 GB on an 80 GB card is an estimate from
`cosmos_course/nim.py` and is the number Lesson 02 has the learner measure for real).

## Attended versus scheduled time

| | Hours |
|---|---:|
| Scheduled total | 42.0 |
| Unattended download (Edge, Nano, NIM profile, policy checkpoint, datasets) | 2.0–3.5 (est.) |
| Unattended compute that can overlap discussion (transfer runs, the Lesson 17 attempt, capstone batches) | 2.0–2.5 (est.) |
| **Attended** | **~36–38** |

Both unattended figures are estimates and the download figure depends entirely on network
speed. On a slow link the download alone can exceed the whole of Module 0.
