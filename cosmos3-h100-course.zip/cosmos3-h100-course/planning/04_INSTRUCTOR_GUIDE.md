# Instructor guide

For anyone delivering **Physical AI with Cosmos 3 on a single H100 80 GB** as a taught
course. It assumes you have read `01_SOURCE_AUDIT.md` and `02_PROPOSED_CURRICULUM.md`.

Two things to know before you plan anything.

**One GPU is the pedagogy, not a limitation.** Almost every difficulty in this course is a
scheduling problem: two things want the card and only one can have it. If you find
yourself apologising for the constraint, you have lost the thread. The constraint is what
makes the memory arithmetic in Modules 4 and 5 matter, and it is the condition most
learners will actually work under.

**Downloads dominate the first day.** Roughly 120 GB arrives across the course, most of it
in Modules 0–2. Nothing in this guide works if you have not pre-staged what you can. See
"Running the course with less GPU time" below.

---

## Module 0 — Foundations (3 h scheduled)

### Timing

| Segment | Planned | Notes |
|---|---:|---|
| L00 environment check | 60 min | Runs to time if the machine is prepared |
| L01 mental model, lecture portion | 45 min | |
| L01 first Edge generation | 45 min | Includes the download |
| L01 mode-enum verification and discussion | 30 min | |

**Where people run over.** The Edge download plus the three first-run auxiliary pulls
(guardrail 3.63 GB, Wan2.2 VAE 2.82 GB, Qwen3Guard-Gen-0.6B 1.52 GB) is 17 GB before
anyone has seen an image. On a shared classroom link this can take an hour. Start it
during Lesson 00 and teach over it.

The other overrun is the guardrail licence click. It is the only gated repository left
(FACTS §1), and a learner who has not accepted it gets a 403 partway through a download
that has already been running for several minutes. Check the whole room has accepted it
*before* the first generation, not after.

### Discussion prompts

**"Nano is 8B or 16B. Which number should be on the slide?"** Defensible either way. The
active count is what a learner needs for inference budgeting and is what NVIDIA's own docs
and NIM use. The total is what is on disk, what training must budget against, and what
Hugging Face reports. The interesting answer is that a course which picks one and hides
the other will mislead someone; the rule in FACTS §1 — active for inference, total for
training — is a rule precisely because neither number alone is enough.

**"Upstream docs say `policy`. The enum says `wam`. Which do you trust, and how would you
have found out?"** This is the course's methodological thesis in one question. Most rooms
will say "the code", which is right, but push on the follow-up: the raw GitHub URL that
most people would reach for serves a stale cached copy still showing `POLICY = "policy"`
(FACTS §2). Trusting the code is not enough if you fetch it wrongly.

**"Should the guardrail be on by default?"** Genuinely two-sided. On: it is the vendor's
safety commitment, and a research pipeline that silently produces unscreened synthetic
training data is a real hazard. Off: it costs ~3.6 GB, it adds latency, it can blank
outputs while reporting success, and a researcher generating robot-arm footage is not the
threat model it was built for. Do not resolve it.

### Demonstration notes

**Show live:** `nvidia-smi` on the teaching machine, narrating each column. The mode-enum
extraction — do it live, in a terminal, against the actual checkout, because the point is
the method.

**Let them discover:** the disk arithmetic. Do not put the total on a slide. Have them
compute it from `MODEL_TIERS` and compare against their own free space. Someone will
discover their machine is short, which is a better moment in Lesson 00 than in Lesson 06.

Also let them discover the `config._assess()` thresholds. Objective 6 asks them to argue
with one. The 100 GB host-RAM warning and the 60 GB disk warning are both arguable, and a
room that argues about them has understood that these are judgements, not laws.

### Likely difficulties

| Symptom they report | Actual cause |
|---|---|
| "`nvidia-smi` works but `torch.cuda.is_available()` is False" | Almost always a CPU-only torch wheel, occasionally a driver/runtime mismatch. Check `torch.version.cuda` first; if it is `None`, it is the wheel |
| "Docker says permission denied" | User not in the `docker` group. On some setups a `newgrp` is insufficient and a fresh login shell is required |
| "The Docker GPU test hangs" | The NVIDIA Container Toolkit is installed but the daemon was not restarted after installation |
| "My first generation 403'd after ten minutes" | Guardrail licence not accepted. The checkpoint downloaded fine because it is not gated; the guardrail is |
| "The download is stuck at 80 %" | The Xet transfer backend stalling on large shards. Set `HF_HUB_DISABLE_XET=1` and it resumes on the classic path |
| "It says compute capability 9.0 but the course mentions 8.9 for FP8" | Not a problem. 8.9 is the floor; Hopper is 9.0 and clears it |

### Optional extensions

Have a fast group serve the **Super** reasoner at FP8 (40 GB profile, FACTS §4) and
observe that a 64B-total model reasons happily on one H100 while a 64B-total model cannot
generate on it. That asymmetry is the whole architecture in one experiment, and it seeds
Lesson 15 objective 7.

---

## Module 1 — Perceive (7 h scheduled)

### Timing

| Segment | Planned | Notes |
|---|---:|---|
| L02 serving the reasoner | 120 min | 20–40 min is the image pull and profile download |
| L03 captioning | 90 min | |
| L04 embodied reasoning | 105 min | |
| L05 spatial reasoning | 105 min | |

**Where people run over.** Lesson 02, badly, in two places. The NIM pull is 8.28 GB
compressed plus a 20 GB profile download, and the first `start_nim` on a cold cache can
take twenty minutes with no useful progress output. Start it before the break.

The second overrun is `discover_memory_env()`. The course cannot pin the memory-limit
environment variable's name because it was not verifiable against a running NIM 1.7 at
authoring time (`cosmos_course/nim.py` says so explicitly). Learners will want a
definitive answer and there is not one. Budget fifteen minutes for the room to find it
together and be comfortable saying "this is what unverified looks like".

Lesson 05 runs long if the Set-of-Mark section is done properly, because deriving marks
from the lesson's own grounding output means grounding has to work first. If you are
short, hard-code marks as the source did and say you are doing so.

### Discussion prompts

**"You have one card. Do you take turns, or cap the NIM?"** The course recommends taking
turns and says so. But a learner doing Lesson 19's plan-then-render loop will switch
dozens of times, and model-load latency on every switch is a real cost. Capping trades KV
cache for switching cost. Neither is right in the abstract, and the correct answer depends
on a ratio the learner has to measure.

**"Chain of thought is auditable. Is it honest?"** The strong position: a `<think>` block
lets you inspect why a model reached a conclusion before it drives hardware, which is the
argument the source makes. The other position: a plausible reasoning trace attached to a
wrong answer is worse than a bare wrong answer, because it manufactures confidence.
Lesson 04 objective 6 requires the learner to find such a case, so this discussion should
happen *after* someone has one.

**"Is captioning a perception task or a compression task?"** Worth ten minutes. If a
caption is a lossy compression of a clip, the right question about a captioning prompt is
what it chose to discard — which reframes prompt design as codec design and makes the
schema-request exercise in Lesson 03 obvious rather than arbitrary.

### Demonstration notes

**Show live:** the deliberate OOM in Lesson 02. Start the NIM uncapped, run
`nim_status()` to show it holding 60–75 GB of an 80 GB card, then launch a generation and
let it fail. This takes four minutes and it is the single most useful demonstration in the
course. Do not let them discover it — an unexplained OOM in week one costs a learner an
hour and teaches nothing.

**Let them discover:** the 422 on an AV1 video. Give one group a clip that is not H.264
and let them hit the error. The failure is fast, the error message is uninformative, and
the fix (`ensure_h264`) is in front of them. Twenty minutes of productive frustration.

Also let them discover the fps/token relationship in Lesson 03. Do not state that doubling
fps roughly doubles context. Have them measure it and say so themselves.

### Likely difficulties

| Symptom they report | Actual cause |
|---|---|
| "The NIM started but `/v1/models` is empty" | It is still loading the profile. Health-ready and model-list readiness are not the same thing; poll `/v1/health/ready` |
| "Connection refused on port 8000" | Either the container exited (check `docker logs`) or they are using the source's `http://cosmos3-reasoner:8000`, which is Compose service DNS and does not resolve here |
| "422 Unprocessable Entity on a video" | OpenCV in the NIM returned zero frames. Almost always AV1. `ensure_h264()` fixes it |
| "It worked yesterday, now the generator OOMs" | The NIM is still running from yesterday. `docker ps` |
| "My bounding boxes are in the wrong place" | Coordinates are normalised to 0–1000 and they scaled against the *displayed* size rather than the original image size |
| "The model returned prose instead of JSON" | The prompt asked nicely instead of specifying a schema. Also check whether they are parsing before the `</think>` split |
| "Set-of-Mark captions describe the wrong objects" | The marks and the prose disagree, exactly as they do in the source (audit §4.11). Check the mark count against what was asked for |
| "Everything is slow today" | Another learner's generation is on the same card, or `fps` is set high enough that each request is sending hundreds of image tokens |

### Optional extensions

Bring-your-own-footage. The source has two commented-out URLs in notebook 02 cell 13
pointing at cookbook recipe assets; make that an exercise. A learner captioning their own
robot or dashcam footage will find failure modes no curated asset shows.

For a strong group: run the same six reasoning tasks against the Super reasoner at FP8 and
quantify whether 32B active parameters buy anything on physical-common-sense questions.
Design the comparison first — it is a good rehearsal for Lesson 18.

---

## Module 2 — Imagine (8 h scheduled)

### Timing

| Segment | Planned | Notes |
|---|---:|---|
| L06 fundamentals | 150 min | 40–70 min is the Nano download |
| L07 conditioned generation | 120 min | |
| L08 control | 120 min | Longest individual runs in the course |
| L09 audio and guardrail | 90 min | |

**Where people run over.** Lesson 06's cost curve. Learners will want to sweep every knob
across every value. Constrain it: three step counts, three frame counts, two resolutions,
one model, on the *cheapest* configuration that shows the trend. The point is the ratio,
not the resolution.

Lesson 08 is the other one. Transfer runs at 121 frames and 30 FPS take several minutes
each, and objective 3 requires at least three hints. That is fifteen to twenty minutes of
pure compute before anyone can compare anything. Launch all three at the start of the
lesson, teach the conceptual material while they run, and compare at the end.

### Discussion prompts

**"`create_payload` printed the settings back at you. Was that control?"** Look at the
source's helper together (audit §4.8). It takes four parameters and applies eight, then
prints all eight. Ask what a good helper does with an expensive default. Some rooms
defend the pattern as reasonable API design with sensible defaults; the counter is that
resolution and frame count are not settings, they are the bill.

**"720p × 189 frames × 35 steps is the source's first example. Would you have chosen it?"**
Defensible yes: it shows the model at its best, and a first impression matters. Defensible
no: it is the most expensive job in the package, the most likely to OOM on one card, and
it takes long enough that a learner cannot iterate. This is a real curriculum-design
question and there is no correct answer.

**"Should transfer be taught as a mode or as a mechanism?"** The source teaches it as a
capability called "augmentation" and never says `video2video`. That is more accessible and
leaves the learner unable to write a spec. Teaching the mechanism first is more accurate
and drier. Ask which they would do, then point out that the source's choice is why nobody
who finishes it can write a transfer spec from scratch.

**"The guardrail can blank an output while the run reports success. Is a silent guardrail
a bug?"** Two positions. It is not: refusing loudly leaks information about the classifier
and the correct behaviour for a safety system is to fail closed. It is: a data pipeline
that silently drops a fraction of its output produces a biased dataset and nobody knows.

### Demonstration notes

**Show live:** the difference between allocated and reserved memory during a generation
run, with `describe_memory()`. This lands better in Module 2, where a run is actually
happening, than in Module 4 where it is nominally taught.

Also show live the guardrail rejection in Lesson 09. You need a prompt that reliably
trips it, and you should have found one *before* the class rather than improvising in
front of a room.

**Let them discover:** that `check_video()` catches something their eyes did not. Generate
one clip with a deliberately broken configuration, put it next to a good one, and ask
which is which before running the check.

Also let them discover the aspect-ratio format. `"16,9"` with a comma, not `16:9`, not
`1.777`. `validate_spec()` catches it. Letting someone hit it once is worth more than a
warning on a slide.

### Likely difficulties

| Symptom they report | Actual cause |
|---|---|
| "CUDA out of memory at step 3 of 35" | The frame count and resolution, nearly always. Check the spec before the code. See the OOM procedure below |
| "It finished in twelve seconds and the video is grey" | Guardrail rejection, or a spec that produced one frame. `RunResult.diagnose()` distinguishes them |
| "Exit code 0 but no output file" | The framework wrote to a different output directory than the one being inspected — usually a relative `-o` resolved against the process cwd, not the notebook's |
| "Transfer produces a video the wrong length" | Expected. The output geometry and frame count come from the control video, not from the spec. Say this before it happens |
| "`aspect_ratio` rejected" | `16:9` instead of `16,9` |
| "Transfer does nothing on Edge" | Edge does not support transfer at all (FACTS §1). This is the most common consequence of a learner dropping to Edge to save memory |
| "My audio video has no audio" | `enable_sound` not set, or the mode is `image2video` rather than `audio_image2video`, or they are on Edge, which has no audio |
| "The notebook front-end has gone unresponsive" | A full-resolution video base64-embedded into cell output. Use `show_video`, which transcodes a small preview first |
| "The same seed gave a different video" | Something else changed — resolution, frame count, or the model tier. Diff the specs, not the code |

### Optional extensions

Multi-control transfer with `TransferArgs.weight`. Flag honestly that the cookbook's
`assets/multi_control/` directory is referenced in its README and does not exist in the
checkout (FACTS §2), so this is an exercise in building the assets, not in running a demo.

A quality ladder: the same prompt on Edge at 480p and Nano at 768p, with the time and VRAM
cost of the difference measured. This is a preview of Lesson 15 and it is worth doing here
while both models are warm.

---

## Module 3 — Act (7 h scheduled)

### Timing

| Segment | Planned | Notes |
|---|---:|---|
| L10 forward dynamics | 105 min | |
| L11 inverse dynamics | 105 min | The pose maths is the variable |
| L12 wam | 105 min | |
| L13 closed loop | 105 min | Second venv build dominates |

**Where people run over.** Lesson 11, if the room is not comfortable with rigid-body
transforms. Objective 3 asks them to explain 6D rotation, which for some groups is
fifteen minutes and for others is fifty. Have a shorter path ready: state the result —
`rot6d` stores two 3-vectors and Gram-Schmidts them back into a rotation matrix, avoiding
the discontinuities that make Euler angles and quaternions awkward to regress — and move
on, returning to it only if there is time.

Lesson 13 runs over because `uv`/`pip` resolving `robosuite==1.4.1`, `mujoco==2.3.7` and
`torch<2.6` takes real time. Build the second venv *before* the session.

### Discussion prompts

**"Should this course teach the `policy` failure, or just teach `wam`?"** The course
deliberately has learners reproduce the failure (Lesson 12 objective 2). The argument
against: you are spending class time on an error, and every minute on a dead name is a
minute not spent on the live one. The argument for: they will meet `policy` in upstream
docs, in the cookbook README, and in every blog post written before the rename, and an
error they have seen once is not frightening. Let the room decide and note that this is a
general question about teaching deprecations.

**"Forward and inverse dynamics round-trip imperfectly. Is that model error?"** Genuinely
open. Some of it is model error. Some is `translation_scale=1.35`, a constant with no
stated source that scales every recovered translation (audit §4.13). Some is that
monocular motion estimation has an inherent scale ambiguity that no model can resolve.
Lesson 11 objective 8 asks for a check that separates them, and there is no clean answer.

**"Is a world action model a policy?"** It predicts actions from an observation and an
instruction, which is what a policy does. It also predicts video, which no policy does,
and it runs open-loop over a chunk rather than closed-loop per step. Whether the extra
video output is a useful auxiliary signal or an expensive distraction is a real research
question and learners should be told it is one.

### Demonstration notes

**Show live:** the `policy` → `wam` failure and its fix, once, at the start of Lesson 12.
Then have them reproduce it.

**Let them discover:** the two action layouts. Do not tell them the AV action is 9-D and
the manipulation action is 10-D. Let them run both, print both shapes, and notice. The
source's only acknowledgement of this is a defensive conditional
(`action[:, 9] if action.shape[1] > 9 else None`), which is worth showing afterwards as an
example of code that knows something the prose does not.

Also let them discover the distribution boundary in Lesson 10 objective 7. Hand-authoring
an increasingly implausible trajectory until the video falls apart is the most memorable
twenty minutes in Module 3.

### Likely difficulties

| Symptom they report | Actual cause |
|---|---|
| "`model_mode: policy` — KeyError / invalid mode" | Expected, and the point. It is `wam` |
| "`action_chunk_size` seems to do nothing" | It interacts with `fps` and the input length; changing it alone may not change the output length. Check the record end to end |
| "The recovered trajectory is the right shape but the wrong scale" | `translation_scale`. Monocular scale ambiguity, plus an unexplained constant |
| "3D plot is empty" | `np.ptp` over a degenerate axis produced a zero box aspect. Usually means the predicted motion was near-zero, which is itself the finding |
| "The `wam` run needs network access and I am on a captive portal" | The source fetches its start observation from a raw GitHub URL mid-cell. This course caches it via `scripts/fetch_assets.py`; if that has not been run, it has not been cached |
| "`import cosmos_framework` fails in the action visualisation" | Wrong kernel. `pose_rel_to_abs` lives in the framework venv. The source works around this with `sys.path.insert`, which imports the module without its dependencies |
| "`pip install robosuite` broke my framework venv" | Exactly the conflict Lesson 13 is about. `torch<2.6` downgraded torch under the framework. Rebuild the framework venv and do it in a separate one |
| "The policy server starts and immediately exits" | Usually the checkpoint path, occasionally VRAM. Check `docker logs` / the process output before assuming memory |

### Optional extensions

Post-trained policy comparison: run `Cosmos3-Edge-Policy-DROID` (4B, ~9 GB) against base
Edge on the same manipulation observation and characterise the difference. This is the
cheapest available demonstration that post-training does something, and it costs 9 GB
rather than the 30 GB of the Nano policy checkpoint.

For a group with time and patience: a genuine LIBERO closed-loop run. Flag it as
unvalidated by this course (see below).

---

## Module 4 — Systems (5 h scheduled)

### Timing

| Segment | Planned | Notes |
|---|---:|---|
| L14 measurement | 150 min | |
| L15 optimisation | 150 min | The sweep is the variable |

**Where people run over.** The Lesson 15 Pareto sweep, invariably. A full grid over three
axes on two models is hours of compute. Constrain it to a diagonal — vary one axis at a
time from a common baseline — and have the room pool results rather than each learner
sweeping alone. Pooling is also a better lesson about experiment design.

Lesson 14's deliberate OOM (objective 6) can also eat time, because recovering a notebook
kernel after an OOM is slower than people expect and some learners will need to restart.
Do it once, together, at a known-good checkpoint in the lesson.

### Discussion prompts

**"Your speedup was 40×. Do you believe it?"** Run this before teaching synchronisation.
Someone will produce an absurd number by timing a kernel launch, and the room's instinct
about whether to believe it is the lesson. The follow-up — how many published speedups
have this bug — is worth asking and not answering.

**"Does `--parallelism-preset` mean anything at world size 1?"** The source uses
`throughput` in one notebook and `latency` in another without explanation. The measured
answer on one GPU is probably "very little", but "probably" is doing work there. Have them
measure it and report a null result if that is what they find. A room that learns to
report "no measurable difference" without embarrassment has learned something durable.

**"Is fragmentation worth worrying about?"** Reserved-minus-allocated is real and
`expandable_segments:True` genuinely helps some workloads. It is also the first thing
people reach for when the actual problem is that they asked for 189 frames at 768p.
Discuss when a memory knob is the answer and when it is displacement activity.

### Demonstration notes

**Show live:** the warm-up effect. First call, second call, tenth call, on the same
operation in the same process. It is thirty seconds and it makes `benchmark()`'s design
obvious.

**Let them discover:** the OOM ladder's uselessness on one GPU. Give them the FAQ's six
levers and let them work out that raising the FSDP shard degree and raising the
context-parallel degree both need GPUs they do not have (FACTS §5). Four of six levers
survive. That realisation sets up Module 5 exactly.

### Likely difficulties

| Symptom they report | Actual cause |
|---|---|
| "My timings are wildly inconsistent" | No warm-up, or another process on the card, or thermal throttling on a long sweep. Check `nvidia-smi` for a second process first |
| "Peak memory is lower than the model size" | They are reading allocated, not reserved, and the weights are in the framework subprocess rather than this process. `memory_snapshot(driver=True)` reconciles it |
| "`expandable_segments` did nothing" | It usually does very little for a workload whose peak is a single large allocation. Not a failure |
| "The kernel died and now nothing works" | Post-OOM, CUDA context may be unrecoverable in-process. Restart the kernel; this is normal and worth saying in advance |
| "Edge is not much faster than Nano" | Check whether the comparison held resolution and frame count fixed. Also check whether the measurement includes model load, which dominates short runs |

### Optional extensions

Have the room build a shared results table across all machines present. Variance between
nominally identical H100s — SXM versus PCIe, different driver versions, different thermal
headroom — is real, visible, and a good corrective to the idea that a benchmark number is
a property of a model.

---

## Module 5 — Post-training (7 h scheduled)

### Timing

| Segment | Planned | Notes |
|---|---:|---|
| L16 concepts and data | 120 min | |
| L17 the one-GPU attempt | 180 min | Will overrun. Plan for it |
| L18 evaluation | 120 min | |

**Where people run over.** Lesson 17, without exception. The memory arithmetic is 45
minutes if the room engages with it, the TOML editing is 30, and then the run either
starts or does not. If it starts, it runs for as long as you let it. If it does not, the
debugging is open-ended.

Set expectations at the top of the lesson: **a documented failure is a pass.** The
artefact is `training_report.md`, not a checkpoint. If you do not say this explicitly,
learners will treat the OOM as their fault, and the honest finding — that the single-GPU
Edge path is undocumented and may not work — will not get written down.

### Discussion prompts

**"NVIDIA documents no single-GPU training path. Should this course attempt one?"**
Defensible no: teaching an undocumented extrapolation as if it were a path risks learners
carrying a false belief into their own work. Defensible yes: the arithmetic is sound, the
levers are real, and refusing to try teaches learned helplessness about a constraint most
people actually have. The course chose yes with the outcome framed as an experiment, and
that choice is worth arguing about in the room.

**"EMA defaults to true and costs another fp32 copy of every parameter. Why is that the
default?"** EMA weights usually generalise better and the shipped recipes run on enough
GPUs that the cost is invisible. The design question — whether a default should be tuned
for the vendor's hardware or the user's — has no clean answer and comes up constantly in
this ecosystem.

**"LoRA is generator-only and explicitly skipped on the reasoner path. What does that
tell you?"** Speculative and productive. It may say something about how the reasoner tower
is trained, about which capability NVIDIA expects people to adapt, or simply about
engineering priority. Do not pretend to know.

**"There is no evaluation harness. Is that a gap or a statement?"** `cosmos_framework/
evaluation/` is `[planned]` and absent (FACTS §5). One reading: it is unfinished. Another:
offline metrics for world models are genuinely bad, and shipping closed-loop simulation
eval instead is a considered position. Both are arguable and the second is more
interesting.

### Demonstration notes

**Show live:** the memory arithmetic, on a whiteboard, in front of them. 16B × 2 bytes =
32 GB of bf16 parameters. Plus 64 GB of fp32 master weights. Plus 128 GB of AdamW moments.
Plus gradients. Plus another 64 GB if EMA is on. The total crosses 80 GB before the third
line, and watching it happen is worth more than reading the table.

**Let them discover:** why the shipped recipe is HSDP 2×8. Give them ≈256 GB and 16 ranks
and let them divide. The recipe stops looking arbitrary immediately.

Also let them discover `extra="forbid"`. Have them make a typo in a TOML key. The error is
immediate and clear, which is a good property, and understanding why a config validator
should be strict is a transferable lesson.

### Likely difficulties

| Symptom they report | Actual cause |
|---|---|
| "OOM immediately, before step 1" | Optimizer state allocation. If EMA is still enabled this is guaranteed. Check `ema.enabled` first, always |
| "OOM at step 40 after running fine" | Activations, and probably `max_num_tokens_after_packing` still at its 8-GPU value of 45,056 |
| "Unknown config key" | `extra="forbid"`. A typo, or a key copied from a different recipe version |
| "The dataset loaded but training sees fewer samples than I have" | The two silent loader filters: clips over 61 s dropped, windows under 61 frames dropped (FACTS §5). Check before training, not after |
| "LoRA is enabled but nothing is training" | `optimizer.keys_to_select` not set to `["lora_"]`, so the selected parameters and the LoRA parameters are disjoint |
| "Can I offload the optimizer to CPU?" | No. `SFTExperimentConfig` has no parameter, optimizer-state or activation offload of any kind, and there is no 8-bit optimizer (FACTS §5) |
| "torch.compile makes it OOM" | Compilation working memory on top of an already-tight budget. Turn it off; it is in the course's recommended modifications for exactly this reason |
| "My eval says the fine-tune is better but I only ran it once" | Seed variance. Lesson 18 objective 7 exists because of this and it will still happen |

### Optional extensions

Compare a LoRA fine-tune against full-parameter selective training on Edge, if the
selective path runs at all. If it does not, comparing LoRA against the base model is still
a complete experiment.

For a strong group: implement a validation-loss loop, since none ships. It is a genuine
contribution and it is not hard.

---

## Module 6 — Capstone (5 h scheduled)

### Timing

Give them the full five hours with two checkpoints: a design review at 45 minutes and a
progress check at 2.5 hours. The design review is the important one — most capstone
failures are scope failures decided in the first half hour.

**Where people run over.** Scope. Every group will want more source clips, more variants
and more hints than five hours allows. The notebook's `reduced` profile already imposes a
ceiling — 3 source clips, 9 variants, Cosmos3-Edge at the 256 tier, sized for 45–60
minutes — and the design review's job is to stop groups raising it before they have run it
once. `full` is Nano at 480p and takes hours; it is opt-in behind
`COSMOS_CAPSTONE_ALLOW_DOWNLOAD=1` and nobody should reach it in the scheduled five.

**Point them at the rubric on day one.** `assets/reference/CAPSTONE_RUBRIC.md` is the
specification, and three of its six criteria — measurement rigour, failure handling and
honesty of the evaluation — cannot be retrofitted after the run. The cost prediction in
particular has to be committed to the ledger *before* the pipeline runs; there is no
credible way to add it afterwards, and the notebook's `check_stage_5` refuses to pass
while the prediction still says `TODO`.

The second overrun is NIM/generator switching. Groups that did not internalise Lesson 02
will burn twenty minutes on model-load latency and not notice until the measurement stage.
That is a good lesson but it is expensive; the design review should ask how they plan to
schedule the card.

### Discussion prompts

**"What is your rejection rate, and is a high one good or bad?"** A high rejection rate
means the screen is doing something, or that generation is producing garbage, or that the
screen is miscalibrated. Distinguishing those requires looking at rejected samples, which
most groups will not have planned for.

**"You screened generated video with the same model family that generated it. Is that
valid?"** Lesson 18 objective 6 covers the circularity. In the capstone it becomes
concrete and there is no clean fix on one machine.

### Demonstration notes

Show nothing. This is the module where you answer questions and otherwise stay out of the
way. The most useful thing you can do is ask "how do you know?" every time someone reports
a result.

### Likely difficulties

| Symptom they report | Actual cause |
|---|---|
| "The pipeline dies three hours in" | No checkpointing. Almost every group learns this the expensive way; mention it at the design review and let those who ignore it find out |
| "Disk full" | Generated video accumulating. At 720p a long clip is not small and nothing is being pruned |
| "The reasoner screen passes everything" | The screening prompt asks a leading question. Same failure as Lesson 04 objective 5 |
| "It works but I cannot say where the time went" | No instrumentation. `MeasurementLog` from Lesson 14 exists precisely for this and gets forgotten under time pressure |

---

## When the NIM will not start

Work through this in order. It is written to be handed to a learner.

**1. Is the container running at all?** `docker ps -a` and look for the NIM by name. If it
exited, `docker logs <name>` has the reason and you should read it before doing anything
else. `nim_status(cfg)` does all of this and prints the log tail.

**2. Did the image pull?** A 401 or `unauthorized` on pull means no nvcr.io credentials.
`echo $NGC_API_KEY | docker login nvcr.io -u '$oauthtoken' --password-stdin`. The username
is literally `$oauthtoken` — single-quote it so the shell does not expand it. Note that
NGC has been phasing out legacy keys that do not begin with `nvapi-`, and a NIM download
needs a personal key with NGC Catalog authorisations.

**3. Does the tag exist?** FACTS §4 records the published tag as `1.7`. The source course
pins `1.7.0`. If the pull 404s, try the other.

**4. Can Docker see the GPU?** `docker run --rm --gpus all nvidia/cuda:12.8.0-base-ubuntu22.04
nvidia-smi -L`. If that fails, the NVIDIA Container Toolkit is missing or the daemon was
not restarted after installing it. Nothing else will work until this does.

**5. Is there VRAM available?** If a generation is running, or a previous notebook kernel
is holding the card, the NIM will fail to allocate. `nvidia-smi` shows compute processes;
`_compute_apps()` in `cosmos_course/nim.py` maps them to containers.

**6. Is it downloading?** First start pulls a 20 GB profile for FP8 nano with limited
progress output. Twenty minutes of apparent silence is normal. `docker logs -f` shows
movement. Do not kill it at minute fifteen.

**7. Is `shm_size` too small?** The source sets 32 GB. A default `docker run` gives 64 MB,
and the failure mode is an obscure crash in a dataloader worker rather than a clear
message. Pass `--shm-size=32g`.

**8. Is the port taken?** Something else on 8000. `ss -tlnp | grep 8000`.

**If none of that works, keep teaching.** Every lesson in Module 1 can run against the
vLLM fallback from Lesson 02, and Modules 2, 3 and 4 do not need the reasoner at all.
Reorder rather than stall — this is exactly why Modules 1 and 2 are independent.

---

## When a generation OOMs mid-class

**Do not debug it live for more than five minutes.** Have a recovery configuration ready
and switch to it, then treat the OOM as material.

**Immediate recovery, in order.**

1. Restart the kernel. Post-OOM CUDA state is often unrecoverable in-process, and ten
   minutes spent trying to free memory in a poisoned context is ten minutes wasted.
2. `nvidia-smi` and confirm the card is actually clear. A zombie framework subprocess
   holding VRAM is common because the framework runs as a subprocess and a killed notebook
   cell does not always take it down. `Generator._kill()` terminates the process group for
   this reason.
3. Confirm the NIM is stopped. It is the single most common cause.
4. Drop to the recovery configuration: Edge, 480p, 61 frames, 20 steps. It should complete
   in a couple of minutes and it re-establishes that the environment works.

**Then use it.** An OOM in Module 2 is the best possible motivation for Module 4, and an
OOM in Module 5 is the lesson. Ask the room, before touching anything: what was the
largest single allocation, and what would you change first? Then check against
`oom_advice()`.

**Pre-class insurance.** Know your machine's actual ceiling before you teach. Run the
heaviest configuration in the lesson plan the day before and record what it peaked at. If
720p × 189 frames × 35 steps on Nano does not fit on your card with your driver, find that
out privately.

---

## Running the course with less GPU time

The course as specified wants ~155 GB of disk and 42 hours. Here is how to compress it.

### Which lessons can share one model download

| Download | Size | Lessons that use it | Notes |
|---|---:|---|---|
| Cosmos3-Edge | 9.1 GB | 01, 06, 14, 15, 17 | The best value in the course. If you download exactly one checkpoint, download this one |
| Cosmos3-Nano | 34.9 GB | 06, 07, 08, 09, 10, 11, 12, 19 | Required for transfer and audio; nothing else can do those |
| Reasoner NIM (nano FP8) | 8.3 GB image + 20 GB profile | 02, 03, 04, 05, 19 | The whole of Module 1 and the capstone's screening stage |
| Guardrail + VAE + Qwen3Guard | 7.97 GB | Every generation lesson | Pulled once on first generation, in Lesson 01 |
| Edge-Policy-DROID | 9 GB | 13 (+ optional Module 3 extension) | Prefer over Nano-Policy-DROID (30 GB) unless you specifically need Nano |
| BridgeData2 subset | 0.65 GB | 16, 17, 18 | |
| LIBERO `libero_10` | 0.5 GB | 13, 16 | Do not pull all suites (4.5 GB) unless doing the closed-loop extension |
| Super reasoner FP8 | 40 GB | 15 objective 7 only, optional | Cut this first if disk is short |

**Minimum viable download set: 61 GB.** Edge (9.1) + Nano (34.9) + NIM nano profile (20)
— minus the guardrail chain and datasets, which add another 9 GB. That covers Lessons
00–12, 14–16, 18 and 19. Skipping Nano entirely drops you to ~30 GB and costs you
Lessons 08 and 09 outright, plus quality in 07 and 10–12.

### Compression strategies

**Pre-stage everything.** Populate the Hugging Face cache and pull the NIM image before
anyone arrives. This alone removes two to three and a half hours of the schedule.

**Share a card across a small group.** Modules 1 and 4 are almost entirely
inference-and-measure, and three or four learners can share one H100 if they coordinate.
Modules 2, 3 and 5 cannot be shared usefully — the runs are long and the whole point is
that one job takes the card.

**Run Edge for everything that will tolerate it.** Lessons 06, 14, 15 and 17 are all
better on Edge anyway: faster iteration, more experiments per hour, and the pedagogy does
not depend on quality.

**A 20-hour version.** Drop Lesson 13 (closed loop) and Lesson 17's execution while
keeping its arithmetic, shorten Module 2 to text2video plus one transfer hint, and
compress the capstone to three hours with a supplied pipeline skeleton. You lose the
closed-loop material and the post-training attempt; you keep the mental model, the
measurement discipline and the flywheel.

**A 12-hour version.** Modules 0, 1 and 2 only, Edge for everything, capstone replaced by
a two-hour guided version of Lesson 19's reasoning-plus-generation arc. This is roughly
"the source course, done properly", and it is a legitimate offering.

**Do not compress by removing measurement.** Modules 4 and 5 are the parts that
distinguish this course from a demo walkthrough. If time is short, cut breadth in Modules
2 and 3 rather than depth in 4 and 5.

---

## What is least validated

This section exists so nobody is surprised in front of a room. Ordered from least
confident to most.

**Lesson 17, the single-GPU Edge fine-tune.** NVIDIA documents no single-GPU training path
at all; the smallest documented claim is that Edge "also fits a 4-GPU node" (FACTS §5).
The arithmetic supporting a single-GPU Edge run — ~2B trainable via `keys_to_select`,
≈45–50 GB of state, ~30 GB left for activations — is sound and is entirely this course's
extrapolation. It has not been demonstrated. Teach it as an experiment with a predicted
outcome. If it fails, that is a result and the lesson's artefact is designed to capture it.

**Lesson 13, closed-loop control.** The dependency conflict is verified from FACTS §5 and
the policy server is documented upstream. A full LIBERO closed-loop run on a single H100
has not been demonstrated by this course, and the RoboLab path needs an Isaac Sim
installation this course does not provide. Expect to run the server and read about the
rest.

**The NIM memory-fraction environment variable.** `cosmos_course/nim.py` states plainly
that the exact variable name could not be verified against a running NIM 1.7 container at
authoring time. `discover_memory_env()` runs `docker run --rm <image> --help` and greps
for it. Whatever it finds, trust the observed VRAM in `nim_status()` over any flag.

**The NIM's resting VRAM footprint.** The 60–75 GB figure for an idle 80 GB card is an
estimate from `cosmos_course/nim.py`, not a published number. Lesson 02 has learners
measure it, and if your measurement differs materially, your measurement wins — update the
number.

**Edge's ~12 GB inference VRAM.** Not an NVIDIA figure. `COSMOS3_FACTS.md` §3 says
explicitly that Edge is not listed in the framework's VRAM table and that ~12 GB is "a
working figure to be measured in Lesson 06, not quoted". Do not put it on a slide as a
fact.

**Every time estimate in `02_PROPOSED_CURRICULUM.md`.** The only compute-duration figure
in any supplied material is the source e2e harness's "~2-3 hours" for three notebooks,
dominated by first-run downloads. Everything else is authorial judgement. Record your
actual timings the first time you teach this and correct the estimates.

**The audit's runtime claims about the source.** All four source notebooks are committed
output-clean, so there is not a single recorded execution anywhere in the package.
Statements in `01_SOURCE_AUDIT.md` about what the source *does at runtime* — whether its
base64 previews play, whether its 720p × 189-frame default OOMs on one H100 — are
inference from reading code. The static claims (the missing `HTML` import, the `policy`
mode string, the hard-coded device index) were verified directly against the notebook JSON
and are solid.

**Upstream drift.** `COSMOS3_FACTS.md` was verified in August 2026. The `policy` → `wam`
rename is exactly the kind of change that happened once and will happen again. Before
teaching, re-verify the mode enum against
`raw.githubusercontent.com/.../refs/heads/main/...` — note the `refs/heads/` form; the
plain `.../main/...` URL serves a stale cached copy and will tell you the wrong answer
(FACTS §2, §7).
