#!/usr/bin/env python3
"""Static gate for every notebook in the course. Sub-second, no GPU, no kernel.

This runs on every commit and before every release. It catches the class of
mistake that is invisible in a diff and expensive in a classroom: a notebook
committed with somebody's outputs still in it, a kernel name that does not exist
on the learner's machine, an API key pasted into a cell, an absolute path from
the author's laptop, or a `model_mode` that upstream renamed a year ago.

None of these checks execute anything. That is the point — this must stay fast
enough that there is no excuse for skipping it, and safe enough to run on a
notebook you have not read.

What is checked
---------------
ERRORS (exit 1)
  * valid JSON and valid nbformat 4
  * kernelspec name is `cosmos3-h100`
  * no committed cell outputs
  * no non-null execution_count
  * no credential-shaped strings: hf_..., nvapi-..., sk-...
  * no `"model_mode": "policy"` — upstream renamed it to `wam`, and the source
    DLI course's notebook 04 uses the dead name (COSMOS3_FACTS.md section 2)
  * no CUDA_VISIBLE_DEVICES=1 — this is a ONE-GPU course and that hides the
    only GPU. Allowed only in cells tagged `teaching-antipattern`, where the
    lesson is deliberately showing the mistake.
  * no absolute foreign paths: /dli/task, C:\\Users\\, /home/<someone-else>
  * every relative asset reference resolves on disk

WARNINGS (printed, exit 0; promoted to errors by --strict)
  * a lesson notebook with no learning objectives
  * a lesson notebook with no exercise
  * empty cells, `!pip install`, other smells

NOTES (printed, never counted, never promoted by --strict)
  * observations about the machine running this script rather than about any
    notebook — e.g. nbformat not installed, so schema validation was skipped.
    A release gate that goes red because a CI image is missing a dependency
    teaches people to ignore the gate.

Exit codes
----------
0   No errors. Warnings may have been printed.
1   At least one error.
2   Bad usage, or no notebooks found where notebooks were expected.

Examples
--------
    python3 scripts/validate_notebooks.py
    python3 scripts/validate_notebooks.py --json
    python3 scripts/validate_notebooks.py lessons/01_modes.ipynb
    python3 scripts/validate_notebooks.py --strict     # warnings become errors
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent

EXPECTED_KERNEL = "cosmos3-h100"

# Directories that never contain course notebooks.
SKIP_DIRS = {
    ".git", ".ipynb_checkpoints", "vendor", "node_modules", "__pycache__",
    ".venv", "venv", "results", "outputs",
}

# A cell carrying this tag is allowed to contain a deliberate mistake, because
# showing the mistake IS the lesson. Lesson 00 uses it for the DLI course's
# CUDA_VISIBLE_DEVICES=1, which on a single-GPU box hides the only GPU.
ANTIPATTERN_TAG = "teaching-antipattern"

# --------------------------------------------------------------------------
# Credential shapes
# --------------------------------------------------------------------------
# Deliberately shaped rather than entropy-based: we want zero false negatives on
# the three token formats a learner of this course could plausibly paste, and we
# accept a false positive on prose that happens to look like one. Each pattern
# carries an allowance for the obvious placeholder forms so that .env.example
# style documentation inside a notebook does not trip it.
CREDENTIAL_PATTERNS: list[tuple[str, re.Pattern[str], str]] = [
    (
        "Hugging Face token",
        re.compile(r"\bhf_[A-Za-z0-9]{20,}\b"),
        "Never paste an HF token into a notebook. Use `huggingface-cli login` "
        "(or `hf auth login`), or export HF_TOKEN in your shell. If this token "
        "was ever committed, REVOKE IT at "
        "https://huggingface.co/settings/tokens — rewriting history is not "
        "enough, it is already in every clone.",
    ),
    (
        "NGC API key",
        re.compile(r"\bnvapi-[A-Za-z0-9_\-]{10,}\b"),
        "Never paste an NGC key into a notebook. Export NGC_API_KEY in your "
        "shell (put it in ~/.bashrc) and let docker read it by name. If this "
        "was committed, revoke it at https://ngc.nvidia.com/setup/api-key .",
    ),
    (
        "OpenAI-style secret key",
        re.compile(r"\bsk-[A-Za-z0-9_\-]{16,}\b"),
        "The Reasoner NIM does not check bearer tokens, so this course never "
        "needs a real key — cosmos_course.models.Reasoner sends a placeholder. "
        "If this is a genuine key, revoke it.",
    ),
]

# Placeholder forms that are documentation, not secrets.
PLACEHOLDER = re.compile(
    r"(REPLACE_ME|YOUR[_-]?(KEY|TOKEN)|xxx+|\.\.\.|<[^>]{2,30}>|EXAMPLE|placeholder)",
    re.IGNORECASE,
)

# --------------------------------------------------------------------------
# Foreign absolute paths
# --------------------------------------------------------------------------
# The source DLI course hard-coded /dli/task everywhere. cosmos_course.config
# exists precisely so that nothing in this course does. A Windows path or
# another user's home directory means an author's machine leaked into the file.
FOREIGN_PATH_PATTERNS: list[tuple[str, re.Pattern[str], str]] = [
    (
        "DLI container path",
        re.compile(r"/dli/task"),
        "This is the source DLI course's container layout. Use "
        "`from cosmos_course.config import COURSE_ROOT, OUTPUT_ROOT` instead — "
        "removing that assumption is the whole reason config.py exists.",
    ),
    (
        "Windows absolute path",
        re.compile(r"[A-Za-z]:\\\\?Users\\\\?"),
        "An author's Windows path. Use a repo-relative path or COURSE_ROOT.",
    ),
    (
        "another user's home directory",
        # Matches /home/<name>/ but not /home/$USER, /home/${USER} or
        # /home/user (the conventional stand-in).
        re.compile(r"/home/(?!\$|\{|user\b|ubuntu\b)[A-Za-z][A-Za-z0-9_.-]{1,30}/"),
        "A hard-coded home directory. Use Path.home(), COURSE_ROOT, or an "
        "environment variable with a repo-relative fallback.",
    ),
]

CUDA_HIDE_GPU = re.compile(
    r"""CUDA_VISIBLE_DEVICES\s*(?:=|["']\s*\]\s*=\s*["'])\s*["']?1["']?\b"""
)

# Markdown that signals a lesson has learning objectives / an exercise.
OBJECTIVE_MARKERS = re.compile(
    r"(learning objectives?|by the end of this (lesson|notebook)|"
    r"what you will (learn|be able to)|in this lesson you will)",
    re.IGNORECASE,
)
EXERCISE_MARKERS = re.compile(
    r"(##+\s*(exercise|your turn|try it|challenge)|"
    r"\*\*exercise|# TODO|### Exercise)",
    re.IGNORECASE,
)

# A relative path inside a string literal that looks like it points at media or
# data we ship. Deliberately conservative: only extensions the course uses, and
# only forward slashes, so ordinary prose does not match.
ASSET_REF = re.compile(
    r"""["']((?:\.{1,2}/)?(?:assets|vendor|exercises|solutions|lectures|data)"""
    r"""/[^"'\s]+?\.(?:png|jpg|jpeg|mp4|json|jsonl|txt|toml|csv|md|svg|wav))["']"""
)


# nbformat is imported ONCE, here, rather than per notebook. Its absence is a
# fact about the machine running this script, not about any notebook, so it is
# reported once as a note and — crucially — is NOT promoted to an error by
# --strict. Otherwise the release gate would fail on a clean set of notebooks
# purely because a dependency was missing from the CI image, which is exactly
# the kind of false red that teaches people to ignore a gate.
try:
    import nbformat as _nbformat
except ImportError:  # pragma: no cover
    _nbformat = None  # type: ignore[assignment]


@dataclass
class Issue:
    level: str          # "error" | "warning" | "note"
    notebook: str
    cell: int | None
    check: str
    message: str
    remedy: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "level": self.level, "notebook": self.notebook, "cell": self.cell,
            "check": self.check, "message": self.message, "remedy": self.remedy,
        }


@dataclass
class Report:
    issues: list[Issue] = field(default_factory=list)
    notebooks: list[str] = field(default_factory=list)

    def error(self, *args: Any, **kwargs: Any) -> None:
        self.issues.append(Issue("error", *args, **kwargs))

    def warn(self, *args: Any, **kwargs: Any) -> None:
        self.issues.append(Issue("warning", *args, **kwargs))

    def note(self, *args: Any, **kwargs: Any) -> None:
        """An observation about the environment, never about a notebook.

        Printed, but never counted and never promoted by --strict.
        """
        self.issues.append(Issue("note", *args, **kwargs))

    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.level == "error"]

    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.level == "warning"]

    @property
    def notes(self) -> list[Issue]:
        return [i for i in self.issues if i.level == "note"]


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def cell_source(cell: dict[str, Any]) -> str:
    """A cell's source as one string. nbformat allows str or list-of-str."""
    src = cell.get("source", "")
    return "".join(src) if isinstance(src, list) else str(src)


def cell_tags(cell: dict[str, Any]) -> set[str]:
    meta = cell.get("metadata") or {}
    tags = meta.get("tags") or []
    return {str(t) for t in tags} if isinstance(tags, list) else set()


def is_lesson(path: Path) -> bool:
    """Lesson notebooks get the pedagogical checks; scratch notebooks do not.

    Matched on the parent directory rather than the filename so that
    `exercises/` and `solutions/` — which are deliberately fragments — are not
    told they lack learning objectives.
    """
    parts = {p.lower() for p in path.parts}
    if {"exercises", "solutions", "scratch", "sandbox"} & parts:
        return False
    return bool(re.match(r"^\d{2}[_-]", path.name)) or "lessons" in parts


def find_notebooks(targets: list[Path]) -> list[Path]:
    found: list[Path] = []
    for target in targets:
        if target.is_file():
            found.append(target)
        elif target.is_dir():
            for path in sorted(target.rglob("*.ipynb")):
                if SKIP_DIRS & set(path.parts):
                    continue
                if path.name.endswith(".executed.ipynb"):
                    continue
                found.append(path)
    # dict.fromkeys de-duplicates while preserving order.
    return list(dict.fromkeys(found))


# --------------------------------------------------------------------------
# The checks
# --------------------------------------------------------------------------
def check_notebook(path: Path, report: Report, repo_root: Path) -> None:
    rel = str(path.relative_to(repo_root)) if path.is_relative_to(repo_root) else str(path)
    report.notebooks.append(rel)

    # -- parse -------------------------------------------------------------
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        report.error(rel, None, "readable", f"cannot read: {exc}")
        return
    try:
        nb = json.loads(raw)
    except json.JSONDecodeError as exc:
        report.error(
            rel, None, "valid JSON", f"invalid JSON at line {exc.lineno}: {exc.msg}",
            "A notebook is JSON. This is usually a bad merge — look for conflict "
            "markers (<<<<<<<) in the file.",
        )
        return

    # -- nbformat ----------------------------------------------------------
    major = nb.get("nbformat")
    if major != 4:
        report.error(
            rel, None, "nbformat 4", f"nbformat is {major!r}, expected 4",
            "Convert it:  jupyter nbconvert --to notebook --inplace " + rel,
        )
        return

    if _nbformat is not None:
        try:
            _nbformat.validate(_nbformat.reads(raw, as_version=4))
        except Exception as exc:  # noqa: BLE001 - nbformat raises several types
            report.error(
                rel, None, "nbformat schema", f"schema validation failed: {exc}",
                "Round-trip it through nbformat to normalise:\n"
                f"    jupyter nbconvert --to notebook --inplace {rel}",
            )

    # -- kernelspec --------------------------------------------------------
    kernelspec = (nb.get("metadata") or {}).get("kernelspec") or {}
    kernel_name = kernelspec.get("name")
    if kernel_name != EXPECTED_KERNEL:
        report.error(
            rel, None, "kernelspec",
            f"kernel is {kernel_name!r}, expected {EXPECTED_KERNEL!r}",
            f"Every notebook must run on the framework venv's kernel, or "
            f"`import cosmos_framework` fails.\n"
            f"  Fix in JupyterLab: Kernel -> Change Kernel -> \"Cosmos 3 (H100)\"\n"
            f"  Or by hand:  jq '.metadata.kernelspec.name=\"{EXPECTED_KERNEL}\"' "
            f"{rel} > tmp && mv tmp {rel}\n"
            f"  The kernel is created by scripts/setup.sh.",
        )

    # -- cells -------------------------------------------------------------
    cells = nb.get("cells") or []
    if not cells:
        report.warn(rel, None, "non-empty", "notebook has no cells")

    saw_objectives = False
    saw_exercise = False
    asset_refs: list[tuple[int, str]] = []

    for index, cell in enumerate(cells):
        kind = cell.get("cell_type")
        source = cell_source(cell)
        tags = cell_tags(cell)
        antipattern = ANTIPATTERN_TAG in tags

        if kind == "code":
            # -- outputs ---------------------------------------------------
            outputs = cell.get("outputs") or []
            if outputs:
                report.error(
                    rel, index, "no committed outputs",
                    f"{len(outputs)} output(s) present",
                    "Committed outputs bloat diffs, leak whatever was on the "
                    "author's screen, and let a notebook LOOK like it works when "
                    "it does not. Strip them:\n"
                    "    jupyter nbconvert --clear-output --inplace " + rel + "\n"
                    "  Consider installing nbstripout as a git filter so this "
                    "cannot happen again:\n"
                    "    pip install nbstripout && nbstripout --install",
                )
            if cell.get("execution_count") is not None:
                report.error(
                    rel, index, "no execution_count",
                    f"execution_count is {cell.get('execution_count')!r}, expected null",
                    "Same fix as committed outputs: "
                    "jupyter nbconvert --clear-output --inplace " + rel,
                )

            # -- CUDA_VISIBLE_DEVICES --------------------------------------
            if CUDA_HIDE_GPU.search(source) and not antipattern:
                report.error(
                    rel, index, "no CUDA_VISIBLE_DEVICES=1",
                    "sets CUDA_VISIBLE_DEVICES to 1",
                    "This course runs on ONE GPU, which is device 0. Setting "
                    "this to 1 hides the only GPU and every later cell fails "
                    "with a confusing 'no CUDA device' error. The source DLI "
                    "course did this because it had two GPUs.\n"
                    "  If the cell is deliberately demonstrating the mistake, "
                    f"tag it `{ANTIPATTERN_TAG}` and this check will allow it.",
                )

            if re.search(r"^\s*!\s*pip\s+install", source, re.MULTILINE):
                report.warn(
                    rel, index, "no inline pip install",
                    "runs `!pip install` inside a cell",
                    "Installing into a running kernel gives you a session where "
                    "imports and installed versions disagree. Put the dependency "
                    "in pyproject.toml / requirements.txt instead.",
                )

            if not source.strip():
                report.warn(rel, index, "no empty cells", "empty code cell")

        elif kind == "markdown":
            if OBJECTIVE_MARKERS.search(source):
                saw_objectives = True
            if EXERCISE_MARKERS.search(source):
                saw_exercise = True

        # -- checks that apply to any cell type ---------------------------
        for name, pattern, remedy in CREDENTIAL_PATTERNS:
            for match in pattern.finditer(source):
                token = match.group(0)
                if PLACEHOLDER.search(token):
                    continue
                # Show the shape, never the value. A validator that echoes the
                # secret it found has put it in your CI logs as well.
                report.error(
                    rel, index, "no credentials",
                    f"looks like a {name} ({len(token)} chars, "
                    f"starts {token[:6]}...)",
                    remedy,
                )

        if '"model_mode": "policy"' in source or "'model_mode': 'policy'" in source \
                or re.search(r"model_mode\s*=\s*[\"']policy[\"']", source):
            if not antipattern:
                report.error(
                    rel, index, "model_mode is wam, not policy",
                    "uses the dead model_mode 'policy'",
                    "Upstream renamed this mode to `wam` (World Action Model). "
                    "`policy` is not in the ModelMode enum and the run will fail "
                    "with an unhelpful validation error.\n"
                    "  COSMOS3_FACTS.md section 2 has the three independent "
                    "confirmations. docs/inference.md, docs/faq.md and the "
                    "action cookbook README all still say `policy` — trust the "
                    "enum, not the prose.\n"
                    "  cosmos_course.specs.normalize_policy_mode() maps the old "
                    "name to the new one if you need to accept both.",
                )

        for name, pattern, remedy in FOREIGN_PATH_PATTERNS:
            match = pattern.search(source)
            if match and not antipattern:
                report.error(
                    rel, index, "no foreign absolute paths",
                    f"{name}: {match.group(0)!r}", remedy,
                )

        for match in ASSET_REF.finditer(source):
            asset_refs.append((index, match.group(1)))

    # -- asset references resolve -----------------------------------------
    # Resolved relative to the notebook's own directory first (which is how
    # Jupyter's working directory behaves), then relative to the repo root.
    for index, ref in asset_refs:
        candidates = [path.parent / ref, repo_root / ref.lstrip("./")]
        if not any(c.exists() for c in candidates):
            report.error(
                rel, index, "asset references resolve",
                f"{ref!r} does not exist",
                f"Looked in:\n"
                + "".join(f"    {c}\n" for c in candidates)
                + "  If it is a cookbook asset, refer to it through "
                  "`cosmos_course.assets.asset(\"name\")` rather than by path — "
                  "that gives one place to fix when upstream moves it, and a "
                  "useful error instead of a FileNotFoundError twenty cells "
                  "later. Fetch the cookbook with scripts/fetch_assets.py.",
            )

    # -- pedagogy (lessons only, warnings) --------------------------------
    if is_lesson(path):
        if not saw_objectives:
            report.warn(
                rel, None, "has learning objectives",
                "no learning-objectives markdown found",
                "Every lesson should open with what the learner will be able to "
                "do by the end. Looked for headings or prose matching: "
                "'learning objectives', 'by the end of this lesson', "
                "'what you will learn'.",
            )
        if not saw_exercise:
            report.warn(
                rel, None, "has at least one exercise",
                "no exercise found",
                "Looked for a heading matching 'Exercise', 'Your turn', "
                "'Try it' or 'Challenge'. A lesson with nothing to do is a "
                "lecture.",
            )


# --------------------------------------------------------------------------
# Reporting
# --------------------------------------------------------------------------
def print_report(report: Report, strict: bool) -> None:
    print()
    print("=" * 72)
    print(f"Notebook validation — {len(report.notebooks)} notebook(s)")
    print("=" * 72)

    if not report.notebooks:
        print("  No notebooks found.")
        print()
        return

    by_notebook: dict[str, list[Issue]] = {name: [] for name in report.notebooks}
    for issue in report.issues:
        by_notebook.setdefault(issue.notebook, []).append(issue)

    if report.notes:
        for issue in report.notes:
            print(f"  note  {issue.check}: {issue.message}")
            if issue.remedy:
                print(f"        {issue.remedy}")
        print()

    for name in report.notebooks:
        issues = by_notebook.get(name, [])
        errors = [i for i in issues if i.level == "error"]
        warns = [i for i in issues if i.level == "warning"]
        if not issues:
            print(f"  ok    {name}")
            continue
        mark = "FAIL " if errors else "warn "
        print(f"  {mark} {name}   ({len(errors)} error(s), {len(warns)} warning(s))")
        for issue in issues:
            where = f"cell {issue.cell}" if issue.cell is not None else "notebook"
            tag = "ERROR" if issue.level == "error" else "warn "
            print(f"          [{tag}] {where}: {issue.check} — {issue.message}")
            if issue.remedy:
                for line in issue.remedy.splitlines():
                    print(f"              {line}")

    print()
    print("-" * 72)
    print(f"  {len(report.errors)} error(s), {len(report.warnings)} warning(s)")
    if strict and report.warnings:
        print("  --strict: warnings are being treated as errors")
    if not report.errors and not report.warnings:
        print("  Clean.")
    print()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="validate_notebooks.py",
        description=(
            "Static validation of every course notebook: nbformat, kernelspec, "
            "committed outputs, leaked credentials, the dead `policy` model "
            "mode, CUDA_VISIBLE_DEVICES=1 on a one-GPU box, foreign absolute "
            "paths, and unresolvable asset references. Executes nothing and "
            "needs no GPU."
        ),
        epilog=(
            "Exit codes: 0 no errors · 1 at least one error · 2 bad usage.\n\n"
            "A cell tagged `teaching-antipattern` is exempt from the "
            "CUDA_VISIBLE_DEVICES, foreign-path and model_mode checks, so a "
            "lesson can show the mistake on purpose.\n\n"
            "Typical fixes:\n"
            "  committed outputs   jupyter nbconvert --clear-output --inplace NB\n"
            "  wrong kernel        Kernel -> Change Kernel -> \"Cosmos 3 (H100)\"\n"
            "  leaked credential   REVOKE THE KEY FIRST, then remove it"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "paths", nargs="*", type=Path, default=None, metavar="PATH",
        help="Notebooks or directories to check. Default: the whole repository, "
             "excluding vendor/, outputs/, results/ and .ipynb_checkpoints/.",
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Emit the report as JSON on stdout. The prose report is "
             "suppressed so the stream stays parseable.",
    )
    parser.add_argument(
        "--strict", action="store_true",
        help="Treat warnings (missing learning objectives, missing exercises, "
             "inline pip installs) as errors. Use this in the release gate, not "
             "in the pre-commit hook.",
    )
    parser.add_argument(
        "--root", type=Path, default=REPO_ROOT, metavar="DIR",
        help=f"Repository root, used to resolve relative asset references and "
             f"to shorten displayed paths. Default: {REPO_ROOT}",
    )
    parser.add_argument(
        "--require-notebooks", action="store_true",
        help="Exit 2 when no notebooks are found. Off by default so this script "
             "is safe to run on a checkout whose notebooks are not written yet.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    repo_root = args.root.resolve()
    targets = [p.resolve() for p in (args.paths or [repo_root])]

    for target in targets:
        if not target.exists():
            print(f"error: no such path: {target}", file=sys.stderr)
            return 2

    notebooks = find_notebooks(targets)
    report = Report()

    if _nbformat is None:
        report.note(
            "", None, "nbformat schema",
            "nbformat is not installed, so JSON-schema validation was skipped; "
            "every other check ran",
            "pip install nbformat   (or: python3 -m pip install -e .)",
        )

    for notebook in notebooks:
        check_notebook(notebook, report, repo_root)

    if args.json:
        json.dump(
            {
                "notebooks": report.notebooks,
                "errors": [i.to_dict() for i in report.errors],
                "warnings": [i.to_dict() for i in report.warnings],
                "notes": [i.to_dict() for i in report.notes],
                "counts": {
                    "notebooks": len(report.notebooks),
                    "errors": len(report.errors),
                    "warnings": len(report.warnings),
                    "notes": len(report.notes),
                },
            },
            sys.stdout, indent=2,
        )
        sys.stdout.write("\n")
    else:
        print_report(report, args.strict)

    if not notebooks:
        if args.require_notebooks:
            if not args.json:
                print("error: no notebooks found, and --require-notebooks was given",
                      file=sys.stderr)
            return 2
        if not args.json:
            print("  (No notebooks yet. Pass --require-notebooks to make that an error.)")
            print()

    if report.errors:
        return 1
    if args.strict and report.warnings:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
