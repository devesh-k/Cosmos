#!/usr/bin/env bash
#
# run_all.sh — execute every course notebook, in order, one at a time.
#
# This is the end-to-end gate: it proves the course actually runs on this
# machine, in this order, with this kernel. `scripts/validate_notebooks.py` is
# the cheap static check you run constantly; this is the expensive dynamic one
# you run before a release and after any environment change.
#
# ONE AT A TIME, and it waits for the GPU to go idle in between. That is not
# politeness — on a single H100 two notebooks running concurrently will OOM each
# other, and the CUDA driver does not hand memory back the instant a process
# exits. Polling `nvidia-smi --query-gpu=memory.used` until it drops is the
# difference between a real failure and a race that only fails in CI.
#
# Usage:
#   ./scripts/run_all.sh                       # everything, in path order
#   REDUCED=1 ./scripts/run_all.sh             # short/cheap settings
#   NOTEBOOKS="lessons/01.ipynb lessons/02.ipynb" ./scripts/run_all.sh
#   ./scripts/run_all.sh --timeout 3600 --fail-fast
#   ./scripts/run_all.sh --dry-run             # print the plan, run nothing
#
# Environment:
#   NOTEBOOKS              space/newline separated list, overriding discovery
#   REDUCED=1              sets COSMOS_COURSE_MODE=reduced for every notebook
#   CELL_TIMEOUT           seconds per cell (default 1800)
#   RESULTS_DIR            where executed copies go (default <repo>/results/<ts>)
#   KERNEL                 kernel name (default cosmos3-h100)
#   GPU_IDLE_MIB           "idle" threshold in MiB (default 2048)
#   GPU_IDLE_TIMEOUT       seconds to wait for idle (default 300)
#
# Exit status: 0 if every notebook executed cleanly, 1 otherwise, 2 on bad usage.

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/.." && pwd -P)"
readonly SCRIPT_DIR REPO_ROOT

# --------------------------------------------------------------------------
# Defaults, all overridable by environment then by flag
# --------------------------------------------------------------------------
KERNEL="${KERNEL:-cosmos3-h100}"
CELL_TIMEOUT="${CELL_TIMEOUT:-1800}"
GPU_IDLE_MIB="${GPU_IDLE_MIB:-2048}"
GPU_IDLE_TIMEOUT="${GPU_IDLE_TIMEOUT:-300}"
RESULTS_DIR="${RESULTS_DIR:-}"
FAIL_FAST=0
DRY_RUN=0
SKIP_TAG="skip-execution"

if [[ -t 1 ]] && command -v tput >/dev/null 2>&1 && [[ "$(tput colors 2>/dev/null || echo 0)" -ge 8 ]]; then
    C_BOLD="$(tput bold)"; C_RED="$(tput setaf 1)"; C_GREEN="$(tput setaf 2)"
    C_YELLOW="$(tput setaf 3)"; C_OFF="$(tput sgr0)"
else
    C_BOLD=""; C_RED=""; C_GREEN=""; C_YELLOW=""; C_OFF=""
fi
readonly C_BOLD C_RED C_GREEN C_YELLOW C_OFF

info() { printf '%s\n' "$*"; }
warn() { printf '%swarn:%s %s\n' "${C_YELLOW}" "${C_OFF}" "$*" >&2; }
# die "message" [exit-code]. "$1", not "$*" — with "$*" the exit code gets
# printed as part of the message, which looks like a typo in the error text.
die()  { printf '%sfatal:%s %s\n' "${C_RED}${C_BOLD}" "${C_OFF}" "$1" >&2; exit "${2:-1}"; }

usage() {
    cat <<'EOF'
run_all.sh — execute every course notebook in order, one at a time.

  --timeout SEC       Per-cell execution timeout. Default 1800 (30 min). A
                      768p video generation can legitimately exceed 20 minutes
                      in one cell, so do not lower this casually.
  --kernel NAME       Jupyter kernel to execute with. Default cosmos3-h100
                      (created by scripts/setup.sh).
  --results-dir DIR   Where executed copies are written. Default
                      <repo>/results/<UTC timestamp>.
  --idle-mib N        VRAM in MiB at or below which the GPU counts as idle
                      between notebooks. Default 2048.
  --idle-timeout SEC  How long to wait for that. Default 300.
  --fail-fast         Stop at the first failing notebook. Default is to run
                      them all and print a complete table, because on a 3-hour
                      run you want to know about every failure, not the first.
  --dry-run           Print the plan and exit. Executes nothing.
  -h, --help          This text.

Environment: NOTEBOOKS, REDUCED, CELL_TIMEOUT, RESULTS_DIR, KERNEL,
             GPU_IDLE_MIB, GPU_IDLE_TIMEOUT

REDUCED=1 exports COSMOS_COURSE_MODE=reduced into every notebook's kernel.
Notebooks read it to pick shorter clips, fewer denoising steps and smaller
resolutions — a full pass is hours of H100 time; a reduced pass is minutes and
still exercises every code path.

Cells tagged `skip-execution` are REMOVED before execution (nbconvert's
TagRemovePreprocessor runs before the ExecutePreprocessor). Use it for cells
that download 130 GB, or that demonstrate a failure on purpose.

Exit: 0 all passed · 1 at least one failed · 2 bad usage.
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --timeout)      CELL_TIMEOUT="${2:?--timeout needs a value}"; shift ;;
        --kernel)       KERNEL="${2:?--kernel needs a value}"; shift ;;
        --results-dir)  RESULTS_DIR="${2:?--results-dir needs a value}"; shift ;;
        --idle-mib)     GPU_IDLE_MIB="${2:?--idle-mib needs a value}"; shift ;;
        --idle-timeout) GPU_IDLE_TIMEOUT="${2:?--idle-timeout needs a value}"; shift ;;
        --fail-fast)    FAIL_FAST=1 ;;
        --dry-run)      DRY_RUN=1 ;;
        -h|--help)      usage; exit 0 ;;
        *)              printf 'unknown flag: %s\n\n' "$1" >&2; usage >&2; exit 2 ;;
    esac
    shift
done

[[ "$CELL_TIMEOUT" =~ ^[0-9]+$ ]] || die "--timeout must be an integer number of seconds" 2
[[ "$GPU_IDLE_MIB" =~ ^[0-9]+$ ]] || die "--idle-mib must be an integer" 2
[[ "$GPU_IDLE_TIMEOUT" =~ ^[0-9]+$ ]] || die "--idle-timeout must be an integer" 2

if [[ -z "$RESULTS_DIR" ]]; then
    RESULTS_DIR="${REPO_ROOT}/results/$(date -u +%Y%m%dT%H%M%SZ)"
fi

# --------------------------------------------------------------------------
# Which notebooks, in which order
# --------------------------------------------------------------------------
# Path order is deliberate: the lessons are numbered (00_, 01_, ...) so a plain
# sort is the teaching order, and `sort` on the full path keeps directories
# grouped. NOTEBOOKS= overrides it entirely for re-running a subset.
declare -a NOTEBOOK_LIST=()

if [[ -n "${NOTEBOOKS:-}" ]]; then
    # Word-split on whitespace, on purpose: the documented interface is a
    # space- or newline-separated list, which is what a shell user will type.
    # shellcheck disable=SC2206
    NOTEBOOK_LIST=(${NOTEBOOKS})
    info "Using the NOTEBOOKS override (${#NOTEBOOK_LIST[@]} entries)."
else
    while IFS= read -r nb; do
        NOTEBOOK_LIST+=("$nb")
    done < <(
        find "$REPO_ROOT" -type f -name '*.ipynb' \
            -not -path '*/.ipynb_checkpoints/*' \
            -not -path '*/vendor/*' \
            -not -path '*/results/*' \
            -not -path '*/outputs/*' \
            -not -path '*/.git/*' \
            -not -name '*.executed.ipynb' \
            | sort
    )
fi

if [[ "${#NOTEBOOK_LIST[@]}" -eq 0 ]]; then
    warn "no notebooks found under $REPO_ROOT"
    warn "Nothing to do. (Set NOTEBOOKS=... to run a specific list.)"
    exit 0
fi

# --------------------------------------------------------------------------
# Preconditions
# --------------------------------------------------------------------------
command -v jupyter >/dev/null 2>&1 || die \
"jupyter is not on PATH.
       Install the course kernel layer:
           python3 -m pip install -e \"$REPO_ROOT\""

if ! jupyter kernelspec list 2>/dev/null | grep -qE "^\s*${KERNEL}\s"; then
    die "the '$KERNEL' kernel is not registered.
       Available kernels:
$(jupyter kernelspec list 2>/dev/null | sed 's/^/         /')
       Create it with:
           ./scripts/setup.sh
       (stage 3 registers the framework venv as '$KERNEL')"
fi

HAVE_SMI=0
if command -v nvidia-smi >/dev/null 2>&1 && nvidia-smi -L >/dev/null 2>&1; then
    HAVE_SMI=1
else
    warn "nvidia-smi is unavailable, so the GPU-idle wait between notebooks is disabled."
    warn "On a real single-GPU run that wait is what stops notebook N+1 OOMing on"
    warn "memory notebook N has not released yet."
fi

# --------------------------------------------------------------------------
# GPU idle wait
# --------------------------------------------------------------------------
gpu_used_mib() {
    local out
    out="$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null | head -n1)" || return 1
    # Some drivers report "[Not Supported]" (vGPU, some MIG configurations).
    [[ "$out" =~ ^[0-9]+$ ]] || return 1
    printf '%s' "$out"
}

wait_for_gpu_idle() {
    [[ "$HAVE_SMI" -eq 1 ]] || return 0

    local deadline=$(( SECONDS + GPU_IDLE_TIMEOUT ))
    local used
    while (( SECONDS < deadline )); do
        if ! used="$(gpu_used_mib)"; then
            warn "could not read GPU memory; not waiting."
            return 0
        fi
        if (( used <= GPU_IDLE_MIB )); then
            printf '  GPU idle (%s MiB used, threshold %s MiB)\n' "$used" "$GPU_IDLE_MIB"
            return 0
        fi
        printf '\r  waiting for the GPU to drain: %s MiB used (want <= %s)   ' \
               "$used" "$GPU_IDLE_MIB"
        sleep 5
    done
    printf '\n'
    used="$(gpu_used_mib || echo '?')"
    warn "GPU still holds ${used} MiB after ${GPU_IDLE_TIMEOUT}s."
    warn "Something is still resident — most likely the Reasoner NIM, or a"
    warn "leftover python process from a previous run. Check:"
    warn "    nvidia-smi"
    warn "    docker ps --filter name=cosmos3-reasoner"
    warn "Continuing anyway; the next notebook may OOM."
    return 0
}

# --------------------------------------------------------------------------
# Plan
# --------------------------------------------------------------------------
mkdir -p -- "$RESULTS_DIR"
LOG_DIR="${RESULTS_DIR}/logs"
mkdir -p -- "$LOG_DIR"

export COSMOS_COURSE_MODE="${COSMOS_COURSE_MODE:-full}"
if [[ "${REDUCED:-0}" == "1" ]]; then
    export COSMOS_COURSE_MODE="reduced"
fi

printf '\n%s========================================================================%s\n' "${C_BOLD}" "${C_OFF}"
printf '%sExecuting %d notebook(s)%s\n' "${C_BOLD}" "${#NOTEBOOK_LIST[@]}" "${C_OFF}"
printf '%s========================================================================%s\n' "${C_BOLD}" "${C_OFF}"
printf '  kernel        %s\n' "$KERNEL"
printf '  cell timeout  %s s\n' "$CELL_TIMEOUT"
printf '  course mode   %s%s\n' "$COSMOS_COURSE_MODE" \
       "$( [[ "$COSMOS_COURSE_MODE" == reduced ]] && echo '  (REDUCED=1)' || true )"
printf '  results       %s\n' "$RESULTS_DIR"
printf '  drop cells    tagged %s\n' "$SKIP_TAG"
if [[ "$HAVE_SMI" -eq 1 ]]; then
    printf '  gpu idle      <= %s MiB, waiting up to %s s between notebooks\n' \
           "$GPU_IDLE_MIB" "$GPU_IDLE_TIMEOUT"
fi
printf '\n'
for nb in "${NOTEBOOK_LIST[@]}"; do
    printf '    %s\n' "${nb#"$REPO_ROOT"/}"
done
printf '\n'

if [[ "$DRY_RUN" -eq 1 ]]; then
    info "--dry-run: nothing was executed."
    exit 0
fi

# --------------------------------------------------------------------------
# Run
# --------------------------------------------------------------------------
declare -a RESULT_NAMES=() RESULT_STATUS=() RESULT_SECONDS=()
FAILURES=0
INDEX=0
TOTAL="${#NOTEBOOK_LIST[@]}"
RUN_START="$SECONDS"

for nb in "${NOTEBOOK_LIST[@]}"; do
    INDEX=$(( INDEX + 1 ))

    # Accept both absolute paths and repo-relative ones from NOTEBOOKS=.
    if [[ "$nb" != /* ]]; then
        nb="${REPO_ROOT}/${nb}"
    fi
    rel="${nb#"$REPO_ROOT"/}"
    # A notebook outside the repo keeps its absolute path here; strip the
    # leading slash so the results mirror stays under RESULTS_DIR instead of
    # producing "<results>//abs/path".
    rel="${rel#/}"

    printf '%s------------------------------------------------------------------------%s\n' \
           "${C_BOLD}" "${C_OFF}"
    printf '%s[%d/%d] %s%s\n' "${C_BOLD}" "$INDEX" "$TOTAL" "$rel" "${C_OFF}"

    if [[ ! -f "$nb" ]]; then
        warn "no such notebook: $nb"
        RESULT_NAMES+=("$rel"); RESULT_STATUS+=("MISSING"); RESULT_SECONDS+=("0")
        FAILURES=$(( FAILURES + 1 ))
        if [[ "$FAIL_FAST" -eq 1 ]]; then break; fi
        continue
    fi

    wait_for_gpu_idle

    # Mirror the source tree inside the results directory so two notebooks with
    # the same basename in different lesson folders cannot overwrite each other.
    out_subdir="${RESULTS_DIR}/$(dirname -- "$rel")"
    mkdir -p -- "$out_subdir"
    log_file="${LOG_DIR}/$(echo "$rel" | tr '/' '_').log"

    start="$SECONDS"
    status="PASS"

    # --ExecutePreprocessor.kernel_name overrides the notebook's own kernelspec,
    #   so a notebook that slipped through with `python3` still runs on the right
    #   interpreter here (validate_notebooks.py is what fails it, not this).
    # --TagRemovePreprocessor runs BEFORE ExecutePreprocessor in nbconvert's
    #   default preprocessor order, so tagged cells are removed rather than
    #   executed-and-hidden.
    # `set +e` around it: a failing notebook must be recorded in the table, not
    #   abort the whole run through `set -e`.
    set +e
    jupyter nbconvert \
        --to notebook \
        --execute \
        --ExecutePreprocessor.kernel_name="$KERNEL" \
        --ExecutePreprocessor.timeout="$CELL_TIMEOUT" \
        --ExecutePreprocessor.allow_errors=False \
        --TagRemovePreprocessor.enabled=True \
        --TagRemovePreprocessor.remove_cell_tags="[\"${SKIP_TAG}\"]" \
        --output-dir="$out_subdir" \
        --output="$(basename -- "${rel%.ipynb}").executed.ipynb" \
        "$nb" 2>&1 | tee "$log_file"
    rc="${PIPESTATUS[0]}"
    set -e

    elapsed=$(( SECONDS - start ))

    if [[ "$rc" -ne 0 ]]; then
        status="FAIL"
        FAILURES=$(( FAILURES + 1 ))
        printf '%sFAILED%s after %ds (exit %d). Log: %s\n' \
               "${C_RED}${C_BOLD}" "${C_OFF}" "$elapsed" "$rc" "$log_file"
        # The traceback nbconvert prints is the useful part; surface the last
        # lines here so a long run does not require opening every log.
        printf '  last 15 lines:\n'
        tail -n 15 -- "$log_file" | sed 's/^/    /'
    else
        printf '%sok%s in %ds\n' "${C_GREEN}" "${C_OFF}" "$elapsed"
    fi

    RESULT_NAMES+=("$rel")
    RESULT_STATUS+=("$status")
    RESULT_SECONDS+=("$elapsed")

    if [[ "$rc" -ne 0 && "$FAIL_FAST" -eq 1 ]]; then
        warn "--fail-fast: stopping after the first failure."
        break
    fi
done

# Leave the card clean for whoever runs next.
wait_for_gpu_idle

# --------------------------------------------------------------------------
# Table
# --------------------------------------------------------------------------
TOTAL_SECONDS=$(( SECONDS - RUN_START ))

# `if`, not `(( ... )) && ...`. An arithmetic command that evaluates to zero
# returns exit status 1, and a bare AND-list ending in a false test makes
# `set -e` kill the script — right at the point where we are about to print the
# results the caller actually ran this for.
width=0
for name in "${RESULT_NAMES[@]}"; do
    if (( ${#name} > width )); then width="${#name}"; fi
done
if (( width < 20 )); then width=20; fi

printf '\n%s========================================================================%s\n' "${C_BOLD}" "${C_OFF}"
printf '%sResults%s\n' "${C_BOLD}" "${C_OFF}"
printf '%s========================================================================%s\n' "${C_BOLD}" "${C_OFF}"
printf '  %-6s  %-*s  %8s\n' "STATUS" "$width" "NOTEBOOK" "SECONDS"
printf '  %-6s  %-*s  %8s\n' "------" "$width" "$(printf '%*s' "$width" '' | tr ' ' '-')" "--------"

for i in "${!RESULT_NAMES[@]}"; do
    case "${RESULT_STATUS[$i]}" in
        PASS) colour="${C_GREEN}" ;;
        *)    colour="${C_RED}" ;;
    esac
    printf '  %s%-6s%s  %-*s  %8s\n' \
        "$colour" "${RESULT_STATUS[$i]}" "${C_OFF}" \
        "$width" "${RESULT_NAMES[$i]}" "${RESULT_SECONDS[$i]}"
done

printf '\n  %d/%d passed in %dm %ds\n' \
       "$(( ${#RESULT_NAMES[@]} - FAILURES ))" "${#RESULT_NAMES[@]}" \
       "$(( TOTAL_SECONDS / 60 ))" "$(( TOTAL_SECONDS % 60 ))"
printf '  executed copies : %s\n' "$RESULTS_DIR"
printf '  logs            : %s\n' "$LOG_DIR"

if [[ "$FAILURES" -gt 0 ]]; then
    printf '\n%sWhat to do next%s\n' "${C_BOLD}" "${C_OFF}"
    cat <<EOF
  1. Read the log of the FIRST failure. Later ones are often knock-on effects
     of a GPU left in a bad state:
         less $LOG_DIR/<first-failure>.log
  2. Re-run just that notebook, and watch it:
         NOTEBOOKS="<path>" $0
  3. If it was an OOM, check nothing else owns the card:
         nvidia-smi
         docker ps --filter name=cosmos3-reasoner
     On one GPU the Reasoner NIM and generation cannot both be resident.
     See the header of docker/docker-compose.yml.
  4. If it was a timeout, the cell may simply be slow rather than hung:
         ./scripts/run_all.sh --timeout 3600
     or run the whole pass cheaply first:
         REDUCED=1 ./scripts/run_all.sh
EOF
    exit 1
fi

printf '\n%sAll notebooks executed cleanly.%s\n\n' "${C_GREEN}${C_BOLD}" "${C_OFF}"
