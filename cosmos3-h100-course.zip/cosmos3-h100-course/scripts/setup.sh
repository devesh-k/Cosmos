#!/usr/bin/env bash
#
# setup.sh — build the machine this course needs, on ONE H100 80 GB.
#
# Target: x86_64 Linux, glibc >= 2.35, NVIDIA driver with CUDA >= 12.8
#         (13.0 recommended), Python >= 3.10, Docker, ~150 GB free disk.
#
# Everything here is idempotent. Re-running it after a failure, or after a
# partial run, is the intended way to use it: each stage checks whether its work
# is already done and says "already done" rather than redoing it.
#
# Stages (each can be skipped):
#   0  preflight        ~5 s      0 GB    hardware / OS / driver / disk
#   1  uv               ~10 s   <0.1 GB   the package manager the framework needs
#   2  framework        20-40 m  ~25 GB   clone cosmos-framework + uv sync
#   3  kernel           ~1 m     ~1 GB    register `cosmos3-h100` for Jupyter
#   4  cookbook         2-10 m   ~3 GB    clone NVIDIA/cosmos (sample media)
#   5  ngc              ~5 s      0 GB    check nvcr.io credentials (never echoed)
#
# Usage:
#   ./scripts/setup.sh                 # everything
#   ./scripts/setup.sh --check-only    # preflight only, change nothing
#   ./scripts/setup.sh --skip-framework
#   ./scripts/setup.sh --skip-assets
#   ./scripts/setup.sh --nim-only      # only what the Reasoner NIM needs
#
# Exit status: 0 on success, 1 on a preflight failure or a stage error.

set -euo pipefail

# --------------------------------------------------------------------------
# Where are we?
# --------------------------------------------------------------------------
# Derived from BASH_SOURCE, not from $PWD, so the script works when invoked as
# `./scripts/setup.sh`, as `bash /abs/path/scripts/setup.sh`, or from anywhere
# else. Everything downstream uses absolute paths built from these two.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/.." && pwd -P)"
readonly SCRIPT_DIR REPO_ROOT

# --------------------------------------------------------------------------
# Output helpers
# --------------------------------------------------------------------------
if [[ -t 1 ]] && command -v tput >/dev/null 2>&1 && [[ "$(tput colors 2>/dev/null || echo 0)" -ge 8 ]]; then
    C_BOLD="$(tput bold)"; C_RED="$(tput setaf 1)"; C_GREEN="$(tput setaf 2)"
    C_YELLOW="$(tput setaf 3)"; C_BLUE="$(tput setaf 4)"; C_OFF="$(tput sgr0)"
else
    C_BOLD=""; C_RED=""; C_GREEN=""; C_YELLOW=""; C_BLUE=""; C_OFF=""
fi
readonly C_BOLD C_RED C_GREEN C_YELLOW C_BLUE C_OFF

PROBLEMS=0

stage()  { printf '\n%s=== %s ===%s\n' "${C_BOLD}${C_BLUE}" "$*" "${C_OFF}"; }
plan()   { printf '  %s->%s %s\n' "${C_BLUE}" "${C_OFF}" "$*"; }
ok()     { printf '  %sok%s   %s\n' "${C_GREEN}" "${C_OFF}" "$*"; }
warn()   { printf '  %swarn%s %s\n' "${C_YELLOW}" "${C_OFF}" "$*" >&2; }
info()   { printf '       %s\n' "$*"; }
fail()   { printf '  %sFAIL%s %s\n' "${C_RED}" "${C_OFF}" "$*" >&2; PROBLEMS=$((PROBLEMS + 1)); }
die()    { printf '\n%sfatal:%s %s\n' "${C_RED}${C_BOLD}" "${C_OFF}" "$*" >&2; exit 1; }

# fix "…" prints an indented remediation block under a fail/warn.
fix() {
    local line
    while IFS= read -r line; do
        printf '         %s\n' "$line"
    done <<< "$1"
}

# version_ge A B  ->  true when A >= B, using sort -V (handles 1.10 > 1.9).
version_ge() {
    [[ "$(printf '%s\n%s\n' "$2" "$1" | sort -V | head -n1)" == "$2" ]]
}

# --------------------------------------------------------------------------
# Argument parsing
# --------------------------------------------------------------------------
DO_FRAMEWORK=1
DO_ASSETS=1
DO_KERNEL=1
DO_NGC=1
DO_UV=1
CHECK_ONLY=0
NGC_LOGIN=0

usage() {
    # Anchored to CONTENT, not line numbers: a line-range here silently drifts
    # the first time anyone edits the header, and then --help prints code.
    sed -n '/^# setup\.sh —/,/^# Exit status/p' "${BASH_SOURCE[0]}" \
        | sed 's/^# \{0,1\}//'
    cat <<'EOF'

Flags:
  --check-only        Run preflight and stop. Changes nothing on disk.
  --skip-framework    Do not clone or build the Cosmos Framework venv (stage 2).
                      Implies --skip-kernel, since the kernel IS that venv.
  --skip-assets       Do not clone the NVIDIA/cosmos cookbook (stage 4).
  --skip-kernel       Build the framework venv but do not register the kernel.
  --nim-only          Only preflight + Docker/NGC checks. Use this when the
                      framework is already built and you just want the NIM path.
  --ngc-login         Actually run `docker login nvcr.io` using $NGC_API_KEY
                      (piped on stdin; the key is never placed in argv, printed,
                      or written to a file). Without this flag we only report.
  -h, --help          This text.

Environment overrides (all optional):
  COSMOS3_REPO              where to clone cosmos-framework   (~/cosmos3/cosmos-framework)
  COSMOS_ROOT               where to clone the cookbook       (<repo>/vendor/cosmos)
  COSMOS3_FRAMEWORK_REF     git ref to pin the framework to   (config.PINNED)
  COSMOS_COOKBOOK_REF       git ref to pin the cookbook to    (config.PINNED)
  COSMOS3_CUDA_GROUP        force cu128-train or cu130-train  (auto-detected)
  NGC_API_KEY               your NGC key. Read, never printed.
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --check-only)     CHECK_ONLY=1 ;;
        --skip-framework) DO_FRAMEWORK=0; DO_KERNEL=0 ;;
        --skip-assets)    DO_ASSETS=0 ;;
        --skip-kernel)    DO_KERNEL=0 ;;
        --nim-only)       DO_FRAMEWORK=0; DO_KERNEL=0; DO_ASSETS=0; DO_UV=0 ;;
        --ngc-login)      NGC_LOGIN=1 ;;
        -h|--help)        usage; exit 0 ;;
        *)                printf 'unknown flag: %s\n\n' "$1" >&2; usage >&2; exit 2 ;;
    esac
    shift
done

# --------------------------------------------------------------------------
# Read paths and pins from cosmos_course/config.py — one source of truth
# --------------------------------------------------------------------------
# config.py is loaded by file path rather than imported as `cosmos_course.config`
# on purpose: importing the submodule executes the package __init__, which pulls
# in viz/checks and therefore numpy, PIL and matplotlib. Those are not installed
# yet at this point in setup, and a preflight script must never require the thing
# it is about to install. config.py itself imports nothing but the stdlib.
read_config() {
    local key="$1"
    python3 - "$REPO_ROOT" "$key" <<'PY' 2>/dev/null || true
import importlib.util, pathlib, sys

root = pathlib.Path(sys.argv[1])
path = root / "cosmos_course" / "config.py"
name = "_cosmos_course_config"
spec = importlib.util.spec_from_file_location(name, path)
if spec is None or spec.loader is None:
    raise SystemExit(1)
mod = importlib.util.module_from_spec(spec)
# Registering in sys.modules is REQUIRED, not tidiness: @dataclass resolves
# annotations via sys.modules[cls.__module__], and an unregistered module makes
# that None, so config.py's EnvReport dies with
# "AttributeError: 'NoneType' object has no attribute '__dict__'".
sys.modules[name] = mod
spec.loader.exec_module(mod)

key = sys.argv[2]
if key.startswith("PINNED."):
    print(mod.PINNED[key.split(".", 1)[1]])
else:
    print(getattr(mod, key))
PY
}

COSMOS3_REPO="${COSMOS3_REPO:-$(read_config COSMOS3_REPO)}"
COSMOS_ROOT="${COSMOS_ROOT:-$(read_config COSMOS_ROOT)}"
FRAMEWORK_REF="${COSMOS3_FRAMEWORK_REF:-$(read_config PINNED.cosmos_framework)}"
COOKBOOK_REF="${COSMOS_COOKBOOK_REF:-$(read_config PINNED.cosmos_cookbook)}"

# Fall back to the documented defaults if config.py could not be read at all
# (a truncated checkout, a python3 that is too old to parse it). Better to keep
# going with a stated default than to abort before preflight has had its say.
COSMOS3_REPO="${COSMOS3_REPO:-$HOME/cosmos3/cosmos-framework}"
COSMOS_ROOT="${COSMOS_ROOT:-$REPO_ROOT/vendor/cosmos}"
FRAMEWORK_REF="${FRAMEWORK_REF:-main}"
COOKBOOK_REF="${COOKBOOK_REF:-main}"

readonly FRAMEWORK_URL="https://github.com/NVIDIA/cosmos-framework"
readonly COOKBOOK_URL="https://github.com/NVIDIA/cosmos"
readonly KERNEL_NAME="cosmos3-h100"
readonly KERNEL_DISPLAY="Cosmos 3 (H100)"
readonly UV_MIN="0.11.3"

# Disk accounting: measured against the filesystem holding COSMOS3_REPO, which
# is where the ~25 GB of wheels and CUDA libraries actually land.
disk_free_kb() {
    local target="$1"
    while [[ ! -d "$target" && "$target" != "/" ]]; do target="$(dirname -- "$target")"; done
    df -Pk -- "$target" 2>/dev/null | awk 'NR==2 {print $4}'
}

DISK_AT_START="$(disk_free_kb "$COSMOS3_REPO")"
DISK_AT_START="${DISK_AT_START:-0}"

# ==========================================================================
# Stage 0 — preflight
# ==========================================================================
stage "Stage 0/5  preflight  (~5 s, 0 GB)"
plan "Confirming this machine can run the course before anything is downloaded."

# -- OS and architecture ---------------------------------------------------
UNAME_S="$(uname -s)"
UNAME_M="$(uname -m)"
if [[ "$UNAME_S" != "Linux" ]]; then
    fail "this is $UNAME_S, not Linux."
    fix "The Cosmos Framework wheels, flash-attn-3-nv and the Reasoner NIM are
Linux-only. On Windows use WSL2 with the NVIDIA WSL driver; on macOS
there is no path — you need a Linux box with an H100."
else
    ok "Linux"
fi

if [[ "$UNAME_M" != "x86_64" ]]; then
    fail "CPU architecture is $UNAME_M, not x86_64."
    fix "The framework also supports aarch64, but this course is validated on
x86_64 only and the Reasoner NIM image may not have an arm64 manifest.
If you are on GH200/GB200, expect to build flash-attn yourself and note
that those are unified-memory parts, so the VRAM arithmetic in
cosmos_course.config.vram_budget() does not apply."
else
    ok "x86_64"
fi

# -- glibc -----------------------------------------------------------------
GLIBC_VER=""
if command -v ldd >/dev/null 2>&1; then
    GLIBC_VER="$(ldd --version 2>/dev/null | head -n1 | awk '{print $NF}')"
fi
if [[ -z "$GLIBC_VER" ]]; then
    warn "could not determine the glibc version (no ldd?). Continuing."
elif version_ge "$GLIBC_VER" "2.35"; then
    ok "glibc $GLIBC_VER  (>= 2.35)"
else
    fail "glibc $GLIBC_VER is older than the required 2.35."
    fix "The framework's prebuilt wheels are manylinux_2_35. Ubuntu 22.04 or
newer, RHEL 9 or newer, or Debian 12 will satisfy this. There is no
workaround short of upgrading the distribution or building from source."
fi

# -- Python ----------------------------------------------------------------
if ! command -v python3 >/dev/null 2>&1; then
    fail "python3 is not on PATH."
    fix "Install it:  sudo apt-get install -y python3 python3-venv python3-pip"
else
    PY_VER="$(python3 -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])')"
    if version_ge "$PY_VER" "3.10.0"; then
        ok "Python $PY_VER  (>= 3.10)"
    else
        fail "Python $PY_VER is older than the required 3.10."
        fix "cosmos-framework declares requires-python >=3.10, and this course
uses match statements and PEP 604 unions. Install 3.10+ and make sure
python3 resolves to it (deadsnakes PPA, pyenv, or your distro's
python3.11 package)."
    fi
fi

# -- NVIDIA driver + CUDA --------------------------------------------------
CUDA_VER=""
GPU_COUNT=0
if ! command -v nvidia-smi >/dev/null 2>&1; then
    fail "nvidia-smi is not on PATH, so no NVIDIA driver is installed."
    fix "Install the driver (>= 580 for CUDA 13, >= 525 for CUDA 12.8):
  sudo apt-get install -y nvidia-driver-580-server
then reboot and re-run this script. If you are in a container, the host
driver must be visible — start it with \`--gpus all\`."
elif ! nvidia-smi -L >/dev/null 2>&1; then
    fail "nvidia-smi exists but cannot talk to the driver."
    fix "Usually a kernel-module mismatch after an unattended upgrade.
  sudo modprobe nvidia   (then check: dmesg | tail -30)
A reboot fixes this in almost every case."
else
    GPU_COUNT="$(nvidia-smi -L | grep -c '^GPU ' || true)"
    DRIVER_VER="$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -n1)"
    GPU_NAME="$(nvidia-smi --query-gpu=name --format=csv,noheader | head -n1)"
    GPU_MEM="$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | head -n1)"
    ok "driver $DRIVER_VER, ${GPU_COUNT} GPU(s): ${GPU_NAME} (${GPU_MEM} MiB)"

    # The CUDA version in nvidia-smi's header is the highest CUDA runtime this
    # DRIVER supports. That, not nvcc, is what decides whether the cu130 wheels
    # will load, because the wheels ship their own runtime and only need a
    # driver new enough for it.
    CUDA_VER="$(nvidia-smi 2>/dev/null | sed -n 's/.*CUDA Version: *\([0-9][0-9.]*\).*/\1/p' | head -n1)"
    if [[ -z "$CUDA_VER" ]]; then
        CUDA_VER="$(nvidia-smi --query --display=COMPUTE 2>/dev/null \
                    | sed -n 's/.*CUDA Version *: *\([0-9][0-9.]*\).*/\1/p' | head -n1)"
    fi
    if [[ -z "$CUDA_VER" ]]; then
        warn "could not read the driver's CUDA version; assuming 12.8."
        CUDA_VER="12.8"
    elif version_ge "$CUDA_VER" "12.8"; then
        ok "driver supports CUDA $CUDA_VER  (>= 12.8)"
    else
        fail "the driver supports only CUDA $CUDA_VER; the framework needs >= 12.8."
        fix "Upgrade the driver — you do not need to touch the CUDA toolkit, the
wheels bring their own runtime. Driver 525+ gives you 12.8, 580+ gives
you 13.0 which is the recommended configuration."
    fi

    if [[ "$GPU_COUNT" -gt 1 ]]; then
        warn "$GPU_COUNT GPUs detected. This course is written for exactly one."
        fix "Nothing will break, but the VRAM-contention lessons assume a single
card. If you want to reproduce the course conditions exactly:
  export CUDA_VISIBLE_DEVICES=0
Do NOT copy the source DLI course's CUDA_VISIBLE_DEVICES=1 — on a
one-GPU box that hides your only GPU."
    fi

    # Compute capability: 8.0 for bf16, 8.9 for FP8, 9.0 = Hopper = H100.
    CC="$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -n1 || true)"
    if [[ -n "$CC" ]]; then
        if version_ge "$CC" "9.0"; then
            ok "compute capability $CC (Hopper or newer — FP8 and FlashAttention-3 available)"
        elif version_ge "$CC" "8.0"; then
            warn "compute capability $CC is pre-Hopper."
            fix "Everything runs, but the attention backend falls back from
flash-attn-3-nv to flash-attn and the NIM's FP8 profiles are
unavailable, so it will serve BF16 and need more VRAM."
        else
            fail "compute capability $CC is below 8.0."
            fix "Cosmos 3 needs Ampere or newer; bf16 does not exist before it."
        fi
    fi
fi

# -- Docker ----------------------------------------------------------------
if ! command -v docker >/dev/null 2>&1; then
    warn "docker is not installed. Lessons 02-05 (the Reasoner NIM) need it."
    fix "  curl -fsSL https://get.docker.com | sh
  sudo usermod -aG docker \"\$USER\"   # then log out and back in
Lesson 02 documents a no-Docker fallback (model_mode='reasoner' through
the framework), so this is a warning, not a failure."
elif ! docker info >/dev/null 2>&1; then
    warn "the docker binary exists but the daemon did not answer."
    fix "  sudo systemctl start docker
  sudo usermod -aG docker \"\$USER\"   # then log out and back in"
else
    ok "docker $(docker info --format '{{.ServerVersion}}' 2>/dev/null || echo '?')"
fi

# -- Disk ------------------------------------------------------------------
FREE_GB=$(( DISK_AT_START / 1024 / 1024 ))
if [[ "$DISK_AT_START" -eq 0 ]]; then
    warn "could not measure free disk space on the filesystem holding $COSMOS3_REPO."
elif [[ "$FREE_GB" -lt 100 ]]; then
    fail "only ${FREE_GB} GB free on the filesystem holding $COSMOS3_REPO; 100 GB is the minimum."
    fix "Budget, from COSMOS3_FACTS.md section 3:
  ~25 GB  framework venv (torch, CUDA libs, flash-attn)
  ~9 GB   Cosmos3-Edge weights
  ~35 GB  Cosmos3-Nano weights (Lesson 07 onward)
  ~20 GB  Reasoner NIM weights, FP8 nano profile
  ~20 GB  uv cache
  ~30 GB  generated video
150 GB is comfortable. If this filesystem is small, point the big
consumers elsewhere:
  export COSMOS3_REPO=/mnt/big/cosmos-framework
  export HF_HOME=/mnt/big/hf
  export UV_CACHE_DIR=/mnt/big/uv"
else
    ok "${FREE_GB} GB free on the filesystem holding $COSMOS3_REPO"
fi

# -- Nice-to-haves ---------------------------------------------------------
command -v git      >/dev/null 2>&1 || fail "git is not installed:  sudo apt-get install -y git"
command -v curl     >/dev/null 2>&1 || fail "curl is not installed: sudo apt-get install -y curl"
command -v ffmpeg   >/dev/null 2>&1 || warn "ffmpeg not found. Video preview cells will fail:  sudo apt-get install -y ffmpeg"
command -v git-lfs  >/dev/null 2>&1 || warn "git-lfs not found. Cookbook media will arrive as pointer files:  sudo apt-get install -y git-lfs && git lfs install"

if [[ "$PROBLEMS" -gt 0 ]]; then
    die "$PROBLEMS preflight problem(s). Fix them and re-run — nothing has been
       downloaded or changed. Use --check-only to re-check without side effects."
fi
ok "preflight clean"

if [[ "$CHECK_ONLY" -eq 1 ]]; then
    printf '\n%s--check-only: stopping here. Nothing was changed.%s\n' "${C_BOLD}" "${C_OFF}"
    exit 0
fi

# ==========================================================================
# Stage 1 — uv
# ==========================================================================
if [[ "$DO_UV" -eq 1 ]]; then
    stage "Stage 1/5  uv >= ${UV_MIN}  (~10 s, <0.1 GB)"

    # ~/.local/bin may not be on PATH yet in this shell even if uv is installed.
    export PATH="$HOME/.local/bin:$PATH"

    UV_CURRENT=""
    if command -v uv >/dev/null 2>&1; then
        UV_CURRENT="$(uv --version 2>/dev/null | awk '{print $2}')"
    fi

    if [[ -n "$UV_CURRENT" ]] && version_ge "$UV_CURRENT" "$UV_MIN"; then
        ok "uv $UV_CURRENT already installed (>= $UV_MIN); nothing to do"
    else
        if [[ -n "$UV_CURRENT" ]]; then
            plan "Upgrading uv $UV_CURRENT -> latest (need >= $UV_MIN) via the astral installer."
        else
            plan "Installing uv into ~/.local/bin via the astral installer."
        fi
        info "cosmos-framework's lockfile uses resolution features that landed in $UV_MIN."
        # UV_INSTALL_DIR keeps it in ~/.local/bin rather than ~/.cargo/bin, and
        # the installer is idempotent — re-running it replaces the binary in
        # place. No sudo, nothing outside $HOME.
        #
        # The variable is applied with `env` on the RIGHT of the pipe. Writing
        # `VAR=x curl ... | sh` sets it for curl, not for the shell that actually
        # reads it, which is a silent no-op that installs to the default prefix.
        curl -LsSf https://astral.sh/uv/install.sh \
            | env UV_INSTALL_DIR="$HOME/.local/bin" sh
        hash -r
        UV_CURRENT="$(uv --version 2>/dev/null | awk '{print $2}' || true)"
        if [[ -z "$UV_CURRENT" ]]; then
            die "uv still is not on PATH after installation.
       Add this to ~/.bashrc and open a new shell:
           export PATH=\"\$HOME/.local/bin:\$PATH\""
        fi
        version_ge "$UV_CURRENT" "$UV_MIN" \
            || warn "installed uv is $UV_CURRENT, which is below $UV_MIN. The sync may fail."
        ok "uv $UV_CURRENT"
    fi
else
    stage "Stage 1/5  uv  — skipped"
fi

# ==========================================================================
# Stage 2 — Cosmos Framework
# ==========================================================================
# Decide the CUDA dependency group up front so the plan we print is the plan we
# execute. The framework ships mutually exclusive `cu128-train` and `cu130-train`
# groups; picking the wrong one gives you wheels the driver cannot load.
CUDA_GROUP="${COSMOS3_CUDA_GROUP:-}"
if [[ -z "$CUDA_GROUP" ]]; then
    CUDA_MAJOR="${CUDA_VER%%.*}"
    if [[ -n "$CUDA_MAJOR" ]] && [[ "$CUDA_MAJOR" =~ ^[0-9]+$ ]] && [[ "$CUDA_MAJOR" -ge 13 ]]; then
        CUDA_GROUP="cu130-train"
    else
        CUDA_GROUP="cu128-train"
    fi
fi
readonly CUDA_GROUP

if [[ "$DO_FRAMEWORK" -eq 1 ]]; then
    stage "Stage 2/5  Cosmos Framework  (20-40 min, ~25 GB)"
    plan "Clone $FRAMEWORK_URL -> $COSMOS3_REPO"
    plan "Pin to ref '$FRAMEWORK_REF', then build its uv venv with --group=$CUDA_GROUP"
    info "Chose $CUDA_GROUP because the driver reports CUDA $CUDA_VER."
    if [[ "$CUDA_GROUP" == "cu130-train" ]]; then
        info "CUDA 13 is what NVIDIA recommends for Cosmos 3 (COSMOS3_FACTS.md section 3)."
    else
        info "CUDA 12.8 is the supported floor. Upgrading the driver to 580+ would"
        info "let you use cu130-train, which is the recommended configuration."
    fi
    info "Override with:  COSMOS3_CUDA_GROUP=cu130-train ./scripts/setup.sh"

    if [[ ! -d "$COSMOS3_REPO/.git" ]]; then
        if [[ -e "$COSMOS3_REPO" ]] && [[ -n "$(ls -A -- "$COSMOS3_REPO" 2>/dev/null)" ]]; then
            die "$COSMOS3_REPO exists and is not a git checkout.
       Move it aside, or point COSMOS3_REPO somewhere else."
        fi
        mkdir -p -- "$(dirname -- "$COSMOS3_REPO")"
        git clone --filter=blob:none "$FRAMEWORK_URL" "$COSMOS3_REPO"
        ok "cloned"
    else
        ok "already cloned at $COSMOS3_REPO"
        git -C "$COSMOS3_REPO" fetch --tags --prune origin
    fi

    # Pinning, honestly. COSMOS3_FACTS.md section 3 records that this repository
    # publishes NO git tags or releases: "v1.2.2" is the version string inside
    # pyproject.toml on main, not something you can check out. So we try the ref,
    # and if it does not resolve we say so loudly and stay on main rather than
    # pretending the checkout is pinned when it is not.
    if git -C "$COSMOS3_REPO" rev-parse --verify --quiet "${FRAMEWORK_REF}^{commit}" >/dev/null 2>&1; then
        git -C "$COSMOS3_REPO" -c advice.detachedHead=false checkout --quiet "$FRAMEWORK_REF"
        ok "checked out $FRAMEWORK_REF ($(git -C "$COSMOS3_REPO" rev-parse --short HEAD))"
    else
        git -C "$COSMOS3_REPO" -c advice.detachedHead=false checkout --quiet origin/main
        RESOLVED_SHA="$(git -C "$COSMOS3_REPO" rev-parse HEAD)"
        warn "the ref '$FRAMEWORK_REF' does not exist in this repository."
        fix "This is expected and documented: NVIDIA/cosmos-framework publishes no
git tags, so '$FRAMEWORK_REF' is only the version string in pyproject.toml
(COSMOS3_FACTS.md section 3). We have checked out origin/main instead,
which is NOT reproducible.

To pin properly, record the SHA you actually built against:
  export COSMOS3_FRAMEWORK_REF=$RESOLVED_SHA
and put that line in your shell profile before re-running."
    fi

    # `uv sync` is idempotent: it reconciles .venv against uv.lock and does
    # nothing if they already agree.
    #
    # GIT_LFS_SKIP_SMUDGE=1 stops git-lfs pulling optional test fixtures during
    # dependency resolution — those are large, unnecessary for inference, and a
    # common cause of a sync failing 30 minutes in.
    plan "Running: GIT_LFS_SKIP_SMUDGE=1 uv sync --all-extras --group=$CUDA_GROUP"
    info "First run compiles/downloads torch, CUDA libraries and the attention"
    info "backend. 20-40 minutes and ~25 GB is normal. Later runs take seconds."
    cd -- "$COSMOS3_REPO" || die "could not enter $COSMOS3_REPO"
    GIT_LFS_SKIP_SMUDGE=1 uv sync --all-extras "--group=$CUDA_GROUP"
    cd -- "$REPO_ROOT" || die "could not return to $REPO_ROOT"

    VENV_PY="$COSMOS3_REPO/.venv/bin/python"
    [[ -x "$VENV_PY" ]] || die "uv sync finished but there is no interpreter at $VENV_PY"

    if "$VENV_PY" -c 'import cosmos_framework' >/dev/null 2>&1; then
        ok "cosmos_framework imports inside $COSMOS3_REPO/.venv"
    else
        warn "cosmos_framework does not import in the new venv."
        fix "Show the real error with:
  $VENV_PY -c 'import cosmos_framework'
An 'undefined symbol' error means a bundled libtorch is shadowing the
venv's copy — clear LD_LIBRARY_PATH and try again."
    fi
else
    stage "Stage 2/5  Cosmos Framework  — skipped"
    VENV_PY="$COSMOS3_REPO/.venv/bin/python"
fi

# ==========================================================================
# Stage 3 — Jupyter kernel
# ==========================================================================
if [[ "$DO_KERNEL" -eq 1 ]]; then
    stage "Stage 3/5  Jupyter kernel '$KERNEL_NAME'  (~1 min, ~1 GB)"
    plan "Install ipykernel + notebook helpers into the framework venv."
    plan "Register it as '$KERNEL_NAME' / \"$KERNEL_DISPLAY\", then patch kernel.json."

    if [[ ! -x "$VENV_PY" ]]; then
        warn "no interpreter at $VENV_PY, so there is nothing to register."
        fix "Run without --skip-framework first, or set COSMOS3_REPO to an
existing framework checkout that has a .venv."
    else
        # Idempotent: uv pip install is a no-op when the packages are present at
        # a satisfying version.
        uv pip install --quiet --python "$VENV_PY" \
            ipykernel matplotlib imageio-ffmpeg ipywidgets
        ok "ipykernel matplotlib imageio-ffmpeg ipywidgets present in the venv"

        # --user puts the kernelspec in ~/.local/share/jupyter/kernels/, which is
        # right for a host-side Jupyter and needs no root. Re-running overwrites
        # the existing spec rather than erroring.
        "$VENV_PY" -m ipykernel install --user \
            --name="$KERNEL_NAME" --display-name="$KERNEL_DISPLAY"
        ok "kernel registered"

        # Patch kernel.json.
        #
        # WHY: the NGC PyTorch image (nvcr.io/nvidia/pytorch:25.09-py3) — and any
        # host that has sourced a similar environment — puts its own bundled
        # libtorch on LD_LIBRARY_PATH. That shadows the framework venv's copy and
        # `import torch` dies with an undefined-symbol error that reads exactly
        # like a corrupt install. Clearing LD_LIBRARY_PATH for this kernel only
        # is the fix documented in the Cosmos Framework FAQ.
        #
        # PYTHONNOUSERSITE=1 for the same class of reason: a stray
        # ~/.local/lib/python3.x/site-packages/torch would otherwise be importable
        # from inside the venv and win.
        #
        # The kernel.json is located by GLOB, not by assuming a prefix. Where
        # ipykernel writes depends on --user, on sys.prefix, on whether a
        # JUPYTER_DATA_DIR is set, and on whether you are root; hard-coding one
        # of those is how this silently patches nothing.
        python3 - "$KERNEL_NAME" <<'PY'
import glob
import json
import os
import sys

name = sys.argv[1]
roots = [
    os.path.expanduser("~/.local/share/jupyter"),
    os.path.expanduser("~/Library/Jupyter"),
    "/usr/local/share/jupyter",
    "/usr/share/jupyter",
    os.environ.get("JUPYTER_DATA_DIR", ""),
]
seen, matches = set(), []
for root in roots:
    if not root:
        continue
    for path in glob.glob(os.path.join(root, "kernels", name, "kernel.json")):
        real = os.path.realpath(path)
        if real not in seen:
            seen.add(real)
            matches.append(path)

if not matches:
    print(f"  warn  could not find a kernel.json for {name!r} to patch.")
    print(f"        Look for it with:  jupyter kernelspec list")
    sys.exit(0)

for kernel in matches:
    with open(kernel, encoding="utf-8") as handle:
        spec = json.load(handle)
    env = spec.setdefault("env", {})
    env["LD_LIBRARY_PATH"] = ""
    env["PYTHONNOUSERSITE"] = "1"
    with open(kernel, "w", encoding="utf-8") as handle:
        json.dump(spec, handle, indent=1)
        handle.write("\n")
    print(f"  ok   patched {kernel}")
    print(f"       LD_LIBRARY_PATH=\"\"  PYTHONNOUSERSITE=1")
PY
    fi
else
    stage "Stage 3/5  Jupyter kernel  — skipped"
fi

# ==========================================================================
# Stage 4 — cookbook assets
# ==========================================================================
if [[ "$DO_ASSETS" -eq 1 ]]; then
    stage "Stage 4/5  Cosmos cookbook  (2-10 min, ~3 GB)"
    plan "Clone $COOKBOOK_URL -> $COSMOS_ROOT (pin: $COOKBOOK_REF)"
    info "This is sample media only — prompts, control videos, action trajectories."
    info "No model weights. scripts/fetch_assets.py verifies the individual files."

    if [[ ! -d "$COSMOS_ROOT/.git" ]]; then
        if [[ -e "$COSMOS_ROOT" ]] && [[ -n "$(ls -A -- "$COSMOS_ROOT" 2>/dev/null)" ]]; then
            die "$COSMOS_ROOT exists and is not a git checkout. Move it aside."
        fi
        mkdir -p -- "$(dirname -- "$COSMOS_ROOT")"
        git clone "$COOKBOOK_URL" "$COSMOS_ROOT"
        ok "cloned"
    else
        ok "already cloned at $COSMOS_ROOT"
        git -C "$COSMOS_ROOT" fetch --prune origin
    fi

    if git -C "$COSMOS_ROOT" rev-parse --verify --quiet "${COOKBOOK_REF}^{commit}" >/dev/null 2>&1; then
        git -C "$COSMOS_ROOT" -c advice.detachedHead=false checkout --quiet "$COOKBOOK_REF"
    else
        git -C "$COSMOS_ROOT" -c advice.detachedHead=false checkout --quiet origin/main
        warn "cookbook ref '$COOKBOOK_REF' did not resolve; using origin/main."
    fi
    ok "cookbook at $(git -C "$COSMOS_ROOT" rev-parse --short HEAD)"

    if command -v git-lfs >/dev/null 2>&1; then
        git -C "$COSMOS_ROOT" lfs pull || warn "git lfs pull failed; media may be pointer files."
        ok "git-lfs media pulled"
    else
        warn "git-lfs is not installed, so the .mp4 and .jpg files are 130-byte pointers."
        fix "  sudo apt-get install -y git-lfs && git lfs install
  git -C $COSMOS_ROOT lfs pull
scripts/fetch_assets.py detects pointer files and will tell you."
    fi
else
    stage "Stage 4/5  Cosmos cookbook  — skipped"
fi

# ==========================================================================
# Stage 5 — NGC credentials
# ==========================================================================
stage "Stage 5/5  NGC / nvcr.io credentials  (~5 s, 0 GB)"
plan "Check whether Docker can pull the Reasoner NIM. The key is never printed."

NGC_OK=0
if [[ -f "$HOME/.docker/config.json" ]] \
   && grep -q 'nvcr\.io' "$HOME/.docker/config.json" 2>/dev/null; then
    ok "docker already holds credentials for nvcr.io"
    NGC_OK=1
elif [[ -n "${NGC_API_KEY:-}" ]] && [[ "$NGC_LOGIN" -eq 1 ]] && command -v docker >/dev/null 2>&1; then
    plan "Logging in to nvcr.io (--ngc-login was passed)."
    # The key goes in on stdin only. It never appears in argv, so it cannot
    # leak through `ps`, shell history, or a traceback. The username is the
    # LITERAL string $oauthtoken — single quotes stop the shell expanding it
    # to the empty string, which is the most common way this command fails.
    if printf '%s' "$NGC_API_KEY" | docker login nvcr.io -u '$oauthtoken' --password-stdin >/dev/null 2>&1; then
        ok "logged in to nvcr.io"
        NGC_OK=1
    else
        warn "docker login nvcr.io failed. The key may be wrong or expired."
    fi
elif [[ -n "${NGC_API_KEY:-}" ]]; then
    warn "NGC_API_KEY is set (value not shown) but docker is not logged in to nvcr.io."
    fix "Either re-run with --ngc-login, or do it yourself:
  echo \"\$NGC_API_KEY\" | docker login nvcr.io -u '\$oauthtoken' --password-stdin
The username is the literal text \$oauthtoken. The single quotes matter."
else
    warn "NGC_API_KEY is not set, so the Reasoner NIM image pull will 401."
    fix "1. Get a key at https://ngc.nvidia.com/setup/api-key
   (the free NVIDIA Developer Program tier is enough)
2. export NGC_API_KEY=...      # put this in ~/.bashrc, never in a notebook
3. ./scripts/setup.sh --nim-only --ngc-login
Lessons 06+ (generation, post-training) do not need this at all."
fi

# ==========================================================================
# Summary
# ==========================================================================
DISK_AT_END="$(disk_free_kb "$COSMOS3_REPO")"
DISK_AT_END="${DISK_AT_END:-$DISK_AT_START}"
USED_KB=$(( DISK_AT_START - DISK_AT_END ))
# `if`, not `[[ ... ]] && ...`: under `set -e` a bare AND-list whose test fails
# makes the whole script exit, which would abort the summary on a happy path.
if [[ "$USED_KB" -lt 0 ]]; then USED_KB=0; fi
USED_GB=$(( USED_KB / 1024 / 1024 ))
FREE_NOW_GB=$(( DISK_AT_END / 1024 / 1024 ))

printf '\n%s========================================================================%s\n' "${C_BOLD}" "${C_OFF}"
printf '%sSetup complete%s\n' "${C_BOLD}${C_GREEN}" "${C_OFF}"
printf '%s========================================================================%s\n' "${C_BOLD}" "${C_OFF}"
printf '\n'
printf '  course repo     %s\n' "$REPO_ROOT"
printf '  framework       %s\n' "$COSMOS3_REPO"
printf '  framework venv  %s\n' "$COSMOS3_REPO/.venv"
printf '  cuda group      %s  (driver reports CUDA %s)\n' "$CUDA_GROUP" "${CUDA_VER:-unknown}"
printf '  cookbook        %s\n' "$COSMOS_ROOT"
printf '  jupyter kernel  %s  ("%s")\n' "$KERNEL_NAME" "$KERNEL_DISPLAY"
printf '  nvcr.io login   %s\n' "$( [[ "$NGC_OK" -eq 1 ]] && echo yes || echo 'no — NIM lessons will not pull' )"
printf '\n'
printf '  disk consumed by this run   ~%s GB\n' "$USED_GB"
printf '  free on that filesystem     %s GB\n' "$FREE_NOW_GB"
printf '\n'
printf '%sNext steps%s\n' "${C_BOLD}" "${C_OFF}"
cat <<EOF

  1. Install the course kernel layer (openai, jupyterlab, nbconvert, ...):
         python3 -m pip install -e "$REPO_ROOT"

  2. Verify the machine end to end. Tiers 0-3 are fast and need no downloads:
         python3 "$REPO_ROOT/scripts/smoke_test.py"
         python3 "$REPO_ROOT/scripts/smoke_test.py" --full   # + a ~9 GB Edge run

  3. Confirm the cookbook assets the lessons name are really on disk:
         python3 "$REPO_ROOT/scripts/fetch_assets.py" --check

  4. Start the Reasoner NIM when you reach Lesson 02:
         cd "$REPO_ROOT/docker" && cp .env.example .env   # then edit .env
         docker compose up -d cosmos3-reasoner
     Read docker/docker-compose.yml first — the comment block at the top
     explains why you must stop the NIM before generating on one GPU.

  5. Launch Jupyter on the host and pick the "$KERNEL_DISPLAY" kernel:
         cd "$REPO_ROOT" && jupyter lab

EOF
if [[ "$FREE_NOW_GB" -lt 60 ]]; then
    warn "only ${FREE_NOW_GB} GB left. Nano's weights alone are ~35 GB."
    fix "scripts/cleanup.sh reports what is reclaimable."
fi
