#!/usr/bin/env python3
"""Tiered smoke test for the Cosmos 3 single-H100 course. Fast checks first.

The tiers are ordered by cost, and each one presumes the ones before it. Run
this after ``scripts/setup.sh`` and again whenever something stops working: it
is much cheaper to learn "the framework venv is broken" in four seconds than to
find out forty minutes into a render.

    Tier 0   package imports, config resolves            <1 s    no GPU
    Tier 1   GPU present, >=20 GB VRAM, bf16, CC >= 8.0  ~2 s    GPU
    Tier 2   framework venv + ModelMode regression check ~10 s   GPU optional
    Tier 3   Reasoner NIM reachable and healthy          ~2 s    NIM running
    Tier 4   a real end-to-end generation (--full only)  5-20 m  ~9 GB download

Tier 2 is a genuine REGRESSION CHECK against upstream drift, not a smoke test in
the usual sense. It asserts that ``ModelMode`` contains ``wam`` and does NOT
contain ``policy``. Upstream renamed the mode; ``docs/inference.md``,
``docs/faq.md`` and the action cookbook README all still say ``policy``, and the
source DLI course's notebook 04 uses it and would fail. If that check ever goes
red, upstream changed something the course depends on. See COSMOS3_FACTS.md
section 2.

Skips are not failures. A tier whose prerequisite is absent (no GPU, no NIM, no
framework) is reported as SKIP and does not affect the exit code, so this script
is useful on a laptop as well as on the H100.

Exit codes
----------
0   Everything that ran, passed.
1   Tier 0 failed — the course package itself is broken. Nothing else can work.
2   Tier 1 failed — the GPU is missing or unsuitable.
3   Tier 2 failed — the framework venv is broken, or upstream drifted.
4   Tier 3 failed — the NIM is running but unhealthy. (Not started = SKIP = 0.)
5   Tier 4 failed — end-to-end generation did not produce a usable file.
6   Bad usage.

When several tiers fail, the exit code is the LOWEST failing tier, because that
is the one to fix first.

Examples
--------
    python3 scripts/smoke_test.py                 # tiers 0-3
    python3 scripts/smoke_test.py --full          # + tier 4 (downloads ~9 GB)
    python3 scripts/smoke_test.py --tier 2        # stop after tier 2
    python3 scripts/smoke_test.py --json          # machine-readable
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent

# The course package lives at the repo root. Prepending rather than appending so
# a stale `pip install cosmos-course` elsewhere cannot shadow the checkout you
# are actually editing.
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

PASS, FAIL, SKIP = "PASS", "FAIL", "SKIP"


@dataclass
class Check:
    """One assertion, its outcome, and what to do when it is red."""

    tier: int
    name: str
    status: str = SKIP
    detail: str = ""
    remedy: str = ""
    seconds: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "tier": self.tier, "name": self.name, "status": self.status,
            "detail": self.detail, "remedy": self.remedy,
            "seconds": round(self.seconds, 3),
        }


@dataclass
class Results:
    checks: list[Check] = field(default_factory=list)

    def add(self, check: Check) -> Check:
        self.checks.append(check)
        return check

    def failed_tiers(self) -> list[int]:
        return sorted({c.tier for c in self.checks if c.status == FAIL})

    def counts(self) -> dict[str, int]:
        out = {PASS: 0, FAIL: 0, SKIP: 0}
        for check in self.checks:
            out[check.status] += 1
        return out


def timed(fn: Callable[[], tuple[str, str, str]]) -> tuple[str, str, str, float]:
    """Run a check function, returning ``(status, detail, remedy, seconds)``.

    Any unexpected exception becomes a FAIL carrying the exception text. A smoke
    test that dies with a traceback has told you less than one that says which
    assertion blew up and what to do about it.
    """
    start = time.monotonic()
    try:
        status, detail, remedy = fn()
    except Exception as exc:  # noqa: BLE001 - by design; see docstring
        status, detail = FAIL, f"{type(exc).__name__}: {exc}"
        remedy = "This check raised rather than returning a verdict, which is a "\
                 "bug in the check or a genuinely broken environment. Re-run "\
                 "with --traceback to see where."
    return status, detail, remedy, time.monotonic() - start


# ==========================================================================
# Tier 0 — no GPU needed
# ==========================================================================
def tier0(results: Results, args: argparse.Namespace) -> None:
    def check_import() -> tuple[str, str, str]:
        import cosmos_course  # noqa: F401

        return (
            PASS,
            f"cosmos_course {cosmos_course.__version__} from "
            f"{Path(cosmos_course.__file__).parent}",
            "",
        )

    def check_submodules() -> tuple[str, str, str]:
        """`models` and `nim` are required; `finetune` genuinely is not.

        cosmos_course/__init__.py imports those three defensively on purpose, so
        a partial checkout costs you those helpers and nothing else. This check
        honours that design: only the two that the scripts and Lessons 02-13
        actually call are treated as required. Failing on `finetune` would make
        every run red on a checkout that is working perfectly well for
        inference.
        """
        import cosmos_course

        missing = cosmos_course.missing_modules()
        required = [name for name in ("models", "nim") if name in missing]
        if required:
            return (
                FAIL,
                "; ".join(f"{name}: {missing[name]}" for name in required),
                "These are not optional for this course — models.Generator and "
                "nim.NimConfig are used from Lesson 02 onward. A missing "
                "third-party import is the usual cause:\n"
                f"    python3 -m pip install -e {REPO_ROOT}",
            )
        optional_missing = sorted(set(missing) - {"models", "nim"})
        detail = "models, nim available"
        if optional_missing:
            detail += f"  (optional not present: {', '.join(optional_missing)})"
        return PASS, detail, ""

    def check_config() -> tuple[str, str, str]:
        from cosmos_course import config

        lines = [
            f"COURSE_ROOT={config.COURSE_ROOT}",
            f"OUTPUT_ROOT={config.OUTPUT_ROOT}",
            f"COSMOS3_REPO={config.COSMOS3_REPO}",
            f"COSMOS_ROOT={config.COSMOS_ROOT}",
        ]
        if not config.COURSE_ROOT.is_dir():
            return (
                FAIL, "; ".join(lines),
                "COURSE_ROOT does not exist, which should be impossible since it "
                "is derived from config.py's own location. A broken symlink or a "
                "half-copied checkout would do it.",
            )
        # Not a failure if these are absent — later tiers report on them — but
        # worth surfacing here where it is cheap.
        notes = []
        if not config.COSMOS3_REPO.exists():
            notes.append("framework not cloned")
        if not config.COSMOS_ROOT.exists():
            notes.append("cookbook not cloned")
        detail = "; ".join(lines)
        if notes:
            detail += f"  [{', '.join(notes)}]"
        return PASS, detail, ""

    def check_vram_budget() -> tuple[str, str, str]:
        from cosmos_course.config import vram_budget

        # Passing total_gb explicitly makes this a pure-arithmetic test with no
        # GPU dependency: 80 GB is the machine the course targets, so the
        # answers below are the ones the lessons quote.
        budget = vram_budget(80.0)
        edge = budget["coexist_with_edge"]
        nano = budget["coexist_with_nano"]
        if not edge["feasible"]:
            return (
                FAIL,
                f"vram_budget(80) says Edge cannot coexist with the NIM "
                f"({edge['nim_budget_gb']} GB left)",
                "The arithmetic in config.vram_budget() has changed and no longer "
                "agrees with the course text. Check MODEL_TIERS' "
                "inference_vram_gb figures against COSMOS3_FACTS.md section 3.",
            )
        return (
            PASS,
            f"80 GB card: NIM cap {edge['nim_fraction']:.2f} with Edge, "
            f"{nano['nim_fraction']:.2f} with Nano "
            f"(nano coexist feasible: {nano['feasible']})",
            "",
        )

    def check_modes_table() -> tuple[str, str, str]:
        """The course's own mode table must agree with the facts file.

        Cheap, local, and it catches the `policy` regression one layer earlier
        than tier 2 does — without needing the framework installed at all.
        """
        from cosmos_course.config import MODEL_MODES
        from cosmos_course.specs import normalize_policy_mode

        problems = []
        if "wam" not in MODEL_MODES:
            problems.append("config.MODEL_MODES is missing 'wam'")
        if "policy" in MODEL_MODES:
            problems.append("config.MODEL_MODES still contains the dead 'policy' mode")
        if normalize_policy_mode("policy") != "wam":
            problems.append("normalize_policy_mode('policy') does not return 'wam'")
        if problems:
            return (
                FAIL, "; ".join(problems),
                "COSMOS3_FACTS.md section 2 is authoritative: upstream renamed "
                "`policy` to `wam`. Fix cosmos_course/config.py and specs.py to "
                "match, not the other way round.",
            )
        return PASS, f"{len(MODEL_MODES)} modes, 'wam' present, 'policy' absent", ""

    def check_python() -> tuple[str, str, str]:
        major, minor = sys.version_info[:2]
        version = f"{major}.{minor}.{sys.version_info[2]}"
        if (major, minor) < (3, 10):
            return (
                FAIL, f"Python {version}",
                "This course and cosmos-framework both require >= 3.10. Install a "
                "newer interpreter and re-create the kernel:\n"
                "    scripts/setup.sh --skip-framework --skip-assets",
            )
        return PASS, f"Python {version}", ""

    for name, fn in (
        ("python >= 3.10", check_python),
        ("import cosmos_course", check_import),
        ("required submodules present", check_submodules),
        ("config resolves paths", check_config),
        ("vram_budget() arithmetic", check_vram_budget),
        ("MODEL_MODES has wam, not policy", check_modes_table),
    ):
        status, detail, remedy, seconds = timed(fn)
        results.add(Check(0, name, status, detail, remedy, seconds))
        if args.traceback and status == FAIL:
            print(f"  [traceback mode] {name}: {detail}", file=sys.stderr)


# ==========================================================================
# Tier 1 — the GPU
# ==========================================================================
def tier1(results: Results, args: argparse.Namespace) -> None:
    del args

    try:
        import torch
    except ImportError:
        results.add(Check(
            1, "torch importable", SKIP,
            "torch is not installed in this interpreter",
            "This is expected if you are running the smoke test from the course "
            "kernel layer rather than the framework venv. To test the GPU as the "
            "notebooks will see it, run this script with the framework's python:\n"
            f"    $COSMOS3_REPO/.venv/bin/python {Path(__file__).name}",
        ))
        for name in ("GPU visible", "VRAM >= 20 GB", "bf16 available",
                     "compute capability >= 8.0"):
            results.add(Check(1, name, SKIP, "no torch", ""))
        return

    results.add(Check(1, "torch importable", PASS,
                      f"torch {torch.__version__} (CUDA {torch.version.cuda})"))

    if not torch.cuda.is_available():
        results.add(Check(
            1, "GPU visible", FAIL,
            "torch.cuda.is_available() is False",
            "In order:\n"
            "  1. `nvidia-smi` — does the driver see the card at all?\n"
            "  2. `python -c \"import torch; print(torch.version.cuda)\"` — a "
            "None here means a CPU-only torch build.\n"
            "  3. `echo $CUDA_VISIBLE_DEVICES` — the source DLI notebooks pinned "
            "this to '1', which on a one-GPU box hides your only GPU. Unset it.\n"
            "  4. Inside a container? It needs `--gpus all` and the NVIDIA "
            "Container Toolkit on the host.",
        ))
        for name in ("VRAM >= 20 GB", "bf16 available", "compute capability >= 8.0"):
            results.add(Check(1, name, SKIP, "no CUDA device", ""))
        return

    count = torch.cuda.device_count()
    name0 = torch.cuda.get_device_name(0)
    detail = f"{count} device(s), cuda:0 = {name0}"
    if count > 1:
        detail += " — the course assumes exactly one; set CUDA_VISIBLE_DEVICES=0"
    results.add(Check(1, "GPU visible", PASS, detail))

    props = torch.cuda.get_device_properties(0)
    total_gb = props.total_memory / (1024 ** 3)
    free_b, _ = torch.cuda.mem_get_info(0)
    free_gb = free_b / (1024 ** 3)

    if total_gb < 20:
        results.add(Check(
            1, "VRAM >= 20 GB", FAIL,
            f"{total_gb:.1f} GB total",
            "Cosmos3-Edge inference wants ~12 GB and Nano ~32 GB. Below 20 GB "
            "you cannot complete the course. There is no quantised path that "
            "changes this.",
        ))
    elif total_gb < 40:
        results.add(Check(
            1, "VRAM >= 20 GB", PASS,
            f"{total_gb:.1f} GB total, {free_gb:.1f} GB free — Edge only; "
            f"Nano (~32 GB) will be tight and Super is out of reach",
        ))
    else:
        note = ""
        if free_gb < total_gb - 4:
            note = (f"  WARNING: only {free_gb:.1f} GB free — something else "
                    f"already owns this card (a leftover NIM, or a python "
                    f"process from a previous run)")
        results.add(Check(1, "VRAM >= 20 GB", PASS,
                          f"{total_gb:.1f} GB total, {free_gb:.1f} GB free{note}"))

    try:
        bf16 = torch.cuda.is_bf16_supported()
    except Exception:  # noqa: BLE001
        bf16 = False
    results.add(Check(
        1, "bf16 available", PASS if bf16 else FAIL,
        "torch.cuda.is_bf16_supported() = " + str(bf16),
        "" if bf16 else
        "Every Cosmos 3 checkpoint is bf16. Without it you have a pre-Ampere "
        "card and there is no supported path. Check compute capability below.",
    ))

    major, minor = torch.cuda.get_device_capability(0)
    cc = f"{major}.{minor}"
    if (major, minor) < (8, 0):
        results.add(Check(
            1, "compute capability >= 8.0", FAIL, f"sm_{major}{minor} ({cc})",
            "Cosmos 3 needs Ampere (8.0) or newer. bf16 does not exist before it.",
        ))
    elif (major, minor) < (9, 0):
        results.add(Check(
            1, "compute capability >= 8.0", PASS,
            f"sm_{major}{minor} ({cc}) — pre-Hopper: FlashAttention-3 and the "
            f"NIM's FP8 profiles are unavailable, so expect slower kernels and "
            f"a BF16 NIM that needs >56 GB",
        ))
    else:
        results.add(Check(1, "compute capability >= 8.0", PASS,
                          f"sm_{major}{minor} ({cc}) — Hopper or newer: FP8 and "
                          f"flash-attn-3-nv available"))


# ==========================================================================
# Tier 2 — the framework venv, and the ModelMode regression check
# ==========================================================================
# Run inside the framework venv, not here. The framework has its own torch, its
# own flash-attn and its own CUDA wheels, and its dependency groups conflict
# with each other (vllm vs every cu* group), so nothing can import both.
_PROBE = r"""
import json, sys
out = {"import_ok": False, "version": None, "modes": [], "error": None}
try:
    import cosmos_framework
    out["import_ok"] = True
    out["version"] = getattr(cosmos_framework, "__version__", "unknown")
except Exception as exc:
    out["error"] = f"{type(exc).__name__}: {exc}"
    print(json.dumps(out)); sys.exit(0)
try:
    from cosmos_framework.inference.args import ModelMode
    out["modes"] = sorted(getattr(m, "value", str(m)) for m in ModelMode)
except Exception as exc:
    out["error"] = f"ModelMode: {type(exc).__name__}: {exc}"
print(json.dumps(out))
"""


def tier2(results: Results, args: argparse.Namespace) -> None:
    del args
    from cosmos_course.config import COSMOS3_REPO

    repo = COSMOS3_REPO
    venv_python = repo / ".venv" / "bin" / "python"

    if not repo.exists():
        for name in ("framework checkout exists", "framework venv exists",
                     "import cosmos_framework", "ModelMode contains wam",
                     "ModelMode does NOT contain policy"):
            results.add(Check(
                2, name, SKIP, f"no checkout at {repo}",
                "    scripts/setup.sh          # clones and builds it\n"
                "or, if you already have one elsewhere:\n"
                "    export COSMOS3_REPO=/path/to/cosmos-framework",
            ))
        return
    results.add(Check(2, "framework checkout exists", PASS, str(repo)))

    if not venv_python.exists():
        for name in ("framework venv exists", "import cosmos_framework",
                     "ModelMode contains wam", "ModelMode does NOT contain policy"):
            results.add(Check(
                2, name, FAIL, f"no interpreter at {venv_python}",
                "The checkout is there but its venv was never built:\n"
                f"    cd {repo} && GIT_LFS_SKIP_SMUDGE=1 uv sync --all-extras "
                f"--group=cu130-train\n"
                "  (use cu128-train on a CUDA 12.x driver — scripts/setup.sh "
                "picks the right one for you)",
            ))
        return
    results.add(Check(2, "framework venv exists", PASS, str(venv_python)))

    # LD_LIBRARY_PATH is cleared for the same reason the Jupyter kernel.json
    # clears it: a bundled libtorch on the ambient LD_LIBRARY_PATH shadows the
    # venv's own copy and `import torch` fails with an undefined-symbol error
    # that reads like a corrupt install.
    env = dict(os.environ, LD_LIBRARY_PATH="", PYTHONNOUSERSITE="1")
    try:
        proc = subprocess.run(
            [str(venv_python), "-c", _PROBE],
            capture_output=True, text=True, timeout=180, check=False, env=env,
        )
    except (subprocess.SubprocessError, OSError) as exc:
        results.add(Check(2, "import cosmos_framework", FAIL, str(exc),
                          f"Could not even launch {venv_python}."))
        return

    try:
        probe = json.loads(proc.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        results.add(Check(
            2, "import cosmos_framework", FAIL,
            f"probe produced no JSON (exit {proc.returncode})",
            "Run it by hand to see the real error:\n"
            f"    LD_LIBRARY_PATH= {venv_python} -c 'import cosmos_framework'\n\n"
            f"stderr tail:\n{proc.stderr.strip()[-800:]}",
        ))
        return

    if not probe["import_ok"]:
        results.add(Check(
            2, "import cosmos_framework", FAIL, probe["error"] or "unknown",
            "An 'undefined symbol' error means a libtorch mismatch: clear "
            "LD_LIBRARY_PATH. Anything else means the venv is incomplete — "
            f"re-run `uv sync --all-extras --group=cu130-train` in {repo}.",
        ))
        for name in ("ModelMode contains wam", "ModelMode does NOT contain policy"):
            results.add(Check(2, name, SKIP, "cosmos_framework did not import", ""))
        return

    results.add(Check(2, "import cosmos_framework", PASS,
                      f"version {probe['version']}"))

    modes = probe["modes"]
    if not modes:
        for name in ("ModelMode contains wam", "ModelMode does NOT contain policy"):
            results.add(Check(
                2, name, FAIL, probe.get("error") or "ModelMode enum was empty",
                "cosmos_framework.inference.args.ModelMode could not be read. "
                "If upstream moved the enum, find it with:\n"
                f"    grep -rn 'class ModelMode' {repo}/cosmos_framework/",
            ))
        return

    # --- the regression check -------------------------------------------
    results.add(Check(
        2, "ModelMode contains wam",
        PASS if "wam" in modes else FAIL,
        f"{len(modes)} modes: {', '.join(modes)}",
        "" if "wam" in modes else
        "COSMOS3_FACTS.md section 2 says the World Action Model mode is `wam`. "
        "It is not in this checkout's enum. Either the checkout predates the "
        "rename (check out a newer ref) or upstream renamed it again — in which "
        "case update the facts file FIRST, then config.MODEL_MODES, then the "
        "lessons.",
    ))
    results.add(Check(
        2, "ModelMode does NOT contain policy",
        PASS if "policy" not in modes else FAIL,
        "`policy` absent, as expected" if "policy" not in modes
        else "`policy` is present in this checkout's ModelMode",
        "" if "policy" not in modes else
        "This checkout still has the OLD enum. `policy` was renamed to `wam`. "
        "Notebooks written for `wam` will fail against it. Update the framework:\n"
        f"    git -C {repo} fetch && git -C {repo} checkout origin/main\n"
        "then re-run `uv sync`. Note that raw.githubusercontent.com/.../main/... "
        "serves a stale cached copy showing POLICY — use .../refs/heads/main/... "
        "if you are checking by hand.",
    ))

    extra = [m for m in ("reasoner", "image2image", "audio_image2video") if m not in modes]
    if extra:
        results.add(Check(
            2, "ModelMode has the modes the course teaches", FAIL,
            f"missing: {', '.join(extra)}",
            "The course teaches these modes and this checkout does not have "
            "them. It is probably older than the course. Check the pinned ref.",
        ))
    else:
        results.add(Check(2, "ModelMode has the modes the course teaches", PASS,
                          "reasoner, image2image, audio_image2video all present"))


# ==========================================================================
# Tier 3 — the Reasoner NIM
# ==========================================================================
def tier3(results: Results, args: argparse.Namespace) -> None:
    del args
    from cosmos_course.nim import NimConfig, nim_status

    cfg = NimConfig()
    status = nim_status(cfg)

    if not status["docker"]:
        results.add(Check(
            3, "NIM reachable", SKIP, "docker is not installed",
            "Lessons 02-05 need it. Lesson 02 also documents a no-Docker "
            "fallback: the framework serves the reasoner tower directly with "
            "model_mode='reasoner'.",
        ))
        return

    if not status["container_exists"] and not status["ready"]:
        results.add(Check(
            3, "NIM reachable", SKIP,
            f"nothing listening on {cfg.base_url} and no container named "
            f"{cfg.container_name!r}",
            "This is fine — the NIM is not meant to be running all the time; on "
            "one GPU it would starve generation of VRAM. Start it when a lesson "
            "asks:\n"
            "    cd docker && docker compose up -d cosmos3-reasoner\n"
            "    python -c 'from cosmos_course.nim import start_nim; start_nim()'",
        ))
        return

    if status["container_exists"] and not status["running"]:
        results.add(Check(
            3, "NIM reachable", SKIP,
            f"a container named {cfg.container_name!r} exists but is not running "
            f"({status['state']})",
            "If it exited unexpectedly, the logs will say why:\n"
            f"    docker logs --tail 100 {cfg.container_name}",
        ))
        return

    if not status["ready"]:
        code = status["health_status"]
        results.add(Check(
            3, "NIM healthy", FAIL,
            f"container is up ({status['state']}) but /v1/health/ready returned "
            f"{code or 'connection refused'}",
            "Almost always one of:\n"
            "  * still loading weights — the first start downloads 20 GB (nano) "
            "or 40 GB (super) with no progress on this side. Wait, and watch:\n"
            f"      docker logs -f {cfg.container_name}\n"
            "  * 401/403 on the pull — you are not logged in to nvcr.io:\n"
            "      echo \"$NGC_API_KEY\" | docker login nvcr.io -u '$oauthtoken' "
            "--password-stdin\n"
            "  * CUDA OOM at load — something else owns the GPU. Check "
            "`nvidia-smi`; a leftover generation process is the usual culprit.",
        ))
        return

    results.add(Check(3, "NIM healthy", PASS,
                      f"{cfg.base_url} ready, serving {status['model_id']}"))

    expected = f"cosmos3-{cfg.model_size}-reasoner"
    model_id = status["model_id"] or ""
    results.add(Check(
        3, "NIM serves the expected model",
        PASS if expected in model_id else FAIL,
        f"serving {model_id!r}, expected something containing {expected!r}",
        "" if expected in model_id else
        "The running container was started with a different NIM_MODEL_SIZE. "
        "Recreate it:\n"
        "    docker compose up -d --force-recreate cosmos3-reasoner",
    ))

    vram = status["vram_gb"]
    if vram is None:
        results.add(Check(
            3, "NIM VRAM footprint measured", SKIP,
            "nvidia-smi did not attribute per-process memory on this machine",
            "Measure by difference instead: read gpu_used_gb with the NIM "
            "stopped, then again with it running.",
        ))
    else:
        total = status["gpu_total_gb"] or 80.0
        hogging = vram > 0.6 * total
        results.add(Check(
            3, "NIM VRAM footprint measured", PASS,
            f"{vram:.1f} / {total:.1f} GB held by the NIM"
            + ("  — that is most of the card, which is EXPECTED (KV cache "
               "reservation). Generation will OOM while it is up." if hogging else ""),
            "" if not hogging else
            "Either stop_nim(cfg) before generating (the course default), or "
            "restart with a cap — print_vram_plan() gives you the number.",
        ))


# ==========================================================================
# Tier 4 — a genuinely tiny end-to-end generation
# ==========================================================================
def tier4(results: Results, args: argparse.Namespace) -> None:
    from cosmos_course.config import COSMOS3_REPO, OUTPUT_ROOT

    if not args.full:
        results.add(Check(
            4, "end-to-end generation", SKIP,
            "--full not given",
            "Tier 4 downloads Cosmos3-Edge (~9.1 GB) on first run and takes "
            "5-20 minutes. Enable it deliberately:\n"
            "    python3 scripts/smoke_test.py --full",
        ))
        return

    if not (COSMOS3_REPO / ".venv" / "bin" / "python").exists():
        results.add(Check(
            4, "end-to-end generation", SKIP,
            "the framework venv does not exist (see tier 2)",
            "Run scripts/setup.sh first.",
        ))
        return

    from cosmos_course.models import Generator
    from cosmos_course.specs import InferenceSpec

    # The smallest thing the framework will do that still exercises the whole
    # path: text -> latent -> VAE -> file. num_frames=1 makes it text2image, so
    # there is no temporal dimension at all; the 256 tier is 256x144; 8 steps is
    # well below the 35 a real render uses. This is a plumbing test, and the
    # image it produces will look bad. That is fine and expected.
    spec = InferenceSpec(
        model_mode="text2image",
        name="smoke_test",
        prompt="a single red cube on a plain grey table, studio lighting",
        resolution="256",
        aspect_ratio="16,9",
        num_frames=1,
        num_steps=8,
        seed=0,
    )

    output_dir = Path(args.output or (OUTPUT_ROOT / "smoke_test"))
    print("\n  Tier 4: a 256p, 1-frame, 8-step Cosmos3-Edge generation")
    print(f"  into {output_dir}")
    print("  First run downloads ~9.1 GB of weights. This is not fast.\n")

    generator = Generator(checkpoint="Cosmos3-Edge")
    result = generator.run(spec, output_dir, stream_logs=not args.json,
                           timeout=args.timeout)

    if not result.ok:
        diagnosis = "\n".join(f"  * {d}" for d in result.diagnose()) or \
                    "  (no specific diagnosis; read the log tail above)"
        results.add(Check(
            4, "end-to-end generation", FAIL,
            f"exit {result.returncode} after {result.seconds:.0f}s, "
            f"{len(result.outputs)} output file(s)",
            "The framework's own diagnosis:\n" + diagnosis + "\n\n"
            "Note that exit 0 with no output files also counts as a failure "
            "here, deliberately — this stack does produce that combination.",
        ))
        return

    # verify_result returns a LIST of CheckResult, each with .passed. Exiting
    # zero and writing a file is not the same as producing a usable image —
    # that asymmetry is the whole point of cosmos_course.checks.
    from cosmos_course.checks import verify_result

    verdicts = verify_result(result, verbose=not args.json)
    bad = [v for v in verdicts if not v.passed]
    results.add(Check(
        4, "end-to-end generation",
        PASS if not bad else FAIL,
        f"{result.seconds:.0f}s, wrote {[p.name for p in result.outputs]}"
        + (f"; content checks failed: {', '.join(v.name for v in bad)}" if bad else ""),
        "" if not bad else
        "A file was written but content verification failed:\n"
        + "\n".join(f"  * {v.name}: {v.reason}" for v in bad)
        + "\nA blank or single-colour image usually means the guardrail "
          "rejected the prompt, or the VAE decoded noise. Open the file.",
    ))


# ==========================================================================
# Reporting
# ==========================================================================
_GLYPH = {PASS: "ok  ", FAIL: "FAIL", SKIP: "skip"}


def print_report(results: Results, elapsed: float) -> None:
    width = max((len(c.name) for c in results.checks), default=20) + 2
    print()
    print("=" * (width + 30))
    print("Cosmos 3 smoke test")
    print("=" * (width + 30))
    current = -1
    for check in results.checks:
        if check.tier != current:
            current = check.tier
            print(f"\n  Tier {current}")
        print(f"    [{_GLYPH[check.status]}] {check.name:<{width}} {check.detail}")

    print()
    print("-" * (width + 30))
    counts = results.counts()
    print(f"  {counts[PASS]} passed, {counts[FAIL]} failed, {counts[SKIP]} skipped "
          f"in {elapsed:.1f}s")

    problems = [c for c in results.checks if c.status == FAIL and c.remedy]
    if problems:
        print()
        print("  WHAT TO DO NEXT")
        print("  " + "-" * 60)
        for check in problems:
            print(f"\n  [tier {check.tier}] {check.name}")
            for line in check.remedy.splitlines():
                print(f"    {line}")

    skipped_with_advice = [
        c for c in results.checks if c.status == SKIP and c.remedy
    ]
    if skipped_with_advice and not problems:
        print()
        print("  Skipped. Grouped by cause, since one missing prerequisite")
        print("  usually skips several checks at once:")
        # Group by remedy so "no framework checkout" prints once rather than
        # five times with five different check names in front of it.
        grouped: dict[str, list[str]] = {}
        for check in skipped_with_advice:
            grouped.setdefault(check.remedy, []).append(check.name)
        for remedy, names in grouped.items():
            print(f"\n    {', '.join(names)}")
            for line in remedy.splitlines():
                print(f"      {line}")
    print()


class _Parser(argparse.ArgumentParser):
    """ArgumentParser that exits 6 on a usage error.

    argparse's default is 2, which in this script's scheme already means "tier 1
    failed — the GPU is unsuitable". A typo in a flag reporting a GPU problem
    would be a small, avoidable lie, and CI would act on it.
    """

    def error(self, message: str) -> Any:  # type: ignore[override]
        self.print_usage(sys.stderr)
        self.exit(6, f"{self.prog}: error: {message}\n")


def build_parser() -> argparse.ArgumentParser:
    parser = _Parser(
        prog="smoke_test.py",
        description=(
            "Tiered environment check for the Cosmos 3 single-H100 course. "
            "Cheap checks run first; a tier whose prerequisite is missing is "
            "SKIPPED, not failed, so this is useful on a laptop too."
        ),
        epilog=(
            "Tiers:\n"
            "  0  package imports and config          <1 s,  no GPU needed\n"
            "  1  GPU, VRAM, bf16, compute capability ~2 s,  needs a GPU\n"
            "  2  framework venv + ModelMode wam/policy regression check\n"
            "  3  Reasoner NIM health (skipped if not started)\n"
            "  4  a real 256p 1-frame 8-step generation  --full only, ~9 GB\n\n"
            "Exit codes: 0 ok · 1 tier 0 · 2 tier 1 · 3 tier 2 · 4 tier 3 · "
            "5 tier 4 · 6 bad usage.\n"
            "With several failures the code is the LOWEST failing tier — fix "
            "that one first."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--tier", type=int, default=3, metavar="N", choices=range(0, 5),
        help="Highest tier to run (0-4). Default 3. Tier 4 additionally "
             "requires --full.",
    )
    parser.add_argument(
        "--full", action="store_true",
        help="Run tier 4: a real end-to-end Cosmos3-Edge generation. Downloads "
             "~9.1 GB of weights on first run and takes 5-20 minutes. Off by "
             "default for exactly that reason.",
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Emit results as JSON on stdout instead of the table.",
    )
    parser.add_argument(
        "--output", type=Path, default=None, metavar="DIR",
        help="Where tier 4 writes. Default: $COSMOS_COURSE_OUTPUT/smoke_test.",
    )
    parser.add_argument(
        "--timeout", type=float, default=3600.0, metavar="SEC",
        help="Wall-clock limit for the tier 4 generation subprocess. Default "
             "3600 — generous, because the first run includes the download.",
    )
    parser.add_argument(
        "--traceback", action="store_true",
        help="Print exception detail for failing checks as they happen, rather "
             "than only in the summary.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.full and args.tier < 4:
        args.tier = 4

    results = Results()
    started = time.monotonic()

    tiers: list[tuple[int, Callable[[Results, argparse.Namespace], None]]] = [
        (0, tier0), (1, tier1), (2, tier2), (3, tier3), (4, tier4),
    ]

    for number, runner in tiers:
        if number > args.tier:
            break
        # A failed tier 0 means cosmos_course itself is unusable, and every
        # later tier imports from it. Stopping is honest; continuing would
        # produce a screenful of derived noise.
        if number > 0 and 0 in results.failed_tiers():
            results.add(Check(
                number, f"tier {number}", SKIP,
                "tier 0 failed, so nothing downstream can be trusted", "",
            ))
            continue
        try:
            runner(results, args)
        except Exception as exc:  # noqa: BLE001
            if args.traceback:
                import traceback
                traceback.print_exc()
            results.add(Check(
                number, f"tier {number} runner", FAIL,
                f"{type(exc).__name__}: {exc}",
                "The tier itself crashed. Re-run with --traceback.",
            ))

    elapsed = time.monotonic() - started

    if args.json:
        json.dump(
            {
                "checks": [c.to_dict() for c in results.checks],
                "counts": results.counts(),
                "failed_tiers": results.failed_tiers(),
                "seconds": round(elapsed, 3),
            },
            sys.stdout, indent=2,
        )
        sys.stdout.write("\n")
    else:
        print_report(results, elapsed)

    failed = results.failed_tiers()
    return (failed[0] + 1) if failed else 0


if __name__ == "__main__":
    sys.exit(main())
