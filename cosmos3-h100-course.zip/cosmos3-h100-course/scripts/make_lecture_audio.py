#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Turn the Cosmos 3 lecture scripts into audio files you can listen to anywhere.

Reads ``lectures/NN_<slug>.md``, strips the markdown down to speakable prose,
splits it into chunks a speech engine can swallow, synthesises each chunk,
and stitches the pieces back together with short pauses between paragraphs.
You get ``lectures/audio/NN_<slug>.mp3``, a ``playlist.m3u`` in course order,
and an ``index.html`` that plays the whole course in a browser.

    python scripts/make_lecture_audio.py                 # all twenty, edge-tts
    python scripts/make_lecture_audio.py --lesson 03     # just lesson 03
    python scripts/make_lecture_audio.py --dry-run       # plan only, no audio
    python scripts/make_lecture_audio.py --self-test     # prove the pipeline works

FOUR BACKENDS, tried in this order unless you pass --backend.

1. edge-tts  (DEFAULT, and the one you want)
   Microsoft's neural voices. Free, no account, no GPU, ``pip install edge-tts``.
   Writes MP3 directly. Runs on Windows, macOS and Linux.

   PRIVACY, PLAINLY: edge-tts needs an internet connection and it sends the
   text of each chunk to a Microsoft speech endpoint (the same service that
   powers Edge's Read Aloud). The lecture scripts are not secret, but if you
   are not comfortable sending them to Microsoft, use the kokoro backend
   instead, which runs entirely on your own machine.

2. kokoro
   An 82-million-parameter neural TTS model. Runs locally, on CPU or on the
   H100. Downloads roughly 350 MB once, then works offline forever. Slower
   than edge-tts and a little less polished, but nothing leaves the box.

3. piper
   Small CPU ONNX voices. Clearly synthetic but perfectly intelligible, and
   very fast. Good when you want offline audio and do not want a torch install.

4. espeak-ng
   The last resort. It is on almost every Linux box already and it sounds like
   1998. Never selected automatically unless nothing else is installed, and it
   warns when it is used.

Everything is idempotent. A lesson whose audio is newer than its script is
skipped unless you pass --force, so an interrupted run costs you nothing.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import time
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable, Sequence

__version__ = "1.0.0"

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------

SCRIPT_DIR = Path(__file__).resolve().parent
COURSE_ROOT = SCRIPT_DIR.parent
DEFAULT_LECTURE_DIR = COURSE_ROOT / "lectures"
DEFAULT_AUDIO_DIR = DEFAULT_LECTURE_DIR / "audio"

LESSON_RE = re.compile(r"^(\d{2})_([A-Za-z0-9_\-]+)\.md$")

# --------------------------------------------------------------------------
# Backend defaults
# --------------------------------------------------------------------------

BACKENDS = ("edge", "kokoro", "piper", "espeak")
AUTO_ORDER = ("edge", "kokoro", "piper", "espeak")

DEFAULT_VOICE = {
    "edge": "en-US-AndrewNeural",
    "kokoro": "am_michael",
    "piper": "en_US-lessac-medium",
    "espeak": "en-us",
}

# A short curated list, so --list-voices is useful even with no network.
CURATED_VOICES = {
    "edge": [
        ("en-US-AndrewNeural", "male, warm, conversational  [default]"),
        ("en-US-BrianNeural", "male, calm, even pace"),
        ("en-US-GuyNeural", "male, brighter, a little faster"),
        ("en-US-ChristopherNeural", "male, lower, news-reader"),
        ("en-US-EmmaNeural", "female, warm, conversational"),
        ("en-US-AvaNeural", "female, expressive"),
        ("en-US-JennyNeural", "female, neutral, very clear"),
        ("en-GB-RyanNeural", "male, British"),
        ("en-GB-SoniaNeural", "female, British"),
        ("en-IN-PrabhatNeural", "male, Indian English"),
        ("en-IN-NeerjaNeural", "female, Indian English"),
        ("en-AU-WilliamNeural", "male, Australian"),
    ],
    "kokoro": [
        ("am_michael", "American male  [default]"),
        ("am_adam", "American male, deeper"),
        ("am_fenrir", "American male, brighter"),
        ("af_heart", "American female, warm"),
        ("af_bella", "American female"),
        ("af_nicole", "American female, softer"),
        ("bm_george", "British male"),
        ("bm_lewis", "British male, lower"),
        ("bf_emma", "British female"),
    ],
    "piper": [
        ("en_US-lessac-medium", "American male, clearest of the small ones  [default]"),
        ("en_US-ryan-high", "American male, higher quality, bigger download"),
        ("en_US-amy-medium", "American female"),
        ("en_GB-alan-medium", "British male"),
        ("en_GB-northern_english_male-medium", "British male, northern"),
    ],
    "espeak": [
        ("en-us", "American English  [default]"),
        ("en-gb", "British English"),
        ("en-gb-x-rp", "British English, received pronunciation"),
    ],
}

INSTALL_HINT = {
    "edge": "pip install edge-tts",
    "kokoro": "pip install kokoro soundfile   (plus 'apt install espeak-ng' on Linux for its phonemiser)",
    "piper": "pip install piper-tts",
    "espeak": "apt install espeak-ng   (Linux)  /  choco install espeak   (Windows)",
}

FFMPEG_HINT = (
    "Install ffmpeg and put it on PATH:\n"
    "  Windows : winget install Gyan.FFmpeg      (then open a NEW terminal)\n"
    "  macOS   : brew install ffmpeg\n"
    "  Linux   : sudo apt install ffmpeg\n"
    "Or pass --format wav, which can be stitched together without ffmpeg."
)

# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------

_QUIET = False


def say(msg: str = "") -> None:
    if not _QUIET:
        print(msg, flush=True)


def warn(msg: str) -> None:
    print(f"  ! {msg}", file=sys.stderr, flush=True)


class PipelineError(RuntimeError):
    """An error whose message already tells the user what to do next."""


def human_size(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.0f} KB"
    return f"{n / (1024 * 1024):.1f} MB"


def human_time(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    h, rem = divmod(int(round(seconds)), 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}h {m:02d}m {s:02d}s"
    return f"{m}m {s:02d}s"


# ==========================================================================
# 1. Markdown -> speakable text
# ==========================================================================

@dataclass
class Block:
    kind: str          # "heading" | "para"
    text: str
    level: int = 0


# Order matters in a few of these, so they are applied as a list, not a dict.
SYMBOLS: list[tuple[str, str]] = [
    ("—", ", "),   # em dash
    ("–", ", "),   # en dash
    ("‒", ", "),   # figure dash
    ("…", ", "),   # ellipsis
    ("‘", "'"), ("’", "'"),
    ("“", '"'), ("”", '"'),
    (" ", " "),    # non-breaking space
    ("​", ""),     # zero width space
    ("×", " by "),
    ("÷", " divided by "),
    ("≈", " about "),
    ("≥", " at least "),
    ("≤", " at most "),
    ("≠", " not equal to "),
    ("→", " to "),
    ("±", " plus or minus "),
    ("°", " degrees "),
    ("µ", "micro"), ("μ", "micro"),
    ("‑", "-"),
    ("&nbsp;", " "),
    ("&amp;", " and "),
    ("&", " and "),
]

RE_FENCE = re.compile(r"^[ \t]*(```|~~~).*?(?:^[ \t]*\1[ \t]*$|\Z)", re.M | re.S)
RE_HTML = re.compile(r"<[^<>\n]{1,200}>")
RE_HEADING = re.compile(r"^[ \t]{0,3}(#{1,6})[ \t]+(.*?)[ \t]*#*[ \t]*$")
RE_LIST = re.compile(r"^[ \t]*(?:[-*+]|\d{1,3}[.)])[ \t]+(.*)$")
RE_HRULE = re.compile(r"^[ \t]{0,3}([-*_])[ \t]*(?:\1[ \t]*){2,}$")
RE_QUOTE = re.compile(r"^[ \t]{0,3}>[ \t]?")
RE_INDENT_CODE = re.compile(r"^(?: {4,}|\t)\S")
RE_IMAGE = re.compile(r"!\[([^\]]*)\]\([^)]*\)")
RE_LINK = re.compile(r"\[([^\]]+)\]\([^)]*\)")
RE_REFLINK = re.compile(r"\[([^\]]+)\]\[[^\]]*\]")
RE_INLINE_CODE = re.compile(r"`+([^`]+?)`+")
RE_URL = re.compile(r"\b(?:https?://|www\.)\S+")
RE_FOOTNOTE = re.compile(r"\[\^[^\]]*\]")
RE_BOLD = re.compile(r"\*\*(.+?)\*\*", re.S)
RE_BOLD_U = re.compile(r"__(.+?)__", re.S)
RE_ITAL = re.compile(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", re.S)
RE_ITAL_U = re.compile(r"(?<![\w_])_(?!\s)(.+?)(?<!\s)_(?![\w_])", re.S)
RE_STRIKE = re.compile(r"~~(.+?)~~", re.S)
RE_ESCAPE = re.compile(r"\\([\\`*_{}\[\]()#+\-.!>|~])")
RE_FRONTMATTER = re.compile(r"\A﻿?---[ \t]*\r?\n.*?\r?\n---[ \t]*\r?\n", re.S)


def strip_front_matter(text: str) -> tuple[str, dict]:
    """Remove a leading YAML front-matter block and parse its simple keys."""
    meta: dict[str, str] = {}
    m = RE_FRONTMATTER.match(text)
    if not m:
        return text.lstrip("﻿"), meta
    for line in m.group(0).splitlines():
        line = line.strip()
        if not line or line == "---":
            continue
        if ":" in line:
            k, _, v = line.partition(":")
            meta[k.strip()] = v.strip().strip("'\"")
    return text[m.end():], meta


def speakify_identifier(s: str) -> str:
    """`max_num_tokens` -> 'max num tokens'. A fallback for stray inline code."""
    s = re.sub(r"[_/\\]+", " ", s)
    s = re.sub(r"(?<=\w)\.(?=\w)", " dot ", s)
    s = re.sub(r"^--?", "", s)
    return re.sub(r"\s+", " ", s).strip()


def markdown_to_speech(md_text: str, lesson: str = "?") -> tuple[list[Block], list[str], dict]:
    """Convert a lecture markdown file into speakable blocks.

    Returns (blocks, warnings, front_matter). Everything that cannot be spoken
    is either converted or dropped, and every drop produces a warning naming
    the lesson so you know which script to go and fix.
    """
    warnings: list[str] = []

    def note(what: str, n: int = 1) -> None:
        warnings.append(f"{lesson}: {what}" + (f" (x{n})" if n > 1 else ""))

    text, meta = strip_front_matter(md_text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    # --- block-level removals -------------------------------------------
    fenced = RE_FENCE.findall(text)
    if fenced:
        note("dropped fenced code block", len(fenced))
        text = RE_FENCE.sub("\n", text)

    n_html = len(RE_HTML.findall(text))
    if n_html:
        note("stripped inline HTML tag", n_html)
        text = RE_HTML.sub(" ", text)

    # --- line-by-line ----------------------------------------------------
    blocks: list[Block] = []
    buf: list[str] = []
    n_table = n_list = n_code = n_quote = 0

    def flush() -> None:
        if buf:
            joined = " ".join(x.strip() for x in buf if x.strip())
            if joined.strip():
                blocks.append(Block("para", joined))
            buf.clear()

    for raw in text.split("\n"):
        line = raw.rstrip()
        stripped = line.strip()

        if not stripped:
            flush()
            continue
        if RE_HRULE.match(line):
            flush()
            continue
        if stripped.count("|") >= 2:                 # a table row, or its ruler
            flush()
            n_table += 1
            continue
        if RE_INDENT_CODE.match(line) and not buf:   # indented code block
            n_code += 1
            continue

        m = RE_HEADING.match(line)
        if m:
            flush()
            head = m.group(2).strip()
            if head:
                blocks.append(Block("heading", head, level=len(m.group(1))))
            continue

        if RE_QUOTE.match(line):
            n_quote += 1
            line = RE_QUOTE.sub("", line)
            stripped = line.strip()

        m = RE_LIST.match(line)
        if m:
            flush()
            n_list += 1
            blocks.append(Block("para", m.group(1).strip()))
            continue

        buf.append(stripped)
    flush()

    if n_table:
        note("dropped table row", n_table)
    if n_code:
        note("dropped indented code line", n_code)
    if n_list:
        note("flattened list item into a sentence", n_list)
    if n_quote:
        note("unwrapped block quote line", n_quote)

    # --- inline cleanup --------------------------------------------------
    n_img = n_link = n_inline = n_url = 0
    out: list[Block] = []
    for b in blocks:
        s = b.text

        n_img += len(RE_IMAGE.findall(s))
        s = RE_IMAGE.sub(" ", s)

        n_link += len(RE_LINK.findall(s)) + len(RE_REFLINK.findall(s))
        s = RE_LINK.sub(r"\1", s)
        s = RE_REFLINK.sub(r"\1", s)

        n_url += len(RE_URL.findall(s))
        s = RE_URL.sub("a link in the notes", s)

        n_inline += len(RE_INLINE_CODE.findall(s))
        s = RE_INLINE_CODE.sub(lambda m: speakify_identifier(m.group(1)), s)

        s = RE_FOOTNOTE.sub("", s)
        s = RE_BOLD.sub(r"\1", s)
        s = RE_BOLD_U.sub(r"\1", s)
        s = RE_STRIKE.sub(r"\1", s)
        s = RE_ITAL.sub(r"\1", s)
        s = RE_ITAL_U.sub(r"\1", s)
        s = RE_ESCAPE.sub(r"\1", s)

        for a, bb in SYMBOLS:
            if a in s:
                s = s.replace(a, bb)

        # Anything markdown-ish that survived all of that gets removed, loudly.
        leftovers = [c for c in "`|*_#~<>" if c in s]
        if leftovers:
            note("removed stray markdown character(s) " + " ".join(sorted(set(leftovers))))
            s = re.sub(r"[`|*_#~<>]", " ", s)

        # Tidy the punctuation the substitutions can leave behind.
        s = re.sub(r"[ \t]+", " ", s)
        s = re.sub(r"\s+([,.;:!?])", r"\1", s)
        s = re.sub(r",\s*,+", ",", s)
        s = re.sub(r",\s*\.", ".", s)
        s = re.sub(r"\.\s*,", ".", s)
        s = re.sub(r"^[\s,;:.]+", "", s)
        s = s.strip()

        if not s:
            continue
        if b.kind == "heading" and s[-1] not in ".?!:":
            s += "."      # a heading has to be spoken as a sentence
        out.append(Block(b.kind, s, b.level))

    if n_img:
        note("dropped image", n_img)
    if n_link:
        note("replaced link with its text", n_link)
    if n_inline:
        note("spoke inline code as words", n_inline)
    if n_url:
        note("replaced bare URL", n_url)

    return out, warnings, meta


def speech_text(blocks: Sequence[Block]) -> str:
    """The blocks as one plain string. Used by --dry-run and the tests."""
    return "\n\n".join(b.text for b in blocks)


# ==========================================================================
# 2. Chunking
# ==========================================================================

# Abbreviations that must not end a sentence. Parked before splitting.
_ABBREV = ["e.g.", "i.e.", "etc.", "vs.", "cf.", "approx.", "Dr.", "Mr.", "Mrs.",
           "Ms.", "Prof.", "St.", "No.", "Fig.", "Inc.", "Ltd.", "Jr.", "Sr."]

RE_SENT = re.compile(r"(?<=[.!?])[\"')\]]*\s+")


def split_sentences(text: str) -> list[str]:
    """Split on sentence ends. Decimals and common abbreviations survive."""
    guard = text
    for i, ab in enumerate(_ABBREV):
        guard = guard.replace(ab, f"\x00{i}\x00")
    parts = [p.strip() for p in RE_SENT.split(guard) if p.strip()]
    out = []
    for p in parts:
        for i, ab in enumerate(_ABBREV):
            p = p.replace(f"\x00{i}\x00", ab)
        out.append(p)
    return out


def _hard_split(sentence: str, limit: int) -> list[str]:
    """Last resort for one sentence longer than the limit: clause, then word."""
    pieces: list[str] = []
    for clause in re.split(r"(?<=[,;:])\s+", sentence):
        if not clause.strip():
            continue
        if len(clause) <= limit:
            pieces.append(clause.strip())
            continue
        cur = ""
        for word in clause.split():
            candidate = f"{cur} {word}".strip()
            if len(candidate) > limit and cur:
                pieces.append(cur)
                cur = word
            else:
                cur = candidate
        if cur:
            pieces.append(cur)

    merged: list[str] = []
    for p in pieces:
        if merged and len(merged[-1]) + 1 + len(p) <= limit:
            merged[-1] = f"{merged[-1]} {p}"
        else:
            merged.append(p)
    return merged


def chunk_text(text: str, limit: int) -> list[str]:
    """Pack whole sentences into chunks no longer than `limit` characters.

    Chunk boundaries land on sentence ends whenever a sentence fits at all.
    The only time a chunk ends mid-sentence is when one sentence on its own
    is longer than the limit, and then it is broken at a clause boundary.
    """
    if limit < 40:
        raise PipelineError(
            f"--chunk-chars={limit} is too small to be useful. Use 400 or more; "
            "the default of 1400 is safe on every backend."
        )
    chunks: list[str] = []
    cur = ""
    for sent in split_sentences(text):
        if len(sent) > limit:
            if cur:
                chunks.append(cur)
                cur = ""
            chunks.extend(_hard_split(sent, limit))
            continue
        candidate = f"{cur} {sent}".strip()
        if len(candidate) > limit and cur:
            chunks.append(cur)
            cur = sent
        else:
            cur = candidate
    if cur:
        chunks.append(cur)
    return chunks


@dataclass
class Segment:
    kind: str          # "text" | "pause"
    text: str = ""
    seconds: float = 0.0


def build_segments(blocks: Sequence[Block], chunk_chars: int,
                   pause_para: float, pause_head: float,
                   pause_chunk: float = 0.18) -> list[Segment]:
    """Blocks -> a flat list of things to synthesise and silences to insert."""
    segs: list[Segment] = []
    for i, b in enumerate(blocks):
        if segs:
            gap = pause_head if b.kind == "heading" else pause_para
            segs.append(Segment("pause", seconds=gap))
        parts = chunk_text(b.text, chunk_chars)
        for j, part in enumerate(parts):
            if j:
                segs.append(Segment("pause", seconds=pause_chunk))
            segs.append(Segment("text", text=part))
        if b.kind == "heading" and i + 1 < len(blocks):
            segs.append(Segment("pause", seconds=pause_head * 0.6))
    # Trim a leading pause, and leave a breath at the end.
    while segs and segs[0].kind == "pause":
        segs.pop(0)
    if segs:
        segs.append(Segment("pause", seconds=0.6))
    return segs


# ==========================================================================
# 3. Audio assembly (ffmpeg, with a pure-python WAV fallback)
# ==========================================================================

def have(cmd: str) -> str | None:
    return shutil.which(cmd)


def run(cmd: Sequence[str], *, stdin_text: str | None = None,
        timeout: int = 900) -> subprocess.CompletedProcess:
    return subprocess.run(
        list(cmd),
        input=stdin_text.encode("utf-8") if stdin_text is not None else None,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout,
    )


def probe_duration(path: Path) -> float:
    """Length of an audio file in seconds. ffprobe if present, else the header."""
    ffprobe = have("ffprobe")
    if ffprobe:
        p = run([ffprobe, "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=nw=1:nk=1", str(path)], timeout=60)
        if p.returncode == 0:
            try:
                return float(p.stdout.decode().strip())
            except ValueError:
                pass
    if path.suffix.lower() == ".wav":
        try:
            with wave.open(str(path), "rb") as w:
                return w.getnframes() / float(w.getframerate())
        except Exception:
            pass
    return 0.0


def wav_params(path: Path) -> tuple[int, int, int] | None:
    """(channels, sample width in bytes, frame rate) of a WAV file, or None."""
    try:
        with wave.open(str(path), "rb") as w:
            return w.getnchannels(), w.getsampwidth(), w.getframerate()
    except Exception:
        return None


def make_silence(seconds: float, out: Path, fmt: str, rate: int = 24000,
                 channels: int = 1, width: int = 2) -> Path:
    """A file of pure silence, used as the gap between paragraphs.

    The sample rate, channel count and sample width must match the speech
    chunks it will be spliced between, otherwise a WAV join has nothing it can
    do but fail. Backends differ: edge-tts gives 24 kHz, Windows SAPI gives
    22.05 kHz, so the caller passes in what it actually got.
    """
    if fmt == "wav" or not have("ffmpeg"):
        frames = int(seconds * rate)
        with wave.open(str(out.with_suffix(".wav")), "wb") as w:
            w.setnchannels(channels)
            w.setsampwidth(width)
            w.setframerate(rate)
            w.writeframes(b"\x00" * (width * channels) * frames)
        return out.with_suffix(".wav")
    p = run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
             "-f", "lavfi", "-i", f"anullsrc=r={rate}:cl=mono",
             "-t", f"{seconds:.3f}", "-c:a", "libmp3lame", "-b:a", "64k",
             str(out)])
    if p.returncode != 0:
        raise PipelineError("ffmpeg could not create a silence file.\n"
                            + p.stderr.decode(errors="replace")[-600:])
    return out


def _concat_wav_pure_python(parts: Sequence[Path], out: Path) -> None:
    """Stitch WAV files with the standard library. No ffmpeg required."""
    params = None
    with wave.open(str(out), "wb") as w:
        for p in parts:
            with wave.open(str(p), "rb") as r:
                if params is None:
                    params = r.getparams()
                    w.setnchannels(params.nchannels)
                    w.setsampwidth(params.sampwidth)
                    w.setframerate(params.framerate)
                elif (r.getnchannels(), r.getsampwidth(), r.getframerate()) != \
                     (params.nchannels, params.sampwidth, params.framerate):
                    raise PipelineError(
                        f"The audio chunks disagree on format, so they cannot be "
                        f"joined without resampling.\n"
                        f"  {parts[0].name}: {params.nchannels} ch, "
                        f"{params.sampwidth * 8}-bit, {params.framerate} Hz\n"
                        f"  {p.name}: {r.getnchannels()} ch, "
                        f"{r.getsampwidth() * 8}-bit, {r.getframerate()} Hz\n"
                        "  Install ffmpeg, which can resample on the fly:\n"
                        + FFMPEG_HINT)
                w.writeframes(r.readframes(r.getnframes()))
    if params is None:
        raise PipelineError("Nothing to concatenate: no audio chunks were produced.")


def concat_audio(parts: Sequence[Path], out: Path, fmt: str, rate: int = 24000) -> None:
    """Join the chunk files into one track.

    Tries the ffmpeg concat demuxer, falls back to the concat filter (which
    copes with chunks that disagree about sample rate), and falls back again
    to a pure-python WAV join when ffmpeg is not installed at all.
    """
    parts = [p for p in parts if p.exists() and p.stat().st_size > 0]
    if not parts:
        raise PipelineError("Nothing to concatenate: no audio chunks were produced.")
    out.parent.mkdir(parents=True, exist_ok=True)

    if not have("ffmpeg"):
        if fmt == "wav" and all(p.suffix.lower() == ".wav" for p in parts):
            _concat_wav_pure_python(parts, out)
            return
        raise PipelineError(
            "ffmpeg is not on PATH, so MP3 output is not possible.\n" + FFMPEG_HINT)

    codec = ["-c:a", "libmp3lame", "-b:a", "64k"] if fmt == "mp3" \
        else ["-c:a", "pcm_s16le"]

    listing = out.parent / (out.stem + ".concat.txt")
    with listing.open("w", encoding="utf-8") as fh:
        for p in parts:
            fh.write("file '" + str(p.resolve()).replace("'", r"'\''") + "'\n")
    p = run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
             "-f", "concat", "-safe", "0", "-i", str(listing),
             "-ar", str(rate), "-ac", "1", *codec, str(out)])
    listing.unlink(missing_ok=True)
    if p.returncode == 0 and out.exists() and out.stat().st_size > 0:
        return

    # Fallback: the concat filter, which re-decodes every input independently.
    args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]
    for src in parts:
        args += ["-i", str(src)]
    graph = "".join(f"[{i}:a]" for i in range(len(parts)))
    graph += f"concat=n={len(parts)}:v=0:a=1[a]"
    args += ["-filter_complex", graph, "-map", "[a]",
             "-ar", str(rate), "-ac", "1", *codec, str(out)]
    p2 = run(args, timeout=1800)
    if p2.returncode != 0:
        raise PipelineError(
            "ffmpeg could not join the audio chunks. Both the concat demuxer and "
            "the concat filter failed. Re-run with --keep-chunks and try joining "
            "them by hand to see which chunk is bad.\n"
            + p2.stderr.decode(errors="replace")[-800:])


# ==========================================================================
# 4. Backends
# ==========================================================================

def norm_rate(value: str) -> str:
    """'-10%', '10', '+10%' -> '+10%' / '-10%'. edge-tts is fussy about this."""
    v = str(value).strip().replace(" ", "")
    if not v:
        return "+0%"
    if not v.endswith("%"):
        v += "%"
    if v[0] not in "+-":
        v = "+" + v
    if not re.fullmatch(r"[+-]\d{1,3}%", v):
        raise PipelineError(
            f"--rate {value!r} is not a valid speed. Use something like "
            "'+10%' to speed up or '-10%' to slow down.")
    return v


def norm_pitch(value: str) -> str:
    v = str(value).strip().replace(" ", "")
    if not v:
        return "+0Hz"
    if v.lower().endswith("hz"):
        v = v[:-2]
    if v and v[0] not in "+-":
        v = "+" + v
    if not re.fullmatch(r"[+-]\d{1,3}", v or ""):
        raise PipelineError(
            f"--pitch {value!r} is not a valid pitch. Use something like "
            "'+5Hz' or '-5Hz'.")
    return v + "Hz"


def rate_to_multiplier(rate: str) -> float:
    return 1.0 + int(norm_rate(rate).rstrip("%")) / 100.0


class Backend:
    name = "?"
    ext = "wav"

    def __init__(self, voice: str, rate: str, pitch: str):
        self.voice = voice or DEFAULT_VOICE[self.name]
        self.rate = rate
        self.pitch = pitch

    @classmethod
    def available(cls) -> bool:
        raise NotImplementedError

    def synth(self, text: str, out: Path) -> None:
        raise NotImplementedError

    @property
    def parallel_safe(self) -> bool:
        return True

    def describe(self) -> str:
        return f"{self.name} / voice {self.voice} / rate {self.rate} / pitch {self.pitch}"


class EdgeBackend(Backend):
    name = "edge"
    ext = "mp3"

    @staticmethod
    def _cmd() -> list[str] | None:
        exe = have("edge-tts") or have("edge_tts")
        if exe:
            return [exe]
        try:
            import edge_tts  # noqa: F401
            return [sys.executable, "-m", "edge_tts"]
        except Exception:
            return None

    @classmethod
    def available(cls) -> bool:
        return cls._cmd() is not None

    def synth(self, text: str, out: Path) -> None:
        cmd = self._cmd()
        if cmd is None:
            raise PipelineError("edge-tts is not installed. Run: pip install edge-tts")
        # --file avoids every quoting problem a long paragraph can create.
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False,
                                         encoding="utf-8") as fh:
            fh.write(text)
            tmp = Path(fh.name)
        try:
            last = None
            for attempt in range(3):
                p = run(cmd + ["--voice", self.voice,
                               f"--rate={norm_rate(self.rate)}",
                               f"--pitch={norm_pitch(self.pitch)}",
                               "--file", str(tmp),
                               "--write-media", str(out)], timeout=300)
                if p.returncode == 0 and out.exists() and out.stat().st_size > 512:
                    return
                last = p
                time.sleep(1.5 * (attempt + 1))
            err = (last.stderr.decode(errors="replace") if last else "")[-600:]
            raise PipelineError(
                "edge-tts failed after three attempts.\n"
                f"  voice: {self.voice}\n"
                "  Check that you have internet access, that the voice name is "
                "valid (run --list-voices), and that no proxy is blocking "
                "speech.platform.bing.com. If you have no internet, use "
                "--backend kokoro or --backend piper.\n" + err)
        finally:
            tmp.unlink(missing_ok=True)


class KokoroBackend(Backend):
    name = "kokoro"
    ext = "wav"
    _pipeline = None

    @classmethod
    def available(cls) -> bool:
        try:
            import importlib.util
            return importlib.util.find_spec("kokoro") is not None
        except Exception:
            return False

    @property
    def parallel_safe(self) -> bool:
        return False        # one torch model, one thread

    def _pipe(self):
        if KokoroBackend._pipeline is None:
            try:
                from kokoro import KPipeline
            except Exception as exc:
                raise PipelineError(
                    "kokoro is not importable. Run: pip install kokoro soundfile\n"
                    "On Linux it also wants the espeak-ng phonemiser: "
                    "sudo apt install espeak-ng\n"
                    f"  import error: {exc}")
            lang = "b" if self.voice.startswith(("b",)) else "a"
            KokoroBackend._pipeline = KPipeline(lang_code=lang)
        return KokoroBackend._pipeline

    def synth(self, text: str, out: Path) -> None:
        import numpy as np
        pipe = self._pipe()
        speed = rate_to_multiplier(self.rate)
        pieces = []
        for item in pipe(text, voice=self.voice, speed=speed):
            audio = item[2] if isinstance(item, (tuple, list)) else item.audio
            arr = np.asarray(audio, dtype="float32").reshape(-1)
            pieces.append(arr)
        if not pieces:
            raise PipelineError(
                "kokoro produced no audio for a chunk. Try a shorter "
                "--chunk-chars, for example 600.")
        data = np.concatenate(pieces)
        pcm = (np.clip(data, -1.0, 1.0) * 32767.0).astype("<i2")
        with wave.open(str(out), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(24000)
            w.writeframes(pcm.tobytes())


class PiperBackend(Backend):
    name = "piper"
    ext = "wav"

    @staticmethod
    def _cmd() -> list[str] | None:
        exe = have("piper")
        if exe:
            return [exe]
        try:
            import importlib.util
            if importlib.util.find_spec("piper") is not None:
                return [sys.executable, "-m", "piper"]
        except Exception:
            pass
        return None

    @classmethod
    def available(cls) -> bool:
        return cls._cmd() is not None

    def synth(self, text: str, out: Path) -> None:
        cmd = self._cmd()
        if cmd is None:
            raise PipelineError("piper is not installed. Run: pip install piper-tts")
        length_scale = 1.0 / max(0.25, rate_to_multiplier(self.rate))
        p = run(cmd + ["--model", self.voice,
                       "--length-scale", f"{length_scale:.3f}",
                       "--output-file", str(out)], stdin_text=text, timeout=600)
        if p.returncode != 0 or not out.exists() or out.stat().st_size == 0:
            raise PipelineError(
                "piper failed.\n"
                f"  model: {self.voice}\n"
                "  Piper needs the voice model on disk. Either pass a path to a "
                "'.onnx' file with --voice, or let piper download a named voice "
                "(it needs internet the first time). See --list-voices.\n"
                + p.stderr.decode(errors="replace")[-600:])


class EspeakBackend(Backend):
    name = "espeak"
    ext = "wav"

    @staticmethod
    def _exe() -> str | None:
        return have("espeak-ng") or have("espeak")

    @classmethod
    def available(cls) -> bool:
        return cls._exe() is not None

    def synth(self, text: str, out: Path) -> None:
        exe = self._exe()
        if exe is None:
            raise PipelineError("espeak-ng is not installed. Run: sudo apt install espeak-ng")
        wpm = max(80, min(400, int(165 * rate_to_multiplier(self.rate))))
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False,
                                         encoding="utf-8") as fh:
            fh.write(text)
            tmp = Path(fh.name)
        try:
            p = run([exe, "-v", self.voice, "-s", str(wpm),
                     "-f", str(tmp), "-w", str(out)], timeout=300)
            if p.returncode != 0 or not out.exists() or out.stat().st_size == 0:
                raise PipelineError(
                    "espeak-ng failed.\n"
                    + p.stderr.decode(errors="replace")[-400:])
        finally:
            tmp.unlink(missing_ok=True)


BACKEND_CLASSES: dict[str, type[Backend]] = {
    "edge": EdgeBackend, "kokoro": KokoroBackend,
    "piper": PiperBackend, "espeak": EspeakBackend,
}


def choose_backend(requested: str | None, voice: str | None,
                   rate: str, pitch: str, quiet_probe: bool = False) -> Backend:
    if requested:
        cls = BACKEND_CLASSES[requested]
        if not cls.available():
            raise PipelineError(
                f"You asked for the {requested} backend but it is not installed.\n"
                f"  Install it with: {INSTALL_HINT[requested]}\n"
                f"  Or drop --backend and let the script pick whatever is available.")
        if requested == "espeak":
            warn("Using espeak-ng. It is intelligible but it sounds like 1998. "
                 "For listenable audio: pip install edge-tts")
        return cls(voice or DEFAULT_VOICE[requested], rate, pitch)

    for name in AUTO_ORDER:
        cls = BACKEND_CLASSES[name]
        if cls.available():
            if name == "espeak":
                warn("Falling back to espeak-ng, because nothing better is "
                     "installed. It is intelligible but it sounds like 1998.\n"
                     "    For good audio, stop and run:  pip install edge-tts")
            elif not quiet_probe and name != "edge":
                say(f"  edge-tts not found, using {name} instead "
                    f"(pip install edge-tts for better voices).")
            return cls(voice or DEFAULT_VOICE[name], rate, pitch)

    raise PipelineError(
        "No text-to-speech backend is installed. Pick one:\n"
        "  pip install edge-tts        best quality, needs internet   <-- do this\n"
        "  pip install kokoro          fully offline, ~350 MB download\n"
        "  pip install piper-tts       offline, small and fast, robotic\n"
        "  sudo apt install espeak-ng  last resort, sounds like 1998")


def list_voices(backend_name: str | None) -> int:
    names = [backend_name] if backend_name else list(BACKENDS)
    for name in names:
        cls = BACKEND_CLASSES[name]
        state = "installed" if cls.available() else f"not installed ({INSTALL_HINT[name]})"
        say(f"\n=== {name}  [{state}] ===")
        for v, desc in CURATED_VOICES[name]:
            say(f"  {v:38s} {desc}")
        if name == "edge" and cls.available():
            cmd = EdgeBackend._cmd()
            p = run(cmd + ["--list-voices"], timeout=90)
            if p.returncode == 0:
                out = p.stdout.decode(errors="replace")
                english = sorted({m for m in re.findall(r"\ben-[A-Z]{2}-\w+Neural\b", out)})
                if english:
                    say(f"\n  All {len(english)} English voices available right now:")
                    say(textwrap.fill(", ".join(english), 96,
                                      initial_indent="    ", subsequent_indent="    "))
            else:
                say("  (could not reach Microsoft to list the full set; "
                    "the curated list above is still valid)")
        elif name == "piper":
            say("  Full catalogue: https://huggingface.co/rhasspy/piper-voices")
            say("  You can also pass a path to a downloaded .onnx file.")
    return 0


# ==========================================================================
# 5. Lessons, playlist, index
# ==========================================================================

@dataclass
class Lesson:
    number: str
    slug: str
    path: Path
    title: str = ""
    blocks: list[Block] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    words: int = 0
    chars: int = 0
    duration: float = 0.0
    size: int = 0
    out: Path | None = None
    status: str = "pending"

    @property
    def stem(self) -> str:
        return f"{self.number}_{self.slug}"


def discover_lessons(lecture_dir: Path, only: Sequence[str] | None) -> list[Lesson]:
    if not lecture_dir.is_dir():
        raise PipelineError(
            f"No lecture directory at {lecture_dir}\n"
            "  Pass --lectures /path/to/lectures, or run this script from the "
            "course checkout so it can find lectures/ next to scripts/.")
    wanted = {str(x).zfill(2) for x in only} if only else None
    found: list[Lesson] = []
    for p in sorted(lecture_dir.glob("*.md")):
        m = LESSON_RE.match(p.name)
        if not m:
            continue
        num, slug = m.group(1), m.group(2)
        if wanted and num not in wanted:
            continue
        found.append(Lesson(num, slug, p))
    if not found:
        if wanted:
            have_nums = sorted(m.group(1) for m in
                               (LESSON_RE.match(p.name) for p in lecture_dir.glob("*.md")) if m)
            raise PipelineError(
                f"No lecture matched --lesson {', '.join(sorted(wanted))}.\n"
                f"  Available lessons: {', '.join(have_nums) or '(none)'}")
        raise PipelineError(
            f"No lecture scripts found in {lecture_dir}\n"
            "  Files must be named like 03_reasoning_captioning.md")
    return found


def load_lesson(lesson: Lesson, chunk_chars: int) -> None:
    text = lesson.path.read_text(encoding="utf-8")
    blocks, warns, meta = markdown_to_speech(text, lesson.stem)
    lesson.blocks = blocks
    lesson.warnings = warns
    lesson.title = meta.get("title") or (blocks[0].text.rstrip(".") if blocks else lesson.slug)
    joined = speech_text(blocks)
    lesson.words = len(joined.split())
    lesson.chars = len(joined)


# Some filesystems (FAT32, OneDrive and other FUSE mounts, some network shares)
# record modification times only to the nearest second. A script edited in the
# same second its audio was written can therefore look fractionally older than
# it is. We skip only when the audio is at least this many seconds newer, which
# errs towards rebuilding. Rebuilding costs minutes; shipping stale audio costs
# a walk spent listening to the wrong thing.
MTIME_SLACK = 1.0


def needs_rebuild(lesson: Lesson, out: Path, force: bool) -> bool:
    if force or not out.exists() or out.stat().st_size == 0:
        return True
    return out.stat().st_mtime < lesson.path.stat().st_mtime + MTIME_SLACK


def write_playlist(lessons: Sequence[Lesson], out_dir: Path) -> Path:
    """An extended M3U with durations and titles, using relative paths."""
    path = out_dir / "playlist.m3u"
    lines = ["#EXTM3U"]
    for L in lessons:
        if not L.out or not L.out.exists():
            continue
        secs = int(round(L.duration)) or -1
        lines.append(f"#EXTINF:{secs},Cosmos 3 - Lesson {L.number} - {L.title}")
        lines.append(L.out.name)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


INDEX_CSS = """
:root{color-scheme:light dark}
*{box-sizing:border-box}
body{margin:0;padding:2rem 1rem 4rem;font:16px/1.55 -apple-system,Segoe UI,Roboto,
  Helvetica,Arial,sans-serif;background:#11131a;color:#e7e9ee}
.wrap{max-width:760px;margin:0 auto}
h1{font-size:1.5rem;margin:0 0 .25rem}
.sub{color:#98a0b3;margin:0 0 1.5rem;font-size:.92rem}
.player{position:sticky;top:0;background:#171a23;border:1px solid #262b38;
  border-radius:10px;padding:.9rem 1rem;margin-bottom:1.25rem;z-index:5}
.now{font-weight:600;margin-bottom:.55rem;font-size:.95rem}
audio{width:100%}
.speed{margin-top:.6rem;font-size:.85rem;color:#98a0b3}
.speed button{background:#222736;color:#cfd4e0;border:1px solid #333a4c;
  border-radius:5px;padding:.15rem .5rem;margin-right:.3rem;cursor:pointer;font:inherit;
  font-size:.82rem}
.speed button[aria-pressed=true]{background:#3b6ef0;border-color:#3b6ef0;color:#fff}
ol{list-style:none;margin:0;padding:0;counter-reset:t}
li{border-bottom:1px solid #222736}
li button{display:flex;gap:.85rem;align-items:baseline;width:100%;text-align:left;
  background:none;border:0;color:inherit;font:inherit;padding:.7rem .4rem;cursor:pointer}
li button:hover{background:#181c26}
li[aria-current=true] button{background:#1b2440;color:#fff}
.num{color:#7d879c;font-variant-numeric:tabular-nums;min-width:2.1em}
.ttl{flex:1}
.dur{color:#7d879c;font-variant-numeric:tabular-nums;font-size:.86rem}
footer{margin-top:2rem;color:#7d879c;font-size:.84rem}
"""

INDEX_JS = """
const items=[...document.querySelectorAll('li')];
const audio=document.getElementById('a');
const now=document.getElementById('now');
let idx=-1;
function play(i,auto){
  if(i<0||i>=items.length)return;
  idx=i;
  items.forEach((li,n)=>li.setAttribute('aria-current',n===i));
  audio.src=items[i].dataset.src;
  now.textContent=items[i].dataset.title;
  audio.playbackRate=rate;
  if(auto!==false)audio.play().catch(()=>{});
  try{localStorage.setItem('cosmos3-track',i)}catch(e){}
}
items.forEach((li,i)=>li.querySelector('button').addEventListener('click',()=>play(i)));
audio.addEventListener('ended',()=>play(idx+1));
let rate=1;
document.querySelectorAll('.speed button').forEach(b=>{
  b.addEventListener('click',()=>{
    rate=parseFloat(b.dataset.rate);audio.playbackRate=rate;
    document.querySelectorAll('.speed button').forEach(x=>
      x.setAttribute('aria-pressed',x===b));
  });
});
document.addEventListener('keydown',e=>{
  if(e.target.tagName==='INPUT')return;
  if(e.key===' '){e.preventDefault();audio.paused?audio.play():audio.pause();}
  if(e.key==='ArrowRight')audio.currentTime+=15;
  if(e.key==='ArrowLeft')audio.currentTime-=15;
  if(e.key==='n')play(idx+1);
  if(e.key==='p')play(idx-1);
});
let saved=0;try{saved=parseInt(localStorage.getItem('cosmos3-track')||'0',10)}catch(e){}
play(isNaN(saved)?0:saved,false);
"""


def write_index(lessons: Sequence[Lesson], out_dir: Path, backend: str, voice: str) -> Path:
    path = out_dir / "index.html"
    playable = [L for L in lessons if L.out and L.out.exists()]
    total = sum(L.duration for L in playable)
    rows = []
    for L in playable:
        rows.append(
            '    <li data-src="{src}" data-title="Lesson {n} — {t}">'
            '<button type="button"><span class="num">{n}</span>'
            '<span class="ttl">{t}</span>'
            '<span class="dur">{d}</span></button></li>'.format(
                src=html.escape(L.out.name, quote=True),
                n=html.escape(L.number),
                t=html.escape(L.title),
                d=human_time(L.duration) if L.duration else "&mdash;"))
    doc = f"""<!DOCTYPE html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cosmos 3 on one H100 — audio lectures</title>
<style>{INDEX_CSS}</style>
<div class="wrap">
  <h1>Cosmos 3 on one H100 — audio lectures</h1>
  <p class="sub">{len(playable)} lectures &middot; {human_time(total)} total &middot;
     generated with {html.escape(backend)} / {html.escape(voice)}</p>
  <div class="player">
    <div class="now" id="now">&nbsp;</div>
    <audio id="a" controls preload="none"></audio>
    <div class="speed">Speed:
      <button data-rate="1" aria-pressed="true">1x</button>
      <button data-rate="1.25" aria-pressed="false">1.25x</button>
      <button data-rate="1.5" aria-pressed="false">1.5x</button>
      <button data-rate="1.75" aria-pressed="false">1.75x</button>
      <button data-rate="2" aria-pressed="false">2x</button>
    </div>
  </div>
  <ol>
{chr(10).join(rows)}
  </ol>
  <footer>Space plays and pauses. Left and right arrows skip fifteen seconds.
    N and P change track. Your place is remembered in this browser.</footer>
</div>
<script>{INDEX_JS}</script>
"""
    path.write_text(doc, encoding="utf-8")
    return path


# ==========================================================================
# 6. Synthesis of one lesson
# ==========================================================================

def synth_lesson(lesson: Lesson, backend: Backend, out: Path, fmt: str,
                 chunk_chars: int, pause_para: float, pause_head: float,
                 jobs: int, keep_chunks: bool, work_root: Path) -> None:
    segs = build_segments(lesson.blocks, chunk_chars, pause_para, pause_head)
    texts = [s for s in segs if s.kind == "text"]
    work = work_root / lesson.stem
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)

    part_ext = backend.ext
    produced: dict[int, Path] = {}
    errors: list[tuple[int, Exception]] = []

    def do(i: int, seg: Segment) -> None:
        target = work / f"{i:04d}.{part_ext}"
        try:
            backend.synth(seg.text, target)
            produced[i] = target
        except Exception as exc:          # noqa: BLE001 - re-raised below
            errors.append((i, exc))

    indexed = [(i, s) for i, s in enumerate(segs) if s.kind == "text"]
    n_workers = jobs if backend.parallel_safe else 1
    if n_workers > 1 and len(indexed) > 1:
        with concurrent.futures.ThreadPoolExecutor(max_workers=n_workers) as ex:
            list(ex.map(lambda t: do(*t), indexed))
    else:
        for i, s in indexed:
            do(i, s)

    if errors:
        i, exc = errors[0]
        raise PipelineError(
            f"{lesson.stem}: {len(errors)} of {len(texts)} chunks failed to "
            f"synthesise.\n  First failure was chunk {i}.\n  {exc}")

    # Match the silence to whatever the backend actually produced, so the gaps
    # can be spliced in even when ffmpeg is not available to resample.
    ch, wd, rate = 1, 2, 24000
    if part_ext == "wav" and produced:
        p = wav_params(produced[min(produced)])
        if p:
            ch, wd, rate = p

    # Silence files, one per distinct gap length, reused across the lesson.
    sil_cache: dict[float, Path] = {}
    ordered: list[Path] = []
    sil_ext = "mp3" if part_ext == "mp3" else "wav"
    for i, s in enumerate(segs):
        if s.kind == "text":
            ordered.append(produced[i])
        else:
            key = round(s.seconds, 2)
            if key not in sil_cache:
                sil_cache[key] = make_silence(
                    key, work / f"sil_{int(key * 100):04d}.{sil_ext}",
                    sil_ext, rate=rate, channels=ch, width=wd)
            ordered.append(sil_cache[key])

    concat_audio(ordered, out, fmt)
    lesson.duration = probe_duration(out)
    lesson.size = out.stat().st_size
    if not keep_chunks:
        shutil.rmtree(work, ignore_errors=True)


# ==========================================================================
# 7. Self-test
# ==========================================================================

SELF_TEST_MD = """---
title: "Fixture"
lesson: "99"
---

# Lesson 99 — A fixture with every construct

This paragraph has **bold**, *italic*, __also bold__, _also italic_,
`inline_code_here`, a [link](https://example.com/x), and ~~strikethrough~~.

## A heading with no full stop

> A block quote line.
> A second one.

- first bullet
- second bullet
1. numbered one
2. numbered two

| a | b |
|---|---|
| 1 | 2 |

```python
raise SystemExit("this must never be spoken")
```

    indented_code_line = True

An image ![alt text](x.png) and a bare URL https://nvidia.com/cosmos here.
An em-dash — like that — and an ellipsis… and 8 × 80 GB ≥ 600.

---

Final paragraph.
"""


def self_test(tmpdir: Path) -> int:
    failures: list[str] = []

    def check(name: str, cond: bool, detail: str = "") -> None:
        say(f"  {'PASS' if cond else 'FAIL'}  {name}" + (f"  {detail}" if detail and not cond else ""))
        if not cond:
            failures.append(name)

    say("\n[1] markdown -> speech on a fixture containing every construct")
    blocks, warns, meta = markdown_to_speech(SELF_TEST_MD, "99_fixture")
    spoken = speech_text(blocks)
    check("front matter stripped", "title:" not in spoken and meta.get("lesson") == "99")
    check("code block dropped", "SystemExit" not in spoken and "raise" not in spoken)
    check("indented code dropped", "indented_code_line" not in spoken)
    check("table dropped", "---" not in spoken and not re.search(r"\|", spoken))
    check("no markdown characters survive", not re.search(r"[`|*_#~<>]", spoken),
          repr(re.findall(r"[`|*_#~<>]", spoken)))
    check("link becomes its text", "link" in spoken and "example.com" not in spoken)
    check("bare URL replaced", "nvidia.com" not in spoken)
    check("image dropped", "alt text" not in spoken and "x.png" not in spoken)
    check("bold/italic markers gone", "bold" in spoken and "**" not in spoken)
    check("inline code spoken as words", "inline code here" in spoken)
    check("em-dash and ellipsis normalised", "—" not in spoken and "…" not in spoken)
    check("symbols normalised", "8 by 80 GB at least 600" in spoken, spoken[-200:])
    check("bullets kept as sentences", "first bullet" in spoken and "numbered one" in spoken)
    check("heading gets a full stop",
          any(b.kind == "heading" and b.text.endswith(".") for b in blocks))
    check("warnings were raised", len(warns) >= 5, str(warns))
    check("warnings name the lesson", all(w.startswith("99_fixture:") for w in warns))

    say("\n[2] chunking")
    long_para = " ".join(f"This is sentence number {i} and it says something." for i in range(200))
    for limit in (200, 400, 1400):
        ch = chunk_text(long_para, limit)
        check(f"limit {limit}: no chunk over limit", all(len(c) <= limit for c in ch),
              f"max={max(len(c) for c in ch)}")
        check(f"limit {limit}: boundaries on sentence ends",
              all(c.rstrip().endswith((".", "!", "?")) for c in ch))
        check(f"limit {limit}: nothing lost",
              len(" ".join(ch).split()) == len(long_para.split()))
    monster = "word " * 3000
    ch = chunk_text(monster.strip(), 500)
    check("one absurdly long sentence still respects the limit",
          all(len(c) <= 500 for c in ch), f"max={max(len(c) for c in ch)}")
    check("decimals do not split a sentence",
          split_sentences("Version 1.2.2 is current. It is fine.")
          == ["Version 1.2.2 is current.", "It is fine."])
    check("abbreviations do not split a sentence",
          split_sentences("Use e.g. this one. Then stop.")
          == ["Use e.g. this one.", "Then stop."])
    check("a sentence ending in a quote still splits",
          len(split_sentences('He said "no." Then he left.')) == 2)
    check("short paragraph stays one chunk",
          chunk_text("Version 1.2.2 is current. It is fine.", 4000)
          == ["Version 1.2.2 is current. It is fine."])

    say("\n[3] segments and pauses")
    segs = build_segments(blocks, 1400, 0.45, 0.9)
    check("segments start with speech", segs[0].kind == "text")
    check("segments end with a pause", segs[-1].kind == "pause")
    check("pauses exist between paragraphs",
          sum(1 for s in segs if s.kind == "pause") >= 3)

    say("\n[4] audio assembly (real ffmpeg, tones standing in for speech)")
    if not have("ffmpeg"):
        say("  SKIP  ffmpeg is not installed, so assembly cannot be tested here.")
    else:
        parts = []
        for i, (freq, dur) in enumerate([(440, 1.0), (660, 0.75), (880, 1.25)]):
            p = tmpdir / f"tone{i}.mp3"
            r = run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                     "-f", "lavfi", "-i", f"sine=frequency={freq}:sample_rate=24000",
                     "-t", str(dur), "-c:a", "libmp3lame", "-b:a", "64k", str(p)])
            check(f"tone {i} generated", r.returncode == 0 and p.exists())
            parts.append(p)
            sil = make_silence(0.5, tmpdir / f"sil{i}.mp3", "mp3")
            parts.append(sil)
        out = tmpdir / "assembled.mp3"
        concat_audio(parts, out, "mp3")
        expected = 1.0 + 0.75 + 1.25 + 0.5 * 3
        got = probe_duration(out)
        check("assembled file exists and is non-trivial", out.exists() and out.stat().st_size > 2000,
              f"{out.stat().st_size if out.exists() else 0} bytes")
        check(f"duration is about {expected:.2f}s", abs(got - expected) < 0.35, f"got {got:.2f}s")
        p = run(["ffprobe", "-v", "error", "-select_streams", "a:0",
                 "-show_entries", "stream=codec_name,channels,sample_rate",
                 "-of", "json", str(out)]) if have("ffprobe") else None
        if p is not None and p.returncode == 0:
            info = json.loads(p.stdout.decode())["streams"][0]
            check("output is mono mp3 at 24 kHz",
                  info["codec_name"] == "mp3" and int(info["channels"]) == 1
                  and int(info["sample_rate"]) == 24000, json.dumps(info))

    say("\n[5] pure-python WAV join (the no-ffmpeg path, e.g. bare Windows)")
    wparts = []
    for i, dur in enumerate([0.4, 0.6]):
        wparts.append(make_silence(dur, tmpdir / f"w{i}.wav", "wav"))
    wout = tmpdir / "joined.wav"
    _concat_wav_pure_python(wparts, wout)
    with wave.open(str(wout)) as w:
        check("wav join duration is 1.0s",
              abs(w.getnframes() / w.getframerate() - 1.0) < 0.05)
    # Windows SAPI emits 22.05 kHz, not 24 kHz. Silence must follow the speech,
    # or the join has nothing it can do but fail.
    speech = tmpdir / "speech22k.wav"
    with wave.open(str(speech), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(22050)
        w.writeframes(b"\x01\x00" * 22050)
    p = wav_params(speech)
    check("wav_params reads the header", p == (1, 2, 22050), str(p))
    sil22 = make_silence(0.5, tmpdir / "s22.wav", "wav",
                         rate=p[2], channels=p[0], width=p[1])
    check("silence matches the backend's sample rate", wav_params(sil22) == p,
          str(wav_params(sil22)))
    mixed = tmpdir / "mixed.wav"
    _concat_wav_pure_python([speech, sil22, speech], mixed)
    with wave.open(str(mixed)) as w:
        check("22.05 kHz speech and silence join to 2.5s",
              abs(w.getnframes() / w.getframerate() - 2.5) < 0.02
              and w.getframerate() == 22050)
    # And a genuine mismatch must fail with a message that says what to do.
    bad24 = make_silence(0.5, tmpdir / "s24.wav", "wav", rate=24000)
    try:
        _concat_wav_pure_python([speech, bad24], tmpdir / "nope.wav")
        check("mismatched rates are rejected", False)
    except PipelineError as exc:
        check("mismatched rates are rejected with an actionable message",
              "22050 Hz" in str(exc) and "24000 Hz" in str(exc) and "ffmpeg" in str(exc))

    say("\n[6] playlist and index with stand-in audio")
    adir = tmpdir / "audio"
    adir.mkdir(exist_ok=True)
    fake: list[Lesson] = []
    for n, slug, title, dur in [("00", "alpha", "Alpha", 731.0),
                                ("01", "beta", "Beta", 812.5),
                                ("02", "gamma", "Gamma & <quotes>", 799.0)]:
        f = adir / f"{n}_{slug}.mp3"
        f.write_bytes(b"\0" * 4096)
        L = Lesson(n, slug, tmpdir / f"{n}_{slug}.md", title=title)
        L.out, L.duration, L.size = f, dur, 4096
        fake.append(L)
    pl = write_playlist(fake, adir)
    ptxt = pl.read_text(encoding="utf-8")
    check("playlist starts with #EXTM3U", ptxt.startswith("#EXTM3U"))
    check("playlist has one EXTINF per track", ptxt.count("#EXTINF:") == 3)
    check("playlist uses relative names", "00_alpha.mp3" in ptxt and str(adir) not in ptxt)
    check("playlist is in course order",
          ptxt.index("00_alpha") < ptxt.index("01_beta") < ptxt.index("02_gamma"))
    check("playlist carries durations", "#EXTINF:731," in ptxt)
    ix = write_index(fake, adir, "edge", "en-US-AndrewNeural")
    itxt = ix.read_text(encoding="utf-8")
    check("index lists every track", itxt.count("<li ") == 3)
    check("index escapes html in titles", "Gamma &amp; &lt;quotes&gt;" in itxt)
    check("index references the audio files", 'data-src="01_beta.mp3"' in itxt)
    check("index reports total time", human_time(731 + 812.5 + 799) in itxt)
    check("index is self-contained", "http://" not in itxt and "https://" not in itxt)

    say("\n[7] resume and skip logic")
    src = tmpdir / "03_demo.md"
    src.write_text("---\ntitle: \"D\"\n---\n\n# D\n\nHello.\n", encoding="utf-8")
    L = Lesson("03", "demo", src)
    out = adir / "03_demo.mp3"
    check("missing output rebuilds", needs_rebuild(L, out, False))
    out.write_bytes(b"\0" * 100)
    os.utime(out, (time.time() + 10, time.time() + 10))
    check("newer output is skipped", not needs_rebuild(L, out, False))
    check("--force rebuilds anyway", needs_rebuild(L, out, True))
    os.utime(src, (time.time() + 60, time.time() + 60))
    check("edited script rebuilds", needs_rebuild(L, out, False))
    out.write_bytes(b"")
    check("empty output rebuilds", needs_rebuild(L, out, False))

    say("\n[8] argument normalisation")
    check("rate '+10%'", norm_rate("+10%") == "+10%")
    check("rate '10'", norm_rate("10") == "+10%")
    check("rate '-5%'", norm_rate("-5%") == "-5%")
    check("pitch '+5Hz'", norm_pitch("+5Hz") == "+5Hz")
    check("pitch '-3'", norm_pitch("-3") == "-3Hz")
    try:
        norm_rate("fast")
        check("bad rate is rejected", False)
    except PipelineError:
        check("bad rate is rejected", True)
    check("rate to multiplier", abs(rate_to_multiplier("-20%") - 0.8) < 1e-9)

    say("")
    if failures:
        say(f"SELF-TEST FAILED: {len(failures)} check(s) failed")
        for f_ in failures:
            say(f"  - {f_}")
        return 1
    say("SELF-TEST PASSED: every check succeeded.")
    return 0


# ==========================================================================
# 8. CLI
# ==========================================================================

EPILOG = """\
examples
  python scripts/make_lecture_audio.py
      Every lesson, best available backend, MP3 into lectures/audio/.

  python scripts/make_lecture_audio.py --lesson 03 --lesson 12
      Just those two.

  python scripts/make_lecture_audio.py --dry-run
      Show the plan, the chunk counts and the estimated running time.
      Touches nothing.

  python scripts/make_lecture_audio.py --backend kokoro --voice am_michael
      Fully offline on the H100 box. Nothing is sent anywhere.

  python scripts/make_lecture_audio.py --voice en-GB-RyanNeural --rate +10%
      A different narrator, ten percent faster.

  python scripts/make_lecture_audio.py --self-test
      Prove the whole pipeline works on this machine before spending an hour.

privacy
  The default backend (edge-tts) sends the text of each chunk to a Microsoft
  speech endpoint over the internet. Use --backend kokoro or --backend piper
  if you would rather nothing left the machine.
"""


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="make_lecture_audio.py",
        description="Turn the Cosmos 3 lecture scripts into MP3 files you can "
                    "listen to on a phone, a laptop or a walk.",
        epilog=EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--lesson", action="append", metavar="NN",
                   help="Lesson number to build, for example 03. Repeatable. "
                        "Default: all of them.")
    p.add_argument("--backend", choices=BACKENDS,
                   help="Force a speech engine. Default: the first of "
                        "edge, kokoro, piper, espeak that is installed.")
    p.add_argument("--voice", help="Voice name for the chosen backend. "
                                   "See --list-voices.")
    p.add_argument("--rate", default="+0%", metavar="PCT",
                   help="Speaking speed, e.g. +10%% or -10%%. Default +0%%.")
    p.add_argument("--pitch", default="+0Hz", metavar="HZ",
                   help="Pitch shift, e.g. +5Hz. edge-tts only. Default +0Hz.")
    p.add_argument("--format", choices=("mp3", "wav"), default="mp3",
                   help="Output format. Default mp3. wav needs no ffmpeg but "
                        "is about ten times bigger.")
    p.add_argument("--out", type=Path, metavar="DIR",
                   help=f"Output directory. Default: {DEFAULT_AUDIO_DIR}")
    p.add_argument("--lectures", type=Path, metavar="DIR",
                   help=f"Where the .md scripts live. Default: {DEFAULT_LECTURE_DIR}")
    p.add_argument("--force", action="store_true",
                   help="Rebuild even if the audio is newer than the script.")
    p.add_argument("--dry-run", action="store_true",
                   help="Print the plan and stop. Writes nothing, synthesises "
                        "nothing, needs no backend.")
    p.add_argument("--list-voices", action="store_true",
                   help="List the voices available for each backend and stop.")
    p.add_argument("--self-test", action="store_true",
                   help="Run the built-in checks on markdown handling, chunking "
                        "and audio assembly, then stop.")
    p.add_argument("--chunk-chars", type=int, default=1400, metavar="N",
                   help="Target maximum characters per synthesis request. "
                        "Default 1400. Lower it if a backend truncates.")
    p.add_argument("--pause", type=float, default=0.45, metavar="SEC",
                   help="Silence between paragraphs, in seconds. Default 0.45.")
    p.add_argument("--pause-heading", type=float, default=0.9, metavar="SEC",
                   help="Silence before a section heading. Default 0.9.")
    p.add_argument("--jobs", type=int, default=4, metavar="N",
                   help="Chunks to synthesise at once. Default 4. Only applies "
                        "to network and subprocess backends.")
    p.add_argument("--keep-chunks", action="store_true",
                   help="Do not delete the per-chunk audio. Useful when a "
                        "single chunk sounds wrong.")
    p.add_argument("--no-playlist", action="store_true",
                   help="Skip writing playlist.m3u and index.html.")
    p.add_argument("--quiet", action="store_true", help="Only print the summary.")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def print_plan(lessons: Sequence[Lesson], out_dir: Path, fmt: str,
               chunk_chars: int, pause: float, pause_head: float,
               force: bool, backend_desc: str) -> None:
    say(f"\nPlan  (backend: {backend_desc})")
    say(f"  scripts  : {lessons[0].path.parent}")
    say(f"  output   : {out_dir}")
    say(f"  format   : {fmt}   chunk limit: {chunk_chars} chars   "
        f"pauses: {pause}s / {pause_head}s\n")
    say(f"  {'lesson':<38}{'words':>7}{'chunks':>8}{'longest':>9}{'est.':>9}  action")
    say("  " + "-" * 80)
    total_words = 0
    total_est = 0.0
    all_warnings: list[str] = []
    for L in lessons:
        segs = build_segments(L.blocks, chunk_chars, pause, pause_head)
        texts = [s.text for s in segs if s.kind == "text"]
        pauses = sum(s.seconds for s in segs if s.kind == "pause")
        longest = max((len(t) for t in texts), default=0)
        est = L.words / 150.0 * 60.0 + pauses      # 150 words per minute
        out = out_dir / f"{L.stem}.{fmt}"
        action = "build" if needs_rebuild(L, out, force) else "skip (up to date)"
        say(f"  {L.stem:<38}{L.words:>7}{len(texts):>8}{longest:>9}"
            f"{human_time(est):>9}  {action}")
        total_words += L.words
        total_est += est
        all_warnings.extend(L.warnings)
    say("  " + "-" * 80)
    say(f"  {'TOTAL':<38}{total_words:>7}{'':>8}{'':>9}{human_time(total_est):>9}")
    if all_warnings:
        say(f"\n  Text conversion notes ({len(all_warnings)}):")
        for w in all_warnings:
            say(f"    - {w}")
    else:
        say("\n  Text conversion: clean. No markdown survived into the spoken text.")


def main(argv: Sequence[str] | None = None) -> int:
    global _QUIET
    args = build_parser().parse_args(argv)
    _QUIET = args.quiet

    try:
        if args.self_test:
            with tempfile.TemporaryDirectory(prefix="cosmos-tts-selftest-") as td:
                return self_test(Path(td))

        if args.list_voices:
            return list_voices(args.backend)

        lecture_dir = (args.lectures or DEFAULT_LECTURE_DIR).resolve()
        out_dir = (args.out or (lecture_dir / "audio")).resolve()
        fmt = args.format
        if args.chunk_chars < 40:
            raise PipelineError("--chunk-chars must be at least 40. Try 1400.")
        if args.jobs < 1:
            raise PipelineError("--jobs must be at least 1.")
        if args.pause < 0 or args.pause_heading < 0:
            raise PipelineError("--pause and --pause-heading must not be negative. "
                                "Use 0 for no gap at all.")
        # Validate these now, so a typo fails in a second rather than an hour in.
        norm_rate(args.rate)
        norm_pitch(args.pitch)

        lessons = discover_lessons(lecture_dir, args.lesson)
        for L in lessons:
            load_lesson(L, args.chunk_chars)

        if args.dry_run:
            print_plan(lessons, out_dir, fmt, args.chunk_chars, args.pause,
                       args.pause_heading, args.force, "none needed for --dry-run")
            say("\nDry run: nothing was written. Drop --dry-run to build the audio.")
            return 0

        backend = choose_backend(args.backend, args.voice, args.rate, args.pitch)
        if fmt == "mp3" and backend.ext == "wav" and not have("ffmpeg"):
            raise PipelineError(
                f"The {backend.name} backend produces WAV and ffmpeg is not "
                "installed, so it cannot be converted to MP3.\n" + FFMPEG_HINT)

        print_plan(lessons, out_dir, fmt, args.chunk_chars, args.pause,
                   args.pause_heading, args.force, backend.describe())

        out_dir.mkdir(parents=True, exist_ok=True)
        work_root = out_dir / ".chunks"
        work_root.mkdir(exist_ok=True)

        say("\nBuilding")
        started = time.time()
        built = skipped = failed = 0
        for L in lessons:
            out = out_dir / f"{L.stem}.{fmt}"
            L.out = out
            if not needs_rebuild(L, out, args.force):
                L.duration = probe_duration(out)
                L.size = out.stat().st_size
                L.status = "skipped"
                skipped += 1
                say(f"  skip   {L.stem:<40} {human_time(L.duration):>9}  "
                    f"{human_size(L.size):>9}")
                continue
            t0 = time.time()
            try:
                synth_lesson(L, backend, out, fmt, args.chunk_chars, args.pause,
                             args.pause_heading, args.jobs, args.keep_chunks, work_root)
                L.status = "built"
                built += 1
                say(f"  built  {L.stem:<40} {human_time(L.duration):>9}  "
                    f"{human_size(L.size):>9}  in {time.time() - t0:.0f}s")
            except PipelineError as exc:
                L.status = "failed"
                failed += 1
                warn(f"{L.stem} failed.\n    {exc}")
                if built == 0 and skipped == 0:
                    raise           # first lesson failed: stop, do not grind on

        if not args.keep_chunks:
            shutil.rmtree(work_root, ignore_errors=True)

        done = [L for L in lessons if L.out and L.out.exists()]
        if done and not args.no_playlist:
            # Always write the playlist over every track present in the folder,
            # not only the ones built this run.
            everything = discover_lessons(lecture_dir, None)
            for L in everything:
                cached = next((x for x in lessons if x.stem == L.stem), None)
                if cached is not None:
                    L.title, L.out = cached.title, cached.out
                    L.duration, L.size = cached.duration, cached.size
                    continue
                cand = out_dir / f"{L.stem}.{fmt}"
                if cand.exists():
                    load_lesson(L, args.chunk_chars)
                    L.out, L.size = cand, cand.stat().st_size
                    L.duration = probe_duration(cand)
            present = [L for L in everything if L.out and L.out.exists()]
            pl = write_playlist(present, out_dir)
            ix = write_index(present, out_dir, backend.name, backend.voice)
            say(f"\n  playlist  {pl}")
            say(f"  index     {ix}")

        total_dur = sum(L.duration for L in done)
        total_size = sum(L.size for L in done)
        say("\nSummary")
        say(f"  built {built}, skipped {skipped}, failed {failed}")
        say(f"  {len(done)} tracks   {human_time(total_dur)} of audio   "
            f"{human_size(total_size)} on disk")
        say(f"  wall clock {human_time(time.time() - started)}")
        say(f"  folder: {out_dir}")
        if failed:
            say("\n  Some lessons failed. Re-run the same command: finished "
                "lessons are skipped, so only the failures are retried.")
            return 1
        return 0

    except PipelineError as exc:
        print(f"\nERROR: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nInterrupted. Re-run the same command to carry on where you "
              "stopped: finished lessons are skipped automatically.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
