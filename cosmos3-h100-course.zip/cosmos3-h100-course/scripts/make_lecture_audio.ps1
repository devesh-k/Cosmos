<#
.SYNOPSIS
    Turn the Cosmos 3 lecture scripts into audio, on Windows, with nothing installed.

.DESCRIPTION
    This is the zero-install path. It uses the speech engine that is already in
    Windows (System.Speech, the SAPI voices behind Narrator) to read each
    lecture script aloud into a WAV file, then converts to MP3 if ffmpeg
    happens to be on PATH.

    Be honest with yourself about the trade: the built-in Microsoft David and
    Zira voices are noticeably robotic. They are fine for a lesson you just
    want to get through, and painful for four hours of listening. If you can
    spare five minutes and 20 MB, run this instead:

        pip install edge-tts
        .\scripts\make_lecture_audio.ps1 -Backend edge

    which hands the job to scripts\make_lecture_audio.py and gives you
    Microsoft's neural voices, which sound close to a person reading.

    Output goes to lectures\audio\ as NN_<slug>.mp3 (or .wav), plus a
    playlist.m3u and an index.html you can open in a browser.

.PARAMETER Lesson
    One or more lesson numbers, for example -Lesson 03 or -Lesson 03,12.
    Default: every lesson.

.PARAMETER Backend
    'sapi'  - the built-in Windows voices. No install, robotic. Default.
    'edge'  - hand off to the Python script and edge-tts. Much better audio.
              Needs 'pip install edge-tts' and an internet connection, and it
              sends the lecture text to a Microsoft speech endpoint.

.PARAMETER Voice
    Voice name. Run with -ListVoices to see what this machine has.
    Typical Windows names: 'Microsoft David Desktop', 'Microsoft Zira Desktop'.

.PARAMETER Rate
    Speaking speed as a percentage, e.g. -Rate 10 for ten percent faster.
    Range -100 to 100.

.PARAMETER Format
    mp3 (default, needs ffmpeg) or wav (no ffmpeg needed, about ten times bigger).

.PARAMETER Force
    Rebuild even when the audio is already newer than the script.

.PARAMETER WhatIf
    Show exactly what would be built and written, and do none of it.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\make_lecture_audio.ps1 -WhatIf
    Show the plan without touching anything.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\make_lecture_audio.ps1
    Build every lesson with the built-in Windows voice.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\make_lecture_audio.ps1 -Lesson 03 -Format wav
    One lesson, WAV output, no ffmpeg required at all.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\make_lecture_audio.ps1 -Backend edge
    Use edge-tts through the Python script. The good voices.
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string[]] $Lesson,
    [ValidateSet('sapi', 'edge')] [string] $Backend = 'sapi',
    [string] $Voice,
    [ValidateRange(-100, 100)] [int] $Rate = 0,
    [ValidateSet('mp3', 'wav')] [string] $Format = 'mp3',
    [string] $OutDir,
    [string] $LectureDir,
    [switch] $Force,
    [switch] $ListVoices,
    [double] $Pause = 0.45,
    [double] $PauseHeading = 0.9,
    [switch] $NoPlaylist
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------

$CourseRoot = Split-Path -Parent $PSScriptRoot
if (-not $LectureDir) { $LectureDir = Join-Path $CourseRoot 'lectures' }
if (-not $OutDir)     { $OutDir     = Join-Path $LectureDir 'audio' }

function Write-Utf8NoBom {
    param([string] $Path, [string] $Text)
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Text, $enc)
}

function Get-FfmpegPath {
    $c = Get-Command ffmpeg -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    return $null
}

function Format-Duration {
    param([double] $Seconds)
    if ($Seconds -lt 0) { $Seconds = 0 }
    $ts = [TimeSpan]::FromSeconds([Math]::Round($Seconds))
    if ($ts.TotalHours -ge 1) { return ('{0}h {1:00}m {2:00}s' -f [int]$ts.TotalHours, $ts.Minutes, $ts.Seconds) }
    return ('{0}m {1:00}s' -f [int]$ts.TotalMinutes, $ts.Seconds)
}

function Format-Size {
    param([long] $Bytes)
    if ($Bytes -lt 1KB) { return "$Bytes B" }
    if ($Bytes -lt 1MB) { return ('{0:N0} KB' -f ($Bytes / 1KB)) }
    return ('{0:N1} MB' -f ($Bytes / 1MB))
}

# --------------------------------------------------------------------------
# Markdown -> speakable blocks
# Mirrors markdown_to_speech() in make_lecture_audio.py. Anything that cannot
# be spoken is converted or dropped, and every drop is reported.
# --------------------------------------------------------------------------

function Convert-MarkdownToSpeech {
    param([string] $Markdown, [string] $LessonName = '?')

    $notes = New-Object System.Collections.ArrayList
    $text = $Markdown -replace "`r`n", "`n" -replace "`r", "`n"

    # YAML front matter
    $text = $text -replace '(?s)\A\uFEFF?---[ \t]*\n.*?\n---[ \t]*\n', ''

    # Fenced code blocks
    $fenceRe = '(?sm)^[ \t]*(```|~~~).*?(?:^[ \t]*\1[ \t]*$|\z)'
    $fences = ([regex]$fenceRe).Matches($text).Count
    if ($fences -gt 0) {
        [void]$notes.Add("${LessonName}: dropped $fences fenced code block(s)")
        $text = $text -replace $fenceRe, "`n"
    }

    # Inline HTML
    $htmlRe = '<[^<>\n]{1,200}>'
    $htmlCount = ([regex]$htmlRe).Matches($text).Count
    if ($htmlCount -gt 0) {
        [void]$notes.Add("${LessonName}: stripped $htmlCount inline HTML tag(s)")
        $text = $text -replace $htmlRe, ' '
    }

    $blocks = New-Object System.Collections.ArrayList
    $buffer = New-Object System.Collections.ArrayList
    $nTable = 0; $nList = 0; $nCode = 0; $nQuote = 0

    function Add-Paragraph {
        param($Buf, $Blocks)
        if ($Buf.Count -gt 0) {
            $joined = ($Buf -join ' ').Trim()
            if ($joined) { [void]$Blocks.Add([pscustomobject]@{ Kind = 'para'; Text = $joined }) }
            $Buf.Clear()
        }
    }

    foreach ($raw in ($text -split "`n")) {
        $line = $raw.TrimEnd()
        $trim = $line.Trim()

        if (-not $trim) { Add-Paragraph $buffer $blocks; continue }
        if ($trim -match '^([-*_])[ \t]*(\1[ \t]*){2,}$') { Add-Paragraph $buffer $blocks; continue }
        if (([regex]'\|').Matches($trim).Count -ge 2) { Add-Paragraph $buffer $blocks; $nTable++; continue }
        if ($buffer.Count -eq 0 -and $line -match '^(?: {4,}|\t)\S') { $nCode++; continue }

        if ($trim -match '^(#{1,6})[ \t]+(.*?)[ \t]*#*$') {
            Add-Paragraph $buffer $blocks
            $head = $Matches[2].Trim()
            if ($head) { [void]$blocks.Add([pscustomobject]@{ Kind = 'heading'; Text = $head }) }
            continue
        }

        if ($trim -match '^>[ \t]?') { $nQuote++; $trim = ($trim -replace '^>[ \t]?', '').Trim() }

        if ($trim -match '^(?:[-*+]|\d{1,3}[.)])[ \t]+(.*)$') {
            Add-Paragraph $buffer $blocks
            $nList++
            [void]$blocks.Add([pscustomobject]@{ Kind = 'para'; Text = $Matches[1].Trim() })
            continue
        }

        [void]$buffer.Add($trim)
    }
    Add-Paragraph $buffer $blocks

    if ($nTable) { [void]$notes.Add("${LessonName}: dropped $nTable table row(s)") }
    if ($nCode)  { [void]$notes.Add("${LessonName}: dropped $nCode indented code line(s)") }
    if ($nList)  { [void]$notes.Add("${LessonName}: flattened $nList list item(s) into sentences") }
    if ($nQuote) { [void]$notes.Add("${LessonName}: unwrapped $nQuote block quote line(s)") }

    # Symbols a speech engine mishandles or reads as nothing at all.
    # An ordered hashtable, so the substitutions happen in a known sequence.
    $symbols = [ordered]@{}
    $symbols[[string][char]0x2014] = ', '              # em dash
    $symbols[[string][char]0x2013] = ', '              # en dash
    $symbols[[string][char]0x2012] = ', '              # figure dash
    $symbols[[string][char]0x2026] = ', '              # ellipsis
    $symbols[[string][char]0x2018] = "'"
    $symbols[[string][char]0x2019] = "'"
    $symbols[[string][char]0x201C] = '"'
    $symbols[[string][char]0x201D] = '"'
    $symbols[[string][char]0x00A0] = ' '               # non-breaking space
    $symbols[[string][char]0x200B] = ''                # zero-width space
    $symbols[[string][char]0x00D7] = ' by '
    $symbols[[string][char]0x00F7] = ' divided by '
    $symbols[[string][char]0x2248] = ' about '
    $symbols[[string][char]0x2265] = ' at least '
    $symbols[[string][char]0x2264] = ' at most '
    $symbols[[string][char]0x2260] = ' not equal to '
    $symbols[[string][char]0x2192] = ' to '
    $symbols[[string][char]0x00B1] = ' plus or minus '
    $symbols[[string][char]0x00B0] = ' degrees '
    $symbols[[string][char]0x00B5] = 'micro'
    $symbols[[string][char]0x03BC] = 'micro'
    $symbols[[string][char]0x2011] = '-'

    $out = New-Object System.Collections.ArrayList
    $nImg = 0; $nLink = 0; $nCodeSpan = 0; $nUrl = 0; $nStray = 0

    foreach ($b in $blocks) {
        $s = $b.Text

        $nImg  += ([regex]'!\[([^\]]*)\]\([^)]*\)').Matches($s).Count
        $s = $s -replace '!\[([^\]]*)\]\([^)]*\)', ' '

        $nLink += ([regex]'\[([^\]]+)\]\([^)]*\)').Matches($s).Count
        $s = $s -replace '\[([^\]]+)\]\([^)]*\)', '$1'
        $s = $s -replace '\[([^\]]+)\]\[[^\]]*\]', '$1'

        $nUrl  += ([regex]'\b(?:https?://|www\.)\S+').Matches($s).Count
        $s = $s -replace '\b(?:https?://|www\.)\S+', 'a link in the notes'

        # Inline code becomes spoken words: max_num_tokens -> "max num tokens"
        $codeRe = [regex]'`+([^`]+?)`+'
        $nCodeSpan += $codeRe.Matches($s).Count
        $s = $codeRe.Replace($s, {
            param($m)
            $t = $m.Groups[1].Value -replace '[_/\\]+', ' '
            $t = $t -replace '(?<=\w)\.(?=\w)', ' dot '
            $t = $t -replace '^--?', ''
            ($t -replace '\s+', ' ').Trim()
        })

        $s = $s -replace '\[\^[^\]]*\]', ''
        $s = $s -replace '(?s)\*\*(.+?)\*\*', '$1'
        $s = $s -replace '(?s)__(.+?)__', '$1'
        $s = $s -replace '(?s)~~(.+?)~~', '$1'
        $s = $s -replace '(?s)(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', '$1'
        $s = $s -replace '(?s)(?<![\w_])_(?!\s)(.+?)(?<!\s)_(?![\w_])', '$1'
        $s = $s -replace '\\([\\`*_{}\[\]()#+\-.!>|~])', '$1'

        foreach ($k in @($symbols.Keys)) { $s = $s.Replace($k, [string]$symbols[$k]) }
        $s = $s -replace '&nbsp;', ' ' -replace '&amp;', ' and ' -replace '&', ' and '

        if ($s -match '[`|*_#~<>]') {
            $nStray++
            $s = $s -replace '[`|*_#~<>]', ' '
        }

        $s = $s -replace '[ \t]+', ' '
        $s = $s -replace '\s+([,.;:!?])', '$1'
        $s = $s -replace ',\s*,+', ','
        $s = $s -replace ',\s*\.', '.'
        $s = $s -replace '\.\s*,', '.'
        $s = $s -replace '^[\s,;:.]+', ''
        $s = $s.Trim()

        if (-not $s) { continue }
        if ($b.Kind -eq 'heading' -and $s -notmatch '[.?!:]$') { $s = "$s." }
        [void]$out.Add([pscustomobject]@{ Kind = $b.Kind; Text = $s })
    }

    if ($nImg)      { [void]$notes.Add("${LessonName}: dropped $nImg image(s)") }
    if ($nLink)     { [void]$notes.Add("${LessonName}: replaced $nLink link(s) with their text") }
    if ($nCodeSpan) { [void]$notes.Add("${LessonName}: spoke $nCodeSpan inline code span(s) as words") }
    if ($nUrl)      { [void]$notes.Add("${LessonName}: replaced $nUrl bare URL(s)") }
    if ($nStray)    { [void]$notes.Add("${LessonName}: removed stray markdown characters in $nStray block(s)") }

    return [pscustomobject]@{ Blocks = $out; Notes = $notes }
}

function Get-FrontMatterTitle {
    param([string] $Markdown, [string] $Fallback)
    if ($Markdown -match '(?sm)\A\uFEFF?---[ \t]*\n(.*?)\n---[ \t]*\n') {
        foreach ($l in ($Matches[1] -split "`n")) {
            if ($l -match '^\s*title\s*:\s*(.+?)\s*$') {
                return $Matches[1].Trim().Trim('"').Trim("'")
            }
        }
    }
    return $Fallback
}

# --------------------------------------------------------------------------
# Lesson discovery
# --------------------------------------------------------------------------

function Get-Lessons {
    param([string] $Dir, [string[]] $Only)

    if (-not (Test-Path -LiteralPath $Dir)) {
        throw ("No lecture directory at $Dir`n" +
               "  Pass -LectureDir C:\path\to\lectures, or run this script from " +
               "the course checkout so it can find lectures\ next to scripts\.")
    }
    $wanted = $null
    if ($Only) { $wanted = @($Only | ForEach-Object { ([string]$_).PadLeft(2, '0') }) }

    $result = New-Object System.Collections.ArrayList
    foreach ($f in (Get-ChildItem -LiteralPath $Dir -Filter '*.md' | Sort-Object Name)) {
        if ($f.Name -notmatch '^(\d{2})_([A-Za-z0-9_\-]+)\.md$') { continue }
        $num = $Matches[1]; $slug = $Matches[2]
        if ($wanted -and ($wanted -notcontains $num)) { continue }
        [void]$result.Add([pscustomobject]@{
            Number = $num; Slug = $slug; Stem = "${num}_$slug"
            Path = $f.FullName; Title = ''; Blocks = $null; Notes = $null
            Words = 0; Duration = 0.0; Size = 0L; Out = ''; Status = 'pending'
        })
    }
    if ($result.Count -eq 0) {
        $available = (Get-ChildItem -LiteralPath $Dir -Filter '*.md' |
                      Where-Object { $_.Name -match '^(\d{2})_' } |
                      ForEach-Object { $_.Name.Substring(0, 2) }) -join ', '
        if ($wanted) {
            throw ("No lecture matched -Lesson $($wanted -join ', ').`n" +
                   "  Available lessons: $available")
        }
        throw ("No lecture scripts found in $Dir`n" +
               "  Files must be named like 03_reasoning_captioning.md")
    }
    # The leading comma stops PowerShell unrolling a one-element result into a
    # bare object, which would break .Count at every call site.
    return , @($result.ToArray())
}

function Test-NeedsRebuild {
    param($LessonObj, [string] $OutFile, [switch] $ForceRebuild)
    if ($ForceRebuild) { return $true }
    if (-not (Test-Path -LiteralPath $OutFile)) { return $true }
    $o = Get-Item -LiteralPath $OutFile
    if ($o.Length -eq 0) { return $true }
    $s = Get-Item -LiteralPath $LessonObj.Path
    # One second of slack: some filesystems record mtimes only to the second.
    return ($o.LastWriteTimeUtc -lt $s.LastWriteTimeUtc.AddSeconds(1))
}

# --------------------------------------------------------------------------
# SAPI synthesis
# --------------------------------------------------------------------------

function Initialize-Speech {
    try {
        Add-Type -AssemblyName System.Speech -ErrorAction Stop
    } catch {
        throw ("Could not load System.Speech, so the built-in Windows voices " +
               "are not reachable from this shell.`n" +
               "  Try running under Windows PowerShell 5.1 instead of PowerShell 7:`n" +
               "    powershell -ExecutionPolicy Bypass -File .\scripts\make_lecture_audio.ps1`n" +
               "  Or use the much better path:  pip install edge-tts  then  -Backend edge`n" +
               "  Original error: $($_.Exception.Message)")
    }
}

function Show-Voices {
    Initialize-Speech
    $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
    try {
        Write-Host ''
        Write-Host '=== Voices installed on this machine (SAPI) ==='
        $any = $false
        foreach ($v in $synth.GetInstalledVoices()) {
            if (-not $v.Enabled) { continue }
            $any = $true
            $i = $v.VoiceInfo
            Write-Host ('  {0,-38} {1}, {2}' -f $i.Name, $i.Gender, $i.Culture.Name)
        }
        if (-not $any) {
            Write-Host '  (none enabled - add one under Settings > Time & language > Speech)'
        }
        Write-Host ''
        Write-Host 'These are the Narrator voices. They are robotic. For voices that'
        Write-Host 'sound close to a person reading, install edge-tts and use -Backend edge:'
        Write-Host '    pip install edge-tts'
        Write-Host '    .\scripts\make_lecture_audio.ps1 -Backend edge'
        Write-Host ''
        Write-Host 'To see the edge-tts voices:  python scripts\make_lecture_audio.py --list-voices'
    } finally {
        $synth.Dispose()
    }
}

function New-SapiSynthesizer {
    param([string] $VoiceName, [int] $RatePercent)
    $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
    if ($VoiceName) {
        $names = @($synth.GetInstalledVoices() |
                   Where-Object { $_.Enabled } |
                   ForEach-Object { $_.VoiceInfo.Name })
        $match = $names | Where-Object { $_ -eq $VoiceName }
        if (-not $match) { $match = $names | Where-Object { $_ -like "*$VoiceName*" } | Select-Object -First 1 }
        if (-not $match) {
            $synth.Dispose()
            throw ("No installed voice matches '$VoiceName'.`n" +
                   "  Installed: $($names -join ', ')`n" +
                   "  Run with -ListVoices to see them, or drop -Voice to use the default.")
        }
        $synth.SelectVoice($match)
    }
    # SAPI rate is an integer from -10 (slowest) to 10 (fastest).
    $r = [int][Math]::Round($RatePercent / 10.0)
    if ($r -gt 10) { $r = 10 }
    if ($r -lt -10) { $r = -10 }
    $synth.Rate = $r
    return $synth
}

function Invoke-SapiLesson {
    param($Synth, $Blocks, [string] $WavPath, [double] $ParaPause, [double] $HeadPause)

    $fmt = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(
        22050,
        [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,
        [System.Speech.AudioFormat.AudioChannel]::Mono)

    $pb = New-Object System.Speech.Synthesis.PromptBuilder
    $first = $true
    for ($i = 0; $i -lt $Blocks.Count; $i++) {
        $b = $Blocks[$i]
        if (-not $first) {
            $gap = if ($b.Kind -eq 'heading') { $HeadPause } else { $ParaPause }
            $pb.AppendBreak([TimeSpan]::FromMilliseconds([int]($gap * 1000)))
        }
        $pb.AppendText($b.Text)
        if ($b.Kind -eq 'heading' -and $i -lt ($Blocks.Count - 1)) {
            $pb.AppendBreak([TimeSpan]::FromMilliseconds([int]($HeadPause * 600)))
        }
        $first = $false
    }
    $pb.AppendBreak([TimeSpan]::FromMilliseconds(600))

    $Synth.SetOutputToWaveFile($WavPath, $fmt)
    try {
        $Synth.Speak($pb)
    } finally {
        $Synth.SetOutputToNull()
    }
    if (-not (Test-Path -LiteralPath $WavPath) -or (Get-Item -LiteralPath $WavPath).Length -lt 1024) {
        throw ("The speech engine produced no audio for $WavPath.`n" +
               "  Check that a voice is installed (run with -ListVoices) and that " +
               "nothing else is holding the audio device.")
    }
}

function Get-WavDuration {
    param([string] $Path)
    # 44-byte canonical WAV header written by System.Speech: bytes 28..31 are
    # the byte rate, so duration is (size - header) / byteRate.
    try {
        $fs = [System.IO.File]::OpenRead($Path)
        try {
            $head = New-Object byte[] 44
            $null = $fs.Read($head, 0, 44)
            $byteRate = [BitConverter]::ToUInt32($head, 28)
            if ($byteRate -le 0) { return 0.0 }
            return [Math]::Max(0.0, ($fs.Length - 44) / [double]$byteRate)
        } finally { $fs.Dispose() }
    } catch { return 0.0 }
}

function Convert-WavToMp3 {
    param([string] $Wav, [string] $Mp3, [string] $Ffmpeg)
    $ffArgs = @('-hide_banner', '-loglevel', 'error', '-y', '-i', $Wav,
                '-ar', '24000', '-ac', '1', '-c:a', 'libmp3lame', '-b:a', '64k', $Mp3)
    # ffmpeg writes to stderr as a matter of course. Under $ErrorActionPreference
    # = 'Stop' newer PowerShell turns that into a terminating error, so relax it
    # for the duration of the call and read the exit code instead.
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $out = & $Ffmpeg @ffArgs 2>&1
    $code = $LASTEXITCODE
    $ErrorActionPreference = $prev
    if ($code -ne 0 -or -not (Test-Path -LiteralPath $Mp3)) {
        throw ("ffmpeg could not convert to MP3 (exit $code).`n" +
               "  $($out -join ' ')`n" +
               "  Re-run with -Format wav to keep the WAV files instead, which " +
               "needs no ffmpeg at all.")
    }
}

function Get-AudioDuration {
    param([string] $Path, [double] $Fallback = 0.0)
    if ($Path -like '*.wav') { return (Get-WavDuration $Path) }
    $probe = Get-Command ffprobe -ErrorAction SilentlyContinue
    if ($probe) {
        $prev = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        $raw = & $probe.Source '-v' 'error' '-show_entries' 'format=duration' `
                               '-of' 'default=nw=1:nk=1' $Path 2>$null
        $ErrorActionPreference = $prev
        $val = 0.0
        if ([double]::TryParse(("$raw").Trim(), [ref]$val)) { return $val }
    }
    return $Fallback
}

# --------------------------------------------------------------------------
# Playlist and index
# --------------------------------------------------------------------------

function Write-Playlist {
    param($Lessons, [string] $Dir)
    $lines = New-Object System.Collections.ArrayList
    [void]$lines.Add('#EXTM3U')
    foreach ($L in $Lessons) {
        if (-not $L.Out -or -not (Test-Path -LiteralPath $L.Out)) { continue }
        $secs = [int][Math]::Round($L.Duration)
        if ($secs -le 0) { $secs = -1 }
        [void]$lines.Add("#EXTINF:$secs,Cosmos 3 - Lesson $($L.Number) - $($L.Title)")
        [void]$lines.Add((Split-Path -Leaf $L.Out))
    }
    $path = Join-Path $Dir 'playlist.m3u'
    Write-Utf8NoBom $path (($lines -join "`n") + "`n")
    return $path
}

$IndexCss = @'
:root{color-scheme:light dark}
*{box-sizing:border-box}
body{margin:0;padding:2rem 1rem 4rem;font:16px/1.55 -apple-system,Segoe UI,Roboto,
  Helvetica,Arial,sans-serif;background:#11131a;color:#e7e9ee}
.wrap{max-width:760px;margin:0 auto}
h1{font-size:1.5rem;margin:0 0 .25rem}
.sub{color:#98a0b3;margin:0 0 1.5rem;font-size:.92rem}
.player{position:sticky;top:0;background:#171a23;border:1px solid #262b38;
  border-radius:10px;padding:.9rem 1rem;margin-bottom:1.25rem;z-index:5}
.now{font-weight:600;margin-bottom:.55rem;font-size:.95rem}
audio{width:100%}
.speed{margin-top:.6rem;font-size:.85rem;color:#98a0b3}
.speed button{background:#222736;color:#cfd4e0;border:1px solid #333a4c;
  border-radius:5px;padding:.15rem .5rem;margin-right:.3rem;cursor:pointer;font:inherit;
  font-size:.82rem}
.speed button[aria-pressed=true]{background:#3b6ef0;border-color:#3b6ef0;color:#fff}
ol{list-style:none;margin:0;padding:0}
li{border-bottom:1px solid #222736}
li button{display:flex;gap:.85rem;align-items:baseline;width:100%;text-align:left;
  background:none;border:0;color:inherit;font:inherit;padding:.7rem .4rem;cursor:pointer}
li button:hover{background:#181c26}
li[aria-current=true] button{background:#1b2440;color:#fff}
.num{color:#7d879c;font-variant-numeric:tabular-nums;min-width:2.1em}
.ttl{flex:1}
.dur{color:#7d879c;font-variant-numeric:tabular-nums;font-size:.86rem}
footer{margin-top:2rem;color:#7d879c;font-size:.84rem}
'@

$IndexJs = @'
const items=[...document.querySelectorAll('li')];
const audio=document.getElementById('a');
const now=document.getElementById('now');
let idx=-1,rate=1;
function play(i,auto){
  if(i<0||i>=items.length)return;
  idx=i;
  items.forEach((li,n)=>li.setAttribute('aria-current',n===i));
  audio.src=items[i].dataset.src;
  now.textContent=items[i].dataset.title;
  audio.playbackRate=rate;
  if(auto!==false)audio.play().catch(()=>{});
  try{localStorage.setItem('cosmos3-track',i)}catch(e){}
}
items.forEach((li,i)=>li.querySelector('button').addEventListener('click',()=>play(i)));
audio.addEventListener('ended',()=>play(idx+1));
document.querySelectorAll('.speed button').forEach(b=>{
  b.addEventListener('click',()=>{
    rate=parseFloat(b.dataset.rate);audio.playbackRate=rate;
    document.querySelectorAll('.speed button').forEach(x=>
      x.setAttribute('aria-pressed',x===b));
  });
});
document.addEventListener('keydown',e=>{
  if(e.target.tagName==='INPUT')return;
  if(e.key===' '){e.preventDefault();audio.paused?audio.play():audio.pause();}
  if(e.key==='ArrowRight')audio.currentTime+=15;
  if(e.key==='ArrowLeft')audio.currentTime-=15;
  if(e.key==='n')play(idx+1);
  if(e.key==='p')play(idx-1);
});
let saved=0;try{saved=parseInt(localStorage.getItem('cosmos3-track')||'0',10)}catch(e){}
play(isNaN(saved)?0:saved,false);
'@

function ConvertTo-HtmlText {
    param([string] $Text)
    return ($Text -replace '&', '&amp;' -replace '<', '&lt;' -replace '>', '&gt;' -replace '"', '&quot;')
}

function Write-IndexHtml {
    param($Lessons, [string] $Dir, [string] $BackendName, [string] $VoiceName)

    $playable = @($Lessons | Where-Object { $_.Out -and (Test-Path -LiteralPath $_.Out) })
    $total = ($playable | Measure-Object -Property Duration -Sum).Sum
    if (-not $total) { $total = 0 }

    $rows = New-Object System.Collections.ArrayList
    foreach ($L in $playable) {
        $name = ConvertTo-HtmlText (Split-Path -Leaf $L.Out)
        $ttl  = ConvertTo-HtmlText $L.Title
        $dur  = if ($L.Duration -gt 0) { Format-Duration $L.Duration } else { '&mdash;' }
        [void]$rows.Add(
            "    <li data-src=`"$name`" data-title=`"Lesson $($L.Number) - $ttl`">" +
            "<button type=`"button`"><span class=`"num`">$($L.Number)</span>" +
            "<span class=`"ttl`">$ttl</span><span class=`"dur`">$dur</span></button></li>")
    }

    $count = $playable.Count
    $totalLabel = Format-Duration $total
    $bLabel = ConvertTo-HtmlText $BackendName
    $vLabel = ConvertTo-HtmlText $VoiceName
    $sub = "$count lectures &middot; $totalLabel total &middot; generated with $bLabel / $vLabel"
    $rowsText = $rows -join "`n"

    $doc = @"
<!DOCTYPE html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cosmos 3 on one H100 - audio lectures</title>
<style>$IndexCss</style>
<div class="wrap">
  <h1>Cosmos 3 on one H100 - audio lectures</h1>
  <p class="sub">$sub</p>
  <div class="player">
    <div class="now" id="now">&nbsp;</div>
    <audio id="a" controls preload="none"></audio>
    <div class="speed">Speed:
      <button data-rate="1" aria-pressed="true">1x</button>
      <button data-rate="1.25" aria-pressed="false">1.25x</button>
      <button data-rate="1.5" aria-pressed="false">1.5x</button>
      <button data-rate="1.75" aria-pressed="false">1.75x</button>
      <button data-rate="2" aria-pressed="false">2x</button>
    </div>
  </div>
  <ol>
$rowsText
  </ol>
  <footer>Space plays and pauses. Left and right arrows skip fifteen seconds.
    N and P change track. Your place is remembered in this browser.</footer>
</div>
<script>$IndexJs</script>
"@
    $path = Join-Path $Dir 'index.html'
    Write-Utf8NoBom $path $doc
    return $path
}

# --------------------------------------------------------------------------
# edge-tts hand-off
# --------------------------------------------------------------------------

function Invoke-EdgeBackend {
    param($LessonNumbers)

    $py = $null
    foreach ($cand in @('python', 'python3', 'py')) {
        $c = Get-Command $cand -ErrorAction SilentlyContinue
        if ($c) { $py = $c.Source; break }
    }
    if (-not $py) {
        throw ("-Backend edge needs Python, and no python was found on PATH.`n" +
               "  Install it from https://www.python.org/downloads/ (tick 'Add " +
               "python.exe to PATH'), then run:`n" +
               "    pip install edge-tts`n" +
               "  Or drop -Backend edge to use the built-in Windows voices.")
    }

    $pyScript = Join-Path $PSScriptRoot 'make_lecture_audio.py'
    if (-not (Test-Path -LiteralPath $pyScript)) {
        throw ("Expected the Python script next to this one, at:`n    $pyScript`n" +
               "  It is missing. Re-check out the course, or use the default " +
               "-Backend sapi which needs nothing but Windows.")
    }

    $argv = @($pyScript, '--backend', 'edge', '--format', $Format,
              '--out', $OutDir, '--lectures', $LectureDir)
    foreach ($n in $LessonNumbers) { $argv += @('--lesson', $n) }
    if ($Voice)   { $argv += @('--voice', $Voice) }
    if ($Rate -ne 0) { $argv += @('--rate', ('{0}{1}%' -f $(if ($Rate -ge 0) { '+' } else { '' }), $Rate)) }
    if ($Force)   { $argv += '--force' }
    if ($NoPlaylist) { $argv += '--no-playlist' }
    if ($WhatIfPreference) { $argv += '--dry-run' }

    $shown = $argv -join ' '
    Write-Host 'Handing off to edge-tts:'
    Write-Host "  $py $shown"
    Write-Host ''
    # Relax the error preference: python writes progress to stdout and notes to
    # stderr, and neither is a failure. The exit code is the truth.
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    & $py @argv | Out-Host
    $script:EdgeExitCode = $LASTEXITCODE
    $ErrorActionPreference = $prev
}

# ==========================================================================
# Main
# ==========================================================================

try {
    if ($ListVoices) { Show-Voices; exit 0 }

    if ($Backend -eq 'edge') {
        $nums = @()
        if ($Lesson) { $nums = @($Lesson | ForEach-Object { ([string]$_).PadLeft(2, '0') }) }
        $script:EdgeExitCode = 0
        Invoke-EdgeBackend $nums
        exit $script:EdgeExitCode
    }

    $lessons = @(Get-Lessons -Dir $LectureDir -Only $Lesson)
    $ffmpeg = Get-FfmpegPath

    if ($Format -eq 'mp3' -and -not $ffmpeg) {
        Write-Warning ("ffmpeg is not on PATH, so MP3 output is not possible. " +
                       "Falling back to WAV, which plays fine everywhere but is " +
                       "about ten times bigger (expect roughly 1.5 GB for the " +
                       "whole course).")
        Write-Warning "  To get MP3 instead:  winget install Gyan.FFmpeg   then open a NEW terminal."
        $Format = 'wav'
    }

    # ---- read and convert every script ----------------------------------
    $allNotes = New-Object System.Collections.ArrayList
    foreach ($L in $lessons) {
        $md = Get-Content -LiteralPath $L.Path -Raw -Encoding UTF8
        $conv = Convert-MarkdownToSpeech -Markdown $md -LessonName $L.Stem
        $L.Blocks = $conv.Blocks
        $L.Notes = $conv.Notes
        foreach ($n in $conv.Notes) { [void]$allNotes.Add($n) }
        $L.Title = Get-FrontMatterTitle -Markdown $md -Fallback $L.Slug
        $joined = ($conv.Blocks | ForEach-Object { $_.Text }) -join ' '
        $L.Words = @($joined -split '\s+' | Where-Object { $_ }).Count
        $L.Out = Join-Path $OutDir "$($L.Stem).$Format"
    }

    # ---- plan ------------------------------------------------------------
    $voiceLabel = if ($Voice) { $Voice } else { 'system default' }
    $ffmpegLabel = if ($ffmpeg) { $ffmpeg } else { 'not found' }
    Write-Host ''
    Write-Host "Plan  (backend: sapi / voice $voiceLabel / rate $Rate%)"
    Write-Host "  scripts : $LectureDir"
    Write-Host "  output  : $OutDir"
    Write-Host "  format  : $Format   ffmpeg: $ffmpegLabel"
    Write-Host ''
    Write-Host ('  {0,-40}{1,7}{2,9}  action' -f 'lesson', 'words', 'est.')
    Write-Host ('  ' + ('-' * 72))
    $todo = 0
    $estTotal = 0.0
    foreach ($L in $lessons) {
        $est = $L.Words / 150.0 * 60.0
        $estTotal += $est
        $build = Test-NeedsRebuild -LessonObj $L -OutFile $L.Out -ForceRebuild:$Force
        if ($build) { $todo++ }
        Write-Host ('  {0,-40}{1,7}{2,9}  {3}' -f $L.Stem, $L.Words,
                    (Format-Duration $est), $(if ($build) { 'build' } else { 'skip (up to date)' }))
    }
    Write-Host ('  ' + ('-' * 72))
    Write-Host ('  {0,-40}{1,7}{2,9}' -f 'TOTAL', ($lessons | Measure-Object -Property Words -Sum).Sum,
                (Format-Duration $estTotal))
    if ($allNotes.Count -gt 0) {
        Write-Host ''
        Write-Host "  Text conversion notes ($($allNotes.Count)):"
        foreach ($n in $allNotes) { Write-Host "    - $n" }
    } else {
        Write-Host ''
        Write-Host '  Text conversion: clean. No markdown survived into the spoken text.'
    }

    if ($todo -eq 0 -and -not $Force) {
        Write-Host ''
        Write-Host 'Everything is already up to date. Use -Force to rebuild anyway.'
    }

    # ---- build -----------------------------------------------------------
    if (-not $WhatIfPreference) {
        Initialize-Speech
        if (-not (Test-Path -LiteralPath $OutDir)) {
            $null = New-Item -ItemType Directory -Path $OutDir -Force
        }
    }

    $synth = $null
    $built = 0; $skipped = 0; $failed = 0
    Write-Host ''
    Write-Host 'Building'

    foreach ($L in $lessons) {
        if (-not (Test-NeedsRebuild -LessonObj $L -OutFile $L.Out -ForceRebuild:$Force)) {
            $skipped++
            $L.Status = 'skipped'
            $item = Get-Item -LiteralPath $L.Out
            $L.Size = $item.Length
            $L.Duration = Get-AudioDuration -Path $L.Out -Fallback ($L.Words / 150.0 * 60.0)
            Write-Host ('  skip   {0,-40} {1,9}  {2,9}' -f $L.Stem,
                        (Format-Duration $L.Duration), (Format-Size $L.Size))
            continue
        }

        if (-not $PSCmdlet.ShouldProcess($L.Out, 'synthesise lecture audio')) {
            Write-Host ('  would build  {0,-40} -> {1}' -f $L.Stem, $L.Out)
            continue
        }

        try {
            if (-not $synth) { $synth = New-SapiSynthesizer -VoiceName $Voice -RatePercent $Rate }
            $wav = if ($Format -eq 'wav') { $L.Out } else { [System.IO.Path]::ChangeExtension($L.Out, '.tmp.wav') }
            $sw = [Diagnostics.Stopwatch]::StartNew()
            Invoke-SapiLesson -Synth $synth -Blocks $L.Blocks -WavPath $wav `
                              -ParaPause $Pause -HeadPause $PauseHeading
            $L.Duration = Get-WavDuration $wav
            if ($Format -eq 'mp3') {
                Convert-WavToMp3 -Wav $wav -Mp3 $L.Out -Ffmpeg $ffmpeg
                Remove-Item -LiteralPath $wav -Force -ErrorAction SilentlyContinue
            }
            $L.Size = (Get-Item -LiteralPath $L.Out).Length
            $L.Status = 'built'
            $built++
            Write-Host ('  built  {0,-40} {1,9}  {2,9}  in {3:N0}s' -f
                        $L.Stem, (Format-Duration $L.Duration), (Format-Size $L.Size),
                        $sw.Elapsed.TotalSeconds)
        } catch {
            $failed++
            $L.Status = 'failed'
            Write-Warning "$($L.Stem) failed: $($_.Exception.Message)"
        }
    }
    if ($synth) { $synth.Dispose() }

    # ---- playlist and index ---------------------------------------------
    if (-not $NoPlaylist -and -not $WhatIfPreference) {
        $everything = @(Get-Lessons -Dir $LectureDir -Only $null)
        foreach ($E in $everything) {
            $cached = $lessons | Where-Object { $_.Stem -eq $E.Stem } | Select-Object -First 1
            if ($cached) {
                $E.Title = $cached.Title; $E.Out = $cached.Out
                $E.Duration = $cached.Duration; $E.Size = $cached.Size
                continue
            }
            $cand = Join-Path $OutDir "$($E.Stem).$Format"
            if (Test-Path -LiteralPath $cand) {
                $md = Get-Content -LiteralPath $E.Path -Raw -Encoding UTF8
                $E.Title = Get-FrontMatterTitle -Markdown $md -Fallback $E.Slug
                $E.Out = $cand
                $E.Size = (Get-Item -LiteralPath $cand).Length
                $E.Duration = Get-AudioDuration -Path $cand -Fallback 0.0
            }
        }
        $present = @($everything | Where-Object { $_.Out -and (Test-Path -LiteralPath $_.Out) })
        if ($present.Count -gt 0) {
            $pl = Write-Playlist -Lessons $present -Dir $OutDir
            $ix = Write-IndexHtml -Lessons $present -Dir $OutDir -BackendName 'sapi' `
                                  -VoiceName $voiceLabel
            Write-Host ''
            Write-Host "  playlist  $pl"
            Write-Host "  index     $ix"
        }
    }

    # ---- summary ---------------------------------------------------------
    $done = @($lessons | Where-Object { $_.Out -and (Test-Path -LiteralPath $_.Out) })
    $totalDur = ($done | Measure-Object -Property Duration -Sum).Sum
    $totalSize = ($done | Measure-Object -Property Size -Sum).Sum
    if (-not $totalDur) { $totalDur = 0 }
    if (-not $totalSize) { $totalSize = 0 }

    Write-Host ''
    Write-Host 'Summary'
    Write-Host "  built $built, skipped $skipped, failed $failed"
    Write-Host "  $($done.Count) tracks   $(Format-Duration $totalDur) of audio   $(Format-Size $totalSize) on disk"
    Write-Host "  folder: $OutDir"
    if ($failed -gt 0) {
        Write-Host ''
        Write-Host '  Some lessons failed. Re-run the same command: finished lessons'
        Write-Host '  are skipped, so only the failures are retried.'
        exit 1
    }
    if ($Backend -eq 'sapi' -and $built -gt 0) {
        Write-Host ''
        Write-Host '  These are the built-in Windows voices. If four hours of that is'
        Write-Host '  too much, install edge-tts and rebuild with much better audio:'
        Write-Host '     pip install edge-tts'
        Write-Host '     .\scripts\make_lecture_audio.ps1 -Backend edge -Force'
    }
    exit 0

} catch {
    # Deliberately not Write-Error: with $ErrorActionPreference = 'Stop' that
    # would itself throw and bury the message we are trying to show.
    [Console]::Error.WriteLine('')
    [Console]::Error.WriteLine("ERROR: $($_.Exception.Message)")
    exit 2
}
