#!/usr/bin/env python3
"""Clone or update the Cosmos cookbook and verify the assets this course needs.

The cookbook (https://github.com/NVIDIA/cosmos, path ``cookbooks/cosmos3/``) is
the source of every sample image, video, prompt and action trajectory the
lessons use. It is media only — no model weights — so this is a few GB, not a
few hundred.

Why this script exists rather than "just git clone"
---------------------------------------------------
Three things go wrong, and all three are silent:

1. **git-lfs.** The media are LFS objects. Without git-lfs installed, ``clone``
   succeeds and leaves you 130-byte text files where the .mp4s should be. Every
   downstream failure then looks like a codec problem.
2. **Upstream drift.** The cookbook's own READMEs reference paths that do not
   exist in the checkout — ``assets/multi_control/`` is the documented example
   (COSMOS3_FACTS.md section 7). A lesson that assumes the README is right dies
   halfway through. This script names the drift explicitly instead.
3. **Partial checkouts.** A cancelled clone leaves a directory that looks fine.

The expected inventory is READ FROM ``assets/reference/COSMOS3_FACTS.md``
section 6 at run time. It is not duplicated here. If the facts file is wrong,
fix the facts file — that is the single source of truth for this course, and
having a second hard-coded list in a script is how the two drift apart.

Exit codes
----------
0   Everything present (or, with --check, everything present).
1   Assets are missing beyond the known-drift list, or the checkout is broken.
2   Bad usage — a flag or path this script does not understand.
3   git failed (network, auth, disk) and the checkout could not be created.

Examples
--------
    python3 scripts/fetch_assets.py             # clone or update, then verify
    python3 scripts/fetch_assets.py --check     # verify only, touch nothing
    python3 scripts/fetch_assets.py --json      # machine-readable report
    COSMOS_ROOT=/mnt/big/cosmos python3 scripts/fetch_assets.py
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

# --------------------------------------------------------------------------
# Paths. Resolved from this file, never from the working directory.
# --------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
FACTS_FILE = REPO_ROOT / "assets" / "reference" / "COSMOS3_FACTS.md"

COOKBOOK_URL = "https://github.com/NVIDIA/cosmos"
COOKBOOK_SUBDIR = Path("cookbooks") / "cosmos3"

# An LFS pointer file is a few hundred bytes of text beginning with this line.
# Anything smaller than this that should be media is almost certainly a pointer.
LFS_MAGIC = b"version https://git-lfs.github.com/spec/v1"
LFS_POINTER_MAX_BYTES = 1024

MEDIA_SUFFIXES = {".mp4", ".jpg", ".jpeg", ".png", ".webm", ".wav", ".mov"}

# --------------------------------------------------------------------------
# Known upstream drift
# --------------------------------------------------------------------------
# Paths the cookbook's own documentation names but which are NOT in the
# checkout, plus paths this course's asset table optimistically expected. Each
# entry maps a path fragment to the explanation a learner should see instead of
# a bare "missing".
#
# Sourced from COSMOS3_FACTS.md section 7. Keep them in sync; the facts file wins.
KNOWN_DRIFT: dict[str, str] = {
    "multi_control": (
        "transfer/README.md references assets/multi_control/, which does not "
        "exist in the checkout. Multi-control IS supported — it runs as "
        "video2video with several hint blocks and TransferArgs.weight — but you "
        "build the spec yourself. Lesson 11 does exactly that."
    ),
    "negative_prompts/text2image": (
        "there is no negative prompt shipped for text2image, only for text2video "
        "and image2video. That is upstream's choice, not a missing file."
    ),
    "robolab": (
        "the RoboLab closed-loop rollout is illustrative only; closed-loop "
        "evaluation needs a separate venv (robosuite/mujoco/torch<2.6) and is "
        "out of scope for a single-GPU course."
    ),
}


# --------------------------------------------------------------------------
# Config loading
# --------------------------------------------------------------------------
def load_config() -> Any:
    """Load ``cosmos_course/config.py`` by path, without importing the package.

    Importing ``cosmos_course.config`` normally would execute the package
    ``__init__``, which pulls in viz/checks and therefore numpy, PIL and
    matplotlib. This script must work in a bare environment — it is one of the
    things you run *before* the course kernel exists. config.py itself imports
    nothing outside the standard library.

    The ``sys.modules`` line is load-bearing and not defensive tidiness.
    ``@dataclass`` resolves annotations through ``sys.modules[cls.__module__]``;
    for a module built with ``module_from_spec`` and never registered, that
    lookup returns None and class creation dies with
    ``AttributeError: 'NoneType' object has no attribute '__dict__'`` — an error
    that points at dataclasses and says nothing about the real cause.
    """
    name = "_cosmos_course_config"
    path = REPO_ROOT / "cosmos_course" / "config.py"
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


# --------------------------------------------------------------------------
# Parsing the inventory out of COSMOS3_FACTS.md section 6
# --------------------------------------------------------------------------
_BRACE = re.compile(r"\{([^{}]*)\}")


def expand_braces(pattern: str) -> list[str]:
    """Expand shell-style ``{a,b}`` alternatives, recursively.

    The facts file writes inventories compactly:

        prompts/image2video/{car_driving,car_driving_edge,coastal_road_audio}.json
        assets/{edge,blur,depth,seg}/prompt.json

    which is far more readable than 3 or 4 separate lines but has to be expanded
    before anything can be checked on disk.
    """
    match = _BRACE.search(pattern)
    if not match:
        return [pattern]
    head, tail = pattern[: match.start()], pattern[match.end() :]
    out: list[str] = []
    for option in match.group(1).split(","):
        out.extend(expand_braces(head + option.strip() + tail))
    return out


def parse_inventory(facts_text: str) -> tuple[dict[str, list[str]], list[str]]:
    """Extract section 6's asset inventory.

    Returns ``(families, notes)`` where ``families`` maps a base directory
    (relative to ``cookbooks/cosmos3/``) to the list of files expected under it,
    and ``notes`` collects anything the parser deliberately skipped, so a change
    in the facts file's formatting surfaces as a visible note rather than as a
    silently shorter inventory.

    Two shapes are recognised, because section 6 uses both:

    * a bolded path header followed by inline backticked filenames --
      ``**`reasoner/assets/`** (flat) — images `robot_153.jpg`, ...``
    * a bolded path header followed by a fenced code block, one path per line.
    """
    # Section 6 runs from its heading to the next level-2 heading.
    match = re.search(
        r"^##\s+6\.\s+.*?$(.*?)(?=^##\s+\d)", facts_text, re.MULTILINE | re.DOTALL
    )
    if not match:
        raise ValueError(
            "could not find '## 6. Cookbook assets' in COSMOS3_FACTS.md.\n"
            "  The inventory is read from that section at run time rather than "
            "duplicated in this script. If the heading was renumbered, update "
            "the regex here to match."
        )
    section = match.group(1)

    families: dict[str, list[str]] = {}
    notes: list[str] = []

    # Split on the bolded `path` headers, keeping the header with its body.
    header = re.compile(r"^\*\*`([^`]+)`\*\*", re.MULTILINE)
    positions = [(m.start(), m.group(1)) for m in header.finditer(section)]
    if not positions:
        raise ValueError("section 6 contained no **`path/`** family headers")

    for index, (start, base) in enumerate(positions):
        end = positions[index + 1][0] if index + 1 < len(positions) else len(section)
        body = section[start:end]
        base = base.strip().rstrip("/")
        entries: list[str] = []

        fences = re.findall(r"```(?:\w+)?\n(.*?)```", body, re.DOTALL)
        if fences:
            for fence in fences:
                for raw in fence.splitlines():
                    line = raw.strip()
                    if not line or line.startswith("#"):
                        continue
                    # Trim trailing prose: "assets/wsm/control_wsm.mp4 + prompt.json
                    # 101 frames @ 10 FPS" and "(shared)" style annotations.
                    line = re.sub(r"\s{2,}.*$", "", line)
                    line = re.sub(r"\s*\((?:none|shared)[^)]*\)\s*$", "", line)

                    # "assets/{edge,blur}/control_*.mp4 + prompt.json" means two
                    # files in the SAME directory. A bare continuation after ` + `
                    # inherits the first part's directory, brace expression and
                    # all — expansion happens afterwards so both sides expand
                    # together.
                    parts = [p.strip() for p in line.split(" + ") if p.strip()]
                    prefix = ""
                    if parts and "/" in parts[0]:
                        prefix = parts[0].rsplit("/", 1)[0] + "/"
                    for index, part in enumerate(parts):
                        if " " in part:
                            notes.append(f"skipped unparseable entry: {raw.strip()!r}")
                            continue
                        if index > 0 and "/" not in part:
                            part = prefix + part
                        entries.extend(expand_braces(part))
        else:
            # Inline form: every `backticked` token after the header is a
            # filename directly under `base`. The header itself was already
            # consumed by the regex, so nothing here re-matches it.
            after = body[body.index("**", 2) + 2 :] if body.startswith("**") else body
            for token in re.findall(r"`([^`]+)`", after):
                token = token.strip()
                if not token or token.endswith("/"):
                    continue
                entries.extend(expand_braces(token))

        if entries:
            # dict.fromkeys: de-duplicate while keeping the documented order,
            # which is the order a learner reads them in.
            families[base] = list(dict.fromkeys(entries))
        else:
            notes.append(f"family {base!r} produced no entries")

    # LeRobot episode DIRECTORIES are described in prose under the action
    # family rather than as file paths. They are checked as directories.
    # The trailing slash is optional because the facts file writes the plain
    # families as `droid_lerobot_example/` but the sub-foldered one as
    # `robomind_lerobot_example/{franka,franka_dual,ur}` with no trailing slash.
    for line in section.splitlines():
        for token in re.findall(
            r"`([A-Za-z0-9_]+_lerobot_example(?:/[a-z_,{}]+)?)/?`", line
        ):
            for expanded in expand_braces(token):
                target = families.setdefault("generator/action/assets", [])
                entry = expanded.rstrip("/") + "/"
                if entry not in target:
                    target.append(entry)

    return families, notes


# --------------------------------------------------------------------------
# git
# --------------------------------------------------------------------------
def run_git(args: list[str], *, cwd: Path | None = None, check: bool = True) -> str:
    """Run git and return stdout. Raises RuntimeError with the real stderr."""
    proc = subprocess.run(
        ["git", *args],
        cwd=str(cwd) if cwd else None,
        capture_output=True,
        text=True,
        check=False,
    )
    if check and proc.returncode != 0:
        raise RuntimeError(
            f"git {' '.join(args)} failed (exit {proc.returncode})\n"
            f"{proc.stderr.strip() or proc.stdout.strip()}"
        )
    return proc.stdout.strip()


def clone_or_update(root: Path, ref: str, *, quiet: bool = False) -> dict[str, Any]:
    """Make ``root`` a checkout of the cookbook at ``ref``. Idempotent.

    Skips work that is already done: an existing checkout already sitting on the
    requested ref is fetched (cheap) but not re-cloned, and ``git lfs pull`` is
    a no-op when every object is already local.
    """
    info: dict[str, Any] = {"action": None, "sha": None, "ref": ref, "lfs": False}

    if shutil.which("git") is None:
        raise RuntimeError("git is not installed:  sudo apt-get install -y git")

    has_lfs = shutil.which("git-lfs") is not None
    info["lfs"] = has_lfs

    if (root / ".git").is_dir():
        if not quiet:
            print(f"  checkout exists at {root}; fetching")
        run_git(["fetch", "--prune", "origin"], cwd=root)
        info["action"] = "updated"
    else:
        if root.exists() and any(root.iterdir()):
            raise RuntimeError(
                f"{root} exists, is not a git checkout, and is not empty.\n"
                f"  Move it aside, or set COSMOS_ROOT to a different path."
            )
        root.parent.mkdir(parents=True, exist_ok=True)
        if not quiet:
            print(f"  cloning {COOKBOOK_URL} -> {root}")
            print("  (media only, no weights; a few GB and a few minutes)")
        # GIT_LFS_SKIP_SMUDGE during clone, then an explicit `lfs pull`. Doing
        # it in two steps means a network failure part-way through leaves a
        # usable checkout you can resume, instead of an aborted clone.
        env = dict(os.environ, GIT_LFS_SKIP_SMUDGE="1")
        proc = subprocess.run(
            ["git", "clone", COOKBOOK_URL, str(root)],
            env=env, capture_output=True, text=True, check=False,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"git clone failed:\n{proc.stderr.strip()}")
        info["action"] = "cloned"

    # Pin. `main` is the documented default; a SHA is what you want for real
    # reproducibility.
    target = ref
    if run_git(["rev-parse", "--verify", "--quiet", f"{ref}^{{commit}}"],
               cwd=root, check=False) == "":
        if not quiet:
            print(f"  ref {ref!r} did not resolve; using origin/main")
        target = "origin/main"
    run_git(["-c", "advice.detachedHead=false", "checkout", "--quiet", target], cwd=root)
    info["sha"] = run_git(["rev-parse", "HEAD"], cwd=root)

    if has_lfs:
        if not quiet:
            print("  git lfs pull (this is where the media actually arrives)")
        try:
            run_git(["lfs", "pull"], cwd=root)
        except RuntimeError as exc:
            print(f"  warn: git lfs pull failed: {exc}", file=sys.stderr)
    else:
        print(
            "  warn: git-lfs is not installed, so every .mp4/.jpg in the checkout\n"
            "        is a 130-byte pointer file rather than media.\n"
            "          sudo apt-get install -y git-lfs && git lfs install\n"
            f"          git -C {root} lfs pull",
            file=sys.stderr,
        )
    return info


# --------------------------------------------------------------------------
# Verification
# --------------------------------------------------------------------------
def is_lfs_pointer(path: Path) -> bool:
    """True if this file is an unresolved git-LFS pointer rather than content."""
    try:
        if path.stat().st_size > LFS_POINTER_MAX_BYTES:
            return False
        with path.open("rb") as handle:
            return handle.read(len(LFS_MAGIC)) == LFS_MAGIC
    except OSError:
        return False


def dir_size(path: Path) -> int:
    """Total bytes under ``path``. Symlinks are not followed."""
    total = 0
    for entry in path.rglob("*"):
        try:
            if entry.is_file() and not entry.is_symlink():
                total += entry.stat().st_size
        except OSError:
            continue
    return total


def human(num_bytes: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(num_bytes) < 1024.0:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f} PB"


def drift_reason(relative: str) -> str | None:
    for fragment, reason in KNOWN_DRIFT.items():
        if fragment in relative:
            return reason
    return None


def verify(cookbook: Path, families: dict[str, list[str]]) -> dict[str, Any]:
    """Check every expected path. Returns a structured report."""
    present: list[dict[str, Any]] = []
    missing: list[dict[str, Any]] = []
    pointers: list[str] = []
    drifted: list[dict[str, str]] = []
    total_bytes = 0

    for base, entries in sorted(families.items()):
        for entry in entries:
            expect_dir = entry.endswith("/")
            relative = f"{base}/{entry.rstrip('/')}" if expect_dir else f"{base}/{entry}"
            path = cookbook / relative

            # The facts file writes some entries as globs — `control_*.mp4` —
            # because upstream's filenames carry a suffix that has churned. Glob
            # them rather than declaring them missing.
            if "*" in entry:
                hits = sorted(cookbook.glob(relative))
                if hits:
                    for hit in hits:
                        size = hit.stat().st_size
                        total_bytes += size
                        rel = str(hit.relative_to(cookbook))
                        present.append({"path": rel, "bytes": size})
                        if hit.suffix.lower() in MEDIA_SUFFIXES and is_lfs_pointer(hit):
                            pointers.append(rel)
                    continue
                exists = False
            else:
                exists = path.is_dir() if expect_dir else path.is_file()

            if exists:
                size = dir_size(path) if expect_dir else path.stat().st_size
                total_bytes += size
                present.append({"path": relative, "bytes": size})
                if not expect_dir and path.suffix.lower() in MEDIA_SUFFIXES \
                        and is_lfs_pointer(path):
                    pointers.append(relative)
            else:
                reason = drift_reason(relative)
                if reason:
                    drifted.append({"path": relative, "reason": reason})
                else:
                    missing.append({"path": relative, "is_dir": expect_dir})

    return {
        "cookbook": str(cookbook),
        "cookbook_exists": cookbook.is_dir(),
        "expected": sum(len(v) for v in families.values()),
        "present": present,
        "missing": missing,
        "pointers": pointers,
        "drifted": drifted,
        "bytes_verified": total_bytes,
    }


# --------------------------------------------------------------------------
# Reporting
# --------------------------------------------------------------------------
def report(result: dict[str, Any], checkout: dict[str, Any] | None, notes: list[str]) -> None:
    cookbook = Path(result["cookbook"])
    print()
    print("=" * 72)
    print("Cookbook asset inventory")
    print("=" * 72)
    if checkout:
        print(f"  checkout   {checkout['action']} at {cookbook.parents[1]}")
        print(f"  commit     {checkout['sha'][:12] if checkout['sha'] else '?'} (ref {checkout['ref']})")
        print(f"  git-lfs    {'installed' if checkout['lfs'] else 'MISSING — media will be pointers'}")
    print(f"  path       {cookbook}")
    print()

    n_present = len(result["present"])
    n_expected = result["expected"]
    print(f"  {n_present}/{n_expected} expected assets present, "
          f"{human(result['bytes_verified'])} verified")

    if cookbook.is_dir():
        print(f"  whole checkout on disk: {human(dir_size(cookbook.parents[1]))}")

    if result["drifted"]:
        print()
        print("  UPSTREAM HAS MOVED THESE — expected, not your fault:")
        for item in result["drifted"]:
            print(f"    - {item['path']}")
            for line in _wrap(item["reason"], 64):
                print(f"        {line}")

    if result["pointers"]:
        print()
        print(f"  {len(result['pointers'])} file(s) are unresolved git-LFS POINTERS,")
        print("  not media. They will decode as corrupt:")
        for path in result["pointers"][:8]:
            print(f"    - {path}")
        if len(result["pointers"]) > 8:
            print(f"    ... and {len(result['pointers']) - 8} more")
        print("  Fix:")
        print("    sudo apt-get install -y git-lfs && git lfs install")
        print(f"    git -C {cookbook.parents[1]} lfs pull")

    if result["missing"]:
        print()
        print(f"  {len(result['missing'])} asset(s) MISSING and not explained by known drift:")
        for item in result["missing"][:20]:
            kind = "dir " if item["is_dir"] else "file"
            print(f"    - [{kind}] {item['path']}")
        if len(result["missing"]) > 20:
            print(f"    ... and {len(result['missing']) - 20} more")
        print()
        print("  What to do next:")
        if not cookbook.is_dir():
            print("    The cookbook is not checked out at all. Run this script")
            print("    without --check to clone it.")
        else:
            print("    1. Re-run without --check to fetch and `git lfs pull`.")
            print("    2. If they are still missing, upstream has moved them.")
            print("       Check the path against the live repo:")
            print(f"         {COOKBOOK_URL}/tree/main/cookbooks/cosmos3")
            print("       and then fix assets/reference/COSMOS3_FACTS.md section 6 —")
            print("       the facts file is the source of truth and this script")
            print("       reads its inventory from there.")

    if notes:
        print()
        print("  Parser notes (lines in COSMOS3_FACTS.md section 6 that were skipped):")
        for note in notes[:10]:
            print(f"    - {note}")

    print()
    if not result["missing"] and not result["pointers"]:
        print("  All good. Nothing to do.")
    print()


def _wrap(text: str, width: int) -> list[str]:
    words, lines, current = text.split(), [], ""
    for word in words:
        if len(current) + len(word) + 1 > width:
            lines.append(current)
            current = word
        else:
            current = f"{current} {word}".strip()
    if current:
        lines.append(current)
    return lines


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="fetch_assets.py",
        description=(
            "Clone or update the NVIDIA/cosmos cookbook and verify that every "
            "asset this course names is really on disk. The expected inventory "
            "is read from assets/reference/COSMOS3_FACTS.md section 6, not "
            "hard-coded here."
        ),
        epilog=(
            "Exit codes: 0 all present · 1 assets missing or checkout broken · "
            "2 bad usage · 3 git failed.\n\n"
            "Common drift (e.g. transfer/assets/multi_control/ referenced by the "
            "cookbook README but absent from the checkout) is reported as "
            "EXPECTED and does not fail the run."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--check", action="store_true",
        help="Report only. Do not clone, fetch, checkout or lfs-pull anything. "
             "Safe to run on a machine with no network.",
    )
    parser.add_argument(
        "--root", type=Path, default=None, metavar="DIR",
        help="Where the cookbook checkout lives. Default: $COSMOS_ROOT, else "
             "<repo>/vendor/cosmos (from cosmos_course.config).",
    )
    parser.add_argument(
        "--ref", default=None, metavar="REF",
        help="Git ref to pin the cookbook to. Default: $COSMOS_COOKBOOK_REF, "
             "else config.PINNED['cosmos_cookbook'] (currently 'main'). Pass a "
             "SHA for real reproducibility.",
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Emit the report as JSON on stdout instead of prose. Human output "
             "is suppressed so the stream stays parseable.",
    )
    parser.add_argument(
        "--quiet", "-q", action="store_true",
        help="Suppress progress chatter; keep the final report.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if not FACTS_FILE.is_file():
        print(f"error: cannot find the facts file at {FACTS_FILE}", file=sys.stderr)
        print("       This script reads its asset inventory from section 6 of that",
              file=sys.stderr)
        print("       file. Are you running it from a complete checkout?", file=sys.stderr)
        return 2

    try:
        families, notes = parse_inventory(FACTS_FILE.read_text(encoding="utf-8"))
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    try:
        config = load_config()
        default_root = Path(config.COSMOS_ROOT)
        default_ref = config.PINNED["cosmos_cookbook"]
    except Exception as exc:  # noqa: BLE001 - a broken config must not be fatal here
        print(f"warn: could not read cosmos_course/config.py ({exc}); using defaults",
              file=sys.stderr)
        default_root = Path(os.environ.get("COSMOS_ROOT", REPO_ROOT / "vendor" / "cosmos"))
        default_ref = os.environ.get("COSMOS_COOKBOOK_REF", "main")

    root = (args.root or default_root).expanduser().resolve()
    ref = args.ref or default_ref
    cookbook = root / COOKBOOK_SUBDIR

    checkout: dict[str, Any] | None = None
    if not args.check:
        try:
            checkout = clone_or_update(root, ref, quiet=args.quiet or args.json)
        except RuntimeError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 3
    elif not args.quiet and not args.json:
        print("--check: reporting only, nothing will be fetched or modified.")

    result = verify(cookbook, families)
    result["notes"] = notes
    result["checkout"] = checkout

    if args.json:
        json.dump(result, sys.stdout, indent=2, default=str)
        sys.stdout.write("\n")
    else:
        report(result, checkout, notes)

    if not cookbook.is_dir():
        if not args.json:
            print(f"The cookbook is not at {cookbook}.", file=sys.stderr)
            print("Run without --check to clone it.", file=sys.stderr)
        return 1
    return 1 if (result["missing"] or result["pointers"]) else 0


if __name__ == "__main__":
    sys.exit(main())
