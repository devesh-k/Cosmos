#!/usr/bin/env python3
"""Turn the lecture scripts into HTML pages that Microsoft Edge can narrate.

Why this exists
---------------
Edge has a built-in Read Aloud feature (Ctrl+Shift+U) driven by the same neural
voices Microsoft sells through Azure. It is the best-sounding text-to-speech
most people already have, it needs nothing installed, and it works offline once
the page is open. Point it at a clean HTML page and it reads the page.

"Clean" is doing real work in that sentence, and it is the whole reason this
script is more than a markdown-to-HTML converter:

1. **Read Aloud narrates everything it can see.** Navigation links, footers and
   helpful instructions all get read out in the same voice as the lecture. So
   the lecture pages carry no preamble at all — they open on the first sentence
   of the lecture. Instructions live on the index page, where they are read
   once, and navigation sits after an explicit spoken end marker.

2. **Text-to-speech mangles technical writing.** "H100" becomes "H one hundred
   zero", "bf16" becomes something unrepeatable, and a URL is read character by
   character for twenty seconds. So the prose is rewritten for the ear before
   it reaches the page. The markdown in ``lectures/`` stays readable for the
   eye; this rewriting happens only on the way to HTML.

The rewriting is the fiddly part and it is deliberately auditable: run with
``--check`` and the script reports every remaining pronunciation hazard it
found, per lecture, so the dictionary can be extended rather than trusted.

Outputs
-------
``lectures/read-aloud/index.html``   the contents page, with progress tracking
``lectures/read-aloud/NN_slug.html`` one page per lecture (20 of them)
``lectures/read-aloud/all.html``     every lecture on one page, for hands-off listening

Usage
-----
    python scripts/make_read_aloud.py              # build everything
    python scripts/make_read_aloud.py --check      # report hazards, write nothing
    python scripts/make_read_aloud.py --lesson 03  # rebuild one lecture
    python scripts/make_read_aloud.py --open       # build, then print the file:// URL

Exit codes: 0 success, 1 a lecture could not be read, 2 bad arguments.
"""

from __future__ import annotations

import argparse
import html
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
LECTURE_DIR = REPO_ROOT / "lectures"
OUT_DIR = LECTURE_DIR / "read-aloud"

# Words per minute for duration estimates. Edge's default rate lands around
# here; the reader can speed it up in the toolbar, so treat this as a ceiling.
WPM = 145


# ---------------------------------------------------------------------------
# Pronunciation
# ---------------------------------------------------------------------------
# Ordered list of (pattern, replacement). ORDER MATTERS: longer and more
# specific patterns must come before the general ones that would eat them.
#
# The guiding rule is "write what a person would say". A human reading this
# aloud says "an H one hundred with eighty gigabytes", not "an H-one-zero-zero
# with eighty G B". Where a term is genuinely pronounced as a word by people in
# the field (NIM, LoRA, CUDA, wam), it is left alone, because spelling it out
# would be less natural, not more.
PRONUNCIATION: list[tuple[str, str]] = [
    # -- URLs and paths first: they contain characters every later rule would
    #    mangle further, and they are unlistenable regardless. -----------------
    (r"https?://[^\s)\]]+", "the link in the notes"),
    (r"\b[\w.-]+\.(?:com|org|io|ai|co|dev)/[^\s)\]]*", "the link in the notes"),

    # -- GPUs and silicon ----------------------------------------------------
    # Plural first: "eight H100s" must not become "eight H one hundred s".
    (r"\bH100s\b", "H one hundreds"),
    (r"\bA100s\b", "A one hundreds"),
    (r"\bH100\b", "H one hundred"),
    (r"\bH200\b", "H two hundred"),
    (r"\bA100\b", "A one hundred"),
    (r"\bB300\b", "B three hundred"),
    (r"\bB200\b", "B two hundred"),
    (r"\bGB300\b", "G B three hundred"),
    (r"\bGB200\b", "G B two hundred"),
    (r"\bGB10\b", "G B ten"),
    (r"\bGH200\b", "G H two hundred"),
    (r"\bH20\b", "H twenty"),
    (r"\bL40S\b", "L forty S"),
    (r"\bRTX\b", "R T X"),
    (r"\bsm_90\b", "S M ninety"),
    (r"\bsm_89\b", "S M eighty-nine"),
    (r"\bDGX\b", "D G X"),
    (r"\bSXM\b", "S X M"),
    (r"\bPCIe\b", "P C I E"),
    (r"\bNVLink\b", "N V Link"),
    (r"\bHBM3?\b", "H B M"),

    # -- Numeric precision formats ------------------------------------------
    # Case-insensitive: the scripts use both "bf16" and "BF16" depending on
    # whether the sentence is talking about the flag or the format.
    (r"(?i)\bbf16\b", "B F sixteen"),
    (r"(?i)\bfp16\b", "F P sixteen"),
    (r"(?i)\bfp32\b", "F P thirty-two"),
    (r"(?i)\btf32\b", "T F thirty-two"),
    (r"(?i)\bfp8\b", "F P eight"),
    (r"(?i)\bfp4\b", "F P four"),
    (r"(?i)\bnvfp4\b", "N V F P four"),
    (r"(?i)\be4m3\b", "E four M three"),
    (r"(?i)\be5m2\b", "E five M two"),
    (r"(?i)\bint8\b", "int eight"),

    # -- Memory and storage units -------------------------------------------
    # Attach to a preceding number where there is one, so "35 GB" becomes
    # "35 gigabytes" rather than "35 gigabyte s".
    (r"(\d)\s*GiB\b", r"\1 gibibytes"),
    (r"(\d)\s*MiB\b", r"\1 mebibytes"),
    (r"(\d)\s*GB\b", r"\1 gigabytes"),
    (r"(\d)\s*MB\b", r"\1 megabytes"),
    (r"(\d)\s*TB\b", r"\1 terabytes"),
    (r"(\d)\s*KB\b", r"\1 kilobytes"),
    (r"\bGiB\b", "gibibytes"),
    (r"\bGB\b", "gigabytes"),
    (r"\bMB\b", "megabytes"),
    (r"\bTB\b", "terabytes"),
    (r"\bVRAM\b", "V RAM"),

    # -- Cosmos model names --------------------------------------------------
    # The hyphenated forms are the ones that break; "Cosmos 3" with a space is
    # already read correctly.
    (r"\bCosmos3-Nano-Policy-DROID\b", "Cosmos three Nano Policy DROID"),
    (r"\bCosmos3-Edge-Policy-DROID\b", "Cosmos three Edge Policy DROID"),
    (r"\bCosmos3-Nano\b", "Cosmos three Nano"),
    (r"\bCosmos3-Edge\b", "Cosmos three Edge"),
    (r"\bCosmos3-Super\b", "Cosmos three Super"),
    (r"\bCosmos3\b", "Cosmos three"),
    (r"\bCosmos-Guardrail1\b", "Cosmos Guardrail one"),
    (r"\bWan2\.2\b", "Wan two point two"),
    (r"\bQwen3\b", "Qwen three"),

    # -- Model modes ---------------------------------------------------------
    (r"\baudio_image2video\b", "audio image to video"),
    (r"\bimage2video\b", "image to video"),
    (r"\bvideo2video\b", "video to video"),
    (r"\btext2video\b", "text to video"),
    (r"\btext2image\b", "text to image"),
    (r"\bimage2image\b", "image to image"),
    (r"\bmodel_mode\b", "model mode"),
    (r"\brot6d\b", "rot six D"),
    (r"\bSO\(3\)\b", "S O three"),

    # -- Training vocabulary -------------------------------------------------
    (r"\bHSDP\b", "H S D P"),
    (r"\bFSDP\b", "F S D P"),
    (r"\bSFT\b", "S F T"),
    (r"\bRLHF\b", "R L H F"),
    (r"\bGRPO\b", "G R P O"),
    (r"\bPPO\b", "P P O"),
    (r"\bDPO\b", "D P O"),
    (r"\bEMA\b", "E M A"),
    (r"\bDCP\b", "D C P"),
    (r"\bAdamW\b", "Adam W"),
    (r"\bVLM\b", "V L M"),
    (r"\bVFM\b", "V F M"),
    (r"\bWFM\b", "W F M"),
    (r"\bMoT\b", "Mixture of Transformers"),
    (r"\bMoE\b", "Mixture of Experts"),
    (r"\bVAE\b", "V A E"),
    (r"\bKL\b", "K L"),
    (r"\bIoU\b", "I O U"),
    (r"\bMSE\b", "M S E"),

    # -- Infrastructure ------------------------------------------------------
    (r"\bnvidia-smi\b", "nvidia S M I"),
    (r"\bnvcr\.io\b", "N V C R dot I O"),
    (r"\bNGC\b", "N G C"),
    (r"\bJSONL\b", "JSON L"),
    (r"\bvLLM\b", "v L L M"),
    (r"\bTensorRT\b", "Tensor R T"),
    (r"\bffmpeg\b", "F F mpeg"),
    (r"\bffprobe\b", "F F probe"),
    (r"\bHTTP\b", "H T T P"),
    (r"\bAPI\b", "A P I"),
    (r"\bSSH\b", "S S H"),
    (r"\bNVMe\b", "N V M E"),
    (r"\bLeRobot\b", "Le Robot"),
    (r"(?i)\bbase64\b", "base sixty-four"),
    (r"\bAV1\b", "A V one"),
    (r"\bH\.?264\b", "H two six four"),
    (r"\bHEVC\b", "H E V C"),
    (r"\bOpenCV\b", "Open C V"),
    (r"\bSAM\b", "SAM"),
    (r"\bcu130\b", "C U one thirty"),
    (r"\bcu128\b", "C U one twenty-eight"),
    (r"\bCUDA_VISIBLE_DEVICES\b", "CUDA VISIBLE DEVICES"),
    (r"\bPYTORCH_ALLOC_CONF\b", "PYTORCH ALLOC CONF"),

    # -- Notation ------------------------------------------------------------
    (r"\b0\s*[-–]\s*1000\b", "zero to one thousand"),
    (r"\b16\s*,\s*9\b", "sixteen by nine"),
    (r"\b9\s*,\s*16\b", "nine by sixteen"),
    (r"\b(\d+)\s*x\s*(\d+)\b", r"\1 by \2"),
    (r"\b(\d+(?:\.\d+)?)x\b", r"\1 times"),
    (r"~(\d)", r"about \1"),
    (r"\bvs\.?\b", "versus"),
    (r"\be\.g\.", "for example"),
    (r"\bi\.e\.", "that is"),
    (r"\betc\.", "and so on"),
]

# After transformation, anything matching these is probably still unlistenable.
# Reported by --check so the dictionary can be extended rather than assumed
# complete. Each entry is (name, pattern, why it matters).
HAZARDS: list[tuple[str, str]] = [
    ("underscore identifier", r"\b\w+_\w+\b"),
    ("path-like", r"\b[\w.-]+/[\w./-]+"),
    ("letter-digit mash", r"\b(?![A-Z] )[A-Za-z]{1,6}\d+[A-Za-z]*\b"),
    ("backtick", r"`"),
    ("angle bracket", r"[<>]"),
    ("curly quote or dash", r"[‘’“”–—]"),
]

# Curly punctuation confuses some voices and gains nothing spoken.
STRAIGHTEN = {
    "‘": "'", "’": "'", "“": '"', "”": '"',
    "–": " to ", "—": ", ", "…": "...", " ": " ",
    "×": " by ", "→": " becomes ", "≥": " at least ",
    "≤": " at most ", "≈": " about ",
}


def speakable(text: str) -> str:
    """Rewrite prose so a speech engine says it the way a person would."""
    for bad, good in STRAIGHTEN.items():
        text = text.replace(bad, good)
    # Inline markdown must go before pronunciation, or the patterns miss terms
    # wrapped in backticks or asterisks.
    text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)   # [text](url) -> text
    text = re.sub(r"`([^`]+)`", r"\1", text)                # `code` -> code
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)          # **bold** -> bold
    text = re.sub(r"(?<!\w)\*([^*]+)\*(?!\w)", r"\1", text)  # *ital* -> ital
    for pattern, repl in PRONUNCIATION:
        text = re.sub(pattern, repl, text)
    # Leftover underscores inside identifiers read as "underscore" on some
    # voices and as nothing on others; a space is right either way.
    text = re.sub(r"(?<=\w)_(?=\w)", " ", text)
    return re.sub(r"\s{2,}", " ", text).strip()


def find_hazards(text: str) -> list[tuple[str, str]]:
    """Return (hazard name, offending substring) for anything still unspeakable."""
    found: list[tuple[str, str]] = []
    for name, pattern in HAZARDS:
        for m in re.finditer(pattern, text):
            found.append((name, m.group(0)))
    return found


# ---------------------------------------------------------------------------
# Reading the lecture scripts
# ---------------------------------------------------------------------------
@dataclass
class Lecture:
    number: str
    slug: str
    title: str
    blocks: list[tuple[str, str]] = field(default_factory=list)  # (kind, text)
    words: int = 0
    hazards: list[tuple[str, str]] = field(default_factory=list)

    @property
    def minutes(self) -> int:
        return max(1, round(self.words / WPM))

    @property
    def filename(self) -> str:
        return f"{self.slug}.html"

    @property
    def notebook(self) -> str:
        return f"../../{self.slug}.ipynb"


def parse_frontmatter(raw: str) -> tuple[dict[str, str], str]:
    if not raw.startswith("---"):
        return {}, raw
    end = raw.find("\n---", 3)
    if end == -1:
        return {}, raw
    meta: dict[str, str] = {}
    for line in raw[3:end].strip().splitlines():
        key, _, value = line.partition(":")
        meta[key.strip()] = value.strip().strip('"').strip("'")
    return meta, raw[end + 4:].lstrip("\n")


def load_lecture(path: Path) -> Lecture:
    meta, body = parse_frontmatter(path.read_text(encoding="utf-8"))
    number = meta.get("lesson") or path.name[:2]
    slug = meta.get("slug") or path.stem
    title = meta.get("title") or slug.replace("_", " ")

    blocks: list[tuple[str, str]] = []
    for chunk in re.split(r"\n\s*\n", body):
        chunk = chunk.strip()
        if not chunk or chunk.startswith("```"):
            continue
        if chunk.startswith("# "):
            continue          # the H1 duplicates the title; the page supplies it
        if chunk.startswith("## ") or chunk.startswith("### "):
            blocks.append(("h2", speakable(chunk.lstrip("# ").strip())))
            continue
        if chunk.startswith(("- ", "* ")):
            # Lists read badly. Fold each item into its own short sentence.
            for item in chunk.splitlines():
                item = item.strip().lstrip("-* ").strip()
                if item:
                    spoken = speakable(item)
                    blocks.append(("p", spoken if spoken.endswith((".", "?", "!")) else spoken + "."))
            continue
        blocks.append(("p", speakable(re.sub(r"\s*\n\s*", " ", chunk))))

    spoken_text = " ".join(t for _, t in blocks)
    return Lecture(
        number=number,
        slug=slug,
        title=speakable(title),
        blocks=blocks,
        words=len(spoken_text.split()),
        hazards=find_hazards(spoken_text),
    )


def load_key_terms() -> dict[str, list[tuple[str, str]]]:
    """Load the spoken glossaries, if they have been authored."""
    path = LECTURE_DIR / "key_terms.py"
    if not path.exists():
        return {}
    namespace: dict[str, object] = {}
    exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"), namespace)
    terms = namespace.get("KEY_TERMS", {})
    return terms if isinstance(terms, dict) else {}


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------
# One stylesheet, inlined into every page so the files work from OneDrive, a
# USB stick or anywhere else without a server. Serif body text at a generous
# size, because these pages are also readable; `color-scheme` makes Edge honour
# the Windows light/dark setting without any toggle to maintain.
STYLE = """
:root { color-scheme: light dark; --accent: #76b900; --rule: rgba(128,128,128,.28); }
* { box-sizing: border-box; }
body { font-family: Georgia, "Times New Roman", serif; font-size: 1.14rem;
       line-height: 1.75; max-width: 42rem; margin: 0 auto;
       padding: 3rem 1.25rem 4rem; }
h1 { font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
     font-size: 1.5rem; line-height: 1.3; margin: 0 0 2rem; }
h2 { font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
     font-size: 1.1rem; line-height: 1.4; margin: 2.5rem 0 1rem;
     padding-top: .5rem; border-top: 1px solid var(--rule); }
p { margin: 0 0 1.2rem; }
.meta { font-family: system-ui, sans-serif; font-size: .85rem; opacity: .6;
        margin: -1.5rem 0 2.5rem; }
.terms { margin-top: 3rem; padding-top: 1rem; border-top: 2px solid var(--accent); }
.terms h2 { border: 0; margin-top: 0; padding-top: 0; }
.terms dt { font-weight: bold; margin-top: 1rem; }
.terms dd { margin: .3rem 0 0; }
.end { font-family: system-ui, sans-serif; opacity: .55; font-size: .9rem;
       margin: 2.5rem 0 0; }
nav.after { font-family: system-ui, sans-serif; font-size: .85rem;
            margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--rule); }
nav.after a { color: inherit; }
a { color: inherit; text-decoration-color: var(--accent); }
a:hover { text-decoration-thickness: 2px; }
ol.toc { font-family: system-ui, sans-serif; font-size: .98rem;
         padding-left: 0; list-style: none; counter-reset: n -1; }
ol.toc li { margin: .1rem 0; padding: .55rem .6rem; border-radius: 5px;
            display: flex; gap: .7rem; align-items: baseline; }
ol.toc li:hover { background: rgba(128,128,128,.09); }
ol.toc li::before { content: counter(n, decimal-leading-zero);
                    counter-increment: n; opacity: .45; font-variant-numeric: tabular-nums;
                    font-size: .85rem; min-width: 1.6rem; }
ol.toc a { text-decoration: none; flex: 1; }
ol.toc a:hover { text-decoration: underline; }
.mins { opacity: .45; font-size: .82rem; font-variant-numeric: tabular-nums; }
.done::after { content: "listened"; color: var(--accent); font-size: .72rem;
               text-transform: uppercase; letter-spacing: .04em; }
.module { font-family: system-ui, sans-serif; font-size: .74rem; letter-spacing: .09em;
          text-transform: uppercase; opacity: .5; margin: 1.8rem 0 .4rem; }
.bar { height: 5px; border-radius: 3px; background: rgba(128,128,128,.22);
       overflow: hidden; margin: .5rem 0 .3rem; }
.bar > i { display: block; height: 100%; background: var(--accent); width: 0; }
.howto { font-family: system-ui, sans-serif; font-size: .93rem;
         border-left: 3px solid var(--accent); background: rgba(118,185,0,.07);
         padding: .9rem 1.1rem; border-radius: 0 5px 5px 0; margin: 1.5rem 0 2rem; }
kbd { font-family: system-ui, sans-serif; border: 1px solid rgba(128,128,128,.5);
      border-bottom-width: 2px; border-radius: 3px; padding: 0 .35em; font-size: .85em; }
button.mark { font: inherit; font-family: system-ui, sans-serif; font-size: .85rem;
              padding: .4rem .8rem; border-radius: 5px; cursor: pointer;
              border: 1px solid var(--rule); background: transparent; color: inherit; }
button.mark:hover { border-color: var(--accent); }
"""

# Progress tracking. Wrapped in try/catch throughout: pages opened from a
# file:// URL sometimes have storage blocked by policy, and a course that
# throws an error because it could not remember a checkbox would be absurd.
# Everything degrades to "works, just does not remember".
PROGRESS_JS = """
const KEY = 'cosmos3-lectures-listened';
function load() {
  try { return new Set(JSON.parse(localStorage.getItem(KEY) || '[]')); }
  catch (e) { return new Set(); }
}
function save(set) {
  try { localStorage.setItem(KEY, JSON.stringify([...set])); } catch (e) {}
}
function mark(slug, done) {
  const s = load();
  done ? s.add(slug) : s.delete(slug);
  save(s);
  return s;
}
"""


def page(title: str, body: str, *, extra_js: str = "") -> str:
    return (
        "<!DOCTYPE html>\n"
        '<html lang="en">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
        f"<title>{html.escape(title)}</title>\n"
        f"<style>{STYLE}</style>\n</head>\n<body>\n{body}\n"
        f"<script>{PROGRESS_JS}{extra_js}</script>\n</body>\n</html>\n"
    )


def render_terms(number: str, terms: dict[str, list[tuple[str, str]]]) -> str:
    """The key-terms recap, written as a spoken outro rather than a glossary."""
    entries = terms.get(number)
    if not entries:
        return ""
    items = "\n".join(
        f"<dt>{html.escape(term)}</dt>\n<dd>{html.escape(definition)}</dd>"
        for term, definition in entries
    )
    return (
        '<section class="terms">\n<h2>Terms from this lecture</h2>\n'
        f"<dl>\n{items}\n</dl>\n</section>"
    )


def render_lecture(lec: Lecture, terms: dict, prev: Lecture | None,
                   nxt: Lecture | None) -> str:
    """One lecture page.

    Deliberate ordering, because Read Aloud narrates top to bottom: title,
    then straight into the lecture with no preamble, then the spoken recap,
    then an explicit end marker, and only then anything navigational.
    """
    parts = [f"<h1>{html.escape(lec.title)}</h1>"]
    for kind, text in lec.blocks:
        tag = "h2" if kind == "h2" else "p"
        parts.append(f"<{tag}>{html.escape(text)}</{tag}>")

    recap = render_terms(lec.number, terms)
    if recap:
        parts.append(recap)

    parts.append(
        f'<p class="end">That is the end of lecture {lec.number}.</p>'
    )

    links = [f'<a href="index.html">All lectures</a>']
    if prev:
        links.insert(0, f'<a href="{prev.filename}">Previous</a>')
    if nxt:
        links.append(f'<a href="{nxt.filename}">Next</a>')
    links.append(f'<a href="{lec.notebook}">Open the notebook</a>')
    parts.append(
        '<nav class="after">\n'
        + " &middot; ".join(links)
        + f'\n<p><button class="mark" id="mk" type="button"></button></p>\n</nav>'
    )

    js = f"""
const slug = {json.dumps(lec.slug)};
const btn = document.getElementById('mk');
function paint() {{
  const done = load().has(slug);
  btn.textContent = done ? 'Listened \\u2713 (click to undo)' : 'Mark as listened';
}}
btn.addEventListener('click', () => {{ mark(slug, !load().has(slug)); paint(); }});
paint();
"""
    return page(lec.title, "\n".join(parts), extra_js=js)


MODULES = [
    ("Foundations", ["00", "01"]),
    ("Module 1 — Perceive", ["02", "03", "04", "05"]),
    ("Module 2 — Imagine", ["06", "07", "08", "09"]),
    ("Module 3 — Act", ["10", "11", "12", "13"]),
    ("Module 4 — Systems", ["14", "15"]),
    ("Module 5 — Post-training", ["16", "17", "18"]),
    ("Module 6 — Capstone", ["19"]),
]


def render_index(lectures: list[Lecture]) -> str:
    total_words = sum(l.words for l in lectures)
    hours, mins = divmod(round(total_words / WPM), 60)
    by_number = {l.number: l for l in lectures}

    parts = [
        "<h1>Physical AI with Cosmos 3 &mdash; lectures</h1>",
        f'<p class="meta">{len(lectures)} lectures &middot; {total_words:,} words '
        f"&middot; about {hours} hours {mins} minutes spoken</p>",
        '<div class="howto">\n'
        "<p><strong>To listen:</strong> open any lecture, then press "
        "<kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>U</kbd>, or right-click and choose "
        "<em>Read aloud</em>. In the toolbar that appears, open <em>Voice options</em> "
        "and pick a <strong>Natural</strong> voice &mdash; Andrew, Aria, Guy or Jenny. "
        "Those are the neural ones and they sound markedly better than the defaults.</p>\n"
        "<p>The lecture pages carry no introduction, so narration begins on the first "
        "real sentence. Each ends with a short recap of its key terms and a spoken "
        'end marker. <a href="all.html">Every lecture on one page</a> plays the whole '
        "course unattended, which is the closest thing to a podcast.</p>\n</div>",
        '<div class="bar"><i id="pb"></i></div>',
        '<p class="meta" id="pt">&nbsp;</p>',
    ]

    for module_name, numbers in MODULES:
        parts.append(f'<p class="module">{module_name}</p>')
        parts.append('<ol class="toc">')
        for number in numbers:
            lec = by_number.get(number)
            if lec is None:
                continue
            parts.append(
                f'<li data-slug="{lec.slug}">'
                f'<a href="{lec.filename}">{html.escape(lec.title)}</a>'
                f'<span class="mins">{lec.minutes} min</span></li>'
            )
        parts.append("</ol>")

    js = """
const done = load();
document.querySelectorAll('li[data-slug]').forEach(li => {
  if (done.has(li.dataset.slug)) li.classList.add('done');
});
const total = document.querySelectorAll('li[data-slug]').length;
const pct = total ? Math.round(100 * done.size / total) : 0;
document.getElementById('pb').style.width = pct + '%';
document.getElementById('pt').textContent =
  done.size + ' of ' + total + ' listened' + (done.size ? ' (' + pct + '%)' : '');
"""
    return page("Cosmos 3 course lectures", "\n".join(parts), extra_js=js)


def render_all(lectures: list[Lecture], terms: dict) -> str:
    """Every lecture on one page, for hands-off listening.

    Edge starts Read Aloud from the paragraph you last clicked, so the contents
    list at the top doubles as a way to start partway through: click a heading,
    then start narration.
    """
    parts = [
        "<h1>Physical AI with Cosmos 3 &mdash; all lectures</h1>",
        '<p class="meta">Click any paragraph before starting Read Aloud and Edge '
        "begins from there.</p>",
        '<ol class="toc">',
    ]
    for lec in lectures:
        parts.append(
            f'<li><a href="#{lec.slug}">{html.escape(lec.title)}</a>'
            f'<span class="mins">{lec.minutes} min</span></li>'
        )
    parts.append("</ol>")

    for lec in lectures:
        parts.append(f'<h1 id="{lec.slug}">Lecture {lec.number}. {html.escape(lec.title)}</h1>')
        for kind, text in lec.blocks:
            tag = "h2" if kind == "h2" else "p"
            parts.append(f"<{tag}>{html.escape(text)}</{tag}>")
        recap = render_terms(lec.number, terms)
        if recap:
            parts.append(recap)
        parts.append(f'<p class="end">That is the end of lecture {lec.number}.</p>')

    parts.append('<nav class="after"><a href="index.html">Back to the contents</a></nav>')
    return page("All lectures", "\n".join(parts))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(
        description="Build read-aloud HTML pages from the lecture scripts.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Exit codes: 0 ok, 1 could not read a lecture, 2 bad arguments.",
    )
    ap.add_argument("--lesson", metavar="NN", help="build only this lecture (e.g. 03)")
    ap.add_argument("--check", action="store_true",
                    help="report pronunciation hazards and write nothing")
    ap.add_argument("--out", type=Path, default=OUT_DIR, help=f"output dir (default {OUT_DIR})")
    ap.add_argument("--open", action="store_true", dest="show",
                    help="print the file URL to open when done")
    args = ap.parse_args()

    sources = sorted(LECTURE_DIR.glob("[0-9][0-9]_*.md"))
    if not sources:
        print(f"No lecture scripts found in {LECTURE_DIR}", file=sys.stderr)
        return 1

    lectures = [load_lecture(p) for p in sources]
    terms = load_key_terms()
    if not terms:
        print("note: lectures/key_terms.py not found — pages will have no recap section")

    if args.check:
        total = 0
        for lec in lectures:
            missing = "" if lec.number in terms else "   [no key terms]"
            if lec.hazards:
                seen: dict[str, set[str]] = {}
                for name, text in lec.hazards:
                    seen.setdefault(name, set()).add(text)
                print(f"\n{lec.number} {lec.title}{missing}")
                for name, items in sorted(seen.items()):
                    shown = ", ".join(sorted(items)[:8])
                    more = f" (+{len(items) - 8} more)" if len(items) > 8 else ""
                    print(f"    {name}: {shown}{more}")
                total += len(lec.hazards)
            elif missing:
                print(f"\n{lec.number} {lec.title}{missing}")
        print(f"\n{total} pronunciation hazard(s) across {len(lectures)} lecture(s).")
        print("Each one is a word Read Aloud will probably mangle. Extend "
              "PRONUNCIATION in this file to fix.")
        return 0

    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    wanted = [l for l in lectures if not args.lesson or l.number == args.lesson.zfill(2)]
    if args.lesson and not wanted:
        print(f"No lecture numbered {args.lesson}", file=sys.stderr)
        return 2

    for i, lec in enumerate(lectures):
        if lec not in wanted:
            continue
        prev = lectures[i - 1] if i else None
        nxt = lectures[i + 1] if i + 1 < len(lectures) else None
        path = out / lec.filename
        path.write_text(render_lecture(lec, terms, prev, nxt), encoding="utf-8")
        print(f"  {path.name:44s} {lec.words:>5,} words  ~{lec.minutes} min")

    if not args.lesson:
        (out / "index.html").write_text(render_index(lectures), encoding="utf-8")
        (out / "all.html").write_text(render_all(lectures, terms), encoding="utf-8")
        total_words = sum(l.words for l in lectures)
        hours, mins = divmod(round(total_words / WPM), 60)
        print(f"\n  index.html and all.html written")
        print(f"  {len(lectures)} lectures, {total_words:,} words, "
              f"about {hours}h {mins}m spoken")

    hazards = sum(len(l.hazards) for l in lectures)
    if hazards:
        print(f"\n  {hazards} pronunciation hazard(s) remain — run with --check to see them")

    if args.show:
        print(f"\nOpen this in Edge:\n  {(out / 'index.html').resolve().as_uri()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
